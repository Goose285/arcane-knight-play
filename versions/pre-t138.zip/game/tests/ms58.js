// M58 (t135u/t136u/t137u): backups, tabbed pause menu, card descriptions + THUNDER FANG + NINJA STAR, first-fight lesson, guide + signs, reveals,
// RUN, world life (slimes eat flowers, chats, fog, pet pen), editor categories + undo/redo for every tool, dungeon kills stay dead.  node tests/ms58.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms58',{town:true,grow:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 // ---- 0. backups
 ok(fs.existsSync(__dirname+'/../scripts/snapshot.sh'),'scripts/snapshot.sh exists');
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t135/.test(tags),'backup tag backup-pre-t135 exists');
 await E(()=>__game.dbg.startFromTitle());await sleep(700);
 // ---- 1. pause menu
 let s=await E(async()=>{const k=__game.t135();__game.state='paused';await new Promise(r=>setTimeout(r,250));const ids=k.pauseRects.map(r=>r.e.id),out={ids,tabs:{}};
   for(const [t] of k.PM_TABS){k.pauseRects.find(r=>r.e.id===t).e.act();await new Promise(r=>setTimeout(r,120));out.tabs[t]=k.pauseRects.map(r=>r.e.id);}
   k.PM.tab='cards';await new Promise(r=>setTimeout(r,120));const c=k.pauseRects.find(r=>/^card:/.test(r.e.id));c.e.act();out.card=k.PM.card;await new Promise(r=>setTimeout(r,120));
   const d0=k.DECK.length,dec=k.pauseRects.find(r=>r.e.id==='dec:'+out.card);dec.e.act();out.dec=d0-k.DECK.length;k.pauseRects.find(r=>r.e.id==='inc:'+out.card)&&k.deckCount(out.card)<99&&k.pauseRects.find(r=>r.e.id==='inc:'+out.card).e.act();out.back=k.DECK.length===d0;
   k.PM.tab='inventory';await new Promise(r=>setTimeout(r,120));out.cats=k.pauseRects.filter(r=>/^cat:/.test(r.e.id)).map(r=>r.e.id);return out;});
 ok(['character','cards','inventory','journal','world','skills','settings'].every(t=>s.ids.includes(t)),'7 tabs: '+s.ids.slice(0,7));
 ok(Object.values(s.tabs).every(a=>['resume','home','quit','editor'].every(x=>a.includes(x))),'RESUME / HOME / SAVE & QUIT bar and EDITOR on every tab');
 ok(s.tabs.character.includes('pets')&&s.tabs.character.includes('ach')&&s.tabs.character.includes('daily')&&s.tabs.character.includes('lab'),'character tab: pets / achievements / daily / combat lab');
 ok(s.tabs.world.includes('travel')&&s.tabs.skills.includes('fish')&&s.tabs.skills.includes('craft')&&s.tabs.settings.includes('master+')&&s.tabs.settings.includes('cb+')&&s.tabs.settings.includes('text+'),'world TRAVEL, skills fishing/crafting, settings sliders + text size + colour-blind');
 ok(!!s.card&&s.dec===1&&s.back,'cards tab: tap a card for details, - / + change the deck');
 ok(s.cats.length===4,'inventory sidebar: potions / items / materials / key items');
 await E(()=>{__game.state='play';});
 // ---- 2. cards
 s=await E(()=>{const k=__game.t135();const ids=Object.keys(k.CARD);return {missing:ids.filter(id=>!k.cardInfo(id)||k.cardInfo(id).length<12),th:k.CARD.thunder&&k.CARD.thunder.name,st:k.CARD.star&&k.CARD.star.name,cast:typeof k.CAST.thunder+typeof k.CAST.star};});
 ok(!s.missing.length,'every card has a description (missing: '+s.missing+')');ok(s.th==='THUNDER FANG'&&s.st==='NINJA STAR'&&s.cast==='functionfunction','THUNDER FANG + NINJA STAR exist and cast');
 // ---- 3. first fight lesson
 s=await E(()=>{const k=__game.t135(),g=__game;window.__NOFF=false;k.QS.met.__ff=false;k.QS.st.slimes='active';
   const sl=k.enemies.filter(e=>e.type==='slime'&&e.alive).sort((a,b)=>Math.hypot(a.x-k.P.x,a.y-k.P.y)-Math.hypot(b.x-k.P.x,b.y-k.P.y)).slice(0,4);
   k.startEncounter(sl[0],true);const B=k.B;for(const e of sl.slice(1))if(!B.ens.includes(e)){B.ens.push(e);e.engaged=true;}
   k.ffBegin();const r={on:k.FF.on,n:B.ens.length,steps:[]};
   for(let i=0;i<k.FF_STEPS.length;i++){const ev=k.FF_STEPS[k.FF.step].ev;k.updateFF(.05);const s0=k.FF.step;k.TEV[ev]++;k.updateFF(.05);r.steps.push(ev+':'+(k.FF.step>s0||!k.FF.on));}
   r.done=!k.FF.on&&k.QS.met.__ff;window.__NOFF=true;return r;});
 ok(s.on&&s.n<=2,'first slime fight is a lesson with at most 2 slimes ('+s.n+')');
 ok(s.steps.every(x=>/true$/.test(x))&&s.steps.length===6,'lesson waits for each input in turn: '+s.steps.join(' '));ok(s.done,'lesson completes and is remembered');
 await E(()=>{const k=__game.t135();if(k.B){for(const e of k.B.ens){e.engaged=false;}}});await E(()=>__game.dbg.endBattle&&__game.dbg.endBattle());
 // ---- 4. guide + signs + reveal
 s=await E(()=>{const k=__game.t135();window.__NOREVEAL=false;k.revealCard('star');k.updateReveal(.1);const cur=k.REV.cur&&k.REV.cur.k;k.REV.cur=null;k.REV.q.length=0;window.__NOREVEAL=true;
   return {guide:k.NPCS.some(n=>n.guide),lines:k.guideLines().join('|'),signs:k.signs().map(n=>n.name),cur};});
 ok(s.guide,'Controls Guide sign exists');ok(/RUN/.test(s.lines)&&/DASH/i.test(s.lines)&&/(swipe|K: cast)/i.test(s.lines),'controls guide covers run, dash, swipes');
 ok(s.signs.length>=12,'signs at the significant places ('+s.signs.length+')');ok(s.cur==='card','new card triggers the reveal showcase');
 // ---- 5. RUN
 s=await E(()=>{const k=__game.t135();for(const e of k.enemies){e.chasing=false;}k.RUN.on=true;const a=k.runMul(),b=k.runBlocked();const e=k.enemies.find(q=>q.alive);e.chasing=true;const c=k.runMul(),d=k.runBlocked();e.chasing=false;k.RUN.on=false;return {a,b,c,d};});
 ok(s.a===1.6&&!s.b,'run = 1.6x outside combat');ok(s.c===1&&s.d==='aggro','run disabled while a monster is after you');
 // ---- 6. life
 s=await E(()=>{const k=__game.t135(),T=k.T,TS=k.TS;const e=k.enemies.find(q=>q.type==='slime'&&q.alive&&!q.engaged);e.mode='look';e.lifeCd=0;e.food=null;
   const tx=Math.floor(e.x/TS),ty=Math.floor((e.y-6)/TS);const fx=tx+1,fy=ty,old=k.map[fy][fx];k.map[fy][fx]=T.L;
   for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++)if((dx||dy)&&!(dx===1&&dy===0)&&k.map[ty+dy][tx+dx]===T.L)k.map[ty+dy][tx+dx]=T.G;
   k.lifeEnemy(e,.1);const tgt=e.food&&[e.food.x,e.food.y];e.x=(fx+.5)*TS;e.y=(fy+.6)*TS;k.lifeEnemy(e,.1);const eaten=k.map[fy][fx]===T.G,rg=k.LIFE.regrow.length;
   k.lifeRegrow(999);const back=k.map[fy][fx]===T.L;k.map[fy][fx]=old;return {tgt,eaten,rg,back};});
 ok(s.tgt&&s.eaten&&s.rg>0&&s.back,'a slime walks to a flower, eats it, and it regrows '+JSON.stringify(s));
 s=await E(()=>{const k=__game.t135();const n=k.NPCS.find(q=>q.name==='Elder Orin');k.P.x=n.x;k.P.y=n.y+60;k.LIFE.chatT=0;k.LIFE.bub.length=0;k.updateLife(.1);const b=k.LIFE.bub.length;
   return {b,tom:k.NPCS.some(q=>q.bench),lyn:k.NPCS.some(q=>q.garden),pen:k.PEN.on&&k.PEN.pets.length,perk:Object.keys(k.PET_PERK).length};});
 ok(s.b>=2,'villagers pair up and chat with speech bubbles');ok(s.tom&&s.lyn,'Old Tom sits on a bench, Gardener Lyn waters flowers');ok(s.pen>=3&&s.perk>=4,'pet pen with pets in town + pet perks');
 s=await E(()=>{const k=__game.t135(),TS=k.TS;let p=null;for(let y=k.OY+16;y<k.OY+44&&!p;y++)for(let x=k.OX+30;x<k.OX+60;x++)if(k.regions.forest(x,y)&&!k.solidTile(x,y)){p=[x,y];break;}
   k.P.x=(p[0]+.5)*TS;k.P.y=(p[1]+.5)*TS;k.FOG.next=0;k.FOG.target=0;for(let i=0;i<60;i++)k.updateLife(.1);return {a:k.FOG.a,t:k.FOG.target,here:k.fogHere()};});
 ok(s.here&&s.t>0&&s.a>.1,'fog rolls into Whisperwood at random times '+JSON.stringify(s));
 // ---- 7. editor: categories + undo/redo
 await E(()=>__game.dbg.edOpen());await sleep(300);
 s=await E(()=>{const k=__game.t135(),T=k.T;const want=['Ground','Paths','Water','Trees','Plants','Walls','Buildings','Props','Regions','NPCs/Enemies','All'];
   const trees=k.edCatItems('Trees').map(i=>i.id),ground=k.edCatItems('Ground').map(i=>i.id);
   return {cats:k.ED_CATS.join(','),ok:want.join(',')===k.ED_CATS.join(','),trees:[T.T,T.PN,T.PM,T.AC,T.ST].every(t=>trees.includes(t)),ground:[T.G,T.K,T.L,T.SD,T.MD,T.SN,T.MO,T.RG,T.VB,T.IC,T.CV].every(t=>ground.includes(t)),
     all:k.edCatItems('All').length===k.ED_ITEMS.length,empty:want.filter(c=>!k.edCatItems(c).length)};});
 ok(s.ok,'tray categories: '+s.cats);ok(s.trees,'every tree in Trees');ok(s.ground,'every ground tile in Ground');ok(s.all&&!s.empty.length,'All lists everything; no empty tab ('+s.empty+')');
 s=await E(()=>{const k=__game.t135(),T=k.T,TS=k.TS,P=k.P,res={};const cx=Math.floor(P.x/TS),cy=Math.floor(P.y/TS);
   let gx=null,gy=null;for(let r=3;r<20&&gx==null;r++)for(let dy=-r;dy<=r&&gx==null;dy++)for(let dx=-r;dx<=r;dx++){const x=cx+dx,y=cy+dy;if([0,1,2,3].every(i=>k.map[y][x+i]===T.G)&&[0,1,2,3].every(i=>k.map[y+1][x+i]===T.G)){gx=x;gy=y;break;}}
   const sig=()=>JSON.stringify([k.map[gy].slice(gx,gx+4),k.map[gy+1].slice(gx,gx+4)]);
   const chk=(name,op,extra)=>{const a=sig()+(extra?extra():'');k.edPush(op);const b=sig()+(extra?extra():'');k.edUndo();const c=sig()+(extra?extra():'');k.edRedo();const d=sig()+(extra?extra():'');k.edUndo();const e=sig()+(extra?extra():'');res[name]=[a!==b,a===c,b===d,a===e].join('');};
   chk('paint',{k:'tiles',t:[[gx,gy,T.SD],[gx+1,gy,T.SD]]});
   chk('prop',{k:'tiles',t:[[gx+2,gy,T.T]]});
   chk('erase',{k:'group',ops:[{k:'tiles',t:[[gx,gy,T.MD]]},{k:'tiles',t:[[gx+3,gy+1,T.L]]}]});
   const n=k.NPCS.find(q=>q.name==='Elder Orin'),ni=k.NPCS.indexOf(n);chk('npc',{k:'npc',i:ni,n:n.name,x:n.x+64,y:n.y},()=>n.x);
   chk('npcEdit',{k:'npcEdit',i:ni,n:n.name,label:'Bob'},()=>String(n.label));
   const e=k.enemies.find(q=>q.alive&&!q.def.boss&&!q.tmp&&!q.spw&&!q.night),fx=Math.floor(e.hx/TS),fy=Math.floor(e.hy/TS);chk('emove',{k:'emove',i:k.enemies.indexOf(e),type:e.type,fx,fy,tx:fx+1,ty:fy},()=>e.hx);
   chk('eadd',{k:'eadd',type:'slime',tx:gx,ty:gy+1},()=>k.enemies.length);
   chk('edel',{k:'edel',i:k.enemies.indexOf(e),type:e.type,fx,fy},()=>String(!!e.edDel));
   chk('nadd',{k:'nadd',key:'kid',tx:gx,ty:gy},()=>k.NPCS.length);
   const h=k.edHouses()[0];chk('house',{k:'house',x:h.x,y:h.y,w:h.w,nx:h.x,ny:h.y},()=>'');res.house='skip';
   k.map[gy][gx]=T.SD;k.edCopyGrab(gx,gy,gx+1,gy);const n0=k.ED.ops.length;k.edCopyStamp(gx+2,gy);const one=k.ED.ops.length-n0;const mid=k.map[gy][gx+2];k.edUndo();res.copy=[one===1,mid===T.SD,k.map[gy][gx+2]===T.G].join('');k.map[gy][gx]=T.G;
   return res;});
 for(const [t,v] of Object.entries(s))if(v!=='skip')ok(v==='truetruetruetrue'||v==='truetruetrue','undo/redo: '+t+' ('+v+')');
 await E(()=>__game.dbg.edExit?__game.dbg.edExit():(__game.state='play'));await sleep(200);
 // ---- 8. old editor layers keep their NPC indices
 s=await E(()=>{const k=__game.t135(),nb=k.ED.base.npcs.length;const a=k.edShiftNb({},[{k:'npc',i:nb-k.NEW_NPCS_T135,n:'x'},{k:'group',ops:[{k:'ndel',i:nb-k.NEW_NPCS_T135+1}]}]),b=k.edShiftNb({nb},[{k:'npc',i:nb,n:'x'}]);return [a[0].i===nb,a[1].ops[0].i===nb+1,b[0].i===nb];});
 ok(s.every(Boolean),'editor layers written before t135 keep pointing at the right NPCs');
 // ---- 9. dungeon kills stay dead until re-entry
 s=await E(async()=>{const k=__game.t135(),TS=k.TS;const z='snow',es=k.enemies.filter(e=>k.enemyZone(e)===z&&!e.def.boss&&!e.night&&!e.spw&&!e.tmp);
   const e=es[0],far=es.find(q=>Math.hypot(q.x-e.x,q.y-e.y)>12*TS)||es[1];k.P.x=far.x;k.P.y=far.y;k.P.grace=99;k.lifeZoneTick();
   for(const q of es){q.alive=true;}e.alive=false;e.respawn=.3;const hold=k.dungeonHold(e);await new Promise(r=>setTimeout(r,1200));const still=!e.alive;
   const o=k.enemies.find(q=>k.enemyZone(q)==='ow'&&q.alive&&!q.def.boss);
   k.P.x=k.NPCS[0].x;k.P.y=k.NPCS[0].y;k.lifeZoneTick();const outside=!e.alive;k.P.x=far.x;k.P.y=far.y;k.lifeZoneTick();const back=e.alive;
   k.P.x=k.NPCS[0].x;k.P.y=k.NPCS[0].y;k.lifeZoneTick();return {n:es.length,hold,still,outside,back,zs:[...k.DUNGEON_ZONES].join(',')};});
 ok(s.n>0&&s.hold&&s.still,'a monster killed inside a dungeon stays dead while you are inside');ok(s.back,'leaving and re-entering the dungeon brings it back');ok(/crypt/.test(s.zs)&&/desert/.test(s.zs)&&/swamp/.test(s.zs),'applies to every dungeon ('+s.zs+')');
 ok(!errs.length,'no page errors '+errs.slice(0,3).join(' | '));
 await finish();
})();
