/* =====================================================================
   FIRST 5 MINUTES (t135u)
   1. GUIDE TRAIL: glowing footsteps from the hero toward the current objective (Elder Orin, then the slimes) while the first quest runs.
   2. FIRST FIGHT: the first slime fight holds at most 2 slimes and is a guided lesson. The slimes stay harmless and cannot be finished
      until every step is done, each one waiting for the player:
        shoot  ->  charged shot  ->  dash  ->  tap a card + tap a target  ->  swipe a card UP (quick-cast at the nearest foe)
        ->  swipe a card DOWN (discard it: the empty slot refills sooner)  ->  "finish them!"
      Keyboard: J / hold J / Shift / click card + click target / K / X.
   3. CONTROLS GUIDE: a sign by the fountain (and the JOURNAL) re-opens the full controls guide at any time.
   TEV counts the player's inputs (used by the lesson and by tests).
   ===================================================================== */
const TEV={shot:0,charged:0,dash:0,aim:0,up:0,down:0,run:0};
const FF={on:false,step:0,flash:0,skipR:null};
const ffOff=()=>window.__NOFF===true;
const FF_STEPS=[
  {ev:'shot',   t:'Tap SHOT to fire an arcane bolt',                                k:'Press J to fire an arcane bolt'},
  {ev:'charged',t:'HOLD SHOT until it glows, then let go: a CHARGED blast (5x)',     k:'HOLD J until it glows, then release: a CHARGED blast (5x)'},
  {ev:'dash',   t:'FLICK your finger across open screen to DASH (2.5s cooldown)',   k:'Press SHIFT to DASH where you move (2.5s cooldown)'},
  {ev:'aim',    t:'Tap a CARD, then tap where it should go (or on a monster)',      k:'Click a CARD, then click where it should go (or on a monster)'},
  {ev:'up',     t:'Swipe a card UP: it casts at the nearest monster right away',    k:'Press K: casts the highlighted card at the nearest monster'},
  {ev:'down',   t:'Swipe a card DOWN: discard it - its slot refills sooner',        k:'Press X: discard the highlighted card - its slot refills sooner'},
];
function ffEligible(){return !ffOff()&&!(QS.met&&QS.met.__ff)&&QS.st&&QS.st.slimes!=='done';}
function ffBegin(){
  if(!B||!ffEligible()||!B.ens.length||!B.ens.every(e=>e.type==='slime'))return;
  // a beginner's fight: at most 2 slimes, the rest go back to their meadow
  for(const e of B.ens.slice(2)){e.engaged=false;e.st='idle';e.cur=null;}B.ens=B.ens.slice(0,2);B.total=B.ens.length;
  FF.on=true;FF.step=0;FF.flash=1;B.ffTut=true;B.phase='fight';TEV0=Object.assign({},TEV);ffFillHand();
}
let TEV0=null;
function ffDoneStep(){const s=FF_STEPS[FF.step];return s&&TEV[s.ev]>TEV0[s.ev];}
function ffFillHand(){if(!B||!B.hand)return;const want=FF.step===3?['fire','fire']:['sword','fire'];for(let i=0;i<B.hand.length&&i<2;i++)if(!B.hand[i])B.hand[i]=want[i];
  if(FF.step===3&&!B.hand.some(id=>id&&typeof expAimed==='function'&&expAimed(id)))B.hand[0]='fire';}
function ffFinish(skipped){FF.on=false;if(B)B.ffTut=false;QS.met.__ff=true;if(!skipped){toast('Lesson complete! Now finish the slimes!',2.6,'#9be8a0');sfx('questdone');}saveGame('ff');}
function updateFF(dt){
  FF.flash=Math.max(0,FF.flash-dt);
  if(!FF.on)return;if(!B){FF.on=false;return;}
  for(const e of B.ens){e.atkCd=Math.max(e.atkCd||0,1);}          // harmless while learning
  if(ffDoneStep()){FF.step++;FF.flash=1;sfx('select');TEV0=Object.assign({},TEV);if(FF.step>=FF_STEPS.length){ffFinish(false);return;}}
  ffFillHand();
}
const ffProtect=()=>!!(FF.on&&B&&B.ffTut);
function drawFF(){
  if(!FF.on||!B)return;const s=FF_STEPS[FF.step];if(!s)return;
  const w=Math.min(VW-SL-SR-24,420),x=Math.round(VW/2-w/2),y=ST+64,h=56;
  ctx.fillStyle='rgba(20,12,4,.88)';ctx.fillRect(x,y,w,h);ctx.strokeStyle=FF.flash>0?'#fff':'#e0b44a';ctx.lineWidth=2;ctx.strokeRect(x+1,y+1,w-2,h-2);
  txt('LESSON '+(FF.step+1)+'/'+FF_STEPS.length,x+10,y+14,{size:9,col:'#ffe27a',lw:2});
  const font='bold '+scaleText(11)+'px "Courier New",monospace',ls=wrapText(TOUCH?s.t:s.k,w-20,font);ls.slice(0,2).forEach((l,i)=>txt(l,x+10,y+30+i*14,{size:11,col:'#fff3d0',lw:3}));
  for(let i=0;i<FF_STEPS.length;i++){ctx.fillStyle=i<FF.step?'#9be8a0':i===FF.step?'#ffe14d':'#4a3a2a';ctx.fillRect(x+w-14-(FF_STEPS.length-i)*12,y+7,8,8);}
  FF.skipR={x:x+w-52,y:y+h+4,w:52,h:18};ctx.fillStyle='rgba(20,12,4,.8)';ctx.fillRect(FF.skipR.x,FF.skipR.y,52,18);txt('SKIP',FF.skipR.x+26,FF.skipR.y+13,{size:9,align:'center',col:'#cfe0ff',lw:2});
  // pointer toward the card hand / SHOT button on touch
  if(TOUCH&&FF.step!==2){const b=btn.atk;if(b){const bob=Math.sin(gtime*6)*5;ctx.fillStyle='#ffe14d';const tx=b.x+(FF.step>=3?-70:0),ty=b.y-b.r-22+bob-(FF.step>=3?30:0);ctx.beginPath();ctx.moveTo(tx,ty+14);ctx.lineTo(tx-8,ty);ctx.lineTo(tx+8,ty);ctx.closePath();ctx.fill();}}
}
function ffTap(p){if(FF.on&&FF.skipR&&inRect(p,FF.skipR)){ffFinish(true);return true;}return false;}
/* ---- guide trail: footsteps to the objective during the first quest ---- */
const GT={pts:[],t:0,key:''};
function guideTarget(){
  if(window.__NOGUIDE||B||state!=='play')return null;
  const intro=typeof introActive==='function'&&introActive();if(!intro&&!(QS.st&&QS.st.slimes&&QS.st.slimes!=='done'))return null;
  try{const l=trkEntries(),c=trkCurrent(l),tg=c&&trkTarget(c);if(tg)return tg;}catch(e){}
  return null;
}
function updateGuide(dt){
  GT.t-=dt;if(GT.t>0)return;GT.t=.5;const tg=guideTarget();if(!tg){GT.pts=[];return;}
  const sx=Math.floor(P.x/TS),sy=Math.floor((P.y-6)/TS),gx=Math.floor(tg.x/TS),gy=Math.floor((tg.y-6)/TS);
  if(Math.hypot(gx-sx,gy-sy)<3){GT.pts=[];return;}
  const p=rtPath(sx,sy,(x,y)=>Math.abs(x-gx)+Math.abs(y-gy)<=1);GT.pts=p?p.slice(1,40):[];
}
function drawGuide(){
  if(!GT.pts.length||B)return;
  for(let i=0;i<GT.pts.length;i+=2){const [x,y]=GT.pts[i],ph=((gtime*2.5-i*.18)%2+2)%2,a=ph<1?.25+.6*(1-ph):.25;
    const nx=GT.pts[Math.min(GT.pts.length-1,i+1)],an=Math.atan2(nx[1]-y,nx[0]-x),cx=x*TS+16-cam.x,cy=y*TS+20-cam.y;
    ctx.save();ctx.translate(cx,cy);ctx.rotate(an);ctx.globalAlpha=a;ctx.fillStyle='#ffe14d';ctx.beginPath();ctx.moveTo(7,0);ctx.lineTo(-4,-5);ctx.lineTo(-1,0);ctx.lineTo(-4,5);ctx.closePath();ctx.fill();ctx.restore();}
  ctx.globalAlpha=1;
}
/* ---- the controls guide (signs + journal) ---- */
function guideLines(){
  const T_=TOUCH;
  return [
    'CONTROLS GUIDE  (read this sign again any time)',
    T_?'MOVE: drag the left stick. Tap a person or place to walk there.':'MOVE: WASD or arrow keys. E or click to talk.',
    T_?'RUN: tap RUN above the stick (or double-tap and hold the stick). 1.6x speed - only when no monster is after you.':'RUN: hold R. 1.6x speed - only when no monster is after you.',
    T_?'SHOOT: tap SHOT. HOLD SHOT and let go for a CHARGED blast (5x damage).':'SHOOT: J. HOLD J and release for a CHARGED blast (5x damage).',
    T_?'DASH: flick across open screen. 2.5s cooldown (ring at your feet). Dodges hits.':'DASH: SHIFT. 2.5s cooldown (ring at your feet). Dodges hits.',
    T_?'CARDS: tap a card, then tap where it should go. Buffs cast on one tap.':'CARDS: click a card (or 1-4), then click where it should go. Buffs cast at once.',
    T_?'SWIPE a card UP: cast it at the nearest monster. SWIPE DOWN: discard it (slot refills sooner). Drag along the fan to turn it.':'K: cast the highlighted card at the nearest monster. X: discard it (slot refills sooner). L: next card.',
    'One new card arrives every 2.5s. Some pairs of cards make a COMBO.',
    T_?'MENU: II (top right): character, cards, inventory, journal, world map, skills, settings.':'MENU: P or Esc: character, cards, inventory, journal, world map, skills, settings.',
    'Signs like this one stand at every important place: shops, gates, waystones, the pet pen.'];
}
function openGuide(){DLG={name:'CONTROLS GUIDE',lines:guideLines().slice(1),i:0,c:0};sfx('talk');}
