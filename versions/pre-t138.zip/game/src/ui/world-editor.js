/* =====================================================================
   WORLD EDITOR (pause menu -> EDITOR). Touch-first: drag to move houses / NPCs / guards / trees / props / enemy spawns (tile snap; collision and door
   triggers follow because they are tile / door based), paint ground, place + delete props. Two fingers pan + pinch-zoom (integer pixel-scale steps).
   Every edit is an entry in an ordered op list kept in localStorage ('ak_world_edits_v1'); on load the ops are replayed over the freshly built world.
   Undo / redo = re-apply the list over a snapshot of the untouched world. EXPORT shows the op list as JSON to copy; RESET removes all edits.
   ===================================================================== */
const ED_KEY='ak_world_edits_v1';
let EDS=0;                                   // pixel-scale override while editing (0 = normal); read by resize()
const ED={bakedOps:[],pub:{msg:'',col:'#fff',t:-99,busy:false},item:'t:'+T.G,cat:'Ground',trayX:0,trayMax:0,cells:[],hover:null,barTop:0,hold:null,holdT:0,expN:8,on:false,tool:'move',ground:T.G,prop:T.T,brush:1,ops:[],redo:[],base:null,ptrs:new Map(),drag:null,pan:null,stroke:null,pinch:null,sel:null,rects:[],msg:'',msgT:0,resetAt:-99,s0:1};
const edOW=py=>py>=OWY0*TS&&py<(OWY0+OW_H)*TS;                      // is this pixel row inside the overworld block?
const edIn=(x,y)=>x>=1&&y>=OWY0+1&&x<MW-1&&y<OWY0+OW_H-2;
function edMini(x,y){try{const g=miniMap.getContext('2d');g.fillStyle=TSPR.mini[map[y][x]]||'#000';g.fillRect(x*2,(y-OWY0)*2,2,2);}catch(e){}}
/* road + water edges are drawn from the map around each tile: refresh the cached look of a tile and its neighbours after it changes */
function edInvalidate(x,y){
  for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=MW||ny>=MH)continue;const k=ny*MW+nx;PATH_CACHE.delete(k);if(EDGE_MEMO)EDGE_MEMO[k]=0;
    if(WE_MASK&&Math.abs(dx)<=1&&Math.abs(dy)<=1){const id=map[ny][nx],wt=WE_WATER.has(id),lt=!wt&&WE_LAND.has(id);let m=0;
      if(wt||lt)for(let i=0;i<8;i++){const ax=nx+WE_DIRS[i][0],ay=ny+WE_DIRS[i][1];if(ax<0||ay<0||ax>=MW||ay>=MH)continue;const n=map[ay][ax];if(wt?WE_LAND.has(n):WE_WATER.has(n))m|=1<<i;}
      WE_MASK[k]=m;}}
}
function edSetTile(x,y,id){if(!edIn(x,y))return;map[y][x]=id;edMini(x,y);edInvalidate(x,y);}
/* ---- WORLD EXPANSION ----
   EXPAND adds grass rows / columns on any side of the overworld. The overworld block of the shared map is rebuilt at the new size; once it grows north or south
   it moves down to start at row 224 (below the house room) so the interiors (crypt, regions, arena, house) never move. Everything that stands on the overworld
   (NPCs, guards, spawns, doors, gates, waystones, fishing spots, quest spots, the town / chapel / inn rectangles, the player...) is shifted by the same amount.
   OX / OY = how far the authored overworld sits from the top-left of the world now; EXP = tiles added per side. edGeom(W,N,E,S) goes from the current size to any target. */
const EXP={W:0,N:0,E:0,S:0},EXP0={W:0,N:0,E:0,S:0},ED_MAXSIDE=96;   // EXP0 = the size the game itself ships with (Oakvale's southern quarter + Goldenfield are built in); edits add to it
function edGeom(nW,nN,nE,nS){
  const oOWY0=OWY0,oOWH=OW_H,oMW=MW,oOX=OX,oOY=OY;
  const reloc=nN>0||nS>0,nOWY0=reloc?224:0,nOWH=48+nN+nS,nMW=64+nW+nE,nMH=reloc?224+nOWH:224,nOX=nW,nOY=nOWY0+nN;
  const ddx=nOX-oOX,ddy=nOY-oOY;
  const owPx=y=>y>=oOWY0*TS&&y<(oOWY0+oOWH)*TS,owTy=ty=>ty>=oOWY0&&ty<oOWY0+oOWH;
  // 1. shift everything that stands on the overworld (classified with the OLD layout)
  const px=(o,kx,ky)=>{if(o[kx]!=null){o[kx]+=ddx*TS;o[ky]+=ddy*TS;}},tl=(o,kx,ky)=>{if(o[kx]!=null){o[kx]+=ddx;o[ky]+=ddy;}};
  for(const n of NPCS)if(owPx(n.y)){px(n,'x','y');px(n,'hx','hy');}
  for(const e of enemies)if(owPx(e.hy)){px(e,'x','y');px(e,'hx','hy');if(e.terr){e.terr.x0+=ddx*TS;e.terr.x1+=ddx*TS;e.terr.y0+=ddy*TS;e.terr.y1+=ddy*TS;}e.path=null;}
  for(const sp of SPW)if(owPx(sp.y))px(sp,'x','y');
  for(const d of SPAWNER_DEFS)if(owTy(d.ty))tl(d,'tx','ty');
  for(const f of FISH_SPOTS)if(owTy(f.ty)){tl(f,'tx','ty');f.bank[0]+=ddx;f.bank[1]+=ddy;if(f.pond){f.pond.x+=ddx;f.pond.y+=ddy;}}
  for(const w of WAYSTONES)if(w.tx!=null&&owTy(w.ty)){tl(w,'tx','ty');px(w.to,'x','y');}
  for(const m of TMAPS)tl(m,'x','y');
  for(const q of QWORLD)tl(q,'tx','ty');
  for(const q of QUESTS)if(q.obj&&q.obj.k==='find')tl(q.obj,'tx','ty');
  for(const id in ZONES)tl(ZONES[id].gate,'x','y');
  for(const k in GATES)delete GATES[k];for(const id in ZONES){const g=ZONES[id].gate;GATES[g.x+','+g.y]=id;}
  CHAPEL.x0+=ddx;CHAPEL.x1+=ddx;CHAPEL.door+=ddx;CHAPEL.cross.x+=ddx;CHAPEL.y0+=ddy;CHAPEL.y1+=ddy;CHAPEL.cross.y+=ddy;
  INN.x0+=ddx;INN.x1+=ddx;INN.door+=ddx;INN.y0+=ddy;INN.y1+=ddy;
  TOWN.x0+=ddx*TS;TOWN.x1+=ddx*TS;TOWN.y0+=ddy*TS;TOWN.y1+=ddy*TS;
  VILLAGE_POND.x0+=ddx;VILLAGE_POND.x1+=ddx;VILLAGE_POND.y0+=ddy;VILLAGE_POND.y1+=ddy;VILLAGE_FIRE.x+=ddx;VILLAGE_FIRE.y+=ddy;
  for(const r of REGION_LABELS)tl(r,'tx','ty');for(const a of ORCHARD){a[0]+=ddx;a[1]+=ddy;}for(const a of VILLAGE_LANTERNS){a[0]+=ddx;a[1]+=ddy;}
  tl(HOUSE_DOOR,'tx','ty');px(HOUSE_FRONT,'x','y');px(HOUSE_OUT,'x','y');tl(GOBLIN_CAMP,'tx','ty');
  px(SPAWN,'x','y');tl(CRYPT_IN,'x','y');px(CRYPT_OUT,'x','y');px(WARP_DEST.out,'x','y');
  if(owPx(PET.y)){px(PET,'x','y');PET.trail.length=0;}
  if(owPx(P.y))px(P,'x','y');
  cam.x+=ddx*TS;cam.y+=ddy*TS;
  // 2. rebuild the map: overworld block (old tiles at the new offset, grass elsewhere) + the interior rows (padded / cropped to the new width)
  const nm=[],oldRow=y=>map[y];
  for(let y=0;y<nMH;y++){
    let row;
    if(y>=nOWY0&&y<nOWY0+nOWH){
      row=new Array(nMW);const sy=y-nOWY0-(nN-EXP.N)+oOWY0,srow=sy>=oOWY0&&sy<oOWY0+oOWH?oldRow(sy):null;   // source row inside the old overworld
      for(let x=0;x<nMW;x++){const sx=x-(nW-EXP.W);row[x]=srow&&sx>=0&&sx<oMW?srow[sx]:T.G;}
    }else if(y>=48&&y<224){const r0=oldRow(y);row=new Array(nMW);const edge=r0[63];for(let x=0;x<nMW;x++)row[x]=x<oMW?r0[x]:edge;}
    else{row=new Array(nMW).fill(T.CW);}                                 // rows the overworld left behind (above the interiors): solid filler
    nm.push(row);
  }
  map.length=0;for(const r of nm)map.push(r);
  MW=nMW;MH=nMH;OW_H=nOWH;OWY0=nOWY0;OX=nOX;OY=nOY;EXP.W=nW;EXP.N=nN;EXP.E=nE;EXP.S=nS;
  edMapChanged();
}
/* everything derived from the map / its size: caches, walkability, minimap (also called after a whole region is authored in code) */
function edMapChanged(){
  BLOSSOM=new Uint8Array(MW*MH);TREE_TILE=new Array(MW*MH);TREE_TILE_ID=new Uint8Array(MW*MH);BIGT_CACHE.clear();TREE_FADE.clear();
  WE_MASK=null;WE_CACHE.clear();EDGE_MEMO=null;PATH_CACHE.clear();INN_CACHE.clear();TRK.cache={};WS.length=0;
  reach.length=0;for(let y=0;y<MH;y++)reach.push(new Array(MW).fill(false));
  {const sx=Math.floor(SPAWN.x/TS),sy=Math.floor(SPAWN.y/TS),q=[[sx,sy]];reach[sy][sx]=true;
   while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(!solidTile(nx,ny)&&!reach[ny][nx]){reach[ny][nx]=true;q.push([nx,ny]);}}}}
  miniMap.width=MW*2;miniMap.height=OW_H*2;MINI.ow.y0=OWY0;
  {const g=miniMap.getContext('2d');for(let y=0;y<OW_H;y++)for(let x=0;x<MW;x++){g.fillStyle=TSPR.mini[map[OWY0+y][x]]||'#000';g.fillRect(x*2,y*2,2,2);}}
  ED.sel=null;
}
function edSnap(){
  ED.base={map:map.slice(OWY0,OWY0+OW_H).map(r=>Array.from(r)),   // t135u fix: the overworld rows (it starts at OWY0, row 224 in the grown world) - undo used to restore rows 0.. (the crypt) and never the overworld
    npcs:NPCS.map(n=>({x:n.x,y:n.y,hx:n.hx,hy:n.hy,label:n.label,lines:n.lines&&n.lines.slice()})),
    en:enemies.length,enp:enemies.map(e=>({x:e.x,y:e.y,hx:e.hx,hy:e.hy})),door:{...HOUSE_DOOR},front:{...HOUSE_FRONT},out:{...HOUSE_OUT},inn:{...INN}};
}
function edRestore(){
  const b=ED.base;if(!b)return;
  if(EXP.W!==EXP0.W||EXP.N!==EXP0.N||EXP.E!==EXP0.E||EXP.S!==EXP0.S)edGeom(EXP0.W,EXP0.N,EXP0.E,EXP0.S);   // back to the shipped size (the replay re-applies every EXPAND in order)
  for(let y=0;y<OW_H;y++){const row=map[OWY0+y],br=b.map[y];if(!br)continue;for(let x=0;x<MW;x++)if(row[x]!==br[x]){row[x]=br[x];edMini(x,OWY0+y);edInvalidate(x,OWY0+y);}}
  if(NPCS.length>b.npcs.length)NPCS.length=b.npcs.length;
  NPCS.forEach((n,i)=>{const s=b.npcs[i];if(!s)return;n.x=s.x;n.y=s.y;if(s.hx!=null){n.hx=s.hx;n.hy=s.hy;}if(s.label===undefined)delete n.label;else n.label=s.label;if(s.lines)n.lines=s.lines.slice();});
  if(enemies.length>b.en)enemies.length=b.en;
  enemies.forEach((e,i)=>{const s=b.enp[i];if(!s)return;e.x=s.x;e.y=s.y;e.hx=s.hx;e.hy=s.hy;if(e.edDel){e.edDel=false;e.alive=true;e.dying=false;e.respawn=0;}});
  Object.assign(HOUSE_DOOR,b.door);Object.assign(HOUSE_FRONT,b.front);Object.assign(HOUSE_OUT,b.out);Object.assign(INN,b.inn);
}
/* houses = a roof row, an eave row and a wall row with one door, found from the map */
function edHouses(){
  const out=[];
  for(let y=OWY0+2;y<OWY0+OW_H;y++)for(let x=0;x<MW;x++){
    if(map[y][x]!==T.D||map[y-2][x]!==T.R)continue;
    let x0=x,x1=x;while(x0>0&&map[y][x0-1]===T.H&&map[y-2][x0-1]===T.R)x0--;while(x1<MW-1&&map[y][x1+1]===T.H&&map[y-2][x1+1]===T.R)x1++;
    out.push({x:x0,y:y-2,w:x1-x0+1,dx:x,dy:y});
  }
  return out;
}
const edHouseAt=(tx,ty)=>edHouses().find(h=>tx>=h.x&&tx<h.x+h.w&&ty>=h.y&&ty<=h.y+2)||null;
function edMoveHouse(op){
  const ids=[];for(let r=0;r<3;r++){ids.push([]);for(let c=0;c<op.w;c++)ids[r].push(map[op.y+r][op.x+c]);}
  const dx=op.nx-op.x,dy=op.ny-op.y;
  for(let r=0;r<3;r++)for(let c=0;c<op.w;c++)edSetTile(op.x+c,op.y+r,T.G);
  for(let r=0;r<3;r++)for(let c=0;c<op.w;c++)edSetTile(op.nx+c,op.ny+r,ids[r][c]);
  if(op.x+(op.w>>1)===HOUSE_DOOR.tx&&op.y+2===HOUSE_DOOR.ty-1){HOUSE_DOOR.tx+=dx;HOUSE_DOOR.ty+=dy;HOUSE_FRONT.x+=dx*TS;HOUSE_FRONT.y+=dy*TS;HOUSE_OUT.x+=dx*TS;HOUSE_OUT.y+=dy*TS;}   // your house: door trigger + exit follow
  if(op.x===INN.x0&&op.y===INN.y0){INN.x0+=dx;INN.x1+=dx;INN.door+=dx;INN.y0+=dy;INN.y1+=dy;}                                                           // the Inn's look follows
}
function edFindEnemy(op){
  const m=e=>e.type===op.type&&Math.floor(e.hx/TS)===op.fx&&Math.floor(e.hy/TS)===op.fy,e0=enemies[op.i];
  if(e0&&m(e0))return e0;return enemies.find(m)||null;
}
function edApply(op){
  switch(op.k){
    case 'tiles':for(const [x,y,id] of op.t)edSetTile(x,y,id);break;
    case 'group':for(const o of op.ops)edApply(o);break;   // one undo step (an erase stroke, a COPY stamp)
    case 'expand':{const n=op.n|0,d=op.d;edGeom(EXP.W+(d==='w'?n:0),EXP.N+(d==='n'?n:0),EXP.E+(d==='e'?n:0),EXP.S+(d==='s'?n:0));break;}
    case 'house':edMoveHouse(op);break;
    case 'npc':{const n=NPCS[op.i];if(n&&n.name===op.n){n.x=op.x;n.y=op.y;if(n.hx!=null){n.hx=op.x;n.hy=op.y;}}break;}
    case 'npcEdit':{const n=NPCS[op.i];if(n&&n.name===op.n){if(op.label!==undefined)n.label=op.label;if(op.lines)n.lines=op.lines.slice();}break;}
    case 'emove':{const e=edFindEnemy(op);if(e){e.hx=e.x=op.tx*TS+TS/2;e.hy=e.y=op.ty*TS+TS-4;}break;}   // op: {i,type,fx,fy} = which one, {tx,ty} = new tile
    case 'eadd':addEnemy(op.type,op.tx,op.ty);break;
    case 'nadd':{const d=ED_NPC_DEFS[op.key];if(d)NPCS.push({name:op.name||d.name,x:(op.tx+.5)*TS,y:(op.ty+.9)*TS,spr:d.spr,lines:(op.lines||d.lines).slice(),edAdded:true});break;}
    case 'ndel':{const n=NPCS[op.i];if(n&&n.edAdded){n.x=n.hx=-9999;n.y=n.hy=-9999;}break;}
    case 'edel':{const e=edFindEnemy(op);if(e){e.alive=false;e.edDel=true;e.dying=false;e.engaged=false;}break;}
  }
}
function edSave(){try{if(ED.ops.length)localStorage.setItem(ED_KEY,JSON.stringify({v:2,g:edGV(),nb:ED.base?ED.base.npcs.length:NPCS.length,ops:ED.ops}));else localStorage.removeItem(ED_KEY);}catch(e){}}
function edRebuild(){edRestore();for(const o of ED.bakedOps)edApply(o);for(const o of ED.ops)edApply(o);}   // baked layer (world-edits.json) first, then this device's own edits
function edPush(op){ED.ops.push(op);ED.redo.length=0;edApply(op);edSave();}
function edUndo(){if(!ED.ops.length)return edMsg('Nothing to undo');ED.redo.push(ED.ops.pop());edRebuild();edSave();ED.sel=null;edMsg('Undone');}
function edRedo(){if(!ED.redo.length)return edMsg('Nothing to redo');ED.ops.push(ED.redo.pop());edRebuild();edSave();edMsg('Redone');}
function edReset(){
  if(gtime-ED.resetAt>3){ED.resetAt=gtime;edMsg('Tap RESET again to remove ALL edits');return;}
  ED.ops=[];ED.redo=[];edRebuild();edSave();ED.sel=null;ED.resetAt=-99;edMsg('All edits removed');
}
function edMsg(s){ED.msg=s;ED.msgT=gtime;}
const edJSON=()=>JSON.stringify({v:2,world:{cols:MW,rows:OW_H,expand:{n:EXP.N,s:EXP.S,e:EXP.E,w:EXP.W}},ops:ED.ops});
function edExportBox(){
  let o=document.getElementById('edExport');
  if(!o){
    o=document.createElement('div');o.id='edExport';o.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(10,6,2,.92);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;font:bold 14px monospace;color:#fff3d0';
    const t=document.createElement('div');t.textContent='WORLD EDITS (copy this and send it to be baked in)';
    const ta=document.createElement('textarea');ta.id='edExportText';ta.readOnly=true;ta.style.cssText='width:86%;height:55%;font:12px monospace;background:#1c1208;color:#ffe9a0;border:2px solid #c89858';
    const row=document.createElement('div');row.style.cssText='display:flex;gap:14px';
    const mk=(lab,fn)=>{const b=document.createElement('button');b.textContent=lab;b.style.cssText='font:bold 16px monospace;padding:12px 26px;background:#7a5530;color:#fff3d0;border:2px solid #e0b44a;border-radius:6px';b.onclick=fn;return b;};
    row.appendChild(mk('COPY',()=>{ta.focus();ta.select();ta.setSelectionRange(0,1e9);let ok=false;try{if(navigator.clipboard)navigator.clipboard.writeText(ta.value).catch(()=>{});ok=document.execCommand('copy');}catch(e){}t.textContent=ok?'Copied! Paste it in the chat.':'Select all + copy (long-press the text)';}));
    row.appendChild(mk('CLOSE',()=>{o.style.display='none';}));
    o.appendChild(t);o.appendChild(ta);o.appendChild(row);document.body.appendChild(o);
  }
  o.style.display='flex';o.querySelector('#edExportText').value=edJSON();o.firstChild.textContent='WORLD EDITS ('+ED.ops.length+' changes) - copy this and send it to be baked in';
}
/* ---- open / close ---- */
function edOpen(){
  if(B||DLG||zoneOfPx(P.y)!=='ow'){toast('The editor works in Oakvale and the open world',2,'#ffb0a0');return;}
  ED.on=true;state='editor';ED.tool='move';ED.hold=null;ED.sel=null;ED.drag=ED.pan=ED.stroke=ED.pinch=null;ED.ptrs.clear();ED.redo.length=0;releaseAllTouch();
  ED.s0=S;EDS=0;resize();cam.x=P.x-VW/2;cam.y=P.y-VH/2;edClampCam();edMsg('Drag things to move them. Two fingers pan / zoom.');
}
function edExit(){ED.on=false;state='play';EDS=0;resize();snapCam();ED.ptrs.clear();ED.drag=ED.pan=ED.stroke=ED.pinch=null;const o=document.getElementById('edExport');if(o)o.style.display='none';releaseAllTouch();}
const ED_MARGIN=5;   // tiles the camera may drift past the map edge
function edClampCam(){const m=ED_MARGIN*TS,x0=-m,y0=OWY0*TS-m,x1=Math.max(x0,MW*TS-VW+m),y1=Math.max(y0,(OWY0+OW_H)*TS-VH+m);cam.x=clamp(cam.x,x0,x1);cam.y=clamp(cam.y,y0,y1);}
function edZoom(d){
  const cs=EDS||S,ns=clamp(cs+d,1,6);if(ns===cs)return;
  const c={x:cam.x+VW/2,y:cam.y+VH/2};EDS=ns;resize();cam.x=c.x-VW/2;cam.y=c.y-VH/2;edClampCam();
}
/* ---- pointers ---- */
const edW=p=>({x:p.x+Math.round(cam.x),y:p.y+Math.round(cam.y)});
function edHit(wx,wy){   // what is under a world point: NPC > enemy spawn > house > prop tile
  const tx=Math.floor(wx/TS),ty=Math.floor(wy/TS);
  for(let i=NPCS.length-1;i>=0;i--){const n=NPCS[i];if(!edOW(n.y))continue;if(Math.abs(wx-n.x)<17&&wy>n.y-38&&wy<n.y+8)return {kind:'npc',i,n};}
  for(let i=enemies.length-1;i>=0;i--){const e=enemies[i];if(e.def.boss||e.night||e.edDel||e.spw||e.rush||e.tmp||!edOW(e.hy))continue;if(Math.abs(wx-e.hx)<15&&Math.abs(wy-(e.hy-10))<17)return {kind:'enemy',i,e};}
  const h=edHouseAt(tx,ty);if(h)return {kind:'house',h};
  if(edIn(tx,ty)&&ED_PROPSET.has(map[ty][tx]))return {kind:'prop',tx,ty,id:map[ty][tx]};
  return null;
}
function edBrushTiles(tx,ty){const n=ED.brush,o=Math.floor((n-1)/2),out=[];for(let y=0;y<n;y++)for(let x=0;x<n;x++)out.push([tx-o+x,ty-o+y]);return out;}
function edStrokeAt(tx,ty){
  const s=ED.stroke;if(!s||s.pending)return;
  const key=tx+','+ty;if(s.seen.has(key))return;s.seen.add(key);
  if(ED.tool==='paint'){
    for(const [x,y] of edBrushTiles(tx,ty)){if(!edIn(x,y)||!ED_OKSET.has(map[y][x]))continue;
      if(map[y][x]===ED.ground||isVillagePondTile(x,y))continue;s.t.push([x,y,ED.ground]);edSetTile(x,y,ED.ground);}
  }else if(ED.tool==='erase'){
    for(const [x,y] of edBrushTiles(tx,ty)){if(!edIn(x,y)||!ED_PROPSET.has(map[y][x]))continue;s.t.push([x,y,T.G]);edSetTile(x,y,T.G);}
    for(const e of enemies){if(e.def.boss||e.night||e.edDel||e.spw||e.rush||e.tmp)continue;if(Math.floor(e.hx/TS)===tx&&Math.floor(e.hy/TS)===ty&&!s.dels.has(e)){s.dels.add(e);s.ops.push({k:'edel',i:enemies.indexOf(e),type:e.type,fx:tx,fy:ty});e.edDel=true;}}
    NPCS.forEach((n,i)=>{if(Math.floor(n.x/TS)!==tx||Math.floor((n.y-4)/TS)!==ty)return;if(n.edAdded&&!s.ops.some(o=>o.k==='ndel'&&o.i===i))s.ops.push({k:'ndel',i,n:n.name});else if(!n.edAdded)edMsg('Story NPCs cannot be removed - drag them instead');});
  }
}
const isVillagePondTile=(x,y)=>x>=VILLAGE_POND.x0&&x<=VILLAGE_POND.x1&&y>=VILLAGE_POND.y0&&y<=VILLAGE_POND.y1;
function edStrokeLine(a,b){const n=Math.max(1,Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/(TS*.4)));for(let i=1;i<=n;i++){const x=a.x+(b.x-a.x)*i/n,y=a.y+(b.y-a.y)*i/n;edStrokeAt(Math.floor(x/TS),Math.floor(y/TS));}}
function edEndStroke(){
  const s=ED.stroke;ED.stroke=null;if(!s)return;
  if(s.pending){const it=ED_ITEM_BY[ED.item],tx=Math.floor(s.last.x/TS),ty=Math.floor(s.last.y/TS),why=edWhy(it,tx,ty);if(why){edMsg(why);return;}edPush(edPlaceOp(it,tx,ty));sfx('select');return;}
  for(const e of s.dels)e.edDel=false;   // (the flag was only a preview marker: applying the op sets it for real)
  const ops=[];if(s.t.length)ops.push({k:'tiles',t:s.t});for(const o of s.ops)ops.push(o);
  if(!ops.length)return;
  for(const o of ops)if(o.k!=='tiles')edApply(o);   // (tiles were already painted live)
  ED.ops.push(ops.length===1?ops[0]:{k:'group',ops});   // the whole stroke is ONE undo step
  ED.redo.length=0;edSave();
}
function edDown(id,p){
  const r=ED.rects.find(q=>inRect(p,q));
  ED.ptrs.set(id,{x:p.x,y:p.y,sx:p.x,sy:p.y,t0:performance.now(),moved:false,ui:r||null,sc0:ED.trayX});
  if(id==='mouse')ED.hover=p;
  if(r){if(r.hold){ED.hold=r.hold;ED.holdT=0;}return;}
  if(ED.ptrs.size>=2){   // two fingers: pan + pinch zoom (cancel whatever one finger was doing)
    if(ED.stroke){if(ED.stroke.pending)ED.stroke=null;else edEndStroke();}ED.drag=null;ED.pan=null;
    const [a,b]=[...ED.ptrs.values()];ED.pinch={d0:Math.hypot(a.x-b.x,a.y-b.y)||1,mx:(a.x+b.x)/2,my:(a.y+b.y)/2};return;}
  const w=edW(p);
  if(ED.tool==='copy'){ED.sel=null;edCopyDown(w);return;}
  if(ED.tool==='cam'){ED.sel=null;ED.pan={cx:cam.x,cy:cam.y,sx:p.x,sy:p.y};return;}   // CAMERA tool: one finger always pans
  if(ED.tool==='move'){
    const h=edHit(w.x,w.y);
    if(h){ED.sel=h;ED.drag={h,w0:w,dtx:0,dty:0,moved:false};}
    else{ED.sel=null;ED.pan={cx:cam.x,cy:cam.y,sx:p.x,sy:p.y};}
  }else{
    ED.stroke={t:[],ops:[],seen:new Set(),dels:new Set(),last:w,pending:ED.tool==='props'};edStrokeAt(Math.floor(w.x/TS),Math.floor(w.y/TS));
  }
}
function edMove(id,p){
  const q=ED.ptrs.get(id);if(!q){if(id==='mouse')ED.hover=p;return;}q.x=p.x;q.y=p.y;if(id==='mouse')ED.hover=p;if(Math.hypot(p.x-q.sx,p.y-q.sy)>6*edK())q.moved=true;
  if(q.ui){if(q.ui.tray&&q.moved)ED.trayX=clamp(q.sc0-(p.x-q.sx),0,ED.trayMax);return;}
  if(ED.pinch&&ED.ptrs.size>=2){
    const [a,b]=[...ED.ptrs.values()],d=Math.hypot(a.x-b.x,a.y-b.y)||1,mx=(a.x+b.x)/2,my=(a.y+b.y)/2;
    cam.x-=mx-ED.pinch.mx;cam.y-=my-ED.pinch.my;ED.pinch.mx=mx;ED.pinch.my=my;edClampCam();
    if(d/ED.pinch.d0>1.4){edZoom(1);ED.pinch.d0=d;}else if(d/ED.pinch.d0<.72){edZoom(-1);ED.pinch.d0=d;}
    return;}
  if(ED.pan){cam.x=ED.pan.cx-(p.x-ED.pan.sx);cam.y=ED.pan.cy-(p.y-ED.pan.sy);edClampCam();return;}
  const w=edW(p);
  if(ED.tool==='copy'){edCopyMove(w);return;}
  if(ED.drag){const d=ED.drag;d.dtx=Math.floor(w.x/TS)-Math.floor(d.w0.x/TS);d.dty=Math.floor(w.y/TS)-Math.floor(d.w0.y/TS);if(d.dtx||d.dty||q.moved)d.moved=true;return;}
  if(ED.stroke){if(ED.stroke.pending)ED.stroke.last=w;else{edStrokeLine(ED.stroke.last,w);ED.stroke.last=w;}}
}
function edDragOk(d){   // is the dragged thing allowed to land on its target?
  const h=d.h;
  if(h.kind==='npc')return !solidTile(Math.floor((h.n.x+d.dtx*TS)/TS),Math.floor((h.n.y+d.dty*TS)/TS))&&edIn(Math.floor((h.n.x+d.dtx*TS)/TS),Math.floor((h.n.y+d.dty*TS)/TS));
  if(h.kind==='enemy'){const tx=Math.floor(h.e.hx/TS)+d.dtx,ty=Math.floor(h.e.hy/TS)+d.dty;return edIn(tx,ty)&&!solidTile(tx,ty)&&!inTownPx(tx*TS+16,ty*TS+16);}
  if(h.kind==='prop'){const tx=h.tx+d.dtx,ty=h.ty+d.dty;return edIn(tx,ty)&&ED_OKSET.has(map[ty][tx])&&map[ty][tx]!==T.W&&!isVillagePondTile(tx,ty);}
  if(h.kind==='house'){const H=h.h;if(!edIn(H.x+d.dtx,H.y+d.dty)||!edIn(H.x+d.dtx+H.w-1,H.y+d.dty+2))return false;
    for(let r=0;r<3;r++)for(let c=0;c<H.w;c++){const x=H.x+d.dtx+c,y=H.y+d.dty+r,own=x>=H.x&&x<H.x+H.w&&y>=H.y&&y<=H.y+2;if(!own&&(!ED_OKSET.has(map[y][x])||map[y][x]===T.W||isVillagePondTile(x,y)))return false;}return true;}
  return false;
}
function edCommitDrag(){
  const d=ED.drag;ED.drag=null;if(!d||!d.moved||(!d.dtx&&!d.dty))return;
  if(!edDragOk(d)){edMsg('Cannot move it there');return;}
  const h=d.h;
  if(h.kind==='npc'){const n=h.n;edPush({k:'npc',i:h.i,n:n.name,x:n.x+d.dtx*TS,y:n.y+d.dty*TS});}
  else if(h.kind==='enemy'){const e=h.e,fx=Math.floor(e.hx/TS),fy=Math.floor(e.hy/TS);edPush({k:'emove',i:h.i,type:e.type,fx,fy,tx:fx+d.dtx,ty:fy+d.dty});}
  else if(h.kind==='prop'){edPush({k:'tiles',t:[[h.tx,h.ty,T.G],[h.tx+d.dtx,h.ty+d.dty,h.id]]});ED.sel={kind:'prop',tx:h.tx+d.dtx,ty:h.ty+d.dty,id:h.id};}
  else if(h.kind==='house'){const H=h.h;edPush({k:'house',x:H.x,y:H.y,w:H.w,nx:H.x+d.dtx,ny:H.y+d.dty});ED.sel={kind:'house',h:edHouseAt(H.x+d.dtx,H.y+d.dty)};}
  sfx('select');
}
function edUp(id){
  const q=ED.ptrs.get(id);ED.ptrs.delete(id);if(!q)return;
  if(q.ui){const u=q.ui;if(u.tray){if(!q.moved){const c=ED.cells.find(c=>inRect({x:q.x,y:q.y},c));if(c){sfx('select');edSelect(c.key);}}return;}
    if(u.hold){if(ED.hold===u.hold){if(ED.holdT<.18){cam.x+=u.hold[0]*TS*2;cam.y+=u.hold[1]*TS*2;edClampCam();}ED.hold=null;}return;}
    if(!q.moved&&inRect({x:q.x,y:q.y},q.ui)){sfx('select');q.ui.act();}return;}
  if(ED.pinch){if(ED.ptrs.size<2)ED.pinch=null;return;}
  if(ED.pan){ED.pan=null;return;}
  if(ED.drag){edCommitDrag();return;}
  if(ED.tool==='copy'){edCopyUp();return;}
  if(ED.stroke)edEndStroke();
}
/* ---- palette selection ---- */
function edSelect(key){
  const it=ED_ITEM_BY[key];if(!it)return;ED.item=key;ED.cat=it.cat;ED.sel=null;
  if(it.kind==='t'){ED.ground=it.id;ED.tool='paint';}
  else{ED.prop=it.kind==='p'?it.id:it.kind==='b'?'b:'+it.w:it.kind==='e'?'e:'+it.type:'n:'+it.npc;ED.tool='props';}
  edMsg(it.name);
}
function edTool(t){
  ED.sel=null;ED.tool=t==='build'?(ED_ITEM_BY[ED.item]&&ED_ITEM_BY[ED.item].kind==='t'?'paint':'props'):t;
  edMsg({move:'Drag things to move them',cam:'Drag to move the camera',build:'Pick from the tray, drag to aim, lift to place',erase:'Tap props, spawns or signs to remove',copy:'Drag a box (or tap one thing) to copy, then tap to stamp copies',expand:'Add grass to a side of the world'}[t]);
}
/* ---- world expansion action ---- */
function edExpand(d){
  const n=ED.expN,tot=(d==='n'||d==='s'?EXP.N+EXP.S:EXP.W+EXP.E)+n;
  if(tot>ED_MAXSIDE){edMsg('The world can grow by at most '+ED_MAXSIDE+' tiles per direction');return;}
  edPush({k:'expand',d,n});edMsg('Added '+n+' '+(d==='n'||d==='s'?'rows':'columns')+' of grass '+({n:'north',s:'south',e:'east',w:'west'})[d]);sfx('select');
}
/* ---- selection actions ---- */
function edNpcName(){const s=ED.sel;if(!s||s.kind!=='npc')return;const n=s.n,cur=n.label||n.name;let v=null;try{v=prompt('NPC name',cur);}catch(e){}
  if(v===null||!v.trim())return;edPush({k:'npcEdit',i:s.i,n:n.name,label:v.trim().slice(0,28)});edMsg('Renamed');}
function edNpcLines(){const s=ED.sel;if(!s||s.kind!=='npc')return;const n=s.n;
  if(!n.lines||!n.lines.length){edMsg('This NPC runs a special menu (shop / quest / inn) - only the name can change');return;}
  let v=null;try{v=prompt('Dialogue (separate lines with  |  )',n.lines.join(' | '));}catch(e){}
  if(v===null)return;const ls=v.split('|').map(a=>a.trim()).filter(Boolean);if(!ls.length)return;edPush({k:'npcEdit',i:s.i,n:n.name,lines:ls});edMsg('Dialogue saved');}
function edDelSel(){
  const s=ED.sel;if(!s)return;
  if(s.kind==='prop'){edPush({k:'tiles',t:[[s.tx,s.ty,T.G]]});ED.sel=null;edMsg('Deleted');}
  else if(s.kind==='npc'&&s.n.edAdded){edPush({k:'ndel',i:s.i,n:s.n.name});ED.sel=null;edMsg('Removed');}
  else if(s.kind==='enemy'){const e=s.e;edPush({k:'edel',i:s.i,type:e.type,fx:Math.floor(e.hx/TS),fy:Math.floor(e.hy/TS)});ED.sel=null;edMsg('Spawn deleted');}
}
/* ---- frame ---- */
function updateEditor(dt){
  if(hit('Escape')||hit('KeyP')){edExit();return;}
  if(hit('KeyZ'))edUndo();if(hit('KeyY'))edRedo();
  if(ED.hold&&!ED.ptrs.size)ED.hold=null;
  if(ED.hold){ED.holdT+=dt;if(ED.holdT>.18){const v=(ED.holdT>.9?620:420)*dt;cam.x+=ED.hold[0]*v;cam.y+=ED.hold[1]*v;}}
  const sp=420*dt;if(held('ArrowLeft','KeyA'))cam.x-=sp;if(held('ArrowRight','KeyD'))cam.x+=sp;if(held('ArrowUp','KeyW'))cam.y-=sp;if(held('ArrowDown','KeyS'))cam.y+=sp;edClampCam();
}
cv.addEventListener('wheel',e=>{if(state!=='editor')return;e.preventDefault();const tr=ED.rects.find(r=>r.tray);if(tr&&ED.hover&&inRect(ED.hover,tr)){ED.trayX=clamp(ED.trayX+(e.deltaX||e.deltaY)*.6,0,ED.trayMax);return;}edZoom(e.deltaY<0?1:-1);},{passive:false});
const edK=()=>Math.max(.7,ED.s0/(EDS||S));       // UI scale: buttons keep their size on screen however far the map is zoomed
function edBtn(x,y,w,h,lab,act,on,col,hold,ex){const r={x,y,w,h,lab,act,on,col,hold:hold||null};if(ex)Object.assign(r,ex);ED.rects.push(r);return r;}
function edLayout(){
  ED.rects=[];ED.cells=[];const k=edK(),u=v=>Math.round(v*k),m=u(4),bh=u(32),tb=ST+m,L=SL+m,R=VW-SR-m;let x=L;ED.k=k;
  // top bar: left group (EXIT UNDO REDO - +) and right group (KEY SAVE EXPORT RESET); on a narrow screen both shrink so they never overlap
  const TL=[['EXIT',edExit,'#7a2a2a',44],['UNDO',edUndo,null,48],['REDO',edRedo,null,48],['  -  ',()=>edZoom(-1),null,32],['  +  ',()=>edZoom(1),null,32]];
  const TR=[['SAVE',()=>edPublish(),'#b8862a',48],['KEY',()=>edSaveBox(),'#34406a',38],['EXPORT',()=>edExportBox(),'#2d6a4f',62],['RESET',edReset,'#7a2a2a',54]];
  {const gap=u(3),tot=[...TL,...TR].reduce((a,b)=>a+u(b[3])+gap,0)+u(6),f=Math.min(1,(R-L)/tot);
   for(const [l,fn,c,w0] of TL){const w=Math.floor(u(w0)*f);edBtn(x,tb,w,bh,l,fn,false,c);x+=w+Math.floor(gap*f);}
   let rx=R;for(const [l,fn,c,w0] of TR){const w=Math.floor(u(w0)*f);rx-=w;edBtn(rx,tb,w,bh,l,fn,false,c);rx-=Math.floor(gap*f);}}
  const build=ED.tool==='paint'||ED.tool==='props',small=VH/k<350,a=small?2:Math.max(2,Math.round(2.5*k)),cw=16*a+u(8),chh=16*a+u(10),yRow=VH-SB-m-bh;
  // left tool rail (squeezes to fit above the tray on short screens)
  const rw=u(52);let ry=tb+bh+u(10);
  const trayTopEst=build?VH-SB-m-(chh+u(6))-u(4)-u(26)-u(22)-u(6):ED.tool==='expand'?yRow-bh*2-u(12):VH-SB-m-bh-u(6),rh=Math.min(u(36),Math.floor((trayTopEst-ry-u(3)*5)/6));
  for(const [l,t] of [['MOVE','move'],['CAM','cam'],['BUILD','build'],['ERASE','erase'],['COPY','copy'],['EXPAND','expand']]){
    const on=t==='build'?(ED.tool==='paint'||ED.tool==='props'):ED.tool===t;edBtn(L,ry,rw,rh,l,()=>edTool(t),on,t==='expand'?'#6a4a1a':'#4a3016',null,{icon:t});ry+=rh+u(3);}
  ED.a=a;ED.headTxt=null;ED.trayRect=null;ED.sizeTxt=null;
  if(build){
    const trayH=chh+u(6),yCells=VH-SB-m-trayH,yTabs=yCells-u(4)-u(26),yHead=yTabs-u(22);ED.barTop=yHead-u(4);
    const tw0=ED_CATS.map(c=>u(20)+Math.round(c.length*u(6))+u(8)),tf=Math.min(1,(R-L-u(3)*ED_CATS.length)/tw0.reduce((a,b)=>a+b,0));
    let tx=L;for(const c of ED_CATS){const w=Math.floor(tw0[ED_CATS.indexOf(c)]*tf);edBtn(tx,yTabs,w,u(26),c,()=>{ED.cat=c;ED.trayX=0;},ED.cat===c,'#4a3016',null,{chip:edCatItems(c)[0]});tx+=w+u(3);}
    const it=ED_ITEM_BY[ED.item];ED.headTxt={x:L,y:yHead+u(13),t:it?it.name:''};
    if(ED.tool==='paint'){let bx=R;for(const n of [3,2,1]){bx-=u(34);edBtn(bx,yHead,u(32),u(20),'x'+n,()=>{ED.brush=n;},ED.brush===n,'#2a4a6a');bx-=u(2);}}
    const items=edCatItems(ED.cat),gap=u(4),tot=items.length*(cw+gap)-gap;
    ED.trayMax=Math.max(0,tot-(R-L));ED.trayX=clamp(ED.trayX,0,ED.trayMax);
    ED.trayRect=edBtn(L,yCells,R-L,trayH,'',null,false,null,null,{tray:true});
    items.forEach((i,n)=>{const cx=L+n*(cw+gap)-ED.trayX;if(cx+cw<L||cx>R)return;ED.cells.push({x:cx,y:yCells+u(3),w:cw,h:chh,key:i.key,it:i});});
  }else if(ED.tool==='expand'){
    let xx=L;for(const [l,d] of [['NORTH','n'],['SOUTH','s'],['EAST','e'],['WEST','w']]){const lab=l+' +'+ED.expN,w=Math.round(lab.length*u(7.4)+u(14));edBtn(xx,yRow,w,bh,lab,()=>edExpand(d),false,'#2d6a4f');xx+=w+u(4);}
    const y2=yRow-bh-u(4);xx=L;for(const n of [4,8,16]){edBtn(xx,y2,u(38),bh,'+'+n,()=>{ED.expN=n;},ED.expN===n,'#2a4a6a');xx+=u(42);}
    ED.sizeTxt='World '+MW+' x '+OW_H+' tiles   (N'+EXP.N+' S'+EXP.S+' E'+EXP.E+' W'+EXP.W+')';ED.sizeX=xx+u(6);ED.sizeY=y2+bh/2+3;ED.barTop=y2-u(6);
  }else if(ED.tool==='erase'){
    let xx=L;for(const n of [1,2,3]){edBtn(xx,yRow,u(34),bh,'x'+n,()=>{ED.brush=n;},ED.brush===n,'#2a4a6a');xx+=u(38);}ED.barTop=yRow-u(6);
  }else if(ED.sel&&(ED.tool==='move')){
    const sl=ED.sel;let xx=L;
    if(sl.kind==='npc'){edBtn(xx,yRow,u(70),bh,'NAME',edNpcName,false,'#2d6a4f');xx+=u(74);edBtn(xx,yRow,u(96),bh,'DIALOGUE',edNpcLines,false,'#2d6a4f');xx+=u(100);if(sl.n.edAdded)edBtn(xx,yRow,u(78),bh,'DELETE',edDelSel,false,'#7a2a2a');}
    else if(sl.kind==='enemy'||sl.kind==='prop')edBtn(xx,yRow,u(78),bh,'DELETE',edDelSel,false,'#7a2a2a');
    ED.barTop=yRow-u(6);
  }else ED.barTop=VH;
  // on-screen camera arrows (hold to glide, tap to nudge)
  {const ar=u(26),cx0=R-ar*3-u(4),cy0=tb+bh+u(8);
   for(const [l,dx,dy,gx,gy] of [['^',0,-1,1,0],['<',-1,0,0,1],['v',0,1,1,1],['>',1,0,2,1]])edBtn(cx0+gx*(ar+2),cy0+gy*(ar+2),ar,ar,l,null,ED.hold&&ED.hold[0]===dx&&ED.hold[1]===dy,'#34406a',[dx,dy]);}
}
/* tiny hand-drawn tool glyphs for the left rail */
function edGlyph(t,cx,cy,k){
  const s=Math.max(1,Math.round(k*5));ctx.save();ctx.lineWidth=Math.max(2,Math.round(k*2));ctx.strokeStyle='#fff3d0';ctx.fillStyle='#fff3d0';ctx.lineCap='round';
  if(t==='move'){ctx.beginPath();ctx.moveTo(cx-s*1.5,cy);ctx.lineTo(cx+s*1.5,cy);ctx.moveTo(cx,cy-s*1.5);ctx.lineTo(cx,cy+s*1.5);ctx.stroke();for(const [dx,dy] of [[0,-1],[0,1],[-1,0],[1,0]]){ctx.beginPath();ctx.moveTo(cx+dx*s*1.9,cy+dy*s*1.9);ctx.lineTo(cx+dx*s*1.1+dy*s*.7,cy+dy*s*1.1+dx*s*.7);ctx.lineTo(cx+dx*s*1.1-dy*s*.7,cy+dy*s*1.1-dx*s*.7);ctx.fill();}}
  else if(t==='cam'){ctx.beginPath();ctx.ellipse(cx,cy,s*1.9,s*1.1,0,0,6.283);ctx.stroke();ctx.beginPath();ctx.arc(cx,cy,s*.6,0,6.283);ctx.fill();}
  else if(t==='copy'){ctx.strokeRect(cx-s*1.4,cy-s*1.4,s*1.8,s*1.8);ctx.strokeRect(cx-s*.4,cy-s*.4,s*1.8,s*1.8);}
  else if(t==='erase'){ctx.strokeStyle='#ff9a8a';ctx.beginPath();ctx.moveTo(cx-s,cy-s);ctx.lineTo(cx+s,cy+s);ctx.moveTo(cx+s,cy-s);ctx.lineTo(cx-s,cy+s);ctx.stroke();}
  else if(t==='expand'){ctx.strokeRect(cx-s*.9,cy-s*.9,s*1.8,s*1.8);ctx.beginPath();ctx.moveTo(cx+s*.3,cy-s*.3);ctx.lineTo(cx+s*1.9,cy-s*1.9);ctx.moveTo(cx+s*1.9,cy-s*1.1);ctx.lineTo(cx+s*1.9,cy-s*1.9);ctx.lineTo(cx+s*1.1,cy-s*1.9);ctx.stroke();}
  else if(t==='build'){const it=ED_ITEM_BY[ED.item];if(it)edDrawArt(it,Math.round(cx-8*Math.max(1,Math.round(k))),Math.round(cy-8*Math.max(1,Math.round(k))),Math.max(1,Math.round(k)));}
  ctx.restore();
}
function edButton(r){
  if(r.tray)return;
  const k=ED.k||1;
  ctx.fillStyle='#1c0e06';ctx.fillRect(r.x-1,r.y-1,r.w+2,r.h+2);
  ctx.fillStyle=r.on?'#e0b44a':(r.col||'#4a3016');ctx.fillRect(r.x,r.y,r.w,r.h);
  ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(r.x,r.y,r.w,2);ctx.fillStyle='rgba(0,0,0,.18)';ctx.fillRect(r.x,r.y+r.h-2,r.w,2);
  const lab=r.lab.trim(),fs=Math.max(7,Math.round((lab.length>6?9:10)*k));
  if(r.icon){edGlyph(r.icon,r.x+r.w/2,r.y+r.h*.38,k);txt(lab,r.x+r.w/2,r.y+r.h-Math.round(5*k),{size:Math.max(6,Math.round(7*k)),align:'center',col:r.on?'#2a160a':'#fff3d0',lw:r.on?0:3,out:r.on?false:'#1c0e06'});return;}
  if(r.chip){const ia=k>=1.5?2:1;edDrawArt(r.chip,r.x+Math.round(3*k),Math.round(r.y+(r.h-16*ia)/2),ia);txt(lab,r.x+Math.round(6*k)+16*ia+(r.w-Math.round(6*k)-16*ia)/2-Math.round(3*k),r.y+r.h/2+Math.round(3.5*k),{size:fs,align:'center',col:r.on?'#2a160a':'#fff3d0',lw:r.on?0:3,out:r.on?false:'#1c0e06'});return;}
  txt(lab,r.x+r.w/2,r.y+r.h/2+Math.round(4*k),{size:fs,align:'center',col:r.on?'#2a160a':'#fff3d0',lw:r.on?0:3,out:r.on?false:'#1c0e06'});
}
/* the picture tray: thumbnails of real in-game art, selected one glows gold */
function edDrawTray(){
  const tr=ED.trayRect;if(!tr)return;const k=ED.k||1,a=ED.a||2;
  ctx.fillStyle='#1c0e06';ctx.fillRect(tr.x-2,tr.y-2,tr.w+4,tr.h+4);ctx.fillStyle='#3a2412';ctx.fillRect(tr.x,tr.y,tr.w,tr.h);
  ctx.save();ctx.beginPath();ctx.rect(tr.x,tr.y,tr.w,tr.h);ctx.clip();
  for(const c of ED.cells){const sel=c.key===ED.item;
    ctx.fillStyle=sel?'#7a5a22':'#56381c';ctx.fillRect(c.x,c.y,c.w,c.h);ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(c.x+2,c.y+2,c.w-4,c.h-4);
    edDrawArt(c.it,Math.round(c.x+(c.w-16*a)/2),Math.round(c.y+(c.h-16*a)/2),a);
    if(sel){ctx.fillStyle='rgba(255,225,77,.18)';ctx.fillRect(c.x,c.y,c.w,c.h);ctx.strokeStyle='#ffe14d';ctx.lineWidth=Math.max(2,Math.round(2*k));ctx.strokeRect(c.x+1,c.y+1,c.w-2,c.h-2);}
    else{ctx.strokeStyle='#8a6232';ctx.lineWidth=1;ctx.strokeRect(c.x+.5,c.y+.5,c.w-1,c.h-1);}}
  ctx.restore();
  if(ED.trayX>2)txt('<',tr.x+6,tr.y+tr.h/2+4,{size:Math.round(14*k),align:'center',col:'#ffe14d',lw:3,out:'#1c0e06'});
  if(ED.trayX<ED.trayMax-2)txt('>',tr.x+tr.w-6,tr.y+tr.h/2+4,{size:Math.round(14*k),align:'center',col:'#ffe14d',lw:3,out:'#1c0e06'});
  if(ED.headTxt)txt(ED.headTxt.t,ED.headTxt.x+2,ED.headTxt.y,{size:Math.max(8,Math.round(11*k)),align:'left',col:'#ffe9b0',lw:3,out:'#1c0e06'});
}
/* see-through preview of the chosen item on a tile (red when it cannot go there) */
function edGhost(it,tx,ty,cx,cy){
  const why=edWhy(it,tx,ty),sx=tx*TS-cx,sy=ty*TS-cy,A=edArt(it);ctx.save();ctx.imageSmoothingEnabled=false;ctx.globalAlpha=.75;
  let bx=sx,by=sy,bw=TS,bh=TS;
  if(it.kind==='t'||it.kind==='p'){ctx.drawImage(A.tile,sx,sy,TS,TS);if(A.fg){const w=TS*BIGTREE;ctx.drawImage(A.fg,sx+TS/2-w/2,sy+TS-w+2,w,w);}}
  else if(it.kind==='b'){bx=(tx-(it.w>>1))*TS-cx;by=(ty-2)*TS-cy;bw=it.w*TS;bh=3*TS;ctx.drawImage(A.spr,bx,by,bw,bh);}
  else if(it.kind==='e')ctx.drawImage(A.spr,sx+TS/2-A.spr.width,sy+TS-6-A.spr.height*2,A.spr.width*2,A.spr.height*2);
  else ctx.drawImage(A.spr,sx+TS/2-16,sy+Math.round(TS*.9)-31,32,32);
  ctx.globalAlpha=1;ctx.fillStyle=why?'rgba(255,60,40,.32)':'rgba(255,225,77,.16)';ctx.fillRect(bx,by,bw,bh);ctx.strokeStyle=why?'#ff5040':'#ffe14d';ctx.lineWidth=2;ctx.strokeRect(bx+1,by+1,bw-2,bh-2);
  txt(why||it.name,sx+TS/2,by-6,{size:9,align:'center',col:why?'#ffb0a0':'#fff3d0',lw:3,out:'#1c0e06'});
  ctx.restore();return !why;
}
const edTileCol=id=>TSPR.mini[id]||'#888';
function drawEditor(){
  const cx=Math.round(cam.x),cy=Math.round(cam.y);
  // grid
  ctx.save();ctx.strokeStyle='rgba(255,255,255,.16)';ctx.lineWidth=1;ctx.beginPath();
  const ox0=0,oy0=OWY0*TS,ox1=MW*TS,oy1=(OWY0+OW_H)*TS;
  // beyond the map: a dark void (never the crypt / interior rows that sit above or below the overworld block)
  ctx.fillStyle='#08060f';ctx.fillRect(0,0,VW,Math.max(0,Math.min(VH,oy0-cy)));ctx.fillRect(0,Math.max(0,oy1-cy),VW,VH);ctx.fillRect(0,0,Math.max(0,Math.min(VW,ox0-cx)),VH);ctx.fillRect(Math.max(0,ox1-cx),0,VW,VH);
  ctx.strokeStyle='#e0b44a';ctx.lineWidth=2;ctx.strokeRect(ox0-cx,oy0-cy,ox1-ox0,oy1-oy0);ctx.strokeStyle='rgba(255,255,255,.16)';ctx.lineWidth=1;ctx.beginPath();
  const gx0=Math.max(0,Math.floor(cx/TS)),gx1=Math.min(MW,Math.ceil((cx+VW)/TS)),gy0=Math.max(OWY0,Math.floor(cy/TS)),gy1=Math.min(OWY0+OW_H,Math.ceil((cy+VH)/TS));
  for(let x=gx0;x<=gx1;x++){ctx.moveTo(x*TS-cx+.5,gy0*TS-cy);ctx.lineTo(x*TS-cx+.5,gy1*TS-cy);}
  for(let y=gy0;y<=gy1;y++){ctx.moveTo(gx0*TS-cx,y*TS-cy+.5);ctx.lineTo(gx1*TS-cx,y*TS-cy+.5);}
  ctx.stroke();ctx.restore();
  // NPC rings + names, enemy spawn markers
  for(let i=0;i<NPCS.length;i++){const n=NPCS[i];if(!edOW(n.y))continue;const sx=n.x-cx,sy=n.y-cy;if(sx<-40||sy<-60||sx>VW+40||sy>VH+40)continue;
    const sel=ED.sel&&ED.sel.kind==='npc'&&ED.sel.i===i;
    ctx.strokeStyle=sel?'#ffe14d':(n.tguard?'#7ab8ff':'#9be8a0');ctx.lineWidth=sel?3:2;ctx.beginPath();ctx.ellipse(sx,sy+2,13,6,0,0,6.283);ctx.stroke();
    txt(n.tguard?'GUARD':(n.label||n.name).toUpperCase(),sx,sy+16,{size:7,align:'center',col:sel?'#ffe14d':'#e8f6e8',lw:3,out:'#10240f'});}
  for(let i=0;i<enemies.length;i++){const e=enemies[i];if(e.def.boss||e.night||e.edDel||e.spw||e.rush||e.tmp||!edOW(e.hy))continue;const sx=e.hx-cx,sy=e.hy-cy;if(sx<-20||sy<-20||sx>VW+20||sy>VH+20)continue;
    const sel=ED.sel&&ED.sel.kind==='enemy'&&ED.sel.e===e;
    const sp=SP[e.def.spr];ctx.fillStyle='rgba(20,0,0,.4)';ctx.beginPath();ctx.ellipse(sx,sy-2,12,5,0,0,6.283);ctx.fill();
    if(sp)draw(sp,sx-sp.width,sy-4-sp.height*2,2);
    ctx.strokeStyle=sel?'#ffe14d':'#ff6b5a';ctx.lineWidth=sel?3:2;ctx.beginPath();ctx.ellipse(sx,sy-2,12,5,0,0,6.283);ctx.stroke();}
  // drag ghost
  const d=ED.drag;
  if(d&&d.moved){
    const ok=edDragOk(d),h=d.h;ctx.save();ctx.globalAlpha=.7;
    const box=(x,y,w,hh)=>{ctx.fillStyle=ok?'rgba(255,225,77,.28)':'rgba(255,80,60,.35)';ctx.fillRect(x-cx,y-cy,w,hh);ctx.strokeStyle=ok?'#ffe14d':'#ff5040';ctx.lineWidth=2;ctx.strokeRect(x-cx+1,y-cy+1,w-2,hh-2);};
    if(h.kind==='house'){const H=h.h;box((H.x+d.dtx)*TS,(H.y+d.dty)*TS,H.w*TS,3*TS);for(let r=0;r<3;r++)for(let c=0;c<H.w;c++)ctx.drawImage(tileSprite(map[H.y+r][H.x+c],H.x+c,H.y+r,gtime),(H.x+d.dtx+c)*TS-cx,(H.y+d.dty+r)*TS-cy,TS,TS);}
    else if(h.kind==='prop'){const x=(h.tx+d.dtx)*TS,y=(h.ty+d.dty)*TS;ctx.drawImage(tileSprite(h.id,h.tx,h.ty,gtime),x-cx,y-cy,TS,TS);box(x,y,TS,TS);}
    else if(h.kind==='npc'){const n=h.n;draw(SP[n.spr],n.x+d.dtx*TS-cx-16,n.y+d.dty*TS-cy-31,2);box(Math.floor((n.x+d.dtx*TS)/TS)*TS,Math.floor((n.y+d.dty*TS)/TS)*TS,TS,TS);}
    else if(h.kind==='enemy'){const e=h.e,x=(Math.floor(e.hx/TS)+d.dtx)*TS,y=(Math.floor(e.hy/TS)+d.dty)*TS;box(x,y,TS,TS);}
    ctx.restore();
  }
  else if(ED.sel){const s=ED.sel;ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;
    if(s.kind==='house'&&s.h)ctx.strokeRect(s.h.x*TS-cx,s.h.y*TS-cy,s.h.w*TS,3*TS);else if(s.kind==='prop')ctx.strokeRect(s.tx*TS-cx,s.ty*TS-cy,TS,TS);}
  // ghost of the chosen item under the finger (or the mouse) before it is placed; erase shows its brush
  {const pt=[...ED.ptrs.values()][0],it=ED_ITEM_BY[ED.item];let w=null;
   if(ED.stroke&&ED.stroke.last&&ED.ptrs.size===1)w=ED.stroke.last;
   else if(pt&&!pt.ui&&ED.ptrs.size===1)w=edW(pt);
   else if(!ED.ptrs.size&&ED.hover&&!ED.rects.some(r=>inRect(ED.hover,r))&&ED.hover.y<ED.barTop)w=edW(ED.hover);
   ED.ghost=null;
   if(w&&(ED.tool==='paint'||ED.tool==='props')&&it){const tx=Math.floor(w.x/TS),ty=Math.floor(w.y/TS);
     if(ED.tool==='paint'){ctx.save();ctx.globalAlpha=.55;for(const [x,y] of edBrushTiles(tx,ty)){if(!edIn(x,y))continue;ctx.drawImage(edArt(it).tile,x*TS-cx,y*TS-cy,TS,TS);}ctx.globalAlpha=1;ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;for(const [x,y] of edBrushTiles(tx,ty))ctx.strokeRect(x*TS-cx+1,y*TS-cy+1,TS-2,TS-2);ctx.restore();ED.ghost={tx,ty,ok:true};}
     else ED.ghost={tx,ty,ok:edGhost(it,tx,ty,cx,cy)};}
   else if(w&&ED.tool==='erase'){ctx.strokeStyle='rgba(255,140,120,.9)';ctx.lineWidth=2;for(const [x,y] of edBrushTiles(Math.floor(w.x/TS),Math.floor(w.y/TS)))ctx.strokeRect(x*TS-cx+1,y*TS-cy+1,TS-2,TS-2);}}
  // bars
  edLayout();
  ctx.fillStyle='rgba(16,8,2,.55)';ctx.fillRect(0,0,VW,ST+Math.round(40*(ED.k||1)));
  if(ED.barTop<VH){ctx.fillStyle='rgba(28,14,6,.8)';ctx.fillRect(0,ED.barTop,VW,VH-ED.barTop);ctx.fillStyle='#8a6232';ctx.fillRect(0,ED.barTop,VW,2);}
  for(const r of ED.rects)edButton(r);
  edDrawTray();
  if(ED.tool==='expand'&&ED.sizeTxt)txt(ED.sizeTxt,ED.sizeX,ED.sizeY,{size:9,align:'left',col:'#e8d4a8',lw:3,out:'#1c0e06'});
  const sel=ED.sel,info=gtime-ED.msgT<4&&ED.msg?ED.msg:(sel?(sel.kind==='npc'?'Selected: '+(sel.n.label||sel.n.name)+' - drag to move':sel.kind==='enemy'?'Selected: '+sel.e.type+' spawn - drag to move':sel.kind==='house'?'Selected: house - drag to move (door follows)':'Selected: prop - drag to move'):'');
  if(ED.pub.msg&&(ED.pub.busy||gtime-ED.pub.t<14))txt(ED.pub.msg,VW/2,ST+Math.round(72*(ED.k||1)),{size:11,align:'center',col:ED.pub.col,lw:4,out:'#1c0e06'});
  if(info)txt(info,VW/2,ST+Math.round(56*(ED.k||1)),{size:10,align:'center',col:'#fff3d0',lw:4,out:'#1c0e06'});
  txt(ED.ops.length+' edit'+(ED.ops.length===1?'':'s'),VW-SR-6,Math.min(ED.barTop,VH-SB-8)-4,{size:8,align:'right',col:'#e8d4a8',lw:3,out:'#1c0e06'});
}
/* a save made with another world size: move the hero by the difference so he stays on the same spot of the (shifted) overworld */
function edFrameFix(pl,fr){
  const sOX=fr?fr[0]:0,sOY=fr?fr[1]:0,sOWH=fr?fr[2]:48,sOWY0=sOY>=224?224:0,ty=Math.floor(pl.y/TS);
  if(sOX===OX&&sOY===OY)return;
  if(ty>=sOWY0&&ty<sOWY0+sOWH){pl.x+=(OX-sOX)*TS;pl.y+=(OY-sOY)*TS;
    if(pl.x<TS*2||pl.x>(MW-2)*TS||pl.y<(OWY0+2)*TS||pl.y>(OWY0+OW_H-2)*TS||solidTile(Math.floor(pl.x/TS),Math.floor((pl.y-4)/TS))){pl.x=SPAWN.x;pl.y=SPAWN.y;}}
}
