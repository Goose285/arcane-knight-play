/* =====================================================================
   WORLD EDITOR - PUBLISH ("SAVE"). The edit layer can be committed straight to the play site's GitHub repo as world-edits.json (GitHub REST
   contents API: GET sha, then PUT). The game fetches that file from the site root at boot and applies it BEFORE this device's own layer,
   so published edits are permanent for everybody. A missing file = nothing to apply. The GitHub token is pasted once (KEY) and lives only
   in this device's localStorage; it is never part of any export or save.
   Double-apply safety: after a publish the local layer is kept until the baked file shows it; whenever the baked file ends with the first k ops of the
   local layer, those k ops are dropped from the local layer (so the same edit is never replayed twice).
   ===================================================================== */
const ED_REPO='Goose285/arcane-knight-play',ED_BRANCH='main',ED_FILE='world-edits.json',ED_TOKEN_KEY='ak_gh_token';
const edGV=()=>growOn()?1:0;                       // 1 = layer authored on the shipped (grown) world; 0 / missing = the old 64x48 overworld
const edGetToken=()=>{try{return (localStorage.getItem(ED_TOKEN_KEY)||'').trim();}catch(e){return '';}};
function edPubSay(msg,col,busy){ED.pub.msg=msg;ED.pub.col=col||'#fff3d0';ED.pub.t=gtime;ED.pub.busy=!!busy;const o=document.getElementById('edSaveBox');if(o){const s=o.querySelector('#edPubStatus');if(s){s.textContent=msg;s.style.color=col||'#fff3d0';}}}
/* ops written before the world grew assumed the overworld started at row 0 (or 224 once expanded): move them onto the shipped layout */
function edMigrate(l){
  const ops=l.ops||[];if(!growOn()||(l.g|0)>=1)return edShiftNb(l,JSON.parse(JSON.stringify(ops)));
  let N=0,S=0;const out=[],n0=typeof GROW_NPC0==='number'?GROW_NPC0:1e9,add=typeof GROW_NPC_ADDED==='number'?GROW_NPC_ADDED:0;
  for(const o of ops){
    const dy=(N>0||S>0)?0:224,c=JSON.parse(JSON.stringify(o));
    if(o.k==='expand'){if(o.d==='n')N+=o.n|0;if(o.d==='s')S+=o.n|0;}
    else{
      if(dy){
        if(c.k==='tiles')for(const t of c.t)t[1]+=dy;
        else if(c.k==='house'){c.y+=dy;c.ny+=dy;}
        else if(c.k==='npc')c.y+=dy*TS;
        else if(c.k==='emove'){c.fy+=dy;c.ty+=dy;}
        else if(c.k==='eadd'||c.k==='nadd')c.ty+=dy;
        else if(c.k==='edel')c.fy+=dy;
      }
      if((c.k==='npc'||c.k==='npcEdit'||c.k==='ndel')&&c.i>=n0)c.i+=add;   // NPCs added after the base list now sit behind the new farm NPCs
    }
    out.push(c);
  }
  return edShiftNb(l,out);
}
function edShiftNb(l,out){
  // NPC indices: the shipped base list grew (t133u east NPCs, t135u signs); ops written against a shorter base move up with it
  const nbNow=ED.base?ED.base.npcs.length:NPCS.length,nb=l.nb!=null?l.nb:nbNow-NEW_NPCS_T135;   // (layers without nb were written on the t133u base)
  const flat=a=>a.flatMap(c=>c.k==='group'?flat(c.ops):[c]);
  if(nb!==nbNow)for(const c of flat(out))if((c.k==='npc'||c.k==='npcEdit'||c.k==='ndel')&&c.i>=nb)c.i+=nbNow-nb;
  return out;
}
function edLoad(){
  edSnap();
  let l=null;try{l=JSON.parse(localStorage.getItem(ED_KEY)||'null');}catch(e){}
  if(l&&Array.isArray(l.ops)){ED.ops=edMigrate(l);for(const o of ED.ops){try{edApply(o);}catch(e){}}if((l.g|0)!==edGV())edSave();}
  edLoadBaked();
}
/* fetch the baked file (network-first via the service worker) and, if it has edits, replay baked + local */
function edLoadBaked(){
  if(typeof fetch!=='function')return Promise.resolve(false);
  let p;try{p=fetch(ED_FILE+'?t='+Date.now(),{cache:'no-store'});}catch(e){return Promise.resolve(false);}
  return p.then(r=>r&&r.ok?r.json():null).then(j=>{if(!j||!Array.isArray(j.ops))return false;edAdoptBaked(edMigrate(j));return true;}).catch(()=>false);
}
function edAdoptBaked(b){
  const same=JSON.stringify(b)===JSON.stringify(ED.bakedOps);let dropped=0;
  const L=ED.ops;
  for(let k=Math.min(L.length,b.length);k>=1;k--)if(JSON.stringify(b.slice(-k))===JSON.stringify(L.slice(0,k))){ED.ops=L.slice(k);ED.redo.length=0;dropped=k;edSave();break;}
  if(same&&!dropped)return;
  ED.bakedOps=b;
  const run=()=>{if(B||ED.stroke||ED.drag){setTimeout(run,1500);return;}edRebuild();};
  if(b.length||dropped)run();
}
/* ---- publish ---- */
const edB64=s=>btoa(unescape(encodeURIComponent(s)));
async function edHttpErr(r){let m='';try{m=(await r.json()).message||'';}catch(e){}const c=r.status;
  return {code:c,msg:c===401?'Token rejected (401) - paste a fresh one with KEY':c===403?'No permission (403) - the token needs Contents: Read and write on arcane-knight-play'+(m?' ['+m+']':''):c===404?'Not found (404) - the token must be allowed to use the arcane-knight-play repo':c===409||c===422?'Conflict ('+c+') - tap SAVE again':'GitHub error '+c+(m?': '+m:'')};}
async function edPublish(){
  if(ED.pub.busy)return;
  const tok=edGetToken();if(!tok){edPubSay('Paste your GitHub token first (KEY)','#ffb0a0');edSaveBox();return;}
  const full=ED.bakedOps.concat(ED.ops);
  edPubSay('Saving\u2026','#ffe14d',true);
  const url='https://api.github.com/repos/'+ED_REPO+'/contents/'+ED_FILE,hd={Authorization:'Bearer '+tok,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'};
  const body=JSON.stringify({v:2,g:edGV(),nb:ED.base?ED.base.npcs.length:NPCS.length,saved:new Date().toISOString(),world:{cols:MW,rows:OW_H,expand:{n:EXP.N,s:EXP.S,e:EXP.E,w:EXP.W}},ops:full});
  try{
    for(let attempt=0;attempt<2;attempt++){
      let sha;const g=await fetch(url+'?ref='+ED_BRANCH+'&t='+Date.now(),{headers:hd,cache:'no-store'});
      if(g.status===200){const j=await g.json();sha=j&&j.sha;}else if(g.status!==404)throw await edHttpErr(g);
      const put=await fetch(url,{method:'PUT',headers:Object.assign({'Content-Type':'application/json'},hd),body:JSON.stringify(Object.assign({message:'World edits from the in-game editor ('+full.length+' changes)',content:edB64(body),branch:ED_BRANCH},sha?{sha}:{}))});
      if(put.ok){edPubSay('Saved! Live in ~1 min','#7df97d');ED.pub.n=full.length;edPollBaked();return;}
      if(attempt===0&&(put.status===409||put.status===422))continue;
      throw await edHttpErr(put);
    }
  }catch(e){
    const msg=e&&e.msg?e.msg:(e instanceof TypeError?'Cannot reach GitHub - check your connection':'Save failed: '+(e&&e.message||e));
    edPubSay('Save failed: '+msg,'#ff9a8a');if(e&&(e.code===401||e.code===403))setTimeout(edSaveBox,600);
  }
}
/* after a publish, look for the baked file to catch up (GitHub Pages takes about a minute) so the local layer retires itself */
let edPollT=null;
function edPollBaked(){if(edPollT)clearInterval(edPollT);let n=0;edPollT=setInterval(()=>{if(++n>12||!ED.ops.length){clearInterval(edPollT);edPollT=null;return;}edLoadBaked();},20000);}
/* ---- settings box: paste the token once ---- */
function edSaveBox(){
  let o=document.getElementById('edSaveBox');
  if(!o){
    o=document.createElement('div');o.id='edSaveBox';o.style.cssText='position:fixed;left:0;top:0;right:0;bottom:0;background:rgba(10,6,2,.94);z-index:99999;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;font:bold 14px monospace;color:#fff3d0;padding:12px;text-align:center;overflow:auto';
    const t=document.createElement('div');t.textContent='SAVE SETTINGS - publish your edits to the live game';t.style.fontSize='16px';
    const d=document.createElement('div');d.style.cssText='max-width:560px;font:12px monospace;color:#e8d4a8;line-height:1.5';
    d.innerHTML='Paste a GitHub <b>fine-grained token</b> (only the arcane-knight-play repo, Contents: Read and write). It is kept only on this device and used only to save <b>world-edits.json</b> to Goose285/arcane-knight-play (main).';
    const inp=document.createElement('input');inp.id='edTok';inp.type='password';inp.placeholder='github_pat_...';inp.autocomplete='off';inp.spellcheck=false;inp.style.cssText='width:min(86%,520px);font:14px monospace;padding:10px;background:#1c1208;color:#ffe9a0;border:2px solid #c89858;border-radius:6px';
    const st=document.createElement('div');st.id='edPubStatus';st.style.cssText='min-height:18px;font:13px monospace';
    const row=document.createElement('div');row.style.cssText='display:flex;gap:10px;flex-wrap:wrap;justify-content:center';
    const mk=(lab,fn,bg)=>{const b=document.createElement('button');b.textContent=lab;b.style.cssText='font:bold 15px monospace;padding:11px 18px;background:'+(bg||'#7a5530')+';color:#fff3d0;border:2px solid #e0b44a;border-radius:6px';b.onclick=fn;return b;};
    row.appendChild(mk('SAVE KEY',()=>{const v=inp.value.trim();if(!v){edPubSay('Paste the token first','#ffb0a0');return;}try{localStorage.setItem(ED_TOKEN_KEY,v);}catch(e){}inp.value='';inp.placeholder='(key saved on this device)';edPubSay('Key saved. Now tap PUBLISH NOW or SAVE.','#7df97d');},'#2d6a4f'));
    row.appendChild(mk('SHOW',()=>{inp.type=inp.type==='password'?'text':'password';}));
    row.appendChild(mk('PUBLISH NOW',()=>{const v=inp.value.trim();if(v){try{localStorage.setItem(ED_TOKEN_KEY,v);}catch(e){}inp.value='';}edPublish();},'#b8862a'));
    row.appendChild(mk('FORGET KEY',()=>{try{localStorage.removeItem(ED_TOKEN_KEY);}catch(e){}inp.placeholder='github_pat_...';edPubSay('Key removed from this device','#e8d4a8');},'#7a2a2a'));
    row.appendChild(mk('CLOSE',()=>{o.style.display='none';}));
    o.appendChild(t);o.appendChild(d);o.appendChild(inp);o.appendChild(row);o.appendChild(st);document.body.appendChild(o);
  }
  o.style.display='flex';const i=o.querySelector('#edTok');i.placeholder=edGetToken()?'(a key is saved - paste to replace)':'github_pat_...';
  const s=o.querySelector('#edPubStatus');s.textContent=ED.pub.msg||'';s.style.color=ED.pub.col;
}
if(typeof window!=='undefined')edLoad();
