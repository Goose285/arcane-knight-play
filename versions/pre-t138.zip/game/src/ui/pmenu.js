/* =====================================================================
   PAUSE MENU (t135u): one wood-framed parchment panel with tabs along the top
   CHARACTER  CARDS  INVENTORY  JOURNAL  WORLD  SKILLS  SETTINGS
   and a RESUME / HOME / SAVE & QUIT bar on every tab (plus the small EDITOR + SOUND buttons).
   Each tab shows its content inline; deep features (deck editor, gear, quests, skill tree...) open from buttons in the tab.
   Replaces the satchel main page; the old sub-pages (character / journal / skills) still work.
   ===================================================================== */
const PM_TABS=[['character','CHARACTER','hero'],['cards','CARDS','cards'],['inventory','INVENTORY','bag'],['journal','JOURNAL','scroll'],['world','WORLD','map'],['skills','SKILLS','star'],['settings','SETTINGS','cog']];
const PM={tab:'inventory',cat:'items',card:null,scroll:0,sel:null};
const PMC={ink:'#3a2210',ink2:'#6a4a2a',parch:'#ecdcb0',parch2:'#dcc690',wood:'#6a4224',wood2:'#3e2412',gold:'#a8741a'};
function pmText(s,x,y,o){txt(s,x,y,Object.assign({size:10,col:PMC.ink,lw:0,out:false},o||{}));}
function pmBtn(x,y,w,h,lab,col,act,id,o){
  const r={x,y,w,h,e:Object.assign({id,lab,act},o||{}),kind:'pm'};pauseRects.push(r);
  const sel=PAUSE.kbd&&pauseRects[PAUSE.sel]===r,dis=o&&o.dis;
  ctx.fillStyle=PMC.wood2;ctx.fillRect(x,y,w,h);ctx.fillStyle=dis?'#8a7a68':col||'#7a4a26';ctx.fillRect(x+2,y+2,w-4,h-4);
  ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(x+2,y+2,w-4,3);if(sel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x+1,y+1,w-2,h-2);}
  let sz=o&&o.size||11;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';while(sz>7&&ctx.measureText(lab).width>w-8){sz--;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';}
  txt(lab,x+w/2,y+h/2+sz*.36,{size:sz,align:'center',col:'#fff3d0',lw:2,out:'#2a160a'});return r;
}
function pmPanel(x,y,w,h){
  ctx.fillStyle=PMC.wood2;ctx.fillRect(x-2,y-2,w+4,h+4);ctx.fillStyle=PMC.wood;ctx.fillRect(x,y,w,h);
  for(let i=0;i<h;i+=7){ctx.fillStyle='rgba(0,0,0,.08)';ctx.fillRect(x,y+i,w,2);}
  ctx.fillStyle=PMC.parch;ctx.fillRect(x+7,y+7,w-14,h-14);
  ctx.fillStyle=PMC.parch2;ctx.fillRect(x+7,y+7,w-14,3);ctx.fillRect(x+7,y+h-10,w-14,3);
  for(const [cx,cy] of [[x+3,y+3],[x+w-9,y+3],[x+3,y+h-9],[x+w-9,y+h-9]]){ctx.fillStyle=PMC.gold;ctx.fillRect(cx,cy,6,6);ctx.fillStyle='#ffe27a';ctx.fillRect(cx+1,cy+1,2,2);}
}
function pmDraw(){
  pauseRects.length=0;
  const L=SL+6,R=VW-SR-6,W=Math.min(R-L,680),x=Math.round((VW-W)/2),y=ST+4,H=VH-ST-SB-8,tabH=Math.max(26,Math.min(34,Math.round(H*.1))),barH=Math.max(26,Math.min(34,Math.round(H*.1)));
  PM.box={x,y,W,H};
  // tabs
  const tw=Math.floor((W-12)/PM_TABS.length);
  PM_TABS.forEach(([id,lab,ic],i)=>{const tx=x+6+i*tw,on=PM.tab===id,ty=on?y:y+4,r={x:tx,y,w:tw-2,h:tabH,e:{id,lab,act:()=>{PM.tab=id;PM.scroll=0;PM.card=null;PM.sel=null;sfx('select');}},kind:'pmtab'};pauseRects.push(r);
    ctx.fillStyle=PMC.wood2;ctx.fillRect(tx,ty,tw-2,tabH+4);ctx.fillStyle=on?PMC.parch:'#8a5a32';ctx.fillRect(tx+2,ty+2,tw-6,tabH+2);
    if(PAUSE.kbd&&pauseRects[PAUSE.sel]===r){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(tx+1,ty+1,tw-4,tabH);}
    const small=tw<70;if(!small)pauseIcon(ic,tx+6,ty+Math.round(tabH/2)-5,1);
    let sz=9;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';const avail=tw-(small?8:22);while(sz>6&&ctx.measureText(lab).width>avail){sz--;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';}
    txt(lab,tx+(small?(tw-2)/2:18+(tw-20)/2),ty+tabH/2+4,{size:sz,align:'center',col:on?PMC.ink:'#fff3d0',lw:on?0:2,out:on?false:'#2a160a'});
    const b=id==='journal'?pauseReadyQ()+pauseStoryNew():id==='skills'?skillPoints():id==='character'?pauseDaily():0;
    if(b){ctx.fillStyle='#e8504a';ctx.beginPath();ctx.arc(tx+tw-8,ty+6,5,0,6.283);ctx.fill();}});
  const by=y+tabH,bh=H-tabH;pmPanel(x,by,W,bh);
  const cx0=x+14,cy0=by+12,cw=W-28,ch=bh-24-barH-8;PM.content={x:cx0,y:cy0,w:cw,h:ch};
  ctx.save();ctx.beginPath();ctx.rect(cx0-2,cy0-2,cw+4,ch+4);ctx.clip();
  try{(PM_DRAW[PM.tab]||(()=>{}))(cx0,cy0,cw,ch);}catch(err){if(window.__PMERR!==false)console.error(err);}
  ctx.restore();
  // bottom bar
  const yb=by+bh-12-barH,warn=gtime-PAUSE.qAt<=3,gap=8,eW=Math.min(70,Math.round(cw*.13)),bw=Math.floor((cw-eW*2-gap*4)/3);
  pmBtn(cx0,yb,bw,barH,'RESUME','#2d6a4f',()=>{pressed.KeyP=true;},'resume');
  pmBtn(cx0+bw+gap,yb,bw,barH,HOME.cd>0?'HOME '+Math.ceil(HOME.cd)+'s':'HOME','#2a6a6a',()=>pauseGo('KeyH2'),'home');
  pmBtn(cx0+2*(bw+gap),yb,bw,barH,warn?'TAP AGAIN':'SAVE & QUIT','#7a2a2a',pauseQuit,'quit',{quit:true});
  pmBtn(cx0+cw-eW*2-gap,yb,eW,barH,'EDITOR','#8a6a1a',()=>edOpen(),'editor',{size:9});
  pmBtn(cx0+cw-eW,yb,eW,barH,muted?'SOUND OFF':'SOUND ON','#34406a',()=>{muted=!muted;sfx('select');},'sound',{size:9});
}
/* ---------- tab contents ---------- */
const PM_DRAW={
  character(x,y,w,h){
    ctx.fillStyle='#14182c';ctx.fillRect(x,y,76,76);ctx.strokeStyle=PMC.gold;ctx.lineWidth=2;ctx.strokeRect(x+1,y+1,74,74);try{draw(SP.port.hero,x+4,y+4,2.85);}catch(e){}
    pmText('HERO',x+88,y+16,{size:16});pmText('Sun Paladin   Level '+P.lv,x+88,y+34,{size:11,col:PMC.ink2});
    const hp=Math.max(0,P.hp|0),mh=maxHp(),bw=Math.min(240,w-100);ctx.fillStyle=PMC.wood2;ctx.fillRect(x+88,y+42,bw,12);ctx.fillStyle='#c83a3a';ctx.fillRect(x+90,y+44,Math.round((bw-4)*hp/mh),8);
    pmText('HP '+hp+'/'+mh,x+88+bw/2,y+52,{size:9,align:'center',col:'#fff',lw:2,out:'#2a160a'});
    pmText(P.gold+' G     Foes beaten: '+kills,x+88,y+70,{size:10,col:PMC.ink2});
    const st=gearStats();pmText('Shot +'+st.shot+'   HP +'+st.hp+'   DEF +'+st.def+'   Crit +'+st.crit,x,y+94,{size:10});
    if(PET.active)pmText('Pet: '+PETS[PET.active].name+(PET_PERK[PET.active]?'  ('+PET_PERK[PET.active].t+')':''),x,y+110,{size:9,col:PMC.ink2});
    const bw2=Math.floor((w-24)/4),yy=y+Math.min(h-36,124);
    pmBtn(x,yy,bw2,32,'PETS','#5a2a5a',()=>openPets(),'pets');
    pmBtn(x+bw2+8,yy,bw2,32,'ACHIEVEMENTS','#7a5a1a',()=>openAch(),'ach');
    pmBtn(x+2*(bw2+8),yy,bw2,32,'DAILY'+(pauseDaily()?' !':''),'#8a6a1a',()=>openDaily(),'daily');
    pmBtn(x+3*(bw2+8),yy,bw2,32,labOn()?'LEAVE LAB':'COMBAT LAB','#1f5a7a',()=>pauseItem('KeyU').act(),'lab');
  },
  cards(x,y,w,h){
    const own=Object.keys(COL).filter(id=>COL[id]>0&&CARD[id]),detW=PM.card?Math.min(220,Math.round(w*.38)):0,gw=w-detW-(detW?10:0);
    pmText('DECK '+DECK.length+'/'+DECK_MAX+'  (min '+DECK_MIN+')',x,y+10,{size:10,col:DECK.length<DECK_MIN?'#a02020':PMC.ink2});
    pmBtn(x+gw-90,y-2,90,20,'EDIT DECK','#2d4f8a',()=>openDeck(),'deckedit',{size:9});
    const cw=Math.max(150,Math.min(200,Math.floor(gw/3)-6)),cols=Math.max(1,Math.floor((gw+6)/(cw+6))),rh=40,rows=Math.max(1,Math.floor((h-26)/(rh+5))),per=cols*rows,pages=Math.max(1,Math.ceil(own.length/per));
    PM.scroll=Math.min(PM.scroll,pages-1);
    own.slice(PM.scroll*per,PM.scroll*per+per).forEach((id,i)=>{const c=CARD[id],cx=x+(i%cols)*(cw+6),cy=y+20+Math.floor(i/cols)*(rh+5),on=PM.card===id;
      const r={x:cx,y:cy,w:cw-44,h:rh,e:{id:'card:'+id,lab:c.name,act:()=>{PM.card=PM.card===id?null:id;sfx('select');}},kind:'pmcard'};pauseRects.push(r);
      ctx.fillStyle=on?'#fff6d8':PMC.parch2;ctx.fillRect(cx,cy,cw,rh);ctx.strokeStyle=RAR[c.rar].col;ctx.lineWidth=2;ctx.strokeRect(cx+1,cy+1,cw-2,rh-2);
      try{draw(SP.ic[id],cx+4,cy+4,1.5);}catch(e){}
      {let sz=9;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';while(sz>6&&ctx.measureText(c.name).width>cw-78){sz--;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';}pmText(c.name,cx+30,cy+15,{size:sz});}pmText('deck '+deckCount(id)+'/'+COL[id],cx+30,cy+31,{size:8,col:PMC.ink2});
      pmBtn(cx+cw-42,cy+4,19,rh-8,'-','#7a2a2a',()=>deckRemove(id),'dec:'+id,{size:12});pmBtn(cx+cw-21,cy+4,19,rh-8,'+','#2d6a4f',()=>deckAdd(id),'inc:'+id,{size:12});});
    if(pages>1){pmBtn(x,y+h-20,40,20,'<','#6a4a2a',()=>{PM.scroll=Math.max(0,PM.scroll-1);},'pgprev');pmText((PM.scroll+1)+'/'+pages,x+60,y+h-6,{size:9});pmBtn(x+90,y+h-20,40,20,'>','#6a4a2a',()=>{PM.scroll=Math.min(pages-1,PM.scroll+1);},'pgnext');}
    if(PM.card&&CARD[PM.card]){const c=CARD[PM.card],dx=x+gw+10;ctx.fillStyle='#fff6d8';ctx.fillRect(dx,y,detW,h);ctx.strokeStyle=RAR[c.rar].col;ctx.lineWidth=3;ctx.strokeRect(dx+1.5,y+1.5,detW-3,h-3);
      try{draw(SP.ic[PM.card],dx+detW/2-24,y+10,3);}catch(e){}
      pmText(c.name,dx+detW/2,y+72,{size:13,align:'center'});pmText(RAR[c.rar].n,dx+detW/2,y+86,{size:9,align:'center',col:RAR[c.rar].col,lw:2,out:'#2a160a'});
      const lines=wrapText(cardInfo(PM.card),detW-16,'bold '+scaleText(10)+'px "Courier New",monospace');lines.forEach((l,i)=>pmText(l,dx+8,y+104+i*13,{size:10}));
      pmText('In deck: '+deckCount(PM.card)+'   Owned: '+(COL[PM.card]|0),dx+8,y+h-10,{size:9,col:PMC.ink2});}
  },
  inventory(x,y,w,h){
    const cats=[['potions','POTIONS'],['items','ITEMS'],['materials','MATERIALS'],['key','KEY ITEMS']],sw=Math.min(110,Math.round(w*.22));
    cats.forEach(([id,lab],i)=>{const on=PM.cat===id;pmBtn(x,y+i*34,sw,30,lab,on?'#a8741a':'#6a4a2a',()=>{PM.cat=id;PM.sel=null;sfx('select');},'cat:'+id,{size:10});});
    pmText(P.gold+' G',x+sw/2,y+4*34+18,{size:13,align:'center',col:'#8a5a00'});
    const items=pmItems(PM.cat),gx=x+sw+12,gw=w-sw-12,s=Math.max(36,Math.min(56,Math.floor((h-40)/3)-6)),cols=Math.max(1,Math.floor((gw+6)/(s+6))),rows=Math.max(1,Math.floor((h-34)/(s+6)));
    if(PM.cat==='items'){const st=gearStats();pmText('Totals  Shot +'+st.shot+'  HP +'+st.hp+'  DEF +'+st.def+'  Crit +'+st.crit,gx,y+10,{size:9,col:PMC.ink2});pmBtn(gx+gw-96,y-2,96,20,'EQUIPMENT','#7a5530',()=>openGear(),'gear',{size:9});}
    for(let i=0;i<cols*rows;i++){const sx=gx+(i%cols)*(s+6),sy=y+22+Math.floor(i/cols)*(s+6),it=items[i];satSlot(sx,sy,s,PM.sel===i?1:0);
      if(it){pauseRects.push({x:sx,y:sy,w:s,h:s,e:{id:'slot:'+i,lab:it.name,act:()=>{PM.sel=PM.sel===i?null:i;sfx('select');}},kind:'pmslot'});
        if(it.key){ctx.fillStyle='#ffe27a';ctx.fillRect(sx+s/2-6,sy+s/2-3,8,6);ctx.fillRect(sx+s/2+2,sy+s/2-1,8,2);}else satItemIcon(it,sx,sy,s);
        if(it.count>1)txt(String(it.count),sx+s-4,sy+s-5,{size:9,align:'right',col:'#fff',lw:3,out:'#1c0e06'});
        if(it.eq){ctx.fillStyle='#e0b44a';ctx.fillRect(sx+3,sy+3,9,9);txt('E',sx+7.5,sy+11,{size:8,align:'center',col:'#3a2208',lw:0,out:false});}}}
    const sel=PM.sel!=null&&items[PM.sel];
    if(sel){pmText(sel.name,gx,y+h-14,{size:11});pmText(sel.sub||'',gx,y+h-2,{size:9,col:PMC.ink2});}
    else if(!items.length)pmText(PM.cat==='potions'?'No potions yet. Healing comes from your Heal cards and resting at the inn.':'Nothing here yet.',gx,y+h-4,{size:9,col:PMC.ink2});
  },
  journal(x,y,w,h){
    const act=QUESTS.filter(q=>{const s=questStatus(q.id);return s==='active'||s==='ready';}),done=QUESTS.filter(q=>questStatus(q.id)==='done').length;
    pmText('QUESTS  ('+act.length+' active, '+done+' done)',x,y+10,{size:11});
    act.slice(0,Math.max(1,Math.floor((h-80)/26))).forEach((q,i)=>{const yy=y+22+i*26,rd=questStatus(q.id)==='ready';ctx.fillStyle=rd?'#f6e6a0':PMC.parch2;ctx.fillRect(x,yy,w,22);
      pmText((rd?'READY  ':'')+q.name,x+8,yy+15,{size:10,col:rd?'#7a4a00':PMC.ink});});
    if(!act.length)pmText('No active quests. Talk to the villagers!',x,y+38,{size:10,col:PMC.ink2});
    const bw=Math.floor((w-8)/2);pmBtn(x,y+h-34,bw,32,'ALL QUESTS','#2a5a4a',()=>openQuests(),'quests');
    pmBtn(x+bw+8,y+h-34,bw,32,'CHRONICLE'+(pauseStoryNew()?' ('+pauseStoryNew()+')':''),'#7a4a2a',()=>openUIMode('story'),'story');
  },
  world(x,y,w,h){
    const mw=Math.min(w,Math.round((h-40)*1.25));try{travelMapRow().draw(x,y,mw,h-40);}catch(e){}
    const n=WAYSTONES.filter(q=>SEC.ways[q.id]).length;
    if(mw<w-120){let yy=y+12;pmText('WAYSTONES '+n+'/'+WAYSTONES.length,x+mw+10,yy,{size:10});for(const q of WAYSTONES){yy+=15;pmText((SEC.ways[q.id]?'* ':'? ')+(SEC.ways[q.id]?q.name.replace(' Waystone',''):'???'),x+mw+10,yy,{size:9,col:SEC.ways[q.id]?'#1a5a6a':PMC.ink2});}}
    pmText(areaName(Math.floor(P.x/TS),Math.floor(P.y/TS)),x,y+h-12,{size:11});
    pmBtn(x+w-130,y+h-34,130,32,'TRAVEL','#2a4a6a',()=>openTravel(),'travel');
  },
  skills(x,y,w,h){
    const sp=skillPoints();pmText(sp+' skill point'+(sp===1?'':'s')+' to spend',x,y+12,{size:12,col:sp?'#8a5a00':PMC.ink2});
    const rows=[['tree','SKILL TREE','Spend points on new powers','#6a3a8a',()=>openSkills()],['fish','FISHING','Rods and your catch'+(FSH.rod>=0?' ('+fishCount()+')':''),'#1f5a7a',()=>openFishing()],['craft','CRAFTING','Workbench: craft gear, upgrade cards','#6a5a2a',()=>openCraft()]];
    rows.forEach(([id,lab,sub,col,act],i)=>{const yy=y+26+i*44;pmBtn(x,yy,150,38,lab,col,act,id);pmText(sub,x+162,yy+23,{size:10,col:PMC.ink2});});
  },
  settings(x,y,w,h){
    const row=(i,lab,val,dec,inc,id)=>{const yy=y+4+i*34;pmText(lab,x,yy+19,{size:11});const bx=x+Math.min(170,w*.35);pmBtn(bx,yy,30,28,'-','#6a4a2a',dec,id+'-',{size:13});
      if(typeof val==='number'){const bw=Math.min(160,w-bx+x-80);ctx.fillStyle=PMC.wood2;ctx.fillRect(bx+36,yy+8,bw,12);ctx.fillStyle='#d9a02a';ctx.fillRect(bx+38,yy+10,Math.round((bw-4)*val),8);pmBtn(bx+42+bw,yy,30,28,'+','#6a4a2a',inc,id+'+',{size:13});}
      else{const bw=Math.min(190,w-bx+x-80);pmText(val,bx+36+bw/2,yy+19,{size:10,align:'center'});pmBtn(bx+42+bw,yy,30,28,'>','#6a4a2a',inc,id+'+',{size:13});}};
    row(0,'MASTER',SET.master,()=>setVol('master',-.1),()=>setVol('master',.1),'master');
    row(1,'MUSIC',SET.music,()=>setVol('music',-.1),()=>setVol('music',.1),'music');
    row(2,'EFFECTS',SET.sfx,()=>setVol('sfx',-.1),()=>setVol('sfx',.1),'sfx');
    row(3,'TEXT SIZE',TEXT_SIZES[SET.text].n,()=>setCycle('text',TEXT_SIZES.length,-1),()=>setCycle('text',TEXT_SIZES.length,1),'text');
    row(4,'COLOUR-BLIND',CB_MODES[SET.cb].n,()=>setCycle('cb',CB_MODES.length,-1),()=>setCycle('cb',CB_MODES.length,1),'cb');
    pmBtn(x,y+Math.min(h-32,5*34+8),170,30,'MORE SETTINGS','#34406a',()=>openSettings('paused'),'moreset',{size:10});
    pmBtn(x+180,y+Math.min(h-32,5*34+8),170,30,'CONTROLS GUIDE','#2d4f8a',()=>{pressed.KeyP=true;openGuide();},'guide',{size:10});
  }
};
function pmItems(cat){
  const all=satItems();
  if(cat==='items')return all.filter(i=>i.spr);
  if(cat==='materials')return all.filter(i=>i.gem||i.fish);
  if(cat==='key')return Object.keys(QS.items||{}).filter(k=>QS.items[k]>0).map(k=>({name:k.replace(/[_-]/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),sub:'Key item',count:QS.items[k]|0,key:true}));
  return [];
}
function pmTap(p){
  PAUSE.kbd=false;const r=pauseRects.slice().reverse().find(q=>inRect(p,q));if(r){r.e.act();return true;}return false;
}
function pmKeys(){
  const i=PM_TABS.findIndex(t=>t[0]===PM.tab);
  if(hit('BracketRight','Tab','KeyE')){PM.tab=PM_TABS[(i+1)%PM_TABS.length][0];PM.scroll=0;sfx('select');return true;}
  if(hit('BracketLeft','KeyQ2')){PM.tab=PM_TABS[(i+PM_TABS.length-1)%PM_TABS.length][0];PM.scroll=0;sfx('select');return true;}
  const n=pauseRects.length,mv=d=>{PAUSE.kbd=true;PAUSE.sel=((PAUSE.sel+d)%n+n)%n;sfx('select');};
  if(hit('ArrowRight','ArrowDown','KeyS'))mv(1);else if(hit('ArrowLeft','ArrowUp','KeyW'))mv(-1);
  if(hit('Enter','Space')){const r=pauseRects[PAUSE.sel];if(r&&PAUSE.kbd){r.e.act();return true;}PAUSE.kbd=true;}
  return false;
}
