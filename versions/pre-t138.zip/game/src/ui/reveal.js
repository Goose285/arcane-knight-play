/* =====================================================================
   REVEAL: getting something new is an event. NEW CARD / NEW ITEM / LEVEL UP / TREASURE each get a short showcase over the world:
   a white flash, rotating light rays, a sparkle burst, a fanfare and the thing itself, big, with its name and what it does.
   Queued; shown outside fights and dialogue; tap / any key (or 3.4s) moves on.
   ===================================================================== */
const REV={q:[],cur:null,t:0,parts:[],lastLv:0,seen:0};
const REV_TITLES={card:'NEW CARD!',item:'NEW ITEM!',level:'LEVEL UP!',chest:'TREASURE!'};
function revealPush(o){if(window.__NOREVEAL)return;REV.q.push(o);REV.seen++;}
function revealCard(id){const c=CARD[id];if(c)revealPush({k:'card',id,name:c.name,col:RAR[c.rar].col,sub:RAR[c.rar].n+' card',info:typeof cardInfo==='function'?cardInfo(id):c.desc});}
function revealItem(it){if(!it||!GEAR_RAR[it.rar])return;revealPush({k:'item',it,name:it.name,col:GEAR_RAR[it.rar].col,sub:GEAR_RAR[it.rar].n+' '+(GEAR_SLOT_NAME[it.slot]||'').toLowerCase()+'  Lv'+it.lv});}
function revealLevel(lv){revealPush({k:'level',name:'LEVEL '+lv,col:'#7dffa0',sub:'HP restored  -  +1 skill point',info:'Max HP '+maxHp()+'.  Spend skill points in the menu (SKILLS).'});}
function revealChest(tier,lines){revealPush({k:'chest',tier,name:['Wooden Chest','Iron Chest','Golden Chest','Hidden Chest'][tier]||'Chest',col:'#ffd23f',sub:lines.slice(0,4).join('  -  ')});}
const revealBusy=()=>!!REV.cur;
function updateReveal(dt){
  for(const p of REV.parts){p.t+=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=60*dt;}REV.parts=REV.parts.filter(p=>p.t<p.life);
  if(!REV.lastLv)REV.lastLv=P.lv;
  if(state==='play'&&P.lv>REV.lastLv){revealLevel(P.lv);}REV.lastLv=Math.max(REV.lastLv,P.lv);
  if(state==='title'){REV.q.length=0;REV.cur=null;REV.lastLv=0;return;}
  if(REV.cur){REV.t+=dt;if(REV.t>3.4)REV.cur=null;else if(REV.t>.5&&hit('Enter','Space','KeyJ','KeyE','Escape'))REV.cur=null;return;}
  if(!REV.q.length||state!=='play'||B||DLG||(typeof introHold==='function'&&introHold()))return;
  REV.cur=REV.q.shift();REV.t=0;sfx(REV.cur.k==='level'?'level':REV.cur.k==='chest'?'coin':'questdone');setTimeout(()=>sfx('select'),180);
  for(let i=0;i<44;i++){const a=Math.random()*6.283,s=R(60,260);REV.parts.push({x:VW/2,y:VH*.42,vx:Math.cos(a)*s,vy:Math.sin(a)*s-40,t:0,life:R(.6,1.4),col:i%3?REV.cur.col:'#ffffff',sz:R(2,4)|0});}
}
function revealTap(){if(REV.cur&&REV.t>.35){REV.cur=null;return true;}return !!REV.cur;}
function drawReveal(){
  for(const p of REV.parts){ctx.globalAlpha=Math.max(0,1-p.t/p.life);ctx.fillStyle=p.col;ctx.fillRect(Math.round(p.x),Math.round(p.y),p.sz,p.sz);}ctx.globalAlpha=1;
  const r=REV.cur;if(!r)return;
  const t=REV.t,cx=VW/2,cy=VH*.42,inA=Math.min(1,t/.25),outA=t>3?Math.max(0,1-(t-3)/.4):1,a=inA*outA;
  // flash, dim, rays
  if(t<.3){ctx.fillStyle=`rgba(255,255,255,${(1-t/.3)*.85})`;ctx.fillRect(0,0,VW,VH);}
  ctx.fillStyle=`rgba(8,6,20,${.55*a})`;ctx.fillRect(0,0,VW,VH);
  ctx.save();ctx.translate(cx,cy);ctx.rotate(t*.6);ctx.globalAlpha=.22*a;ctx.fillStyle=r.col;
  for(let i=0;i<12;i++){ctx.rotate(Math.PI/6);ctx.beginPath();ctx.moveTo(0,0);ctx.lineTo(-18,-VH);ctx.lineTo(18,-VH);ctx.closePath();ctx.fill();}ctx.restore();ctx.globalAlpha=1;
  const sc=Math.min(1,.4+t*3)*(1+.03*Math.sin(t*6));
  txt(REV_TITLES[r.k]||'NEW!',cx,cy-VH*.25,{size:Math.round(26*Math.min(1.2,.6+t*2)),align:'center',col:'#ffe14d',lw:6,out:'#2a160a'});
  ctx.save();ctx.translate(cx,cy);ctx.scale(sc,sc);ctx.globalAlpha=a;
  if(r.k==='card'){const cw=86,ch=118;ctx.translate(-cw/2,-ch/2);drawCardFace(r.id,cw,ch,true,null);}
  else if(r.k==='item'){gearIconBox(-32,-32,r.it,64);}
  else if(r.k==='level'){ctx.fillStyle='#14182c';ctx.beginPath();ctx.arc(0,0,40,0,6.283);ctx.fill();ctx.fillStyle=r.col;ctx.beginPath();ctx.arc(0,0,35,0,6.283);ctx.fill();txt(String(P.lv),0,12,{size:32,align:'center',col:'#14182c',lw:0,out:false});}
  else{draw(TSPR[T.CHST]?TSPR[T.CHST][0]:SP.ic.sword,-32,-32,4);}
  ctx.restore();ctx.globalAlpha=1;
  // sparkles twinkling around the showcase
  for(let i=0;i<8;i++){const an=i/8*6.283+t*1.2,rr=70+8*Math.sin(t*4+i),x=cx+Math.cos(an)*rr,y=cy+Math.sin(an)*rr*.8,s=(Math.sin(t*8+i*2)+1)*2;ctx.fillStyle='#fff8d0';ctx.fillRect(x-s,y,s*2+1,1);ctx.fillRect(x,y-s,1,s*2+1);}
  const ny=cy+VH*.2;txt(r.name,cx,ny,{size:17,align:'center',col:r.col,lw:4,out:'#14182c'});
  if(r.sub)txt(r.sub,cx,ny+20,{size:10,align:'center',col:'#f6e6c0',lw:3,out:'#14182c'});
  if(r.info){const font='bold '+scaleText(10)+'px "Courier New",monospace',ls=wrapText(r.info,Math.min(VW-60,420),font);ls.slice(0,3).forEach((l,i)=>txt(l,cx,ny+38+i*14,{size:10,align:'center',col:'#cfe0ff',lw:3,out:'#14182c'}));}
  if(t>.6)txt(TOUCH?'tap to continue':'press Enter',cx,VH-SB-16,{size:9,align:'center',col:'rgba(255,255,255,.7)',lw:2});
}
