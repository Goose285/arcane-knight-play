#!/usr/bin/env bash
# Recoverable backup before a major update:
#  1. tags HEAD in the game repo and the play repo (local tags: backup-<label>)
#  2. copies the CURRENT playable build from the play repo into ak-play/versions/<label>/ so that older version stays playable on the
#     site at  <site>/versions/<label>/  (sw.js is left out on purpose so the old copy never fights the live service worker)
#  3. commits that copy in the play repo (no push)
# usage: scripts/snapshot.sh [label] [play-repo]      label defaults to YYYY-MM-DD-<short game hash>
set -euo pipefail
GAME="$(cd "$(dirname "$0")/.." && pwd)"
PLAY="${2:-$GAME/../ak-play}"; PLAY="$(cd "$PLAY" && pwd)"
LABEL="${1:-$(date +%Y-%m-%d)-$(git -C "$GAME" rev-parse --short HEAD)}"
ID=(-c user.name="Seth Moynahan" -c user.email="seth@users.noreply.local")
for R in "$GAME" "$PLAY"; do
  if git -C "$R" rev-parse -q --verify "refs/tags/backup-$LABEL" >/dev/null; then echo "tag backup-$LABEL already in $R"; else git -C "$R" "${ID[@]}" tag -a "backup-$LABEL" -m "backup before update ($LABEL)"; echo "tagged $R -> backup-$LABEL"; fi
done
DEST="$PLAY/versions/$LABEL"; mkdir -p "$DEST"
for f in index.html manifest.webmanifest icons world-edits.json; do [ -e "$PLAY/$f" ] && cp -R "$PLAY/$f" "$DEST/"; done
# list of every kept version
( echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Arcane Knight - older versions</title><h1>Older versions</h1><ul>'
  for d in $(ls -1 "$PLAY/versions" | grep -v '\.html$' | sort -r); do echo "<li><a href=\"$d/\">$d</a></li>"; done; echo '</ul><p><a href="../">current version</a></p>' ) > "$PLAY/versions/index.html"
git -C "$PLAY" add versions && git -C "$PLAY" "${ID[@]}" commit -qm "Snapshot playable build: versions/$LABEL" && echo "committed versions/$LABEL in play repo"
echo "versions path: /versions/$LABEL/"
