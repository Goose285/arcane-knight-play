// M70 (t153u): west Blacksmith + Oakvale Tap + fishing features.
//   node tests/ms70.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms70',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t153/.test(tags),'backup tag backup-pre-t153');
 await E(()=>__game.dbg.startFromTitle());await sleep(1200);
 // wait for t153 builders
 await E(async()=>{for(let i=0;i<40;i++){if(window.__t153Town)window.__t153Town();await new Promise(r=>setTimeout(r,50));if(SMITH_SHOP&&SMITH_SHOP.west&&TAVERN&&TAVERN.west)break;}});
 await sleep(200);
 let s=await E(()=>{
  const brum=NPCS.find(n=>n.name==='Blacksmith Brum');
  const mara=NPCS.find(n=>n.name==='Mara the Tapster');
  const forgeSign=NPCS.find(n=>/Brum.*Forge/.test(n.name||''));
  const tapSign=NPCS.find(n=>/Oakvale Tap/.test(n.name||''));
  let anv=0,frn=0,yard=0;
  const door=SMITH_SHOP.door;
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){
    if(map[y][x]===T.ANV){anv++;const near=door&&Math.abs(x-door.tx)<=5&&y>=door.wy-6&&y<=door.wy;if(!near)yard++;}
    if(map[y][x]===T.FRN){frn++;const tb=TAVERN.box,inTap=tb&&x>tb.x0&&x<tb.x1&&y>tb.y0&&y<tb.y1;const near=inTap||door&&Math.abs(x-door.tx)<=5&&y>=door.wy-6&&y<=door.wy;if(!near)yard++;}
  }
  // west buildings: smith around local x1-6 y33-37, tavern x1-7 y39-43
  const ox=typeof OX==='number'?OX:0,oy=typeof OY==='number'?OY:0;
  let smithFloor=0,tapFloor=0;
  for(let y=46;y<=50;y++)for(let x=49;x<=54;x++)if(map[oy+y][ox+x]===T.F||map[oy+y][ox+x]===T.ANV||map[oy+y][ox+x]===T.FRN||map[oy+y][ox+x]===T.BT)smithFloor++;
  for(let y=46;y<=51;y++)for(let x=35;x<=44;x++)if(map[oy+y][ox+x]===T.F||map[oy+y][ox+x]===T.Z||map[oy+y][ox+x]===T.BT)tapFloor++;
  const brumIn=brum&&brum.x>(ox+48)*TS&&brum.x<(ox+56)*TS&&brum.y>(oy+45)*TS&&brum.y<(oy+51)*TS;
  const maraIn=mara&&mara.x>(ox+34)*TS&&mara.x<(ox+46)*TS&&mara.y>(oy+45)*TS&&mara.y<(oy+53)*TS;
  return {west:!!(SMITH_SHOP.west&&TAVERN.west),anv,frn,yard,smithFloor,tapFloor,brumIn,maraIn,
    maraInn:!!(mara&&mara.inn),maraTap:!!(mara&&mara.oakTap),forgeSign:!!forgeSign,tapSign:!!tapSign,
    stew:!!(TAVERN.stew&&TAVERN.stew.buff),townX0:TOWN.x0};
 });
 ok(s.west,'west smith + tavern flagged');
 ok(s.smithFloor>=8,'west smith has interior floors/props ('+s.smithFloor+')');
 ok(s.tapFloor>=8,'west tavern has interior floors/props ('+s.tapFloor+')');
 ok(s.brumIn,'Brum is inside west smith');
 ok(s.maraIn,'Mara is inside Oakvale Tap');
 ok(!s.maraInn&&s.maraTap,'Mara is oakTap (not inn sleep dialog)');
 ok(s.anv>=1&&s.frn>=1,'forge has anvil+furnace');
 ok(s.yard===0,'no stray yard anvil/furnace (yard='+s.yard+')');
 ok(s.forgeSign&&s.tapSign,'forge + tap signs present');
 ok(s.stew,'tavern stew buff configured');
 // Mara dialog unique path
 s=await E(()=>{openDlg(NPCS.find(n=>n.name==='Mara the Tapster'));const d=DLG;const ok=d&&/MARA|TAPSTER/i.test(d.name||'')&&/STEW/i.test(d.yes||'');DLG=null;return {ok,name:d&&d.name,yes:d&&d.yes};});
 ok(s.ok,'Mara opens stew dialog (name='+s.name+' yes='+s.yes+')');
 // fishing features API
 s=await E(()=>{
  const max=FISH_MAX_LV;
  const glow=!!FISH_BY.glowfish,dusk=!!FISH_BY.duskfin;
  FSH.spots={pond:{caught:3}};const st1=spotStars('pond');
  FSH.spots.pond.caught=80;const st5=spotStars('pond');
  FSH.fish={minnow:2,carp:2,trout:1,pike:1,sturgeon:1,glowfish:1,gill:1};
  P.gold=500;const baitOk=buyBait('worm');const bobOk=buyBobber('cork');
  const cookOk=cookMeal('river_stew');
  const mealOn=MEAL_BUFF.t>0&&MEAL_BUFF.luck>0;
  applyMealBuff('def',30,'Test Chowder');
  const defMul=mealDefMul();
  const w0=FSH.week.best|0;fishWeekSubmit(FISH_BY.trout,42.5);const w1=FSH.week.best;
  tankAdd('glowfish');
  const packed=packFish();
  return {max,glow,dusk,st1,st5,baitOk,bobOk,cookOk,mealOn,defMul,w0,w1,tank:FSH.tank.slice(),
    packHas:!!(packed.spots&&packed.tank&&packed.week&&('bait' in packed)),
    tod:typeof fishTimeBucket==='function'?fishTimeBucket():null,
    rows:typeof UI_MODES.fish.rows==='function'?UI_MODES.fish.rows().some(r=>r.t==='head'&&/SPOT MASTERY/.test(r.s||'')):false};
 });
 ok(s.max===70,'FISH_MAX_LV stays 70');
 ok(s.glow&&s.dusk,'glowfish + duskfin registered');
 ok(s.st1===1&&s.st5===5,'spot stars 1 at 3 catches, 5 at 80');
 ok(s.baitOk&&s.bobOk,'tackle buy/equip works');
 ok(s.cookOk&&s.mealOn,'cooking applies luck meal buff');
 ok(s.defMul<1,'defense meal reduces damage mul ('+s.defMul+')');
 ok(s.w1>=42,'weekly contest records biggest catch');
 ok(s.tank.includes('glowfish'),'trophy shelf accepts rare fish');
 ok(s.packHas,'packFish persists spots/tank/week/bait');
 ok(s.rows,'fishing UI shows spot mastery section');
 // camera / HUD / DPR regressions stay fixed
 s=await E(()=>{
  SET.perf=false;qualApply();P.x=21*32;P.y=262*32;state='play';DLG=null;WARP=null;FISH.on=false;B=null;snapCam();
  P.x+=280;for(let i=0;i<40;i++)update(1/30);
  return {dx:Math.abs(cam.x-(P.x-VW/2)),DPR,EN:typeof EN_AI_I,hasCam:typeof camFollow==='function'};
 });
 ok(s.dx<2,'camera still follows (dx='+s.dx.toFixed(2)+')');
 ok(s.EN==='number','EN_AI_I still declared');
 ok(s.hasCam,'camFollow still present');
 ok(s.DPR<=2,'DPR <=2');
 const main=fs.readFileSync(__dirname+'/../src/main.js','utf8');
 ok(!/while\s*\(!EDS&&Math\.floor\(dw\/\(S\+1\)\)>=420\)/.test(main),'no VW<=420 loop reintroduced');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');
 ok(/arcane-knight-v60/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v60');
 // tutorial slimes still north of gate (spot-check y)
 s=await E(()=>{
  const tut=enemies.filter(e=>e.alive&&e.type==='slime'&&e.y<(typeof OY==='number'?OY:0)*TS+40*TS);
  return {n:tut.length};
 });
 ok(s.n>=1,'tutorial/north slimes still present ('+s.n+')');
 await sleep(200);ok(errs.length===0,'no page errors '+errs.slice(0,3).join(' | '));
 await finish();
})();
