// M71 (t154u): tavern, card gap, Orin one-talk, skeletons, shadow curse, achievements, XP curve, fish, roofs.
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms71',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t154/.test(tags),'backup tag backup-pre-t154');
 await E(()=>__game.dbg.startFromTitle());await sleep(1500);
 await E(async()=>{for(let i=0;i<30;i++){window.__t153Town&&window.__t153Town();if(TAVERN.box)break;await new Promise(r=>setTimeout(r,60));}});
 // tavern: enterable (doorway walkable, BFS from outside reaches Mara) + ~3x bigger
 let s=await E(()=>{const b=TAVERN.box,d=TAVERN.door,area=(b.x1-b.x0-1)*(b.y1-b.y0-1);
   const mara=NPCS.find(n=>n.name==='Mara the Tapster');const mx=Math.floor(mara.x/TS),my=Math.floor(mara.y/TS);
   const sx=d.tx,sy=d.wy+2;const seen=new Set([sx+','+sy]),q=[[sx,sy]];let reach=false;
   while(q.length){const [x,y]=q.shift();if(Math.abs(x-mx)+Math.abs(y-my)<=1){reach=true;break;}for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=nx+','+ny;if(seen.has(k)||solidTile(nx,ny))continue;seen.add(k);q.push([nx,ny]);}}
   return {area,doorSolid:solidTile(d.tx,d.wy),reach,oak:!!mara.oakTap,inn:!!mara.inn,inside:mx>b.x0&&mx<b.x1&&my>b.y0&&my<b.y1};});
 ok(!s.doorSolid,'tavern doorway is walkable');ok(s.reach,'player can walk from the street to Mara');ok(s.inside,'Mara inside the tavern');
 ok(s.area>=45,'tavern interior ~3x bigger (area='+s.area+', was 15)');ok(s.oak&&!s.inn,'Mara keeps oakTap, not inn');
 s=await E(()=>{const b=SMITH_SHOP.door;const brum=NPCS.find(n=>n.name==='Blacksmith Brum');return {door:!solidTile(b.tx,b.wy),bx:Math.floor(brum.x/TS)-b.tx,by:b.wy-Math.floor(brum.y/TS)};});
 ok(s.door&&Math.abs(s.bx)<=3&&s.by>0&&s.by<=5,'smith walkable, Brum inside');
 // west restored: pet pen + inn not overwritten
 s=await E(()=>({pen:PEN.on?PEN.pets.every(p=>p.x>=(PEN.x0+1)*TS&&p.x<=PEN.x1*TS):true,innRoof:map[INN.y0][INN.x0]===T.R}));
 ok(s.pen,'pen pets inside paddock');ok(s.innRoof,'inn roof row intact');
 // homes for homeless villagers
 s=await E(()=>Object.keys(window.__t154Homes||{}));ok(s.length>=4,'cottages for villagers ('+s.join(',')+')');
 // card gap (touch geometry) for small + large hands
 s=await E(()=>{const r=[];for(const n of [3,5,7,8]){const F=fanGeom(n);r.push(F.gap);}return r;});
 ok(s.every(g=>g>=9.5),'card fan keeps >=10px gap for 3/5/7/8 cards ('+s.map(g=>g.toFixed(1)).join(',')+')');
 // Orin: one talk hands in Slime Trouble and offers the next quest
 s=await E(()=>{const orin=NPCS.find(n=>n.name==='Elder Orin');QS.st.slimes='active';QS.n.slimes=3;try{questCheckReady(QUEST_BY_ID.slimes);}catch(e){}QS.st.slimes='ready';
   DLG=null;openDlg(orin);const d=DLG;const offered=!!(d&&d.choice&&/Signet/.test(d.lines.join(' ')));if(d&&d.choice)d.choice();DLG=null;return {offered,ring:QS.st.ring};});
 ok(s.offered,'one talk with Orin hands in slimes AND offers The Lost Signet');ok(s.ring==='active','Lost Signet starts from that same talk');
 // skeletons not in Greenmeadow
 s=await E(()=>{skelGuardTick(true);return enemies.filter(e=>e.type==='knight'&&(inGreenmeadow(e.hx,e.hy)||inGreenmeadow(e.x,e.y))).length;});
 ok(s===0,'no skeleton homes/positions in Greenmeadow ('+s+')');
 // shadow step curse
 s=await E(()=>{const g=__game;g.P.hp=1e6;g.fight('slime');const B2=g.B;B2.phase='fight';B2.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;});const e=B2.ens[0];
   const a=Math.atan2(e.y-P.y,e.x-P.x);doShadowStep(a,130);const w=e.weak;const hp0=e.hp;return {w};});
 ok(s.w>0,'Shadow Step applies the shadow curse (weak='+s.w+')');
 await E(()=>{B=null;});
 // achievements
 s=await E(()=>{const a=ACHS.find(x=>x.id==='fish1000'),b=ACHS.find(x=>x.id==='boots25');ACH.s.boots=0;fishAward(FISH_BY.boot,false);const one=ACH.s.boots;const pk=packAch();return {a:!!a,b:!!b,one,saved:pk.s.boots};});
 ok(s.a&&s.b,'achievements fish1000 + boots25 exist');ok(s.one===1&&s.saved===1,'old boots counted + saved');
 // XP curve
 s=await E(()=>({l3:xpNeedAt(3)/xpNeedOld(3),l20:xpNeedAt(20)/xpNeedOld(20),l10:xpNeedAt(10)/xpNeedOld(10)}));
 ok(s.l3<1.2&&s.l10>1.4&&s.l20>2,'XP curve steeper mid/late, early gentle '+JSON.stringify(s));
 // fish
 s=await E(()=>({n:FISHES.length,ids:['shiner','lantern','emberkoi','starray','serpent'].every(i=>FISH_BY[i])}));
 ok(s.n>=30&&s.ids,'fish count increased ('+s.n+')');
 // tracker vs daily
 s=await E(()=>trkPick(trkEntries().filter(e=>e.kind==='daily')));ok(s===null,'tracker never picks a daily');
 // roofs + inn
 const hs=fs.readFileSync(__dirname+'/../src/render/house-styles.js','utf8'),inn=fs.readFileSync(__dirname+'/../src/render/inn-art.js','utf8');
 ok(!/#c8a050/.test(hs)&&/char/.test(hs),'no golden thatch, six roof styles');ok(/#26252c/.test(inn),'inn roof is black');
 // regressions
 s=await E(()=>({EN:typeof EN_AI_I,cf:typeof camFollow,DPR}));ok(s.EN==='number'&&s.cf==='function'&&s.DPR<=2,'EN_AI_I/camFollow/DPR ok');
 ok(/arcane-knight-v60/.test(fs.readFileSync(__dirname+'/../sw.js','utf8')),'sw v60');
 await sleep(200);ok(errs.length===0,'no page errors '+errs.slice(0,3).join(' | '));
 await finish();
})();
