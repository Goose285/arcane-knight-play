/* =====================================================================
   HOUSE VARIETY (t138u): every house in town gets one of five styles, picked from where it stands (stable, no save data):
     0 RED TILE roof + cream plaster, flower boxes      1 BLUE SLATE roof + grey stone, shutters, hipped ends
     2 MOSS GREEN roof + white TIMBER FRAMING            3 golden THATCH (hipped) + wooden planks, shutters
     4 PLUM roof + red BRICK, flower boxes
   plus chimneys (most styles), varied windows and doors. Pure art: tile ids, collision and the editor are unchanged; the Inn keeps its own look.
   ===================================================================== */
{
  const HS=[   // t154u: no more yellow roofs - deep red, slate, forest green, brown thatch, terracotta, charcoal
    {n:'red',  roof:['#8e2a22','#ac4436','#5a1610'],fas:'#3e120c',wall:'plaster',door:'#7a4a24',box:true, chim:true, hip:false},
    {n:'slate',roof:['#4a5878','#6a7aa0','#2a3450'],fas:'#1e2638',wall:'stone',  door:'#3e5a7a',box:false,chim:true, hip:true},
    {n:'moss', roof:['#2f5e30','#4a7e44','#1a3a1e'],fas:'#1e2c14',wall:'timber', door:'#6a3f1e',box:true, chim:false,hip:false},
    {n:'thatch',roof:['#7a5a34','#94714a','#4e381e'],fas:'#3a2812',wall:'planks',door:'#8a5a2c',box:false,chim:false,hip:true},
    {n:'terra',roof:['#b0603a','#c87c52','#7a3e22'],fas:'#4a2412',wall:'brick',  door:'#2f5a3a',box:true, chim:true, hip:false},
    {n:'char', roof:['#3a3a40','#55555e','#202024'],fas:'#18181c',wall:'stone',  door:'#5a2a2a',box:true, chim:true, hip:true},
  ];
  const r=(g,x,y,w,h,c)=>rect(g,x,y,w,h,c),O='#14182c';
  const roofRow=(id,y)=>id===T.R?y:id===T.RL?y-1:y-2;
  function hsHouseOf(id,x,y){const ry=roofRow(id,y);if(!map[ry])return null;let x0=x,x1=x;
    while(x0>0&&map[ry][x0-1]===T.R)x0--;while(x1<MW-1&&map[ry][x1+1]===T.R)x1++;return {x0,x1,ry};}
  const styleOf=(x0,ry)=>{const h=hash2(x0*7+3,ry*13+1)%10;return h<2?0:h<4?1:h<6?2:h<7?3:h<9?4:5;};   // t154u: an even mix of six roofs
  function roofTex(g,S,v,thatch){const [b,l,d]=S.roof;r(g,0,0,16,16,b);
    if(thatch){for(let x=0;x<16;x++){const k=hash2(x,v)%3;r(g,x,0,1,16,k===0?l:k===1?b:d);}for(let y=3;y<16;y+=5)r(g,0,y,16,1,d);}
    else for(let y=0;y<16;y+=4){r(g,0,y+3,16,1,d);const off=((y/4)+v)%2?0:4;for(let x=off;x<16;x+=8)r(g,x,y,1,3,d);r(g,0,y,16,1,l);}}
  function wallTex(g,S,v){
    switch(S.wall){
      case 'plaster':r(g,0,0,16,16,'#ecdfc2');r(g,0,0,16,1,'#f8f0dc');break;
      case 'stone':r(g,0,0,16,16,'#9a98a8');for(let y=0;y<16;y+=4){r(g,0,y+3,16,1,'#6a6878');const o=(y/4+v)%2?0:5;for(let x=o;x<16;x+=10)r(g,x,y,1,3,'#6a6878');r(g,0,y,16,1,'#b8b6c4');}break;
      case 'timber':r(g,0,0,16,16,'#f4ecdc');r(g,0,0,16,2,'#4a2c14');r(g,0,7,16,2,'#4a2c14');for(let i=0;i<7;i++){r(g,1+i,8-i,2,1,'#4a2c14');r(g,13-i,8-i,2,1,'#4a2c14');}break;
      case 'planks':r(g,0,0,16,16,'#9a6a3a');for(let y=0;y<16;y+=3){r(g,0,y+2,16,1,'#6a4224');r(g,0,y,16,1,'#b8844a');}r(g,(v*5)%14+1,4,1,1,'#4a2c14');break;
      case 'brick':r(g,0,0,16,16,'#a8503a');for(let y=0;y<16;y+=3){r(g,0,y+2,16,1,'#d8c8b0');const o=(y/3+v)%2?0:3;for(let x=o;x<16;x+=6)r(g,x,y,1,2,'#d8c8b0');}break;
    }
    r(g,0,0,2,16,'rgba(60,30,10,.55)');r(g,14,0,2,16,'rgba(60,30,10,.45)');r(g,0,14,16,2,'#7a7060');r(g,0,14,16,1,'#a89a80');}
  function windowOn(g,S,kind){
    r(g,3,3,10,8,O);r(g,4,4,8,6,'#7ab8e8');r(g,4,4,8,2,'#bfe0ff');r(g,7,4,2,6,'#5a3a1e');r(g,4,7,8,1,'#5a3a1e');
    if(kind===1){r(g,4,4,4,6,'#ffd870');r(g,8,4,4,6,'#ffe9a0');r(g,7,4,2,6,'#5a3a1e');}       // lit window
    if(S.box){r(g,2,11,12,3,'#6a3f1e');r(g,2,11,12,1,'#8a5a32');for(let i=0;i<5;i++){r(g,3+i*2,9+(i%2),2,2,i%2?'#f070a0':'#ffe14d');r(g,3+i*2,10+(i%2),1,1,'#3a7a3a');}}
    else{r(g,1,3,2,8,S.door);r(g,13,3,2,8,S.door);r(g,1,5,2,1,O);r(g,13,8,2,1,O);r(g,3,11,10,1,'#d8d0c0');}}
  const HC=new Map();
  function hsTile(id,x,y){
    if(inInn(x,y))return innTile(id,x,y);
    const h=hsHouseOf(id,x,y);if(!h||h.x1-h.x0<1)return null;const s=styleOf(h.x0,h.ry),S=HS[s];
    const Lend=x===h.x0,Rend=x===h.x1,mid=(h.x0+h.x1)>>1,chim=S.chim&&id===T.R&&x===(hash2(h.x0,h.ry)%2?h.x0+1:h.x1-1)&&x!==mid,v=x&1,win=id===T.H?((hash2(x,y)%3)===0?1:0):0;
    const key=s+'|'+id+'|'+(Lend?1:0)+(Rend?1:0)+'|'+(chim?1:0)+'|'+v+'|'+win;let c=HC.get(key);if(c)return c;
    c=makeSprite(16,16,g=>{
      if(id===T.R||id===T.RL){
        roofTex(g,S,v,S.n==='thatch');
        if(S.hip&&id===T.R){if(Lend){for(let i=0;i<16;i++)r(g,0,i,Math.max(0,6-Math.floor(i/2.6)),1,'#5a9a3a');r(g,Math.max(0,6-0),0,1,1,S.roof[2]);for(let i=0;i<16;i++)r(g,Math.max(0,6-Math.floor(i/2.6)),i,1,1,S.roof[2]);}
          if(Rend){for(let i=0;i<16;i++){const w=Math.max(0,6-Math.floor(i/2.6));r(g,16-w,i,w,1,'#5a9a3a');r(g,15-w,i,1,1,S.roof[2]);}}}
        else{if(Lend)r(g,0,0,2,16,S.roof[2]);if(Rend)r(g,14,0,2,16,S.roof[2]);}
        if(id===T.RL){r(g,0,12,16,4,S.fas);r(g,0,12,16,1,S.roof[2]);for(let xx=1;xx<16;xx+=4)r(g,xx,13,2,2,S.roof[0]);}
        if(chim){r(g,5,0,6,11,O);r(g,6,1,4,9,'#8a7a6a');for(let yy=2;yy<10;yy+=3)r(g,6,yy,4,1,'#6a5a4a');r(g,5,0,6,2,'#4a3a3a');r(g,6,0,4,1,'#2a2020');}
      }else{
        wallTex(g,S,v);
        if(id===T.H)windowOn(g,S,win);
        else{r(g,3,2,10,14,O);r(g,4,3,8,13,S.door);r(g,4,3,8,1,'rgba(255,255,255,.3)');r(g,7,3,2,13,'rgba(0,0,0,.25)');r(g,10,9,1,2,'#e0c050');r(g,5,2,6,1,O);
          if(S.n==='moss'||S.n==='plum')r(g,6,1,4,1,S.roof[0]);r(g,2,15,12,1,'#8d7a5c');}
      }
    });HC.set(key,c);return c;
  }
  for(const id of [T.R,T.RL,T.H,T.D]){const prev=XTILE_FN[id];XTILE_FN[id]=(x,y,t)=>hsTile(id,x,y)||(prev?prev(x,y,t):(TSPR[id][(x+y)%TSPR[id].length]||TSPR[id][0]));}
  var HOUSE_STYLE_OF=(x,y)=>{const id=map[y]&&map[y][x];const h=hsHouseOf(id,x,y);return h?HS[styleOf(h.x0,h.ry)].n:null;};
  window.__houseStyleOf=HOUSE_STYLE_OF;
}
