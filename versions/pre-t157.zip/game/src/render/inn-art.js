/* ---- the Oakvale Inn (the house at tiles 4..8 x 30..32, Innkeeper Rosa out front): its own look so it stands out from the plain red-roofed houses -
   BLACK shingle roof (t154u, Seth's favourite) with a gold ridge and trim, warm lit windows with shutters, a teal door, a porch of planks, a swinging hanging sign (mug + bed)
   and porch lanterns (real lantern tiles, so they glow at night). Pure art: the map, collision and tile ids are unchanged. ---- */
const INN={x0:4,y0:30,x1:8,y1:32,door:6};
const inInn=(x,y)=>x>=INN.x0&&x<=INN.x1&&y>=INN.y0&&y<=INN.y1;
const INN_CACHE=new Map();
function innTile(id,x,y){
  const key=id+'|'+(id===T.R?y:id===T.RL?'e':(id===T.H?(x===INN.x0||x===INN.x1?'w':'p'):'d'))+'|'+(x&1);
  let s=INN_CACHE.get(key);if(s)return s;
  s=makeSprite(16,16,g=>{
    const roof=(eave)=>{
      rect(g,0,0,16,16,'#26252c');
      for(let yy=0;yy<(eave?12:16);yy+=4){rect(g,0,yy+3,16,1,'#111015');const off=((yy/4)+(x&1))%2?0:4;for(let xx=off;xx<16;xx+=8)rect(g,xx,yy,1,3,'#1b1a20');rect(g,0,yy,16,1,'#45434e');
        for(let xx=off+1;xx<16;xx+=8)if(((xx>>3)+(yy>>2)+x)%3===0)rect(g,xx,yy+1,5,2,'#33313b');}
    };
    if(id===T.R){roof(false);if(y===INN.y0){rect(g,0,0,16,3,'#e0b43a');rect(g,0,0,16,1,'#fbe08a');rect(g,0,3,16,1,'#8a6a1c');}}
    else if(id===T.RL){roof(true);rect(g,0,12,16,4,'#0c0b10');rect(g,0,12,16,1,'#e0b43a');rect(g,0,15,16,1,'#0f2b3a');for(let xx=2;xx<16;xx+=4)rect(g,xx,13,2,2,'#2a2832');}
    else if(id===T.H){
      rect(g,0,0,16,16,'#f6e6c0');rect(g,0,0,2,16,'#6b4423');rect(g,14,0,2,16,'#6b4423');rect(g,0,0,16,2,'#6b4423');rect(g,0,14,16,2,'#7a7060');
      sprinkle(g,x*5+3,['#e8d6a8','#fff0cf'],8);
      if(x===INN.x0||x===INN.x1){   // warm lit windows with teal shutters
        rect(g,2,4,12,9,'#2e7d9a');rect(g,4,4,8,9,'#3a2410');rect(g,5,5,6,7,'#ffd870');rect(g,5,5,6,2,'#fff0a8');rect(g,8,5,1,7,'#7a4c22');rect(g,5,8,6,1,'#7a4c22');rect(g,2,4,2,9,'#58b4d0');rect(g,12,4,2,9,'#1f566d');}
      else {rect(g,3,9,10,4,'#6b4423');rect(g,3,9,10,1,'#8a5a2c');for(let xx=3;xx<13;xx+=2){rect(g,xx,7+((xx>>1)%2),2,2,['#ff6a8a','#ffe14d','#ff9a3d','#ff6a8a','#fff'][(xx>>1)%5]);}rect(g,4,8,8,1,'#58a845');}
    }
    else {   // the door: teal, arched, gold trim and knob, a warm light above it
      rect(g,0,0,16,16,'#f6e6c0');rect(g,0,0,2,16,'#6b4423');rect(g,14,0,2,16,'#6b4423');rect(g,0,0,16,2,'#6b4423');
      rect(g,2,2,12,14,'#e0b43a');rect(g,3,3,10,13,'#173f52');rect(g,4,4,8,12,'#2e7d9a');rect(g,4,4,3,12,'#3e93b0');rect(g,9,4,3,12,'#25677f');rect(g,7,4,1,12,'#173f52');
      rect(g,5,5,2,3,'#ffd870');rect(g,9,5,2,3,'#ffd870');rect(g,10,10,2,2,'#f0d060');rect(g,4,4,8,1,'#58b4d0');}
  });
  INN_CACHE.set(key,s);return s;
}
/* the plank porch in front of the door (ground layer, under everyone's feet) */
function drawInnPorch(cx,cy){
  const x0=(INN.door-1)*TS-cx,y0=(INN.y1+1)*TS-cy;
  if(x0>VW+TS||x0<-4*TS||y0>VH+TS||y0<-2*TS)return;
  ctx.fillStyle='#8a5a30';ctx.fillRect(x0,y0,3*TS,TS-6);
  for(let i=0;i<3*TS;i+=8){ctx.fillStyle=(i/8)%2?'#a87240':'#9a6a38';ctx.fillRect(x0+i,y0,7,TS-6);ctx.fillStyle='#5a3a1c';ctx.fillRect(x0+i+7,y0,1,TS-6);}
  ctx.fillStyle='#c89458';ctx.fillRect(x0,y0,3*TS,2);ctx.fillStyle='#4a2c14';ctx.fillRect(x0,y0+TS-8,3*TS,2);
  ctx.fillStyle='#173f52';ctx.fillRect(x0+TS+4,y0+6,TS-8,TS-16);ctx.fillStyle='#e0b43a';ctx.fillRect(x0+TS+4,y0+6,TS-8,2);   // a teal doormat with a gold edge
}
/* the hanging sign: an iron bracket on the wall left of the door, a swinging board with a mug and a bed */
function drawInnSign(cx,cy){
  const bx=(INN.door-1)*TS-cx+2,by=INN.y1*TS-cy+4;
  if(bx>VW+TS||bx<-2*TS||by>VH+TS||by<-2*TS)return;
  const u=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(ox+x*2),Math.round(oy+y*2),w*2,h*2);};
  const sw=Math.sin(gtime*1.7)*1.4,ox=bx+sw+3,oy=by+10;
  ctx.fillStyle='#2a2a30';ctx.fillRect(bx-2,by-1,32,3);ctx.fillRect(bx+26,by-1,4,6);ctx.fillStyle='#e0b43a';ctx.fillRect(bx+28,by+2,3,3);   // bracket + curl
  ctx.fillStyle='#2a2a30';ctx.fillRect(bx+4+sw*.5,by+2,1,9);ctx.fillRect(bx+22+sw*.5,by+2,1,9);   // chains
  u(0,0,12,10,'#3a2410');u(1,1,10,8,'#e8bd6a');u(1,1,10,1,'#f6d890');u(1,8,10,1,'#b88a40');
  u(2,3,3,4,'#f0c040');u(2,2,3,1,'#fff');u(5,3,1,3,'#b88a40');u(2,6,3,1,'#b88a40');   // mug with foam + handle
  u(7,3,1,5,'#6b4423');u(7,5,4,2,'#d9e6f2');u(8,4,2,1,'#fff');u(8,5,3,1,'#c0392b');u(10,5,1,2,'#c0392b');u(10,7,1,1,'#6b4423');   // bed: headboard, sheets, pillow, blanket
}
