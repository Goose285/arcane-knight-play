/* =====================================================================
   FISHING DATA: fish, rods, levels. Catches sell for gold, can be cooked & eaten to heal, and drop Silver Scales for crafting.
   ===================================================================== */
const FISH_MAX_LV=70;   // t148u: fishing is its own skill, capped at 70
const fishNeed=l=>Math.round(28+10*(l-1)+.12*(l-1)*(l-1));   // t148u: gentle early, steeper later toward 70
const FISHES=[
  {id:'minnow',n:'Silverscale Minnow',tier:0,lv:1,w:10,price:6,  heal:.06,xp:6, dif:.8, rar:0,col:'#cfe3ff'},
  {id:'carp',  n:'Mudfin Carp',       tier:0,lv:1,w:8, price:11, heal:.10,xp:9, dif:1.0,rar:0,col:'#b08a5a'},
  {id:'trout', n:'Riverbell Trout',   tier:0,lv:2,w:4, price:22, heal:.14,xp:14,dif:1.15,rar:1,col:'#e8a8c8'},
  {id:'pike',  n:'Greenwood Pike',    tier:1,lv:3,w:8, price:34, heal:.20,xp:20,dif:1.3, rar:1,col:'#7ac060'},
  {id:'bass',  n:'Moonpetal Bass',    tier:1,lv:4,w:4, price:52, heal:.26,xp:28,dif:1.45,rar:2,col:'#c8b8ff'},
  {id:'eel',   n:'Bog Lurker Eel',    tier:2,lv:5,w:8, price:70, heal:.30,xp:36,dif:1.6, rar:2,col:'#8aa860'},
  {id:'gill',  n:'Glowgill',          tier:2,lv:6,w:4, price:105,heal:.36,xp:48,dif:1.75,rar:3,col:'#7dffd0'},
  {id:'perch', n:'Sunscale Perch',    tier:3,lv:7,w:8, price:130,heal:.42,xp:60,dif:1.9, rar:3,col:'#ffd23f'},
  {id:'koi',   n:'Mirage Koi',        tier:3,lv:8,w:3, price:210,heal:.55,xp:90,dif:2.1, rar:4,col:'#ff8a5a'},
  {id:'salmon',n:'Dawn Salmon',       tier:3,lv:12,w:5,price:160,heal:.45,xp:70,dif:2.0, rar:3,col:'#ff9a7a'},
  {id:'catfish',n:'Whisker Catfish',  tier:3,lv:18,w:6,price:190,heal:.48,xp:85,dif:2.15,rar:3,col:'#8a7a5a'},
  {id:'sturgeon',n:'Ironjaw Sturgeon',tier:4,lv:28,w:3,price:320,heal:.6,xp:120,dif:2.3, rar:4,col:'#b0c0d0'},
  {id:'goldfin',n:'Royal Goldfin',    tier:4,lv:40,w:2,price:480,heal:.7,xp:160,dif:2.5, rar:4,col:'#ffd23f'},
  {id:'levi',  n:'Leviathan Fry',     tier:4,lv:55,w:1,price:900,heal:.85,xp:260,dif:2.8, rar:4,col:'#7df9ff'},
  {id:'myth',  n:'Mythfin',           tier:4,lv:68,w:1,price:1400,heal:1,xp:400,dif:3.0, rar:4,col:'#ffe14d'},
  // t154u: fourteen new catches (todOnly = only bites at that time of day)
  {id:'shiner', n:'Brook Shiner',      tier:0,lv:1,w:7, price:8,  heal:.07,xp:7, dif:.85,rar:0,col:'#e0ecf4'},
  {id:'sunny',  n:'Pumpkinseed Sunny', tier:0,lv:2,w:6, price:14, heal:.10,xp:10,dif:1.0,rar:0,col:'#ffa64a'},
  {id:'chub',   n:'Mossback Chub',     tier:1,lv:3,w:6, price:28, heal:.16,xp:17,dif:1.2,rar:1,col:'#6a8a4a'},
  {id:'dawnchar',n:'Dawnlight Char',   tier:1,lv:5,w:3, price:85, heal:.3, xp:40,dif:1.6,rar:3,col:'#ffc0a0',tod:'dawn',todOnly:true},
  {id:'mudskip',n:'Mire Mudskipper',   tier:2,lv:6,w:6, price:60, heal:.26,xp:32,dif:1.5,rar:2,col:'#8a7040'},
  {id:'lantern',n:'Lanternfish',       tier:2,lv:8,w:4, price:120,heal:.34,xp:52,dif:1.8,rar:3,col:'#9affe0',tod:'night',todOnly:true},
  {id:'ghostcarp',n:'Ghost Carp',      tier:2,lv:10,w:2,price:160,heal:.4,xp:66,dif:1.95,rar:3,col:'#e8f0ff',tod:'night',todOnly:true},
  {id:'emberkoi',n:'Ember Koi',        tier:3,lv:11,w:3,price:200,heal:.45,xp:80,dif:2.05,rar:3,col:'#ff6a3a',tod:'dusk',todOnly:true},
  {id:'frostpike',n:'Frostjaw Pike',   tier:3,lv:14,w:4,price:175,heal:.44,xp:76,dif:2.0,rar:3,col:'#a8d8ff'},
  {id:'thunder',n:'Thunderscale Bass', tier:3,lv:22,w:3,price:240,heal:.5,xp:98,dif:2.2,rar:3,col:'#ffe870'},
  {id:'starray',n:'Starlit Ray',       tier:4,lv:32,w:2,price:380,heal:.62,xp:140,dif:2.4,rar:4,col:'#b8a8ff',tod:'night',todOnly:true},
  {id:'crownfish',n:'Crowned Sunfish', tier:4,lv:45,w:2,price:520,heal:.72,xp:175,dif:2.55,rar:4,col:'#ffd870',tod:'dawn',todOnly:true},
  {id:'abyss',  n:'Abyssal Angler',    tier:4,lv:50,w:1,price:700,heal:.8,xp:220,dif:2.7,rar:4,col:'#5a7aff',tod:'dusk',todOnly:true},
  {id:'serpent',n:'Elder Lake Serpent',tier:4,lv:62,w:1,price:1100,heal:.95,xp:330,dif:2.9,rar:4,col:'#5affb0'},
];
const FISH_RARITY=[{n:'Common',col:'#cfd6e6'},{n:'Uncommon',col:'#7dff8a'},{n:'Rare',col:'#6ab8ff'},{n:'Epic',col:'#c58aff'},{n:'Legendary',col:'#ffb43a'}];
const FISH_JUNK=[
  {id:'boot', n:'Old Boot',  price:1, col:'#7a5a3a',junk:true,heal:0,xp:0},
  {id:'pearl',n:'Moon Pearl',price:75,col:'#f4f0ff',junk:true,heal:0,xp:0},
];
const FISH_BY={};FISHES.concat(FISH_JUNK).forEach(f=>{FISH_BY[f.id]=f;});
/* rods: bite = seconds you have to answer a Rare bite, waitMul = shorter gaps between catches, luck = better odds for rare fish (and rarer bites sooner) */
const RODS=[
  {id:'wood',n:'WOODEN ROD',    price:25, bite:4,waitMul:1,  luck:0,  col:'#c08a52',desc:'A plain pole - fine for the river.'},
  {id:'bog', n:'BOGWOOD ROD',   price:150,bite:4.4,waitMul:.88, luck:.15,col:'#9ad03a',desc:'Springy: fish bite a little sooner, better odds at rare ones.'},
  {id:'star',n:'STARLIGHT ROD', price:480,bite:4.8,waitMul:.76, luck:.35,col:'#9fd8ff',desc:'Silver-strung: quickest bites, rare fish love it, longer rare-bite window.'},
];
MATS.fscale={n:'Silver Scale',col:'#cfe6ff'};
RECIPES.push({id:'r_angler',name:"Angler's Band",slot:'ring',rar:'rare',mats:{fscale:5,shard:2},gold:110});
