/* =====================================================================
   M12 DATA: daily challenge kinds, 7-day login chest, weekly crypt boons, achievements. (logic: player/daily.js, weekly.js, achievements.js)
   ===================================================================== */
// each reward: {g:gold, mat:{id:n}, card:'rarity', gear:'rarity'}
const LOGIN_REWARDS=[
  {n:'Day 1',g:80},
  {n:'Day 2',mat:{gel:3,bone:2}},
  {n:'Day 3',g:150},
  {n:'Day 4',card:'uncommon'},
  {n:'Day 5',g:220,mat:{shard:2}},
  {n:'Day 6',gear:'uncommon'},
  {n:'Day 7 - GRAND CHEST',g:400,card:'rare',gear:'rare'},
];
const DAILY_BONUS={g:200,card:'uncommon',mat:{shard:3}};
// challenge templates: {k,txt(n,t),min,max,gold,type?}
const DAILY_KINDS=[
  {k:'kills',   txt:n=>`Defeat ${n} monsters`,                 min:8, max:16,gold:60},
  {k:'type',    txt:(n,t)=>`Defeat ${n} ${DAILY_TYPES[t]}`,     min:3, max:6, gold:70},
  {k:'cards',   txt:n=>`Cast ${n} cards in battle`,             min:15,max:30,gold:60},
  {k:'gold',    txt:n=>`Earn ${n} gold from monsters`,          min:150,max:320,gold:80},
  {k:'elite',   txt:n=>`Defeat ${n} elite monster${n>1?'s':''}`,min:1, max:2, gold:130,minLv:4},
  {k:'arena',   txt:n=>`Clear ${n} Ember Arena round${n>1?'s':''}`,min:1,max:2,gold:140,minLv:12},
];
const DAILY_TYPES={slime:'slimes',goblin:'goblin archers',knight:'skeleton knights'};
/* ---- weekly seeded crypt: 7 floors, a boon between floors ---- */
const WEEKLY_CFG={floors:7,pool:['slime','goblin','knight','bat','wraith','scorpion'],boss:['dragon','rimegar','lich','mossback','colossus'],keep:8,
  reward:{g:450,card:'epic',mat:{shard:4,dust:2}}};
const BOONS=[
  {id:'fury',  n:'Fury',      d:'+18% damage dealt',            dmg:.18},
  {id:'ward',  n:'Iron Ward', d:'-15% damage taken',            def:.15},
  {id:'vigor', n:'Vigor',     d:'+25 max HP, heal 25 now',      hp:25},
  {id:'feast', n:'Soul Feast',d:'Heal 12% max HP after each floor',feast:.12},
  {id:'fortune',n:'Fortune',  d:'+25% score',                   score:.25},
  {id:'rage',  n:'Hollow Rage',d:'+30% damage, -10% max HP',    dmg:.3,hpPct:-.1},
  {id:'bulwark',n:'Bulwark',  d:'-25% damage taken, -10% damage dealt',def:.25,dmg:-.1},
  {id:'ember', n:'Ember Heart',d:'+12% damage, +12 max HP',     dmg:.12,hp:12},
];
const WEEKLY_NAMES=['Ashen','Gloam','Cinder','Hollow','Rime','Briar','Dusk','Umber','Pale','Vesper'],WEEKLY_NAMES2=['Vault','Catacomb','Descent','Ossuary','Labyrinth','Barrow','Warren','Depths'];
/* ---- achievements: {id,n,d,gold,t:()=>bool, p?:()=>[cur,max]} ---- */
const ACHS=[
  {id:'blood',  n:'First Blood',     d:'Defeat a monster',                 gold:25, p:()=>[kills,1]},
  {id:'hunter', n:'Monster Hunter',  d:'Defeat 100 monsters',              gold:100,p:()=>[kills,100]},
  {id:'slayer', n:'Realm Slayer',    d:'Defeat 500 monsters',              gold:300,p:()=>[kills,500]},
  {id:'lv5',    n:'Squire',          d:'Reach level 5',                    gold:40, p:()=>[P.lv,5]},
  {id:'lv10',   n:'Knight',          d:'Reach level 10',                   gold:120,p:()=>[P.lv,10]},
  {id:'lv20',   n:'Arcane Knight',   d:'Reach level 20',                   gold:400,p:()=>[P.lv,20]},
  {id:'drake',  n:'Dragon Slayer',   d:'Defeat Emberfang',                 gold:150,t:()=>bossDown},
  {id:'lich',   n:'Crown Breaker',   d:'Defeat the Lich King',             gold:250,t:()=>lichDown},
  {id:'cards',  n:'Card Collector',  d:'Own 12 different cards',           gold:120,p:()=>[Object.keys(COL).length,12]},
  {id:'smith',  n:'Apprentice Smith',d:'Craft 3 pieces of gear',           gold:100,p:()=>[ACH.s.crafts,3]},
  {id:'upg',    n:'Spell Tuner',     d:'Upgrade cards 3 times',            gold:100,p:()=>[Object.values(CR.upg).reduce((a,b)=>a+b,0),3]},
  {id:'legend', n:'Legendary Find',  d:'Own a legendary item',             gold:200,t:()=>[...GEAR.inv,...Object.values(GEAR.eq)].some(i=>i&&i.rar==='legendary')},
  {id:'pal',    n:'Best Friend',     d:'Adopt a pet',                      gold:60, t:()=>Object.keys(PET.owned).length>=1},
  {id:'zoo',    n:'Menagerie',       d:'Adopt all four pets',              gold:250,p:()=>[Object.keys(PET.owned).length,4]},
  {id:'decor',  n:'Trophy Hunter',   d:'Earn 4 trophies',                  gold:150,p:()=>[trophyCount(),4]},
  {id:'elite',  n:'Elite Hunter',    d:'Defeat 10 elite monsters',         gold:150,p:()=>[HOUSE.elites,10]},
  {id:'ways',   n:'Wayfarer',        d:'Attune 4 waystones',               gold:120,p:()=>[Object.keys(SEC.ways).length,4]},
  {id:'secret', n:'Secret Seeker',   d:'Find 3 secrets',                   gold:150,p:()=>[Object.keys(SEC.opened).length+Object.keys(SEC.broken).length+Object.keys(SEC.dug).length,3]},
  {id:'story',  n:'Chronicler',      d:'Finish the Hollow Crown story',    gold:300,p:()=>[STORY.ch,5]},
  {id:'arena3', n:'Arena Challenger',d:'Clear 3 arena rounds in one run',  gold:150,p:()=>[ACH.s.rushBest,3]},
  {id:'arena5', n:'Arena Champion',  d:'Clear 5 arena rounds in one run',  gold:300,p:()=>[ACH.s.rushBest,5]},
  {id:'daily3', n:'Daily Grind',     d:'Complete 3 daily challenges',      gold:100,p:()=>[DAILY.total,3]},
  {id:'streak', n:'Week of Embers',  d:'Reach a 7-day login streak',       gold:300,p:()=>[ACH.s.streakBest,7]},
  {id:'crypt3', n:'Crypt Wanderer',  d:'Reach floor 3 of a weekly crypt',  gold:100,p:()=>[ACH.s.bestFloor,3]},
  {id:'fish1',  n:'First Catch',     d:'Catch a fish',                     gold:30, p:()=>[ACH.s.fish,1]},
  {id:'fish25', n:'Seasoned Angler', d:'Catch 25 fish',                    gold:150,p:()=>[ACH.s.fish,25]},
  {id:'fishlv', n:'Master Angler',   d:'Reach Fishing level 8',            gold:250,p:()=>[fishLv(),8]},
  {id:'fish1000',n:'Legend of the Lake',d:'Catch 1000 fish',                 gold:1500,p:()=>[ACH.s.fish,1000]},   // t154u
  {id:'boots25', n:'Boot Collector',  d:'Fish up 25 Old Boots',              gold:250,p:()=>[ACH.s.boots|0,25]},   // t154u
  {id:'spw1',   n:'Spawner Smasher', d:'Destroy a monster spawner',        gold:100,p:()=>[ACH.s.spw,1]},
  {id:'spw5',   n:'Brazier Breaker', d:'Destroy 5 monster spawners',       gold:300,p:()=>[ACH.s.spw,5]},
  {id:'bless',  n:'Blessed Traveler',d:'Receive a blessing at the chapel', gold:40, p:()=>[ACH.s.bless,1]},
  {id:'crypt7', n:'Crypt Delver',    d:'Conquer all 7 weekly crypt floors',gold:400,p:()=>[ACH.s.bestFloor,7]},
];
