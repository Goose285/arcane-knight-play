
/* =====================================================================
   GAME STATE
   ===================================================================== */
const P={x:SPAWN.x,y:SPAWN.y,dir:'d',aim:Math.PI/2,anim:0,moving:false,hp:80,lv:1,xp:0,gold:0,up:0,grace:0,regen:0};
SP.heroBL=flipH(SP.heroB[0]);
const blackCache=new Map();
const tintCache=new Map();
function tintOf(c,col){const k=col;let m=tintCache.get(c);if(!m){m={};tintCache.set(c,m);}if(!m[k])m[k]=makeSprite(c.width,c.height,g=>{g.drawImage(c,0,0);g.globalCompositeOperation='source-atop';g.fillStyle=col;g.fillRect(0,0,c.width,c.height);});return m[k];}
function blackOf(c){let w=blackCache.get(c);if(!w){w=makeSprite(c.width,c.height,g=>{g.drawImage(c,0,0);g.globalCompositeOperation='source-atop';g.fillStyle='#000';g.fillRect(0,0,c.width,c.height);});blackCache.set(c,w);}return w;}
const maxHp=()=>80+15*(P.lv-1)+gearStats().hp+storyHp()+boonHp();
const xpNeedOld=l=>40+(l-1)*35;   // (pre-t154u curve, kept for tests)
const xpNeedAt=l=>Math.round(40+(l-1)*35+3.5*Math.pow(Math.max(0,l-1),1.9));   // t154u: steeper mid/late game; the first few levels barely change
const xpNeed=()=>xpNeedAt(P.lv);
const arcaneDmg=()=>6+(P.lv-1)+P.up*2+gearStats().shot;
const cardMult=()=>1+0.08*(P.lv-1)+P.up*0.05+gearStats().shot*0.01;
let state='title';      // title | play | paused
let gtime=0;
const cam={x:0,y:0};
const toasts=[];
function toast(s,dur=2.6,col='#fff'){if(toasts.some(t=>t.s===s))return;toasts.push({s,t:0,dur,col});while(toasts.length>6)toasts.splice(1,1);}   // ONE queue: only the first shows; the rest wait their turn
let areaT=0,areaCur='',bossDown=false,lichDown=false,kills=0;
let B=null;             // active real-time combat (null = exploring)
const joy={on:false,x:0,y:0,id:null,bx:0,by:0,kx:0,ky:0};
