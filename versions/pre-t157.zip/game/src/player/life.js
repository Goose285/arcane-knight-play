/* =====================================================================
   LIFE (t135u): the world goes on without you.
   - SLIMES EAT FLOWERS: a wandering slime spots a flower tile nearby, hops over and munches it (the flower regrows after a while).
   - BEASTS DRINK: boars and wolves wander to water now and then and lap at it. Every wild monster keeps away from campfires.
   - VILLAGERS CHAT in pairs with speech bubbles; Old Tom sits on the bench by the fountain; Gardener Lyn waters the flowers.
   - FOG rolls into Whisperwood at random times (a soft drifting overlay while you are in the forest).
   - PET PEN: pets potter about the paddock; owned pets give a small PERK.
   - DUNGEONS: monsters killed inside a dungeon stay down while you are inside (no respawn timers); all of them are back when you
     leave and come in again.
   ===================================================================== */
const LIFE={regrow:[],chat:null,chatT:6,bub:[],lastZone:null,munch:[]};
/* ---- dungeon respawn rule ---- */
const DUNGEON_ZONES=new Set(['crypt','snow','swamp','desert']);
const enemyZone=e=>zoneOfTy(Math.floor(e.hy/TS));
function dungeonHold(e){const z=enemyZone(e);return DUNGEON_ZONES.has(z)&&zoneOfPx(P.y)===z;}
function lifeZoneTick(){
  const z=zoneOfPx(P.y);if(z===LIFE.lastZone)return;const prev=LIFE.lastZone;LIFE.lastZone=z;
  if(prev!=null&&DUNGEON_ZONES.has(z))for(const e of enemies){if(e.alive||e.night||e.spw||e.tmp||e.edDel||e.rush||enemyZone(e)!==z)continue;   // re-entering: everyone is back
    if(!e.def.boss&&!window.__NOELITE){eliteRoll(e);applyLevel(e,e.lv);}e.alive=true;e.respawn=0;resetEnemyState(e);}
}
/* ---- slimes + beasts + fire ---- */
const FLOWER_REGROW=[70,140];
function lifeEnemy(e,dt){
  if(e.ret){lifeReturn(e,dt);return;}
  if(e.engaged||e.def.boss)return;
  e.lifeCd=(e.lifeCd==null?R(2,8):e.lifeCd)-dt;
  const tx=Math.floor(e.x/TS),ty=Math.floor((e.y-6)/TS);
  // campfires: turn away
  for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){const t=map[ty+dy]&&map[ty+dy][tx+dx];if(t===T.FR){e.fa=Math.atan2(-dy,-dx);e.mode='walk';e.mt=.8;e.food=null;return;}}
  if(e.food){const f=e.food,fx=(f.x+.5)*TS,fy=(f.y+.6)*TS,d=Math.hypot(fx-e.x,fy-e.y);
    e.fa=Math.atan2(fy-e.y,fx-e.x);e.mode='walk';e.mt=.4;f.t+=dt;
    if(d<14||f.t>8){if(f.kind==='eat'&&map[f.y][f.x]===T.L){map[f.y][f.x]=T.G;LIFE.regrow.push({x:f.x,y:f.y,t:R(...FLOWER_REGROW)});LIFE.munch.push({x:fx,y:fy-10,t:0,s:'munch!'});
        for(let i=0;i<6;i++)LIFE.munch.push({x:fx,y:fy-6,vx:R(-30,30),vy:R(-40,-10),t:0,p:1,col:i%2?'#f070a0':'#5ea83a'});e.bob+=3;e.ate=(e.ate||0)+1;}
      else if(f.kind==='drink')LIFE.munch.push({x:fx,y:fy-12,t:0,s:'~ ~'});
      e.food=null;e.mode='look';e.mt=R(1.5,3);e.lifeCd=R(10,22);}
    return;}
  if(e.lifeCd>0||e.mode!=='look')return;e.lifeCd=R(4,9);
  const want=e.type==='slime'?'eat':(e.type==='boar'||e.type==='wolf'||e.type==='bboar')?'drink':null;if(!want)return;
  const tile=want==='eat'?T.L:T.W;let best=null,bd=1e9;
  for(let dy=-4;dy<=4;dy++)for(let dx=-4;dx<=4;dx++){const x=tx+dx,y=ty+dy;if(!map[y]||map[y][x]!==tile)continue;
    if(inTownPx(x*TS+16,y*TS+16))continue;let gx=x,gy=y;if(want==='drink'){const s=[[1,0],[-1,0],[0,1],[0,-1]].map(([a,b])=>[x+a,y+b]).find(([a,b])=>!solidTile(a,b));if(!s)continue;[gx,gy]=s;}
    const d=Math.abs(dx)+Math.abs(dy);if(d<bd){bd=d;best={x:gx,y:gy,kind:want,t:0};if(want==='eat'){best.x=x;best.y=y;}}}
  if(best)e.food=best;
}
/* ---- villagers ---- */
const CHAT_LINES=[["Lovely weather today!","Perfect for the fields."],["Did you hear? Slimes ate my tulips again!","They do love flowers..."],["The fog is back in Whisperwood.","Stay on the road, then."],
  ["Brum's new blades are sharp!","He never sleeps, that one."],["Have you seen the new church?","The windows are beautiful!"],["My cat ran off to the pet pen.","Marlo will look after it."],
  ["The bread smells wonderful.","Wren is up before dawn."],["Strange lights in the east...","Mushrooms, they say. Walking ones!"]];
const chatOk=n=>!n.sign135&&!n.way&&!n.house&&!n.tguard&&n.spr!=='houseSign'&&n.spr!=='waystone'&&n.x>0&&!n.board&&!n.rush;
function lifeNpcs(dt){
  // speech bubbles
  for(const b of LIFE.bub)b.t+=dt;LIFE.bub=LIFE.bub.filter(b=>b.t<b.dur);
  LIFE.chatT-=dt;
  if(LIFE.chatT<=0){LIFE.chatT=R(7,13);
    const near=NPCS.filter(chatOk).filter(n=>Math.abs(n.x-P.x)<VW&&Math.abs(n.y-P.y)<VH);
    const pairs=[];for(let i=0;i<near.length;i++)for(let j=i+1;j<near.length;j++)if(Math.hypot(near[i].x-near[j].x,near[i].y-near[j].y)<5*TS)pairs.push([near[i],near[j]]);
    if(pairs.length){const [a,b]=pairs[RI(0,pairs.length-1)],l=CHAT_LINES[RI(0,CHAT_LINES.length-1)];LIFE.chat={a,b};
      LIFE.bub.push({n:a,s:l[0],t:0,dur:3.2});LIFE.bub.push({n:b,s:l[1],t:-1.8,dur:3.2-(-1.8)});}}
  // Gardener Lyn waters the flowers (walks between her beds), Old Tom sits on the bench
  for(const n of NPCS){
    if(n.garden){const g=n.garden;g.t-=dt;const tg=g.spots[g.i];const dx=tg[0]-n.x,dy=tg[1]-n.y,d=Math.hypot(dx,dy);
      if(d>2){const s=30*dt;n.x+=dx/d*Math.min(s,d);n.y+=dy/d*Math.min(s,d);n.watering=0;}
      else{n.watering=(n.watering||0)+dt;if(n.watering>3.5){g.i=(g.i+1)%g.spots.length;n.watering=0;}}}
  }
}
/* ---- regrowth ---- */
function lifeRegrow(dt){for(const r of LIFE.regrow)r.t-=dt;for(const r of LIFE.regrow)if(r.t<=0&&map[r.y][r.x]===T.G)map[r.y][r.x]=T.L;LIFE.regrow=LIFE.regrow.filter(r=>r.t>0);}
/* ---- fog ---- */
const FOG={a:0,target:0,next:R(40,150),blobs:[],REGION:'WHISPERWOOD'};
const fogHere=()=>zoneOfPx(P.y)==='ow'&&regions.forest(Math.floor(P.x/TS),Math.floor(P.y/TS));
function lifeFog(dt){
  FOG.next-=dt;if(FOG.next<=0){if(FOG.target>0){FOG.target=0;FOG.next=R(70,200);}else{FOG.target=.6;FOG.next=R(40,100);if(fogHere())toast('A thick fog rolls into Whisperwood...',2.6,'#cfd8e0');}}
  const want=fogHere()?FOG.target:0;FOG.a+=(want-FOG.a)*Math.min(1,dt*.5);
  if(!FOG.blobs.length)for(let i=0;i<14;i++)FOG.blobs.push({x:Math.random(),y:Math.random(),r:R(.18,.4),v:R(.004,.015)});
  for(const b of FOG.blobs){b.x+=b.v*dt;if(b.x>1.3)b.x=-.3;}
}
/* t143u: real drifting fog - soft layered wisps anchored to the world (parallax, three depths) over a light haze; no darkening */
let FOG_SPR=null;
function fogSprites(){if(FOG_SPR)return FOG_SPR;const rnd=mulberry32(4711);FOG_SPR=[];
  for(let k=0;k<4;k++){const c=document.createElement('canvas');c.width=320;c.height=110;const g=c.getContext('2d');
    for(let i=0;i<26;i++){const x=40+rnd()*240,y=30+rnd()*50+Math.sin(x/50+k)*10,r=18+rnd()*36;const gr=g.createRadialGradient(x,y,0,x,y,r);
      gr.addColorStop(0,'rgba(236,240,246,.30)');gr.addColorStop(.6,'rgba(230,236,244,.12)');gr.addColorStop(1,'rgba(230,236,244,0)');g.fillStyle=gr;g.beginPath();g.ellipse(x,y,r*1.6,r*.7,0,0,6.283);g.fill();}
    FOG_SPR.push(c);}
  return FOG_SPR;}
function drawFog(){
  if(FOG.a<.02)return;const a=FOG.a,S=fogSprites();ctx.save();
  ctx.fillStyle=`rgba(226,232,238,${a*.08})`;ctx.fillRect(0,0,VW,VH);                         // light haze (brightens a touch, never darkens)
  const layers=[[.55,.9,.55,9],[.8,1.25,.75,16],[1.1,1.7,.9,26]];
  layers.forEach(([par,sc,al,spd],li)=>{const w=320*sc,h=110*sc,ox=-(cam.x*par)+gtime*spd,oy=-(cam.y*par);
    ctx.globalAlpha=Math.min(1,a*al*.75);
    const W=w*.8,H=h*.7,bx=((ox%W)+W)%W-W,by=((oy%H)+H)%H-H;
    for(let gy=0;gy<=Math.ceil(VH/H)+1;gy++)for(let gx=0;gx<=Math.ceil(VW/W)+1;gx++){
      const sx=bx+gx*W+(gy%2)*W*.4,sy=by+gy*H+Math.sin(gtime*.3+gx+li)*6;ctx.drawImage(S[(gx*7+gy*3+li)%4],Math.round(sx-w*.1),Math.round(sy),Math.round(w),Math.round(h));}
  });
  ctx.restore();ctx.globalAlpha=1;
}
/* ---- pet pen + perks ---- */
const PET_PERK={cinder:{k:'dmg',v:1.05,t:'+5% damage'},wisp:{k:'spd',v:1.06,t:'+6% move speed'},moth:{k:'regen',v:1,t:'regenerate HP outside fights'},pebblin:{k:'def',v:.92,t:'take 8% less damage'}};
for(const id in PET_PERK)if(PETS[id]&&!/Perk:/.test(PETS[id].desc))PETS[id].desc+='. Perk: '+PET_PERK[id].t;
const petPerk=k=>{const p=PET.active&&PET_PERK[PET.active];return p&&p.k===k?p.v:1;};
let regenT=0;
function lifePets(dt){
  if(PET.active==='moth'&&!B&&state==='play'&&P.hp<maxHp()){regenT+=dt;if(regenT>3){regenT=0;P.hp=Math.min(maxHp(),P.hp+1);}}
  if(!PEN.on)return;const x0=(PEN.x0+1.3)*TS,x1=(PEN.x1-.3)*TS,y0=(PEN.y0+1.6)*TS,y1=(PEN.y1-.1)*TS;
  for(const p of PEN.pets){p.wt-=dt;if(p.wt<=0){p.wt=R(1.5,4);p.tx=R(x0,x1);p.ty=R(y0,y1);}if(p.tx){const dx=p.tx-p.x,dy=p.ty-p.y,d=Math.hypot(dx,dy);if(d>2){p.x+=dx/d*22*dt;p.y+=dy/d*22*dt;p.face=dx<0?-1:1;}}p.x=clamp(p.x,x0,x1);p.y=clamp(p.y,y0,y1);}   // t154u: pen pets never stray out of the paddock
}
const benchSpr=makeSprite(20,10,g=>{rect(g,0,2,20,3,'#8a5a32');rect(g,0,2,20,1,'#b07a48');rect(g,2,5,2,5,'#5a3a1e');rect(g,16,5,2,5,'#5a3a1e');rect(g,0,0,20,2,'#6e4626');});
function drawBench(n){draw(benchSpr,Math.round(n.x-cam.x-20),Math.round(n.y-cam.y-14),2);}
function penPetsVisible(){return PEN.on?PEN.pets.filter(p=>p.id!==PET.active):[];}
function drawPenPet(p){const spr=SP.pets&&SP.pets[p.id];if(!spr)return;const w=spr.width*1.5,h=spr.height*1.5,x=Math.round(p.x-cam.x-w/2),y=Math.round(p.y-cam.y-h+Math.sin(gtime*6+p.x)*1);
  drawEntShadow(p.x,p.y,7);if(p.face<0){ctx.save();ctx.translate(x+w,y);ctx.scale(-1,1);ctx.drawImage(spr,0,0,w,h);ctx.restore();}else ctx.drawImage(spr,x,y,w,h);
  if(!PET.owned[p.id]&&Math.hypot(P.x-p.x,P.y-p.y)<90)txt(PETS[p.id].price+' G',p.x-cam.x,y-4,{size:8,align:'center',col:'#ffe27a',lw:2});}
/* ---- update + overlay ---- */
function updateLife(dt){
  if(state!=='play'&&state!=='paused')return;if(state==='paused')return;
  lifeZoneTick();lifeRegrow(dt);lifeNpcs(dt);lifeFog(dt);lifePets(dt);
  for(const m of LIFE.munch){m.t+=dt;if(m.p){m.x+=m.vx*dt;m.y+=m.vy*dt;m.vy+=120*dt;}else m.y-=10*dt;}LIFE.munch=LIFE.munch.filter(m=>m.t<(m.p?.6:1.1));
}
function drawLifeOverlay(){
  for(const m of LIFE.munch){const a=1-m.t/(m.p?.6:1.1);ctx.globalAlpha=Math.max(0,a);if(m.p){ctx.fillStyle=m.col;ctx.fillRect(m.x-cam.x,m.y-cam.y,2,2);}else txt(m.s,m.x-cam.x,m.y-cam.y,{size:9,align:'center',col:'#fff3d0',lw:2});}ctx.globalAlpha=1;
  for(const n of NPCS)if(n.watering>0){const x=n.x-cam.x+10,y=n.y-cam.y-14;ctx.fillStyle='#8a8a9a';ctx.fillRect(x,y,6,4);for(let i=0;i<3;i++){const k=((gtime*2+i/3)%1);ctx.fillStyle=`rgba(120,190,255,${1-k})`;ctx.fillRect(x+7+k*4,y+2+k*12,2,2);}}
  for(const b of LIFE.bub){if(b.t<0||!b.n||b.n.x<0)continue;const x=b.n.x-cam.x,y=b.n.y-cam.y-46;if(x<-80||x>VW+80||y<-40||y>VH+40)continue;
    ctx.font='bold '+scaleText(9)+'px "Courier New",monospace';const w=Math.min(200,ctx.measureText(b.s).width+12),a=Math.min(1,b.t*4,(b.dur-b.t)*3);
    ctx.globalAlpha=Math.max(0,a);ctx.fillStyle='#fffdf0';ctx.fillRect(Math.round(x-w/2),Math.round(y-12),w,16);ctx.strokeStyle='#14182c';ctx.lineWidth=1;ctx.strokeRect(Math.round(x-w/2)+.5,Math.round(y-12)+.5,w,16);
    ctx.beginPath();ctx.moveTo(x-3,y+4);ctx.lineTo(x+3,y+4);ctx.lineTo(x,y+9);ctx.closePath();ctx.fill();txt(b.s,x,y,{size:9,align:'center',col:'#14182c',lw:0,out:false});ctx.globalAlpha=1;}
  drawFog();
}
/* ---- t138u: AUTO ESCAPE IN TOWN - step inside Oakvale and any fight ends; chasers give up and walk back to their spawn ---- */
const TOWN_ESC={n:0};
function updateTownEscape(){
  if(state!=='play'||window.__NOESC||!playerInTown())return;   // (__NOESC: test hook for older suites that stage fights inside town)
  try{if(labOn()||RUSH.on)return;}catch(e){}
  let any=false;
  if(B&&B.phase!=='win'&&B.phase!=='lose'&&B.phase!=='reward'){for(const e of B.ens)if(!e.dying&&!e.tmp)e.ret=true;resetFighters(false);B=null;P.grace=3;any=true;}
  for(const e of enemies)if(e.alive&&(e.chasing||e.engaged)){e.chasing=false;e.engaged=false;e.ret=true;any=true;}
  if(any){TOWN_ESC.n++;toast('Safe in Oakvale - the monsters give up the chase',2.2,'#9ad0ff');}
}
function lifeReturn(e,dt){   // walk home after giving up; no new aggro on the way
  if(!e.ret)return false;const dx=e.hx-e.x,dy=e.hy-e.y,d=Math.hypot(dx,dy);e.calm=Math.max(e.calm||0,1);
  if(d<10){e.ret=false;e.mode='look';e.mt=1;return true;}
  e.fa=Math.atan2(dy,dx);e.mode='walk';e.mt=.5;return false;
}
