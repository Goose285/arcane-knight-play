/* =====================================================================
   ACHIEVEMENTS: polled once a second against live game state; each pays a small gold bounty.
   ACH.s holds the few counters that are not derivable from other state.
   ===================================================================== */
const ACH={done:{},s:{crafts:0,rushBest:0,bestFloor:0,weeklyWins:0,streakBest:0,spw:0,fish:0,bless:0,boots:0}};
function resetAch(){ACH.done={};ACH.s={crafts:0,rushBest:0,bestFloor:0,weeklyWins:0,streakBest:0,spw:0,fish:0,bless:0,boots:0};}
function packAch(){return {d:ACH.done,s:ACH.s};}
function unpackAch(s){resetAch();if(!s)return;
  if(s.d)for(const a of ACHS)if(s.d[a.id])ACH.done[a.id]=1;
  if(s.s)for(const k in ACH.s)if(Number.isFinite(s.s[k]))ACH.s[k]=clamp(s.s[k]|0,0,99999);}
function achProg(a){try{if(a.p){const [c,m]=a.p();return [Math.min(c,m),m];}return [a.t()?1:0,1];}catch(e){return [0,1];}}
const achDone=a=>!!ACH.done[a.id];
const achCount=()=>ACHS.filter(achDone).length;
function achUnlock(a){
  if(ACH.done[a.id])return false;ACH.done[a.id]=1;P.gold+=a.gold;
  toast(`ACHIEVEMENT: ${a.n}  (+${a.gold} G)`,3.6,'#ffd23f');sfx('level');return true;
}
let achChk=1;
function achTick(){
  let n=0;for(const a of ACHS){if(ACH.done[a.id])continue;const [c,m]=achProg(a);if(c>=m&&achUnlock(a))n++;}
  if(n&&!RUSH.on&&state==='play')saveGame('achievement');
  return n;
}
function updateAch(dt){
  if(metaOff()||window.__NOACH||state!=='play'||RUSH.on)return;
  achChk-=dt;if(achChk>0)return;achChk=1;achTick();
}
