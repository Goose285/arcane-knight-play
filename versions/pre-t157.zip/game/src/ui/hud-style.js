/* =====================================================================
   t143u HUD + PANEL STYLE: every HUD panel (hero card, quest tracker, minimap, foe list, toasts that use panel()) now matches the pause
   menu: a stitched dark-leather slab with cut corners, a thin brass rim, a soft drop shadow and a lighter bevel on top.
   Panels that pass their own colours keep them as the fill, inside the same leather frame.
   ===================================================================== */
const _panelOld=panel;
const HUDST={out:'#1e1008',leather:'#4a2c18',leatherHi:'#6b4423',rim:'#c8963c',rimHi:'#f0cf7a',fill:'#2a1a12',fillHi:'#3a2618'};
panel=function(x,y,w,h,o={}){
  if(o.legacy)return _panelOld(x,y,w,h,o);
  x=Math.round(x);y=Math.round(y);w=Math.round(w);h=Math.round(h);const S=HUDST;
  ctx.fillStyle='rgba(0,0,0,.42)';ctx.fillRect(x+2,y+4,w,h);                                                    // soft drop shadow
  ctx.fillStyle=S.out;ctx.fillRect(x+2,y,w-4,h);ctx.fillRect(x,y+2,w,h-4);ctx.fillRect(x+1,y+1,w-2,h-2);           // cut-corner outline
  ctx.fillStyle=S.leather;ctx.fillRect(x+2,y+2,w-4,h-4);ctx.fillStyle=S.leatherHi;ctx.fillRect(x+2,y+2,w-4,1);
  const rim=o.border&&o.border!=='#e8e0c8'?o.border:S.rim;ctx.fillStyle=rim;ctx.fillRect(x+3,y+3,w-6,1);ctx.fillRect(x+3,y+h-4,w-6,1);ctx.fillRect(x+3,y+3,1,h-6);ctx.fillRect(x+w-4,y+3,1,h-6);   // brass rim
  ctx.fillStyle=o.fill&&o.fill!=='#2a1a10'?o.fill:S.fill;ctx.fillRect(x+4,y+4,w-8,h-8);
  ctx.fillStyle=S.fillHi;ctx.fillRect(x+4,y+4,w-8,2);
  for(const [qx,qy] of [[x+2,y+2],[x+w-4,y+2],[x+2,y+h-4],[x+w-4,y+h-4]]){ctx.fillStyle=S.rimHi;ctx.fillRect(qx,qy,2,2);}  // brass corner studs
};
/* ---- t143u main-quest guidance: glowing breadcrumbs on the ground leading from the hero toward the tracked objective ---- */
function drawQuestCrumbs(){
  if(B||DLG||state!=='play'||typeof trkEntries!=='function')return;let cur,tg;try{cur=trkCurrent(trkEntries());tg=cur&&trkRoute(cur);}catch(e){return;}
  if(!cur||!tg)return;const main=cur.kind==='story'||(cur.kind==='quest'&&isMainQuest(cur.q));
  const dx=tg.x-P.x,dy=tg.y-P.y,d=Math.hypot(dx,dy);if(d<70)return;
  const ux=dx/d,uy=dy/d,n=Math.min(6,Math.floor((d-30)/40)),ph=(gtime*1.2)%1,col=main?'255,225,77':'125,249,255';
  for(let i=0;i<n;i++){const s=34+(i+ph)*40,x=P.x+ux*s-cam.x,y=P.y-6+uy*s-cam.y,a=.75*(1-(i+ph)/n);if(a<=0)continue;
    ctx.save();ctx.translate(Math.round(x),Math.round(y));ctx.rotate(Math.atan2(uy,ux));ctx.globalAlpha=a;
    ctx.fillStyle='rgba(0,0,0,.35)';ctx.beginPath();ctx.moveTo(7,2);ctx.lineTo(-4,-4);ctx.lineTo(-1,2);ctx.lineTo(-4,8);ctx.closePath();ctx.fill();
    ctx.fillStyle=`rgb(${col})`;ctx.beginPath();ctx.moveTo(7,0);ctx.lineTo(-4,-6);ctx.lineTo(-1,0);ctx.lineTo(-4,6);ctx.closePath();ctx.fill();ctx.restore();}
  ctx.globalAlpha=1;
}
{const _dt=drawTracker;drawTracker=function(){try{drawQuestCrumbs();}catch(e){}return _dt.apply(this,arguments);};}
