/* =====================================================================
   LEATHER SATCHEL: pixel-art drawing helpers for the pause / inventory menu (stitched leather, brass buckles, bookmark tabs,
   recessed item slots with a soft glow, parchment tooltips). Pure drawing: the menu logic stays in pause-menu.js.
   ===================================================================== */
const SAT={dark:'#2a160a',L0:'#7a4a26',L1:'#8c5a31',L2:'#a8703f',L3:'#5e3a1c',stitch:'#e2b878',stitchSh:'#3a2210',brass:'#e0b44a',brassHi:'#fff0a0',brassLo:'#9a7418',well:'#3a2210',wellDk:'#1c0e06',wellHi:'#6a4a2c'};
let SAT_PAT=null;
function satPattern(){   // tiled leather grain
  if(SAT_PAT)return SAT_PAT;
  const c=makeSprite(32,32,g=>{g.fillStyle=SAT.L1;g.fillRect(0,0,32,32);for(let y=0;y<32;y++)for(let x=0;x<32;x++){const r=hash2(x*7+3,y*13+5)/4294967296;if(r<.10){g.fillStyle=SAT.L3;g.fillRect(x,y,1,1);}else if(r<.19){g.fillStyle=SAT.L2;g.fillRect(x,y,1,1);}else if(r>.97){g.fillStyle='#6a3e1e';g.fillRect(x,y,2,1);}}});
  SAT_PAT=ctx.createPattern(c,'repeat');return SAT_PAT;
}
function satLeather(x,y,w,h,o={}){   // stitched leather slab: dark outline with cut corners, grain, bevel, dashed stitching
  x=Math.round(x);y=Math.round(y);w=Math.round(w);h=Math.round(h);const cut=o.cut==null?3:o.cut;
  ctx.fillStyle=SAT.dark;ctx.fillRect(x+cut,y,w-cut*2,h);ctx.fillRect(x,y+cut,w,h-cut*2);ctx.fillRect(x+1,y+1,w-2,h-2);
  ctx.save();ctx.beginPath();ctx.rect(x+2+(cut>2?1:0),y+2,w-4-(cut>2?2:0),h-4);ctx.clip();
  ctx.fillStyle=satPattern();ctx.fillRect(x,y,w,h);
  if(o.tone){ctx.fillStyle=o.tone;ctx.fillRect(x,y,w,h);}
  ctx.restore();
  ctx.fillStyle=SAT.L2;ctx.fillRect(x+cut,y+2,w-cut*2,2);ctx.fillRect(x+2,y+cut,2,h-cut*2);        // lit top / left
  ctx.fillStyle=SAT.L3;ctx.fillRect(x+cut,y+h-4,w-cut*2,2);ctx.fillRect(x+w-4,y+cut,2,h-cut*2);   // shaded bottom / right
  if(o.stitch!==false)satStitch(x+6,y+6,w-12,h-12,o.sc);
}
function satStitch(x,y,w,h,col){
  col=col||SAT.stitch;const d=(a,b,len,hor)=>{for(let i=0;i<len;i+=6){const l=Math.min(3,len-i);
    if(hor){ctx.fillStyle=SAT.stitchSh;ctx.fillRect(a+i,b+1,l,1);ctx.fillStyle=col;ctx.fillRect(a+i,b,l,1);}
    else{ctx.fillStyle=SAT.stitchSh;ctx.fillRect(a+1,b+i,1,l);ctx.fillStyle=col;ctx.fillRect(a,b+i,1,l);}}};
  d(x,y,w,true);d(x,y+h,w,true);d(x,y,h,false);d(x+w,y,h,false);
}
function satWell(x,y,w,h){   // recessed (sunken) panel
  x=Math.round(x);y=Math.round(y);ctx.fillStyle=SAT.wellDk;ctx.fillRect(x,y,w,h);ctx.fillStyle=SAT.well;ctx.fillRect(x+2,y+2,w-3,h-3);
  ctx.fillStyle=SAT.wellHi;ctx.fillRect(x+1,y+h-1,w-1,1);ctx.fillRect(x+w-1,y+1,1,h-1);
}
function satBrass(x,y,w,h){   // brass plate / buckle frame with a dark slot
  x=Math.round(x);y=Math.round(y);ctx.fillStyle='#4a3208';ctx.fillRect(x,y,w,h);ctx.fillStyle=SAT.brass;ctx.fillRect(x+1,y+1,w-2,h-2);
  ctx.fillStyle=SAT.brassHi;ctx.fillRect(x+1,y+1,w-2,2);ctx.fillRect(x+1,y+1,2,h-2);ctx.fillStyle=SAT.brassLo;ctx.fillRect(x+1,y+h-3,w-2,2);ctx.fillRect(x+w-3,y+1,2,h-2);
}
function satBuckle(cx,y,w,h){   // brass buckle: a square frame with a hole and a prong across it
  const x=Math.round(cx-w/2);satBrass(x,y,w,h);ctx.fillStyle='#2a1806';ctx.fillRect(x+4,y+4,w-8,h-8);
  const my=y+Math.round(h/2);ctx.fillStyle=SAT.brass;ctx.fillRect(x+2,my-1,w-4,2);ctx.fillStyle=SAT.brassHi;ctx.fillRect(x+2,my-1,w-4,1);ctx.fillStyle=SAT.brassLo;ctx.fillRect(x+w-6,my-2,3,4);
}
function satTabPath(x,y,w,h){const n=Math.min(9,Math.round(w*.2));ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+w,y);ctx.lineTo(x+w,y+h);ctx.lineTo(x+w/2,y+h-n);ctx.lineTo(x,y+h);ctx.closePath();}
function satTab(x,y,w,h,sel){   // bookmark-shaped leather tab (notched bottom)
  if(sel)y-=2;
  ctx.save();satTabPath(x-1.5,y-1.5,w+3,h+3);ctx.fillStyle=SAT.dark;ctx.fill();ctx.restore();
  ctx.save();satTabPath(x,y,w,h);ctx.clip();ctx.fillStyle=satPattern();ctx.fillRect(x,y,w,h);ctx.fillStyle=sel?'rgba(255,210,120,.22)':'rgba(40,20,8,.12)';ctx.fillRect(x,y,w,h);
  ctx.fillStyle=SAT.L2;ctx.fillRect(x,y,w,2);ctx.fillStyle=SAT.L3;ctx.fillRect(x+w-2,y,2,h);ctx.restore();
  // stitched edge following the notch
  const n=Math.min(9,Math.round(w*.2)),ix=x+4,iw=w-8,ih=h-6;
  ctx.fillStyle=SAT.stitch;for(let i=0;i<ih-n;i+=6){ctx.fillRect(ix,y+4+i,1,3);ctx.fillRect(ix+iw,y+4+i,1,3);}
  for(let i=0;i<iw/2;i+=5){ctx.fillRect(ix+i,y+4+ih-n+Math.round(i*n/(iw/2))-1,2,1);ctx.fillRect(ix+iw-i-1,y+4+ih-n+Math.round(i*n/(iw/2))-1,2,1);}
  if(sel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;satTabPath(x,y,w,h);ctx.stroke();}
  return y;
}
function satGlow(cx,cy,r,a){const g=ctx.createRadialGradient(cx,cy,1,cx,cy,r);g.addColorStop(0,'rgba(255,214,130,'+a+')');g.addColorStop(1,'rgba(255,170,60,0)');ctx.fillStyle=g;ctx.fillRect(cx-r,cy-r,r*2,r*2);}
function satSlot(x,y,s,glow){   // recessed item slot with an optional soft glow
  x=Math.round(x);y=Math.round(y);satWell(x,y,s,s);ctx.fillStyle='rgba(0,0,0,.28)';ctx.fillRect(x+2,y+2,s-4,3);
  if(glow>0){ctx.save();ctx.beginPath();ctx.rect(x+2,y+2,s-4,s-4);ctx.clip();satGlow(x+s/2,y+s/2,s*.8,.55*glow);ctx.restore();ctx.strokeStyle='rgba(255,207,106,'+(.75*glow)+')';ctx.lineWidth=2;ctx.strokeRect(x+1,y+1,s-2,s-2);}
}
function satTip(cx,by,name,sub,col,bounds){   // parchment tooltip with a folded corner, anchored above (cx,by)
  ctx.font='bold '+scaleText(11)+'px "Courier New",monospace';const w1=ctx.measureText(name).width;ctx.font='bold '+scaleText(8)+'px "Courier New",monospace';const w2=sub?ctx.measureText(sub).width:0;
  const w=Math.round(Math.max(w1,w2)+18),h=sub?32:22;let x=Math.round(cx-w/2),y=Math.round(by-h-6);
  if(bounds){x=Math.max(bounds.x+2,Math.min(bounds.x+bounds.w-w-2,x));if(y<bounds.y+2)y=Math.round(by+6);}
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(x+2,y+3,w,h);
  ctx.fillStyle='#3a2210';ctx.fillRect(x-1,y-1,w+2,h+2);ctx.fillStyle='#f0dcae';ctx.fillRect(x,y,w,h);
  ctx.fillStyle='#e0c88c';ctx.fillRect(x,y+h-3,w,3);ctx.fillStyle='#fff3cf';ctx.fillRect(x,y,w,2);
  ctx.fillStyle='#c8a868';ctx.fillRect(x+w-7,y+h-7,7,7);ctx.fillStyle='#8a6a38';ctx.fillRect(x+w-7,y+h-7,1,7);ctx.fillRect(x+w-7,y+h-7,7,1);
  txt(name,x+w/2,y+(sub?14:15),{size:11,align:'center',col:col||'#3a2210',lw:0,out:false});
  if(sub)txt(sub,x+w/2,y+26,{size:8,align:'center',col:'#6a4a22',lw:0,out:false,bold:false});
}
function satStrap(x,y,w,h,sel,warn){   // a leather strap hanging over the bag's lower edge, with a brass buckle at its end
  satLeather(x,y,w,h,{cut:2,tone:'rgba(30,14,4,.22)'});
  ctx.fillStyle='rgba(0,0,0,.25)';ctx.fillRect(Math.round(x)+3,Math.round(y+h),w-6,3);
  if(sel||warn){ctx.strokeStyle=warn?'#ff8a8a':'#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x+1,y+1,w-2,h-2);}
}
/* the backpack contents the slots show: equipped gear first, then the backpack, the day's catch and crafting materials */
function satItems(){
  const out=[];
  for(const s of GEAR_SLOTS){const it=GEAR.eq[s];if(it)out.push({name:it.name,sub:'Equipped '+GEAR_SLOT_NAME[s].toLowerCase()+'  Lv'+it.lv,col:GEAR_RAR[it.rar].col,spr:gearIcon(it),tint:GEAR_RAR[it.rar].col,eq:true});}
  GEAR.inv.slice().sort((a,b)=>GEAR_RAR_ORDER.indexOf(b.rar)-GEAR_RAR_ORDER.indexOf(a.rar)||b.lv-a.lv).forEach(it=>out.push({name:it.name,sub:GEAR_RAR[it.rar].n+' '+GEAR_SLOT_NAME[it.slot].toLowerCase()+'  Lv'+it.lv,col:GEAR_RAR[it.rar].col,spr:gearIcon(it),tint:GEAR_RAR[it.rar].col}));
  for(const f of FISHES){const n=FSH.fish[f.id]|0;if(n>0)out.push({name:f.n,sub:(f.junk?'Junk':FISH_RARITY[f.rar|0].n+' fish')+'  x'+n,col:f.junk?f.col:FISH_RARITY[f.rar|0].col,fish:f.col,count:n});}
  for(const k of Object.keys(MATS)){const n=matCount(k);if(n>0)out.push({name:MATS[k].n,sub:'Material  x'+n,col:MATS[k].col,gem:MATS[k].col,count:n});}
  return out;
}
function satItemIcon(it,x,y,s){   // s = slot size; draws the icon centred, ~60% of the slot
  const sc=Math.max(1,Math.floor(s*.62/16)),px=16*sc,ix=Math.round(x+(s-px)/2),iy=Math.round(y+(s-px)/2);
  if(it.spr){draw(it.spr,ix,iy,sc);ctx.globalAlpha=.4;draw(tintOf(it.spr,it.tint),ix,iy,sc);ctx.globalAlpha=1;}
  else if(it.fish){draw(fishTinted(it.fish),ix,iy,sc);}
  else if(it.gem){const c=it.gem,u=sc;ctx.fillStyle='#1e140c';ctx.fillRect(ix+5*u,iy+2*u,6*u,2*u);ctx.fillRect(ix+3*u,iy+4*u,10*u,2*u);ctx.fillRect(ix+4*u,iy+6*u,8*u,5*u);ctx.fillRect(ix+6*u,iy+11*u,4*u,2*u);
    ctx.fillStyle=c;ctx.fillRect(ix+6*u,iy+3*u,4*u,1*u);ctx.fillRect(ix+4*u,iy+5*u,8*u,2*u);ctx.fillRect(ix+5*u,iy+7*u,6*u,3*u);ctx.fillRect(ix+7*u,iy+10*u,2*u,1*u);ctx.fillStyle='rgba(255,255,255,.55)';ctx.fillRect(ix+5*u,iy+5*u,2*u,1*u);ctx.fillRect(ix+5*u,iy+6*u,1*u,2*u);}
}
