/* =====================================================================
   DAILY HUB (pause menu / Notice Board): login chest, today's challenges, the weekly crypt. + ACHIEVEMENTS screen.
   ===================================================================== */
UI_STATES.push('daily','ach');
const hubBar=(x,y,w,f,col)=>{ctx.fillStyle='#140c06';ctx.fillRect(x,y,w,7);ctx.fillStyle=col;ctx.fillRect(x,y,Math.round(w*clamp(f,0,1)),7);};
function openDaily(){dailyEnsure();wkEnsure();openUIMode('daily');}
function openAch(){achTick();openUIMode('ach');}
function weeklyRow(){
  const go=()=>{if(!rushStart('weekly'))uiMsg('Cannot enter right now');};
  return {sel:true,h:58,act:go,tap:go,draw(x0,y,W,h,isSel,si){
    ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle='#b070ff';ctx.fillRect(x0,y,3,h);
    if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
    txt('CRYPT OF THE WEEK: '+weeklyName().toUpperCase(),x0+10,y+17,{size:10,col:'#d8b0ff',lw:2});
    txt(`${WEEKLY_CFG.floors} floors  -  pick a boon after each  -  best floor ${WK.best}`,x0+10,y+31,{size:8,col:'#e8c070',bold:false});
    txt(WK.claimed?'Weekly chest already claimed':'Clear every floor for the weekly chest',x0+10,y+45,{size:8,col:WK.claimed?'#8a7050':'#ffd23f',bold:false});
    uiButton(x0+W-82,y+14,74,30,'DESCEND',true,()=>{UI.sel=si;go();},{tag:'daily:weekly',clip:true,size:10,bg:'#5a2a8a',bd:'#d8a0ff',sel:si});}};
}
function chestRow(){
  const ready=chestReady(),sv=chestPreview(),go=()=>{const r=claimChest();uiMsg(r?'Chest opened: '+r.got.join(', '):'Already opened today',false);};
  return {sel:true,h:64,act:go,tap:go,draw(x0,y,W,h,isSel,si){
    ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle='#ffd23f';ctx.fillRect(x0,y,3,h);
    if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
    txt('DAILY CHEST',x0+10,y+16,{size:11,col:'#ffe14d',lw:2});
    txt(ready?'Streak '+DAILY.streak+' -> '+sv+' day'+(sv>1?'s':''):'Opened  -  streak '+DAILY.streak+' day'+(DAILY.streak===1?'':'s'),x0+10,y+30,{size:8,col:ready?'#7dffa0':'#e8c070',bold:false});
    const cur=(ready?sv:DAILY.streak)-1,pw=Math.min(24,(W-120)/7-3);
    for(let i=0;i<7;i++){const on=i<=cur%7&&(ready?true:true)&&(cur>=0),today=i===cur%7;ctx.fillStyle=on?(today&&ready?'#ffd23f':'#7dffa0'):'#4a2e18';ctx.fillRect(x0+10+i*(pw+3),y+40,pw,14);
      if(i===6){ctx.fillStyle='#e8504a';ctx.fillRect(x0+10+i*(pw+3)+pw/2-2,y+43,4,8);}}
    uiButton(x0+W-86,y+17,78,30,ready?'OPEN':'DONE',ready,()=>{UI.sel=si;go();},{tag:'daily:chest',clip:true,size:12,bg:'#8a6a1a',bd:'#ffe14d',sel:si});}};
}
function challengeRow(c){
  return {h:40,draw(x0,y,W,h){ctx.fillStyle='#1e120a';ctx.fillRect(x0,y,W,h);ctx.fillStyle=c.done?'#7dffa0':'#7a5a30';ctx.fillRect(x0,y,3,h);
    txt((c.done?'\u2713 ':'')+dailyText(c),x0+10,y+16,{size:10,col:c.done?'#7dffa0':'#e8e0c8',lw:2});
    hubBar(x0+10,y+25,W-100,c.p/c.n,c.done?'#7dffa0':'#6fa0ff');
    txt(c.p+'/'+c.n,x0+W-84,y+32,{size:9,col:'#d8c8a8',bold:false});txt('+'+c.gold+' G',x0+W-8,y+16,{size:9,col:'#ffd23f',align:'right',bold:false});}};
}
UI_MODES.daily={title:()=>'DAILY',sub:()=>['Resets at midnight  -  '+DAILY.ch.filter(c=>c.done).length+'/'+DAILY.ch.length+' challenges done','#ffe14d'],rows(){
  dailyEnsure();const r=[{t:'head',s:'LOGIN CHEST'},chestRow(),{t:'head',s:'TODAY\'S CHALLENGES'}];
  DAILY.ch.forEach(c=>r.push(challengeRow(c)));
  r.push({h:26,draw(x0,y,W,h){txt(DAILY.bonus?'\u2713 All done - bonus chest earned!':'Finish all three for a bonus chest',x0+10,y+17,{size:8,col:DAILY.bonus?'#ffd23f':'#e8c070',bold:false});}});
  r.push({t:'head',s:'WEEKLY ROGUELIKE CRYPT'},weeklyRow());
  wkEnsure();r.push({t:'head',s:'THIS WEEK\'S BOARD'});
  if(!WK.lb.length)r.push({h:28,draw(x0,y,W,h){ctx.fillStyle='#1e120a';ctx.fillRect(x0,y,W,h);txt('No runs yet this week',x0+10,y+18,{size:9,col:'#e8c070',bold:false});}});
  WK.lb.forEach((e,i)=>r.push({h:28,draw(x0,y,W,h){ctx.fillStyle=i===0?'#2a2410':'#1e120a';ctx.fillRect(x0,y,W,h);
    txt('#'+(i+1),x0+10,y+18,{size:10,col:i<3?'#ffe14d':'#e8c070',lw:2});txt(String(e.score),x0+46,y+18,{size:10,col:'#fff',lw:2});
    txt(e.floors+'/'+WEEKLY_CFG.floors+' floors'+(e.won?' \u2713':'')+'  Lv'+e.lv,x0+W-8,y+18,{size:9,col:'#d8c8a8',align:'right',bold:false});}}));
  return r;}};
UI_MODES.ach={title:()=>'ACHIEVEMENTS',sub:()=>[achCount()+' / '+ACHS.length+' unlocked','#ffd23f'],rows(){
  return ACHS.map(a=>{const [c,m]=achProg(a),dn=achDone(a);
    return {h:38,draw(x0,y,W,h){ctx.fillStyle=dn?'#1c2a1c':'#1e120a';ctx.fillRect(x0,y,W,h);ctx.fillStyle=dn?'#ffd23f':'#7a5a30';ctx.fillRect(x0,y,3,h);
      txt((dn?'\u2605 ':'')+a.n,x0+10,y+15,{size:10,col:dn?'#ffd23f':'#e8e0c8',lw:2});txt(a.d,x0+10,y+30,{size:8,col:dn?'#9be09b':'#e8c070',bold:false});
      if(!dn&&m>1){hubBar(x0+W-88,y+22,60,c/m,'#6fa0ff');txt(c+'/'+m,x0+W-8,y+30,{size:8,col:'#d8c8a8',align:'right',bold:false});}
      txt(dn?'DONE':'+'+a.gold+' G',x0+W-8,y+15,{size:9,col:dn?'#7dffa0':'#ffd23f',align:'right',bold:false});}};});}};
/* notice board prop (sprite + dialog hook) */
SP.board=autoOutline(makeSprite(16,16,g=>{rect(g,2,13,2,3,'#5a3a1a');rect(g,12,13,2,3,'#5a3a1a');rect(g,1,2,14,11,'#8a5a2a');rect(g,2,3,12,9,'#c89a52');
  rect(g,3,4,4,4,'#f4ecd8');rect(g,8,4,5,3,'#f4ecd8');rect(g,4,9,5,2,'#f4ecd8');rect(g,10,8,3,3,'#e8504a');rect(g,3,4,1,1,'#e8504a');rect(g,5,3,1,2,'#6a6a6a');}),'#2a1a08');
