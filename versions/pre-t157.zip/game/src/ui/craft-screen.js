/* =====================================================================
   CRAFTING SCREEN (pause menu -> CRAFT): parts, gear recipes, card upgrades
   ===================================================================== */
function openCraft(){openUIMode('craft');}
function matsRow(){
  return {h:Math.ceil(Object.keys(MATS).length/4)*20+6,draw(x0,y,W,h){ctx.fillStyle='#1e120a';ctx.fillRect(x0,y,W,h);
    const ks=Object.keys(MATS),cw=W/4;
    ks.forEach((k,i)=>{const cx=x0+(i%4)*cw+cw/2,cy=y+(i>>2)*20;ctx.fillStyle=MATS[k].col;ctx.fillRect(Math.round(cx-cw/2+6),cy+6,8,8);
      txt(MATS[k].n.split(' ').pop()+' '+matCount(k),cx-cw/2+18,cy+14,{size:8,col:matCount(k)?'#fff':'#8a7050',lw:2});});}};
}
function recipeRow(r){
  const can=canPay(r.mats,r.gold),col=GEAR_RAR[r.rar].col;
  const go=()=>{const it=craftGear(r);if(it){sfx('level');uiMsg('Crafted '+it.name,false);saveGame('craft');}else{uiMsg('Missing parts or gold');sfx('clang');}};
  return {sel:true,h:58,act:go,tap:go,
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      gearIconBox(x0+7,y+13,{slot:r.slot,rar:r.rar},32);
      txt(r.name,x0+46,y+14,{size:10,col,lw:2});txt(`${GEAR_RAR[r.rar].n} ${GEAR_SLOT_NAME[r.slot]}`,x0+46,y+26,{size:8,col:'#d8c8a8',lw:2});
      const ks=Object.keys(r.mats);let xx=x0+46;
      ks.forEach(k=>{const have=matCount(k)>=r.mats[k];const s=r.mats[k]+' '+MATS[k].n.split(' ').pop();txt(s,xx,y+38,{size:8,col:have?'#7dffa0':'#ff9a9a',bold:false,lw:2});xx+=s.length*5+10;});
      txt(storyGold(r.gold)+' G',x0+46,y+50,{size:8,col:P.gold>=storyGold(r.gold)?'#ffd23f':'#ff9a9a',lw:2});
      uiButton(x0+W-74,y+14,66,30,'CRAFT',can,()=>{UI.sel=si;go();},{tag:'craft:'+r.id,clip:true,size:11,sel:si});}};
}
function upgradeRow(c){
  const l=upgLvl(c.id),max=l>=UPG_MAX,cs=max?null:upgCost(c.id,l),can=!max&&canPay(cs.mats,cs.gold);
  const go=()=>{if(upgradeCard(c.id)){sfx('level');uiMsg(cardFullName(c)+' upgraded',false);saveGame('craft');}else{uiMsg(max?'Already max':'Missing parts or gold');sfx('clang');}};
  return {sel:true,h:50,act:go,tap:go,
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=c.col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      ctx.fillStyle=c.col;ctx.fillRect(x0+8,y+9,28,28);draw(SP.ic[c.id],x0+9,y+10,1.5);
      txt(cardFullName(c),x0+44,y+15,{size:10,col:RAR[c.rar].col,lw:2});
      txt(l?`+${l*15}% power`:'not upgraded',x0+44,y+27,{size:8,col:'#d8c8a8',lw:2});
      txt(max?'MAX LEVEL':costText(cs.mats,storyGold(cs.gold)),x0+44,y+40,{size:7,col:max?'#ffe14d':can?'#7dffa0':'#ff9a9a',bold:false,lw:2});
      uiButton(x0+W-74,y+10,66,30,max?'MAX':'UPGRADE',can,()=>{UI.sel=si;go();},{tag:'upg:'+c.id,clip:true,size:9,sel:si});}};
}
function lightRow(l){
  const own=!!LGT.own[l.id],eq=LGT.eq===l.id,pr=lightPrice(l),can=own||P.gold>=pr;
  const go=()=>{
    if(!own){if(buyLight(l.id)){sfx('level');uiMsg('Bought '+l.name+(LGT.eq===l.id?' (equipped)':''),false);saveGame('light');}else{uiMsg('Not enough gold');sfx('clang');}}
    else if(eq){equipLight(null);sfx('select');uiMsg(l.name+' put away',false);saveGame('light');}
    else{equipLight(l.id);sfx('select');uiMsg(l.name+' equipped',false);saveGame('light');}};
  return {sel:true,h:50,act:go,tap:go,
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=l.col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      const cx=x0+22,cy=y+25;ctx.fillStyle='#140c06';ctx.fillRect(x0+6,y+9,32,32);
      const gr=ctx.createRadialGradient(cx,cy,2,cx,cy,16);gr.addColorStop(0,l.col);gr.addColorStop(1,'rgba(0,0,0,0)');ctx.fillStyle=gr;ctx.fillRect(x0+6,y+9,32,32);
      ctx.fillStyle='#fff';ctx.fillRect(cx-2,cy-2,4,4);
      txt(l.name,x0+46,y+15,{size:10,col:l.col,lw:2});txt(l.desc,x0+46,y+28,{size:7,col:'#d8c8a8',bold:false,lw:2});
      txt(own?(eq?'EQUIPPED  (V toggles)':'owned'):pr+' G',x0+46,y+42,{size:8,col:own?(eq?'#7dffa0':'#d8c8a8'):P.gold>=pr?'#ffd23f':'#ff9a9a',lw:2});
      uiButton(x0+W-74,y+10,66,30,own?(eq?'UNEQUIP':'EQUIP'):'BUY',can,()=>{UI.sel=si;go();},{tag:'light:'+l.id,clip:true,size:9,sel:si});}};
}
UI_MODES.craft={title:()=>'WORKBENCH',sub:()=>[`Gold ${P.gold} G`,'#ffd23f'],rows(){
  const r=[{t:'head',s:'MONSTER PARTS'},matsRow(),{t:'head',s:'CRAFT GEAR  (parts + gold)'}];
  RECIPES.forEach(x=>r.push(recipeRow(x)));
  r.push({t:'head',s:'UPGRADE CARDS  (+15% power per level, max 3)'});
  CARDS.filter(c=>COL[c.id]>0).sort((a,b)=>RAR_ORDER.indexOf(a.rar)-RAR_ORDER.indexOf(b.rar)||a.name.localeCompare(b.name)).forEach(c=>r.push(upgradeRow(c)));
  return r;}};
