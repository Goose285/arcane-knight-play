/* =====================================================================
   CHRONICLE: chapters, villager trust + perks, chosen ending.
   ===================================================================== */
UI_STATES.push('story');
function storyRows(){
  const rows=[];
  rows.push({head:'CHAPTERS'});
  CHAPTERS.forEach((c,i)=>{const done=STORY.ch>i,next=STORY.ch===i;
    rows.push({h:next?36:24,kind:'ch',c,i,done,next});});
  rows.push({head:'VILLAGERS'});
  for(const id in VILLAGERS)rows.push({h:38,kind:'vil',id});
  if(STORY.ending)rows.push({head:'YOUR ENDING'},{h:52,kind:'end'});
  if(STORY.choices.length){rows.push({head:'YOUR CHOICES'});STORY.choices.slice(-6).forEach(c=>rows.push({h:22,kind:'pick',c}));}
  return rows;
}
UI_MODES.story={title:()=>'CHRONICLE',sub:()=>[STORY.ch>=CHAPTERS.length?'The Hollow Crown: complete':'Chapter '+(STORY.ch+1)+' of '+CHAPTERS.length,'#ffe14d'],rows(){
  return storyRows().map(r=>r.head?{t:'head',s:r.head}
   :{h:r.h,draw(x0,y,w,h){
    if(r.kind==='ch'){
      txt((r.done?'\u2713 ':r.next?'> ':'  ')+(r.i+1)+'. '+(r.done||r.next?r.c.name:'???'),x0+8,y+(r.next?16:16),{size:11,col:r.done?'#7dffa0':r.next?'#ffe14d':'#6a6684'});
      if(r.next)txt(r.c.hint,x0+8,y+30,{size:8,col:'#e0d0b0',bold:false,lw:2});}
    else if(r.kind==='vil'){const v=VILLAGERS[r.id],t=STORY.trust[r.id],on=t>=TRUST_NEED;
      txt(v.n,x0+8,y+15,{size:11,col:on?'#7dffa0':'#e8e0c8'});
      for(let k=0;k<5;k++){ctx.fillStyle=k<t?(on?'#7dffa0':'#ffd23f'):'#4a2e18';ctx.fillRect(x0+w-84+k*14,y+6,11,11);}
      txt(on?v.perk:'Perk locked - earn trust ('+t+'/'+TRUST_NEED+')',x0+8,y+30,{size:8,col:on?'#9be09b':'#6a6684',bold:false,lw:2});}
    else if(r.kind==='end'){const e=ENDINGS[STORY.ending];txt(e.n,x0+8,y+18,{size:12,col:e.col});
      const ls=wrapText(e.desc,w-20,'8px "Courier New",monospace');ls.slice(0,2).forEach((l,k)=>txt(l,x0+8,y+32+k*10,{size:8,col:'#e0d0b0',bold:false,lw:2}));}
    else if(r.kind==='pick')txt('- '+r.c.t,x0+8,y+14,{size:9,col:'#e0d0b0',bold:false,lw:2});
  }});
}};
