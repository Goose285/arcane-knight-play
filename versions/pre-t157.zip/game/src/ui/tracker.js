/* =====================================================================
   QUEST TRACKER: a compact HUD panel under the hero panel. Tracks one villager quest / the story chapter / a daily.
   Pick with TRACK in the quest log (newest quest is tracked automatically when nothing is). Tap the panel to collapse.
   State (TRK: id, open) lives in player/quests.js and is saved with the quests.
   ===================================================================== */
function trkEntries(){
  const out=[];
  for(const q of QUESTS){
    const st=QS.st[q.id];if(st!=='active'&&st!=='ready')continue;
    const o=q.obj,need=questNeed(q),ready=st==='ready',prog=ready?need:questProgress(q);
    const item=o.k==='fish'?'Fish':o.k==='kill'?ENEMY[o.type].name+(o.n>1?'s':''):o.k==='collect'||o.k==='find'?QITEM[o.item].name:'Crypt';
    out.push({id:'q:'+q.id,kind:'quest',q,name:q.name,obj:ready?'Return to '+q.giver:questGoalText(q),short:item,prog,need,ready,order:QS.ord.indexOf(q.id)});
  }
  const ie=introEntry();if(ie)out.push(ie);
  if(introQuiet())return out;   // first five minutes: just the one objective / the first quest
  if(STORY.ch<CHAPTERS.length){const c=CHAPTERS[STORY.ch];
    out.push({id:'s',kind:'story',name:'Story: '+c.name,obj:c.hint,short:'Step',prog:STORY.ch,need:CHAPTERS.length,step:STORY.ch+1,steps:CHAPTERS.length,ready:false,order:-1});}
  if(!metaOff())DAILY.ch.forEach((c,i)=>out.push({id:'d:'+i,kind:'daily',c,name:'Daily Challenge',obj:c.done?'Complete!':dailyText(c),short:'Progress',prog:Math.min(c.p,c.n),need:c.n,ready:!!c.done,order:-2}));
  return out;
}
const trkValid=id=>!!id&&trkEntries().some(e=>e.id===id);
function trkPick(list){const ie=list.find(e=>e.kind==='intro');if(ie)return ie;                                       // newest started quest, else the story chapter, else the first unfinished daily
  const qs=list.filter(e=>e.kind==='quest').sort((a,b)=>b.order-a.order);if(qs.length)return qs[0];
  const s=list.find(e=>e.kind==='story');if(s)return s;
  return null;   // t154u: dailies have their own chip (drawDailyChip) - the tracker shows main / side progress only
}
function trkCurrent(list){list=list||trkEntries();const f=list.find(e=>e.id===TRK.id);return (f&&f.kind!=='daily'?f:null)||trkPick(list);}
function trackQuest(id){if(!trkValid(id))return false;TRK.id=id;TRK.auto=false;TRK.sig=null;sfx('select');saveGame('track');return true;}
function trkTiles(t){if(!TRK.cache)TRK.cache={};if(TRK.cache[t])return TRK.cache[t];let r=null;for(let y=0;y<MH&&!r;y++)for(let x=0;x<MW;x++)if(map[y][x]===t){r={x:x*TS+16,y:y*TS+16};break;}return TRK.cache[t]=r;}
/* where the objective is right now (world px) or null when unknown / in another area */
function trkTarget(en,any){
  if(!en)return null;const pz=zoneOfPx(P.y),zn=any?null:pz;
  const foe=(type,pred)=>{let b=null,bd=1e9;for(const e of enemies){if(!e.alive||e.dying||(type&&e.type!==type)||(pred&&!pred(e))||(zn&&zoneOfPx(e.y)!==zn))continue;const d=Math.hypot(e.x-P.x,e.y-P.y)+(any&&zoneOfPx(e.y)!==pz?1e5:0);if(d<bd){bd=d;b=e;}}return b&&{x:b.x,y:b.y};};
  const npc=name=>{const n=NPCS.find(m=>m.name===name);return n&&(!zn||zoneOfPx(n.y)===zn)?{x:n.x,y:n.y}:null;};
  const stairs=()=>!zn||zn==='ow'?trkTiles(T.CS):null;
  if(en.kind==='quest'){const q=en.q,o=q.obj;if(en.ready)return npc(q.giver);
    if(o.k==='fish'){let bb=null,bd=1e9;for(const f of FISH_SPOTS){const c=spotCenter(f);if((zn&&zoneOfPx(c.y)!==zn)||fishLv()<f.lv)continue;const d=Math.hypot(c.x-P.x,c.y-P.y)+(any&&zoneOfPx(c.y)!==pz?1e5:0);if(d<bd){bd=d;bb=c;}}return bb||npc(q.giver);}
    const camp=t=>t==='goblin'&&(!zn||zn==='ow')?{x:(GOBLIN_CAMP.tx+.5)*TS,y:(GOBLIN_CAMP.ty+.5)*TS}:null;   // all of them are down / respawning: point at their camp
    const meadow=e=>e.x<(25+OX)*TS&&e.y<(27+OY)*TS&&e.y>=OWY0*TS,mc=()=>!zn||zn==='ow'?{x:(13.5+OX)*TS,y:(19.5+OY)*TS}:null;   // slime quests: the meadow just north of the village (never the east forest)
    if(o.k==='kill')return o.type==='slime'?(foe('slime',meadow)||mc()):(foe(o.type)||camp(o.type));if(o.k==='collect')return o.from==='slime'?(foe('slime',meadow)||mc()):(foe(o.from)||camp(o.from));
    if(o.k==='find'){const w=QWORLD.find(x=>x.quest===q.id);return w&&(!zn||zn==='ow')?{x:w.tx*TS+16,y:w.ty*TS+16}:null;}
    return stairs();}
  if(en.kind==='intro')return npc('Elder Orin');
  if(en.kind==='story'){const id=CHAPTERS[STORY.ch].id;
    if(id==='c1'||id==='c5')return npc('Elder Orin');if(id==='c2')return npc('Gate Guard');if(id==='c3')return stairs();if(id==='c4')return foe('lich');return null;}
  const c=en.c;if(c.done)return null;
  if(c.k==='type')return foe(c.t);if(c.k==='kills'||c.k==='gold')return foe();if(c.k==='elite')return foe(null,e=>!!e.elite);return null;
}
/* where the arrow should point: the objective itself when it is in this area, otherwise the way out / in (exit rune, gate arch, crypt stairs) */
function trkExitOf(area){
  if(area==='crypt')return trkTiles(T.CX);
  for(const k in ZEXITS)if(ZEXITS[k]===area){const a=k.split(',');return {x:(+a[0]+.5)*TS,y:(+a[1]+.5)*TS};}
  return null;
}
function trkEntranceTo(area){
  if(ZONES[area])return {x:(ZONES[area].gate.x+.5)*TS,y:(ZONES[area].gate.y+.5)*TS};
  if(area==='crypt')return trkTiles(T.CS)||{x:(CRYPT_IN.x+.5)*TS,y:(CRYPT_IN.y+.5)*TS};
  if(area==='house')return {x:(HOUSE_DOOR.tx+.5)*TS,y:(HOUSE_DOOR.ty+.5)*TS};
  return null;
}
function trkRoute(en){
  const t=trkTarget(en,true);if(!t)return null;
  const pz=zoneOfPx(P.y),tz=zoneOfPx(t.y);
  if(pz===tz)return {x:t.x,y:t.y,area:pz,goal:t,via:null};
  const w=pz==='ow'?trkEntranceTo(tz):trkExitOf(pz);
  return w?{x:w.x,y:w.y,area:pz,goal:t,via:pz==='ow'?(ZONE_NAME[tz]||(tz==='crypt'?CRYPT_NAME:tz)):'exit'}:null;
}
/* the tracked objective on a map: gold marker (cyan when it is the way out / in) and an arrow from the hero's dot toward it.
   (mx,my) = top-left of the map image on screen, oy = world y of its first row, sc = screen px per tile, clip = [x,y,w,h] */
function trkRouteNow(){
  const k=Math.floor(gtime*4);if(TRK.rk===k)return TRK.rv;
  const list=trkEntries(),cur=trkCurrent(list);TRK.rk=k;return TRK.rv=cur?trkRoute(cur):null;
}
function drawMapQuest(mx,my,oy,sc,clip){
  const r=trkRouteNow();if(!r||state==='title')return;
  const tx=mx+r.x/TS*sc,ty=my+(r.y-oy)/TS*sc,px=mx+P.x/TS*sc,py=my+(P.y-oy)/TS*sc,col=r.via?'#7df9ff':'#ffe14d';
  ctx.save();if(clip){ctx.beginPath();ctx.rect(clip[0],clip[1],clip[2],clip[3]);ctx.clip();}
  const pul=(Math.sin(gtime*5)+1)/2,rr=3+pul*3*sc/2;
  ctx.strokeStyle='#000';ctx.lineWidth=3;ctx.beginPath();ctx.arc(tx,ty,rr,0,6.283);ctx.stroke();
  ctx.strokeStyle=col;ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(tx,ty,rr,0,6.283);ctx.stroke();
  ctx.fillStyle=col;ctx.fillRect(Math.round(tx-1.5),Math.round(ty-1.5),3,3);
  const dx=tx-px,dy=ty-py,d=Math.hypot(dx,dy);
  if(d>9){const a=Math.atan2(dy,dx),o=Math.min(8+sc,d-4);ctx.translate(px+Math.cos(a)*o,py+Math.sin(a)*o);ctx.rotate(a);
    ctx.fillStyle=col;ctx.strokeStyle='#000';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(5,0);ctx.lineTo(-3,-4);ctx.lineTo(-1,0);ctx.lineTo(-3,4);ctx.closePath();ctx.stroke();ctx.fill();}
  ctx.restore();
}
function updateTracker(dt){
  if(state!=='play'||WARP)return;
  const list=trkEntries(),cur=trkCurrent(list);
  if(TRK.id!==(cur&&cur.id)&&!TRK.done){
    // the tracked entry vanished: a finished villager quest gets a "complete" flash before the next one is tracked
    const pv=TRK.prev;if(pv&&pv.kind==='quest'&&QS.st[pv.q.id]==='done'&&!list.some(e=>e.id===pv.id))TRK.done={name:pv.name,t:2.6};
    TRK.id=cur?cur.id:null;TRK.auto=true;TRK.sig=null;}
  if(TRK.done){TRK.done.t-=dt;if(TRK.done.t<=0)TRK.done=null;}
  if(!cur){TRK.prev=null;return;}
  const sig=cur.prog+'/'+cur.need+(cur.ready?'R':'')+'|'+cur.obj;
  if(TRK.sig!==null&&sig!==TRK.sig){TRK.flash=1.8;TRK.fk=cur.ready?'ready':'prog';TRK.open=true;}   // progress pops the tracker open
  TRK.sig=sig;TRK.prev=cur;
}
function trkVisible(){return state==='play'&&!WARP&&!(DLG&&DLG.cut)&&!RUSH.on&&!isUI()&&!STORY.cutting&&!(STORY.queue);}   // stays up through fights, talks and fishing (a compact line while fighting)
function drawTracker(){
  TRK.rect=null;
  if(!trkVisible()||introHold())return;
  const list=trkEntries(),cur=trkCurrent(list);
  const inB=!!B,open=TRK.open&&!inB;
  const px=SL+8,py=inB?COMBAT_HUD_BOT+4:ST+8+66,mapX=VW-SR-8-128-6;
  const w=Math.max(120,Math.min(214,mapX-px-4)),pad=7;
  if(TRK.done){const h=22;panel(px,py,w,h,{border:'#7dffa0',fill:'#10301c'});txt('QUEST COMPLETE!',px+pad,py+15,{size:10,col:'#7dffa0',lw:2});TRK.rect={x:px,y:py,w,h};return;}
  if(!cur)return;
  const flashing=TRK.flash>0;if(flashing)TRK.flash=Math.max(0,TRK.flash-1/60);
  const blink=flashing&&Math.floor(gtime*9)%2===0,col=flashing?(TRK.fk==='ready'?QMARK_COL.ready:'#ffe14d'):cur.ready?QMARK_COL.ready:cur.kind==='story'?QMARK_COL.story:cur.kind==='quest'?(isMainQuest(cur.q)?QMARK_COL.story:QMARK_COL.avail):'#e8e0c8';   // t139u: story yellow, side quests blue, ready gold
  const fs=scaleText(9),font='bold '+fs+'px "Courier New",monospace',tg=trkRoute(cur),aw=tg&&open?34:0;
  const nameW=w-pad*2-14;
  ctx.font='bold '+scaleText(10)+'px "Courier New",monospace';
  let title=cur.name;while(title.length>3&&ctx.measureText(title).width>nameW)title=title.slice(0,-2);if(title!==cur.name)title=title.trim()+'..';
  if(!open){   // collapsed chip: still shows the count, a thin progress bar and the direction arrow
    const h=Math.round(scaleText(10)+17),cnt=cur.kind==='story'?`${cur.step}/${cur.steps}`:cur.ready&&cur.kind==='quest'?'READY':`${cur.prog}/${cur.need}`,arW=tg?20:0;
    ctx.font='bold '+scaleText(10)+'px "Courier New",monospace';const cw=Math.ceil(ctx.measureText(cnt).width)+6;
    let t2=cur.name;while(t2.length>3&&ctx.measureText('+ '+t2).width>w-pad*2-cw-arW)t2=t2.slice(0,-2);if(t2!==cur.name)t2=t2.trim()+'..';
    panel(px,py,w,h,{border:blink?'#fff':col,fill:flashing?'#2a2410':'#2a1a10'});
    txt('+ '+t2,px+pad,py+h-9,{size:10,col,lw:2});
    txt(cnt,px+w-pad-arW-cw+6,py+h-9,{size:10,col:cur.ready?'#7dffa0':'#ffe14d',lw:2});
    const bw=w-pad*2,bx=px+pad,by=py+h-6;ctx.fillStyle='#140c06';ctx.fillRect(bx,by,bw,3);ctx.fillStyle=cur.ready?'#7dffa0':'#ffe14d';ctx.fillRect(bx,by,Math.round(bw*clamp(cur.prog/cur.need,0,1)),3);
    if(tg){const ax=px+w-pad-7,ay=py+Math.round((h-6)/2),dx=tg.x-P.x,dy=tg.y-P.y,d=Math.hypot(dx,dy);ctx.save();ctx.translate(ax,ay);
      if(d<40){ctx.fillStyle='#7dffa0';ctx.beginPath();ctx.arc(0,0,3.5+Math.sin(gtime*8),0,6.283);ctx.fill();}
      else{ctx.rotate(Math.atan2(dy,dx));ctx.fillStyle=flashing?'#fff':tg.via?'#7df9ff':'#ffe14d';ctx.strokeStyle='#000';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(8,0);ctx.lineTo(-5,-6);ctx.lineTo(-2,0);ctx.lineTo(-5,6);ctx.closePath();ctx.stroke();ctx.fill();}
      ctx.restore();}
    TRK.rect={x:px,y:py,w,h};return;}
  const lines=wrapText(cur.obj,w-pad*2-aw,font).slice(0,3),lh=Math.round(fs*1.35);
  const hh=Math.round(scaleText(10)+12+lines.length*lh+fs+22);
  panel(px,py,w,hh,{border:blink?'#fff':col,fill:flashing?(TRK.fk==='ready'?'#10301c':'#2a2410'):'#2a1a10'});
  txt((cur.ready?'? ':cur.kind==='story'||cur.kind==='quest'?'! ':'- ')+title,px+pad,py+Math.round(scaleText(10))+3,{size:10,col,lw:2});
  let yy=py+Math.round(scaleText(10))+6+lh;
  lines.forEach((l,i)=>txt(l,px+pad,yy+i*lh,{size:9,col:'#f0e2c0',bold:false,out:false}));
  yy+=lines.length*lh;
  const label=cur.kind==='story'?`Step ${cur.step}/${cur.steps}`:cur.ready&&cur.kind==='quest'?'READY - hand in':`${cur.short} ${cur.prog}/${cur.need}`;
  txt(label,px+pad,py+hh-14,{size:9,col:cur.ready?'#7dffa0':'#ffe14d',lw:2});
  const bw=w-pad*2-aw,bx=px+pad,by=py+hh-9;ctx.fillStyle='#140c06';ctx.fillRect(bx,by,bw,5);ctx.fillStyle=cur.ready?'#7dffa0':'#ffe14d';ctx.fillRect(bx,by,Math.round(bw*clamp(cur.prog/cur.need,0,1)),5);
  if(tg){   // direction arrow + distance
    const ax=px+w-pad-15,ay=py+Math.round(scaleText(10))+24,dx=tg.x-P.x,dy=tg.y-P.y,d=Math.hypot(dx,dy),a=Math.atan2(dy,dx);
    ctx.save();ctx.translate(ax,ay);
    if(d<40){ctx.fillStyle='#7dffa0';ctx.beginPath();ctx.arc(0,0,5+Math.sin(gtime*8)*1.5,0,6.283);ctx.fill();}
    else{ctx.rotate(a);ctx.fillStyle=flashing?'#fff':tg.via?'#7df9ff':'#ffe14d';ctx.strokeStyle='#000';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(11,0);ctx.lineTo(-7,-8);ctx.lineTo(-3,0);ctx.lineTo(-7,8);ctx.closePath();ctx.stroke();ctx.fill();}
    ctx.restore();
    txt(d<40?(tg.via?'exit':'here'):Math.round(d/TS)+'m',ax,ay+22,{size:8,align:'center',col:'#f0e2c0',lw:2});
  }
  TRK.rect={x:px,y:py,w,h:hh};
}
function trkTap(p){if(TRK.rect&&inRect(p,TRK.rect)){if(TRK.done)return true;TRK.open=!TRK.open;sfx('select');return true;}return false;}
