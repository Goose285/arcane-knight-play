
/* ---- HUD ---- */
function drawOverHud(){
  const px=SL+8,py=ST+8;
  panel(px,py,178,60,{});
  draw(SP.heroIcon,px+7,py+4,2);txt('HERO',px+28,py+16,{size:11,col:'#ffe9a0'});txt('Lv'+P.lv,px+170,py+16,{size:11,col:'#ffe14d',align:'right'});
  const hpf=P.hp/maxHp();
  bar(px+8,py+22,160,9,hpf,hpf<.3?'#ff4040':'#44d96a');txt(Math.ceil(P.hp)+'/'+maxHp(),px+8,py+44,{size:9,col:'#fff',lw:2});
  bar(px+8,py+48,160,5,P.xp/xpNeed(),'#58a8ff');
  txt('G '+P.gold,px+170,py+44,{size:11,col:'#ffd23f',align:'right'});
  if(labOn()){const q=py+66;panel(px,q,178,24,{});txt('COMBAT LAB  (practice)',px+8,q+16,{size:10,col:'#7df9ff',lw:2});}
  else if(RUSH.on){const q=py+66;panel(px,q,178,34,{});txt(RUSH.mode==='weekly'?'WEEKLY  F'+(RUSH.round+1)+'/'+WEEKLY_CFG.floors:'BOSS RUSH  R'+(RUSH.round+1),px+8,q+14,{size:10,col:'#ff9a6a',lw:2});txt('SCORE '+RUSH.score,px+170,q+14,{size:10,col:'#ffe14d',align:'right',lw:2});txt(rushTime(RUSH.t),px+8,q+28,{size:9,col:'#f0e2c0',lw:2});txt(RUSH.cur&&!B?'next boss in '+Math.max(0,Math.ceil(RUSH.wait)):RUSH.cur?'':'Get ready...',px+170,q+28,{size:9,col:'#e8c070',align:'right',lw:2,bold:false});}
  // minimap
  const mx=VW-SR-8-128,my=ST+8;panel(mx-2,my-2,132,100,{fill:'#0a0814'});
  const zn=zoneOfPx(P.y),mz=MINI[zn]||MINI.ow,cr=zn!=='ow',oy=mz.y0*TS;
  const mk=Math.min(1,128/mz.spr.width,96/mz.spr.height),k2=2*mk;   // (an expanded world shrinks its minimap to fit the box)
  ctx.globalAlpha=.92;ctx.drawImage(mz.spr,mx,my,Math.round(mz.spr.width*mk),Math.round(mz.spr.height*mk));ctx.globalAlpha=1;
  for(const e of enemies){if(!e.alive||zoneOfPx(e.y)!==zn)continue;ctx.fillStyle=e.def.boss?(Math.floor(gtime*4)%2?'#ff2020':'#ffb0b0'):'#d03030';const s=e.def.boss?5:3;ctx.fillRect(mx+e.x/TS*k2-s/2+1,my+(e.y-oy)/TS*k2-s/2,s,s);}
  ctx.fillStyle=Math.floor(gtime*3)%2?'#fff':'#ffe14d';ctx.fillRect(mx+P.x/TS*k2-1,my+(P.y-oy)/TS*k2-2,4,4);
  if(!cr){drawDayIcon(mx+10,my+10);for(const m of TMAPS)if(SEC.maps[m.id]&&!SEC.dug[m.id]){ctx.fillStyle='#ffd23f';ctx.fillRect(mx+m.x*k2-1,my+(m.y-OWY0)*k2-3,2,6);ctx.fillRect(mx+m.x*k2-3,my+(m.y-OWY0)*k2-1,6,2);}}
  for(const w of WAYSTONES)if(SEC.ways[w.id]){const q=w.zone?zoneArrive(w.zone):{x:(w.tx+.5)*TS,y:(w.ty+.5)*TS};if(zoneOfPx(q.y)===zn){ctx.fillStyle='#7df9ff';ctx.fillRect(mx+q.x/TS*k2-2,my+(q.y-oy)/TS*k2-2,4,4);}}
  drawMapQuest(mx,my,oy,k2,[mx,my,128,96]);
  if(areaT>0&&INTRO.ph!=='story'){const a=Math.min(1,areaT*1.5,(3-areaT)*3),y=Math.round(VH*.3);ctx.font='bold '+scaleText(22)+'px "Courier New",monospace';const bw=Math.min(VW,ctx.measureText(areaCur).width+60);ctx.fillStyle=`rgba(0,0,0,${.5*a})`;ctx.fillRect(Math.round((VW-bw)/2),y,Math.round(bw),34);txt(areaCur,VW/2,y+25,{size:22,align:'center',col:'#ffe9a0',alpha:a});}
  if(!TOUCH)txt('WASD/Arrows move   J shoot   E / click talk   Stay out of monsters\' sight cones   P pause   M mute',VW/2,VH-6,{size:10,align:'center',col:'#fff',alpha:.55,bold:false,lw:2});
}
function drawRushBar(){
  if(!RUSH.on||labOn())return;const w=Math.min(250,VW-SL-SR-16),x=Math.round((VW-w)/2),y=ST+8+112;
  panel(x,y,w,22,{});txt((RUSH.mode==='weekly'?'WEEKLY F':'RUSH R')+(RUSH.round+1)+'   SCORE '+RUSH.score+'   '+rushTime(RUSH.t),VW/2,y+15,{size:9,align:'center',col:'#ffb070',lw:2});
}
function drawToasts(){
  const t=toasts[0];if(!t||introHold())return;   // one transient message at a time, inside the free band (never over the tracker / minimap)
  const bd=hudBand(),w=bd.x1-bd.x0,cx=Math.round((bd.x0+bd.x1)/2),fs=scaleText(12),font='bold '+fs+'px "Courier New",monospace';
  const lines=wrapText(t.s,w-16,font).slice(0,3),lh=Math.round(fs*1.3),h=lines.length*lh+10;let tw=0;ctx.font=font;for(const l of lines)tw=Math.max(tw,ctx.measureText(l).width);
  const a=clamp(Math.min(t.t*4,(t.dur-t.t)*3),0,1),bw=Math.min(w,Math.ceil(tw)+18);
  ctx.globalAlpha=.78*a;ctx.fillStyle='#0d0a1c';ctx.fillRect(cx-bw/2,bd.y,bw,h);ctx.globalAlpha=1;
  lines.forEach((l,i)=>txt(l,cx,bd.y+6+fs+i*lh-2,{size:12,align:'center',col:t.col,alpha:a,lw:2}));
  TOAST_R={x:cx-bw/2,y:bd.y,w:bw,h};
}
let TOAST_R=null;
function drawDlg(){
  if(DLG.cut){drawCut(DLG);return;}
  const d=DLG,x=SL+14,w=VW-SL-SR-28,fs=Math.round(13*(1+(TXS-1)*1.4)),lh=Math.round(fs*1.32),font='bold '+fs+'px "Courier New",monospace';
  const all=wrapText(d.lines[d.i],w-30,font),full=d.c>=d.lines[d.i].length,isCh=!!d.choice&&d.i===d.lines.length-1;
  const h=Math.max(100,38+all.length*lh+(isCh?34:12)),y=VH-SB-h-(TOUCH?(VH>VW?150:12):18);
  dlgRects={box:{x,y,w,h}};
  panel(x,y,w,h,{});
  txt(d.name,x+14,y+22,{size:13,col:'#ffe14d'});
  let left=Math.floor(d.c),ly=y+44;
  for(const l of all){if(left<=0)break;txt(l.slice(0,left),x+14,ly,{size:fs,out:false});left-=l.length+1;ly+=lh;}
  if(isCh&&full){
    dlgRects.yes={x:x+w-176,y:y+h-34,w:78,h:26};dlgRects.no={x:x+w-90,y:y+h-34,w:78,h:26};
    panel(dlgRects.yes.x,dlgRects.yes.y,78,26,{fill:'#1c4a2a'});txt(TOUCH?(d.yes||'BUY'):'Enter: '+(d.yes||'BUY'),dlgRects.yes.x+39,dlgRects.yes.y+18,{size:11,align:'center',out:false});
    panel(dlgRects.no.x,dlgRects.no.y,78,26,{fill:'#4a1c1c'});txt(TOUCH?(d.no||'NO'):'Esc: '+(d.no||'NO'),dlgRects.no.x+39,dlgRects.no.y+18,{size:11,align:'center',out:false});
  } else if(full&&Math.floor(gtime*3)%2===0)txt(TOUCH?'tap v':'v',x+w-18,y+h-12,{size:12,col:'#ffe14d',out:false,align:TOUCH?'right':'left'});
}
let COMBAT_HUD_BOT=64;   // bottom of the combat HUD cluster (the quest tracker sits under it)
/* one card face at (0,0) in local pixels (cw x ch); the caller positions / rotates / scales the context */
function drawCardFace(id,cw,ch,sel,idx){
  const x=0,y=0,c=CARDS.find(q=>q.id===id),ih=TOUCH?26:34;
  ctx.fillStyle='rgba(0,0,0,.5)';ctx.fillRect(x+3,y+3,cw,ch);
  ctx.fillStyle=sel?'#fff':'#e8e0c8';ctx.fillRect(x,y,cw,ch);
  ctx.fillStyle='#17142b';ctx.fillRect(x+2,y+2,cw-4,ch-4);
  ctx.fillStyle=c.col;ctx.fillRect(x+4,y+4,cw-8,ih);ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(x+4,y+4,cw-8,7);
  draw(SP.ic[id],x+cw/2-(TOUCH?12:16),y+(TOUCH?5:6),TOUCH?1.5:2);
  txt(cardLabel(c),x+cw/2,y+ch-(TOUCH?19:24),{size:TOUCH?7:9,align:'center',col:'#fff',lw:2});
  txt(c.pow?String(Math.round(c.pow*cardMult()*schoolMult(c.id)*upgMult(c.id))):'--',x+cw/2,y+ch-(TOUCH?6:9),{size:TOUCH?10:12,align:'center',col:'#ffe14d',lw:2});
  if(!TOUCH&&idx!=null)txt(String(idx+1),x+7,y+14,{size:9,col:'#000',out:false});
  {const rc=RAR[c.rar];ctx.fillStyle=rc.col;ctx.fillRect(x+cw-9,y+3,6,6);if(c.rar!=='common'){ctx.strokeStyle=rc.col;ctx.globalAlpha=.55+.3*Math.sin(gtime*5);ctx.lineWidth=c.rar==='legendary'?2:1;ctx.strokeRect(x+1.5,y+1.5,cw-3,ch-3);ctx.globalAlpha=1;}}
  if(sel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x-1,y-1,cw+2,ch+2);}
}
function drawCombatHud(){
  const b=B,px=SL+8,py=ST+8;
  // player panel
  panel(px,py,176,50,{});
  draw(SP.heroIcon,px+7,py+4,2);txt('HERO',px+28,py+16,{size:11,col:'#ffe9a0'});txt('Lv'+P.lv,px+168,py+16,{size:11,col:'#ffe14d',align:'right'});
  const hpf=P.hp/maxHp();
  txt(String(Math.ceil(P.hp)),px+8,py+42,{size:22,col:hpf<.3?'#ff6b6b':'#fff'});
  bar(px+62,py+30,106,10,hpf,hpf<.3?'#ff4040':'#44d96a');txt('/'+maxHp(),px+168,py+26,{size:9,align:'right',col:'#cfd',lw:2});
  // enemy panel: one compact row (name + HP bar) per fighter
  const list=B.ens.filter(o=>!o.dying),shown=list.slice(0,4),rows=shown.length+(list.length>4?1:0);
  let ew=196,ex=VW-SR-8-ew,ey=py;
  if(ex<px+182){ex=px+182;ew=VW-SR-8-ex;}
  let stacked=false;if(ew<150){stacked=true;ex=px;ey=py+56;ew=176;}
  const eh=10+Math.max(1,rows)*20;
  if(list.length)panel(ex,ey,ew,eh,{});
  shown.forEach((o,i)=>{
    const ry=ey+8+i*20;
    txt(o.tname,ex+14,ry+8,{size:8,col:o.frozen>0||o.chill>0?'#9fe6ff':o.joinT>0?'#ffe14d':'#ffb0a0',lw:2});
    txt('Lv'+o.lv,ex+60,ry+8,{size:8,col:lvColor(o.lv),lw:2});
    bar(ex+90,ry+1,ew-96,9,o.hp/o.maxhp,o.frozen>0||o.chill>0?'#7fd8ff':o.def.boss?'#ff7a2a':'#e8504a');
    if(b.target===o&&list.length>1)txt('>',ex+5,ry+9,{size:9,col:'#ffe14d',lw:2});
  });
  if(list.length>4)txt('+'+(list.length-4)+' more',ex+ew/2,ey+eh-8,{size:8,align:'center',col:'#fff',lw:2});
  // card deal timer: a small bar that fills over 2.5s, then a new card drops into an empty slot (waits while the hand is full)
  let gw=110,gx=(VW-gw)/2,gy=py+2;
  const centerOK=gx>px+182&&gx+gw+6<ex;
  if(!centerOK){gw=Math.min(110,stacked?VW-SR-8-px:ex-px-8);gx=px;gy=(stacked?ey+eh+6:py+56);}
  const full=!b.hand.includes(null),gf=full?1:clamp(b.gauge,0,1);
  ctx.fillStyle='#000';ctx.fillRect(gx-2,gy,gw+4,12);ctx.fillStyle='#140c06';ctx.fillRect(gx,gy+2,gw,8);
  ctx.fillStyle=full?'#6a6a8a':(b.gaugeFlash>0&&Math.floor(gtime*16)%2?'#fff':'#ffcf3a');ctx.fillRect(gx,gy+2,Math.round(gw*gf),8);ctx.fillStyle='rgba(255,255,255,.3)';ctx.fillRect(gx,gy+2,Math.round(gw*gf),3);
  txt(full?'HAND FULL':'NEXT CARD  '+(EXPCARD.deal*(1-gf)).toFixed(1)+'s',gx+gw/2,gy+21,{size:8,align:'center',col:full?'#c8b898':'#ffe9a0',lw:2});
  COMBAT_HUD_BOT=Math.max(py+50,list.length&&(stacked||ex<px+222)?ey+eh:0,gy+28);
  // cards
  /* hand. Desktop: 7% larger than the original, shifted right. Touch: a fan of cards arcing around the SHOT button under the right thumb
     (tops point outward, the selected card pops out); left-handed mode mirrors it. Swipe along the fan to cycle, tap to cast, swipe up to cast at the nearest foe. */
  const HN=b.hand.length||EXPCARD.hand;
  cardRects=[];
  if(TOUCH){
    const F=fanGeom(HN),{pos,CS,cw0,ch0,cw,ch}=F;
    ctx.save();ctx.globalAlpha=.16;ctx.strokeStyle='#ffe9a0';ctx.lineWidth=ch*.9;ctx.lineCap='round';ctx.beginPath();
    {const s=F.s,a0=F.start*Math.PI/180-.09,a1=F.end*Math.PI/180+.09;ctx.arc(F.A.x,F.A.y,F.R,s>0?a0:Math.PI-a1,s>0?a1:Math.PI-a0);}
    ctx.stroke();ctx.restore();
    const order=[];for(let i=0;i<HN;i++)if(i!==b.sel||!b.hand[i]||b.phase!=='fight')order.push(i);if(b.hand[b.sel]&&b.phase==='fight'&&b.sel<HN)order.push(b.sel);
    for(let i=0;i<HN;i++){const q=pos[i],pop=(i===b.sel&&b.hand[i]&&b.phase==='fight')?14:0;cardRects[i]={x:q.cx+q.ox*pop-cw/2,y:q.cy+q.oy*pop-ch/2,w:cw,h:ch,cx:q.cx+q.ox*pop,cy:q.cy+q.oy*pop,rot:q.rot};}
    for(const i of order){
      const id=b.hand[i],sel=i===b.sel&&id&&b.phase==='fight',r=cardRects[i];
      ctx.save();ctx.translate(r.cx,r.cy);ctx.rotate(r.rot);ctx.scale(CS,CS);ctx.translate(-cw0/2,-ch0/2);
      if(!id){ctx.globalAlpha=.25;ctx.fillStyle='#2a1a10';ctx.fillRect(0,0,cw0,ch0);ctx.strokeStyle='#7a5a30';ctx.lineWidth=1;ctx.strokeRect(.5,.5,cw0-1,ch0-1);ctx.restore();continue;}
      drawCardFace(id,cw0,ch0,sel);if(b.xsel===i)expMark(cw0,ch0);
      ctx.restore();
    }
  } else {
  const CS=1.07,cw0=58,ch0=70,gap0=8;
  const cw=Math.round(cw0*CS),ch=Math.round(ch0*CS),gap=Math.round(gap0*CS),total=HN*cw+(HN-1)*gap,xc=Math.round((VW-total)/2);
  let x0=xc+Math.round(xc*.7);
  x0=Math.max(SL+2,Math.min(x0,VW-SR-2-total));
  const y0=VH-ch-22-SB;
  for(let i=0;i<HN;i++){
    const id=b.hand[i],sel=i===b.sel&&id&&b.phase==='fight';
    const X=x0+i*(cw+gap),Y=y0-(sel?8:0);
    cardRects.push({x:X,y:y0-8,w:cw,h:ch+8});
    if(!id){ctx.globalAlpha=.25;ctx.fillStyle='#2a1a10';ctx.fillRect(X,y0,cw,ch);ctx.strokeStyle='#7a5a30';ctx.lineWidth=1;ctx.strokeRect(X+.5,y0+.5,cw-1,ch-1);ctx.globalAlpha=1;continue;}
    ctx.save();ctx.translate(X,Y);ctx.scale(CS,CS);drawCardFace(id,cw0,ch0,sel,i);if(b.xsel===i)expMark(cw0,ch0);ctx.restore();
  }}
  drawDiscards(HN);
  if(!TOUCH)txt('J Shot (hold = charge)   L Next   K Cast   X Discard   WASD   P Pause',VW/2,VH-6-SB,{size:10,align:'center',col:'#f0e2c0',alpha:.8,bold:false,lw:2});
  // leash warning
  if(b.fleeT>.05&&b.phase==='fight'){const f=clamp(b.fleeT/2.2,0,1),cx=VW/2,cy=Math.round(VH*.6);txt('ESCAPING...',cx,cy,{size:14,align:'center',col:'#ffb0a0'});bar(cx-60,cy+6,120,6,f,'#ff8a70');}
  // banner
  if(b.banner){const bb=b.banner,pr=bb.t/bb.dur,sc=pr<.15?lerp(2,1,pr/.15):1,a=pr>.8?(1-pr)/.2:1,cy=Math.round(VH*.33);
    ctx.save();ctx.translate(VW/2,cy);ctx.scale(sc,sc);ctx.globalAlpha=a;
    ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(-VW,-30,VW*2,60);
    txt(bb.s,0,12,{size:Math.min(38,VW/9,(VW-24)/(bb.s.length*.62)),align:'center',col:bb.col,lw:6});ctx.restore();ctx.globalAlpha=1;}
  if(b.phase==='win'){const a=Math.min(1,b.t*3);txt(b.total>1?'ALL ENEMIES DELETED!':'ENEMY DELETED!',VW/2,VH*.35,{size:Math.min(34,VW/(b.total>1?13:10)),align:'center',col:'#ffe14d',alpha:a,lw:6});}
  if(b.phase==='lose'){const a=Math.min(1,b.t*2);txt('HERO DELETED...',VW/2,VH*.35,{size:Math.min(34,VW/10),align:'center',col:'#ff6b6b',alpha:a,lw:6});
    if(b.t>1.6){ctx.fillStyle=`rgba(0,0,0,${clamp((b.t-1.6)/.7,0,1)})`;ctx.fillRect(0,0,VW,VH);}}
  if(b.phase==='reward'){
    const loot=b.drops.filter(d=>d&&d.item),nl=Math.min(loot.length,4,Math.max(1,Math.floor((VH-ST-SB-(b.levels?190:150)-50)/34)));
    const w=Math.min(340,VW-24),h=(b.levels?190:150)+12+(nl?20+nl*34:0),x=(VW-w)/2,y=Math.max(ST+10,(VH-h)/2-30);
    panel(x,y,w,h,{});
    txt('VICTORY!',VW/2,y+30,{size:24,align:'center',col:'#ffe14d'});
    const parts=Object.keys(b.defeated).map(k=>b.defeated[k]+' '+SHORT[k][0]+SHORT[k].slice(1).toLowerCase()+(b.defeated[k]>1?'s':''));
    txt(b.boss?(b.bossName||'EMBERFANG')+' IS SLAIN!':'Defeated: '+parts.join(', '),VW/2,y+50,{size:11,align:'center',col:b.boss?'#ff9a7a':'#f0e2c0'});
    if(b.boss&&parts.length>1)txt(parts.join(', '),VW/2,y+64,{size:9,align:'center',col:'#f0e2c0'});
    txt('XP    +'+b.gainXp,x+36,y+90,{size:15,col:'#9ad0ff'});
    txt('GOLD  +'+b.gainGold,x+36,y+112,{size:15,col:'#ffd23f'});
    let yy=y+134;
    if(nl){txt('LOOT'+(loot.length>nl?'  (+'+(loot.length-nl)+' more in backpack)':''),x+36,yy+4,{size:11,col:'#ffe14d'});
      loot.slice(0,nl).forEach((d,i)=>{const it=d.item,c=GEAR_RAR[it.rar].col,ly=yy+22+i*34;
        ctx.fillStyle=c;ctx.fillRect(x+28,ly-10,3,28);draw(gearIcon(it),x+36,ly-8,1.5);
        txt(`${it.name}  Lv${it.lv}`,x+66,ly+2,{size:10,col:c,lw:2});txt(gearStatLine(it),x+66,ly+14,{size:8,col:'#f0e2c0',bold:false});
        const tag=it.auto?'EQUIPPED':it.upgrade?'UPGRADE':'NEW';txt(tag,x+w-26,ly+2,{size:8,align:'right',col:it.auto?'#7dffa0':it.upgrade?'#ffe14d':'#e8c070',lw:2});});
      yy+=22+nl*34;}
    if(b.levels){txt('LEVEL UP!  Lv '+(P.lv-b.levels)+' -> '+P.lv,VW/2,yy+8,{size:16,align:'center',col:'#7dffa0'});txt('Max HP '+maxHp()+'  Shot +'+b.levels+'  HP restored',VW/2,yy+28,{size:11,align:'center',col:'#cfe'});}
    if(b.t>.7&&Math.floor(gtime*2)%2===0)txt(TOUCH?'Tap to continue':'Press SPACE',VW/2,y+h-12,{size:12,align:'center',col:'#fff'});
  }
}

/* the discarded card drops away, spinning and fading, with a quick '-0.5s' by the deal timer */
function drawDiscards(HN){
  if(!B||!B.discards||!B.discards.length)return;
  const now=performance.now();B.discards=B.discards.filter(d=>now-d.t0<520);
  for(const d of B.discards){
    const p=clamp((now-d.t0)/450,0,1),r=d.r;let CS=1.07,cw0=58,ch0=70;if(TOUCH){const F=fanGeom(HN);CS=F.CS;cw0=F.cw0;ch0=F.ch0;}
    ctx.save();ctx.globalAlpha=1-p*p;ctx.translate(r.cx+d.dir*p*26,r.cy+p*p*80);ctx.rotate(r.rot+d.dir*p*.9);const sc=CS*(1-.35*p);ctx.scale(sc,sc);ctx.translate(-cw0/2,-ch0/2);
    drawCardFace(d.id,cw0,ch0,false);ctx.fillStyle='rgba(255,90,70,'+(.45*p)+')';ctx.fillRect(0,0,cw0,ch0);ctx.restore();
    txt('-'+DISCARD_SAVE+'s',r.cx,r.cy-r.h/2-6-p*14,{size:10,align:'center',col:'#9dffb0',lw:3,alpha:1-p});
  }
}
