/* =====================================================================
   BOSS RUSH SCREEN: leaderboard + start button (from the Arena Master's "BOARD" choice)
   ===================================================================== */
UI_MODES.rush={title:()=>'EMBER ARENA',sub:()=>['Boss rush  -  best scores on this device','#ff9a6a'],rows(){
  const r=[{t:'head',s:'FIVE CHAMPIONS, ENDLESS LAPS   (+3 levels and affixes each lap)'}];
  r.push({sel:true,h:44,act(){if(!rushStart())uiMsg('Cannot enter right now');},tap(){this.act();},
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle='#ff6b3a';ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      txt('ENTER THE ARENA',x0+10,y+19,{size:11,col:'#ffcf9a',lw:2});txt('Full heal on entry, +35% between rounds',x0+10,y+34,{size:8,col:'#e8c070',bold:false});
      uiButton(x0+W-92,y+7,84,30,'START',true,()=>{UI.sel=si;if(!rushStart())uiMsg('Cannot enter right now');},{tag:'rush:start',clip:true,size:12,bg:'#8a3a1a',bd:'#ffb070',sel:si});}});
  r.push({t:'head',s:'WEEKLY ROGUELIKE CRYPT   (new seed every Monday)'},weeklyRow());
  r.push({t:'head',s:'LEADERBOARD'});
  if(!RUSHLB.length)r.push({h:30,draw(x0,y,W,h){ctx.fillStyle='#1e120a';ctx.fillRect(x0,y,W,h);txt('No runs yet - be the first!',x0+10,y+19,{size:10,col:'#e8c070',bold:false});}});
  RUSHLB.forEach((e,i)=>r.push({h:30,draw(x0,y,W,h){ctx.fillStyle=i===0?'#2a2410':'#1e120a';ctx.fillRect(x0,y,W,h);ctx.fillStyle=i===0?'#ffd23f':i===1?'#cfd8e8':i===2?'#d89a5a':'#7a5a30';ctx.fillRect(x0,y,3,h);
    txt('#'+(i+1),x0+10,y+19,{size:11,col:i<3?'#ffe14d':'#e8c070',lw:2});txt(String(e.score),x0+48,y+19,{size:11,col:'#fff',lw:2});
    txt(e.rounds+' rds  '+rushTime(e.time)+'  Lv'+e.lv,x0+W-8,y+19,{size:9,col:'#d8c8a8',align:'right',bold:false});}}));
  return r;}};
UI_STATES.push('rush');
