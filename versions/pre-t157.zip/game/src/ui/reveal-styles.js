/* =====================================================================
   t142u REWARD POPUP STYLES (Settings > DISPLAY > REWARD POPUP STYLE). Same queue / timing / backdrop as REVEAL; only the frame changes:
     0 PARCHMENT (the t139u card)  1 WAX-SEALED SCROLL  2 WOODEN SHOP SIGN on chains  3 TREASURE CHEST opening  4 MINIMAL BANNER
   revealPreview() queues a sample (Silver Ring of Might) so the player can see the choice right away.
   ===================================================================== */
const _drawRevealParchment=drawReveal;
function revIcon(r,t,ts){   // the thing itself on a rarity tile, centred at (0,0)
  ctx.fillStyle='#2a160a';ctx.fillRect(-ts/2-2,-ts/2-2,ts+4,ts+4);ctx.fillStyle=r.col;ctx.fillRect(-ts/2,-ts/2,ts,ts);
  const tg=ctx.createRadialGradient(0,0,4,0,0,ts*.7);tg.addColorStop(0,'rgba(255,255,255,.55)');tg.addColorStop(1,'rgba(0,0,0,.25)');ctx.fillStyle=tg;ctx.fillRect(-ts/2,-ts/2,ts,ts);
  ctx.save();ctx.translate(0,Math.sin(t*3)*2);const k=ts/64;ctx.scale(k,k);
  if(r.k==='card'){const cw=42,ch=58;ctx.translate(-cw/2,-ch/2);drawCardFace(r.id,cw,ch,true,null);}
  else if(r.k==='item'){gearIconBox(-26,-26,r.it,52);}
  else if(r.k==='level'){ctx.fillStyle='#1e140c';ctx.beginPath();ctx.arc(0,0,26,0,6.283);ctx.fill();ctx.fillStyle='#ffe14d';ctx.beginPath();ctx.arc(0,0,22,0,6.283);ctx.fill();txt(String(r.lv||P.lv),0,10,{size:26,align:'center',col:'#2a160a',lw:0,out:false});}
  else draw(TSPR[T.CHST]?TSPR[T.CHST][0]:SP.ic.sword,-24,-24,3);
  ctx.restore();
}
function revInfo(r){return r.info||(r.k==='item'&&r.it&&typeof gearStatLine==='function'?gearStatLine(r.it):'');}
function revLines(r,y,w,col,max){const info=revInfo(r);if(!info)return;const font='bold '+scaleText(9)+'px "Courier New",monospace';wrapText(info,w,font).slice(0,max||3).forEach((l,i)=>txt(l,0,y+i*12,{size:9,align:'center',col,lw:0,out:false}));}
function revBackdrop(a,t,cx,cy){
  ctx.fillStyle=`rgba(20,12,6,${.5*a})`;ctx.fillRect(0,0,VW,VH);
  ctx.save();ctx.globalAlpha=a;const gl=ctx.createRadialGradient(cx,cy,10,cx,cy,Math.min(VW,VH)*.6);gl.addColorStop(0,'rgba(255,214,120,.32)');gl.addColorStop(1,'rgba(255,214,120,0)');ctx.fillStyle=gl;ctx.fillRect(0,0,VW,VH);ctx.restore();
}
const REV_STYLE_FN={
  scroll(r,t,a){   // a cream scroll with rolled wooden ends and a red wax seal
    const W=Math.min(VW*.5,250),H=Math.min(VH*.62,180),x0=-W/2,y0=-H/2;
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(x0+4,y0+8,W,H);
    const pg=ctx.createLinearGradient(0,y0,0,y0+H);pg.addColorStop(0,'#f6e9c8');pg.addColorStop(.5,'#fbf1d8');pg.addColorStop(1,'#ecdbb2');ctx.fillStyle=pg;ctx.fillRect(x0,y0,W,H);
    ctx.fillStyle='rgba(150,110,60,.18)';for(let i=0;i<6;i++)ctx.fillRect(x0+10+i*37%W,y0+20+(i*53)%(H-40),18,2);
    for(const yy of [y0-8,y0+H-6]){ctx.fillStyle='#5a3418';ctx.fillRect(x0-12,yy,W+24,14);ctx.fillStyle='#8a5a32';ctx.fillRect(x0-12,yy+2,W+24,4);ctx.fillStyle='#3a2010';ctx.fillRect(x0-16,yy-2,6,18);ctx.fillRect(x0+W+10,yy-2,6,18);}
    txt(REV_TITLES[r.k]||'NEW!',0,y0+22,{size:15,align:'center',col:'#7a2a1a',lw:0,out:false});
    ctx.fillStyle='#b89a6a';ctx.fillRect(-50,y0+28,100,1);
    ctx.save();ctx.translate(-W/2+50,y0+72);revIcon(r,t,56);ctx.restore();
    ctx.save();ctx.translate(38,0);txt(r.name,0,y0+60,{size:12,align:'center',col:r.k==='level'?'#3f7a3a':r.col,lw:3,out:'#2a160a'});if(r.sub)txt(r.sub,0,y0+78,{size:9,align:'center',col:'#5a3a1e',lw:0,out:false});ctx.restore();
    ctx.save();ctx.translate(0,0);revLines(r,y0+118,W-40,'#2a1a0e',3);ctx.restore();
    // wax seal with a ribbon tail
    const sx=W/2-26,sy=H/2-22;ctx.fillStyle='#8a1a1a';ctx.fillRect(sx-6,sy+8,5,16);ctx.fillRect(sx+3,sy+8,5,14);
    ctx.fillStyle='#b02a24';ctx.beginPath();ctx.arc(sx,sy,13,0,6.283);ctx.fill();ctx.fillStyle='#d8463a';ctx.beginPath();ctx.arc(sx-2,sy-2,9,0,6.283);ctx.fill();
    ctx.fillStyle='#7a1414';ctx.font='bold 12px "Courier New",monospace';ctx.textAlign='center';ctx.fillText('AK',sx,sy+4);ctx.textAlign='left';
  },
  sign(r,t,a){   // a wooden shop sign swinging gently on two chains
    const W=Math.min(VW*.5,240),H=Math.min(VH*.56,160),sw=Math.sin(t*2.2)*.025*Math.max(0,1-t/2.5);
    const top=-H/2-36;ctx.strokeStyle='#4a4a52';ctx.lineWidth=2;
    for(const sx of [-W/2+24,W/2-24]){for(let i=0;i<5;i++){ctx.strokeRect(sx-3,top+i*8,6,8);}ctx.fillStyle='#2a2a30';ctx.fillRect(sx-6,top-6,12,6);}
    ctx.save();ctx.rotate(sw);const x0=-W/2,y0=-H/2+4;
    ctx.fillStyle='rgba(0,0,0,.3)';ctx.fillRect(x0+5,y0+7,W,H);
    ctx.fillStyle='#4a2a14';ctx.fillRect(x0-3,y0-3,W+6,H+6);
    for(let i=0;i<5;i++){const yy=y0+i*H/5;ctx.fillStyle=i%2?'#8a5a32':'#9a6a3a';ctx.fillRect(x0,yy,W,H/5);ctx.fillStyle='#6b4423';ctx.fillRect(x0,yy+H/5-2,W,2);}
    ctx.fillStyle='rgba(255,230,180,.08)';ctx.fillRect(x0,y0,W,6);
    for(const [qx,qy] of [[x0+6,y0+6],[x0+W-10,y0+6],[x0+6,y0+H-10],[x0+W-10,y0+H-10]]){ctx.fillStyle='#2a2a30';ctx.fillRect(qx,qy,4,4);ctx.fillStyle='#8a8a96';ctx.fillRect(qx,qy,2,2);}
    txt(REV_TITLES[r.k]||'NEW!',0,y0+22,{size:16,align:'center',col:'#ffe14d',lw:4,out:'#2a160a'});
    ctx.save();ctx.translate(0,y0+66);revIcon(r,t,52);ctx.restore();
    txt(r.name,0,y0+110,{size:13,align:'center',col:'#fff4d8',lw:3,out:'#2a160a'});if(r.sub)txt(r.sub,0,y0+125,{size:9,align:'center',col:'#ffe6b8',lw:2,out:'#2a160a'});
    const info=revInfo(r);if(info){const font='bold '+scaleText(9)+'px "Courier New",monospace';wrapText(info,W-30,font).slice(0,2).forEach((l,i)=>txt(l,0,y0+140+i*11,{size:8,align:'center',col:'#fff0d0',lw:2,out:'#2a160a'}));}
    ctx.restore();
  },
  chest(r,t,a){   // a treasure chest whose lid swings open, the reward rising out of it on golden light
    const W=Math.min(VW*.4,180),cy=-VH*.02,open=Math.min(1,Math.max(0,(t-.15)/.45)),rise=Math.min(1,Math.max(0,(t-.35)/.5));
    // light shaft
    ctx.save();ctx.globalAlpha=a*open;const sh=ctx.createLinearGradient(0,cy,0,cy-170);sh.addColorStop(0,'rgba(255,220,120,.7)');sh.addColorStop(1,'rgba(255,220,120,0)');ctx.fillStyle=sh;
    ctx.beginPath();ctx.moveTo(-W*.36,cy);ctx.lineTo(W*.36,cy);ctx.lineTo(W*.6,cy-170);ctx.lineTo(-W*.6,cy-170);ctx.fill();ctx.restore();
    // the reward floats up
    ctx.save();ctx.translate(0,cy-30-rise*78);ctx.globalAlpha=a*rise;revIcon(r,t,54);ctx.restore();
    // chest body
    const bx=-W/2,by=cy,bw=W,bh=48;ctx.fillStyle='#2a160a';ctx.fillRect(bx-3,by-3,bw+6,bh+6);ctx.fillStyle='#7a4a24';ctx.fillRect(bx,by,bw,bh);
    for(let i=1;i<4;i++){ctx.fillStyle='#5a3418';ctx.fillRect(bx,by+i*bh/4,bw,2);}
    ctx.fillStyle='#e0b43a';ctx.fillRect(bx,by,bw,5);ctx.fillRect(bx+14,by,8,bh);ctx.fillRect(bx+bw-22,by,8,bh);ctx.fillStyle='#fbe08a';ctx.fillRect(bx,by,bw,1);
    ctx.fillStyle='#e0b43a';ctx.fillRect(-9,by+4,18,20);ctx.fillStyle='#2a160a';ctx.fillRect(-2,by+10,4,8);
    // lid (tilts back as it opens)
    const lh=34*(1-open*.75);ctx.fillStyle='#2a160a';ctx.fillRect(bx-3,by-lh-3,bw+6,lh+3);ctx.fillStyle='#8a5a2e';ctx.fillRect(bx,by-lh,bw,lh);
    ctx.fillStyle='#e0b43a';ctx.fillRect(bx,by-lh,bw,3);ctx.fillRect(bx+14,by-lh,8,lh);ctx.fillRect(bx+bw-22,by-lh,8,lh);
    if(open>.3){ctx.fillStyle='rgba(255,230,140,.9)';ctx.fillRect(bx+4,by-3,bw-8,3);}
    // text plate under the chest
    const py=by+bh+10;ctx.fillStyle='rgba(30,18,8,.85)';ctx.fillRect(-W*.7,py,W*1.4,58);ctx.strokeStyle='#e0b43a';ctx.lineWidth=2;ctx.strokeRect(-W*.7,py,W*1.4,58);
    txt((REV_TITLES[r.k]||'NEW!')+'  '+r.name,0,py+18,{size:12,align:'center',col:r.k==='level'?'#7dffa0':r.col,lw:3,out:'#2a160a'});
    if(r.sub)txt(r.sub,0,py+33,{size:9,align:'center',col:'#ffe6b8',lw:0,out:false});
    const info=revInfo(r);if(info){const font='bold '+scaleText(9)+'px "Courier New",monospace';txt(wrapText(info,W*1.3,font)[0]||'',0,py+48,{size:8,align:'center',col:'#fff0d0',lw:0,out:false});}
  },
  banner(r,t,a){   // a slim dark banner across the screen: icon left, name + stats right
    const W=Math.min(VW*.86,520),H=74,x0=-W/2,y0=-H/2,sl=Math.min(1,t/.3);
    ctx.save();ctx.beginPath();ctx.rect(-W/2*sl,y0-20,W*sl,H+40);ctx.clip();
    ctx.fillStyle='rgba(12,10,22,.92)';ctx.fillRect(x0,y0,W,H);ctx.fillStyle=r.col;ctx.fillRect(x0,y0,W,2);ctx.fillRect(x0,y0+H-2,W,2);
    const gr=ctx.createLinearGradient(x0,0,x0+W,0);gr.addColorStop(0,'rgba(255,214,120,0)');gr.addColorStop(.5,'rgba(255,214,120,.10)');gr.addColorStop(1,'rgba(255,214,120,0)');ctx.fillStyle=gr;ctx.fillRect(x0,y0,W,H);
    ctx.save();ctx.translate(x0+44,0);revIcon(r,t,50);ctx.restore();
    txt(REV_TITLES[r.k]||'NEW!',x0+82,y0+18,{size:9,col:'#ffe14d',lw:2});
    txt(r.name,x0+82,y0+38,{size:14,col:r.k==='level'?'#7dffa0':r.col,lw:3,out:'#000'});
    const info=revInfo(r);txt([r.sub,info].filter(Boolean).join('   '),x0+82,y0+56,{size:9,col:'#d8d0e8',lw:0,out:false});
    ctx.restore();
  },
};
drawReveal=function(){
  const st=(POP_STYLES[SET.pop|0]||POP_STYLES[0]).id;const fn=REV_STYLE_FN[st];
  if(!fn||!REV.cur)return _drawRevealParchment.apply(this,arguments);
  for(const p of REV.parts){ctx.globalAlpha=Math.max(0,1-p.t/p.life);ctx.fillStyle=p.col;ctx.fillRect(Math.round(p.x),Math.round(p.y),p.sz,p.sz);}ctx.globalAlpha=1;
  const r=REV.cur,t=REV.t,cx=VW/2,cy=VH*.46,inA=Math.min(1,t/.25),outA=t>3?Math.max(0,1-(t-3)/.4):1,a=inA*outA;
  revBackdrop(a,t,cx,cy);
  const k=Math.min(1,t/.45),sc=st==='banner'||st==='chest'?1:(k<1?1-Math.pow(1-k,3)*Math.cos(k*7):1);
  ctx.save();ctx.translate(cx,cy);ctx.scale(sc,sc);ctx.globalAlpha=a;fn(r,t,a);ctx.restore();ctx.globalAlpha=1;
  if(t>.6)txt(TOUCH?'tap to continue':'press Enter',cx,VH-SB-16,{size:9,align:'center',col:'rgba(255,240,210,.8)',lw:2});
};
function revealPreview(){REV.q.length=0;REV.cur=null;const mr=Math.random;Math.random=mulberry32(1427);let it;try{it=Object.assign(genGear('ring',8,'rare',false),{name:'Silver Ring of Might'});}finally{Math.random=mr;}revealItem(it);}
