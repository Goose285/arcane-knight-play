/* =====================================================================
   FAST TRAVEL SCREEN (waystone menu / pause menu)
   ===================================================================== */
function openTravel(){if(state==='title'||WARP)return;openUIMode('travel',state==='paused'?'paused':'play');}
function travelRow(w){
  const on=!!SEC.ways[w.id],go=()=>{if(!on){uiMsg('Not discovered yet');sfx('clang');return;}if(!fastTravel(w.id))uiMsg('Cannot travel now');};
  return {sel:true,h:44,act:go,tap:go,
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=on?'#7df9ff':'#7a5a30';ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      draw(on?SP.waystone:SP.waystoneOff,x0+8,y+8,1.75);
      txt(on?w.name:'???  (undiscovered)',x0+44,y+19,{size:10,col:on?'#fff':'#8a7050',lw:2});
      txt(on?(w.zone?ZONE_NAME[w.zone]:'Overworld'):'Find its stone in the world',x0+44,y+33,{size:8,col:'#e8c070',bold:false});
      uiButton(x0+W-78,y+7,70,30,on?'TRAVEL':'--',on,()=>{UI.sel=si;go();},{tag:'travel:'+w.id,clip:true,size:10,sel:si});}};
}
/* the map of the area you are in, with discovered stones, you, and the tracked quest's objective / way out */
const wayPos=w=>w.zone?zoneArrive(w.zone):{x:(w.tx+.5)*TS,y:(w.ty+.5)*TS};
/* the map of the area you are in (or, when you highlight another stone in the list, the area that stone is in): discovered stones,
   a "YOU ARE HERE" ring, the highlighted destination, and the tracked quest's objective / way out */
function travelZoneNow(){const here=zoneOfPx(P.y),sw=UI.sel!=null?WAYSTONES[UI.sel]:null,dq=sw&&SEC.ways[sw.id]?wayPos(sw):null,dz=dq?zoneOfPx(dq.y):null;return {here,sw,dq,dz,zn:dz||here};}
/* landscape: the map gets its own column (as big as the screen is tall, frame hugging the picture) and the stone list sits beside it */
function travelSplitW(h,maxW){const mz=MINI[travelZoneNow().zn]||MINI.ow;return Math.min(Math.round(maxW*.62),Math.round((h-34)*mz.spr.width/mz.spr.height)+16);}
function travelMapRow(){
  return {sel:false,h:Math.round(Math.min(150,(UI.mapW||360)*.75)+34),
    draw(x0,y,W,h){
      const {here,sw,dq,dz,zn}=travelZoneNow();
      const mz=MINI[zn]||MINI.ow,iw=mz.spr.width,ih=mz.spr.height,s=Math.min((W-16)/iw,(h-34)/ih),dw=Math.round(iw*s),dh=Math.round(ih*s);
      const mx=x0+Math.round((W-dw)/2),my=y+4;UI.mapW=W;
      ctx.fillStyle='#0a0814';ctx.fillRect(x0,y,W,h);ctx.strokeStyle='#3a3668';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);
      ctx.imageSmoothingEnabled=false;ctx.drawImage(mz.spr,mx,my,dw,dh);
      const oy=mz.y0*TS,sc=2*s,at=q=>[mx+q.x/TS*sc,my+(q.y-oy)/TS*sc];
      if(zn==='ow')for(const L of REGION_LABELS){const [lx,ly]=at({x:(L.tx+.5)*TS,y:(L.ty+.5)*TS});txt(L.name,lx,ly,{size:7,align:'center',col:'#fff3d0',lw:3,alpha:.85});}
      for(const w of WAYSTONES)if(SEC.ways[w.id]){const q=wayPos(w);if(zoneOfPx(q.y)===zn){const [qx,qy]=at(q);ctx.fillStyle='#7df9ff';ctx.fillRect(Math.round(qx-2),Math.round(qy-2),5,5);}}
      const pulse=.5+.5*Math.sin(gtime*5);UI.mapInfo={zone:zn,here,dest:dq?sw.id:null,destZone:dz};
      if(here===zn){   // you are here: blinking dot inside a ring
        const [px,py]=at(P);ctx.fillStyle=Math.floor(gtime*3)%2?'#fff':'#ffe14d';ctx.fillRect(Math.round(px-2),Math.round(py-3),5,5);
        ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(px,py-1,8,0,6.283);ctx.stroke();ctx.strokeStyle='#14121e';ctx.lineWidth=1;ctx.beginPath();ctx.arc(px,py-1,10,0,6.283);ctx.stroke();
        txt('YOU',px,py-14,{size:8,align:'center',col:'#fff',lw:3});
        drawMapQuest(mx,my,oy,sc,[mx,my,dw,dh]);}
      if(dq){          // the highlighted destination
        const [qx,qy]=at(dq);
        if(here===zn){const [px,py]=at(P);ctx.save();ctx.globalAlpha=.7;ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.setLineDash([5,4]);ctx.lineDashOffset=-gtime*20;ctx.beginPath();ctx.moveTo(px,py);ctx.lineTo(qx,qy);ctx.stroke();ctx.restore();}
        ctx.strokeStyle='#14121e';ctx.lineWidth=5;ctx.beginPath();ctx.arc(qx,qy,9+3*pulse,0,6.283);ctx.stroke();
        ctx.strokeStyle='#ffe14d';ctx.lineWidth=3;ctx.beginPath();ctx.arc(qx,qy,9+3*pulse,0,6.283);ctx.stroke();ctx.fillStyle='#ffe14d';ctx.fillRect(Math.round(qx-2),Math.round(qy-2),5,5);
        txt(sw.name.replace(' Waystone',''),qx,qy-17,{size:8,align:'center',col:'#ffe14d',lw:3});
      }
      const cur=trkCurrent(),r=cur&&trkRouteNow();
      let cap,col;
      if(dq){cap='Destination: '+sw.name+(dz!==here?'   (you are in '+(ZONE_NAME[here]||'Oakvale')+')':'');col='#ffe14d';}
      else{cap=r?(r.via?'Quest: '+cur.name+'  >  via '+r.via:'Quest: '+cur.name):'No tracked quest objective here';col=r?(r.via?'#7df9ff':'#ffe14d'):'#8a7050';}
      txt(cap,x0+W/2,y+h-8,{size:9,align:'center',col,lw:2,bold:false});
    }};
}
UI_MODES.travel={split:true,splitW:travelSplitW,title:()=>'WORLD MAP',sub:()=>canTravel()?['Step through light to any stone you have found','#7df9ff']:['Map only - you cannot fast travel '+(B?'during a fight':'right now'),'#ffb0a0'],rows(){
  const r=[travelMapRow(),{t:'head',s:'DISCOVERED '+WAYSTONES.filter(w=>SEC.ways[w.id]).length+' / '+WAYSTONES.length}];WAYSTONES.forEach(w=>r.push(travelRow(w)));return r;}};
