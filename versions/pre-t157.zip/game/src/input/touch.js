
/* =====================================================================
   TOUCH CONTROLS (virtual joystick + buttons), layout, HUD
   ===================================================================== */
let TOUCH=false,LEFTY=false;
try{TOUCH=!!(window.matchMedia&&matchMedia('(pointer:coarse)').matches);}catch(e){}
let lastTouchT=-9999;
const btn={};
let cardRects=[],dlgRects={},vign=null;
const TM=16;   // safe margin from the screen edges for thumb controls
function layoutTouch(){
  const r=VW-SR,b=VH-SB;
  const l=SL,m=LEFTY?1:0,X=(dx)=>m?l+dx:r-dx;     // left-handed: thumb buttons + card fan on the left, stick on the right
  const sc=VW<340?.85:1,ra=Math.round(52*sc);   // narrow phones: slightly smaller thumb buttons so everything still fits
  btn.atk ={x:X(TM+ra+Math.round(14*sc)),y:b-TM-ra,r:ra,code:'KeyJ',label:'SHOT'};
  // (no CAST button any more: tap a card to use it. K still casts the highlighted card on a keyboard / pad)
  btn.pause={x:X(24),y:ST+132,r:16,code:'KeyP',label:'II'};
  joy.dx=m?r-82:SL+82;joy.dy=b-82;
}
/* left thumb zone: the stick appears wherever it touches in this x range (the mirror in left-handed mode) */
const zoneF=()=>VW<340?.4:.44;
const joyZone=()=>LEFTY?{x0:VW*(1-zoneF()),x1:VW-SR}:{x0:SL,x1:VW*zoneF()};
/* the card hand on touch: a fan arcing around the SHOT button (tops point outward), swipe along it to cycle, tap a card to cast it */
function fanGeom(HN){
  layoutTouch();
  const A=btn.atk,s=LEFTY?-1:1,ch0=68,zf=zoneF();   // t143u: bigger cards (easier to tap)
  const base=HN>5?15:HN<=4?27:20,tries=[[0,1.15],[2,1.08],[4,1.0],[5,.94],[6,.88]];   // [fewer degrees per card, card scale]: squeeze on narrow screens
  let R=92,step=base,CS=1.12,cw0=HN>5?50:HN<=4?60:54,cw=0,ch=0,start=0,end=290;
  for(let k=0;k<tries.length;k++){
    step=base-tries[k][0];CS=tries[k][1];cw=cw0*CS;ch=ch0*CS;start=end-(HN-1)*step;
    const cosS=Math.cos(start*Math.PI/180),rot0=Math.abs(start*Math.PI/180-1.5*Math.PI)*.45,ext=cw/2*Math.cos(rot0)+ch/2*Math.sin(rot0)+13*Math.abs(cosS);
    const room=LEFTY?(VW*(1-zf-.01)-A.x-ext-3):(A.x-VW*(zf+.01)-ext-3);
    let Rn=room/Math.max(.2,-cosS);
    const rotTop=Math.abs(end*Math.PI/180-1.5*Math.PI)*.45,extY=ch/2*Math.cos(rotTop)+cw/2*Math.sin(rotTop);
    const Rv=(A.y-extY-(btn.pause.y+btn.pause.r+8))/Math.abs(Math.sin(end*Math.PI/180));   // keep the top of the fan below the pause button
    R=clamp(Math.min(Rn,Rv,172),84,172);
    const need=Math.max(88,A.r+ch/2+6);   // also keep the cards clear of the SHOT button (short landscape screens)
    if(Rn>=need&&Rv>=need)break;
  }
  // t154u: a reliable gap between neighbouring cards whatever the hand size / screen: widen the fan first (down to 150 deg), then shrink the cards a little
  const CARD_GAP=10,chord=()=>2*R*Math.sin(step*Math.PI/360);
  if(HN>1&&chord()-cw<CARD_GAP){
    const need=2*Math.asin(Math.min(1,(cw+CARD_GAP)/(2*R)))*180/Math.PI;step=Math.max(step,Math.min(need,(end-(HN>5?125:150))/(HN-1)));
    if(chord()-cw<CARD_GAP){const k=Math.max(.55,(chord()-CARD_GAP)/cw);cw*=k;ch*=k;CS*=k;}
    start=end-(HN-1)*step;}
  const pos=[];
  for(let i=0;i<HN;i++){const th=(start+i*step)*Math.PI/180;
    pos.push({th,ox:s*Math.cos(th),oy:Math.sin(th),cx:A.x+s*R*Math.cos(th),cy:A.y+R*Math.sin(th),rot:s*(th-1.5*Math.PI)*.45});}
  return {pos,R,CS,cw0,ch0,cw,ch,start,end,A,s,gap:HN>1?2*R*Math.sin(step*Math.PI/360)-cw:99};
}
function activeButtons(){
  if(state!=='play')return [];
  if(B)return B.phase==='fight'?[btn.atk]:[];
  if(DLG)return [];
  if(FISH.on)return [];
  return [btn.atk];
}
/* which card is under the finger (rotated rects, topmost first: the selected card is drawn last) */
function cardAt(p){
  if(!B||B.phase!=='fight')return -1;
  const order=[];for(let i=cardRects.length-1;i>=0;i--)if(i!==B.sel)order.push(i);if(cardRects[B.sel])order.unshift(B.sel);
  for(const i of order){const r=cardRects[i];if(!r||!B.hand[i])continue;
    const dx=p.x-(r.cx!=null?r.cx:r.x+r.w/2),dy=p.y-(r.cy!=null?r.cy:r.y+r.h/2),c=Math.cos(-(r.rot||0)),sn=Math.sin(-(r.rot||0)),lx=dx*c-dy*sn,ly=dx*sn+dy*c;
    if(Math.abs(lx)<=r.w/2&&Math.abs(ly)<=r.h/2)return i;}
  return -1;
}
const inCircle=(p,c,m=0)=>Math.hypot(p.x-c.x,p.y-c.y)<=c.r+m;
const inRect=(p,r)=>r&&p.x>=r.x&&p.x<=r.x+r.w&&p.y>=r.y&&p.y<=r.y+r.h;
const touches=new Map();
function lpos(t){const r=cv.getBoundingClientRect();return {x:(t.clientX-r.left)/r.width*VW,y:(t.clientY-r.top)/r.height*VH};}
function tapUI(p){   // taps that act like a click; returns true if consumed
  if(typeof revealBusy==='function'&&revealBusy()&&state==='play'){revealTap();return true;}
  if(ffTap(p))return true;
  if(state==='title'){
    if(titleMenu.gear&&inRect(p,titleMenu.gear)){openSettings('title');return true;}
    const i=titleMenu.rects.findIndex(r=>inRect(p,r));
    if(i>=0){if(titleMenu.sel!==i)titleMenu.confirm=false;titleMenu.sel=i;pressed.Space=true;}
    else if(titleMenu.items.filter(x=>x!=='Fishing Lab').length===1){titleMenu.sel=0;pressed.Space=true;}   // single option: tap anywhere to start
    return true;}
  if(TUT.on&&TUT.skipR&&state==='play'&&!DLG&&!B&&inRect(p,TUT.skipR)){tutFinish(true);return true;}
  if(trkTap(p))return true;
  if(fishTap(p))return true;
  if(isUI())return true;     // handled by drag/tap logic in touchDown / mousedown
  if(state==='paused'){
    pauseTap(p);
    return true;}
  if(DLG){
    if(dlgRects.yes&&inRect(p,dlgRects.yes)){pressed.Enter=true;return true;}
    if(dlgRects.no&&inRect(p,dlgRects.no)){pressed.Escape=true;return true;}
    if(dlgRects.opts){const i=dlgRects.opts.findIndex(r=>inRect(p,r));if(i>=0){DLG.sel=i;pressed.Enter=true;}return true;}
    if(dlgRects.yes)return true;
    pressed.Enter=true;return true;}
  if(B&&B.phase==='reward'){pressed.Space=true;return true;}
  if(B&&B.phase==='fight'){const i=cardAt(p);if(i>=0){B.sel=i;cardUse(i);return true;}}
  return false;
}
/* ---- hold SHOT + swipe up = cast the highlighted card at the nearest enemy (touch) ---- */
let atkTouch=null;const SWIPE_PX=40,HOLD_MS=150;
function castFacingNearest(idx){
  if(!B||B.phase!=='fight')return false;
  if(idx!=null&&B.hand[idx])B.sel=idx;
  if(!B.hand[B.sel])return false;
  const near=nearestEnemy();
  if(near){const a=angTo(pcen(),ecen(near));P.aim=a;P.dir=dirOfAngle(a);}
  const mv=P.moving;P.moving=false;                       // so aim/targeting use the nearest enemy, not the move-direction cone
  const col=(CARDS.find(c=>c.id===B.hand[B.sel])||{}).col||'#fff';
  TEV.up++;useCard(B.sel);P.moving=mv;
  if(near&&B)B.swipeFlash={t:0,tx:near.x,ty:near.y-13,col};
  return true;
}
function tickAtkTouch(){
  const t=atkTouch;if(!t||t.started||t.swiped)return;
  if(B&&B.phase==='fight'&&performance.now()-t.t0>=HOLD_MS){keys.KeyJ=true;pressed.KeyJ=true;t.started=true;}   // normal hold = shot + charge
}
function cycleCard(d){
  if(!B||!B.hand.length)return;const n=B.hand.length;let i=B.sel;
  for(let k=0;k<n;k++){i=(i+d+n)%n;if(B.hand[i])break;}
  if(i!==B.sel){B.sel=i;sfx('select');try{navigator.vibrate&&navigator.vibrate(6);}catch(e){}}
}
/* ---- press a card and swipe up = cast THAT card at the nearest enemy (touch + mouse drag); a plain tap still selects/casts it ---- */
let cardTouch=null;
function cardDown(id,p){
  if(!(B&&B.phase==='fight')||state!=='play')return false;
  const i=cardAt(p);
  if(i>=0){cardTouch={kind:'card',i,sx:p.x,sy:p.y,dy:0,dx:0,cb:0,cur:p,swiped:false};touches.set(id,cardTouch);return true;}
  return false;
}
function swipeMove(id,p){
  if(state==='editor'){edMove(id,p);return;}
  const t0=touches.get(id);
  if(t0&&t0.kind==='card'){
    t0.cur=p;t0.dy=t0.sy-p.y;t0.dx=p.x-t0.sx;
    if(!t0.swiped&&!t0.cyc&&t0.dy>=SWIPE_PX&&t0.dy>=Math.abs(t0.dx)*.8&&B&&B.phase==='fight'){
      t0.swiped=true;castFacingNearest(t0.i);try{navigator.vibrate&&navigator.vibrate(15);}catch(e){}}
    else if(!t0.swiped&&!t0.cyc&&-t0.dy>=SWIPE_PX&&-t0.dy>=Math.abs(t0.dx)*.8&&B&&B.phase==='fight'){t0.swiped=true;discardCard(t0.i);}   // swipe DOWN = discard this card
    else if(!t0.swiped&&B&&B.phase==='fight'&&Math.abs(t0.dx)>=40&&Math.abs(t0.dx)>Math.abs(t0.dy)*1.1)t0.cyc=true;   // dragging along the fan = turn the wheel
    if(t0.cyc&&!t0.swiped&&B&&B.phase==='fight'){
      while(Math.abs(t0.dx-t0.cb)>=30){const d=t0.dx>t0.cb?1:-1;t0.cb+=d*30;cycleCard(d);}}
    return;}
  if(t0&&t0.kind==='ui'){if(Math.abs(p.y-t0.sy)>9)t0.moved=true;if(t0.moved){uiScrollBy(t0.ly-p.y);}t0.ly=p.y;return;}
  if(t0&&(t0.kind==='swipe'||t0.kind==='wtap'||t0.kind==='xtap')){dashSwipe(t0,p);return;}
  const t=t0;if(!t||!t.defer)return;
  t.cur=p;t.dy=t.sy-p.y;
  if(!t.swiped&&t.dy>=SWIPE_PX&&B&&B.phase==='fight'){
    t.swiped=true;B.charge=0;B.charging=false;keys.KeyJ=false;           // swipe cancels the charge shot
    if(B.hand[B.sel]){castFacingNearest();try{navigator.vibrate&&navigator.vibrate(15);}catch(e){}}
  }
}
function touchDown(id,p){
  if(state==='editor'){edDown(id,p);return;}
  if(state==='fishlab'){touches.set(id,{kind:'fl'});flDown(p);return;}
  if(isUI()){touches.set(id,{kind:'ui',sx:p.x,sy:p.y,ly:p.y,moved:false});return;}
  if(TOUCH&&state==='play'&&!B&&inCircle(p,runBtn(),4)){runToggle();touches.set(id,{kind:'tap'});return;}
  if(TOUCH&&state!=='title'&&inCircle(p,btn.pause,6)){expCancel();pressed.KeyP=true;touches.set(id,{kind:'tap'});return;}
  if(cardDown(id,p))return;
  if(tapUI(p)){expCancel();touches.set(id,{kind:'tap'});return;}
  for(const b of activeButtons()){
    if(inCircle(p,b,10))expCancel();   // pressing SHOT / CAST cancels a pending aimed card
    if(inCircle(p,b,10)&&b.code==='KeyJ'&&B&&B.phase==='fight'){   // deferred: tap/hold/swipe decided later
      atkTouch={kind:'btn',code:'KeyJ',defer:true,t0:performance.now(),sx:p.x,sy:p.y,dy:0,cur:p,started:false,swiped:false};touches.set(id,atkTouch);return;}
    if(inCircle(p,b,10)){keys[b.code]=true;pressed[b.code]=true;touches.set(id,{kind:'btn',code:b.code});return;}
  }
  const wt=worldTargetAt(p);          // a tap on an NPC / fishing spot (a short tap = go there; dragging still steers)
  const jz=joyZone();
  if(!joy.on&&p.x>=jz.x0&&p.x<=jz.x1&&p.y>VH*.12){
    joy.on=true;joy.id=id;{const now=performance.now();if(now-RUN.lastJoyT<320&&!runBlocked()){RUN.hold=true;if(typeof TEV!=='undefined')TEV.run++;}RUN.lastJoyT=now;}   // double-tap + hold the stick = run
    joy.bx=clamp(p.x,jz.x0+(LEFTY?0:30),jz.x1-(LEFTY?30:0));joy.by=clamp(p.y,ST+90,VH-SB-56);
    joy.kx=p.x;joy.ky=p.y;joy.x=joy.y=0;touches.set(id,{kind:'joy',wt,sx:p.x,sy:p.y,t0:performance.now(),moved:false});
  } else if(expSelActive())touches.set(id,{kind:'xtap',sx:p.x,sy:p.y,t0:performance.now()});   // experimental cards: a tap in the world casts there
  else if(wt)touches.set(id,{kind:'wtap',wt,sx:p.x,sy:p.y,t0:performance.now(),moved:false});
  else touches.set(id,{kind:'swipe',sx:p.x,sy:p.y,t0:performance.now()});   // a flick on open screen = DASH
}
function joyMove(p){
  {const tt=touches.get(joy.id);if(tt)tt.maxd=Math.max(tt.maxd||0,Math.hypot(p.x-tt.sx,p.y-tt.sy));}
  const R=48;let dx=p.x-joy.bx,dy=p.y-joy.by;const l=Math.hypot(dx,dy);
  if(l>R){joy.bx+=dx/l*(l-R);joy.by+=dy/l*(l-R);dx=p.x-joy.bx;dy=p.y-joy.by;}   // base follows the thumb
  joy.kx=joy.bx+clamp(dx,-R,R);joy.ky=joy.by+clamp(dy,-R,R);
  joy.x=dx/R;joy.y=dy/R;
}
function touchEndId(id){
  if(state==='editor'){edUp(id);return;}
  const t=touches.get(id);if(!t)return;touches.delete(id);
  if(t.kind==='btn'&&t.defer){
    if(t.started){keys.KeyJ=false;released.KeyJ=true;}
    else if(!t.swiped){pressed.KeyJ=true;released.KeyJ=true;}    // quick tap = one normal shot
    if(atkTouch===t)atkTouch=null;
  }
  else if(t.kind==='btn'){keys[t.code]=false;released[t.code]=true;}
  else if(t.kind==='card'){
    if(cardTouch===t)cardTouch=null;
    if(!t.swiped&&!t.cyc&&B&&B.phase==='fight'&&B.hand[t.i]){B.sel=t.i;cardUse(t.i);}   // plain tap = select + cast, as before
  }
  else if(t.kind==='fl'){flUp();}
  else if(t.kind==='ui'){if(!t.moved)uiTap({x:t.sx,y:t.sy});}
  else if(t.kind==='joy'){RUN.hold=false;joy.on=false;joy.x=joy.y=0;joy.id=null;if(t.wt&&!t.moved&&performance.now()-t.t0<500)setGoto(t.wt);
    else if(expSelActive()&&(t.maxd||0)<14&&performance.now()-t.t0<420)expTapAt(t.sx,t.sy);}   // a quick tap in the stick zone also aims
  else if(t.kind==='xtap'){if(!t.dashed&&expSelActive()&&performance.now()-t.t0<520)expTapAt(t.sx,t.sy);}
  else if(t.kind==='wtap'){if(t.wt&&!t.moved&&performance.now()-t.t0<500)setGoto(t.wt);}
}
function releaseAllTouch(){for(const id of [...touches.keys()])touchEndId(id);joy.on=false;joy.x=joy.y=0;}
cv.addEventListener('touchstart',e=>{e.preventDefault();TOUCH=true;lockLandscape();lastTouchT=performance.now();ensureAudio();for(const t of e.changedTouches)touchDown(t.identifier,lpos(t));},{passive:false});
cv.addEventListener('touchmove',e=>{e.preventDefault();for(const t of e.changedTouches){const q=lpos(t);{const tt=touches.get(t.identifier);if(tt&&tt.wt&&Math.hypot(q.x-tt.sx,q.y-tt.sy)>14)tt.moved=true;}if(joy.on&&t.identifier===joy.id)joyMove(q);swipeMove(t.identifier,q);}},{passive:false});
const tEnd=e=>{e.preventDefault();lastTouchT=performance.now();ensureAudio();for(const t of e.changedTouches)touchEndId(t.identifier);};
cv.addEventListener('touchend',tEnd,{passive:false});cv.addEventListener('touchcancel',tEnd,{passive:false});
['gesturestart','gesturechange','gestureend'].forEach(n=>document.addEventListener(n,e=>e.preventDefault()));
document.addEventListener('touchmove',e=>e.preventDefault(),{passive:false});
document.addEventListener('dblclick',e=>e.preventDefault());
document.addEventListener('contextmenu',e=>e.preventDefault());
cv.addEventListener('mousedown',e=>{if(performance.now()-lastTouchT<900)return;ensureAudio();const q=lpos(e);if(state==='editor'){edDown('mouse',q);return;}if(state==='fishlab'){touches.set('mouse',{kind:'fl'});flDown(q);return;}if(isUI())uiTap(q);else if(!cardDown('mouse',q)){if(tapUI(q))expCancel();else if(!(B&&expSelActive()&&expTapAt(q.x,q.y)))worldTap(q);}});
addEventListener('mousemove',e=>{if(state==='editor'){edMove('mouse',lpos(e));return;}if(state==='paused'){try{PAUSE.ptr=lpos(e);}catch(x){}}if(touches.has('mouse'))swipeMove('mouse',lpos(e));if(B&&B.xsel>=0){const q=lpos(e);B.xptr={x:q.x+cam.x,y:q.y+cam.y};}});
addEventListener('mouseup',()=>{if(state==='editor'){edUp('mouse');return;}if(touches.has('mouse'))touchEndId('mouse');});
addEventListener('blur',releaseAllTouch);
addEventListener('orientationchange',()=>setTimeout(resize,120));

function drawSwipeHint(){
  const t=atkTouch,b=btn.atk;
  if(B&&B.swipeFlash){const f=B.swipeFlash;f.t+=1/60;if(f.t>.4)B.swipeFlash=null;else{
    ctx.save();ctx.globalAlpha=1-f.t/.4;ctx.strokeStyle=f.col;ctx.lineWidth=3;
    ctx.setLineDash([]);ctx.beginPath();ctx.arc(f.tx-cam.x,f.ty-cam.y,8+f.t*60,0,6.283);ctx.stroke();ctx.restore();}}   // a small ripple where the cast lands (no beam)
  const ct=cardTouch;
  if(ct&&B&&B.phase==='fight'&&!ct.swiped&&ct.dy>10){   // card swipe: aim line to the target + up arrows over the card
    const cid=B.hand[ct.i],cc=cid&&CARDS.find(q=>q.id===cid),prog=clamp(ct.dy/SWIPE_PX,0,1),near=nearestEnemy(),col=cc?cc.col:'#fff';
    if(near){ctx.save();ctx.globalAlpha=.35+.5*prog;ctx.strokeStyle=col;ctx.lineWidth=2;
      ctx.beginPath();ctx.arc(near.x-cam.x,near.y-13-cam.y,eRad(near)+6+Math.sin(gtime*10)*2,0,6.283);ctx.stroke();ctx.restore();}
    const r=cardRects[ct.i];if(r){ctx.save();ctx.globalAlpha=.5+.5*Math.abs(Math.sin(gtime*7));ctx.strokeStyle=prog>=1?'#7dffa0':'#fff';ctx.lineWidth=3;
      for(let i=0;i<2;i++){const ay=r.y-8-i*8-prog*4,cx=r.cx!=null?r.cx:r.x+r.w/2;ctx.beginPath();ctx.moveTo(cx-9,ay+6);ctx.lineTo(cx,ay-2);ctx.lineTo(cx+9,ay+6);ctx.stroke();}ctx.restore();}
  }
  if(ct&&B&&B.phase==='fight'&&!ct.swiped&&ct.dy<-10&&B.hand[ct.i]){   // swipe down: red down-arrows + DISCARD
    const prog=clamp(-ct.dy/SWIPE_PX,0,1),r=cardRects[ct.i];
    if(r){const cx=r.cx!=null?r.cx:r.x+r.w/2,cy=(r.cy!=null?r.cy:r.y+r.h/2)+r.h/2;ctx.save();ctx.globalAlpha=.5+.5*Math.abs(Math.sin(gtime*7));ctx.strokeStyle=prog>=1?'#ff8a7a':'#fff';ctx.lineWidth=3;
      for(let i=0;i<2;i++){const ay=cy+6+i*8+prog*4;ctx.beginPath();ctx.moveTo(cx-9,ay-6);ctx.lineTo(cx,ay+2);ctx.lineTo(cx+9,ay-6);ctx.stroke();}
      ctx.restore();txt('DISCARD',cx,cy+34,{size:9,align:'center',col:prog>=1?'#ff8a7a':'#fff',lw:3});}
  }
  if(!t||!B||B.phase!=='fight'||t.swiped)return;
  const id=B.hand[B.sel],c=id&&CARDS.find(q=>q.id===id);if(!c)return;
  const prog=clamp(t.dy/SWIPE_PX,0,1),held=performance.now()-t.t0;
  if(held<90&&prog<.1)return;
  const near=nearestEnemy();
  if(prog>.12&&near){   // a ring on the target as the swipe begins (no dashed line)
    ctx.save();ctx.globalAlpha=.35+.5*prog;ctx.strokeStyle=c.col;ctx.lineWidth=2;
    ctx.beginPath();ctx.arc(near.x-cam.x,near.y-13-cam.y,eRad(near)+6+Math.sin(gtime*10)*2,0,6.283);ctx.stroke();ctx.restore();}
  // up-arrows above the SHOT button (the highlighted card pops out of the fan)
  ctx.save();ctx.globalAlpha=.5+.5*Math.abs(Math.sin(gtime*7));ctx.strokeStyle=prog>=1?'#7dffa0':'#fff';ctx.lineWidth=3.5;
  for(let i=0;i<2;i++){const ay=b.y-b.r-14-i*9-prog*10;ctx.beginPath();ctx.moveTo(b.x-10,ay+6);ctx.lineTo(b.x,ay-3);ctx.lineTo(b.x+10,ay+6);ctx.stroke();}
  ctx.restore();
}
function drawTouch(){
  layoutTouch();
  // joystick
  const jx=joy.on?joy.bx:joy.dx,jy=joy.on?joy.by:joy.dy;
  ctx.globalAlpha=joy.on?.45:.22;ctx.fillStyle='#10102a';ctx.beginPath();ctx.arc(jx,jy,52,0,6.283);ctx.fill();
  ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke();
  ctx.globalAlpha=joy.on?.35:.15;ctx.beginPath();ctx.arc(jx,jy,26,0,6.283);ctx.stroke();
  ctx.globalAlpha=joy.on?.8:.35;ctx.fillStyle='#dfe8ff';ctx.beginPath();ctx.arc(joy.on?joy.kx:jx,joy.on?joy.ky:jy,22,0,6.283);ctx.fill();
  ctx.globalAlpha=1;
  const bs=[...activeButtons()];
  if(state==='play')bs.push(btn.pause);
  for(const b of bs){
    const down=keys[b.code]||(b===btn.atk&&atkTouch);
    ctx.globalAlpha=down?.9:.55;ctx.fillStyle=b===btn.atk?'#3a2a08':'#14102e';ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,6.283);ctx.fill();
    ctx.strokeStyle=down?'#fff':(b===btn.atk?'#ffd23f':'#cfd0ff');ctx.lineWidth=2.5;ctx.stroke();ctx.globalAlpha=1;
    if(b===btn.atk&&(B?B.charge:WCH.t)>.2){const f=Math.min(1,B?B.charge:WCH.t);ctx.strokeStyle=f>=1?'#fff':'#7df9ff';ctx.lineWidth=5;ctx.beginPath();ctx.arc(b.x,b.y,b.r+5,-Math.PI/2,-Math.PI/2+f*6.283);ctx.stroke();}
    if(b===btn.pause){ctx.fillStyle='#fff';ctx.fillRect(b.x-5,b.y-6,4,12);ctx.fillRect(b.x+1,b.y-6,4,12);}
    else if(b===btn.atk){ctx.fillStyle='#ffe14d';ctx.beginPath();ctx.arc(b.x,b.y-8,12,0,6.283);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(b.x,b.y-8,5.5,0,6.283);ctx.fill();txt('SHOT',b.x,b.y+29,{size:11,align:'center',lw:3});}
    else txt(b.label,b.x,b.y+5,{size:b.r>=30?13:10,align:'center',lw:3});
  }
  drawSwipeHint();
}
