/* =====================================================================
   t153u/t154u: OAKVALE RIVERSIDE QUARTER - real Blacksmith (Brum's Forge) and a big tavern (the Oakvale Tap), plus cottages for
   villagers who had no home. t154u moved it all across the bridge (east of the river), where there is real room: the old west strip
   was squeezed between the Inn, the pet pen and the map edge. The west is left as it was (Inn + pet pen untouched).
   Buildings are open-front: the doorway is a floor tile, so you walk straight in (no warp).
   ===================================================================== */
(function t153Town(){
  try{if(typeof SMITH_SHOP!=='undefined')SMITH_SHOP.west=true;if(typeof TAVERN!=='undefined')TAVERN.west=true;}catch(e){}   // t148 carved shops stay off
  const TSZ=()=>typeof TS==='number'?TS:32;
  const tx=x=>(typeof OX==='number'?OX:0)+x,ty=y=>(typeof OY==='number'?OY:0)+y;
  function put(x,y,id){const X=tx(x),Y=ty(y);if(Y>=0&&Y<MH&&X>=0&&X<MW)map[Y][X]=id;}
  function get(x,y){const X=tx(x),Y=ty(y);return (Y>=0&&Y<MH&&X>=0&&X<MW)?map[Y][X]:-1;}
  // open-front building: roof row, walls, floor; the doorway on the south wall is FLOOR so the player can walk in
  function shop(x0,y0,w,h,doorX){
    for(let y=y0;y<y0+h;y++)for(let x=x0;x<x0+w;x++){
      if(y===y0)put(x,y,T.R);else if(y===y0+h-1)put(x,y,x===doorX?T.F:T.H);else if(x===x0||x===x0+w-1)put(x,y,T.H);else put(x,y,T.F);}
    return {x0,y0,w,h,door:{tx:tx(doorX),wy:ty(y0+h-1)}};
  }
  function cottage(x0,y,w){for(let x=x0;x<x0+w;x++){put(x,y,T.R);put(x,y+1,T.RL);put(x,y+2,T.H);}const dx=x0+(w>>1);put(dx,y+2,T.D);put(dx,y+3,T.P);return {tx:tx(dx),ty:ty(y+2)};}
  const Q={x0:27,x1:59,y0:45,y1:59};   // the quarter (local tiles)
  const STATE={ready:false};
  function clearQuarter(){
    for(let y=Q.y0;y<=Q.y1;y++)for(let x=Q.x0;x<=Q.x1;x++){const t=get(x,y);if(t!==T.W&&t!==T.P&&t!==-1)put(x,y,T.G);}
    for(let y=44;y<=58;y++){put(31,y,T.P);put(32,y,T.P);}        // Riverside Lane: down from the east road
    for(let x=31;x<=58;x++){put(x,53,T.P);put(x,58,T.P);}       // two cross streets
    for(const [x,y] of [[33,54],[46,54],[57,52],[33,59],[46,59],[57,59]])put(x,y,T.Z);   // street lamps (light at night)
    if(T.PLB!=null)for(const [x,y] of [[29,46],[29,50],[46,46],[46,49],[57,46],[39,54]])put(x,y,T.PLB);
    TOWN.x1=Math.max(TOWN.x1,tx(Q.x1+1)*TSZ());TOWN.y1=Math.max(TOWN.y1,ty(Q.y1+1)*TSZ());
    // any wild monster whose home was in the old woods here moves just outside the new quarter
    try{for(const e of enemies){if(inTownPx(e.hx,e.hy)||inTownPx(e.x,e.y)){e.hx=e.x=tx(Q.x1+4)*TSZ();e.hy=e.y=Math.min(e.y,ty(Q.y1)*TSZ());}}}catch(e){}
  }
  function buildSmith(){
    const b=shop(48,45,8,7,51);   // 8x7: furnace, anvil, weapon racks
    put(49,46,T.FRN);put(50,46,T.FRN);put(51,48,T.ANV);put(54,46,T.BT);put(54,47,T.BT);put(53,49,T.BT);
    for(let y=52;y<=53;y++)put(51,y,T.P);
    const n=NPCS.find(q=>q.name==='Blacksmith Brum');
    if(n){n.x=(tx(52)+.5)*TSZ();n.y=(ty(48)+.6)*TSZ();n.hx=n.x;n.hy=n.y;n.smith=true;if(n.rt)n.rt.work={x:n.x,y:n.y};
      n.lines=['Heat and hammer - that is the Brum way.','Need a rod for the river, or a sharper card? The forge is open.','Stay clear of the furnace - she bites hotter than any goblin.'];}
    let sg=NPCS.find(q=>q.name==="Brum's Forge Sign");if(!sg){sg={name:"Brum's Forge Sign",spr:'sign',sign:true};NPCS.push(sg);}
    sg.x=(tx(53)+.5)*TSZ();sg.y=(ty(52)+.4)*TSZ();sg.lines=["BRUM'S FORGE","Open morning to dusk. Rods, cards, and honest steel."];
    SMITH_SHOP.ready=true;SMITH_SHOP.west=true;SMITH_SHOP.door=b.door;return b;
  }
  function buildTavern(){
    const b=shop(34,45,12,8,39);   // 12x8 (interior 10x6 = 4x the old 5x3 room)
    for(let x=36;x<=42;x++)put(x,47,T.BT);                         // the long bar
    put(35,46,T.Z);put(44,46,T.Z);                                 // hanging lanterns
    put(43,46,T.FRN);put(44,47,T.FRN);                             // the big stone hearth (east wall)
    for(const [x,y] of [[36,49],[38,50],[41,49],[43,50],[36,51],[43,48]])put(x,y,T.BT);   // tables (the aisle up from the door stays clear)
    put(39,53,T.P);
    let mara=NPCS.find(q=>q.name==='Mara the Tapster');if(!mara){mara={name:'Mara the Tapster',spr:'inn',lines:[]};NPCS.push(mara);}
    delete mara.inn;mara.tavern=true;mara.oakTap=true;
    mara.x=(tx(39)+.5)*TSZ();mara.y=(ty(48)+.5)*TSZ();mara.hx=mara.x;mara.hy=mara.y;   // in front of the bar, easy to reach
    mara.lines=['Welcome to the Oakvale Tap - stew on the fire, rumors on the house.','Try the River Stew - it puts a shine of luck on your next casts.',
      'Dawn and dusk, the big ones bite. Night brings the glowfish.','Pull up a stool. First bowl is honest gold - not free, mind.'];
    let sg=NPCS.find(q=>q.name==='Oakvale Tap Sign'||q.name==='Tavern Sign');if(!sg){sg={spr:'sign',sign:true};NPCS.push(sg);}
    sg.name='Oakvale Tap Sign';sg.x=(tx(41)+.5)*TSZ();sg.y=(ty(53)+.4)*TSZ();sg.lines=['THE OAKVALE TAP','Hot stew, cold ale, warm rumors. Noon till late.'];
    TAVERN.ready=true;TAVERN.west=true;TAVERN.door=b.door;TAVERN.box={x0:tx(34),y0:ty(45),x1:tx(45),y1:ty(52)};
    TAVERN.stew={gold:18,name:'River Stew',buff:'luck',dur:120,msg:'The stew warms you - fishing luck up for a while!'};
    return b;
  }
  // t154u: villagers who had no house of their own get a cottage on Cottage Row (they head home at night like the shopkeepers)
  const HOMELESS=['Old Tom','Gardener Lyn','Fisher Tobin','Elder Orin'];
  const HOMES={};
  function buildCottages(){
    const xs=[34,41,48,54];
    HOMELESS.forEach((nm,i)=>{const d=cottage(xs[i],55,5);HOMES[nm]=d;
      const n=NPCS.find(q=>q.name===nm);if(n)n.home={x:(d.tx+.5)*TSZ(),y:(d.ty+1.35)*TSZ()};
      if(!NPCS.some(q=>q.name===nm+"'s Cottage"))NPCS.push({name:nm+"'s Cottage",spr:'sign',sign:true,x:(d.tx+1.5)*TSZ(),y:(d.ty+1.4)*TSZ(),lines:[nm+"'s cottage."]});});
  }
  function openTavern(npc){
    const stew=TAVERN.stew||{gold:18,name:'River Stew',buff:'luck',dur:120};
    DLG={name:'MARA THE TAPSTER',lines:npc.lines||['Welcome to the Oakvale Tap!'],i:0,c:0,yes:'BUY STEW  '+stew.gold+'G',no:'JUST CHAT',
      choice(){if(P.gold<stew.gold){toast('Need '+stew.gold+' gold for a bowl.',2,'#ffb0a0');sfx('clang');return;}
        P.gold-=stew.gold;sfx('coin');if(typeof applyMealBuff==='function')applyMealBuff(stew.buff,stew.dur,stew.name);else toast(stew.msg||'Delicious!',2.4,'#ffe14d');},
      noAct(){DLG=null;}};
  }
  {const _od=openDlg;openDlg=function(npc){if(npc&&npc.oakTap){try{if(typeof releaseAllTouch==='function')releaseAllTouch();}catch(e){}sfx('talk');openTavern(npc);return;}return _od.apply(this,arguments);};}
  function run(){
    if(STATE.ready||typeof map==='undefined'||!map||!map.length||typeof TOWN==='undefined'||typeof T==='undefined'||T.ANV==null)return;
    try{clearQuarter();buildSmith();buildTavern();buildCottages();if(typeof clearStrayForge==='function')clearStrayForge();STATE.ready=true;
      if(typeof ROUT!=='undefined'&&ROUT.on&&typeof rtInit==='function')rtInit();}
    catch(e){try{console.error('t153 town',e);}catch(_){}}
  }
  // routines: a cottage owner's home is their own cottage door
  if(typeof ROUT_NAMES!=='undefined'){for(const nm of ['Gardener Lyn','Fisher Tobin'])if(!ROUT_NAMES.includes(nm))ROUT_NAMES.push(nm);}
  if(typeof rtInit==='function'){const _ri=rtInit;rtInit=function(){_ri.apply(this,arguments);try{for(const n of ROUT.list)if(n.home&&n.rt)n.rt.home={x:n.home.x,y:n.home.y};}catch(e){}};}
  setTimeout(run,90);setTimeout(run,450);setTimeout(run,1200);
  window.__t153Town=run;window.__t154Homes=HOMES;window.__t154Quarter=Q;
})();
