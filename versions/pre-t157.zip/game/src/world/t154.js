/* =====================================================================
   t154u: SKELETONS STAY OUT OF GREENMEADOW + the DAILY CHALLENGE CHIP (its own little widget, apart from the quest tracker)
   ===================================================================== */
function inGreenmeadow(x,y){try{const tx=Math.floor(x/TS),ty=Math.floor(y/TS);return zoneOfTy(ty)==='ow'&&areaName(tx,ty)==='GREENMEADOW';}catch(e){return false;}}
const SKEL_GUARD={t:0,forest:null};
function skelForestSpot(){   // a Whisperwood tile for a stray skeleton to go home to
  if(SKEL_GUARD.forest&&SKEL_GUARD.forest.length)return SKEL_GUARD.forest[(Math.random()*SKEL_GUARD.forest.length)|0];
  const out=[];for(let y=0;y<MH;y+=2)for(let x=0;x<MW;x+=2){if(zoneOfTy(y)!=='ow'||solidTile(x,y))continue;try{if(regions.forest(x,y)&&!inTownPx(x*TS+16,y*TS+16)&&areaName(x,y)!=='GREENMEADOW')out.push({x:x*TS+16,y:y*TS+24});}catch(e){}}
  SKEL_GUARD.forest=out;return out.length?out[(Math.random()*out.length)|0]:null;
}
function skelGuardTick(force){
  for(const e of enemies){if(e.type!=='knight'||e.def&&e.def.boss)continue;
    const homeBad=inGreenmeadow(e.hx,e.hy),hereBad=inGreenmeadow(e.x,e.y);
    if(homeBad){const s=skelForestSpot();if(s){e.hx=s.x;e.hy=s.y;if(e.terr)e.terr=null;}}
    if(hereBad&&(force||!(B&&B.ens&&B.ens.includes(e)))){e.x=e.hx;e.y=e.hy;e.engaged=false;e.chasing=false;e.path=null;}}
}
function updateSkelGuard(dt){if(state!=='play')return;SKEL_GUARD.t-=dt;if(SKEL_GUARD.t>0)return;SKEL_GUARD.t=1;try{skelGuardTick(false);}catch(e){}}
{const _up=update;update=function(dt){const r=_up.apply(this,arguments);updateSkelGuard(dt);return r;};}
setTimeout(()=>{try{skelGuardTick(true);}catch(e){}},400);setTimeout(()=>{try{skelGuardTick(true);}catch(e){}},1500);

/* ---- DAILY CHIP: a small leather pill under the quest tracker (or in its place), tap opens the Daily hub ---- */
let DAILY_CHIP=null;
function drawDailyChip(){
  DAILY_CHIP=null;
  if(typeof trkVisible!=='function'||!trkVisible()||B||(typeof metaOff==='function'&&metaOff())||typeof DAILY==='undefined'||!DAILY.ch||!DAILY.ch.length)return;
  if(typeof introQuiet==='function'&&introQuiet())return;
  const done=DAILY.ch.filter(c=>c.done).length,n=DAILY.ch.length,cur=DAILY.ch.find(c=>!c.done);
  const px=SL+8,py=TRK.rect?TRK.rect.y+TRK.rect.h+6:ST+8+66,w=TRK.rect?TRK.rect.w:150,h=Math.round(scaleText(9)+12);
  panel(px,py,w,h,{border:done===n?'#7dffa0':'#c89a4a',fill:'#2a1a10',inner:'#4a2e18'});
  let s=cur?'DAILY '+done+'/'+n+'  '+dailyText(cur)+'  '+Math.min(cur.p,cur.n)+'/'+cur.n:'DAILY '+done+'/'+n+'  all done!';
  ctx.font='bold '+scaleText(9)+'px "Courier New",monospace';while(s.length>6&&ctx.measureText(s).width>w-12)s=s.slice(0,-2);
  txt(s,px+6,py+h-6,{size:9,col:done===n?'#7dffa0':'#ffe14d',lw:2});
  DAILY_CHIP={x:px,y:py,w,h};
}
{const _dt=drawTracker;drawTracker=function(){_dt.apply(this,arguments);try{drawDailyChip();}catch(e){}};}
