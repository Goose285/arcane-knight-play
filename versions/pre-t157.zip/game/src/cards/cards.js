
/* ---- collection / deck / shop state (saved in localStorage) ---- */
let COL={},DECK=[],SHOP={stock:[],kills:0,sold:{}},GUAR_GOT={};   // GUAR_GOT: guaranteed-reward milestones already paid out (saved)
function resetCards(){
  COL={sword:4,fire:4,shield:3,heal:1,lance:3};DECK=[];
  for(const id in COL)for(let i=0;i<COL[id];i++)DECK.push(id);          // starter deck = the five basic cards (17)
  SHOP={stock:[],kills:kills||0,sold:{}};GUAR_GOT={};
}
const deckCount=id=>DECK.filter(x=>x===id).length;
const deckLimit=id=>Math.min(COL[id]||0,RAR[CARD[id].rar].max,id==='heal'?HEAL_MAX_DECK:99);   // healing is capped in the deck
function fixDeck(){                                                       // sanitize after load
  for(const id of Object.keys(COL))if(!CARD[id]||!(COL[id]>0))delete COL[id];
  const seen={};DECK=DECK.filter(id=>CARD[id]&&((seen[id]=(seen[id]||0)+1)<=deckLimit(id)));
  if(DECK.length>DECK_MAX)DECK.length=DECK_MAX;
  if(DECK.length<DECK_MIN){for(const id of ['sword','fire','shield','heal','lance'])while(DECK.length<DECK_MIN&&(COL[id]||0)>deckCount(id)&&deckCount(id)<deckLimit(id))DECK.push(id);}
}
function packCards(){return {col:COL,deck:DECK,shop:SHOP,g:GUAR_GOT};}
function unpackCards(s){
  resetCards();
  if(s&&s.col&&typeof s.col==='object'){COL={};for(const k in s.col)if(CARD[k])COL[k]=Math.max(0,Math.min(9,s.col[k]|0));}
  if(s&&Array.isArray(s.deck))DECK=s.deck.filter(id=>CARD[id]);
  if(s&&s.shop&&Array.isArray(s.shop.stock))SHOP={stock:s.shop.stock.filter(id=>CARD[id]),kills:s.shop.kills|0,sold:s.shop.sold||{}};
  if(s&&s.g&&typeof s.g==='object')GUAR_GOT=Object.assign({},s.g);
  fixDeck();
}
function pickRarity(w){let t=0;for(const k in w)t+=w[k];let r=Math.random()*t;for(const k in w){r-=w[k];if(r<=0)return k;}return 'common';}
function randCardOf(rar){const l=CARDS.filter(c=>c.rar===rar);return l[RI(0,l.length-1)];}
function shopRoll(){
  const st=[];let guard=0;
  while(st.length<4&&guard++<60){const c=randCardOf(pickRarity({common:38,uncommon:34,rare:22,epic:6}));if(c&&!st.includes(c.id))st.push(c.id);}
  SHOP={stock:st,kills:kills,sold:{}};
}
function ensureShop(){if(!SHOP.stock.length||kills-SHOP.kills>=5)shopRoll();}   // stock rotates every 5 kills
/* enemy drops: occasional, rarer cards from higher-level foes */
function rollDrop(lv){
  if(Math.random()>Math.min(.34,.11+lv*.008)*storyDrop())return null;
  const rar=pickRarity({common:Math.max(10,60-3.5*lv),uncommon:30,rare:6+1.7*lv,epic:.5+.55*lv});
  return randCardOf(rar);
}
function grantCard(id,at){
  const c=CARD[id];if(!c)return false;
  if((COL[id]||0)>=RAR[c.rar].own){const gv=Math.round(RAR[c.rar].price*.4);P.gold+=gv;if(B&&at)floatText(at.x,at.y-50,`DUPE +${gv}G`,'#ffd23f',11);return false;}
  COL[id]=(COL[id]||0)+1;
  const room=DECK.length<DECK_MAX&&deckCount(id)<deckLimit(id);if(room)DECK.push(id);
  if(B&&at)floatText(at.x,at.y-52,'NEW CARD!',RAR[c.rar].col,13);
  if(typeof revealCard==='function')revealCard(id);
  toast(`CARD FOUND: ${c.name} (${RAR[c.rar].n})${room?' - added to deck':''}`,3,RAR[c.rar].col);sfx('select');
  return true;
}
/* guaranteed card rewards for the hard-to-find cards (the normal drop chance still applies on top).
   Quests carry theirs in data/quests.js; the rest are paid here once per save. Mapping (also in docs): */
const GUAR_BOSS={dragon:'reflect',rimegar:'wolf'},GUAR_SPAWNER='decoy';
function guarGrant(key,id,at){if(GUAR_GOT[key]||!CARD[id])return false;GUAR_GOT[key]=true;grantCard(id,at);return true;}
function guarOnBossKill(e){const id=GUAR_BOSS[e.type];if(id&&!e.rush)guarGrant('boss:'+e.type,id,{x:e.x,y:e.y});}
const aimPos=()=>B&&B.decoy&&B.decoy.hp>0?{x:B.decoy.x,y:B.decoy.y-12}:pcen();   // enemies aim at the decoy while it lives

/* ---- deck draw pile (gauge draws from the DECK, not a global pool) ---- */
function drawFromDeck(){
  if(!B.pile||!B.pile.length){B.pile=shuffle(DECK.slice());if(!B.pile.length)B.pile=['sword','fire','heal'];}
  return B.pile.pop();
}
function dealHand(){expDealInit();}   // the opening hand; after that expDealTick adds one card every 2.5s (no full-hand refresh any more)
function initExtras(){Object.assign(B,{clk:0,pile:null,lastCard:null,haste:0,ward:0,reflect:0,tstop:0,sanct:0,sanctT:0,ghost:0,channel:null,wolf:null,decoy:null,clouds:[],meteors:[],bolts:[]});}

/* ---- helpers ---- */
function foesIn(x,y,r,needLos=true){
  const o=[];for(const e of B.ens){if(e.dying)continue;const c=ecen(e);
    if(Math.hypot(c.x-x,c.y-y)<r+eRad(e)*.5&&(!needLos||losW({x,y},7,c,7)))o.push(e);}
  return o;
}
function hurt(e,d,k){if(!e.engaged&&liveEns().length>=MAX_ENG)return false;return damageEnemy(e,d,k);}
function stunEnemy(e,dur,kind='stun'){
  if(e.dying)return false;const c=ecen(e);
  if(e.def.freezeImmune){e.chill=Math.max(e.chill,Math.max(2,dur*1.5));floatText(c.x,c.y-(e.def.big?60:34),kind==='time'?'SLOWED':'RESIST','#d8c8ff',13);burst(c.x,c.y,'#d8c8ff',8,90,.5);return false;}
  e.stun=Math.max(e.stun||0,dur);e.stunK=kind;
  if(e.st==='windup'){B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);e.st='idle';e.cur=null;e.charge=0;e.atkCd=Math.max(e.atkCd,.7);}
  e.guard=0;floatText(c.x,c.y-34,kind==='time'?'STOPPED!':'STUNNED!',kind==='time'?'#ffe9a0':'#ffe14d',13);
  return true;
}
function bodyBlocked(x,y){for(const [cx,cy] of [[x-6,y-7],[x+6,y-7],[x-6,y],[x+6,y]])if(solidTile(Math.floor(cx/TS),Math.floor(cy/TS)))return true;if(x<TS||y<TS||x>MW*TS-TS||y>MH*TS-4)return true;return NPCS.some(n=>Math.abs(n.x-x)<13&&Math.abs(n.y-y)<11);}
function stepDest(a,dist){let x=P.x,y=P.y;const dx=Math.cos(a),dy=Math.sin(a);for(let d=4;d<=dist;d+=4){const nx=P.x+dx*d,ny=P.y+dy*d;if(bodyBlocked(nx,ny))break;x=nx;y=ny;}return {x,y};}
// nearest living foe within 1.6x of a reach (centre distance, minus body) with clear line of sight; gap>0 = outside swing reach
function swordLock(reach,from){
  const o=from||pcen();let best=null,bd=1e9;
  for(const e of B.ens){if(e.dying)continue;const c=ecen(e),d=Math.hypot(c.x-o.x,c.y-o.y);
    if(d<=reach*1.6+eRad(e)&&d<bd&&losW(o,7,c,7)){bd=d;best=e;}}
  return best?{e:best,a:angTo(o,ecen(best)),d:bd,gap:bd-(reach+eRad(best))}:null;
}
function dashAngle(){return P.moving&&!B.xt?P.aim:fireAngle();}
function doShadowStep(a,dist=130){
  const from={x:P.x,y:P.y},to=stepDest(a,dist);
  B.bolts.push({k:'shadow',x0:from.x,y0:from.y-12,x1:to.x,y1:to.y-12,t:0,dur:.5});
  P.x=to.x;P.y=to.y;P.dir=dirOfAngle(a);P.aim=a;const sx=skillRank('shadow')>=3?.5:0;B.inv=Math.max(B.inv,.9+sx);B.ghost=.9+sx;sfx('whoosh');
  for(let i=0;i<12;i++){const u=i/11;B.parts.push({x:lerp(from.x,to.x,u),y:lerp(from.y,to.y,u)-R(4,18),vx:R(-10,10),vy:-R(5,30),t:0,life:.6,col:i%2?'#8a6bd6':'#3a2a66',sz:3});}
  // t154u: SHADOW CURSE - the foe nearest to where you land (or any you pass through) is hexed for 5s: takes +30% damage, deals -30%
  {let hit=0;for(const e of B.ens){if(e.dying||e.joinT>0)continue;const c=ecen(e),ab={x:to.x-from.x,y:to.y-from.y},L2=ab.x*ab.x+ab.y*ab.y||1,u=clamp(((c.x-from.x)*ab.x+(c.y-from.y)*ab.y)/L2,0,1),
      d=Math.hypot(c.x-(from.x+ab.x*u),c.y-(from.y+ab.y*u));if(d<=eRad(e)+56){e.weak=5;hit++;floatText(c.x,c.y-36,'SHADOW CURSE','#b69cff',12);burst(c.x,c.y,'#6a4ab0',12,80,.5);}}
   if(!hit){let best=null,bd=120;for(const e of B.ens){if(e.dying||e.joinT>0)continue;const c=ecen(e),d=Math.hypot(c.x-to.x,c.y-to.y);if(d<bd){bd=d;best=e;}}
     if(best){best.weak=5;const c=ecen(best);floatText(c.x,c.y-36,'SHADOW CURSE','#b69cff',12);burst(c.x,c.y,'#6a4ab0',12,80,.5);}}}
  return {from,to};
}
function newCloud(x,y,r,dmg,storm){B.clouds.push({x,y,r,dmg,storm,t:0,dur:5,tk:.25});sfx('poison');}
function newMeteor(x,y,dmg,r=62,dur=1.1){B.meteors.push({x,y,r,dmg,t:0,dur,hit:false});}
function bolt(pts,dur=.45){B.bolts.push({k:'zap',pts,t:0,dur});}
function chainFrom(first,pow,m,maxHits=4,jump=150){
  const hit=[first],pts=[pcen(),ecen(first)];let cur=first;
  while(hit.length<maxHits){
    const cc=ecen(cur);let best=null,bd=1e9;
    for(const o of B.ens){if(o.dying||hit.includes(o))continue;const oc=ecen(o),d=Math.hypot(oc.x-cc.x,oc.y-cc.y);if(d<jump&&d<bd&&losW(cc,7,oc,7)){bd=d;best=o;}}
    if(!best)break;hit.push(best);pts.push(ecen(best));cur=best;
  }
  bolt(pts.map(p=>({x:p.x,y:p.y})));sfx('zap');B.shake=Math.max(B.shake,.2);
  hit.forEach((e,i)=>schedule(i*.09,()=>{if(!e.dying)hurt(e,pow*m*Math.pow(.75,i),'zap');const c=ecen(e);burst(c.x,c.y,'#fff08a',8,90,.35);}));
  return hit.length;
}

/* ---- the casts (each is given: card def, damage multiplier, aim angle, player centre) ---- */
const CAST={
  sword(ch,m,a){
    const lk=swordLock(64);                                   // auto-target: nearest foe within 1.6x reach (LOS-checked)
    let tg=null;
    if(lk){tg=lk.e;a=lk.a;P.aim=a;P.dir=dirOfAngle(a);
      if(lk.gap>0){const to=stepDest(a,Math.min(48,lk.gap+6));                 // just outside reach: short wall-safe lunge
        if(Math.hypot(to.x-P.x,to.y-P.y)>2){B.bolts.push({k:'shadow',x0:P.x,y0:P.y-12,x1:to.x,y1:to.y-12,t:0,dur:.3});P.x=to.x;P.y=to.y;burst(P.x,P.y-6,'#cfe6ff',6,70,.3);}}}
    schedule(.08,()=>{const o=pcen();let aa=a;if(tg&&!tg.dying)aa=angTo(o,ecen(tg));
      addFx('arc',{x:o.x,y:o.y,a:aa,r:64},.28);sfx('slash');
      for(const e of B.ens.slice()){const c=ecen(e);if(e.dying)continue;const d=Math.hypot(c.x-o.x,c.y-o.y);
        if(d<64+eRad(e)&&Math.abs(angDiff(angTo(o,c),aa))<1.15){damageEnemy(e,ch.pow*m,'sword');if(!e.dying)knock(e,aa,18);}}
      spwHitArc(o,aa,64,1.15,ch.pow*m,'sword');});},
  fire(ch,m,a,pc){B.shootAnim=.2;B.shots.push({x:pc.x,y:pc.y,vx:Math.cos(a)*250,vy:Math.sin(a)*250,r:8,dmg:ch.pow*m,own:'p',kind:'fire',life:1.6,a});},
  lance(ch,m,a){schedule(.12,()=>{const o=pcen(),z=Z.line(o.x,o.y,a,290,22);addFx('lance',z,.4);sfx('slash');
    B.shots.forEach(s=>{if(s.own==='e'&&inZone(z,s,0))s.dead=true;});
    for(const e of B.ens.slice()){if(!e.dying&&inZone(z,ecen(e),eRad(e)))damageEnemy(e,ch.pow*m,'lance');}
    spwHitZone(z,ch.pow*m,'lance');});},
  shield(){B.barrier=9;sfx('shield');},
  heal(ch,m,a,pc){poisonCure();const rec=B.healClk!=null&&B.clk-B.healClk<HEAL_COOL;B.healClk=B.clk;const amt=Math.max(1,Math.ceil(maxHp()*HEAL_PCT*(rec?.5:1)*holyHeal()*(1+.15*upgLvl('heal'))));if(rec)floatText(pc.x,pc.y-64,'HALF (RECENT HEAL)','#9ad0ff',10);P.hp=Math.min(maxHp(),P.hp+amt);sfx('heal');
    floatText(pc.x,pc.y-48,'+'+amt,'#4be37a',16);addFx('heal',{x:pc.x,y:pc.y+10},.8);
    for(let i=0;i<10;i++)B.parts.push({x:pc.x+R(-12,12),y:pc.y+R(-4,12),vx:0,vy:-R(30,70),t:0,life:.8,col:'#7dffa0',sz:3});},
  frostbolt(ch,m){castMagic('frostbolt',ch,m);},crimsonbolt(ch,m){castMagic('crimsonbolt',ch,m);},
  frostburst(ch,m){castMagic('frostburst',ch,m);},crimsonburst(ch,m){castMagic('crimsonburst',ch,m);},
  chain(ch,m){const tg=aimEnemy();if(tg)chainFrom(tg,ch.pow,m);},
  quake(ch,m,a,pc){
    const r=118;addFx('quake',{x:P.x,y:P.y,r},.7);sfx('quake');B.shake=Math.max(B.shake,.55);
    for(const e of foesIn(pc.x,pc.y,r)){hurt(e,ch.pow*m,'quake');if(!e.dying){stunEnemy(e,1.2,'quake');knock(e,angTo(pc,ecen(e)),16);}}
    spwHitRadius(pc.x,pc.y,r,ch.pow*m,'quake');
    B.shots.forEach(s=>{if(s.own==='e'&&Math.hypot(s.x-pc.x,s.y-pc.y)<r)s.dead=true;});
  },
  meteor(ch,m){const tg=aimEnemy();if(!tg)return;newMeteor(tg.x,tg.y,ch.pow*m);sfx('warn');},
  poison(ch,m){const tg=aimEnemy();if(!tg)return;newCloud(tg.x,tg.y,68,ch.pow*m,false);},
  shadow(ch,m,a){doShadowStep(dashAngle());},
  ward(){B.ward=3+(skillRank('holy')>=3?1:0);sfx('shield');addFx('wardpop',{x:P.x,y:P.y-12},.5);},
  reflect(){B.reflect=1.5;sfx('clang');addFx('wardpop',{x:P.x,y:P.y-12,c:'#bfe8ff'},.5);},
  haste(){B.haste=5;sfx('whoosh');floatText(P.x,P.y-48,'HASTE!','#ffd0e8',14);},
  wolf(ch,m,a){B.wolf={x:P.x-Math.cos(a)*18,y:P.y,t:10,cd:.3,face:1,bite:0,dmg:ch.pow*m,anim:0,path:null,pathT:0,stuckT:0,lx:P.x,ly:P.y,lt:0};sfx('howl');burst(P.x,P.y-8,'#bcd0f5',14,90,.6);},
  decoy(){const a=P.aim;let x=P.x+Math.cos(a)*30,y=P.y+Math.sin(a)*22;if(bodyBlocked(x,y)){x=P.x;y=P.y;}
    B.decoy={x,y,hp:80,max:80,t:5,face:Math.cos(a)<0?-1:1};sfx('shield');burst(x,y-12,'#d8cfae',12,90,.5);},
  curse(ch,m){const tg=aimEnemy();if(!tg)return;tg.curse=6;sfx('curse');const c=ecen(tg);floatText(c.x,c.y-36,'CURSED! x2','#d58bff',13);burst(c.x,c.y,'#a85fd0',16,100,.6);},
  drain(ch,m){B.channel={t:2,tk:0,dmg:ch.pow*m,tgt:null};sfx('blood');},
  timestop(){
    sfx('timestop');B.tstop=2;B.shake=Math.max(B.shake,.3);addFx('timering',{x:P.x,y:P.y-12},1.0);
    for(const e of B.ens)if(!e.dying)stunEnemy(e,2,'time');
  },
  dragonfire(ch,m,a,pc){
    const z=Z.cone(pc.x,pc.y,a,280,.6);addFx('fire',z,.95);sfx('dragonfire');B.shake=Math.max(B.shake,.7);
    schedule(.1,()=>{for(const e of B.ens.slice()){if(!e.dying&&inZone(z,ecen(e),eRad(e))){hurt(e,ch.pow*m,'fire');if(!e.dying){e.burn=4;e.burnT=.5;}}}
      B.shots.forEach(s=>{if(s.own==='e'&&inZone(z,s,0))s.dead=true;});});
  },
};
/* ---- combos: casting these pairs within 1.5s (either order) fuses into a stronger effect ---- */
const COMBO_FX={
  'STEAM BLAST'(m){const tg=aimEnemy();if(!tg)return;const r=88;addFx('steam',{x:tg.x,y:tg.y,r},.9);sfx('steam');B.shake=Math.max(B.shake,.45);
    for(const e of foesIn(tg.x,tg.y-13,r)){hurt(e,140*m,'steam');if(!e.dying)stunEnemy(e,1.0,'steam');}},
  'STORM CLOUD'(m){const tg=aimEnemy();if(!tg)return;newCloud(tg.x,tg.y,88,16*m,true);},
  'PHANTOM SLASH'(m){let a=dashAngle(),dist=110;const l0=swordLock(110);if(l0){a=l0.a;dist=clamp(l0.d-40,24,110);}   // dash toward the nearest foe, stopping beside it
    const {from,to}=doShadowStep(a,dist);
    const hit=new Set();for(const e of B.ens){if(e.dying)continue;const c=ecen(e);
      for(let u=0;u<=1.001;u+=.1){if(Math.hypot(c.x-lerp(from.x,to.x,u),c.y-(lerp(from.y,to.y,u)-12))<eRad(e)+34){hit.add(e);break;}}}
    const lk=swordLock(84,{x:to.x,y:to.y-12});let sa=a;if(lk){sa=lk.a;hit.add(lk.e);P.aim=sa;P.dir=dirOfAngle(sa);}
    for(const e of B.ens){if(!e.dying&&Math.hypot(e.x-to.x,e.y-to.y)<84+eRad(e)*.5)hit.add(e);}
    schedule(.08,()=>{addFx('arc',{x:to.x,y:to.y-12,a:sa,r:84},.35);addFx('arc',{x:to.x,y:to.y-12,a:sa+2.1,r:84},.35);addFx('arc',{x:to.x,y:to.y-12,a:sa-2.1,r:84},.35);sfx('slash');
      for(const e of hit)if(!e.dying)hurt(e,160*m,'sword');});},
  'SANCTUARY'(m){B.ward=5;B.sanct=5;B.sanctT=0;sfx('heal');addFx('wardpop',{x:P.x,y:P.y-12,c:'#fff0a8'},.7);const amt=Math.ceil(maxHp()*.2);P.hp=Math.min(maxHp(),P.hp+amt);floatText(P.x,P.y-48,'+'+amt,'#4be37a',16);},
  'MAGMA SURGE'(m){const pc=pcen(),r=135;addFx('quake',{x:P.x,y:P.y,r,c:'#ff7a2a'},.8);addFx('boom',{k:'circle',x:pc.x,y:pc.y+6,r:r*.8},.7);sfx('quake');sfx('boom');B.shake=Math.max(B.shake,.7);
    for(const e of foesIn(pc.x,pc.y,r)){hurt(e,130*m,'fire');if(!e.dying){e.burn=3.2;e.burnT=.5;stunEnemy(e,.8,'quake');}}},
  'JUDGMENT'(m){let n=0;for(const e of B.ens)if(!e.dying){newMeteor(e.x,e.y,150*m,62,1.0+n*.12);n++;}sfx('warn');},
};
function tryCombo(id){
  const pv=B.lastCard;if(!pv||B.clk-pv.t>COMBO_WIN)return null;
  return COMBOS.find(c=>(c.a===pv.id&&c.b===id)||(c.a===id&&c.b===pv.id))||null;
}
function noLos(){if(!B.noLosT||B.clk-B.noLosT>.6){floatText(P.x,P.y-40,'NO LINE OF SIGHT','#ffb0a0',11);sfx('clang');B.noLosT=B.clk;}}
function useCard(i){
  const id=B.hand[i];if(!id||B.phase!=='fight')return;
  const ch=CARD[id];if(!ch)return;
  if(ch.tgt){const tg=aimEnemy();if(!tg||!losW(pcen(),7,ecen(tg),7)){noLos();return;}}   // spell needs a clear line to its target - card kept
  if(id==='shadow'){const to=stepDest(dashAngle(),130);if(Math.hypot(to.x-P.x,to.y-P.y)<16){floatText(P.x,P.y-40,'NO ROOM','#ffb0a0',11);sfx('clang');return;}}
  dailyEvent('card');B.hand[i]=null;B.sel=i;nextSel(1);if(!B.hand[B.sel])B.sel=0;
  const pc=pcen(),m=cardMult()*schoolMult(id)*upgMult(id),a=fireAngle();B.loud=1;B.owner=null;ZOFF=7;
  P.aim=a;P.dir=dirOfAngle(a);
  sfx('cast');floatText(pc.x,pc.y-34,cardFullName(ch)+'!',ch.col,12);
  let cb=tryCombo(id);if(cb&&cb.needT&&!aimEnemy())cb=null;
  if(cb){
    B.lastCard=null;setBanner('COMBO!  '+cb.name,1.5,cb.col);sfx('combo');B.comboFlash=1;B.combos=(B.combos||0)+1;B.lastCombo=cb.name;
    floatText(pc.x,pc.y-56,'COMBO!',cb.col,16);
    COMBO_FX[cb.name](m);
  } else {B.lastCard={id,t:B.clk};CAST[id](ch,m,a,pc);}
}

/* ---- spirit wolf steering: straight when the way is clear, otherwise a tile path around walls / obstacles; teleports beside the
   target if it still has not made progress for 1.5s ---- */
function tilePathTo(fx,fy,gx,gy,maxN=1500){
  const sx=Math.floor(fx/TS),sy=Math.floor((fy-4)/TS),tx=Math.floor(gx/TS),ty=Math.floor((gy-4)/TS),key=(x,y)=>y*MW+x,par=new Map([[key(sx,sy),-1]]),q=[[sx,sy]];
  let goal=null,best=[sx,sy],bd=Math.hypot(tx-sx,ty-sy);
  for(let h=0;h<q.length&&q.length<maxN;h++){
    const [x,y]=q[h],d=Math.hypot(tx-x,ty-y);if(d<bd){bd=d;best=[x,y];}
    if(d<=1.01){goal=[x,y];break;}
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=key(nx,ny);if(par.has(k)||solidTile(nx,ny))continue;par.set(k,key(x,y));q.push([nx,ny]);}
  }
  const g=goal||best,path=[];let k=key(g[0],g[1]);
  while(k!==-1&&k!==key(sx,sy)){path.push({x:(k%MW)*TS+16,y:Math.floor(k/MW)*TS+22});k=par.get(k);}
  return path.reverse();
}
function wolfFreeSpot(gx,gy){
  for(let r=20;r<=70;r+=14)for(let i=0;i<10;i++){const a=i*.628+r*.1,x=gx+Math.cos(a)*r,y=gy+Math.sin(a)*r;
    if(!solidTile(Math.floor((x-5)/TS),Math.floor((y-5)/TS))&&!solidTile(Math.floor((x+5)/TS),Math.floor((y-5)/TS))&&!solidTile(Math.floor((x-5)/TS),Math.floor(y/TS))&&!solidTile(Math.floor((x+5)/TS),Math.floor(y/TS)))return {x,y};}
  return {x:P.x,y:P.y};
}
function wolfSteer(w,goal,dd,sp,dt){
  const direct=losW({x:w.x,y:w.y-6},5,{x:goal.x,y:goal.y-6},5);
  let tx=goal.x,ty=goal.y;
  if(!direct){
    w.pathT-=dt;if(w.pathT<=0||!w.path){w.pathT=.4;w.path=tilePathTo(w.x,w.y,goal.x,goal.y);}
    let wp=w.path&&w.path[0];while(wp&&Math.hypot(wp.x-w.x,wp.y-w.y)<8){w.path.shift();wp=w.path[0];}
    if(wp){tx=wp.x;ty=wp.y;}
  }else w.path=null;
  const dx=tx-w.x,dy=ty-w.y,dl=Math.hypot(dx,dy)||1,ox=w.x,oy=w.y;
  moveBox(w,dx/dl*sp,0,5,5);moveBox(w,0,dy/dl*sp,5,5);w.face=dx<0?-1:1;
  // progress watchdog: moved < 6px over the last half second while still far from the goal = stuck
  w.lt+=dt;if(w.lt>=.5){const moved=Math.hypot(w.x-w.lx,w.y-w.ly);w.lx=w.x;w.ly=w.y;w.lt=0;w.stuckT=moved<6?w.stuckT+.5:0;}
  if(w.stuckT>=1.5){const s=wolfFreeSpot(goal.x,goal.y);burst(w.x,w.y-8,'#bcd0f5',8,70,.4);w.x=s.x;w.y=s.y;burst(w.x,w.y-8,'#bcd0f5',8,70,.4);w.stuckT=0;w.path=null;w.tele=(w.tele||0)+1;}
}
/* ---- per-frame upkeep of buffs, clouds, meteors, wolf, decoy, channel ---- */
function updateExtras(dt){
  const pc=pcen(),m=cardMult();
  B.clk+=dt;
  for(const k of ['haste','ward','reflect','tstop','sanct','ghost'])B[k]=Math.max(0,B[k]-dt);
  if(B.sanct>0){B.sanctT+=dt;if(B.sanctT>=1){B.sanctT=0;const h=Math.max(1,Math.round(maxHp()*.05));P.hp=Math.min(maxHp(),P.hp+h);floatText(pc.x,pc.y-40,'+'+h,'#7dffa0',12);}}
  for(const e of B.ens){if(e.curse>0)e.curse-=dt;if(e.weak>0)e.weak-=dt;if(e.pois>0)e.pois-=dt;}
  // poison / storm clouds
  for(const c of B.clouds){c.t+=dt;c.tk-=dt;
    if(c.tk<=0){c.tk=.5;const inn=foesIn(c.x,c.y,c.r);
      for(const e of inn){hurt(e,c.dmg,'dot');if(!isRock(e))e.pois=.7;}
      if(c.storm&&inn.length){const z=inn[RI(0,inn.length-1)];if(!z.dying){bolt([{x:c.x,y:c.y-60},ecen(z)],.3);hurt(z,38*m,'zap');sfx('zap');}}}}
  B.clouds=B.clouds.filter(c=>c.t<c.dur);
  // meteors
  for(const mt of B.meteors){mt.t+=dt;
    if(!mt.hit&&mt.t>=mt.dur){mt.hit=true;sfx('meteor');B.shake=Math.max(B.shake,.8);B.hitstop=Math.max(B.hitstop,.06);
      addFx('meteorboom',{x:mt.x,y:mt.y,r:mt.r},.8);
      for(const e of B.ens.slice()){if(e.dying)continue;const c=ecen(e);if(Math.hypot(e.x-mt.x,e.y-mt.y)<mt.r+eRad(e)*.6){hurt(e,mt.dmg,'meteor');if(!e.dying)knock(e,angTo(mt,e),14);}}spwHitRadius(mt.x,mt.y-8,mt.r,mt.dmg,'meteor');}}
  B.meteors=B.meteors.filter(mt=>mt.t<mt.dur+.5);
  B.bolts.forEach(b=>b.t+=dt);B.bolts=B.bolts.filter(b=>b.t<b.dur);
  // spirit wolf
  const w=B.wolf;
  if(w){w.t-=dt;w.cd-=dt;w.bite=Math.max(0,w.bite-dt);w.anim+=dt*10;
    if(w.t<=0){burst(w.x,w.y-8,'#bcd0f5',12,80,.5);B.wolf=null;}
    else{let tg=null,bd=1e9;for(const e of B.ens){if(e.dying)continue;const d=Math.hypot(e.x-w.x,e.y-w.y);if(d<bd){bd=d;tg=e;}}
      const goal=tg?{x:tg.x,y:tg.y}:{x:P.x-26,y:P.y+6},dd=Math.hypot(goal.x-w.x,goal.y-w.y),stop=tg?eRad(tg)+8:16;
      if(dd>stop)wolfSteer(w,goal,dd,(tg?175:120)*dt,dt);else{w.stuckT=0;w.path=null;}
      if(tg&&dd<=stop+10&&w.cd<=0){w.cd=.55;w.bite=.2;hurt(tg,w.dmg,'wolf');sfx('bite');const c=ecen(tg);burst(c.x,c.y,'#ffffff',6,80,.3);}}}
  // decoy
  const dc=B.decoy;
  if(dc){dc.t-=dt;if(dc.t<=0||dc.hp<=0){burst(dc.x,dc.y-12,'#d8cfae',14,100,.5);floatText(dc.x,dc.y-30,dc.hp<=0?'DECOY BROKEN':'POOF','#d8cfae',11);B.decoy=null;}}
  // drain-soul channel
  const ch=B.channel;
  if(ch){ch.t-=dt;ch.tk-=dt;
    let tg=null,bd=250;for(const e of B.ens){if(e.dying)continue;const c=ecen(e),d=Math.hypot(c.x-pc.x,c.y-pc.y);if(d<bd&&losW(pc,7,c,7)){bd=d;tg=e;}}
    ch.tgt=tg;
    if(tg&&ch.tk<=0){ch.tk=.25;hurt(tg,ch.dmg,'dot');const dl=tg.lastDealt||0;
      if(dl>0){const h=Math.max(1,Math.round(dl*.5));P.hp=Math.min(maxHp(),P.hp+h);floatText(pc.x+R(-8,8),pc.y-40,'+'+h,'#ff6b9a',12);}}
    if(ch.t<=0)B.channel=null;}
}
/* enemy shots vs. ward / reflect / decoy (called from updateShots for hostile shots) */
function shotVsDefenses(s,pc){
  if(B.ward>0&&Math.hypot(s.x-pc.x,s.y-pc.y)<74){s.dead=true;burst(s.x,s.y,'#ffe9a0',8,90,.4);sfx('clang');return true;}
  if(B.reflect>0&&Math.hypot(s.x-pc.x,s.y-pc.y)<s.r+30){s.own='p';s.vx*=-1.25;s.vy*=-1.25;s.a+=Math.PI;s.dmg=Math.max(14,s.dmg*2.2);s.life=1.6;s.refl=true;
    burst(s.x,s.y,'#bfe8ff',10,110,.4);floatText(s.x,s.y-14,'REFLECT!','#bfe8ff',11);sfx('clang');return true;}
  const dc=B.decoy;if(dc&&dc.hp>0&&Math.hypot(s.x-dc.x,s.y-(dc.y-12))<s.r+12){s.dead=true;dc.hp-=s.dmg;burst(s.x,s.y,'#d8cfae',6,80,.3);sfx('hit');return true;}
  return false;
}

/* ---- drawing: ground effects (under sprites) and top effects ---- */
function drawExtrasGround(){
  const b=B;
  for(const c of b.clouds){
    const p=c.t/c.dur,a=Math.min(1,c.t*3)*Math.min(1,(1-p)*4),col=c.storm?'180,255,90':'110,200,60';
    ctx.save();ctx.globalAlpha=.32*a;ctx.fillStyle=`rgb(${col})`;ctx.beginPath();ctx.ellipse(c.x,c.y,c.r,c.r*.62,0,0,6.283);ctx.fill();
    ctx.globalAlpha=.8*a;ctx.strokeStyle=c.storm?'#f0ff80':'#a6e85a';ctx.lineWidth=2;ctx.setLineDash([6,5]);ctx.lineDashOffset=-gtime*14;ctx.stroke();ctx.setLineDash([]);
    for(let i=0;i<9;i++){const ang=i*2.4+gtime*.6,rr=c.r*(.25+.6*((i*37)%10)/10),x=c.x+Math.cos(ang)*rr,y=c.y+Math.sin(ang)*rr*.62-4-((gtime*14+i*9)%18);
      ctx.globalAlpha=.55*a;ctx.fillStyle=i%3?'#7ccf3a':'#c8f070';ctx.beginPath();ctx.arc(x,y,5+(i%3)*2,0,6.283);ctx.fill();}
    ctx.restore();
  }
  for(const mt of b.meteors){
    if(mt.hit)continue;const p=mt.t/mt.dur,fl=Math.floor(gtime*14)%2===0;
    ctx.save();ctx.fillStyle=`rgba(255,${fl?170:90},40,${.28+.2*p})`;ctx.beginPath();ctx.ellipse(mt.x,mt.y,mt.r,mt.r*.62,0,0,6.283);ctx.fill();
    ctx.fillStyle='rgba(255,230,140,.35)';ctx.beginPath();ctx.ellipse(mt.x,mt.y,mt.r*p,mt.r*.62*p,0,0,6.283);ctx.fill();
    ctx.strokeStyle=p>.7?'#fff':'#ffd27a';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(mt.x,mt.y,mt.r,mt.r*.62,0,0,6.283);ctx.stroke();ctx.restore();
  }
  const shad=(x,y,w)=>{ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(x,y-1,w,w*.3,0,0,6.283);ctx.fill();};
  if(b.decoy)shad(b.decoy.x,b.decoy.y,11);
  if(b.wolf)shad(b.wolf.x,b.wolf.y,9);
}
function drawExtrasTop(){
  const b=B,pc=pcen();
  // allies / decoy
  if(b.decoy){const d=b.decoy,spr=SP.heroB[0],fl=d.t<1.2&&Math.floor(gtime*12)%2;
    if(!fl){ctx.save();ctx.globalAlpha=.75;ctx.translate(Math.round(d.x),0);if(d.face<0)ctx.scale(-1,1);ctx.drawImage(tintOf(spr,'#9aa7c0'),-16,Math.round(d.y-31),32,32);ctx.restore();ctx.save();ctx.globalAlpha=.35;ctx.fillStyle='#fff';ctx.fillRect(Math.round(d.x-6),Math.round(d.y-31+Math.sin(gtime*8)*2),12,1);ctx.restore();}
    bar(Math.round(d.x-12),Math.round(d.y-38),24,3,d.hp/d.max,'#d8cfae');txt('DECOY',d.x,d.y-42,{size:8,align:'center',col:'#d8cfae',lw:2});}
  if(b.wolf){const w=b.wolf,fl=w.t<1.2&&Math.floor(gtime*12)%2;if(!fl){ctx.save();ctx.globalAlpha=.8;ctx.translate(Math.round(w.x),0);if(w.face<0)ctx.scale(-1,1);
      const bob=Math.abs(Math.sin(w.anim))*2,lung=w.bite>0?4:0;ctx.drawImage(SP.ic.wolf,-16+lung,Math.round(w.y-28-bob),32,32);ctx.restore();}}
  // bolts: lightning chains, shadow trails
  for(const k of b.bolts){const p=k.t/k.dur;
    if(k.k==='zap'){ctx.save();ctx.globalAlpha=Math.min(1,(1-p)*2.2);ctx.lineJoin='round';
      for(const pass of [[7,'#ffe14d'],[3,'#fffbd0']]){ctx.strokeStyle=pass[1];ctx.lineWidth=pass[0]*(1-p*.5);ctx.beginPath();
        for(let i=0;i<k.pts.length-1;i++){const a=k.pts[i],c=k.pts[i+1],n=7;ctx.moveTo(a.x,a.y);
          for(let j=1;j<=n;j++){const u=j/n,jit=j===n?0:Math.sin(j*12.9+Math.floor(gtime*30)*3.7+i)*9;const dx=c.x-a.x,dy=c.y-a.y,l=Math.hypot(dx,dy)||1;ctx.lineTo(a.x+dx*u-dy/l*jit,a.y+dy*u+dx/l*jit);}}
        ctx.stroke();}
      ctx.restore();}
    else if(k.k==='shadow'){ctx.save();for(let i=0;i<5;i++){const u=i/4;ctx.globalAlpha=(1-p)*(.5-i*.07);ctx.drawImage(tintOf(SP.heroB[0],'#3a2a66'),Math.round(lerp(k.x0,k.x1,u)-16),Math.round(lerp(k.y0,k.y1,u)-19),32,32);}ctx.restore();}
  }
  // meteor falling rock
  for(const mt of b.meteors){if(mt.hit)continue;const left=mt.dur-mt.t;if(left<.45){const u=left/.45,y=mt.y-u*260,x=mt.x+u*90;
      ctx.save();for(let i=1;i<7;i++){ctx.globalAlpha=.5-i*.07;ctx.fillStyle=i%2?'#ff8a2a':'#ffd23f';ctx.beginPath();ctx.arc(x-i*(u*9),y-i*(u*28),18-i*2,0,6.283);ctx.fill();}
      ctx.globalAlpha=1;ctx.fillStyle='#5a3a2a';ctx.beginPath();ctx.arc(x,y,17,0,6.283);ctx.fill();ctx.fillStyle='#ff7a2a';ctx.beginPath();ctx.arc(x+3,y+3,10,0,6.283);ctx.fill();ctx.fillStyle='#ffe99a';ctx.beginPath();ctx.arc(x+4,y+4,5,0,6.283);ctx.fill();ctx.restore();}}
  // holy ward dome / reflect mirror
  if(b.ward>0){const a=Math.min(1,b.ward*3)*(b.ward<.7?(Math.floor(gtime*16)%2?1:.4):1);
    ctx.save();ctx.globalAlpha=.22*a;ctx.fillStyle='#fff0a8';ctx.beginPath();ctx.ellipse(pc.x,pc.y+6,70,56,0,0,6.283);ctx.fill();
    ctx.globalAlpha=.85*a;ctx.strokeStyle='#ffe9a0';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(pc.x,pc.y+6,70,56,0,0,6.283);ctx.stroke();
    ctx.globalAlpha=.5*a;ctx.strokeStyle='#fff';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(pc.x,pc.y+6,60,46,0,Math.PI*1.1+gtime,Math.PI*1.8+gtime);ctx.stroke();ctx.restore();}
  if(b.reflect>0){const a=Math.min(1,b.reflect*4);ctx.save();ctx.globalAlpha=.7*a;ctx.strokeStyle='#bfe8ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(pc.x,pc.y,30,0,6.283);ctx.stroke();
    ctx.globalAlpha=.25*a;ctx.fillStyle='#e8f8ff';ctx.beginPath();ctx.arc(pc.x,pc.y,30,0,6.283);ctx.fill();
    ctx.globalAlpha=.9*a;ctx.fillStyle='#fff';for(let i=0;i<3;i++){const g=gtime*4+i*2.1;ctx.fillRect(Math.round(pc.x+Math.cos(g)*30)-1,Math.round(pc.y+Math.sin(g)*30)-1,3,3);}ctx.restore();}
  if(b.haste>0){ctx.save();ctx.globalAlpha=.5;ctx.strokeStyle='#ffd0e8';ctx.lineWidth=2;for(let i=0;i<4;i++){const y=pc.y+8+i*5-10,x=pc.x-14-((gtime*90+i*17)%26);ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x-12,y);ctx.stroke();}ctx.restore();}
  if(b.sanct>0){ctx.save();ctx.globalAlpha=.35+.15*Math.sin(gtime*6);ctx.fillStyle='#fff6b0';ctx.fillRect(Math.round(pc.x-9),Math.round(pc.y-90),18,100);ctx.restore();}
  // drain beam
  if(b.channel&&b.channel.tgt){const tc=ecen(b.channel.tgt);ctx.save();ctx.lineCap='round';
    for(const pass of [[8,'rgba(208,48,106,.45)'],[3,'#ff9ac0']]){ctx.strokeStyle=pass[1];ctx.lineWidth=pass[0];ctx.beginPath();
      for(let i=0;i<=14;i++){const u=i/14,dx=tc.x-pc.x,dy=tc.y-pc.y,l=Math.hypot(dx,dy)||1,w=Math.sin(u*9-gtime*14)*5*Math.sin(u*3.14);const x=pc.x+dx*u-dy/l*w,y=pc.y+dy*u+dx/l*w;i?ctx.lineTo(x,y):ctx.moveTo(x,y);}ctx.stroke();}
    for(let i=0;i<4;i++){const u=1-((gtime*1.6+i/4)%1),x=lerp(pc.x,tc.x,u),y=lerp(pc.y,tc.y,u);ctx.fillStyle='#ff4a8a';ctx.beginPath();ctx.arc(x,y,4,0,6.283);ctx.fill();ctx.fillStyle='#ffd0e0';ctx.fillRect(Math.round(x)-1,Math.round(y)-1,2,2);}
    ctx.restore();}
  // curse / stun / poison marks over enemies
  for(const e of b.ens){if(e.dying)continue;const c=ecen(e),top=c.y-(e.def.big?60:30)*(e.sz||1);
    if(e.weak>0&&!(e.curse>0)){ctx.save();ctx.globalAlpha=.5+.25*Math.sin(gtime*6);ctx.strokeStyle='#6a4ab0';ctx.lineWidth=2;ctx.setLineDash([4,3]);ctx.beginPath();ctx.ellipse(e.x,e.y,eRad(e)+4,(eRad(e)+4)*.45,0,0,6.283);ctx.stroke();ctx.restore();txt('HEX -30%',e.x,top-4,{size:9,align:'center',col:'#cbb4ff',lw:2});}
    if(e.curse>0){ctx.save();ctx.globalAlpha=.55+.3*Math.sin(gtime*7);ctx.strokeStyle='#c77dff';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(e.x,e.y,eRad(e)+5,(eRad(e)+5)*.45,0,0,6.283);ctx.stroke();ctx.restore();txt('x2',e.x,top-4,{size:10,align:'center',col:'#d58bff',lw:2});}
    if(e.stun>0){const tm=e.stunK==='time';ctx.save();if(tm){ctx.globalAlpha=.8;ctx.strokeStyle='#ffd23f';ctx.lineWidth=2;ctx.beginPath();ctx.arc(e.x,top-12,7,0,6.283);ctx.stroke();ctx.beginPath();ctx.moveTo(e.x,top-12);ctx.lineTo(e.x,top-17);ctx.moveTo(e.x,top-12);ctx.lineTo(e.x+4,top-12);ctx.stroke();}
      else for(let i=0;i<3;i++){const g=gtime*7+i*2.1;ctx.fillStyle='#ffe14d';ctx.fillRect(Math.round(e.x+Math.cos(g)*10)-2,Math.round(top-8+Math.sin(g)*3)-2,4,4);}
      ctx.restore();}
  }
  // time-stop colour wash
  if(b.tstop>0){ctx.save();ctx.globalAlpha=Math.min(.22,b.tstop*.3);ctx.fillStyle='#8a7bd6';ctx.fillRect(cam.x,cam.y,VW,VH);ctx.restore();}
}
