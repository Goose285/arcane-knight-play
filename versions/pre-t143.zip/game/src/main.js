let SANITY_T=0;

/* ---- frame ---- */
function render(){
  ctx.setTransform(S,0,0,S,0,0);ctx.imageSmoothingEnabled=false;
  ctx.fillStyle='#000';ctx.fillRect(0,0,VW,VH);
  if(state==='title'){drawTitle();if(TOUCH)drawTouchTitle();return;}
  if(state==='fishlab'){drawFishLab();return;}
  if(state==='editor'){drawWorld();edCopyDraw();drawEditor();return;}
  const sh=B&&B.shake>0?B.shake:0;
  ctx.save();if(sh)ctx.translate(Math.round((Math.random()-.5)*sh*14),Math.round((Math.random()-.5)*sh*10));
  drawWorld();drawChestFx();drawLifeOverlay();
  ctx.restore();
  drawLighting();
  if(vign)ctx.drawImage(vign,0,0);
  drawHouseVignette();
  if(B){
    // soft combat spotlight: darken everything outside the fight area
    const ex=P.x-cam.x,ey=P.y-cam.y,g=ctx.createRadialGradient(ex,ey,190,ex,ey,Math.max(VW,VH)*.8);
    g.addColorStop(0,'rgba(6,4,24,0)');g.addColorStop(1,`rgba(6,4,24,${.5*B.dim})`);ctx.fillStyle=g;ctx.fillRect(0,0,VW,VH);
    if(B.phase==='alert'&&B.t<.18){ctx.fillStyle=`rgba(255,255,255,${.7*(1-B.t/.18)})`;ctx.fillRect(0,0,VW,VH);}
    drawAimPreview();drawCombatHud();drawRushBar();
  } else drawOverHud();
  drawTracker();drawFishingHud();drawTut();drawHome();drawToasts();drawRunBtn();drawFF();drawPoison();drawReveal();drawWarp();
  if(DLG&&!B)drawDlg();
  if(TOUCH)drawTouch();
  if(state==='paused')drawPause();
  if(isUI())drawUI();
}
function drawTouchTitle(){}
function update(dt){
  pollPad();gtime+=dt;tickAtkTouch();musUpdate(dt);
  if(toasts.length&&!introHold())toasts[0].t+=dt;while(toasts.length&&toasts[0].t>toasts[0].dur)toasts.shift();updateIntro();updateChests(dt);updateReveal(dt);updateRun(dt);updateFF(dt);updateLife(dt);updatePoison(dt);try{updateBestiary();updateTips();}catch(e){}updateTownEscape();updateGuide(dt);updateRoutines(dt);
  if(state==='fishlab'){updateFishLab(dt);return;}
  if(state==='editor'){updateEditor(dt);return;}
  if(state==='title'){
    if(!titleMenu.items.length)initTitleMenu();
    const n=titleMenu.items.length;
    if(hit('ArrowUp','KeyW')&&n>1){titleMenu.sel=(titleMenu.sel+n-1)%n;titleMenu.confirm=false;sfx('select');}
    if(hit('ArrowDown','KeyS')&&n>1){titleMenu.sel=(titleMenu.sel+1)%n;titleMenu.confirm=false;sfx('select');}
    if(hit('KeyO')){openSettings('title');return;}
    if(hit('Space','Enter'))startFromTitle();
    return;
  }
  saveTimer+=dt;if(saveTimer>=30){saveTimer=0;saveGame('timer');}
  if(B&&B.saveSoon){B.saveSoon=false;saveGame('levelup');}
  if(isUI()){updateUI(dt);return;}
  if(state==='paused'&&updatePauseKeys())return;
  if(hit('KeyM')){muted=!muted;toast(muted?'Sound off':'Sound on',1);}
  if(hit('KeyP')||(hit('Escape')&&!DLG&&!FISH.on)){state=state==='paused'?'play':'paused';pauseReset();if(state==='paused')releaseAllTouch();}
  if(state==='paused'){updateTut(dt);return;}
  if(B&&B.hitstop>0){B.hitstop-=dt;dt=0;}
  updateDayNight(dt);updateTown(dt);updateHome(dt);updateWaystones();updateHouseDoor();
  updateExplore(dt);
  if(B)updateBattle(dt);
  updateRush(dt);updateLab(dt);updatePet(dt);updateStory();updateDaily(dt);updateAch(dt);updateTut(dt);updateTracker(dt);
}
/* ---- sizing: integer pixel scale, fills the whole screen, safe-area aware ---- */
const probe=document.createElement('div');
probe.style.cssText='position:fixed;left:0;top:0;width:0;height:0;visibility:hidden;pointer-events:none;padding-top:env(safe-area-inset-top);padding-right:env(safe-area-inset-right);padding-bottom:env(safe-area-inset-bottom);padding-left:env(safe-area-inset-left)';
document.body.appendChild(probe);
function readSafe(){
  const cs=getComputedStyle(probe),k=DPR/S;
  let t=parseFloat(cs.paddingTop)||0,r=parseFloat(cs.paddingRight)||0,b=parseFloat(cs.paddingBottom)||0,l=parseFloat(cs.paddingLeft)||0;
  const q=new URLSearchParams(location.search).get('safe');           // test hook: ?safe=top,right,bottom,left (css px)
  if(q){const a=q.split(',').map(Number);t=a[0]||0;r=a[1]||0;b=a[2]||0;l=a[3]||0;}
  ST=t*k;SR=r*k;SB=b*k;SL=l*k;
}
/* phones play in landscape: held upright they get a 'rotate your phone' screen and the game waits (iOS Safari cannot lock orientation) */
let ROTATE_BLOCK=false;
function rotateCheck(){
  const cw=window.innerWidth||640,ch=window.innerHeight||448,off=window.__NOROTATE||(navigator.webdriver&&!window.__ROTATE_TEST);
  const was=ROTATE_BLOCK;ROTATE_BLOCK=!off&&TOUCH&&Math.min(cw,ch)<=520&&ch>cw*1.05;
  document.body.classList.toggle('rot',ROTATE_BLOCK);
  if(ROTATE_BLOCK&&!was&&typeof releaseAllTouch==='function')releaseAllTouch();
}
function lockLandscape(){try{if(TOUCH&&screen.orientation&&screen.orientation.lock)screen.orientation.lock('landscape').catch(()=>{});}catch(e){}}
let HZ=false;   // inside the house with a ?housevoid zoom option
function resize(){rotateCheck();
  DPR=Math.min(window.devicePixelRatio||1,3);
  const cw=window.innerWidth||640,ch=window.innerHeight||448;
  const dw=Math.max(1,Math.floor(cw*DPR)),dh=Math.max(1,Math.floor(ch*DPR));
  S=Math.max(1,Math.round(Math.min(dw,dh)/400));
  if(EDS)S=EDS;
  else if(HZ&&Math.floor(dw/(S+1))>=18*TS)S++;   // ?housevoid zoom: one pixel-scale step closer inside the house so the room fills the screen
  VW=Math.max(240,Math.floor(dw/S));VH=Math.max(240,Math.floor(dh/S));
  cv.width=VW*S;cv.height=VH*S;
  cv.style.width=(VW*S/DPR)+'px';cv.style.height=(VH*S/DPR)+'px';
  readSafe();layoutTouch();
  vign=makeSprite(VW,VH,g=>{const gr=g.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*.35,VW/2,VH/2,Math.max(VW,VH)*.75);gr.addColorStop(0,'rgba(0,0,0,0)');gr.addColorStop(1,'rgba(0,0,0,.42)');g.fillStyle=gr;g.fillRect(0,0,VW,VH);});
  snapCam();
}
addEventListener('resize',resize);
if(window.visualViewport)visualViewport.addEventListener('resize',resize);
setApply();resize();
let last=performance.now();
function frame(ts){
  {const hw=houseZoomWant();if(hw!==HZ){HZ=hw;resize();}}
  let dt=Math.min(1/30,(ts-last)/1000);last=ts;if(!(dt>0))dt=0;
  try{if(!ROTATE_BLOCK)update(dt);}catch(err){watchdog('update',err);}
  SANITY_T=(SANITY_T||0)+dt;if(SANITY_T>5){SANITY_T=0;try{if(!B)sanitizeWorld('tick');}catch(e){}}
  try{render();}catch(err){watchdog('render',err);try{ctx.setTransform(1,0,0,1,0,0);ctx.globalAlpha=1;}catch(e){}}
  pressed={};released={};
  requestAnimationFrame(frame);
}
/* t142u WATCHDOG: an error inside one frame is logged (console + WATCHDOG.log, last 20) and the game keeps running instead of freezing.
   Repeated errors from a battle reset that battle so a broken fight state can't lock the game. */
const WATCHDOG={n:0,log:[],last:0,burst:0};
function watchdog(where,err){
  WATCHDOG.n++;const msg=where+': '+(err&&err.stack||err);if(WATCHDOG.log.length>=20)WATCHDOG.log.shift();WATCHDOG.log.push(msg.slice(0,500));
  try{console.error('[watchdog]',msg);}catch(e){}
  const now=performance.now();WATCHDOG.burst=now-WATCHDOG.last<1000?WATCHDOG.burst+1:1;WATCHDOG.last=now;
  if(WATCHDOG.burst>30&&B){try{resetFighters(false);}catch(e){}B=null;WATCHDOG.burst=0;try{toast('Something went wrong in that fight - it was reset.',3,'#ffb0a0');}catch(e){}}
}
requestAnimationFrame(frame);
cv.focus();
{const sp=document.getElementById('splash');if(sp){if(NOSAVE)sp.remove();else setTimeout(()=>{sp.style.opacity=0;setTimeout(()=>sp.remove(),600);},900);}}
if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)&&!window.Capacitor&&!NOSAVE){   // PWA / iOS Home Screen: always move to the newest build
  const sw=navigator.serviceWorker,had=!!sw.controller;let reloading=false;
  sw.addEventListener('controllerchange',()=>{if(!had||reloading)return;reloading=true;try{saveGame();}catch(e){}location.reload();});   // a new worker took over: reload into the new build (progress saved first)
  addEventListener('load',()=>sw.register('sw.js',{updateViaCache:'none'}).then(reg=>{
    const chk=()=>reg.update().catch(()=>{});chk();
    document.addEventListener('visibilitychange',()=>{if(!document.hidden)chk();});addEventListener('pageshow',chk);addEventListener('focus',chk);setInterval(chk,20*60*1000);
    reg.addEventListener('updatefound',()=>{const w=reg.installing;if(w)w.addEventListener('statechange',()=>{if(w.state==='installed'&&sw.controller)w.postMessage('skipWaiting');});});
  }).catch(()=>{}));
}
