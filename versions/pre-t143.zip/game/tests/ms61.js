// M61 (t142u): mushroom-boss freeze (unsigned hash index) + frame watchdog + load sanitizer, spawners hit by every attack + auto-aim,
// 4 slimes north of Oakvale, Myrewood Bog layout redo, softer walk-over south gate, reward popup styles.   node tests/ms61.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms61',{town:true,grow:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t142/.test(tags),'backup tag backup-pre-t142');
 await E(()=>{window.__NOESC=0;__game.dbg.startFromTitle();});await sleep(700);
 // 3. slimes north of town
 let s=await E(()=>{return __game.enemies.filter(e=>e.type==='slime'&&e.hy>=TOWN.y0-30*TS&&e.hy<TOWN.y0&&e.hx>TOWN.x0-4*TS&&e.hx<TOWN.x1+4*TS&&!e.spw).length;});
 ok(s===4,'exactly 4 slimes north of Oakvale ('+s+')');
 // 1. freeze: ambient butterflies at the Glowcap spot where the Mushroom King fell (hash >= 2^31 used to index with a negative number)
 s=await E(async()=>{const g=__game;g.P.x=3642;g.P.y=8317;g.dbg.setTimeOfDay(.45);const t0=gtime;await new Promise(r=>setTimeout(r,1500));
   const src=[drawAmbientDay,ambientCells].map(String).join('');return {adv:gtime-t0,wd:WATCHDOG.n,neg:/\(h+>>\d+\)%/.test(src)};});
 ok(s.adv>.8,'game keeps running at the Mushroom King spot (gtime +'+s.adv.toFixed(2)+')');
 ok(!s.neg,'ambient art indexes palettes with >>> (no signed shift)');
 s=await E(()=>{let n=0;for(let i=0;i<4000;i++){const h=hash2(i*7919,i*104729);if(((h>>>4)%5)<0)n++;}return n;});ok(s===0,'unsigned palette index never negative');
 // watchdog: a throwing update no longer kills the frame loop
 s=await E(async()=>{const t0=gtime,n0=WATCHDOG.n;const old=updateDaily;updateDaily=()=>{throw new Error('boom');};await new Promise(r=>setTimeout(r,600));updateDaily=old;await new Promise(r=>setTimeout(r,500));return {adv:gtime-t0,caught:WATCHDOG.n-n0};});
 ok(s.caught>0&&s.adv>.3,'frame watchdog catches errors and the loop keeps going ('+s.caught+' caught)');
 // sanitizer on load
 s=await E(()=>{const g=__game,P=g.P;P.x=NaN;P.gold=Infinity;const e=g.enemies.find(e=>!e.def.boss);e.x=NaN;sanitizeWorld('test');return {px:isFinite(P.x),gold:isFinite(P.gold),bad:g.enemies.some(e=>!isFinite(e.x))};});
 ok(s.px&&s.gold&&!s.bad,'sanitizeWorld fixes NaN player / foes');
 // 2. spawners: every card hurts one, auto-aim falls back to it
 s=await E(async()=>{const g=__game,X=g.t142(),d=Object.assign({},g.dbg,X),S=X.SPW[0],P=g.P,out={};
   const ids=['sword','fire','lance','frostbolt','crimsonbolt','frostburst','crimsonburst','chain','quake','meteor','poison','dragonfire','thunder','star','drain','wolf'];
   for(const id of ids){X.endFight();S.alive=true;S.dying=false;S.hp=S.maxhp=5000;P.x=S.x+50;P.y=S.y+30;d.startEncounter(g.enemies.find(e=>!e.def.boss),true);const B=X.B;B.phase='fight';B.ens.length=0;
     const a=Math.atan2(S.y-P.y,S.x-P.x);P.aim=a;try{X.CAST[id](X.CARD[id],1,a,X.pcen());}catch(err){out[id]='ERR';continue;}
     for(let i=0;i<120&&S.hp>=5000;i++)await new Promise(r=>setTimeout(r,16));out[id]=5000-S.hp;}
   X.endFight();d.startEncounter(g.enemies.find(e=>!e.def.boss),true);X.B.ens.length=0;P.x=S.x+60;P.y=S.y;const t=X.aimEnemy();out.aim=t&&t.type;X.endFight();S.hp=S.maxhp;return out;});
 const miss=Object.entries(s).filter(([k,v])=>k!=='aim'&&!(v>0));ok(!miss.length,'every attack damages a spawner '+JSON.stringify(s));
 ok(s.aim==='spawner','auto-aim targets a spawner when no monster is near');
 // 4. bog layout: organic, boardwalks, everything reachable from the arrival
 s=await E(()=>{const y0=ZONES.swamp.y0,seen=new Set([5+','+(y0+26)]),q=[[5,y0+26]];
   while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=nx+','+ny;if(seen.has(k)||ny<y0||ny>y0+31)continue;const t=map[ny][nx];if(solidTile(nx,ny)&&t!==T.CHST&&t!==T.GB)continue;seen.add(k);if(!solidTile(nx,ny))q.push([nx,ny]);}}
   const at=(x,dy)=>seen.has(x+','+(y0+dy));let bw=0,wt=0,ch=0;for(let y=y0;y<y0+30;y++)for(let x=0;x<64;x++){const t=map[y][x];if(t===T.BWK)bw++;if(t===T.W)wt++;if(t===T.CHST)ch++;}
   const foes=enemies.filter(e=>zoneOfTy(Math.floor(e.hy/TS))==='swamp'&&!e.def.boss).map(e=>at(Math.floor(e.hx/TS),Math.floor(e.hy/TS)-y0));
   let band=0;for(const row of [9,14,22]){let run=0;for(let x=2;x<62;x++)if(map[y0+row][x]===T.MR)run++;if(run>40)band++;}
   return {boss:at(36,4),cave:at(30,29),exit:at(3,27),bank:at(21,23),chests:ch,cr:BOG.pockets.every(p=>at(p[3],p[4])),bw,wt,foes:foes.every(Boolean),nf:foes.length,band};});
 ok(s.boss&&s.cave&&s.exit&&s.bank,'bog: boss arena, cave, exit rune and fishing bank reachable');
 ok(s.chests>=2&&s.cr,'bog: 2 chest side pockets reachable');
 ok(s.bw>=6&&s.wt>=20,'bog: boardwalks over water pockets ('+s.bw+' planks, '+s.wt+' water)');
 ok(s.foes&&s.nf>=8,'bog: every foe spawns on reachable ground ('+s.nf+')');
 ok(s.band===0,'bog: no straight rock bands left');
 // 5. south wall: warm palette, walk-over gate deck (walkable), towers + banners still there
 s=await E(()=>{const ty=Math.floor(TOWN.y1/TS);let gx=-1;for(let x=0;x<40;x++)if(map[ty-1][x]===T.P&&(map[ty-1][x-1]===T.B||map[ty-1][x-1]===T.BT)){gx=x;break;}
   const spr=gx>=0?SW.southTile(gx,ty-1):null;let warm=0;if(spr){const c=spr.getContext('2d').getImageData(0,0,spr.width,spr.height).data;for(let i=0;i<c.length;i+=4)if(c[i]>c[i+2]+8)warm++;}
   return {gx,walk:gx>=0&&!solidTile(gx,ty-1)&&!solidTile(gx,ty)&&!solidTile(gx,ty-2),warm,src:String(SW.southTile).includes('walk-over')};});
 ok(s.gx>0&&s.walk,'south gate span is walkable at x'+s.gx);
 ok(s.warm>40&&s.src,'gate deck drawn as a warm flagstone walk-over span');
 // 6. popup styles
 s=await E(async()=>{const X=__game.t142(),out=[];window.__NOREVEAL=false;__game.P.x=SPAWN.x;__game.P.y=SPAWN.y;for(let i=0;i<5;i++){X.endFight();SET.pop=i;X.revealPreview();await new Promise(r=>setTimeout(r,700));out.push(!!X.REV.cur&&X.REV.cur.name||[X.REV.q.length,!!X.B,!!DLG,state,typeof introHold==='function'&&introHold()].join('|'));X.REV.cur=null;}SET.pop=0;return {out,n:POP_STYLES.length,row:UI_MODES.settings.rows().some(r=>r.draw&&String(r.draw).includes('set:'))};});
 ok(s.n===5&&s.out.every(n=>n==='Silver Ring of Might'),'5 reward popup styles render the sample '+JSON.stringify(s.out));
 s=await E(()=>{SET.pop=3;setSave();SET.pop=0;setLoad();const v=SET.pop;SET.pop=0;setSave();return v;});ok(s===3,'popup style saved in settings');
 ok(['1-parchment','2-scroll','3-sign','4-chest','5-banner'].every(n=>fs.existsSync('/workspace/popup-options/'+n+'.png')),'popup mockup PNGs exist');
 s=await E(()=>navigator.serviceWorker?0:0);
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');ok(/arcane-knight-v50/.test(sw),'service worker v50');
 ok(!errs.length,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
