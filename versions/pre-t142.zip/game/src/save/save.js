
/* ---- save / load (localStorage) ---- */
const SAVE_KEY='arcaneKnight.save.v1',NOSAVE=new URLSearchParams(location.search).has('nosave');
function readSave(){try{const s=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');return s&&s.v===1&&s.P&&isFinite(s.P.x)?s:null;}catch(e){return null;}}
/* ---- safety net: the previous save is kept as a backup whenever it would be replaced by a clearly less advanced one (New Game, or a fresh hero
   overwriting a veteran), and the title screen offers to restore it ---- */
const BAK_KEY=SAVE_KEY+'.backup';
function readBackup(){try{const s=JSON.parse(localStorage.getItem(BAK_KEY)||'null');return s&&s.v===1&&s.P&&isFinite(s.P.x)?s:null;}catch(e){return null;}}
function backupSave(raw){   // raw = the JSON text about to be replaced; keep the most advanced one
  if(NOSAVE||!raw)return;try{const o=JSON.parse(raw),b=readBackup();if(!o||!o.P||!(o.P.lv>1||o.P.gold>0))return;if(b&&(b.P.lv>o.P.lv||(b.P.lv===o.P.lv&&b.P.gold>=o.P.gold)))return;localStorage.setItem(BAK_KEY,raw);}catch(e){}
}
function saveGame(why){
  if(NOSAVE||state==='title'||state==='fishlab'||P.hp<=0||RUSH.on)return false;
  try{const prev=localStorage.getItem(SAVE_KEY);if(prev){try{const o=JSON.parse(prev);if(o&&o.P&&P.lv<o.P.lv-1)backupSave(prev);}catch(e){}}}catch(e){}
  try{localStorage.setItem(SAVE_KEY,JSON.stringify({v:1,t:Date.now(),why,best:packBest(),area:areaCur,bossDown,lichDown,tod:DAY.t,kills,muted,cards:packCards(),gear:packGear(),quests:packQuests(),skills:packSkills(),craft:packCraft(),pets:packPets(),story:packStory(),daily:packDaily(),ach:packAch(),secrets:packSecrets(),spw:packSpawners(),fish:packFish(),
    fr:[OX,OY,OW_H],P:{x:Math.round(P.x),y:Math.round(P.y),dir:P.dir,hp:Math.max(1,Math.round(P.hp)),lv:P.lv,xp:P.xp,gold:P.gold,up:P.up}}));return true;}catch(e){return false;}
}
function loadSave(s){
  try{unpackBest(s.best);}catch(e){}
  unpackGear(s.gear);unpackQuests(s.quests);unpackSkills(s.skills);unpackCraft(s.craft);unpackPets(s.pets);unpackStory(s.story);unpackDaily(s.daily);unpackAch(s.ach);unpackSecrets(s.secrets);unpackSpawners(s.spw);unpackFish(s.fish);Object.assign(P,s.P);if(typeof edFrameFix==='function')edFrameFix(P,s.fr);P.moving=false;P.grace=3;P.regen=0;P.hp=clamp(P.hp,1,maxHp());
  bossDown=!!s.bossDown;lichDown=!!s.lichDown;if(typeof s.tod==='number'){DAY.t=s.tod;dayCompute();syncNight(true);}kills=s.kills|0;unpackCards(s.cards);if(typeof s.muted==='boolean')muted=s.muted;
  if(bossDown){const d=enemies.find(o=>o.type==='dragon');if(d){d.alive=false;d.respawn=150;}}
  if(lichDown){const d=enemies.find(o=>o.type==='lich');if(d){d.alive=false;d.respawn=240;}}
  snapCam();
}
function clearSave(){try{backupSave(localStorage.getItem(SAVE_KEY));localStorage.removeItem(SAVE_KEY);}catch(e){}}   // New Game keeps the old save as a backup
let saveTimer=0;
addEventListener('pagehide',()=>saveGame('hide'));
document.addEventListener('visibilitychange',()=>{if(document.hidden)saveGame('hide');});
