/* =====================================================================
   WALLS, PLANTERS, CHESTS + the new region tiles (Glowcap Grove, Shardstone Caverns, Ember Rift).
   Walls after Seth's kits: low mossy wall with pillars, low clean wall, castle wall (mossy / clean), ivy wall, ruined wall, towers, corner
   pillar, gatehouse arch, wooden gate. Straight walls AUTO-CONNECT: each tile looks at its 4 neighbours (any wall piece counts) and draws
   end caps / pillars / vertical runs / corners to match, so painting a line of wall gives one continuous wall.
   All 16px, light from the top-left, #14182c outline.
   ===================================================================== */
Object.assign(T,{WLM:59,WLC:60,WCM:61,WCC:62,WIV:63,WRU:64,TWM:65,TWC:66,WCN:67,WGH:68,WGT:69,PL1:70,PL2:71,PL3:72,PL4:73,CHST:74,
  MO:75,MS1:76,MS2:77,MS3:78,RG:79,CR1:80,CR2:81,CL:82,VB:83,LV:84,VR:85});
const WALL_IDS=new Set([T.WLM,T.WLC,T.WCM,T.WCC,T.WIV,T.WRU,T.TWM,T.TWC,T.WCN,T.WGH,T.WGT]);
const XWALLS=new Set([T.WLM,T.WLC,T.WCM,T.WCC,T.WIV,T.WRU,T.TWM,T.TWC,T.WCN,T.CL]);   // block shots too
[T.WLM,T.WLC,T.WCM,T.WCC,T.WIV,T.WRU,T.TWM,T.TWC,T.WCN,T.PL1,T.PL2,T.PL3,T.PL4,T.CHST,T.MS1,T.MS2,T.CR1,T.CR2,T.CL,T.LV].forEach(t=>SOLID.add(t));
const XTILE_FN={};
(function buildWallArt(){
  const O='#14182c',px=(g,x,y,c)=>rect(g,x,y,1,1,c);
  const grass=g=>g.drawImage(TSPR[T.G][0],0,0);
  const KIT={   // stone, light, dark, mortar
    m:['#7a7888','#9e9cac','#555366','#45434f'],c:['#8a8a98','#b4b4c2','#62626e','#4e4e5a'],s:['#c8b48c','#e4d4ac','#9a8460','#7a6648']};
  const moss=(g,x,y,w,seed)=>{for(let i=0;i<w;i++){const h=hash2(x+i+seed,y)%3;rect(g,x+i,y,1,1+(h===0?1:0),'#6aa83a');if(h===1)px(g,x+i,y,'#9ad050');}};
  const bricks=(g,y0,y1,k,seed)=>{const [s,l,d,m]=KIT[k];rect(g,0,y0,16,y1-y0,s);for(let y=y0;y<y1;y+=3){rect(g,0,y+2,16,1,m);const off=((y/3|0)+seed)%2?0:4;for(let x=off;x<16;x+=8){px(g,x,y,m);px(g,x,y+1,m);rect(g,x+1,y,3,1,l);}}rect(g,15,y0,1,y1-y0,d);};
  const crack=(g,x,y,c)=>{px(g,x,y,c);px(g,x+1,y+1,c);px(g,x+1,y+2,c);px(g,x+2,y+3,c);};
  // a horizontal run segment: low (h=9) or castle (full + merlons); ends: L/R caps
  function seg(g,kind,L,R,x,y){
    const low=kind===T.WLM||kind===T.WLC,mossy=kind===T.WLM||kind===T.WCM||kind===T.WIV,k=low?(mossy?'m':'c'):kind===T.WCC||kind===T.WIV?'c':'m';
    const [s,l,d,m]=KIT[k];
    if(low){
      rect(g,0,14,16,2,'rgba(20,24,44,.35)');                                            // contact shadow
      for(let i=0;i<4;i++){const bx=(i*5+(hash2(x,y)%3))%16,h=hash2(x*3+i,y)%2;ell(g,bx+2,9+h+(i%2)*2,3,2,s);ell(g,bx+1,8+h+(i%2)*2,2,1,l);}   // rounded fieldstones
      rect(g,0,7,16,1,O);rect(g,0,8,16,6,s);for(let i=0;i<5;i++){const sx=(i*4+hash2(x,y+i)%2)%16;rect(g,sx,9+(i%2)*2,3,2,l);px(g,sx+2,10+(i%2)*2,d);rect(g,sx,11+(i%2)*2,3,1,m);}
      rect(g,0,13,16,1,d);rect(g,0,14,16,1,O);
      if(mossy){moss(g,0,8,16,x*7);for(let i=0;i<3;i++)rect(g,(hash2(x,y+i)%13),8,3,2,'#7ab84a');}
      const pil=(px0)=>{rect(g,px0,3,5,12,O);rect(g,px0+1,5,3,9,s);rect(g,px0+1,5,1,9,l);rect(g,px0+3,5,1,9,d);rect(g,px0,3,5,2,'#d8d4c8');rect(g,px0,3,5,1,'#f0ece2');rect(g,px0+1,9,3,1,m);if(mossy)rect(g,px0+1,6,2,2,'#7ab84a');};
      if(L||x%4===0)pil(0);if(R)pil(11);
      // ground tufts
      for(let i=0;i<4;i++){const gx=hash2(x+i,y*3)%15;px(g,gx,15,'#4f9a3a');px(g,gx+1,14,'#6ab84a');}
      return;
    }
    // castle wall: full height
    bricks(g,4,15,k,x&1);rect(g,0,15,16,1,O);rect(g,0,3,16,1,O);
    for(let mx=0;mx<16;mx+=6){rect(g,mx,0,4,4,O);rect(g,mx+1,1,2,2,l);px(g,mx+1,1,'#e8e6f0');}   // merlons
    rect(g,0,4,16,1,l);
    if(mossy){moss(g,0,4,16,x*5);for(let i=0;i<2;i++){const dx=hash2(x,y+i*7)%14;rect(g,dx,5,2,2+hash2(dx,i)%3,'#6aa83a');}}
    if(kind===T.WIV){for(let i=0;i<3;i++){const vx=(hash2(x,y+i)%12)+1;for(let yy=4;yy<15;yy++){const ox=Math.round(Math.sin((yy+i*3)*.9)*1.2);px(g,vx+ox,yy,yy%3?'#3e8a3a':'#6ac05a');if(yy%4===0)rect(g,vx+ox-1,yy,3,1,'#4f9a3a');}}}
    if(hash2(x,y)%3===0)crack(g,4+hash2(x,y)%7,7,d);
    if(L){rect(g,0,0,2,16,O);rect(g,2,4,1,11,l);}if(R){rect(g,14,0,2,16,O);rect(g,13,4,1,11,d);}
    if(mossy&&hash2(x,y)%2)for(let i=0;i<3;i++){px(g,(hash2(x+i,y)%14)+1,14,'#9ad050');px(g,(hash2(x,y+i)%14)+1,15,'#6ab84a');}
  }
  // a wall running north-south (seen from above-front): the coping strip down the middle, stone face on its right side
  function vrun(g,kind,U,D){
    const low=kind===T.WLM||kind===T.WLC,mossy=kind===T.WLM||kind===T.WCM||kind===T.WIV,k=low?(mossy?'m':'c'):kind===T.WCC||kind===T.WIV?'c':'m',[s,l,d,m]=KIT[k];
    const w=low?6:8,x0=8-(w>>1);
    rect(g,x0-1,0,w+2,16,O);rect(g,x0,0,w,16,s);rect(g,x0,0,2,16,l);rect(g,x0+w-2,0,2,16,d);
    for(let y=1;y<16;y+=4){rect(g,x0,y,w,1,m);px(g,x0+3,y+2,m);}
    if(!low)for(let y=0;y<16;y+=6){rect(g,x0-1,y,w+2,3,O);rect(g,x0,y,w,2,l);}
    if(mossy)for(let y=0;y<16;y+=3)if(hash2(y,w)%2)rect(g,x0+1+(y%3),y,2,1,'#6aa83a');
    if(kind===T.WIV)for(let y=0;y<16;y+=2)px(g,x0+w-1,y,'#4f9a3a');
    if(!U){rect(g,x0-1,0,w+2,3,O);rect(g,x0,1,w,2,'#d8d4c8');}if(!D){rect(g,x0-1,13,w+2,3,O);rect(g,x0,13,w,2,d);}
  }
  function pillar(g,kind,big){   // tower / corner post
    const mossy=kind===T.TWM||kind===T.WCN,k=mossy?'m':'c',[s,l,d,m]=KIT[k],x0=big?1:3,w=big?14:10;
    rect(g,x0-1,0,w+2,16,O);rect(g,x0,4,w,11,s);for(let y=6;y<15;y+=3){rect(g,x0,y,w,1,m);rect(g,x0+((y/3|0)%2?2:5),y-2,1,2,m);}
    rect(g,x0,4,2,11,l);rect(g,x0+w-2,4,2,11,d);
    for(let mx=x0;mx<x0+w;mx+=4){rect(g,mx,0,3,4,l);px(g,mx,0,'#e8e6f0');}rect(g,x0,3,w,1,O);
    if(big){rect(g,7,7,2,4,O);if(kind===T.TWM){rect(g,10,5,3,6,'#2a4aa0');rect(g,10,5,3,1,'#e0b030');px(g,11,9,'#e0b030');rect(g,10,11,1,1,'#2a4aa0');rect(g,12,11,1,1,'#2a4aa0');}}
    if(mossy){moss(g,x0,4,w,7);rect(g,x0,5,2,4,'#6aa83a');rect(g,x0+w-3,9,2,5,'#4f9a3a');}
    rect(g,x0,15,w,1,O);
  }
  const conn=(x,y)=>x>=0&&y>=0&&x<MW&&y<MH&&WALL_IDS.has(map[y][x]);
  const WCACHE=new Map();
  function wallTile(id,x,y,mk){
    const L=mk!=null?!!(mk&1):conn(x-1,y),R=mk!=null?!!(mk&2):conn(x+1,y),U=mk!=null?!!(mk&4):conn(x,y-1),D=mk!=null?!!(mk&8):conn(x,y+1);
    const key=id+':'+(L|R<<1|U<<2|D<<3)+':'+(x%4)+':'+(hash2(x,y)%4);let c=WCACHE.get(key);if(c)return c;
    c=makeSprite(16,16,g=>{grass(g);
      if(id===T.TWM||id===T.TWC){pillar(g,id,true);return;}
      if(id===T.WCN){pillar(g,T.WCN,false);return;}
      if(id===T.WGH){   // gatehouse arch (walk through): towers' masonry around a dark arch, raised portcullis, lanterns
        bricks(g,0,16,'m',0);rect(g,3,4,10,12,'#1a1626');ell(g,8,5,5,3,'#1a1626');for(let i=4;i<13;i+=2)rect(g,i,3,1,4,'#7a5530');rect(g,3,5,10,1,'#7a5530');
        rect(g,0,6,2,4,O);rect(g,1,7,1,2,'#ffd23f');rect(g,14,6,2,4,O);rect(g,14,7,1,2,'#ffd23f');moss(g,0,0,16,3);rect(g,4,14,8,2,'#8d7a5c');return;}
      if(id===T.WGT){   // wooden double gate between stone posts
        rect(g,0,2,3,14,O);rect(g,1,3,1,12,'#9e9cac');rect(g,13,2,3,14,O);rect(g,14,3,1,12,'#7a7888');rect(g,0,1,3,2,'#d8d4c8');rect(g,13,1,3,2,'#d8d4c8');
        rect(g,3,4,10,12,'#6a4224');for(let i=3;i<13;i+=2)rect(g,i,4,1,12,'#8a5a32');rect(g,7,4,2,12,'#3a2414');rect(g,3,6,10,1,'#3e3e4a');rect(g,3,12,10,1,'#3e3e4a');px(g,6,9,'#c8c8d0');px(g,9,9,'#c8c8d0');rect(g,3,3,10,1,O);return;}
      if(id===T.WRU){   // ruined: broken uneven top, fallen stones
        const lo=hash2(x,y)%4;bricks(g,5+lo,15,'m',x&1);rect(g,0,15,16,1,O);
        for(let i=0;i<16;i+=3){const h=5+lo-(hash2(x+i,y)%4);rect(g,i,h,3,1,O);rect(g,i,h+1,3,1,'#9e9cac');}
        for(let i=0;i<3;i++){const rx=hash2(x+i,y*5)%13;ell(g,rx+1,14,1,1,'#8a8898');}moss(g,0,9+lo,16,x);return;}
      const vert=(U||D)&&!(L||R);
      if(vert){vrun(g,id,U,D);return;}
      seg(g,id,!L,!R,x,y);
      if(U||D){const low=id===T.WLM||id===T.WLC;rect(g,5,0,6,low?8:4,O);rect(g,6,0,4,low?8:4,KIT.m[0]);}   // a T / corner joint
    });
    WCACHE.set(key,c);return c;
  }
  for(const id of WALL_IDS)XTILE_FN[id]=(x,y)=>wallTile(id,x,y);
  // ---- planters ----
  const flower=(g,x,y,c,cc='#ffe14d')=>{rect(g,x-1,y,3,1,c);rect(g,x,y-1,1,3,c);px(g,x,y,cc);};
  const leaves=(g,x0,y0,w,h,seed)=>{rect(g,x0,y0,w,h,'#3e7a2e');for(let i=0;i<w*h/3;i++){const hh=hash2(seed+i,i*7);px(g,x0+hh%w,y0+(hh>>4)%h,hh&1?'#5ea83a':'#2e5e22');}};
  TSPR[T.PL1]=[0,1].map(v=>makeSprite(16,16,g=>{grass(g);rect(g,1,2,14,13,O);rect(g,2,3,12,11,'#a8642a');leaves(g,3,4,10,7,v+3);
    for(const [x,y,c] of [[5,5,'#f070a0'],[10,6,'#fff4e0'],[7,9,'#fff4e0'],[11,9,'#f070a0']])flower(g,x,y,c);
    rect(g,2,11,12,3,'#b8743a');rect(g,2,11,12,1,'#d8945a');rect(g,2,13,12,1,'#8a4a1e');for(const [x,y] of [[1,2],[12,2],[1,11],[12,11]]){rect(g,x,y,3,3,'#c8844a');px(g,x,y,'#e8a46a');}}));
  TSPR[T.PL2]=[0,1].map(v=>makeSprite(16,16,g=>{grass(g);rect(g,1,1,14,14,O);rect(g,2,2,12,12,'#b0aaa0');for(let y=2;y<14;y+=4){rect(g,2,y+3,12,1,'#8a847a');}rect(g,2,2,12,1,'#d8d2c6');
    rect(g,4,4,8,6,'#3a2a1a');leaves(g,4,4,8,6,v+9);for(const [x,y] of [[6,5],[9,6],[7,8],[10,9]])flower(g,x,y,'#9a5ad0','#f0e0ff');rect(g,2,11,12,3,'#9a948a');rect(g,2,11,12,1,'#c8c2b6');}));
  TSPR[T.PL4]=[0,1].map(v=>makeSprite(16,16,g=>{grass(g);rect(g,1,1,14,14,O);rect(g,2,2,12,12,'#e8d4a0');for(let y=2;y<14;y+=4)rect(g,2,y+3,12,1,'#c8b07a');rect(g,4,4,8,7,'#4a2e1a');
    ell(g,8,7,4,3,'#3e8a2e');ell(g,7,6,3,2,'#5eb03e');for(const [x,y] of [[4,5],[12,6],[5,10],[11,10],[8,4]])px(g,x,y,'#f070a0');rect(g,2,12,12,2,'#d8c08a');}));
  const PCACHE=new Map();
  XTILE_FN[T.PL3]=(x,y)=>{const L=x>0&&map[y][x-1]===T.PL3,R=x<MW-1&&map[y][x+1]===T.PL3,key=(L?1:0)|(R?2:0)|((hash2(x,y)%3)<<2);let c=PCACHE.get(key);if(c)return c;
    c=makeSprite(16,16,g=>{grass(g);rect(g,0,4,16,11,O);rect(g,0,5,16,9,'#a8642a');leaves(g,0,5,16,5,key*13);const cols=['#e04040','#f0c030','#fff4e0'];for(let i=0;i<3;i++)flower(g,3+i*5,7+(i%2),cols[(key+i)%3]);
      rect(g,0,10,16,4,'#b8743a');rect(g,0,10,16,1,'#d8945a');rect(g,0,13,16,1,'#8a4a1e');if(!L){rect(g,0,4,2,11,O);rect(g,1,5,1,9,'#c8844a');}if(!R){rect(g,14,4,2,11,O);rect(g,14,5,1,9,'#8a4a1e');}});
    PCACHE.set(key,c);return c;};
  // ---- treasure chest (closed / open), drawn per state ----
  const chest=(open,tier)=>makeSprite(16,16,g=>{grass(g);const wood=tier>=2?'#5a3a6a':'#8a5a2c',woodL=tier>=2?'#7a5a8a':'#a8743c',band=tier>=1?'#e0b030':'#9aa4b4';
    rect(g,1,6,14,9,O);rect(g,2,8,12,6,wood);rect(g,2,8,12,1,woodL);rect(g,2,13,12,1,'#3a2414');rect(g,2,8,1,6,band);rect(g,13,8,1,6,band);
    if(open){rect(g,1,1,14,6,O);rect(g,2,2,12,4,'#3a2414');rect(g,2,2,12,1,woodL);rect(g,3,6,10,2,'#1a1008');rect(g,4,6,8,1,'#ffd23f');px(g,6,6,'#fff6c0');}
    else{rect(g,1,4,14,4,O);rect(g,2,5,12,3,woodL);rect(g,2,5,12,1,'#d8a868');rect(g,2,5,1,3,band);rect(g,13,5,1,3,band);rect(g,7,7,2,3,band);px(g,7,8,O);}});
  const CH=[0,1,2].map(t=>[chest(false,t),chest(true,t)]);
  XTILE_FN[T.CHST]=(x,y)=>{const t=chestTier(x,y);return CH[t][chestOpened(x,y)?1:0];};
  // ---- Glowcap Grove ----
  TSPR[T.MO]=[1,2,3].map(s=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#2e5a3a');sprinkle(g,s*31,['#3a6e44','#264a30','#4a8050'],22);for(let i=0;i<3;i++){const h=hash2(s,i);px(g,h%16,(h>>4)%16,'#8ae0a0');}}));
  TSPR[T.MS1]=[0,1].map(v=>makeSprite(16,16,g=>{g.drawImage(TSPR[T.MO][v],0,0);rect(g,3,15,10,1,'rgba(0,0,0,.35)');rect(g,6,8,4,7,'#e8dcc4');rect(g,9,8,1,7,'#c4b496');
    ell(g,8,6,7,5,O);ell(g,8,6,6,4,'#b8283a');ell(g,6,4,3,2,'#e05a5a');rect(g,2,8,13,1,'#7a1424');for(const [x,y] of [[4,5],[10,3],[11,7],[6,7]])rect(g,x,y,2,1,'#fff0e0');}));
  TSPR[T.MS2]=[0,1].map(v=>makeSprite(16,16,g=>{g.drawImage(TSPR[T.MO][v],0,0);rect(g,5,15,8,1,'rgba(0,0,0,.35)');rect(g,7,8,3,7,'#d8d0e8');ell(g,8,6,6,4,O);ell(g,8,6,5,3,'#7a3aa4');ell(g,7,5,3,2,'#b07ae0');
    for(const [x,y] of [[5,6],[10,5],[8,3]])px(g,x,y,'#f0d8ff');rect(g,3,8,11,1,'#4a1e6a');px(g,4,11,'#c8a0ff');px(g,12,12,'#c8a0ff');}));
  TSPR[T.MS3]=[0,1,2].map(v=>makeSprite(16,16,g=>{g.drawImage(TSPR[T.MO][v],0,0);const cols=['#c8323a','#9a5ab8','#d8902a'];for(let i=0;i<3;i++){const x=3+i*4+(v*2)%3,y=8+(i%2)*3;rect(g,x+1,y+1,1,3,'#f0e6d0');ell(g,x+1,y,2,1,cols[(i+v)%3]);px(g,x,y-1,'#fff0e0');}}));
  // ---- Shardstone Caverns / quarry ----
  TSPR[T.RG]=[1,2,3].map(s=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#8a8494');sprinkle(g,s*17,['#9e98a8','#76707e','#aaa4b4','#6a6472'],30);for(let i=0;i<2;i++){const h=hash2(s*3,i);rect(g,h%14,(h>>4)%14,2,1,'#625c6a');}}));
  const crystal=(c,cl,cd)=>[0,1].map(v=>makeSprite(16,16,g=>{g.drawImage(TSPR[T.RG][v],0,0);rect(g,2,14,12,2,'rgba(0,0,0,.3)');
    for(const [x,h,w] of [[7,13,4],[3,8,3],[11,9,3]]){tri(g,x+w/2,15-h,x,15,x+w,15,O);tri(g,x+w/2,16-h,x+.6,15,x+w-.6,15,c);rect(g,x+1,16-h+3,1,h-4,cl);rect(g,x+w-1,16-h+4,1,h-5,cd);}
    px(g,8,4,'#ffffff');}));
  TSPR[T.CR1]=crystal('#a060e0','#e0c0ff','#6a2aa4');TSPR[T.CR2]=crystal('#40c8d8','#c8ffff','#1a7a8a');
  TSPR[T.CL]=[0,1,2].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#5e5868');for(let i=0;i<5;i++){const h=hash2(v*7+i,i*3);const x=h%12,y=(h>>4)%12;rect(g,x,y,5,4,'#787282');rect(g,x,y,5,1,'#948ea0');rect(g,x+4,y,1,4,'#4a4454');}rect(g,0,0,16,1,'#a8a2b4');rect(g,0,15,16,1,'#3a3444');}));
  // ---- Ember Rift (volcanic edge) ----
  TSPR[T.VB]=[1,2,3].map(s=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3a3036');sprinkle(g,s*13,['#4a3e44','#2e262c','#5a4a4e'],26);if(s===2){line(g,3,4,6,7,'#c8501e');px(g,7,8,'#ff9a2a');}}));
  const LAVA=[0,1,2,3].map(f=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#c83a10');for(let i=0;i<10;i++){const h=hash2(i*7+f,i);ell(g,(h+f*3)%16,(h>>4)%16,2,1,i%2?'#ff8a1e':'#ffc23a');}for(let i=0;i<3;i++){const h=hash2(f,i*9);px(g,h%16,(h>>4)%16,'#fff0a0');}}));
  XTILE_FN[T.LV]=(x,y,time)=>LAVA[(Math.floor(time*3)+x+y)&3];TSPR[T.LV]=[LAVA[0]];
  TSPR[T.VR]=[0,1].map(v=>makeSprite(16,16,g=>{g.drawImage(TSPR[T.VB][v],0,0);ell(g,8,10,4,2,'#1e1418');ell(g,8,10,2,1,'#ff6a1e');px(g,8,9,'#ffd23f');}));
  Object.assign(TSPR.mini,{[T.WLM]:'#7a7888',[T.WLC]:'#8a8a98',[T.WCM]:'#6a6878',[T.WCC]:'#8a8a98',[T.WIV]:'#4a7a3a',[T.WRU]:'#7a7888',[T.TWM]:'#5a5868',[T.TWC]:'#7a7a88',[T.WCN]:'#6a6878',[T.WGH]:'#2a2436',[T.WGT]:'#7a4a24',
    [T.PL1]:'#a8642a',[T.PL2]:'#9a5ad0',[T.PL3]:'#a8642a',[T.PL4]:'#e8d4a0',[T.CHST]:'#ffd23f',[T.MO]:'#2e5a3a',[T.MS1]:'#b8283a',[T.MS2]:'#7a3aa4',[T.MS3]:'#3a6e44',[T.RG]:'#8a8494',[T.CR1]:'#a060e0',[T.CR2]:'#40c8d8',[T.CL]:'#4a4454',[T.VB]:'#3a3036',[T.LV]:'#ff6a1e',[T.VR]:'#5a2a1e'});
  for(const id of WALL_IDS)TSPR[id]=[wallTile(id,1,1,3)];          // thumbnails / fallbacks: a straight, joined piece
  TSPR[T.CHST]=[CH[0][0]];TSPR[T.PL3]=[makeSprite(16,16,g=>{g.drawImage(TSPR[T.PL1][0],0,0);})];
})();
XTILE_FN[T.CWL]=(x,y)=>chapelWallTile(x,y);
