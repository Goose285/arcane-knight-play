// M53: town batch - house moved 2 tiles left, guards / fisher repositioned, slime quests point north of town, the Inn's own look, guards only act within 5 tiles, quest-complete chime + sparkle.  (t138u: fights inside town now auto-end, so section 5 sets the __NOESC test hook)
// Screens store/town-batch.png + store/inn-look.png (landscape).  node tests/ms53.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms53',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.TRK.open=false;
   for(const e of g.enemies)if(e.alive&&!e.night){e.mt=1e9;e.lk=1e9;}});
 // ---- 1. the player's house: 2 tiles left (door, trigger, collision)
 const h=await E(()=>{const g=__game,d=g.dbg,T=d.T,m=d.map,D=d.HOUSE_DOOR;return {door:D.tx,doorTile:m[43][19]===T.D,oldDoor:m[43][21]!==T.D,wallOld:!d.solidTile(22,43)&&!d.solidTile(23,42),wallNew:d.solidTile(18,43)&&d.solidTile(17,43)&&d.solidTile(20,43),frontFree:!d.solidTile(19,44)};});
 ok(h.door===19&&h.doorTile&&h.oldDoor&&h.wallOld&&h.wallNew&&h.frontFree,'house moved 2 tiles left '+JSON.stringify(h));
 const ent=await E(async()=>{const g=__game,d=g.dbg,F=d.HOUSE_FRONT;g.tp(19,44);g.P.x=F.x;g.P.y=F.y-6;g.P.grace=99;g.state='play';g.DLG=null;const ok1=d.enterHouse();await new Promise(r=>setTimeout(r,1800));const z=d.zoneOfPx(g.P.y);return {ok1,z};});
 ok(ent.z==='house'||ent.ok1,'walking up to the new door enters the house ('+JSON.stringify(ent)+')');
 await E(()=>{const g=__game,d=g.dbg;g.WARP=null;g.tp(19,45);g.P.x=19*32+16;g.P.y=45*32+28;g.P.grace=99;});await sleep(500);
 // ---- 2. guards + fisher
 const pos=await E(()=>{const g=__game,d=g.dbg,s=d.solidTile,gs=g.npcs.filter(n=>n.tguard),f=g.npcs.find(n=>n.fisher),t=(n)=>({x:Math.floor(n.x/32),y:Math.floor(n.y/32)});
   return {guards:gs.map(n=>({...t(n),tile:d.map[t(n).y][t(n).x]})),fisher:{...t(f),tile:d.map[t(f).y][t(f).x],fy:+(f.y/32).toFixed(1)},P:d.T.P,G:d.T.G,solid:gs.some(n=>s(t(n).x,t(n).y))||s(t(f).x,t(f).y)};});
 ok(!pos.solid&&pos.guards.every(q=>q.tile===pos.G),'guards stand on open grass, not on the road '+JSON.stringify(pos.guards));
 ok(pos.fisher.fy>=41.5&&pos.fisher.tile===pos.G,'fisher moved ~2 tiles down onto grass by the water ('+JSON.stringify(pos.fisher)+')');
 // ---- 3. slimes: all in the meadow just north of town; the quest arrow points there
 const sl=await E(()=>{const g=__game,d=g.dbg,s=g.enemies.filter(e=>e.type==='slime'&&!e.night&&!e.spawner&&e.alive);
   d.questStart('gel');const en=d.trkEntries().find(e=>e.id==='q:gel');const tg=d.trkTarget(en);return {n:s.length,allNorth:s.every(e=>e.x<25*32&&e.y<27*32),tg:tg&&{x:Math.round(tg.x/32),y:Math.round(tg.y/32)}};});
 ok(sl.n>=5&&sl.allNorth,'every open-world slime lives in the meadow north of Oakvale ('+sl.n+', allNorth '+sl.allNorth+')');
 ok(sl.tg&&sl.tg.x<25&&sl.tg.y<27&&sl.tg.y>=12,'the Goo for Pip arrow targets a slime north of town '+JSON.stringify(sl.tg));
 // ---- 5. guard range: a far foe is never struck, a near one is
 const fight=(dx,dy)=>E((dx,dy)=>{const g=__game,d=g.dbg;window.__NOESC=1;d.endFight();g.state='play';const G=g.npcs.filter(n=>n.tguard)[0];g.tp(12,32);g.P.x=12.5*32;g.P.y=32*32+28;g.P.grace=0;
   for(const o of g.enemies)if(o.alive&&!o.night){o.mt=1e9;o.lk=1e9;}
   const e=g.enemies.find(q=>q.type==='slime'&&!q.night&&!q.def.boss);e.alive=true;e.dying=false;e.gdie=false;e.x=e.hx=G.hx+dx*32;e.y=e.hy=G.hy+dy*32;e.hp=e.maxhp=e.mhp=900;e.calm=0;window.__e=e;
   d.startEncounter(e,true);e.stun=1e9;e.atkCd=1e9;g.B.ens=g.B.ens.filter(q=>q===e);g.B.noiseT=g.B.proxT=1e9;g.B.phase='fight';g.B.dim=1;e.joinT=0;g.B.inv=999;},dx,dy);
 await fight(0,-8.5);let struck=0;for(let i=0;i<25;i++){await sleep(150);struck=Math.max(struck,await E(()=>(window.__e.hp<window.__e.maxhp?1:0)+__game.townDbg().TGB.length));}
 ok(struck===0,'a guard never strikes a foe 8.5 tiles away, even with the hero fighting inside town (struck='+struck+')');
 await fight(0,-3.5);let hit=0;for(let i=0;i<25&&!hit;i++){await sleep(150);hit=await E(()=>window.__e.hp<window.__e.maxhp||window.__e.dying||!window.__e.alive?1:0);}
 ok(hit===1,'...but one within 5 tiles is struck');
 const leash=await E(()=>{const G=__game.npcs.filter(n=>n.tguard).map(n=>Math.hypot(n.x-n.hx,n.y-n.hy)/32);return Math.max(...G);});
 ok(leash<=2,'guards stay within ~2 tiles of their post ('+leash.toFixed(2)+')');
 await E(()=>{__game.dbg.endFight();});
 // ---- 6. quest-complete: chime + sparkle text, no flash
 const qc=await E(()=>{const g=__game,d=g.dbg;let chime=0;const orig=d.tone;d.WFX.length=0;d.questStart('slimes');d.QS.st.slimes='ready';let n=0;const sfxCalls=[];
   const r=d.questComplete('slimes');return {txt:d.WFX.some(w=>w.k==='t'&&/Quest Complete/.test(w.s)),sp:d.WFX.filter(w=>w.k==='p').length,r:r[0]};});
 ok(qc.txt&&qc.sp>=10,'quest complete shows a gold "Quest Complete!" sparkle ('+JSON.stringify(qc)+')');
 const snd=await E(()=>!!__game.dbg.SFXT().questdone);ok(snd,'a dedicated quest-complete sound exists');
 // ---- screenshots
 await E(()=>{const g=__game;g.dbg.WFX.length=0;g.dbg.toasts.length=0;g.dbg.endFight();d0=g.dbg;g.dbg.resetQuests&&g.dbg.resetQuests();g.tp(16,39);g.P.x=16.5*32;g.P.y=39.9*32;g.dbg.TRK.open=false;g.P.grace=99;g.snapCam&&g.snapCam();});await sleep(800);
 await shot('town-batch.png');
 await E(()=>{const g=__game;g.tp(8,34);g.P.x=8.5*32;g.P.y=34.5*32;g.dbg.TRK.open=false;g.snapCam&&g.snapCam();});await sleep(700);
 await shot('inn-look.png');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
