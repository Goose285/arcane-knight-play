// M68 (t151u): hitch mitigations — no VW/S change, hitch counter, resize early-out, vision throttle.
//   node tests/ms68.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms68',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t151/.test(tags),'backup tag backup-pre-t151');
 await E(()=>__game.dbg.startFromTitle());await sleep(800);
 let s=await E(()=>{SET.perf=true;SET.fps=true;qualApply();const v0=VW,h0=VH,s0=S;resize();resize();return {v0,h0,s0,VW,VH,S,DPR,same:VW===v0&&VH===h0&&S===s0};});
 ok(s.same,'resize is idempotent (no VW/VH/S thrash)');
 ok(s.DPR===1,'perf DPR 1');
 if(MOB)ok(s.VW>=700,'mobile VW not capped ('+s.VW+')');
 s=await E(()=>({hasHitch:'hitch' in QUAL,drawFps:String(drawFps).includes('skip'),vis:String(drawVision).includes('VIS_FR')||String(drawVision).includes('%3'),ai:String(update).includes('EN_AI_I')||true}));
 // EN_AI_I is in movement closure - check source file
 ok(s.hasHitch&&s.drawFps,'FPS overlay reports hitch/skip counter');
 ok(fs.readFileSync(__dirname+'/../src/player/movement.js','utf8').includes('EN_AI_I'),'enemy AI is staggered');
 ok(fs.readFileSync(__dirname+'/../src/render/world.js','utf8').includes('ENTS_BUF'),'drawWorld reuses entity buffer');
 ok(fs.readFileSync(__dirname+'/../src/main.js','utf8').includes('resizeSoon'),'resize events are debounced');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');
 ok(/arcane-knight-v57/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v57');
 await sleep(200);ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
