// M64 (t147u): performance - DPR capped, fog half-res, chunked tiles, cached HUD skins, auto quality, lighting mask throttle.
//   node tests/ms64.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms64',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t147/.test(tags),'backup tag backup-pre-t147');
 await E(()=>__game.dbg.startFromTitle());await sleep(700);
 let s=await E(()=>({dpr:DPR,cap:QUAL.wantDpr,fog:String(drawFog).includes('FOG_BUF')||String(drawFog).includes('fogDrawFast'),panel:PANEL_SKIN instanceof Map,chunks:typeof chGet==='function',hd:!!HDX}));
 ok(s.dpr<=2&&s.cap<=2,'DPR capped at 2 (got '+s.dpr+', want '+s.cap+')');
 ok(s.fog,'fog uses the half-res buffer path');
 ok(s.panel,'HUD panel skins are cached');
 ok(s.chunks,'chunked tile cache is live');
 // build a few chunks + confirm fog buffer
 s=await E(()=>{P.x=21*32;P.y=262*32;FOG.a=.8;drawFog();FOG.a=0;const n0=CH.map.size;drawWorld();return {chunks:CH.map.size,fogW:FOG_BUF&&FOG_BUF.width,fogH:FOG_BUF&&FOG_BUF.height,VW,panelN:PANEL_SKIN.size};});
 ok(s.chunks>=1,'chunks baked for the view ('+s.chunks+')');
 ok(s.fogW>0&&s.fogW<=s.VW,'fog buffer is half-res or smaller ('+s.fogW+' <= '+s.VW+')');
 // auto quality steps
 s=await E(()=>{const a=QUAL.mode;QUAL.mode='lo';qualApply();const dprLo=QUAL.wantDpr,hdLo=HDX.on;QUAL.mode='hi';qualApply();return {a,dprLo,hdLo,dprHi:QUAL.wantDpr,hdHi:HDX.on};});
 ok(s.dprLo===1&&s.hdLo===false&&s.dprHi===2&&s.hdHi===true,'auto quality lo/hi toggles DPR + HD');
 // panel cache hit
 s=await E(()=>{PANEL_SKIN.clear();panel(10,10,100,40,{});const n1=PANEL_SKIN.size;panel(10,10,100,40,{});return {n1,n2:PANEL_SKIN.size};});
 ok(s.n1===1&&s.n2===1,'panel skin cached (no rebuild on second draw)');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');ok(/arcane-knight-v53/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v53');
 await sleep(400);ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
