/* =====================================================================
   t147–t150 PERFORMANCE
   Real iPhones: canvas at DPR 2–3 fills ~1–2M px/frame. Perf mode (default ON)
   forces DPR=1 + CSS image-rendering:pixelated — draw quality only.
   t150u: NEVER change VW/VH/S/HUD metrics here (t149 VW≤420 / S≥2 made the
   leather HUD collide: RUN on hero bars, oversized dialogue/minimap). Keep
   cheap fog, light night lights, HD off, water-life cull, FPS overlay.
   ===================================================================== */
const QUAL={mode:'perf',fps:60,acc:0,n:0,t:0,wantDpr:1,locked:true};
function qualTick(dt){
  QUAL.acc+=dt;QUAL.n++;QUAL.t+=dt;
  if(QUAL.t<.75)return;QUAL.fps=QUAL.n/Math.max(.001,QUAL.t);QUAL.n=0;QUAL.t=0;
}
function perfOn(){return typeof SET==='undefined'||SET.perf!==false;}   // default ON (unset / true); only OFF when explicitly false
function qualApply(){
  const on=perfOn();QUAL.mode=on?'perf':'hi';QUAL.wantDpr=on?1:2;
  FOG_LQ=on;if(typeof HDX!=='undefined'){HDX.on=!on;HDX.spr=!on;}
  try{resize();}catch(e){}
}
/* ---- DPR: perf mode forces 1; otherwise cap at 2 ---- */
{const _rs=resize;resize=function(){
  const raw=window.devicePixelRatio||1,cap=perfOn()?1:2;
  const desc=Object.getOwnPropertyDescriptor(window,'devicePixelRatio');
  try{Object.defineProperty(window,'devicePixelRatio',{configurable:true,get:()=>Math.min(raw,cap)});_rs();}
  finally{if(desc)Object.defineProperty(window,'devicePixelRatio',desc);else delete window.devicePixelRatio;}
  DPR=Math.min(raw,cap);QUAL.wantDpr=DPR;
  try{cv.style.imageRendering='pixelated';}catch(e){try{cv.style.imageRendering='crisp-edges';}catch(_){}}
};}
/* ---- Fog half-res ---- */
let FOG_LQ=true,FOG_BUF=null,FOG_BG=null,FOG_KEY='';
function fogDrawFast(){
  if(FOG.a<.02)return;const a=FOG.a;
  // t149u perf: cheap full-screen haze only (no wisp sprites) — looks soft, costs almost nothing
  if(perfOn()){ctx.fillStyle=`rgba(226,232,238,${a*.22})`;ctx.fillRect(0,0,VW,VH);return;}
  const S=fogSprites(),sc=.65,W=Math.max(1,Math.ceil(VW*sc)),H=Math.max(1,Math.ceil(VH*sc));
  if(!FOG_BUF||FOG_BUF.width!==W||FOG_BUF.height!==H){FOG_BUF=document.createElement('canvas');FOG_BUF.width=W;FOG_BUF.height=H;FOG_BG=FOG_BUF.getContext('2d');}
  const fr=Math.floor(gtime*10);
  const key=W+'x'+H+'|'+Math.round(cam.x/8)+'|'+Math.round(cam.y/8)+'|'+fr+'|'+Math.round(a*12);
  if(key!==FOG_KEY){FOG_KEY=key;const g=FOG_BG;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W,H);
    g.fillStyle=`rgba(226,232,238,${a*.08})`;g.fillRect(0,0,W,H);
    const layers=[[.55,.9,.55,9],[.85,1.35,.8,18]];
    layers.forEach(([par,ss,al,spd],li)=>{const w=320*ss*sc,h=110*ss*sc,ox=(-(cam.x*par)+gtime*spd)*sc,oy=(-(cam.y*par))*sc;
      g.globalAlpha=Math.min(1,a*al*.75);
      const WW=w*.85,HH=h*.75,bx=((ox%WW)+WW)%WW-WW,by=((oy%HH)+HH)%HH-HH;
      for(let gy=0;gy<=Math.ceil(H/HH)+1;gy++)for(let gx=0;gx<=Math.ceil(W/WW)+1;gx++){
        const sx=bx+gx*WW+(gy%2)*WW*.4,sy=by+gy*HH+Math.sin(gtime*.3+gx+li)*5*sc;
        g.drawImage(S[(gx*7+gy*3+li)%4],Math.round(sx-w*.1),Math.round(sy),Math.round(w),Math.round(h));}
    });
    g.globalAlpha=1;}
  ctx.save();ctx.imageSmoothingEnabled=true;ctx.drawImage(FOG_BUF,0,0,VW,VH);ctx.imageSmoothingEnabled=false;ctx.restore();
}
drawFog=fogDrawFast;
/* ---- HUD panel + button caches ---- */
const PANEL_SKIN=new Map();
function panelSkin(w,h,fillKey){
  const k=w+'x'+h+'|'+fillKey;let s=PANEL_SKIN.get(k);if(s)return s;
  const c=document.createElement('canvas');c.width=w+4;c.height=h+6;const g=c.getContext('2d'),ox=0,oy=0;
  g.fillStyle='rgba(0,0,0,.45)';g.fillRect(ox+2,oy+4,w,h);
  const pat=satPattern();
  g.fillStyle='#2a160a';g.fillRect(ox+3,oy,w-6,h);g.fillRect(ox,oy+3,w,h-6);g.fillRect(ox+1,oy+1,w-2,h-2);
  g.save();g.beginPath();g.rect(ox+2,oy+2,w-4,h-4);g.clip();g.fillStyle=pat;g.fillRect(ox,oy,w,h);g.restore();
  g.fillStyle='#a8703f';g.fillRect(ox+3,oy+2,w-6,2);g.fillRect(ox+2,oy+3,2,h-6);
  g.fillStyle='#5e3a1c';g.fillRect(ox+3,oy+h-4,w-6,2);g.fillRect(ox+w-4,oy+3,2,h-6);
  g.fillStyle='#4a3208';g.fillRect(ox+4,oy+4,w-8,h-8);
  g.fillStyle='#e0b44a';g.fillRect(ox+5,oy+5,w-10,h-10);
  g.fillStyle='#fff0a0';g.fillRect(ox+5,oy+5,w-10,1);g.fillRect(ox+5,oy+5,1,h-10);
  if(fillKey==='def'){const gr=g.createLinearGradient(0,oy+7,0,oy+h-7);gr.addColorStop(0,'#3e2617');gr.addColorStop(1,'#22140b');g.fillStyle=gr;}
  else g.fillStyle=fillKey;
  g.fillRect(ox+7,oy+7,w-14,h-14);
  g.fillStyle='rgba(0,0,0,.4)';g.fillRect(ox+7,oy+7,w-14,2);g.fillRect(ox+7,oy+7,2,h-14);
  for(const [qx,qy] of [[ox+3,oy+3],[ox+w-4,oy+3],[ox+3,oy+h-4],[ox+w-4,oy+h-4]]){g.fillStyle='#4a3208';g.fillRect(qx-2,qy-2,5,5);g.fillStyle='#e0b44a';g.fillRect(qx-1,qy-1,3,3);g.fillStyle='#fff0a0';g.fillRect(qx-1,qy-1,1,1);}
  PANEL_SKIN.set(k,c);return c;
}
{const _panel=panel;panel=function(x,y,w,h,o={}){
  if(o.legacy)return _panel(x,y,w,h,o);
  x=Math.round(x);y=Math.round(y);w=Math.round(w);h=Math.round(h);
  const custom=o.fill&&o.fill!=='#1a1630',fk=custom?o.fill:'def';
  ctx.drawImage(panelSkin(w,h,fk),x,y);
  if(o.border&&o.border!=='#e8e0c8'){ctx.fillStyle=o.border;ctx.fillRect(x+9,y+h-6,w-18,2);}
};}
const BTN_CACHE=new Map();
function btnSkin(r,tintKey){
  const k=r+'|'+tintKey;let s=BTN_CACHE.get(k);if(s)return s;
  const c=document.createElement('canvas'),pad=8,sz=r*2+pad*2;c.width=sz;c.height=sz+4;const g=c.getContext('2d'),cx=pad+r,cy=pad+r;
  g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.arc(cx+2,cy+4,r+3,0,6.283);g.fill();
  g.fillStyle='#1c0e06';g.beginPath();g.arc(cx,cy,r+3,0,6.283);g.fill();
  const gr=g.createLinearGradient(cx-r,cy-r,cx+r,cy+r);gr.addColorStop(0,'#fff0a0');gr.addColorStop(.45,'#e0b44a');gr.addColorStop(1,'#9a7418');
  g.fillStyle=gr;g.beginPath();g.arc(cx,cy,r+1,0,6.283);g.fill();
  g.save();g.beginPath();g.arc(cx,cy,r-3,0,6.283);g.clip();
  g.fillStyle=satPattern();g.fillRect(cx-r,cy-r,r*2,r*2);
  g.fillStyle=tintKey||'rgba(20,8,2,.35)';g.fillRect(cx-r,cy-r,r*2,r*2);
  const sh=g.createRadialGradient(cx-r*.3,cy-r*.4,1,cx,cy,r);sh.addColorStop(0,'rgba(255,230,180,.28)');sh.addColorStop(1,'rgba(0,0,0,.35)');g.fillStyle=sh;g.fillRect(cx-r,cy-r,r*2,r*2);
  g.restore();g.strokeStyle='#2a160a';g.lineWidth=1.5;g.beginPath();g.arc(cx,cy,r-3,0,6.283);g.stroke();
  BTN_CACHE.set(k,c);return c;
}
hdButton=function(x,y,r,down,o={}){
  ctx.globalAlpha=o.alpha==null?1:o.alpha;
  const tint=o.tint||(down?'rgba(255,220,140,.25)':'rgba(20,8,2,.35)');
  ctx.drawImage(btnSkin(r,tint),Math.round(x-r-8),Math.round(y-r-8));
  if(o.ring){ctx.strokeStyle=o.ring;ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,r+4.5,0,6.283);ctx.stroke();}
  ctx.globalAlpha=1;
};
/* ---- HD: stamp cache; off in perf mode ---- */
HDX.spr=true;
{const _hg=hdGet;hdGet=function(src,mode){
  if(!HDX.on||!src||perfOn())return null;if(mode==='spr'&&!HDX.spr)return null;
  if(src._hd)return src._hd;if(src._hdMiss)return null;
  if(!src.width||src.width>48){src._hdMiss=1;return null;}
  const c=_hg(src,mode);if(c)src._hd=c;else src._hdMiss=1;return c;
};}
{const prev=ctx.drawImage;
 ctx.drawImage=function(img,a,b,c,d){
   if(perfOn())return prev.apply(this,arguments);
   if(arguments.length===5&&img&&img._hd)return prev.call(this,img._hd,a,b,c,d);
   if(arguments.length===5&&img&&!img._hdMiss&&img.width<=48&&img.height<=64&&c>=(img.width||0)*1.9&&d>=(img.height||0)*1.9&&!(typeof HD_NO!=='undefined'&&HD_NO.has(img))){
     const h=hdGet(img,'spr');if(h)return prev.call(this,h,a,b,c,d);
   }
   return prev.apply(this,arguments);
 };}
/* ---- Water life: cull offscreen + skip jumps in perf; update every other frame ---- */
let WLIFE_FR=0;
{if(typeof drawWlife==='function'){const _dwl=drawWlife;drawWlife=function(){
  if(perfOn()&&(++WLIFE_FR&1))return;   // every other frame in perf
  // cull pads/reeds/fish to view before drawing by temporarily filtering
  if(typeof WLIFE!=='undefined'&&WLIFE.pads){
    const x0=cam.x-40,y0=cam.y-40,x1=cam.x+VW+40,y1=cam.y+VH+40;
    const op=WLIFE.pads,or=WLIFE.reeds,of=WLIFE.fish,oj=WLIFE.jumps;
    WLIFE.pads=op.filter(p=>p.x>x0&&p.x<x1&&p.y>y0&&p.y<y1);
    WLIFE.reeds=or.filter(p=>p.x>x0&&p.x<x1&&p.y>y0&&p.y<y1);
    WLIFE.fish=of.filter(p=>{const x=p.wx||p.x,y=p.wy||p.y;return x>x0&&x<x1&&y>y0&&y<y1;});
    if(perfOn())WLIFE.jumps=[];   // no jump FX in perf
    try{_dwl();}finally{WLIFE.pads=op;WLIFE.reeds=or;WLIFE.fish=of;WLIFE.jumps=oj;}
  }else _dwl();
};}
 if(typeof updateWlife==='function'){const _uw=updateWlife;updateWlife=function(dt){
   if(perfOn()){if((WLIFE_FR&1)===0)_uw(dt*.5);else WLIFE.t+=dt;} else _uw(dt);
 };}}
/* ---- Night lighting: in perf mode rebuild mask every 4 frames and skip per-lantern screen glows ---- */
{const _dl=drawLighting;drawLighting=function(){
  if(!perfOn())return _dl();
  // simplified night: dark overlay with player+nearby cutouts only, no screen-blend lanterns / night FX
  if(zoneOfPx(P.y)==='house')return;
  const cr=inCryptPx(P.x,P.y);
  if(!cr&&typeof drawGrade==='function')drawGrade(dayGrade());
  LIGHT.tk+=((playerInTown()?1:0)-LIGHT.tk)*.07;
  const dark=cr?.55:(NIGHT_DARK+(NIGHT_DARK_TOWN-NIGHT_DARK)*LIGHT.tk)*DAY.nightAmt;
  if(dark<.02)return;
  if(!LIGHT.cv||LIGHT.cv.width!==VW||LIGHT.cv.height!==VH){LIGHT.cv=document.createElement('canvas');LIGHT.cv.width=VW;LIGHT.cv.height=VH;LIGHT.g=LIGHT.cv.getContext('2d');LIGHT._fr=-1;}
  const fr=Math.floor(gtime*15),camJump=Math.abs((LIGHT._cx||0)-cam.x)>10||Math.abs((LIGHT._cy||0)-cam.y)>10;
  if(fr!==LIGHT._fr||camJump){LIGHT._fr=fr;LIGHT._cx=cam.x;LIGHT._cy=cam.y;
    const g=LIGHT.g,L=collectLights(cr).slice(0,8);   // cap lights
    g.globalCompositeOperation='source-over';g.clearRect(0,0,VW,VH);
    g.fillStyle=cr?`rgba(5,3,20,${dark})`:`rgba(16,8,58,${dark})`;g.fillRect(0,0,VW,VH);
    g.globalCompositeOperation='destination-out';
    for(const l of L){const r=l.r*.9,aa=Math.min(1,l.a*.9),gr=g.createRadialGradient(l.x,l.y,0,l.x,l.y,r);
      gr.addColorStop(0,`rgba(0,0,0,${aa})`);gr.addColorStop(.5,`rgba(0,0,0,${aa*.45})`);gr.addColorStop(1,'rgba(0,0,0,0)');
      g.fillStyle=gr;g.fillRect(l.x-r,l.y-r,r*2,r*2);}
  }
  ctx.drawImage(LIGHT.cv,0,0);
};}
/* ---- FPS overlay ---- */
function drawFps(){
  if(typeof SET==='undefined'||!SET.fps)return;
  const fps=Math.round(QUAL.fps||0),ms=(1000/Math.max(1,QUAL.fps)).toFixed(1);
  const label=fps+' FPS  '+ms+'ms  DPR'+DPR+'  '+(perfOn()?'PERF':'HQ')+'  '+cv.width+'x'+cv.height;
  ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(SL+6,VH-SB-22,Math.min(VW-SL-SR-12,ctx.measureText?220:220),16);
  txt(label,SL+10,VH-SB-10,{size:10,col:fps>=50?'#7dffa0':fps>=30?'#ffe14d':'#ff6b6b',lw:2,out:'#000'});
}
{const _fr=typeof drawOverHud==='function'?null:null;
 // hook into the end of the main render via the existing frame draw path in main.js — wrap after drawTouch
 const hook=()=>{try{drawFps();}catch(e){};};
 if(typeof drawTouch==='function'){const _dt=drawTouch;drawTouch=function(){const r=_dt.apply(this,arguments);hook();return r;};}
 else if(typeof drawRunBtn==='function'){const _dr=drawRunBtn;drawRunBtn=function(){const r=_dr.apply(this,arguments);hook();return r;};}
}
{const _up=update;update=function(dt){qualTick(dt);return _up.apply(this,arguments);};}
/* apply once settings exist */
setTimeout(()=>{try{if(typeof SET!=='undefined'){if(SET.perf===undefined)SET.perf=!!TOUCH;qualApply();}}catch(e){}},0);
/* stubs */
const CH={map:new Map(),n:8,px:256,live:false,zn:null};
function chGet(){return null;}function chInvalidate(){}function chkKey(){return 0;}
