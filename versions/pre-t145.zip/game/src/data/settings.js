/* =====================================================================
   M13 DATA: settings defaults, text sizes, colourblind modes, tutorial steps.
   ===================================================================== */
const SET_KEY='arcaneKnight.settings.v1';
const SET_DEFAULT={master:.8,music:.8,sfx:.8,text:0,cb:0,lefty:false,pad:true,tutDone:false,pop:0};
const POP_STYLES=[{id:'parchment',n:'PARCHMENT'},{id:'scroll',n:'WAX-SEALED SCROLL'},{id:'sign',n:'SHOP SIGN'},{id:'chest',n:'TREASURE CHEST'},{id:'banner',n:'MINIMAL BANNER'}];
const TEXT_SIZES=[{n:'NORMAL',k:1},{n:'LARGE',k:1.15},{n:'EXTRA LARGE',k:1.3}];
// colour-vision assist: a daltonisation filter over the canvas (error redistributed into channels the player can tell apart)
const CB_MODES=[{id:'off',n:'OFF'},{id:'deutan',n:'GREEN-WEAK (DEUTAN)'},{id:'protan',n:'RED-WEAK (PROTAN)'},{id:'tritan',n:'BLUE-WEAK (TRITAN)'}];
const CB_SIM={   // Machado et al. colour-vision deficiency simulation matrices
  protan:[[.152286,1.052583,-.204868],[.114503,.786281,.099216],[-.003882,-.048116,1.051998]],
  deutan:[[.367322,.860646,-.227968],[.280085,.672501,.047413],[-.011820,.042940,.968881]],
  tritan:[[1.255528,-.076749,-.178779],[-.078411,.930809,.147602],[.004733,.691367,.303900]]};
const CB_ERR={protan:[[0,0,0],[.7,1,0],[.7,0,1]],deutan:[[0,0,0],[.7,1,0],[.7,0,1]],tritan:[[1,.7,0],[0,1,0],[0,.7,1]]};
const PAD_MAP={0:'KeyJ',2:'KeyK',3:'KeyL',9:'KeyP',4:'KeyL',5:'KeyL',12:'ArrowUp',13:'ArrowDown',14:'ArrowLeft',15:'ArrowRight'};   // A shoot, X cast, Y/bumpers next card, Start pause, d-pad
// steps: id, text(touch)/text(keys), done(ctx) checks live game state
const TUT_STEPS=[
  {id:'move', k:'Walk around: WASD or arrow keys',            t:'Walk around: drag the left stick',            need:'Walk a few steps'},
  {id:'shoot',k:'Fire your bow: press J',                     t:'Fire your bow: tap SHOT',                    need:'Fire a shot'},
  {id:'talk', k:'Walk up to a villager and press E (or click them) to talk',  t:'Tap a villager to walk over and talk',         need:'Talk to someone'},
  {id:'pause',k:'Press P to open the pause menu: deck, quests, skills',t:'Tap II (top right) to open the menu',need:'Open the menu'},
  {id:'fight',k:'Shoot the TRAINING SLIME to begin a battle. Cast cards with K',t:'Shoot the TRAINING SLIME to begin. Tap a card to cast it',need:'Start a battle'},
];
