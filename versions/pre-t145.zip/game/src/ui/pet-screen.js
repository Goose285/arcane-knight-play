/* =====================================================================
   PET SCREEN (Marlo the Keeper / pause menu) + HOUSE SHELF SCREEN (trophies)
   ===================================================================== */
function petRow(d){
  const own=!!PET.owned[d.id],act=PET.active===d.id,can=own||P.gold>=d.price;
  const go=()=>{if(!own){if(!adoptPet(d.id)){uiMsg('Need '+d.price+' G');sfx('clang');}else uiMsg('Adopted '+d.name,false);}else{summonPet(act?null:d.id);uiMsg(act?d.name+' rests':d.name+' joins you',false);}};
  return {sel:true,h:56,act:go,tap:go,
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#26224a':'#17142b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=d.col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(x0+8,y+8,40,40);draw(SP.pets[d.id],x0+10,y+10,2.25);
      txt(d.name+(own?'   bond Lv '+petLevel(d.id)+(act?'   (with you)':''):''),x0+56,y+17,{size:10,col:d.col,lw:2});
      txt(d.desc,x0+56,y+31,{size:8,col:'#b9b4d8',bold:false});
      txt(own?'Damage '+petDmg(d.id)+'   every '+d.cd+'s':'Adopt for '+d.price+' G',x0+56,y+45,{size:8,col:'#9aa0ff',bold:false});
      uiButton(x0+W-86,y+13,78,30,own?(act?'REST':'SUMMON'):'ADOPT',can,()=>{UI.sel=si;go();},{tag:'pet:'+d.id,clip:true,size:10,sel:si,bg:own?'#2d4f8a':undefined});}};
}
UI_MODES.pets={title:()=>'PETS',sub:()=>['Marlo the Keeper  -  one pet follows you  -  Gold '+P.gold+' G','#c58bff'],rows(){
  const r=[{t:'head',s:'COMPANIONS   (bond grows with every kill)'}];PET_IDS.forEach(id=>r.push(petRow(PETS[id])));return r;}};
function shelfRow(i){
  const cyc=()=>{UI.sel=i;const v=cycleSlot(i);uiMsg(v?TROPHIES[v].name+' on shelf '+(i+1):'Shelf '+(i+1)+' cleared',false);saveGame('house');};
  return {sel:true,h:44,act:cyc,tap:cyc,
    draw(x0,y,W,h,isSel,si){const v=HOUSE.slots[i];ctx.fillStyle=isSel?'#26224a':'#17142b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=v?TROPHIES[v].col:'#4a4470';ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      if(v)draw(SP.trophy[v],x0+8,y+6,2);
      txt('Shelf '+(i+1)+':  '+(v?TROPHIES[v].name:'(empty)'),x0+48,y+19,{size:10,col:v?TROPHIES[v].col:'#8a86b0',lw:2});
      txt(v?TROPHIES[v].how:'Tap CHANGE to place a trophy',x0+48,y+33,{size:8,col:'#9aa0ff',bold:false});
      uiButton(x0+W-86,y+7,78,30,'CHANGE',true,()=>{UI.sel=si;cyc();},{tag:'slot:'+i,clip:true,size:10,sel:si});}};
}
UI_MODES.house={title:()=>'TROPHY SHELF',sub:()=>[trophyCount()+' / '+TROPHY_IDS.length+' trophies earned','#ffd23f'],rows(){
  const r=[{t:'head',s:'DISPLAY   (earned trophies only - each shows once)'}];HOUSE_SLOTS.forEach((_,i)=>r.push(shelfRow(i)));
  r.push({t:'head',s:'COLLECTION'});
  TROPHY_IDS.forEach(id=>r.push({h:34,draw(x0,y,W,h){const own=HOUSE.trophies[id];ctx.fillStyle='#120f26';ctx.fillRect(x0,y,W,h);ctx.fillStyle=own?TROPHIES[id].col:'#3a3660';ctx.fillRect(x0,y,3,h);
    if(own)draw(SP.trophy[id],x0+6,y+3,1.75);else{ctx.fillStyle='#2a2646';ctx.fillRect(x0+10,y+8,18,18);}
    txt(own?TROPHIES[id].name:'???',x0+44,y+15,{size:9,col:own?'#fff':'#6a6690',lw:2});txt(TROPHIES[id].how,x0+44,y+28,{size:8,col:'#9aa0ff',bold:false});}}));
  return r;}};
UI_STATES.push('pets','house');
// world: trophies standing on the shelves of the house
function drawHouseTrophies(){
  if(zoneOfPx(P.y)!=='house')return [];
  const out=[];HOUSE_SLOTS.forEach(([tx,ty],i)=>{const v=HOUSE.slots[i];const x=(tx+.5)*TS,y=(ty+.9)*TS;
    out.push({y,fn:()=>{const sx=Math.round(x-cam.x),sy=Math.round(y-cam.y);if(v){drawEntShadow(x,y,10);draw(SP.trophy[v],sx-24,sy-46,3);}else{ctx.fillStyle='rgba(255,230,150,.16)';ctx.beginPath();ctx.ellipse(sx,sy-4,14,6,0,0,6.283);ctx.fill();ctx.strokeStyle='rgba(255,230,150,.35)';ctx.lineWidth=1;ctx.stroke();}}});});
  return out;
}
