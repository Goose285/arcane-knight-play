/* QUEST LOG (pause menu -> QUESTS). Read-only list: ready / active / available / completed. */
function openQuests(){openUIMode('quests');}
function trackBtn(x0,y,W,id,si){
  const on=TRK.id===id;
  uiButton(x0+W-70,y+4,64,22,on?'TRACKING':'TRACK',!on,()=>{UI.sel=si;if(!on){trackQuest(id);uiMsg('Tracking on your HUD',false);}},{tag:'track:'+id,clip:true,size:8,sel:si});
}
function questRow(q,kind){
  const h=kind==='done'?30:kind==='avail'?44:62,id='q:'+q.id,trk=kind==='active'||kind==='ready';
  const go=()=>{if(trk&&TRK.id!==id){trackQuest(id);uiMsg('Tracking '+q.name,false);}};
  return {h,sel:trk,act:go,tap:go,draw(x0,y,W,hh,isSel,si){
    const prog=questProgress(q),need=questNeed(q);
    const col=kind==='ready'?'#7dffa0':kind==='active'?'#ffe14d':kind==='avail'?'#9ad0ff':'#6a6690';
    ctx.fillStyle=kind==='done'?'#100e20':isSel?'#26224a':'#17142b';ctx.fillRect(x0,y,W,hh);ctx.fillStyle=col;ctx.fillRect(x0,y,3,hh);
    if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,hh-2);}
    txt(q.name,x0+10,y+15,{size:11,col:kind==='done'?'#8a86b8':'#fff',lw:2});
    if(kind==='done'){txt('DONE',x0+W-8,y+15,{size:9,align:'right',col:'#6a6690',lw:2});return;}
    if(trk)trackBtn(x0,y,W,id,si);
    txt(kind==='avail'?'Talk to '+q.giver+' to begin':kind==='ready'?'READY - return to '+q.giver:questGoalText(q)+'  ('+q.giver+')',x0+10,y+29,{size:9,col:kind==='ready'?'#7dffa0':'#cfd0ff',bold:false});
    if(kind==='avail'){txt('Reward: '+questRewardText(q.reward),x0+10,y+40,{size:8,col:'#ffd23f',bold:false});return;}
    const bw=W-20;ctx.fillStyle='#0b0918';ctx.fillRect(x0+10,y+36,bw,8);ctx.fillStyle=col;ctx.fillRect(x0+10,y+36,Math.round(bw*prog/need),8);
    txt(prog+'/'+need,x0+W-10,y+43,{size:8,align:'right',col:'#fff',lw:2});
    txt('Reward: '+questRewardText(q.reward),x0+10,y+57,{size:8,col:'#ffd23f',bold:false});
  }};
}
/* the main story chapter and today's dailies can be tracked too */
function trackRow(en){
  const col=en.kind==='story'?'#c9a3ff':'#ffd23f',go=()=>{if(TRK.id!==en.id){trackQuest(en.id);uiMsg('Tracking '+en.name,false);}};
  return {h:50,sel:true,act:go,tap:go,draw(x0,y,W,hh,isSel,si){
    ctx.fillStyle=isSel?'#26224a':'#17142b';ctx.fillRect(x0,y,W,hh);ctx.fillStyle=col;ctx.fillRect(x0,y,3,hh);
    if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,hh-2);}
    txt(en.name,x0+10,y+15,{size:10,col:'#fff',lw:2});trackBtn(x0,y,W,en.id,si);
    txt(en.obj.length>46?en.obj.slice(0,45)+'..':en.obj,x0+10,y+30,{size:8,col:'#cfd0ff',bold:false});
    const bw=W-20;ctx.fillStyle='#0b0918';ctx.fillRect(x0+10,y+37,bw,7);ctx.fillStyle=en.ready?'#7dffa0':col;ctx.fillRect(x0+10,y+37,Math.round(bw*clamp(en.prog/en.need,0,1)),7);
    txt(en.kind==='story'?`Step ${en.step}/${en.steps}`:en.prog+'/'+en.need,x0+W-10,y+46,{size:7,align:'right',col:'#fff',lw:2});
  }};
}
UI_MODES.quests={title:()=>'QUEST LOG',sub:()=>[`${QUESTS.filter(q=>questStatus(q.id)==='done').length}/${QUESTS.length} completed`,'#9ad0ff'],rows(){
  const r=[],by=k=>QUESTS.filter(q=>questStatus(q.id)===k);
  const sec=(t,k,list)=>{if(!list.length)return;r.push({t:'head',s:t});list.forEach(q=>r.push(questRow(q,k)));};
  sec('READY TO HAND IN','ready',by('ready'));sec('ACTIVE','active',by('active'));
  const ex=trkEntries().filter(e=>e.kind!=='quest');if(ex.length){r.push({t:'head',s:'STORY & DAILY  (tap TRACK to follow)'});ex.forEach(e=>r.push(trackRow(e)));}
  sec('AVAILABLE','avail',by('avail'));sec('COMPLETED','done',by('done'));
  if(!r.length)r.push({t:'head',s:'  No quests yet - talk to the villagers!'});
  return r;}};
