let DLG=null;
function openDlg(npc){
  sfx('talk');
  if(typeof rtShopClosed==='function'&&rtShopClosed(npc)){rtClosedDlg(npc);return;}
  if(npc.guide){openGuide();return;}
  if(npc.rush){openArenaMaster();return;}
  if(npc.board){openDaily();return;}
  if(npc.house){openHouseNpc(npc);return;}
  if(npc.pets){openPets();return;}
  if(npc.priest){openPriest(npc);return;}
  if(npc.inn){openInn(npc);return;}
  if(!npc.way&&storyTalk(npc))return;
  if(!npc.way&&questTalk(npc))return;
  if(npc.way){openWaystone(npc);return;}
  if(npc.fisher){openFisher(npc);return;}
  if(npc.smith){openShop();return;}
  if(false){
  } else DLG={name:npc.label||npc.name,lines:npc.lines,i:0,c:0};
}
function updateDlg(dt){
  if(DLG.cut){updateCut(DLG,dt);return;}
  const d=DLG,line=d.lines[d.i];
  if(d.c<line.length){d.c=Math.min(line.length,d.c+dt*60);if(((d.c|0)%3)===0&&Math.random()<.4)sfx('talk');}
  const isChoice=d.choice&&d.i===d.lines.length-1&&d.c>=line.length;
  if(isChoice){
    if(hit('Enter','KeyY')){const af=d.after;d.choice();DLG=af?af():null;return;}
    if(hit('Escape','KeyN')){const f=d.noAct;DLG=null;if(f)f();return;}
  } else if(hit('Enter','KeyE','Space','KeyJ')){
    if(d.c<line.length)d.c=line.length;
    else if(d.i<d.lines.length-1){d.i++;d.c=0;}
    else DLG=null;
  }
}
