
/* ---- player ---- */
function nextSel(dir=1){const N=B.hand.length||5;for(let i=1;i<=N;i++){const j=(B.sel+i*dir+70)%N;if(B.hand[j]){B.sel=j;return;}}}
function nearestEnemy(){
  if(B.xt&&B.xt.e&&!B.xt.e.dying)return B.xt.e;          // experimental cards: the foe you tapped
  const pc=pcen();let best=null,bd=1e9;
  for(const e of B.ens){if(e.dying)continue;const c=ecen(e),d=Math.hypot(c.x-pc.x,c.y-pc.y);if(d<bd){bd=d;best=e;}}
  return best;
}
function aimEnemy(){
  if(B.xt)return B.xt.tg;                                 // experimental cards: tapped foe / ground marker (null = nothing there)
  const pc=pcen(),near=nearestEnemy();
  if(!near||!P.moving)return near;
  let best=null,bd=1e9;                                  // moving: nearest enemy inside a cone around the aim direction
  for(const e of B.ens){if(e.dying)continue;const c=ecen(e);if(Math.abs(angDiff(angTo(pc,c),P.aim))<.55){const d=Math.hypot(c.x-pc.x,c.y-pc.y);if(d<bd){bd=d;best=e;}}}
  return best||near;
}
function fireAngle(){
  if(B.xt)return angTo(pcen(),B.xt);
  const pc=pcen(),near=nearestEnemy();
  if(!near)return P.aim;
  if(!P.moving)return angTo(pc,ecen(near));
  let best=null,bd=1e9;
  for(const e of B.ens){if(e.dying)continue;const c=ecen(e),ea=angTo(pc,c);if(Math.abs(angDiff(ea,P.aim))<.55){const d=Math.hypot(c.x-pc.x,c.y-pc.y);if(d<bd){bd=d;best=ea;}}}
  return best!=null?best:P.aim;
}
function freezeEnemy(e,dur){
  if(e.dying)return false;
  if(e.def.freezeImmune){                                // bosses: no full freeze, just a short chill (slow) - generic flag for future bosses
    const c=ecen(e);floatText(c.x,c.y-(e.def.big?60:34),'RESIST','#bfe8ff',13);
    if(!(e.chill>0)){burst(c.x,c.y,'#bfe8ff',10,100,.5);}
    e.chill=Math.max(e.chill,2.5);return false;
  }
  if(e.frozen>0||e.fimm>0){const c=ecen(e);floatText(c.x,c.y-34,e.frozen>0?'FROZEN':'IMMUNE','#9fd8ee',10);return false;}
  e.frozen=dur;
  if(e.st==='windup'){B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);e.st='idle';e.cur=null;e.charge=0;e.atkCd=Math.max(e.atkCd,.7);}
  e.dash=null;e.guard=0;
  const c=ecen(e);floatText(c.x,c.y-34,'FROZEN!','#bff1ff',13);burst(c.x,c.y,'#d9f6ff',14,110,.6);
  return true;
}
function castMagic(id,ch,m){
  const cfg=MAGIC[id],tg=aimEnemy();if(!tg)return;
  const tc=ecen(tg),pc=pcen(),area=cfg.area,r=area?SPLASH_R:34;
  addFx(cfg.k==='ice'?'iceburst':'bloodburst',{x:tc.x,y:tc.y+6,r},cfg.k==='ice'?.85:1.05);
  sfx(cfg.k==='ice'?'ice':'blood');B.shake=Math.max(B.shake,.22);
  let dealt=0,hits=0;
  for(const o of enemies){
    if(!o.alive||o.dying)continue;
    const oc=ecen(o);
    const inR=o===tg||(area&&Math.hypot(oc.x-tc.x,oc.y-tc.y)<r+eRad(o)*.5&&losW(tc,7,oc,7));   // splash is stopped by walls
    if(!inR)continue;
    if(!o.engaged&&liveEns().length>=MAX_ENG)continue;
    const ok=damageEnemy(o,ch.pow*m,cfg.k);
    if(ok){dealt+=o.lastDealt;hits++;}
    if(cfg.k==='ice')freezeEnemy(o,cfg.dur);
  }
  if(cfg.k==='blood'&&dealt>0){
    const h=Math.max(1,Math.round(dealt*.25));P.hp=Math.min(maxHp(),P.hp+h);
    floatText(pc.x,pc.y-48,'+'+h,'#ff6b7a',16);
    B.fx.push({k:'bloodheal',z:{x:pc.x,y:pc.y},t:0,dur:.8});
    for(let i=0;i<8;i++)B.parts.push({x:pc.x+R(-10,10),y:pc.y+R(-4,10),vx:0,vy:-R(30,70),t:0,life:.8,col:'#ff4a5e',sz:3});
  }
  B.lastCast={id,hits,dealt};
}
function updatePlayerCombat(dt){
  B.inv=Math.max(0,B.inv-dt);B.flash=Math.max(0,B.flash-dt);B.shootCd-=dt;B.shootAnim=Math.max(0,B.shootAnim-dt);B.barrier=Math.max(0,B.barrier-dt);
  if(!P.moving)B.idleT+=dt;else B.idleT=0;
  B.target=nearestEnemy();
  if(B.idleT>.12&&B.target){const a=angTo(pcen(),ecen(B.target));P.aim=a;P.dir=dirOfAngle(a);}   // standing still: face the nearest enemy
  const pc=pcen();
  if(hit('KeyJ')&&B.shootCd<=0&&!(P.sleepT>0)){
    const a=fireAngle();P.aim=a;P.dir=dirOfAngle(a);
    B.shots.push({x:pc.x,y:pc.y,vx:Math.cos(a)*380,vy:Math.sin(a)*380,r:5,dmg:arcaneDmg(),own:'p',kind:'arcane',life:1.0,a});TEV.shot++;B.shootCd=.2*(B.haste>0?.55:1);B.shootAnim=.12;sfx('shoot');B.charge=0;B.charging=true;
  }
  if(held('KeyJ')&&B.charging){const before=B.charge;B.charge=Math.min(1.3,B.charge+dt*(B.haste>0?1.4:1));if(before<.3&&B.charge>=.3)sfx('charge');if(before<1&&B.charge>=1)sfx('select');}
  if(rel('KeyJ')){
    if(B.charge>=1){TEV.charged++;const a=fireAngle();P.aim=a;P.dir=dirOfAngle(a);B.shots.push({x:pc.x,y:pc.y,vx:Math.cos(a)*420,vy:Math.sin(a)*420,r:12,dmg:arcaneDmg()*5,own:'p',kind:'charged',life:1.1,a});B.shootAnim=.2;sfx('cshot');B.shootCd=.25;}
    B.charge=0;B.charging=false;
  }
  if(!held('KeyJ')&&!rel('KeyJ')){
    if(B.carry&&B.charging&&B.charge>=1){const a=fireAngle();P.aim=a;P.dir=dirOfAngle(a);B.shots.push({x:pc.x,y:pc.y,vx:Math.cos(a)*420,vy:Math.sin(a)*420,r:12,dmg:arcaneDmg()*5,own:'p',kind:'charged',life:1.1,a});B.shootAnim=.2;sfx('cshot');B.shootCd=.25;}   // released during the "!" intro: fire it now
    B.charge=0;B.charging=false;}
  B.carry=false;
  if(hit('KeyX')&&B.phase==='fight'){discardCard(B.sel);}
  if(hit('KeyL'))if(B.hand.some(Boolean)){nextSel(1);sfx('select');}
  if(hit('KeyK'))castFacingNearest();          // K auto-faces the nearest enemy
  ['Digit1','Digit2','Digit3','Digit4','Digit5','Digit6','Digit7'].forEach((k,i)=>{if(hit(k))cardUse(i);});
  if(B.xsel>=0&&(!B.hand[B.xsel]||B.hand[B.xsel]!==B.xid))B.xsel=-1;   // the card was cast, replaced or the hand refreshed
  expDealTick(dt*(1+gearStats().gauge+.1*skillRank('slots')));      // one card every 2.5s into an empty slot (gear / skills deal faster); the timer waits while the hand is full
  B.gaugeFlash=Math.max(0,B.gaugeFlash-dt*1.5);
  // leash: run far enough away and the monster gives up
  if(breakingAway(dt))B.fleeT+=dt;else B.fleeT=Math.max(0,B.fleeT-dt*2);
  if(B.fleeT>2.2)disengage();
}
function updateShots(dt){
  const pc=pcen();
  for(const s of B.shots){
    if(s.own==='e'&&B.tstop>0)continue;          // Time Stop: hostile shots hang in the air
    s.life-=dt;if(s.life<=0){s.dead=true;continue;}
    if(sweepShot(s,dt)){if(s.bounce>0){s.bounce--;bounceShot(s,dt);continue;}s.dead=true;burst(s.x,s.y,s.kind==='fire'?'#ff9a3d':'#ddd',4,60,.3);if(s.kind==='fire'&&s.own==='p'){addFx('boom',{k:'circle',x:s.x,y:s.y,r:26},.35);}continue;}
    if(s.own==='p'){
      if(hitSpawnerShot(s)){s.dead=true;continue;}
      for(const e of enemies){
        if(!e.alive||e.dying||(s.hits&&s.hits.has(e)))continue;
        const c=ecen(e);
        if(Math.hypot(s.x-c.x,s.y-c.y)<s.r+eRad(e)){
          if(!e.engaged&&liveEns().length>=MAX_ENG)continue;
          const ok=damageEnemy(e,s.dmg,s.kind);s.dead=!(s.pierce>0);if(!s.dead){s.pierce--;(s.hits||(s.hits=new Set())).add(e);}if(s.kind==='pet')petOnHit(s,e);
          if(s.kind==='fire'&&ok&&!e.dying){e.burn=3.2;e.burnT=.5;addFx('boom',{k:'circle',x:s.x,y:s.y,r:30},.4);burst(s.x,s.y,'#ff9a3d',10,110,.4);}
          break;
        }
      }
    } else if(shotVsDefenses(s,pc)){}
    else if(Math.hypot(s.x-pc.x,s.y-pc.y)<s.r+6){s.dead=true;damagePlayer(s.dmg,s.src);}
  }
  B.shots=B.shots.filter(s=>!s.dead);
}
function winBattle(){
  if(B.phase==='win'||B.phase==='reward')return;
  B.phase='win';B.t=0;B.shots=[];B.zones=B.zones.filter(z=>z.vol);B.timers=B.timers.filter(t=>t.vol);B.charge=0;   // (an elite's death blast still goes off)
  sfx('boom');B.shake=.5;
}
function loseBattle(){
  B.phase='lose';B.t=0;B.shots=[];B.timers=[];B.zones=[];sfx('lose');B.shake=.5;
  const p=pcen();burst(p.x,p.y,'#6fb7ff',24,170,.9);
}
/* a foe that was mid death-fade when its fight ended (fled / guard drove them off / defeat) must be finished off, not left
   'engaged' + dying forever (it would never be updated again and drew as a frozen pale-white blob). */
function settleDying(e){e.alive=false;e.engaged=false;e.flash=0;e.respawn=e.type==='lich'?240:e.def.boss?150:55;}
function reapStale(){
  for(let i=enemies.length-1;i>=0;i--)if(enemies[i].tmp&&!enemies[i].alive&&!enemies[i].engaged)enemies.splice(i,1);   // summoned minions leave the world with their fight
  for(const e of enemies){
    if(!e.alive){if(e.flash)e.flash=0;continue;}
    if(e.dying){if(!B||!B.ens.includes(e)||e.dyT>1.6)settleDying(e);continue;}
    if(e.engaged&&(!B||!B.ens.includes(e))){e.engaged=false;e.flash=0;e.st='idle';e.cur=null;e.dash=null;}
  }
}
function resetFighters(home){
  for(const e of B.ens){
    if(e.dying){settleDying(e);continue;}
    if(e.tmp){e.alive=false;e.engaged=false;e.flash=0;continue;}
    e.flash=0;e.bshield=0;
    e.engaged=false;e.frozen=0;e.fimm=0;e.chill=0;e.hp=e.maxhp;e.st='idle';e.guard=0;e.burn=0;e.dash=null;e.alert=0;e.mode='look';e.mt=2;e.cur=null;
    if(home){e.chasing=false;e.x=e.hx;e.y=e.hy;}
  }
}
/* 'escaping' only counts while you are truly breaking away: every live foe is beyond the leash distance, none is closing in,
   winding up an attack, or still has a clear line of sight to you within shooting range (walls / castle halls / ranged foes). */
const ESC_SEE=FLEE_DIST+120;
function breakingAway(dt){
  let d=1e9,threat=false;const pc=pcen();
  for(const e of B.ens){if(e.dying)continue;const c=ecen(e),dd=Math.hypot(pc.x-c.x,pc.y-c.y);d=Math.min(d,dd);
    if(e.st==='windup'||e.joinT>0)threat=true;
    if(dd<ESC_SEE&&losW(c,0,pc,0))threat=true;}
  const prev=B.escD==null?d:B.escD;B.escD=d;
  if(d>=1e9||d<=FLEE_DIST||threat)return false;
  return d>=prev-dt*20;                          // not catching up
}
function disengage(){
  resetFighters(false);P.grace=2.5;toast('You got away!',2,'#9ad0ff');B=null;
}
function updateBattle(dt){
  B.t+=dt;B.staleT=(B.staleT||0)-dt;if(B.staleT<=0){B.staleT=.5;reapStale();}B.shake=Math.max(0,B.shake-dt);B.loud=Math.max(0,B.loud-dt);B.atkGap=Math.max(0,B.atkGap-dt);
  B.fx.forEach(f=>f.t+=dt);B.fx=B.fx.filter(f=>f.t<f.dur);
  B.texts.forEach(t=>t.t+=dt);B.texts=B.texts.filter(t=>t.t<1);
  B.parts.forEach(q=>{q.t+=dt;q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=260*dt;});B.parts=B.parts.filter(q=>q.t<q.life);
  B.zones.forEach(w=>w.t+=dt);B.zones=B.zones.filter(w=>w.t<w.dur);updateBossMech(dt);
  if(B.banner){B.banner.t+=dt;if(B.banner.t>B.banner.dur)B.banner=null;}
  for(const tm of B.timers)tm.t-=dt;
  const due=B.timers.filter(t=>t.t<=0);B.timers=B.timers.filter(t=>t.t>0);due.forEach(t=>{B.owner=t.o;t.fn();});
  // territorial enemies give up (and walk home) once the player has been outside their turf for a while
  if(B.phase==='fight'){
    for(const e of B.ens.slice()){
      if(!e.terr||e.dying)continue;
      if(inTerr(e,P.x,P.y,6))e.outT=0;else e.outT=(e.outT||0)+dt;
      if(e.outT>2.5){
        e.outT=0;e.engaged=false;e.hp=e.maxhp;e.st='idle';e.cur=null;e.frozen=0;e.chill=0;e.dash=null;e.charge=0;e.guard=0;e.burn=0;e.mode='look';e.mt=1.5;
        B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);B.ens=B.ens.filter(o=>o!==e);
        if(!B.ens.some(o=>!o.dying)){disengage();return;}
      }
    }
  }
  // per-enemy bookkeeping: join delays, death fade-outs
  for(const e of B.ens){
    if(e.joinT>0){e.joinT-=dt;if(e.joinT<=0)sfx('warn');}
    if(e.dying){e.dyT+=dt;if(e.dyT>1.2&&e.alive){e.alive=false;e.engaged=false;e.respawn=e.type==='lich'?240:e.def.boss?150:55;}}
  }
  switch(B.phase){
    case 'alert':
      B.dim=Math.min(1,B.t/.4);
      if(B.t>.8){B.phase='fight';B.t=0;setBanner(B.ens.some(e=>e.def.boss)?'WARNING!':(B.ens.length>1?'GROUP BATTLE!':'BATTLE START!'),1.0,B.ens.some(e=>e.def.boss)?'#ff6b6b':'#ffe14d');dealHand();sfx('start');}
      break;
    case 'fight':
      B.dim=B.cleared?Math.max(0,B.dim-dt*1.6):1;
      updatePlayerCombat(dt);if(!B)return;
      updateExtras(dt);if(!B)return;
      updateFormation(dt);
      for(const e of B.ens.slice()){if(B.phase!=='fight')break;updateEnemyCombat(e,dt);}
      if(B.phase==='fight')updateShots(dt);
      if(B&&B.phase==='fight'){B.proxT=(B.proxT||0)-dt;if(B.proxT<=0){B.proxT=.3;const k2=recruit(.3,{prox:true});if(k2){B.total+=k2;toast('Nearby enemies joined the fight!',1.4,'#ffb0a0');}}}
      if(B&&B.phase==='fight'){B.noiseT-=dt;if(B.noiseT<=0){B.noiseT=.9;const k=recruit(.45);if(k){B.total+=k;toast('More enemies noticed the fight!',1.4,'#ffb0a0');}}}
      break;
    case 'win':
      B.dim=Math.max(0,B.dim-dt*.5);
      if(B.t>1.4){B.phase='reward';B.t=0;sfx('win');}
      break;
    case 'reward':
      B.dim=Math.max(0,B.dim-dt);
      if(B.t>.7&&hit('Space','Enter','KeyJ','KeyK','KeyE'))endBattle(true);
      break;
    case 'lose':
      if(B.t>2.4)endBattle(false);
      break;
  }
  if(B){B.ens=B.ens.filter(e=>!(e.dying&&!e.alive));if(B.cleared&&B.phase==='fight'&&!B.ens.length)endBattle(true);}
}
function endBattle(won){
  if(!won&&RUSH.on){resetFighters(true);B=null;snapCam();rushFinish('fell');return;}
  if(won){
    P.grace=2.5;
    if(B.boss&&B.bossName==='LICH KING')DLG={name:'NARRATOR',lines:['THE LICH KING CRUMBLES TO DUST!','The Crypt of Hollow Kings falls silent. The valley is safe from the dead - for now.','Return to Elder Orin in Oakvale to claim your reward.'],i:0,c:0};
    else if(B.boss)DLG={name:'NARRATOR',lines:['EMBERFANG HAS FALLEN!','The kingdom of Dracoryn is saved, and the villagers of Oakvale cheer your name.','Thanks for playing! Keep roaming, level up and fight everything - the dragon will return in time...'],i:0,c:0};
    B=null;
  } else {
    const lost=Math.floor(P.gold*.25);P.gold-=lost;P.hp=maxHp();setTimeout(()=>saveGame('respawn'),0);
    P.x=SPAWN.x;P.y=SPAWN.y;P.dir='d';P.grace=3;
    resetFighters(true);
    B=null;snapCam();
    toast(`You awaken in Oakvale village... (-${lost} gold)`,3.2,'#ff9a9a');
  }
}
