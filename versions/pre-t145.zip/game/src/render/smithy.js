/* =====================================================================
   t143u BRUM'S SMITHY: the house Brum stands in front of becomes his forge - a slate roof with a smoking stone chimney, a stone front
   with a glowing forge mouth and an anvil sign beside the door - plus a real ANVIL and a FURNACE (solid props) in his yard.
   Found from Brum's position every few seconds, so it follows editor moves / world growth.
   ===================================================================== */
Object.assign(T,{ANV:96,FRN:97});SOLID.add(T.ANV);SOLID.add(T.FRN);
const SMITHY=(()=>{
  const O='#1a1214',r=(g,x,y,w,h,c)=>rect(g,x,y,w,h,c);
  let box=null,boxT=-9;const C=new Map(),mk=(k,f)=>{let s=C.get(k);if(!s){s=makeSprite(16,16,f);C.set(k,s);}return s;};
  function find(){if(box&&gtime-boxT<3)return box;boxT=gtime;box=null;
    const n=NPCS.find(q=>q.name==='Blacksmith Brum');if(!n)return null;const tx=Math.floor(n.x/TS),ty=Math.floor(n.y/TS);
    let dy=-1;for(let k=1;k<=4;k++){const t=map[ty-k]&&map[ty-k][tx];if(t===T.D||t===T.H){dy=-k;break;}}if(dy===-1&&!(map[ty-1]&&(map[ty-1][tx]===T.D)))return null;
    const wy=ty+dy;let x0=tx,x1=tx;while(x0>0&&(map[wy][x0-1]===T.H||map[wy][x0-1]===T.D))x0--;while(x1<MW-1&&(map[wy][x1+1]===T.H||map[wy][x1+1]===T.D))x1++;
    let y0=wy;while(y0>0&&(map[y0-1][x0]===T.R||map[y0-1][x0]===T.RL||map[y0-1][x0+1]===T.R))y0--;
    box={x0,x1,y0,wy,door:tx,tx,ty};
    // yard props (only on open ground, never on the road)
    const put=(x,y,id)=>{const t=map[y]&&map[y][x];if(t===T.G||t===T.L||t===T.K||t===id)map[y][x]=id;};
    put(x0-1,wy+1,T.FRN);put(tx-2,ty,T.ANV);
    return box;}
  const roof=(x,y,b)=>mk('r'+(y-b.y0)+(x===b.x0?'l':x===b.x1?'r':'m')+(x===b.x1-1?'c':''),g=>{
    const top=y===b.y0;r(g,0,0,16,16,'#3a3a48');for(let yy=top?4:0;yy<16;yy+=4){r(g,0,yy,16,1,'#26262f');for(let xx=((yy/4)%2)*4;xx<16;xx+=8)r(g,xx,yy,1,4,'#26262f');r(g,0,yy+1,16,1,'#4a4a5a');}
    if(top){r(g,0,0,16,4,'#5a7a3a');r(g,0,3,16,1,O);}
    if(x===b.x1-1&&top){r(g,4,0,8,10,O);r(g,5,0,6,9,'#8a7a6a');r(g,5,0,6,2,'#ff9a3d');r(g,6,0,4,1,'#ffe14d');}});   // chimney with forge glow
  const wall=(x,y,b,id,t)=>{if(id===T.D)return null;const fr=x===b.x0+1||(b.x1-b.x0<3&&x===b.x0);const glow=.6+.4*Math.sin(t*6+x);
    return mk('w'+(x===b.x0?'l':x===b.x1?'r':'m')+(fr?'f'+Math.round(glow*4):'')+(x===b.door+1?'s':''),g=>{
      r(g,0,0,16,16,'#7a6e64');for(let yy=0;yy<16;yy+=4){r(g,0,yy+3,16,1,'#5a5048');for(let xx=((yy/4)%2)*5;xx<16;xx+=10)r(g,xx,yy,1,3,'#5a5048');}r(g,0,0,16,1,'#9a8e80');
      if(fr){r(g,2,5,12,11,O);r(g,3,6,10,10,'#3a1a10');ell(g,8,13,4,3,`rgb(255,${120+Math.round(glow*60)},40)`);ell(g,8,13,2,1,'#ffe14d');r(g,2,4,12,2,'#4a4038');}   // forge mouth
      if(x===b.door+1){r(g,3,3,10,8,O);r(g,4,4,8,6,'#8a5a32');r(g,5,6,6,2,'#2a2a30');r(g,7,8,2,1,'#2a2a30');r(g,6,5,1,1,'#ffd060');}   // anvil sign
      if(x===b.x0)r(g,0,0,1,16,O);if(x===b.x1)r(g,15,0,1,16,O);});};
  XTILE_FN[T.ANV]=()=>mk('anv',g=>{g.drawImage(TSPR[T.G][0],0,0);ell(g,8,14,6,2,'rgba(0,0,0,.3)');r(g,6,10,4,4,O);r(g,7,10,2,4,'#3a3a44');r(g,2,6,12,4,O);r(g,3,6,10,3,'#5a5a68');r(g,3,6,10,1,'#9a9aa8');r(g,1,6,3,2,O);r(g,4,12,8,2,O);});
  XTILE_FN[T.FRN]=(x,y,t)=>{const f=Math.floor((t||gtime)*6)%3;return mk('frn'+f,g=>{g.drawImage(TSPR[T.G][0],0,0);r(g,2,2,12,14,O);r(g,3,3,10,12,'#7a5a4a');r(g,3,3,10,2,'#9a7a6a');
    r(g,5,8,6,6,'#200c08');ell(g,8,12,2+(f===1?1:0),2,['#ff7a2a','#ffb02e','#ff9a3d'][f]);r(g,6,0,4,3,O);r(g,7,0,2,3,'#5a4a3a');});};
  TSPR[T.ANV]=[XTILE_FN[T.ANV]()];TSPR[T.FRN]=[XTILE_FN[T.FRN](0,0,0)];TSPR.mini[T.ANV]='#5a5a68';TSPR.mini[T.FRN]='#7a5a4a';
  function tile(id,x,y,t){const b=find();if(!b||x<b.x0||x>b.x1||y<b.y0||y>b.wy)return null;
    if(y<b.wy&&(id===T.R||id===T.RL||id===T.N))return roof(x,y,b);if(y===b.wy&&(id===T.H||id===T.D))return wall(x,y,b,id,t);return null;}
  return {find,tile};
})();
{const _ts=tileSprite;tileSprite=function(id,x,y,time){if(gtime-CHSIGN_T>=3)fixChapelSign();const s=SMITHY.tile(id,x,y,time);return s||_ts.apply(this,arguments);};}
/* ---- t143u: the Chapel Sign stood right in the chapel doorway - keep it beside the path instead (re-checked every few seconds) ---- */
let CHSIGN_T=0;
function fixChapelSign(){if(gtime-CHSIGN_T<3)return;CHSIGN_T=gtime;try{const n=NPCS.find(q=>q.name==='Chapel Sign');if(!n)return;const d=CHAPEL.door,y1=CHAPEL.y1;
  const tx=Math.floor(n.x/TS),ty=Math.floor((n.y-4)/TS);if(Math.abs(tx-d)>1||ty<y1-2||ty>y1+2)return;
  for(const [x,y] of [[d+3,y1+1],[d-3,y1+1],[d+3,y1+2],[d-3,y1+2],[d+4,y1+1]]){if(!solidTile(x,y)&&map[y][x]!==T.P&&map[y][x]!==T.W){n.x=(x+.5)*TS;n.y=(y+.9)*TS;if(n.hx!=null){n.hx=n.x;n.hy=n.y;}return;}}
  n.x=(d+3+.5)*TS;n.y=(y1+1+.9)*TS;}catch(e){}}
