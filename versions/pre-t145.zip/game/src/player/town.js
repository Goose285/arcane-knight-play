/* =====================================================================
   OAKVALE TOWN RULES: monsters never spawn in, wander into, or path into the village. Town Guards (strong, armoured, level 30)
   stand at both entrances. Run back into town mid-fight and the guards strike down the pursuers (bosses are driven off),
   ending the fight safely. Anything that somehow ends up inside the walls is sent home.
   ===================================================================== */
const TGB=[];                                                                       // guard bolts (visual)
[[11.4,30.5],[23.4,39.5]].forEach(([tx,ty],i)=>NPCS.push({name:'Town Guard',x:tx*TS,y:ty*TS,hx:tx*TS,hy:ty*TS,gcd:0,spr:'tguard',tguard:true,lv:TOWN.lv,
  lines:i===1?['Halt, hero! ...Ah, Oakvale\'s own. Crossing the bridge again?','No monster sets foot in Oakvale while the Guard stands. Run to us if a fight turns against you.']
            :['Oakvale\'s Guard, at your service.','Monsters are not allowed past these gates. If something chases you, run inside - we will deal with it.','Stay close to the wall and let our halberds do the talking.']}));
const guardsOf=()=>NPCS.filter(n=>n.tguard);
const tBurst=(x,y,c,n,sp,l)=>B?burst(x,y,c,n,sp,l):wfxBurst(x,y,c,n,sp,l),tText=(x,y,t,c,sz)=>B?floatText(x,y,t,c,sz):wfxText(x,y,t,c,sz);   // in or out of a fight
function townSend(e,fx=true){   // push an enemy back to its home, calm
  const c=ecen(e);tBurst(c.x,c.y,'#bfe6ff',12,130,.5);if(!B){wfxText(c.x,c.y-30,'SENT HOME','#bfe6ff',11);wfxBurst(e.hx,e.hy-12,'#bfe6ff',8,90,.4);}   // never a silent pop: puffs at both ends
  if(B&&B.ens.includes(e))B.guardOut=true;   // the guards (not the hero) removed this foe from the fight
  if(B){B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);B.ens=B.ens.filter(o=>o!==e);}
  Object.assign(e,{engaged:false,frozen:0,fimm:0,chill:0,hp:e.maxhp,st:'idle',cur:null,dash:null,burn:0,mode:'look',mt:2,chasing:false,calm:5,x:e.hx,y:e.hy});
}
/* A guard's bolt is a real hit, not a delete: it takes GUARD_DMG of the foe's max HP, so a fight with the guards is a few visible strikes
   (damage numbers, flash) ending in the normal death animation. Nothing is paid out to the hero for a guard kill. */
const GUARD_DMG=.4;
function guardSlay(e){
  const c=ecen(e);tBurst(c.x,c.y,'#fff6d8',16,150,.6);tBurst(c.x,c.y,'#9ad0ff',10,110,.5);sfx('boom');
  e.hp=0;e.dying=true;e.dyT=0;e.gdie=true;e.st='idle';e.cur=null;e.dash=null;e.guard=0;e.bshield=0;e.chasing=false;
  if(B&&B.ens.includes(e)){
    B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);
    toast('The Town Guard finishes it!',2.2,'#9ad0ff');
    if(B.ens.every(o=>o.dying))B.cleared=true;   // the normal end-of-fight runs once the death animation is done (no XP / loot for the hero)
  }
}
function guardStrike(e,gd){
  const gs=guardsOf();if(!gs.length||e.dying)return;const c=ecen(e);
  let g=gd||gs[0],bd=1e9;if(!gd)for(const q of gs){const d=Math.hypot(q.x-c.x,q.y-c.y);if(d<bd){bd=d;g=q;}}
  TGB.push({x0:g.x,y0:g.y-26,x1:c.x,y1:c.y,t:0,dur:.38});sfx('cshot');
  if(e.def.boss){e.hp=Math.max(1,e.hp-e.maxhp*.08);e.gHits=(e.gHits||0)+1;tText(c.x,c.y-34,'GUARD!','#bfe6ff',11);if(e.gHits>=3){tText(c.x,c.y-34,'DRIVEN OFF','#bfe6ff',11);townSend(e);}}
  else{const d=Math.max(1,Math.round(e.maxhp*GUARD_DMG));e.hp-=d;e.flash=.15;tText(c.x,c.y-30,'GUARD '+d,'#bfe6ff',11);if(e.hp<=0)guardSlay(e);}
}
/* the death animation of a foe the guards finished outside a fight (inside a fight the battle bookkeeping runs it) */
function updateGuardDeaths(dt){
  for(const e of enemies){if(!e.gdie)continue;
    if(!e.alive){e.gdie=false;continue;}   // already settled by the fight's own bookkeeping
    if(B&&B.ens.includes(e))continue;
    e.dyT+=dt;if(e.dyT>1){e.gdie=false;settleDying(e);}}
}
function townEnd(){
  if(!B)return;resetFighters(false);P.grace=3.5;toast('The Town Guard drove them off!',2.6,'#9ad0ff');sfx('select');B=null;
}
/* Guards defend their post on their own: any hostile within GUARD_R tiles of the post (or of the guard) is struck, whether or not
   the hero is fighting or even in town. They step out toward it (never beyond GUARD_LEASH tiles from the post) and walk back after. */
const GUARD_R=5*TS,GUARD_LEASH=1.6*TS,GUARD_CD=.85;
function guardTarget(g){   // only real threats: a foe fighting the hero near the gate, or any monster inside the walls. Idle / wandering monsters are left alone.
  let t=null,bd=1e9;const heroNear=playerInTown()||Math.hypot(P.x-g.x,P.y-g.y)<=GUARD_R+2*TS;
  for(const e of enemies){
    if(!e.alive||e.dying||e.tut||e.rush)continue;
    const inWalls=inTownPx(e.x,e.y-8),fightsHero=!!B&&B.phase==='fight'&&B.ens.includes(e)&&!e.lab;
    if(!inWalls&&!(fightsHero&&heroNear))continue;
    const d=Math.min(Math.hypot(e.x-g.hx,e.y-g.hy),Math.hypot(e.x-g.x,e.y-g.y));
    if(d<=GUARD_R&&d<bd){bd=d;t=e;}
  }
  return t;
}
function updateGuards(dt){
  for(const g of guardsOf()){
    g.gcd=Math.max(0,(g.gcd||0)-dt);
    const t=guardTarget(g);let gx=g.hx,gy=g.hy;
    if(t){
      const dx=t.x-g.hx,dy=t.y-g.hy,dl=Math.hypot(dx,dy)||1,k=Math.min(GUARD_LEASH,Math.max(0,dl-2.5*TS))/dl;   // step out only as far as needed to stay on the target
      gx=g.hx+dx*k;gy=g.hy+dy*k;g.face=dx<0?-1:1;
      if(g.gcd<=0){g.gcd=GUARD_CD;g.struck=(g.struck||0)+1;guardStrike(t,g);}
    }
    const sx=gx-g.x,sy=gy-g.y,sl=Math.hypot(sx,sy);
    if(sl>1){const m=Math.min(sl,(t?96:70)*dt);const nx=g.x+sx/sl*m,ny=g.y+sy/sl*m;if(!solidTile(Math.floor(nx/TS),Math.floor(ny/TS))){g.x=nx;g.y=ny;}else{g.x=g.hx;g.y=g.hy;}}
  }
}
function updateTown(dt){
  for(let i=TGB.length-1;i>=0;i--){TGB[i].t+=dt;if(TGB[i].t>=TGB[i].dur)TGB.splice(i,1);}
  if(!townOn())return;
  updateGuards(dt);updateGuardDeaths(dt);
  for(const e of enemies){
    if(e.calm>0)e.calm-=dt;
    if(!e.alive||e.dying||!inTownPx(e.x,e.y-8))continue;
    // a monster inside the walls: repelled (guards strike it when you are in a fight)
    if(B&&B.ens.includes(e)){{const gq=guardsOf().sort((a,b)=>Math.hypot(a.x-e.x,a.y-e.y)-Math.hypot(b.x-e.x,b.y-e.y))[0]||e;TGB.push({x0:gq.x,y0:gq.y-26,x1:e.x,y1:e.y-12,t:0,dur:.38});}tText(e.x,e.y-34,'REPELLED','#bfe6ff',11);townSend(e);}
    else townSend(e,false);
  }
  if(!B)return;
  if(B.guardOut&&!B.cleared&&!B.ens.length){townEnd();return;}   // only when the guards took the last foe: if the hero landed the kill, the normal victory runs
  if(playerInTown()&&B.phase==='fight'){
    B.townT=(B.townT||0)+dt;
    if(B.townT>.7){B.guardCd=(B.guardCd||0)-dt;if(B.guardCd<=0){B.guardCd=.55;
      const near=o=>guardsOf().some(g=>Math.min(Math.hypot(o.x-g.hx,o.y-g.hy),Math.hypot(o.x-g.x,o.y-g.y))<=GUARD_R);   // a guard only ever strikes what is within 5 tiles of himself / his post
      const t=B.ens.filter(o=>!o.dying&&near(o)).sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y))[0];if(t)guardStrike(t,guardsOf().filter(g=>Math.min(Math.hypot(t.x-g.hx,t.y-g.hy),Math.hypot(t.x-g.x,t.y-g.y))<=GUARD_R)[0]);
      if(B&&B.guardOut&&!B.cleared&&!B.ens.length)townEnd();}}
  }else if(B)B.townT=0;
}
function drawGuardBolts(){
  for(const b of TGB){const p=b.t/b.dur,a=1-p;ctx.save();ctx.globalAlpha=a;ctx.lineCap='round';
    const mx=(b.x0+b.x1)/2,my=(b.y0+b.y1)/2,ox=Math.sin(b.t*90)*6,oy=Math.cos(b.t*70)*6;
    ctx.strokeStyle='#7ab8ff';ctx.lineWidth=6;ctx.beginPath();ctx.moveTo(b.x0,b.y0);ctx.lineTo(mx+ox,my+oy);ctx.lineTo(b.x1,b.y1);ctx.stroke();
    ctx.strokeStyle='#ffffff';ctx.lineWidth=2.5;ctx.stroke();
    ctx.fillStyle='#bfe6ff';ctx.beginPath();ctx.arc(b.x1,b.y1,8+p*14,0,6.283);ctx.fill();ctx.restore();}
}
