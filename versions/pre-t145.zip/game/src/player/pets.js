/* =====================================================================
   PETS (follow + small attacks), TROPHIES and the PLAYER HOUSE
   ===================================================================== */
const PET={owned:{},active:null,bond:{},x:0,y:0,trail:[],cd:2,t:0,face:1,bcd:1.5,an:null};   // bcd/an = the autonomous basic attack (cooldown / running animation)
const HOUSE={trophies:{},slots:HOUSE_SLOTS.map(()=>null),elites:0,rested:0};
function resetPets(){PET.owned={};PET.active=null;PET.bond={};PET.trail=[];PET.cd=2;HOUSE.trophies={};HOUSE.slots=HOUSE_SLOTS.map(()=>null);HOUSE.elites=0;HOUSE.rested=0;}
function packPets(){return {owned:PET.owned,active:PET.active,bond:PET.bond,house:{t:HOUSE.trophies,s:HOUSE.slots,e:HOUSE.elites}};}
function unpackPets(s){resetPets();if(!s)return;
  for(const id of PET_IDS){if(s.owned&&s.owned[id])PET.owned[id]=true;if(s.bond&&s.bond[id]>0)PET.bond[id]=s.bond[id]|0;}
  PET.active=s.active&&PET.owned[s.active]?s.active:null;
  if(s.house){for(const id of TROPHY_IDS)if(s.house.t&&s.house.t[id])HOUSE.trophies[id]=true;
    HOUSE.slots=HOUSE_SLOTS.map((_,i)=>{const v=s.house.s&&s.house.s[i];return v&&HOUSE.trophies[v]?v:null;});HOUSE.elites=s.house.e|0;}
  if(PET.active)petSnap();}
const petLevel=id=>1+Math.min(PET_CFG.maxLv-1,Math.floor((PET.bond[id]||0)/PET_CFG.bondPerLv));
const petPower=id=>1+PET_CFG.lvMul*(petLevel(id)-1)+.04*(P.lv-1);
const petDmg=id=>Math.max(1,Math.round(PETS[id].dmg*petPower(id)));
function petSnap(){PET.x=P.x-14;PET.y=P.y;PET.trail=[];}
function adoptPet(id){
  const d=PETS[id];if(!d||PET.owned[id])return false;if(P.gold<d.price)return false;
  P.gold-=d.price;PET.owned[id]=true;if(!PET.active){PET.active=id;petSnap();}
  toast('Adopted '+d.name+'!',3,d.col);sfx('level');
  if(PET_IDS.every(k=>PET.owned[k]))awardTrophy('banner');
  saveGame('pet');return true;
}
function summonPet(id){if(id&&!PET.owned[id])return false;PET.active=id||null;if(id)petSnap();sfx('select');saveGame('pet');return true;}
function petOnKill(e){if(PET.active){const b=PET.bond[PET.active]||0,l0=petLevel(PET.active);PET.bond[PET.active]=b+(e.def.boss?5:1);if(petLevel(PET.active)>l0)toast(PETS[PET.active].name+' grew stronger! (bond Lv '+petLevel(PET.active)+')',3,PETS[PET.active].col);}}
function petOnHit(s,e){const d=PETS[s.pid];if(d&&d.chill&&!e.dying)e.chill=Math.max(e.chill||0,d.chill);}
// per-frame: follow the hero, attack in fights
function updatePet(dt){
  const id=PET.active;if(!id||state==='title')return;const d=PETS[id];
  PET.t+=dt;PET.trail.push({x:P.x,y:P.y});if(PET.trail.length>PET_CFG.follow)PET.trail.shift();
  const tp=PET.trail[0]||P;
  if(Math.hypot(P.x-PET.x,P.y-PET.y)>320||zoneOfPx(PET.y)!==zoneOfPx(P.y))petSnap();
  else{let nx=tp.x+(P.dir==='l'?36:P.dir==='r'?-36:P.dir==='u'?14:-14),ny=tp.y+(P.dir==='u'?28:P.dir==='d'?-18:-4);   // t143u: trails a bit farther behindconst k=Math.min(1,dt*7);
    if(B&&B.phase==='fight'&&B.target&&!B.target.dying){const c=ecen(B.target),a=Math.atan2(c.y-P.y,c.x-P.x);nx=P.x+Math.cos(a)*34+Math.cos(a+1.57)*18;ny=P.y+Math.sin(a)*24+Math.sin(a+1.57)*14;}   
    PET.face=nx<PET.x-.5?-1:nx>PET.x+.5?1:PET.face;PET.x=lerp(PET.x,nx,k);PET.y=lerp(PET.y,ny,k);}
  petBasic(dt,id,d);
  if(!B){petWorldAssist(dt,id,d);return;}
  if(B.phase!=='fight'||B.cleared)return;
  PET.cd-=dt;if(PET.cd>0)return;
  if(d.atk==='heal'){
    if(P.hp<maxHp()&&P.hp>0){const h=Math.max(2,Math.round((3+P.lv*.6)*petPower(id)));P.hp=Math.min(maxHp(),P.hp+h);const p=pcen();floatText(p.x,p.y-34,'+'+h,'#c58bff',12);burst(p.x,p.y,'#c58bff',8,70,.5);PET.cd=d.cd;}
    else{   // nothing to mend: a little spark at the nearest foe instead
      let t2=null,b2=1e9;for(const o of B.ens){if(o.dying||o.joinT>0)continue;const dd=Math.hypot(o.x-PET.x,o.y-PET.y);if(dd<b2&&dd<PET_CFG.attackRange){b2=dd;t2=o;}}
      if(!t2){PET.cd=.8;return;}
      const c2=ecen(t2),a2=Math.atan2(c2.y-(PET.y-12),c2.x-PET.x);
      B.shots.push({x:PET.x,y:PET.y-12,vx:Math.cos(a2)*330,vy:Math.sin(a2)*330,r:7,dmg:petDmg(id),own:'p',kind:'pet',pk:d.pk,pid:id,life:1.6,a:a2});sfx('shoot');PET.cd=d.cd*.6;}
    return;
  }
  let tg=B.target&&!B.target.dying&&B.target.joinT<=0?B.target:null,bd=1e9;
  if(d.atk==='heal')tg=null;   // (the moth's spark below picks its own nearest target)
  if(!tg)for(const o of B.ens){if(o.dying||o.joinT>0)continue;const dd=Math.hypot(o.x-PET.x,o.y-PET.y);if(dd<bd){bd=dd;tg=o;}}
  if(!tg){PET.cd=.5;return;}
  const c=ecen(tg),a=Math.atan2(c.y-(PET.y-12),c.x-PET.x);
  B.shots.push({x:PET.x,y:PET.y-12,vx:Math.cos(a)*330,vy:Math.sin(a)*330,r:7,dmg:petDmg(id),own:'p',kind:'pet',pk:d.pk,pid:id,life:1.6,a});
  sfx('shoot');PET.cd=d.cd*R(.9,1.1)*.8/(1+.04*(petLevel(id)-1));
}
/* ---- autonomous basic attack: every pet attacks nearby foes by itself on its own cooldown (no input) - melee lunge or a small ranged mote, by pet type ---- */
function petFoe(from,range,needLos){
  let best=null,bd=1e9;
  const list=B?(B.phase==='fight'&&!B.cleared?B.ens:[]):enemies;
  for(const e of list){
    if(!e.alive&&!B)continue;if(e.dying||(e.joinT>0))continue;
    const c=ecen(e),dd=Math.hypot(c.x-from.x,c.y-from.y);if(dd>range||dd>=bd)continue;
    if(!B&&(e.engaged||!sensed(e)))continue;               // out in the world a pet only joins in against foes that have already noticed you (it never wakes a sleeping one)
    if(needLos&&!losClear({x:from.x,y:from.y},c))continue;
    bd=dd;best=e;}
  return best;
}
function petBasic(dt,id,d){
  const an=PET.an;
  if(an){an.t+=dt;const k=an.t/an.dur;
    if(an.melee&&!an.hit&&k>=.5){an.hit=true;const e=an.tg;
      if(e&&(B?!e.dying:(e.alive&&!e.engaged&&!e.dying))){
        if(!B)startEncounter(e,true);
        if(B&&B.ens.includes(e)){damageEnemy(e,an.dmg,'pet');petOnHit({pid:id},e);}
        const c=ecen(e);burst(c.x,c.y-6,d.col,10,110,.4);sfx('hit');}}
    if(an.t>=an.dur)PET.an=null;
    return;}
  if(state!=='play'||DLG||P.hp<=0||!d.bm)return;
  if(B&&(B.phase!=='fight'||B.cleared))return;
  if(!B&&(P.grace>0||WARP||RUSH.on||playerInTown()))return;   // spawn / teleport grace: the pet stays calm
  PET.bcd-=dt;if(PET.bcd>0)return;
  const o={x:PET.x,y:PET.y-12},e=petFoe(o,d.br,d.bm==='ranged');
  if(!e){PET.bcd=.4;return;}
  const c=ecen(e),a=Math.atan2(c.y-o.y,c.x-o.x),dmg=Math.max(1,Math.round(petDmg(id)*d.bd));
  PET.bcd=d.bcd*R(.9,1.15)/(1+.04*(petLevel(id)-1));PET.face=c.x<PET.x?-1:1;
  if(d.bm==='melee'){PET.an={t:0,dur:.42,melee:true,hit:false,tg:e,dmg,dx:Math.cos(a),dy:Math.sin(a),dist:Math.max(0,Math.hypot(c.x-o.x,c.y-o.y)-18),v:d.bv};sfx('slash');}
  else{
    const sh={x:o.x,y:o.y,vx:Math.cos(a)*300,vy:Math.sin(a)*300,r:4,dmg,own:'p',kind:'pet',pk:d.pk,pid:id,life:1.1,a};
    if(B)B.shots.push(sh);else WS.push(sh);
    PET.an={t:0,dur:.3,melee:false,dx:Math.cos(a),dy:Math.sin(a),v:d.bv};sfx('shoot');}
}
// overworld: while you shoot, your pet joins in on the same enemy (they never start a fight on their own); healers mend you when hurt
function petWorldAssist(dt,id,d){
  if(state!=='play'||DLG||P.hp<=0)return;
  PET.cd-=dt;if(PET.cd>0)return;
  if(d.atk==='heal'){
    if(P.hp<maxHp()*.9){const h=Math.max(2,Math.round((3+P.lv*.6)*petPower(id)));P.hp=Math.min(maxHp(),P.hp+h);const p=pcen();floatText(p.x,p.y-34,'+'+h,'#c58bff',12);burst(p.x,p.y,'#c58bff',8,70,.5);PET.cd=d.cd*1.2;}
    else PET.cd=.8;return;
  }
  if(!(wcd>0||WCH.on)){PET.cd=.05;return;}
  let best=null,bd=1e9;const pe={x:P.x,y:P.y-12};
  for(const e of enemies){if(!e.alive||e.engaged||e.dying)continue;const c=ecen(e),dd=Math.hypot(c.x-pe.x,c.y-pe.y);if(dd>PET_CFG.attackRange*.7)continue;
    const df=Math.abs(angDiff(angTo(pe,c),P.aim));if(df>.7)continue;if(!losClear({x:PET.x,y:PET.y-12},c))continue;if(dd<bd){bd=dd;best=e;}}
  if(!best){PET.cd=.15;return;}
  const c=ecen(best),a=Math.atan2(c.y-(PET.y-12),c.x-PET.x);
  WS.push({x:PET.x,y:PET.y-12,vx:Math.cos(a)*330,vy:Math.sin(a)*330,r:7,dmg:petDmg(id),own:'p',kind:'pet',pk:d.pk,pid:id,life:1.6,a});
  sfx('shoot');PET.cd=d.cd*.6/(1+.04*(petLevel(id)-1));
}
function drawPetWorld(){
  const id=PET.active;if(!id)return;const d=PETS[id],spr=SP.pets[id];
  const fly=id==='wisp'||id==='moth',bob=Math.round(Math.sin(PET.t*(fly?5:9))*(fly?3:1.2)),lift=fly?10:0;
  const an=PET.an,k=an?clamp(an.t/an.dur,0,1):0,sn=an?Math.sin(k*Math.PI):0;
  let ox=0,oy=0,sx=1.5,sy=1.5;
  if(an){
    if(an.melee){const f=Math.sin(Math.min(1,k/.5)*Math.PI/2)*(k<.5?1:1-(k-.5)/.5);ox=an.dx*an.dist*f;oy=an.dy*an.dist*f*.8;sx=1.5*(1+.2*sn);sy=1.5*(1-.15*sn);}
    else{const rc=k<.35?Math.sin(k/.35*Math.PI):0;ox=-an.dx*4*rc;oy=-an.dy*3*rc;sx=1.5*(1+.18*rc);sy=1.5*(1-.12*rc);}
  }
  drawEntShadow(PET.x+ox,PET.y,fly?6:8);
  const w=spr.width*sx,h=spr.height*sy,x=Math.round(PET.x+ox-cam.x-w/2),y=Math.round(PET.y+oy-cam.y-h+1-lift+bob);
  if(an&&an.melee&&k>=.45&&k<.95){   // slash arcs at the target
    const e=an.tg,c=e&&ecen(e);if(c){ctx.save();ctx.globalAlpha=1-(k-.45)/.5;ctx.strokeStyle=d.col;ctx.lineWidth=3;
      const ang=Math.atan2(an.dy,an.dx);for(let i=-1;i<=1;i++){ctx.beginPath();ctx.arc(c.x-cam.x,c.y-6-cam.y,12+i*5,ang-.7+i*.08,ang+.7+i*.08);ctx.stroke();}ctx.restore();}}
  if(an&&!an.melee&&k<.4){ctx.save();ctx.globalAlpha=1-k/.4;ctx.fillStyle=d.col;ctx.beginPath();ctx.arc(PET.x-cam.x+an.dx*12,PET.y-12-cam.y+an.dy*10,5-k*8,0,6.283);ctx.fill();ctx.restore();}
  if(PET.face<0){ctx.save();ctx.translate(x+w,y);ctx.scale(-1,1);ctx.drawImage(spr,0,0,w,h);ctx.restore();}else ctx.drawImage(spr,x,y,w,h);
}
/* ---------------- trophies ---------------- */
function awardTrophy(id){if(!TROPHIES[id]||HOUSE.trophies[id])return false;HOUSE.trophies[id]=true;toast('TROPHY: '+TROPHIES[id].name+'  (display it in your house)',4.5,TROPHIES[id].col);sfx('level');return true;}
function trophyOnKill(e){
  const t=TROPHY_BOSS[e.type];if(t&&!e.rush)awardTrophy(t);
  if(e.elite&&!e.rush){HOUSE.elites++;if(HOUSE.elites>=10)awardTrophy('brand');}
}
const trophyCount=()=>TROPHY_IDS.filter(i=>HOUSE.trophies[i]).length;
// cycle a shelf slot through the trophies you own that are not shown elsewhere (then empty)
function cycleSlot(i){
  const used=new Set(HOUSE.slots.filter((v,k)=>v&&k!==i)),opts=[null,...TROPHY_IDS.filter(t=>HOUSE.trophies[t]&&!used.has(t))];
  const cur=Math.max(0,opts.indexOf(HOUSE.slots[i]));HOUSE.slots[i]=opts[(cur+1)%opts.length];sfx('select');return HOUSE.slots[i];
}
/* ---------------- the house ---------------- */
function buildHouse(){
  const set=(x,y,t)=>{if(x>=0&&y>=0&&x<MW&&y<MH)map[y][x]=t;};
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  fill(0,HOUSE_Y0,MW-1,HOUSE_Y0+HOUSE_H-1,T.B);
  fill(HOUSE_ROOM.x0,HOUSE_ROOM.y0,HOUSE_ROOM.x1,HOUSE_ROOM.y1,T.F);
  fill(HOUSE_ROOM.x0,HOUSE_ROOM.y0-1,HOUSE_ROOM.x1,HOUSE_ROOM.y0-1,T.BT);
  fill(29,HOUSE_ROOM.y1-1,33,HOUSE_ROOM.y1,T.P);                         // doormat road
  set(31,HOUSE_ROOM.y1,T.GX);ZEXITS[31+','+HOUSE_ROOM.y1]='house';
  if(HOUSEVOID===4){   // mockup: a bigger house - a kitchen / storage room west of the main room, through a doorway in the shared wall
    const K=HOUSE_KIT,R=HOUSE_ROOM,y0=R.y0,y1=R.y1,prop=(x,y,t,rx=0,ry=0)=>{set(x,y,T.B);HOUSE_PROPS[x+','+y]=[t,rx,ry];};
    fill(K.x0,y0,K.x1,y1,T.F);fill(K.x0,y0-1,K.x1,y0-1,T.BT);
    set(R.x0-1,y0+1,T.F);set(R.x0-1,y0+2,T.F);   // the doorway (2 tiles)
    prop(K.x0,y0,'counter',0);prop(K.x0+1,y0,'counter',1);prop(K.x0+2,y0,'counter',2);prop(K.x0+3,y0,'counter',3);
    prop(K.x0+4,y0,'stove');prop(K.x0+5,y0,'barrel');prop(K.x0+6,y0,'crate');prop(K.x1,y0,'crate');prop(K.x1,y0+1,'barrel');
    for(let ry=0;ry<2;ry++)for(let rx=0;rx<2;rx++)prop(K.x0+2+rx,y0+5+ry,'table',rx,ry);
    prop(K.x0,y1,'crate');prop(K.x0,y1-1,'barrel');prop(K.x0+1,y1,'crate');
  }
}
buildHouse();
MINI.house={spr:makeSprite(MW*2,HOUSE_H*2,g=>{g.fillStyle='#0a0814';g.fillRect(0,0,MW*2,HOUSE_H*2);for(let y=0;y<HOUSE_H;y++)for(let x=0;x<MW;x++){g.fillStyle=TSPR.mini[map[HOUSE_Y0+y][x]]||'#000';g.fillRect(x*2,y*2,2,2);}}),y0:HOUSE_Y0};
NPCS.push({name:'Marlo the Keeper',x:9.5*TS,y:41.4*TS,spr:'keeper',pets:true,lines:[]});
NPCS.push({name:'Trophy Shelf',x:31.5*TS,y:(HOUSE_ROOM.y0+1)*TS,spr:'shelfPost',house:'shelf',lines:[]});
NPCS.push({name:'Your Bed',x:(HOUSE_ROOM.x1-1.2)*TS,y:(HOUSE_ROOM.y0+9.6)*TS,spr:'bed',house:'bed',lines:[]});
function enterHouse(){if(!canTravel())return false;startWarp(HOUSE_IN);return true;}
/* the front door of the player's house (no sign any more): walk into it, or tap it and the hero walks over and goes in */
const HOUSE_FRONT={x:(HOUSE_DOOR.tx+.5)*TS,y:HOUSE_DOOR.ty*TS+28};
function updateHouseDoor(){
  if(state!=='play'||B||WARP||DLG||RUSH.on||FISH.on||zoneOfPx(P.y)!=='ow')return;
  // the hero can rest right against the door (he stops ~20px above HOUSE_FRONT.y): any push up while standing in the doorway enters, including sliding along the wall or a slightly diagonal stick
  if(Math.abs(P.x-HOUSE_FRONT.x)<16&&P.y<=HOUSE_FRONT.y+2&&P.y>HOUSE_FRONT.y-30){const mv=moveInput();if(mv[2]>0&&mv[1]<-.3&&enterHouse())P.moving=false;}
}
function openHouseNpc(n){
  if(n.house==='shelf')openUIMode('house','play');
  else if(n.house==='bed')DLG={name:'YOUR BED',lines:['A soft bed under a warm quilt. Sleep until morning?  (restores all HP and saves the game)'],i:0,c:0,yes:'SLEEP',no:'NOT NOW',choice:()=>bedSleep(),noAct:()=>{DLG=null;}};   // t138u
}
function openPets(){openUIMode('pets',state==='paused'?'paused':'play');}
