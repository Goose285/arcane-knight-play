/* =====================================================================
   DAY / NIGHT  - one full cycle = 8 minutes. t: 0.5 noon, 1.0 (= 0) midnight.
   Full dark = 20% of the cycle (96s) around midnight, dusk and dawn are 5% each (24s) - the monsters' 'night' lasts about 2 minutes.
   Night: enemies +2 levels, extra night-only monsters (wraiths haunt the meadow), torches / windows glow.
   ===================================================================== */
const DAY_CFG={dark:.10,fade:.05};   // fractions of the cycle: dark core is +-10% around midnight, dusk/dawn fade 5%
const DAY={t:.3,len:480,sun:1,nightAmt:0,night:false,syncT:0};
const smooth=(a,b,x)=>{const t=clamp((x-a)/(b-a),0,1);return t*t*(3-2*t);};
function dayCompute(){
  DAY.sun=Math.sin((DAY.t-.25)*6.283185);
  const m=Math.min(DAY.t,1-DAY.t);                              // distance from midnight (0 .. .5)
  DAY.nightAmt=smooth(DAY_CFG.dark+DAY_CFG.fade,DAY_CFG.dark,m);   // 1 inside the dark core, fades out over the dusk/dawn band
  const was=DAY.night;
  if(!was&&DAY.nightAmt>.55)DAY.night=true;else if(was&&DAY.nightAmt<.4)DAY.night=false;
  return was!==DAY.night;
}
const twilight=()=>{const m=Math.min(DAY.t,1-DAY.t);return Math.max(0,1-Math.abs(m-(DAY_CFG.dark+DAY_CFG.fade/2))/(DAY_CFG.fade*1.3));};
function setTimeOfDay(t){DAY.t=((t%1)+1)%1;if(dayCompute()||true)syncNight(true);}
const isEvening=()=>DAY.sun<.2;   // dusk, night and the hours before dawn
/* t138u: your own bed - sleep any time: soft fade, skip to the next morning, full HP, poison cured, game saved (free) */
function bedSleep(){
  if(WARP||B)return false;releaseAllTouch();DLG=null;HOUSE.rested++;
  startWarp({x:P.x,y:P.y,dir:P.dir},{sleep:true,mid:()=>{setTimeOfDay(.3);P.hp=maxHp();P.regen=0;try{poisonCure();}catch(e){}repopulate();toast('Good morning! You slept soundly in your own bed.',3.2,'#ffe9a0');sfx('level');saveGame('bed');}});
  return true;
}
/* sleep through the night: fade out, jump to morning, heal, refill the wilds, save, fade in (fee in gold, 0 = free) */
function sleepToMorning(cost,msg){
  if(WARP||B||RUSH.on||!isEvening())return false;if(P.gold<cost)return false;
  P.gold-=cost;releaseAllTouch();DLG=null;
  startWarp({x:P.x,y:P.y,dir:P.dir},{sleep:true,mid:()=>{setTimeOfDay(.3);P.hp=maxHp();P.regen=0;poisonCure();repopulate();toast(msg||'You wake at dawn, rested.',3.2,'#ffe9a0');sfx('level');saveGame('sleep');}});
  return true;
}
/* respawn timers must never strand a region without monsters across a dusk / dawn change: anything defeated recovers within seconds */
function repopulate(){
  for(const e of enemies){
    if(e.night||e.spw||e.rush||e.def.boss)continue;
    if(!e.alive&&!(e.respawn<=8))e.respawn=4+Math.random()*4;
  }
  if(typeof reapStale==='function')reapStale();
}
function updateDayNight(dt){
  if(hit('KeyV')&&state==='play'&&!DLG&&!isUI()&&!B)toggleLight();
  DAY.t=(DAY.t+dt/DAY.len)%1;
  if(dayCompute()){
    if(DAY.night){toast('Night falls... the dead walk the meadow',3.6,'#b9a6ff');sfx('warn');}
    else toast('Dawn breaks',2.6,'#ffe9a0');
    syncNight(true);repopulate();
  }
  DAY.syncT-=dt;if(DAY.syncT<=0){DAY.syncT=.5;syncNight(false);}
}
/* enemies: +2 levels at night (overworld, not in a fight); night-only monsters appear at dusk and vanish at dawn */
function syncNight(force){
  for(const e of enemies){
    if(e.def.boss||zoneOfPx(e.hy)==='crypt')continue;
    if(e.night){
      if(DAY.night){if(!e.alive&&!e.engaged&&!e.nightUp){e.alive=true;e.nightUp=true;resetEnemyState(e);}}
      else{e.nightUp=false;if(e.alive&&!e.engaged&&!e.dying){const c=ecen(e);wfxBurst(c.x,c.y,'#b9a6ff',14,80,.9);wfxText(c.x,c.y-28,'fades at dawn','#d6c8ff',10);e.alive=false;}}   // dawn: night monsters dissolve in view, never just blink out
    }
    if(e.engaged||e.dying)continue;
    const want=e.baseLv+(DAY.night&&!e.night?2:0);
    if(e.lv!==want)applyLevel(e,want);
  }
}
/* ---- lighting overlay: dark layer with holes cut for lights, then additive warm glow ---- */
const LIGHT={cv:null,g:null,tk:0};
const NIGHT_DARK=.66,NIGHT_DARK_TOWN=.54;   // night overlay strength (was .84 everywhere): you can always see the area; the lantern-lit village is gentlest
function collectLights(cr){
  const al=activeLight(),L=[al?{x:P.x-cam.x,y:P.y-cam.y-14,r:cr?al.r*1.05:al.r,a:al.a,c:al.c,gl:al.gl}:{x:P.x-cam.x,y:P.y-cam.y-14,r:cr?118:104,a:.95,c:'255,220,150',gl:.18}];
  const cx=Math.round(cam.x),cy=Math.round(cam.y),x0=Math.floor(cx/TS)-2,y0=Math.floor(cy/TS)-2,x1=x0+Math.ceil(VW/TS)+5,y1=y0+Math.ceil(VH/TS)+5;
  for(let y=Math.max(0,y0);y<=Math.min(MH-1,y1);y++)for(let x=Math.max(0,x0);x<=Math.min(MW-1,x1);x++){
    const t=map[y][x];
    if(t===T.CT)L.push({x:x*TS+16-cx,y:y*TS+12-cy,r:104,a:.9,c:'255,150,60',gl:.4,fk:.12,ph:x*7.3+y*3.1});
    else if(!cr&&t===T.LN)L.push({x:x*TS+16-cx,y:y*TS+8-cy,r:120,a:.9,c:'255,196,100',gl:.55,ph:x*7.3+y*3.1});
    else if(!cr&&t===T.FR)L.push({x:x*TS+16-cx,y:y*TS+10-cy,r:136,a:1,c:'255,140,50',gl:.8,fk:.17,ph:x*7.3+y*3.1});
    else if(!cr&&t===T.Z)L.push({x:x*TS+16-cx,y:y*TS+4-cy,r:92,a:.85,c:'255,160,70',gl:.4,fk:.1,ph:x*7.3+y*3.1});
    else if(!cr&&t===T.CHA)L.push({x:x*TS+16-cx,y:y*TS+10-cy,r:70,a:.75,c:'255,205,120',gl:.5,fk:.08,ph:x*7.3+y*3.1});
    else if(!cr&&t===T.H&&(hash2(x,y)%2)===1)L.push({x:x*TS+16-cx,y:y*TS+16-cy,r:58,a:.75,c:'255,215,120',gl:.34,win:{x:x*TS+8-cx,y:y*TS+8-cy}});
  }
  if(!cr)for(const n of NPCS){if(!n.way||!SEC.ways[n.way])continue;const lx=n.x-cam.x,ly=n.y-22-cam.y;if(lx<-120||lx>VW+120||ly<-120||ly>VH+120)continue;L.push({x:lx,y:ly,r:92,a:.75,c:'125,249,255',gl:.55,fk:.06,ph:n.x*.07+n.y*.11});}
  if(!cr)for(const sp of SPW){if(!sp.alive||sp.dying)continue;const lx=sp.x-cam.x,ly=sp.y-26-cam.y;if(lx<-120||lx>VW+120||ly<-120||ly>VH+120)continue;L.push({x:lx,y:ly,r:104+(sp.near?16:0),a:.85,c:SPW_THEME[sp.def.theme].glow,gl:.6,fk:.15});}
  return L;
}
// subtle, smooth fire flicker: a few SLOW sines (all under 1 Hz-ish), phased by the light's WORLD position (not its screen position, so scrolling never makes it pulse);
// steady lights barely shimmer, and the lantern-lit village flickers half as much so the whole town reads even
function lightFlick(l){const ph=l.ph||0;
  if(!l.fk)return 1+Math.sin(gtime*1.6+ph)*.02;
  return 1+l.fk*.6*(Math.sin(gtime*2.3+ph)*.5+Math.sin(gtime*3.7+ph*1.7)*.35+Math.sin(gtime*6+ph*.6)*.15)*(1-.5*LIGHT.tk);}
function drawLighting(){
  if(zoneOfPx(P.y)==='house')return;          // indoors at home: always warmly lit
  const cr=inCryptPx(P.x,P.y),G=dayGrade();
  if(!cr)drawGrade(G);                        // warm late-morning cream -> sunset orange (multiply + a soft orange wash)
  LIGHT.tk+=((playerInTown()?1:0)-LIGHT.tk)*.07;
  const dark=cr?.55:(NIGHT_DARK+(NIGHT_DARK_TOWN-NIGHT_DARK)*LIGHT.tk)*DAY.nightAmt,lamp=cr?1:G.lamp;
  if(dark<.02&&lamp<.03)return;
  const L=collectLights(cr);
  if(dark>=.02){
    if(!LIGHT.cv||LIGHT.cv.width!==VW||LIGHT.cv.height!==VH){LIGHT.cv=document.createElement('canvas');LIGHT.cv.width=VW;LIGHT.cv.height=VH;LIGHT.g=LIGHT.cv.getContext('2d');}
    const g=LIGHT.g;
    g.globalCompositeOperation='source-over';g.clearRect(0,0,VW,VH);
    g.fillStyle=cr?`rgba(5,3,20,${dark})`:`rgba(16,8,58,${dark})`;g.fillRect(0,0,VW,VH);   // deep blue-purple night
    g.globalCompositeOperation='destination-out';
    for(const l of L){const fl=lightFlick(l),r=l.r*(1+(fl-1)*.5),aa=Math.min(1,l.a*(1+(fl-1)*.6)),gr=g.createRadialGradient(l.x,l.y,0,l.x,l.y,r);gr.addColorStop(0,`rgba(0,0,0,${aa})`);gr.addColorStop(.35,`rgba(0,0,0,${aa*.72})`);gr.addColorStop(.7,`rgba(0,0,0,${aa*.28})`);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(l.x-r,l.y-r,r*2,r*2);}
    ctx.drawImage(LIGHT.cv,0,0);
  }
  ctx.save();ctx.globalCompositeOperation='screen';   // 'screen' (not additive): overlapping lanterns / fire blend smoothly and can never blow out
  if(!cr&&LIGHT.tk>.01&&DAY.nightAmt>.01){ctx.fillStyle=`rgba(255,168,92,${(.085*LIGHT.tk*DAY.nightAmt).toFixed(4)})`;ctx.fillRect(0,0,VW,VH);}   // steady warm lamplight over the whole village
  for(let i=0;i<L.length;i++){const l=L[i];if(i===0&&!cr&&DAY.nightAmt<.05)continue;
    const fl=lightFlick(l),k=Math.min(.7,lamp*l.gl*(1+(fl-1)*1.2)),r=l.r*.85,gr=ctx.createRadialGradient(l.x,l.y,0,l.x,l.y,r);gr.addColorStop(0,`rgba(${l.c},${k})`);gr.addColorStop(.5,`rgba(${l.c},${k*.38})`);gr.addColorStop(1,`rgba(${l.c},0)`);ctx.fillStyle=gr;ctx.fillRect(l.x-r,l.y-r,r*2,r*2);
    if(l.win){ctx.fillStyle=`rgba(255,225,130,${.75*lamp})`;ctx.fillRect(l.win.x,l.win.y,16,14);}}
  ctx.restore();
  if(!cr)drawNightFx();
}
/* castle torches burn on the throne-room pillars */
function drawFlame(px,py){
  const f=Math.floor(gtime*9+px)%3,h=7+f;
  ctx.fillStyle='#ff7a1f';ctx.fillRect(px-3,py-h,6,h);ctx.fillStyle='#ffc23a';ctx.fillRect(px-2,py-h+2,4,h-2);ctx.fillStyle='#fff3b0';ctx.fillRect(px-1,py-3,2,3);
}
function drawDayIcon(x,y){
  const n=DAY.nightAmt>.5;
  if(!n){ctx.fillStyle='#ffd23f';ctx.beginPath();ctx.arc(x,y,5,0,6.283);ctx.fill();ctx.fillStyle='#fff3b0';for(let i=0;i<8;i++){const a=i*.785+gtime*.5;ctx.fillRect(Math.round(x+Math.cos(a)*8)-1,Math.round(y+Math.sin(a)*8)-1,2,2);}}
  else{ctx.fillStyle='#dfe6ff';ctx.beginPath();ctx.arc(x,y,5,0,6.283);ctx.fill();ctx.fillStyle='#0a0814';ctx.beginPath();ctx.arc(x+3,y-2,4.5,0,6.283);ctx.fill();}
}
