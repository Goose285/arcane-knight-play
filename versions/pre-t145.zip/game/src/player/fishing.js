/* =====================================================================
   FISHING (idle, relaxed): tap a rippling spot (or press E next to it) with a rod -> you cast ONCE and fish are caught by themselves every
   ~8-15s while you do nothing; now and then a RARE BITE pops up - tap within ~4s to land the big one. REEL IN (or walk away / Esc) stops.
   Every catch buzzes (haptics), pops the fish out of the water into the hero's hands with a small splash ring + floating +Name, and chimes (golden sparkles on rare).
   XP -> fishing levels (unlock better spots + fish). State saved as {rod,xp,caught,fish}.
   ===================================================================== */
const FSH={rod:-1,xp:0,caught:0,fish:{}};
function resetFish(){FSH.rod=-1;FSH.xp=0;FSH.caught=0;FSH.fish={};}
function packFish(){return {rod:FSH.rod,xp:FSH.xp,caught:FSH.caught,fish:FSH.fish};}
function unpackFish(s){resetFish();if(!s||typeof s!=='object')return;
  FSH.rod=clamp(s.rod|0,-1,RODS.length-1);FSH.xp=clamp(s.xp|0,0,99999);FSH.caught=clamp(s.caught|0,0,99999);
  if(s.fish&&typeof s.fish==='object')for(const k in s.fish)if(FISH_BY[k])FSH.fish[k]=clamp(s.fish[k]|0,0,99);}
function fishLv(){let l=1,x=FSH.xp;while(l<FISH_MAX_LV&&x>=fishNeed(l)){x-=fishNeed(l);l++;}return l;}
function fishXpInto(){let l=1,x=FSH.xp;while(l<FISH_MAX_LV&&x>=fishNeed(l)){x-=fishNeed(l);l++;}return [l>=FISH_MAX_LV?fishNeed(l-1):x,l>=FISH_MAX_LV?fishNeed(l-1):fishNeed(l)];}
const fishCount=()=>Object.values(FSH.fish).reduce((a,b)=>a+b,0);
const rodPrice=r=>storyGold(r.price);
function buyRod(i){const r=RODS[i];if(!r||i<=FSH.rod)return false;const p=rodPrice(r);if(P.gold<p)return false;P.gold-=p;FSH.rod=i;return true;}
function addFishXp(n){const l0=fishLv();FSH.xp+=n;const l1=fishLv();if(l1>l0){toast('FISHING LEVEL '+l1+'!'+(FISH_SPOTS.some(s=>s.lv===l1)?'  New fishing spot unlocked':'')+(FISHES.some(f=>f.lv===l1)?'  New fish':''),3.4,'#7df9ff');sfx('level');}}
const spotCenter=s=>s.pond?{x:(s.pond.x+s.pond.w/2)*TS,y:(s.pond.y+s.pond.h/2)*TS}:{x:s.tx*TS+TS/2,y:s.ty*TS+TS/2};
const FISH_REACH=66;
const spotDist=s=>{const c=spotCenter(s);return Math.hypot(c.x-P.x,c.y-(P.y-10));};
function fishSpotNear(){let b=null,bd=FISH_REACH;for(const s of FISH_SPOTS){if(zoneOfPx(spotCenter(s).y)!==zoneOfPx(P.y))continue;const d=spotDist(s);if(d<bd){bd=d;b=s;}}return b;}
/* ---- the cast ---- */
const FISH_CFG={catch:[8,15],rare:[35,60],afterRare:[4,8],cast:.7};
const FISH={fid:null,yank:0,on:false,spot:null,ph:'',t:0,next:0,rare:0,win:4,pick:null,stopR:null,tap:false,fx:[],flash:null,log:[],session:0};
function endFishing(msg,col){FISH.on=false;FISH.ph='';FISH.spot=null;FISH.tap=false;FISH.stopR=null;FISH.pick=null;FISH.fx.length=0;FISH.flash=null;FISH.fid=null;FISH.sh=null;FISH.yank=0;if(msg)toast(msg,2.2,col||'#cfe3ff');}
function startFishing(spot){
  if(!spot||B||DLG)return false;
  if(FSH.rod<0){toast("You need a fishing rod - Brum sells one at the forge!",3.2,'#ffd98a');sfx('clang');return false;}
  if(fishLv()<spot.lv){toast('Fishing Lv '+spot.lv+' needed for '+spot.name+'  (you are Lv '+fishLv()+')',3.2,'#ffd98a');sfx('clang');return false;}
  const c=spotCenter(spot);P.dir=Math.abs(c.x-P.x)>=Math.abs(c.y-(P.y-10))*.55?(c.x<P.x?'l':'r'):(c.y<P.y-10?'u':'d');   // water to the side (even a bit diagonal) = side profile; only mostly-vertical water faces up / down
  P.aim=Math.atan2(c.y-(P.y-10),c.x-P.x);P.moving=false;P.anim=0;
  FISH.on=true;FISH.spot=spot;FISH.ph='cast';FISH.t=0;FISH.tap=false;FISH.fx.length=0;FISH.flash=null;FISH.fid=null;FISH.sh=null;FISH.yank=0;FISH.log=[];FISH.session=0;WCH.on=false;WCH.t=0;sfx('whoosh');return true;
}
const fishPool=spot=>{const lv=fishLv();return FISHES.filter(f=>f.lv<=lv&&f.tier<=spot.tier&&f.tier>=spot.tier-1);};
const fishIsRareBite=f=>f.w<=4||f.rar>=4;   // the shy / precious fish only come on a Rare bite
function fishWeighted(pool,spot,rod){
  if(!pool.length)return FISHES[0];
  const ws=pool.map(f=>f.w*(f.w<=4?1+rod.luck*2:1)*(f.tier===spot.tier?1.6:1));let t=ws.reduce((a,b)=>a+b,0),r=Math.random()*t;
  for(let i=0;i<pool.length;i++){r-=ws[i];if(r<=0)return pool[i];}
  return pool[0];
}
function fishPick(spot){   // the plain mixed pick (kept for tests / tools)
  const rod=RODS[FSH.rod]||RODS[0];
  if(Math.random()<.015+rod.luck*.02)return FISH_BY.pearl;
  if(Math.random()<.08)return FISH_BY.boot;
  return fishWeighted(fishPool(spot),spot,rod);
}
function fishPickAuto(spot){   // an ordinary catch: the everyday fish of this water (a little junk now and then)
  const rod=RODS[FSH.rod]||RODS[0],pool=fishPool(spot);
  if(Math.random()<.012+rod.luck*.02)return FISH_BY.pearl;
  if(Math.random()<.06)return FISH_BY.boot;
  let p=pool.filter(f=>!fishIsRareBite(f));if(!p.length)p=pool.slice().sort((a,b)=>a.price-b.price).slice(0,Math.max(1,Math.ceil(pool.length/2)));
  return fishWeighted(p,spot,rod);
}
function fishPickRare(spot){   // what a Rare bite lands: the best fish this water holds at your level
  const rod=RODS[FSH.rod]||RODS[0],pool=fishPool(spot);
  let p=pool.filter(fishIsRareBite);if(!p.length)p=pool.slice().sort((a,b)=>b.price-a.price).slice(0,Math.max(1,Math.ceil(pool.length/2)));
  return fishWeighted(p,spot,rod);
}
/* ---- catch feedback: haptics (Capacitor native / Android web vibrate), screen flash, splash particles, sound ---- */
let FISH_HAP;
function fishHaptics(){if(FISH_HAP!==undefined)return FISH_HAP;FISH_HAP=null;try{const C=window.Capacitor;if(C&&C.isNativePlatform&&C.isNativePlatform()&&C.registerPlugin)FISH_HAP=C.registerPlugin('Haptics');}catch(e){}return FISH_HAP;}
function hapticCatch(rar){
  try{const H=fishHaptics();
    if(H){if(rar>=2){H.notification({type:'SUCCESS'});setTimeout(()=>{try{H.impact({style:'HEAVY'});}catch(e){}},170);if(rar>=4)setTimeout(()=>{try{H.impact({style:'HEAVY'});}catch(e){}},340);}
      else H.impact({style:rar>=1?'MEDIUM':'LIGHT'});return;}
    if(navigator.vibrate)navigator.vibrate(rar>=4?[60,50,60,50,160]:rar>=2?[50,40,100]:rar>=1?[36]:[22]);   // iOS Safari has no vibrate: the flash / splash / sound still play
  }catch(e){}
}
/* ---- hero pose + rod geometry (works for all four facings) ---- */
const FISH_DIRV={r:[1,0],l:[-1,0],u:[0,-1],d:[0,1]};
const fishHandRel=dir=>dir==='r'?[9,-13]:dir==='l'?[-9,-13]:dir==='u'?[8,-15]:[-8,-12];
function fishPose(){   // {ox,oy: body offset in px, bend 0..1, lift: extra rod-tip raise, lean: body tilt (rad, + = to the right), step: leg frame while shifting feet}
  const F=FISH,o={ox:0,oy:0,bend:0,lift:0,jit:0,lean:0,step:0};if(!F.on)return o;
  const v=FISH_DIRV[P.dir]||[0,1],C=FISH_CFG,side=v[0]!==0;
  const breath=-(.5+.5*Math.sin(gtime*2.3))*1.1;   // relaxed breathing bob (about 1px)
  if(F.ph==='cast'){const k=F.t/C.cast;o.ox=v[0]*(k<.2?-2*k/.2:-2+4*Math.min(1,(k-.2)/.3))*(k<.5?1:Math.max(0,1-(k-.5)/.3));o.bend=k<.45?.5*Math.sin(Math.min(1,k/.45)*Math.PI):0;
    o.lean=side?v[0]*(k<.2?-.05*k/.2:-.05+.1*Math.min(1,(k-.2)/.3))*(k<.5?1:Math.max(0,1-(k-.5)/.3)):0;}
  else if(F.ph==='rare'){o.bend=.6+.15*Math.sin(gtime*32);o.oy=-Math.abs(Math.sin(gtime*13))*2.2;o.jit=Math.sin(gtime*41)*1.4;o.lift=Math.sin(gtime*9)*2;
    o.ox+=v[0]*1.5;o.oy+=v[1]*1.5;o.lean=side?v[0]*.06:0;}
  else{o.bend=.14+.05*Math.sin(gtime*1.7);o.oy=breath;
    if(F.fid&&F.fid.t<F.fid.dur){const k=F.fid.t/F.fid.dur,e=Math.sin(k*Math.PI);o.lift=5*e;o.oy+=-1*e;o.ox=v[0]*e*.8;}
    if(F.sh&&F.sh.t<F.sh.dur){const k=F.sh.t/F.sh.dur,e=Math.sin(k*Math.PI);   // occasional weight shift / small step along the bank
      o.ox+=(side?0:F.sh.d*2.2*e);o.oy+=(side?F.sh.d*1.6*e:0);o.lean+=side?-v[0]*.03*e:0;if(F.sh.step)o.step=k<.5?1:2;}
    if(F.yank>0){const k=1-F.yank/.55,e=Math.sin(Math.min(1,k*1.6)*Math.PI)*(1-k*.4);o.lift=12*e;o.bend=Math.max(o.bend,.75*e);   // pull back on the reel / catch
      o.ox+=-v[0]*3.5*e;o.oy+=1.2*e-v[1]*2.6*e;o.lean+=side?-v[0]*.09*e:0;}}
  return o;
}
function fishRodGeom(bobX,bobY){   // screen-space hand, tip (with the swing / bend applied) for the current frame
  const F=FISH,C=FISH_CFG,v=FISH_DIRV[P.dir]||[0,1],po=fishPose(),hr=fishHandRel(P.dir);
  const hand={x:P.x-cam.x+hr[0]+po.ox,y:P.y-cam.y+hr[1]+po.oy};
  const L=P.dir==='u'?[3,-20]:P.dir==='d'?[5,-14]:[v[0]*17,-13],Bk=P.dir==='u'?[-2,-8]:P.dir==='d'?[-4,-22]:[-v[0]*12,-25];
  let tx=L[0],ty=L[1];
  if(F.ph==='cast'){const k=F.t/C.cast,e=t=>t*t*(3-2*t);
    if(k<.2){const u=e(k/.2);tx=lerp(L[0],Bk[0],u);ty=lerp(L[1],Bk[1],u);}
    else if(k<.5){const u=e((k-.2)/.3);tx=lerp(Bk[0],L[0],u);ty=lerp(Bk[1],L[1],u)+Math.sin(u*Math.PI)*-3;}}
  else{ty+=Math.sin(gtime*1.7)*1.3;}
  ty-=po.lift;tx+=po.jit;
  return {hand,tip:{x:hand.x+tx,y:hand.y+ty},bend:po.bend,po};
}
const FISH_TINT=new Map();
function fishTinted(col){let c=FISH_TINT.get(col);if(!c){c=makeSprite(16,16,g=>{g.drawImage(SP.fishIcon,0,0);g.globalCompositeOperation='source-atop';g.globalAlpha=.5;g.fillStyle=col;g.fillRect(0,0,16,16);});FISH_TINT.set(col,c);}return c;}
function fishFeedback(f,rare){
  let rar=f.junk?(f.id==='pearl'?2:0):(f.rar|0);const col=f.junk?f.col:FISH_RARITY[rar].col;if(rare)rar=Math.max(rar,2);const big=rar>=2,F=FISH,spot=F.spot;   // a Rare bite always gets the golden sparkles
  hapticCatch(rar);
  sfx(big?'catchrare':'catch');
  F.flash=null;F.yank=.55;
  if(spot){const c=spotCenter(spot),hr=fishHandRel(P.dir);
    // the fish pops out of the water in a small arc to the hero's hands
    F.fx.push({fish:true,big,col,sx:c.x,sy:c.y,ex:P.x+hr[0],ey:P.y+hr[1]-4,t:0,life:.85,spin:R(-.6,.6)});
    F.fx.push({ring:true,x:c.x,y:c.y,t:0,life:.6,col:'#dff4ff'});
    for(let i=0;i<7;i++){const a=-Math.PI/2+(Math.random()-.5)*1.8,sp=R(40,95);F.fx.push({x:c.x,y:c.y,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,t:0,life:R(.35,.6),col:i%3===0?'#ffffff':'#bfe6ff',sz:2});}
    if(big)for(let i=0;i<8;i++){const a=R(0,6.283),sp=R(20,55);F.fx.push({spark:true,x:c.x,y:c.y-6,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-20,t:0,life:R(.4,.7),col:i%2?'#ffd23f':'#fff3a0',sz:2});}
    F.fx.push({txt:'+'+f.n,x:P.x,y:P.y-46,t:0,life:1.9,d:.45,col});}
}
function fishAward(f,rare){
  FSH.fish[f.id]=Math.min(99,(FSH.fish[f.id]|0)+1);
  if(FISH.on){FISH.session++;FISH.log.unshift({n:f.n,col:f.junk?f.col:FISH_RARITY[f.rar|0].col,rare:!!rare});if(FISH.log.length>3)FISH.log.pop();fishFeedback(f,rare);}
  if(f.junk){toast('You hooked '+(f.id==='pearl'?'a '+f.n+'!':'an '+f.n+'...'),2.2,f.col);return;}
  FSH.caught++;ACH.s.fish=(ACH.s.fish|0)+1;
  addFishXp(f.xp);
  if(Math.random()<.3+.12*f.tier){addMat('fscale',1);toast('+1 '+MATS.fscale.n,1.8,MATS.fscale.col);}
  questEvent('fish',f.id);
  if(!B)saveGame('fish');
}
function updateFishing(dt){
  const rod=RODS[FSH.rod]||RODS[0],spot=FISH.spot,F=FISH,C=FISH_CFG;
  const act=F.tap||hit('Space','KeyE','Enter','KeyJ');F.tap=false;
  if(!spot||B||state!=='play'){endFishing();return;}
  if(hit('Escape')){endFishing('You reel in.');return;}
  const mv=moveInput();if(mv[2]>.3){endFishing('You stop fishing.');return;}
  P.moving=false;P.anim=0;F.t+=dt;
  for(const q of F.fx){q.t+=dt;if(!q.ring&&!q.txt&&!q.fish){q.x+=q.vx*dt;q.y+=q.vy*dt;q.vy+=(q.spark?60:420)*dt;}}F.fx=F.fx.filter(q=>q.t<q.life);
  if(F.yank>0)F.yank=Math.max(0,F.yank-dt);
  if(F.ph==='on'){if(!F.sh)F.sh={t:99,dur:1.2,nx:R(6,10),d:1,step:false};F.sh.nx-=dt;if(F.sh.t<F.sh.dur)F.sh.t+=dt;if(F.sh.nx<=0){F.sh.t=0;F.sh.step=Math.random()<.4;F.sh.dur=F.sh.step?.6:R(1.1,1.6);F.sh.d=-F.sh.d;F.sh.nx=R(7,12);}
    if(!F.fid)F.fid={t:99,dur:.9,nx:R(3,6)};F.fid.nx-=dt;if(F.fid.t<F.fid.dur)F.fid.t+=dt;if(F.fid.nx<=0){F.fid.t=0;F.fid.dur=R(.7,1.1);F.fid.nx=R(5,9);}}
  if(F.flash){F.flash.t+=dt;if(F.flash.t>=F.flash.dur)F.flash=null;}
  const gap=()=>R(C.catch[0],C.catch[1])*rod.waitMul,rareGap=()=>R(C.rare[0],C.rare[1])/(1+rod.luck);
  switch(F.ph){
    case 'cast':if(F.t>=C.cast){F.ph='on';F.t=0;F.next=gap();F.rare=rareGap();sfx('talk');}break;
    case 'on':
      F.next-=dt;F.rare-=dt;
      if(F.next<=0){fishAward(fishPickAuto(spot),false);F.next=gap();}
      if(F.rare<=0){F.ph='rare';F.t=0;F.win=rod.bite;F.pick=fishPickRare(spot);sfx('warn');try{navigator.vibrate&&navigator.vibrate([18,50,18]);}catch(e){}}
      break;
    case 'rare':
      if(act&&F.t>.12){const f=F.pick;F.ph='on';F.t=0;F.rare=rareGap();F.next=Math.max(F.next,R(C.afterRare[0],C.afterRare[1]));fishAward(f,true);}
      else if(F.t>=F.win){F.ph='on';F.t=0;F.rare=rareGap();F.next=Math.max(F.next,R(C.afterRare[0],C.afterRare[1]));toast('It got away...',1.8,'#ffb0a0');sfx('clang');}
      break;
  }
}
/* tap while fishing (touch/mouse): REEL IN ends it, anything else answers a Rare bite */
function fishTap(p){
  if(!FISH.on||state!=='play'||B||DLG)return false;
  if(FISH.stopR&&inRect(p,FISH.stopR)){endFishing('You reel in.');return true;}
  FISH.tap=true;return true;
}
/* ---- drawing ---- */
function drawFishSpot(f){
  const c=spotCenter(f),sx=Math.round(c.x-cam.x),sy=Math.round(c.y-cam.y);
  if(sx<-70||sx>VW+70||sy<-70||sy>VH+70)return;
  const zn=zoneOfPx(c.y);if(zn!==zoneOfPx(P.y))return;
  const w=f.pond?f.pond.w*TS*.5:TS*.5;
  ctx.save();
  for(let i=0;i<3;i++){const k=(gtime*.55+i/3)%1;ctx.globalAlpha=(1-k)*.75;ctx.strokeStyle=i%2?'#d8f0ff':'#ffffff';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(sx,sy,6+k*(w*.9),(6+k*(w*.9))*.5,0,0,6.283);ctx.stroke();}
  ctx.globalAlpha=.55+.4*Math.sin(gtime*5+f.tx);ctx.fillStyle='#fff';ctx.fillRect(sx-9+Math.round(Math.sin(gtime*1.7)*8),sy-3,2,2);ctx.fillRect(sx+6-Math.round(Math.cos(gtime*1.3)*8),sy+3,2,2);
  ctx.restore();
  const d=spotDist(f);
  if(!FISH.on&&d<FISH_REACH+34&&!B&&!DLG){
    const locked=fishLv()<f.lv,by=sy-36+Math.round(Math.sin(gtime*3)*2);
    draw(SP.rodIcon,sx-16,by-26,2);
    txt(locked?'FISH Lv '+f.lv:(FSH.rod<0?'needs rod':(TOUCH?'TAP':'E')),sx,by+12,{size:10,align:'center',col:locked||FSH.rod<0?'#ff9a9a':'#7df9ff',lw:3});
  }
}
function drawFishingWorld(){
  const F=FISH;if(!F.on||!F.spot)return;
  const c=spotCenter(F.spot);
  let bx=c.x-cam.x,by=c.y-cam.y;
  const G=fishRodGeom(),hand=G.hand,tip=G.tip;
  if(F.ph==='cast'){const k=clamp((F.t/FISH_CFG.cast-.42)/.58,0,1);bx=lerp(tip.x,bx,k);by=lerp(tip.y,by,k)-Math.sin(k*Math.PI)*34;if(k<=0){bx=tip.x;by=tip.y+2;}}
  else by+=F.ph==='rare'?Math.abs(Math.sin(gtime*18))*5:Math.sin(gtime*1.8)*1.2;
  const inWater=!(F.ph==='cast'&&F.t/FISH_CFG.cast<.95);
  ctx.save();
  // rod: a curve that bends toward the water (more when something bites / on the yank)
  const bendPx=G.bend*9,mx=(hand.x+tip.x)/2,my=(hand.y+tip.y)/2+bendPx,ex=tip.x,ey=tip.y+bendPx*.55;
  ctx.lineCap='round';
  ctx.strokeStyle='#4a2c10';ctx.lineWidth=4;ctx.beginPath();ctx.moveTo(hand.x,hand.y);ctx.quadraticCurveTo(mx,my,ex,ey);ctx.stroke();
  ctx.strokeStyle='#d8a060';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(hand.x,hand.y);ctx.quadraticCurveTo(mx,my,ex,ey);ctx.stroke();
  ctx.fillStyle='#8a6a3a';ctx.fillRect(Math.round(hand.x-2),Math.round(hand.y-2),4,4);   // grip / reel
  // line + ripples + bobber
  const taut=F.ph==='rare'?.2:1;
  ctx.strokeStyle='rgba(235,240,255,.85)';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(ex,ey);ctx.quadraticCurveTo((ex+bx)/2,Math.max(ey,by)+10*taut,bx,by);ctx.stroke();
  if(inWater){
    for(let i=0;i<2;i++){const k=((gtime*.7)+i*.5)%1;ctx.globalAlpha=(1-k)*.5;ctx.strokeStyle='#dff4ff';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(bx,by+4,3+k*(F.ph==='rare'?20:11),(3+k*(F.ph==='rare'?20:11))*.42,0,0,6.283);ctx.stroke();}ctx.globalAlpha=1;
    if(F.ph==='rare'){for(let i=0;i<2;i++){const k=(gtime*2+i*.5)%1;ctx.globalAlpha=1-k;ctx.strokeStyle='#ffd23f';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(bx,by+3,4+k*16,(4+k*16)*.45,0,0,6.283);ctx.stroke();}ctx.globalAlpha=1;}}
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(bx,by,4,0,6.283);ctx.fill();ctx.fillStyle='#e2403a';ctx.beginPath();ctx.arc(bx,by-1.5,4,Math.PI,0);ctx.fill();ctx.fillStyle='#14182c';ctx.fillRect(bx-4,by-1,8,1);
  // catch: splash ring + droplets, the fish arcing out of the water into the hero's hands, sparkles (rare), floating "+Name"
  for(const q of F.fx){const k=q.t/q.life;
    if(q.ring){ctx.globalAlpha=(1-k)*.8;ctx.strokeStyle=q.col;ctx.lineWidth=2;const r=4+k*18;ctx.beginPath();ctx.ellipse(q.x-cam.x,q.y-cam.y+4,r,r*.45,0,0,6.283);ctx.stroke();ctx.globalAlpha=1;}
    else if(q.fish){const e=k<.5?1-(1-k*2)*(1-k*2):1,kk=clamp(k,0,1),fx=lerp(q.sx,q.ex,kk*kk*(3-2*kk))-cam.x,fy=lerp(q.sy,q.ey,kk)-cam.y-Math.sin(kk*Math.PI)*36,sc=lerp(2,1.2,kk);
      ctx.save();ctx.globalAlpha=kk<.82?1:1-(kk-.82)/.18;ctx.translate(fx,fy);ctx.rotate(q.spin*Math.sin(kk*Math.PI*2)+(kk-.5)*.9);ctx.scale(sc*(c.x>=P.x?-1:1),sc);ctx.drawImage(fishTinted(q.col),-8,-8);ctx.restore();
      if(q.big){ctx.globalAlpha=kk<.9?1:1-(kk-.9)/.1;for(let i=0;i<6;i++){const a=i*1.047+q.t*5,r=9+4*Math.sin(q.t*9+i*2),sx=fx+Math.cos(a)*r,sy=fy+Math.sin(a)*r*.8,tw=.5+.5*Math.sin(q.t*14+i*1.7);ctx.fillStyle=i%2?'#ffd23f':'#fff3a0';ctx.fillRect(Math.round(sx)-1,Math.round(sy),3,1);ctx.fillRect(Math.round(sx),Math.round(sy)-1,1,3);if(tw>.6)ctx.fillRect(Math.round(sx),Math.round(sy),1,1);}ctx.globalAlpha=1;}}
    else if(q.txt){const kk=(q.t-q.d)/(q.life-q.d);if(kk>=0)txt(q.txt,q.x-cam.x,q.y-cam.y-kk*18,{size:10,align:'center',col:q.col,lw:4,alpha:kk<.7?1:1-(kk-.7)/.3});}
    else{ctx.globalAlpha=1-k*k;ctx.fillStyle=q.col;ctx.fillRect(Math.round(q.x-cam.x),Math.round(q.y-cam.y),q.sz,q.sz);ctx.globalAlpha=1;}}
  ctx.restore();
  if(F.ph==='rare')txt('!',bx,by-16,{size:30,align:'center',col:'#ffd23f',lw:5});
}
function drawFishingHud(){
  const F=FISH;if(!F.on||state!=='play'||B||DLG)return;
  const w=Math.min(300,VW-SL-SR-24),x=Math.round(SL+(VW-SL-SR-w)/2),y=VW>=700?ST+6:Math.round(Math.max(ST+120,VH*.17)),spot=F.spot;   // wide (landscape) screens: up in the top middle so the water + angler stay visible
  const rod=RODS[FSH.rod]||RODS[0],act=TOUCH?'TAP':'SPACE';
  const h=F.ph==='rare'?78:84;
  panel(x,y,w,h,{border:F.ph==='rare'?'#ffd23f':'#7dd0ff'});
  txt(spot.name+'   Fishing Lv '+fishLv(),x+w/2,y+16,{size:10,align:'center',col:'#9ad0ff',lw:2});
  if(F.ph==='cast')txt('Casting...',x+w/2,y+44,{size:14,align:'center',col:'#fff'});
  else if(F.ph==='rare'){
    const fl=Math.floor(gtime*6)%2,fr=1-F.t/F.win;
    txt('RARE BITE!  '+act+' NOW!',x+w/2,y+42,{size:15,align:'center',col:fl?'#ffd23f':'#fff',lw:4});
    bar(x+14,y+54,w-28,6,fr,'#ffb43a');txt(Math.ceil(F.win-F.t)+'s',x+w/2,y+72,{size:9,align:'center',col:'#ffe9a0',lw:2});
  } else {
    txt('Relaxing by the water'+'.'.repeat(1+Math.floor(gtime*1.5)%3),x+w/2,y+34,{size:11,align:'center',col:'#cfe3ff',lw:3});
    if(F.log.length){F.log.forEach((e,i)=>txt((e.rare?'* ':'')+e.n,x+10,y+49+i*11,{size:8,col:e.col,lw:2,alpha:1-i*.25}));}
    else txt('A fish bites every few seconds',x+10,y+49,{size:8,col:'#8a96b8',bold:false,lw:2});
    txt('caught '+F.session,x+w-8,y+49,{size:8,align:'right',col:'#9dffb0',lw:2});
  }
  // REEL IN button
  F.stopR={x:x+w-96,y:y+h+6,w:96,h:26};panel(F.stopR.x,F.stopR.y,96,26,{fill:'#3a1c1c'});txt(TOUCH?'REEL IN':'ESC: reel in',F.stopR.x+48,F.stopR.y+18,{size:10,align:'center',lw:2});
}
