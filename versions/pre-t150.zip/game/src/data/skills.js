/* =====================================================================
   SKILL TREE DATA: stat nodes + four spell schools. One skill point is earned per level (points = level-1 - ranks bought).
   node: id, name, max, per-rank cost, level gate per rank, effect text
   ===================================================================== */
const SKILL_NODES=[
  {id:'hp',    g:'STATS',  name:'VITALITY',   max:5,cost:1,lvl:r=>1+r,   col:'#7dffa0',eff:'+12 max HP per rank'},
  {id:'gauge', g:'STATS',  name:'ARCANE FLOW',max:5,cost:1,lvl:r=>1+r,   col:'#7df9ff',eff:'+6% faster card dealing per rank'},
  {id:'crit',  g:'STATS',  name:'KEEN EYE',   max:5,cost:1,lvl:r=>2+r,   col:'#ff8a8a',eff:'+2% crit chance per rank'},
  {id:'slots', g:'STATS',  name:'DEEP POCKETS',max:2,cost:2,lvl:r=>3+r*4,col:'#ffe14d',eff:'+10% faster card dealing per rank'},
  {id:'frost', g:'SCHOOL', name:'FROST',      max:3,cost:1,lvl:r=>1+r*3,col:'#7fd8ff',eff:'Frost spells +7% dmg per rank. Rank 3: ice chills foes'},
  {id:'fire',  g:'SCHOOL', name:'FIRE',       max:3,cost:1,lvl:r=>1+r*3,col:'#ff8a3d',eff:'Fire spells +7% dmg per rank. Rank 3: fire ignites'},
  {id:'shadow',g:'SCHOOL', name:'SHADOW',     max:3,cost:1,lvl:r=>1+r*3,col:'#b69cff',eff:'Shadow spells +7% dmg per rank. Rank 3: longer Shadow Step'},
  {id:'holy',  g:'SCHOOL', name:'HOLY',       max:3,cost:1,lvl:r=>1+r*3,col:'#ffe9a0',eff:'Holy spells +7% dmg per rank. Rank 3: heal +10%, ward +1s'},
];
const SKILL={};SKILL_NODES.forEach(n=>{SKILL[n.id]=n;});
const SCHOOLS=['frost','fire','shadow','holy'];
/* which school each spell card belongs to (cards not listed are school-less) */
const CARD_SCHOOL={frostbolt:'frost',frostburst:'frost',chain:'frost',timestop:'frost',
  fire:'fire',meteor:'fire',dragonfire:'fire',quake:'fire',
  shadow:'shadow',crimsonbolt:'shadow',crimsonburst:'shadow',curse:'shadow',drain:'shadow',decoy:'shadow',wolf:'shadow',poison:'shadow',
  sword:'holy',lance:'holy',shield:'holy',heal:'holy',ward:'holy',reflect:'holy',haste:'holy'};
