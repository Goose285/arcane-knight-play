/* =====================================================================
   LIGHT SOURCES (sold at Brum's workbench): the light slot widens the glow around you at night and in the crypt.
   base glow without one: 104px (116px in the crypt).
   ===================================================================== */
const LIGHTS=[
  {id:'torch',   name:'TORCH',            price:60,   r:150, a:.95, c:'255,165,70',  gl:.26, col:'#ff9a3d', desc:'Warm flame, +45% light radius'},
  {id:'lantern', name:'LANTERN',          price:180,  r:195, a:.97, c:'255,222,150', gl:.22, col:'#ffd98a', desc:'Steady glow, +90% light radius'},
  {id:'enchant', name:'ENCHANTED LANTERN',price:480,  r:250, a:.98, c:'165,220,255', gl:.24, col:'#9fd8ff', desc:'Spirit-lit, +140% light radius'},
  {id:'sunstone',name:'SUNSTONE',         price:1100, r:320, a:1,   c:'255,236,160', gl:.3,  col:'#ffe46b', desc:'A sliver of noon, +210% light radius'},
];
const LIGHT_BY={};LIGHTS.forEach(l=>{LIGHT_BY[l.id]=l;});
