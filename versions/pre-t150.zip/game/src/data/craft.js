/* =====================================================================
   CRAFTING DATA: monster parts, gear recipes, card upgrade costs. Original names only.
   MAT_DROP maps an enemy type to the part it can drop; later regions just add entries.
   ===================================================================== */
const MATS={
  gel:  {n:'Slime Gel',   col:'#8fe36a'}, bone:{n:'Knight Bone',col:'#e8e0c8'}, hide:{n:'Goblin Hide',col:'#b98a52'},
  wing: {n:'Bat Wing',    col:'#a08ad0'}, ecto:{n:'Ectoplasm', col:'#9ad0ff'}, scale:{n:'Ember Scale',col:'#ff7a3a'},
  dust: {n:'Lich Dust',   col:'#9dffb0'}, shard:{n:'Arcane Shard',col:'#7df9ff'},
  fur:{n:'Frost Pelt',col:'#bfe6ff'},moss:{n:'Bog Moss',col:'#9ad03a'},sandg:{n:'Dune Glass',col:'#f0d080'},core:{n:'Rime Core',col:'#7fd8ff'},heart:{n:'Bog Heart',col:'#7ac060'},relic:{n:'Sun Relic',col:'#ffb02e'},
};
const MAT_DROP={slime:'gel',knight:'bone',goblin:'hide',bat:'wing',wraith:'ecto',dragon:'scale',lich:'dust',wolf:'fur',yeti:'fur',toad:'moss',witch:'moss',scorpion:'sandg',mummy:'sandg',rimegar:'core',mossback:'heart',colossus:'relic'};
/* gear recipes: slot + fixed rarity, crafted at the player's level (+1 per 'plus') */
const RECIPES=[
  {id:'r_bone', name:'Marrow Saber',   slot:'weapon',rar:'rare',     mats:{bone:6,gel:3},gold:120},
  {id:'r_hide', name:'Stitched Hide Coat',slot:'armor',rar:'rare',   mats:{hide:6,gel:3},gold:120},
  {id:'r_wing', name:'Nightwing Loop', slot:'ring',  rar:'rare',     mats:{wing:5,shard:2},gold:140},
  {id:'r_ecto', name:'Veilweave Robe', slot:'armor', rar:'epic',     mats:{ecto:6,wing:3,shard:3},gold:320},
  {id:'r_ghost',name:'Banshee Edge',   slot:'weapon',rar:'epic',     mats:{ecto:7,bone:6,shard:3},gold:360},
  {id:'r_scale',name:'Emberscale Plate',slot:'armor',rar:'epic',     mats:{scale:3,hide:6,shard:4},gold:420},
  {id:'r_dust', name:'Hollow Crown Ring',slot:'ring',rar:'legendary',mats:{dust:4,ecto:6,shard:6},gold:900},
  {id:'r_king', name:"Hollow King's Edge",slot:'weapon',rar:'legendary',mats:{dust:5,scale:3,shard:8},gold:1200},
  {id:'r_pelt', name:'Rimeguard Mantle',slot:'armor',rar:'epic',     mats:{fur:6,core:2,shard:4},gold:480},
  {id:'r_bog',  name:'Mirewalker Band', slot:'ring', rar:'epic',     mats:{moss:6,heart:2,shard:4},gold:520},
  {id:'r_glass',name:'Sunglass Saber',  slot:'weapon',rar:'epic',    mats:{sandg:6,relic:2,shard:4},gold:560},
  {id:'r_tri',  name:'Aegis of Three Realms',slot:'armor',rar:'legendary',mats:{core:2,heart:2,relic:2,shard:10},gold:1500},
];
const UPG_MAX=3;
/* card upgrade n -> n+1 costs: shards + the part matching the card's school, plus gold by rarity */
const UPG_MATS={frost:'wing',fire:'scale',shadow:'ecto',holy:'bone'};
const upgCost=(id,lvl)=>{const c=CARD[id],ri=RAR_ORDER.indexOf(c.rar),sch=CARD_SCHOOL[id];
  const m={shard:2+lvl*2+ri};if(sch&&UPG_MATS[sch]&&lvl>0)m[UPG_MATS[sch]]=lvl+ri;else if(lvl>0)m.bone=lvl+ri;
  return {mats:m,gold:Math.round(RAR[c.rar].price*.35*(lvl+1))+30*lvl};};
