/* =====================================================================
   ELITE AFFIXES + BOSS RUSH TABLES (data only)
   An elite is an ordinary monster (level 4+) rolled with one or two affixes: more health and damage, double rewards.
   ===================================================================== */
const AFFIX={
  shielded:{n:'Shielded', col:'#7fd8ff',desc:'Wears a barrier worth 40% of its health that soaks damage first'},
  vampiric:{n:'Vampiric', col:'#ff5a7a',desc:'Heals itself for every point of damage it deals to you'},
  swift:   {n:'Swift',    col:'#ffe14d',desc:'Attacks and moves 30% faster'},
  thorned: {n:'Thorned',  col:'#9bd84a',desc:'Reflects a small part of the damage you deal back at you'},
  volatile:{n:'Volatile', col:'#ff9a3d',desc:'Bursts in a telegraphed blast when it dies'},
  frenzied:{n:'Frenzied', col:'#d49bff',desc:'Goes berserk below 40% health: attacks 50% faster'},
};
const AFFIX_IDS=Object.keys(AFFIX);
const ELITE={chance:.14,minLv:4,hp:1.5,hpExtra:.25,dm:1.2,reward:2.2,thorns:.07,leech:1.0,volatileDmg:34,volatileR:72};
/* boss rush: five bosses in a loop, each lap +3 levels and (from lap 2) elite affixes. [type, level] */
const RUSH_ORDER=[['dragon',12],['rimegar',14],['lich',16],['mossback',17],['colossus',20]];
const RUSH_CFG={prep:3.2,healPct:.35,xpMul:.5,goldMul:.5,keep:10};
