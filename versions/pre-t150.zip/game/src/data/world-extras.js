/* =====================================================================
   WORLD EXTRAS (data): Oakvale Chapel footprint, fishing spots, monster spawners (runed braziers). Placed by map/places.js.
   ===================================================================== */
// the chapel replaces the north-east cottage of Oakvale: roof rows y0..y0+1, back wall + stained glass, nave with pews, door at x=21
const CHAPEL={x0:18,x1:24,y0:29,y1:36,door:21,cross:{x:21,y:29},name:'OAKVALE CHAPEL'};
const inChapel=(tx,ty)=>tx>=CHAPEL.x0&&tx<=CHAPEL.x1&&ty>=CHAPEL.y0&&ty<=CHAPEL.y1;
/* fishing spots sit on water tiles. lv = fishing level needed, tier = which fish live there, bank = tile to stand on (kept walkable) */
const FISH_SPOTS=[
  {id:'oak1', name:'Oakvale River',    tx:25,ty:44,lv:1,tier:0,bank:[24,44]},
  {id:'oak2', name:'Oakvale River',    tx:25,ty:41,lv:1,tier:0,bank:[24,41]},
  {id:'mead', name:'Greenmeadow River',tx:25,ty:22,lv:4,tier:1,bank:[24,22]},
  {id:'wood', name:'Whisperwood Pond', tx:46,ty:36,lv:8,tier:1,bank:[45,36],pond:{x:46,y:36,w:2,h:2}},
  {id:'bog',  name:'Mirewood Pool',    tx:21,ty:ZONE_Y0.swamp+24, lv:15,tier:2,bank:[21,ZONE_Y0.swamp+23],pond:{x:20,y:ZONE_Y0.swamp+24,w:3,h:2}},
  {id:'oasis',name:'Sundered Oasis',   tx:45,ty:ZONE_Y0.desert+24,lv:30,tier:3,bank:[45,ZONE_Y0.desert+23],pond:{x:44,y:ZONE_Y0.desert+24,w:3,h:2}},
];
/* region names drawn on the World Map (tile of the label; shifted with the world when it grows) */
const REGION_LABELS=[{name:'OAKVALE',tx:13,ty:40},{name:'GREENMEADOW',tx:8,ty:22},{name:'WHISPERWOOD',tx:44,ty:27},{name:'CASTLE DRACORYN',tx:32,ty:6}];
/* monster spawners: a caged, runed brazier that keeps summoning its themed monsters (up to cap) while you are near. */
const SPW=[];
const SPAWNER_DEFS=[
  {id:'sp_forest1',tx:53,ty:27, theme:'warren',name:'GOBLIN WARREN BRAZIER', mobs:['goblin','goblin','slime'],cap:3,every:7,hp:240,xp:150,gold:[70,110],card:.35,mats:2},
  {id:'sp_forest2',tx:55,ty:41, theme:'bone',  name:'BONEFIRE CAGE',         mobs:['knight','slime'],         cap:3,every:8,hp:260,xp:160,gold:[70,110],card:.35,mats:2},
  {id:'sp_swamp1', tx:46,ty:ZONE_Y0.swamp+19, theme:'bog',   name:'BOG HEX BRAZIER',  mobs:['toad','toad','witch'],cap:3,every:8,hp:340,xp:260,gold:[110,160],card:.4,mats:3},
  {id:'sp_swamp2', tx:18,ty:ZONE_Y0.swamp+11, theme:'bog',   name:'MIRE-RUNE CAGE',   mobs:['witch','toad'],       cap:3,every:8,hp:340,xp:260,gold:[110,160],card:.4,mats:3},
  {id:'sp_desert1',tx:36,ty:ZONE_Y0.desert+25,theme:'sun',   name:'SUN-RUNE BRAZIER', mobs:['scorpion','mummy'],   cap:3,every:8,hp:440,xp:340,gold:[150,210],card:.4,mats:3},
  {id:'sp_desert2',tx:44,ty:ZONE_Y0.desert+18,theme:'sun',   name:'DUNE EMBER CAGE',  mobs:['mummy','scorpion','scorpion'],cap:3,every:8,hp:440,xp:340,gold:[150,210],card:.4,mats:3},
  {id:'sp_crypt1', tx:9, ty:72, theme:'grave', name:'GRAVE-FLAME BRAZIER', mobs:['bat','bat','wraith'],      cap:3,every:7,hp:540,xp:420,gold:[190,260],card:.45,mats:4},
  {id:'sp_crypt2', tx:54,ty:72, theme:'grave', name:'HOLLOW KING\'S CAGE', mobs:['wraith','bat'],            cap:3,every:8,hp:540,xp:420,gold:[190,260],card:.45,mats:4},
];
