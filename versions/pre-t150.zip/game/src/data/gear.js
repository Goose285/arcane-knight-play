/* =====================================================================
   GEAR DATA - slots, rarity tiers, name tables, stat rolls. Pure data (no game state).
   stats: shot (shot damage), hp (max HP), def (flat damage reduction), gauge (spell gauge speed, 0.1 = +10%), crit (crit chance, 0.05 = 5%)
   ===================================================================== */
const GEAR_SLOTS=['weapon','armor','ring'];
const GEAR_SLOT_NAME={weapon:'WEAPON',armor:'ARMOR',ring:'RING'};
const GEAR_RAR={
  common:   {n:'COMMON',   col:'#cfd3dc',mult:1.00,aff:0,sell:6},
  uncommon: {n:'UNCOMMON', col:'#5fe38a',mult:1.22,aff:1,sell:14},
  rare:     {n:'RARE',     col:'#5aa8ff',mult:1.48,aff:2,sell:32},
  epic:     {n:'EPIC',     col:'#c77dff',mult:1.80,aff:3,sell:70},
  legendary:{n:'LEGENDARY',col:'#ffb02e',mult:2.30,aff:4,sell:160},
};
const GEAR_RAR_ORDER=['common','uncommon','rare','epic','legendary'];
const GEAR_BASES={
  weapon:['Rusty Blade','Iron Blade','Knight Blade','Runed Blade','Emberfang Edge'],
  armor: ['Padded Vest','Chain Mail','Knight Plate','Arcane Mantle','Dragonscale Armor'],
  ring:  ['Copper Ring','Silver Ring','Gold Ring','Sapphire Ring','Ring of Embers'],
};
const GEAR_BASES_BOSS={weapon:['Crypt Reaver','Lich-Bane Blade'],armor:['Hollow King Plate','Shroud of the Lich'],ring:['Signet of Hollow Kings','Phylactery Band']};
const GEAR_SUFFIX={shot:'of Might',hp:'of Vigor',def:'of Warding',gauge:'of Haste',crit:'of Precision'};
// per-slot primary stat and the pool of extra affixes
const GEAR_PRIMARY={weapon:'shot',armor:'hp',ring:null};
const GEAR_POOL={weapon:['crit','gauge','shot','hp'],armor:['def','hp','gauge','crit'],ring:['shot','hp','def','gauge','crit']};
// value of one roll at item level L and rarity multiplier m
const GEAR_ROLL={
  shot:(L,m)=>Math.max(1,Math.round((1.6+L*.75)*m)),
  hp:(L,m)=>Math.max(3,Math.round((7+L*2.6)*m)),
  def:(L,m)=>Math.max(1,Math.round((.8+L*.3)*m)),
  gauge:(L,m)=>+(.035*m+L*.002).toFixed(3),
  crit:(L,m)=>+(.02*m+L*.0015).toFixed(3),
};
const GEAR_STAT_LABEL={shot:'SHOT',hp:'HP',def:'DEF',gauge:'DEAL',crit:'CRIT'};
// drop odds by enemy level
const gearDropChance=L=>Math.min(.3,.055+L*.0065);
const gearRarityWeights=L=>({common:Math.max(8,56-3.6*L),uncommon:30,rare:7+1.5*L,epic:.8+.45*L,legendary:.05+.13*L});
