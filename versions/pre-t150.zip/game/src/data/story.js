/* =====================================================================
   MAIN QUESTLINE: "The Hollow Crown". Six chapters, portrait cutscenes, choices. Data only (logic: player/story.js).
   Step: {w:speaker, t:text, if?:(S)=>bool, ch?:[{t:label, do?:effects, then?:[steps]}]}
   Effects (do): {trust:{orin:1}, flag:'x', ending:'warden', reward:'warden'}
   ===================================================================== */
const WHO={orin:{n:'ELDER ORIN',col:'#e8e0c8'},hale:{n:'CAPTAIN HALE',col:'#ff9a9a'},brum:{n:'BRUM THE SMITH',col:'#ffb070'},pip:{n:'PIP',col:'#9be09b'},aldric:{n:'KING ALDRIC',col:'#7dffa0'},narr:{n:'',col:'#cfd0ff'},hero:{n:'HERO',col:'#ffe27a'}};
const CHAPTERS=[
  {id:'c1',name:'Whispers in Oakvale',   hint:'Talk to Elder Orin (reach level 3 or finish "Slime Trouble")'},
  {id:'c2',name:'The Sleepless Guard',   hint:'Talk to the Gate Guard (finish "Goblin Menace" or reach level 5)'},
  {id:'c3',name:'The Voice in the Dark', hint:'Descend into the Crypt of Hollow Kings'},
  {id:'c4',name:'The Hollow Crown',      hint:'Defeat the Lich King'},
  {id:'c5',name:'What Oakvale Remembers',hint:'Return to Elder Orin'},
];
const VILLAGERS={
  orin:{n:'Elder Orin',     perk:'Orin\'s Blessing: +10% XP from every kill'},
  hale:{n:'Captain Hale',   perk:'Hale\'s Drills: +12 maximum health'},
  brum:{n:'Brum the Smith', perk:'Brum\'s Friend Price: workbench gold costs -20%'},
  pip: {n:'Pip',            perk:'Pip\'s Lucky Charm: +25% card drop chance'},
};
const TRUST_NEED=2;
const ENDINGS={
  ember: {n:'The Ember Crown',   col:'#ff9a3d',desc:'You took the crown for yourself. Power hums in your veins - and the village keeps its distance.'},
  warden:{n:'The Warden\'s Oath',col:'#7dffa0',desc:'You returned the crown to Orin to renew the seal. Oakvale sleeps soundly.'},
  free:  {n:'The Shattered Seal',col:'#8fd8ff',desc:'You broke the crown and freed the hollow souls. The Tide must now be faced - but no one is bound any more.'},
};
const CUTS={
c1:[
 {w:'orin',t:'Hero, sit a moment. The slimes were nothing. What troubles me sits at the far end of the Castle Road.'},
 {w:'orin',t:'Seven winters ago King Aldric Vael vanished from Castle Dracoryn. Soon after, the dead began to walk and a dragon took the courtyard.'},
 {w:'orin',t:'Folk say the king turned lich and raised the crypt against us. Folk say many things.',
  ch:[{t:'Tell me the whole legend.',do:{trust:{orin:1},flag:'lore'},then:[{w:'orin',t:'...You listen. Few do. Aldric forged a Hollow Crown, they say, to bind something beneath the castle. Beyond that the old tales run dry.'}]},
      {t:'Keep it short. What do you need?',do:{},then:[{w:'orin',t:'Straight to the point. Very well: no more stories.'}]}]},
 {w:'orin',t:'Speak with the Gate Guard when you can. He has not slept properly in seven winters, and I do not think it is fear that keeps him up.'},
],
c2:[
 {w:'hale',t:'Quiet. The walls listen here... You cleared the goblins. Good. Then you can hear this.'},
 {w:'hale',t:'The night the king vanished I stood this very post. I saw him on the battlements, crowned in green fire. He was not raising the dead, hero.'},
 {w:'hale',t:'He was screaming at them to go back down. I have told no one. They would call me mad, or worse.',
  ch:[{t:'Your secret is safe with me.',do:{trust:{hale:2},flag:'kept'},then:[{w:'hale',t:'Thank you. A weight leaves me. Take my drills to heart - stand firm and you will outlast what is down there.'}]},
      {t:'The village deserves the truth.',do:{trust:{hale:-1,orin:1},flag:'told'},then:[{w:'hale',t:'...Perhaps. But rumours will run before you do. Do not make me regret trusting you.'}]},
      {t:'Why tell a stranger?',do:{trust:{hale:1}},then:[{w:'hale',t:'Because you walked into the courtyard and walked out again. That is more than I have managed in seven years.'}]}]},
 {w:'hale',t:'The crypt stairs are in the meadow, west of here. Listen carefully down there. The dead speak, if you let them.'},
],
c3:[
 {w:'narr',t:'The air in the Crypt of Hollow Kings is cold as old iron. A voice drifts from the dark ahead.'},
 {w:'aldric',t:'Another one comes. Another candle to snuff... Turn back, little knight. The Tide is patient, but I am not.'},
 {w:'aldric',t:'Why do you walk my halls?',
  ch:[{t:'I come to end your curse.',do:{flag:'end'},then:[{w:'aldric',t:'My curse. Yes. That is what it looks like from the stairs.'}]},
      {t:'I come to listen.',do:{flag:'listen',trust:{orin:1}},then:[{w:'aldric',t:'Listen... It has been so long. Then hear this much: the dead do not rise because of me. They rise in spite of me.'}]},
      {t:'I come for the crown.',do:{flag:'greed'},then:[{w:'aldric',t:'Everyone does, in the end. The crown is a weight, not a prize. But try. All of you try.'}]}]},
 {w:'aldric',t:'Come then. Fight me if you must. But know what you are breaking.'},
],
c4:[
 {w:'narr',t:'The Lich King falls. The green fire gutters, and a gentle voice speaks from the cooling crown.'},
 {w:'aldric',t:'Thank you. I could not stop. The crown held me to the seal; the seal held the Ashen Tide beneath the castle.'},
 {w:'aldric',t:'My daughter Sera bonded a dragon to guard the courtyard. Emberfang was only ever keeping the villagers away from the stairs - to keep them from me.', if:S=>true},
 {w:'aldric',t:'You listened to me before. Remember that.',if:S=>!!S.flags.listen},
 {w:'aldric',t:'You came for the crown. Take it, and carry it well - or ill.',if:S=>!!S.flags.greed},
 {w:'aldric',t:'With me gone the seal weakens. The Hollow Crown can renew it, be carried, or be broken. The choice, little knight, is yours.',
  ch:[{t:'Take the crown. It is mine now.',do:{ending:'ember',reward:'ember',trust:{orin:-1,hale:-1,brum:-1,pip:-1}},then:[{w:'aldric',t:'Then wear it... and remember what it cost me.'}]},
      {t:'Return it to Elder Orin to renew the seal.',do:{ending:'warden',reward:'warden',trust:{orin:2,hale:1}},then:[{w:'aldric',t:'A warden, then. Rest, hero. Rest, Sera. Rest, all of you.'}]},
      {t:'Shatter it. No more bound souls.',do:{ending:'free',reward:'free',trust:{brum:1,pip:1}},then:[{w:'aldric',t:'Free... at last. Free. Tell my people I never meant to leave them.'}]}]},
 {w:'narr',t:'The crypt falls quiet. Somewhere above, Elder Orin is waiting for word. (Your choice is recorded in the Chronicle.)'},
],
c5:[
 {w:'orin',t:'You are back, and the bells of Oakvale have not tolled once all night. Whatever you did down there - it held.',if:S=>S.ending!=='ember'},
 {w:'orin',t:'You wear the crown openly. I will not pretend it does not frighten us, hero. But you did stop the dead.',if:S=>S.ending==='ember'},
 {w:'orin',t:'The crown now rests in my keeping. The seal is renewed; Oakvale will remember your oath.',if:S=>S.ending==='warden'},
 {w:'orin',t:'You broke it? ... Then we shall face the Tide together, without a king to bear it for us. Perhaps that is as it should be.',if:S=>S.ending==='free'},
 {w:'hale',t:'I stand my post without a single nightmare. For that alone, I would follow you.',if:S=>S.trust.hale>=TRUST_NEED},
 {w:'hale',t:'Seven winters I kept watch. And you. You never even told me what he said.',if:S=>S.trust.hale<TRUST_NEED},
 {w:'brum',t:'Forge is hot and the village is safe. Come by, friend - I owe you a better price on everything.',if:S=>S.trust.brum>=TRUST_NEED},
 {w:'pip',t:'I told EVERYONE you beat the Lich King! Here, I found this lucky charm for you!',if:S=>S.trust.pip>=TRUST_NEED},
 {w:'orin',t:'Whatever ending you chose, the Realm of Embers is yours to roam. Go on - there is more beyond the pass.'},
 {w:'narr',t:'THE END OF THE HOLLOW CROWN.  (Keep exploring - the Chronicle shows your villagers and perks.)'},
],
};
