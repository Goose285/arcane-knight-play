
/* =====================================================================
   CARD DATA TABLE  -  every spell card is one entry here. To add a card:
   1) add a row to CARDS  2) add CAST[id]=function  3) add an icon in SP.ic (p1)
   fields: id name lab(short label) col pow rar(rarity) desc tgt(needs a target in line of sight)
   ===================================================================== */
const RAR={
  common:   {n:'COMMON',   col:'#cfd3dc',max:4,own:5,price:40},
  uncommon: {n:'UNCOMMON', col:'#5fe38a',max:3,own:4,price:90},
  rare:     {n:'RARE',     col:'#5aa8ff',max:2,own:3,price:200},
  epic:     {n:'EPIC',     col:'#c77dff',max:1,own:2,price:450},
  legendary:{n:'LEGENDARY',col:'#ffb02e',max:1,own:1,price:1500}
};
const RAR_ORDER=['common','uncommon','rare','epic','legendary'];
const DECK_MAX=20,DECK_MIN=10,COMBO_WIN=1.5;
const HEAL_PCT=.22,HEAL_COOL=12,HEAL_MAX_DECK=2;   // Heal: 22% of max HP (was 35%); half as much if cast again within 12s; 1 in the starter deck (was 3), max 2 in any deck
const CARDS=[
  // ---- common: the starter deck ----
  {id:'sword',  name:'SWORD',   melee:true,col:'#6fb7ff',pow:55,rar:'common',desc:'Melee arc'},
  {id:'fire',   name:'FIREBALL',col:'#ff8a3d',pow:45,rar:'common',desc:'Burning shot'},
  {id:'shield', name:'BARRIER', col:'#58d68d',pow:0, rar:'common',desc:'Blocks 1 hit'},
  {id:'heal',   name:'HEAL',    col:'#4be37a',pow:0, rar:'common',desc:'Restore 22% HP (half if recast within 12s)'},
  {id:'lance',  name:'LANCE',   col:'#c9a3ff',pow:75,rar:'common',desc:'Piercing line'},
  // ---- uncommon ----
  {id:'frostbolt',  name:'FROST BOLT',  lab:'FRST BOLT',col:'#7fd8ff',pow:75,rar:'uncommon',tgt:1,desc:'Freeze one foe'},
  {id:'crimsonbolt',name:'CRIMSON BOLT',lab:'CRMS BOLT',col:'#c0243a',pow:65,rar:'uncommon',tgt:1,desc:'Drain one foe'},
  {id:'chain',  name:'CHAIN LIGHTNING',lab:'CHN LTNG',col:'#ffe14d',pow:70,rar:'uncommon',tgt:1,desc:'Jumps to 4 foes, -25% per jump'},
  {id:'poison', name:'POISON CLOUD',lab:'POISON',   col:'#8fd03a',pow:14,rar:'uncommon',tgt:1,desc:'Toxic cloud: dmg/0.5s for 5s'},
  {id:'haste',  name:'HASTE',   col:'#ffd0e8',pow:0, rar:'uncommon',desc:'+45% move, +80% fire rate 5s'},
  {id:'decoy',  name:'DECOY',   col:'#b8a98f',pow:0, rar:'uncommon',desc:'Fake knight draws aggro 5s'},
  // ---- rare ----
  {id:'frostburst',  name:'FROST BURST',  lab:'FRST BRST',col:'#5ab8f0',pow:100,rar:'rare',tgt:1,desc:'Freeze an area'},
  {id:'crimsonburst',name:'CRIMSON BURST',lab:'CRMS BRST',col:'#a01830',pow:85, rar:'rare',tgt:1,desc:'Drain an area'},
  {id:'quake',  name:'EARTHQUAKE',melee:true,lab:'QUAKE',    col:'#b98a52',pow:55,rar:'rare',desc:'Shockwave around you, stun 1.2s'},
  {id:'shadow', name:'SHADOW STEP',melee:true,lab:'SHDW STEP',col:'#8a6bd6',pow:0, rar:'rare',desc:'Dash through walls-safe, i-frames'},
  {id:'ward',   name:'HOLY WARD',lab:'HOLY WARD', col:'#ffe9a0',pow:0, rar:'rare',desc:'Dome blocks shots 3s'},
  {id:'reflect',name:'REFLECT',  lab:'REFLECT',   col:'#bfe8ff',pow:0, rar:'rare',desc:'Bounce shots back 1.5s'},
  {id:'curse',  name:'CURSE',    lab:'CURSE',     col:'#a85fd0',pow:0, rar:'rare',tgt:1,desc:'Target takes 2x damage 6s'},
  {id:'wolf',   name:'SUMMON WOLF',lab:'WOLF',    col:'#9fb6d8',pow:30,rar:'rare',desc:'Spirit wolf bites foes 10s'},
  // ---- epic ----
  {id:'meteor', name:'METEOR CALL',lab:'METEOR',  col:'#ff7a3a',pow:160,rar:'epic',tgt:1,desc:'Delayed huge blast on target'},
  {id:'drain',  name:'DRAIN SOUL',lab:'DRAIN',    col:'#d0306a',pow:22,rar:'epic',tgt:1,desc:'2s beam, heals 50% of dmg'},
  {id:'timestop',name:'TIME STOP',lab:'TIME STOP',col:'#ffd23f',pow:0, rar:'epic',desc:'Foes frozen 2s, bosses slowed'},
  // ---- legendary (earned by felling the dragon) ----
  {id:'dragonfire',name:'DRAGONFIRE',lab:'DRGNFIRE',col:'#ff4a1a',pow:210,rar:'legendary',desc:'Huge flame cone'},
];
const CARD={};CARDS.forEach(c=>{CARD[c.id]=c;});
const COMBOS=[
  {a:'frostbolt',b:'fire',  name:'STEAM BLAST',  col:'#e8f4ff',needT:1,desc:'Boiling blast (r88): 140 dmg + 1s stun'},
  {a:'chain',    b:'poison',name:'STORM CLOUD',  col:'#d8ff5a',needT:1,desc:'Electrified cloud that zaps foes inside'},
  {a:'shadow',   b:'sword', name:'PHANTOM SLASH',col:'#b69cff',desc:'Dash + 160 dmg slash along the path'},
  {a:'ward',     b:'heal',  name:'SANCTUARY',    col:'#fff0a8',desc:'5s dome + heal 5%/s'},
  {a:'fire',     b:'quake', name:'MAGMA SURGE',  col:'#ff7a2a',desc:'Fire ring (r135): 130 dmg, burn, stun'},
  {a:'timestop', b:'meteor',name:'JUDGMENT',     col:'#ffd23f',desc:'A meteor falls on EVERY foe'},
];
