/* =====================================================================
   PETS (companions) + TROPHIES + HOUSE layout. Data only.
   A pet follows the hero and, in a fight, makes a small attack of its own every few seconds. Bond grows with kills.
   ===================================================================== */
const PETS={
  cinder:{id:'cinder',name:'Cinderpup', price:90, col:'#ff9a3d',desc:'Spits embers and bites foes that come near',        atk:'shot',pk:'ember', cd:2.6,dmg:7, per:1.1, bm:'melee', bcd:1.7,bd:.55,br:150,bv:'bite'},
  wisp:  {id:'wisp',  name:'Rime Wisp', price:160,col:'#8fd8ff',desc:'Frost shards that chill - flicks little motes on its own',      atk:'shot',pk:'pfrost',cd:3.4,dmg:5, per:.8,chill:2.2, bm:'ranged',bcd:2.1,bd:.5,br:260,bv:'mote'},
  moth:  {id:'moth',  name:'Gloam Moth',price:220,col:'#c58bff',desc:'Mends your wounds, zaps foes with tiny sparks',        atk:'heal',pk:'spark', cd:6.5,dmg:3, per:.6, bm:'ranged',bcd:2.6,bd:.7,br:230,bv:'spark'},
  pebblin:{id:'pebblin',name:'Pebblin',  price:300,col:'#b8b0a0',desc:'Hurls heavy pebbles, stomps nearby foes',       atk:'shot',pk:'pebble',cd:4.2,dmg:15,per:1.8, bm:'melee', bcd:3.2,bd:.6,br:130,bv:'stomp'},
};
const PET_IDS=Object.keys(PETS);
const PET_CFG={bondPerLv:8,maxLv:5,lvMul:.3,follow:26,attackRange:520};
/* trophies: earned once, then placed on the shelves of your house */
const TROPHIES={
  fang:   {id:'fang',   name:'Emberfang Tooth',   how:'Defeat Emberfang',              col:'#ffe9c0'},
  crown:  {id:'crown',  name:'Lich King\'s Crown',how:'Defeat the Lich King',          col:'#7dffa0'},
  horn:   {id:'horn',   name:'Rimegar\'s Horn',   how:'Defeat Rimegar',                col:'#8fd8ff'},
  eye:    {id:'eye',    name:'Mossback Eye',      how:'Defeat Old Mossback',           col:'#9ad03a'},
  idol:   {id:'idol',   name:'Colossus Idol',     how:'Defeat the Sundered Colossus',  col:'#ffcf5a'},
  laurel: {id:'laurel', name:'Arena Laurel',      how:'Clear 3 rounds of the boss rush',col:'#6adf6a'},
  brand:  {id:'brand',  name:'Elite Brand',       how:'Defeat 10 elite monsters',      col:'#ff7a3a'},
  banner: {id:'banner', name:'Menagerie Banner',  how:'Adopt every pet',               col:'#e8504a'},
};
const TROPHY_IDS=Object.keys(TROPHIES);
const TROPHY_BOSS={dragon:'fang',lich:'crown',rimegar:'horn',mossback:'eye',colossus:'idol'};
// house: the door sign stands at the 4th village house; the room is the HOUSE_Y0 block of the map
const HOUSE_DOOR={tx:19,ty:44};
const HOUSE_ROOM={x0:24,x1:39,y0:HOUSE_Y0+3,y1:HOUSE_Y0+11};
const HOUSEVOID=(()=>{const q=new URLSearchParams(location.search).get('housevoid');if(q===null||q==='')return 4;const v=+q;return v>=1&&v<=4?v|0:0;})();   // what lies beyond the house walls: default 4 = bigger house (kitchen room) + zoom + vignette; ?housevoid=1..3 alternatives, =0 the old black void
const HOUSE_KIT={x0:15,x1:22};   // option 4 only: a second room (kitchen / storage) west of the main room
const HOUSE_PROPS={};   // option 4: solid furniture tiles in the second room: 'x,y' -> [type, rx, ry]
const HOUSE_SLOTS=[[26,HOUSE_Y0+4],[29,HOUSE_Y0+4],[32,HOUSE_Y0+4],[35,HOUSE_Y0+4],[37,HOUSE_Y0+7],[26,HOUSE_Y0+7],[28,HOUSE_Y0+10],[35,HOUSE_Y0+10]];
const HOUSE_IN={x:31*TS+16,y:(HOUSE_ROOM.y1-1)*TS+28,dir:'u'};
const HOUSE_OUT={x:HOUSE_DOOR.tx*TS+16,y:HOUSE_DOOR.ty*TS+28,dir:'d'};
