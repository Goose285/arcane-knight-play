
const NPCS=[
  {name:'Elder Orin',x:11.5*TS,y:36.9*TS,spr:'elder',lines:['Welcome to Oakvale, brave one!','Monsters watch the world in a faint cone of sight. If you step into it, the fight starts right there - no new screen. Sneak around behind them, or shoot first with J!','Fire your Arcane Shot with J (or the SHOT button) in the direction you face. Hold it to charge a mighty shot!','When the spell gauge fills you get 5 spell cards. L / NEXT cycles them, K / CAST uses the chosen one. You can tap a card, too.','Glowing yellow marks on the ground show where an attack will land. Get out before they flash red!','Run far enough from a monster and it loses interest. Emberfang the Dragon rules Castle Dracoryn to the north - level up first.']},
  {name:'Blacksmith Brum',x:6.5*TS,y:35.2*TS,spr:'smith',smith:true},
  {name:'Pip',x:20.5*TS,y:37.0*TS,spr:'kid',lines:['I saw a Skeleton Knight raise its shield! Your arcane shot just goes CLANG...','Swords, lances and charged shots break through a guard!','The fountain in the village heals you, you know.']},
  {name:'Gate Guard',x:30.3*TS,y:13.2*TS,spr:'guard',lines:['Halt! ...Oh, you are the hero from Oakvale.','Beyond this gate lies the courtyard of Castle Dracoryn. Knights and goblins roam inside.','The dragon sits upon the throne at the far end. Good luck.']},
];
