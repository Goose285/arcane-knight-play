/* =====================================================================
   WAYSTONES (fast travel), SECRETS (cracked walls, hidden caves, treasure maps -> rare cards). Data only.
   ===================================================================== */
// waystone: id, name, tile of the stone (an NPC-like object), and where you appear
const WAYSTONES=[
  {id:'village',name:'Oakvale Waystone',  tx:11,ty:34,to:{x:12*TS+16,y:35*TS+28}},
  {id:'road',   name:'Castle Road Waystone',tx:30,ty:16,to:{x:31*TS+16,y:17*TS+28}},
  {id:'forest', name:'Whisperwood Waystone',tx:44,ty:32,to:{x:45*TS+16,y:33*TS+28}},
  {id:'snow',   name:'Frosthowl Waystone', zone:'snow'},
  {id:'swamp',  name:'Mirewood Waystone',  zone:'swamp'},
  {id:'desert', name:'Sundered Waystone',  zone:'desert'},
];
// treasure maps: dropped by the three regional bosses; an X on the overworld marks the dig spot; digging yields a rare card
const TMAPS=[
  {id:'m_snow',  name:'Frost-Stained Map',from:'rimegar', x:12,y:24,card:'frostburst'},
  {id:'m_swamp', name:'Mildewed Map',     from:'mossback',x:38,y:33,card:'crimsonburst'},
  {id:'m_desert',name:'Sun-Bleached Map', from:'colossus',x:20,y:16,card:'quake'},
];
// hidden chests (behind a cracked wall in each region)
const CHESTS=['snow','swamp','desert'].map(z=>({id:'c_'+z,zone:z,tx:30,ty:ZONE_Y0[z]+31}));
