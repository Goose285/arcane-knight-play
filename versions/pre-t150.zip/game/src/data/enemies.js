
const ENEMY={
  slime:{name:'Gooey Slime',hp:200,xp:20,gold:[5,12],speed:24,chase:44,aggro:3.4*TS,spr:'slime'},
  knight:{name:'Skeleton Knight',hp:380,xp:45,gold:[14,26],speed:30,chase:68,aggro:5*TS,spr:'knight'},
  goblin:{name:'Goblin Archer',hp:300,xp:38,gold:[10,22],speed:34,chase:56,aggro:6*TS,spr:'goblin'},
  dragon:{name:'Emberfang the Dragon',hp:1500,xp:400,gold:[160,220],speed:26,chase:50,aggro:5*TS,spr:'dragon',boss:true},
};
// vision: range in px and half-angle of the sight cone (radians)
ENEMY.slime.vr=105;ENEMY.slime.vh=.9;ENEMY.knight.vr=170;ENEMY.knight.vh=.7;ENEMY.goblin.vr=235;ENEMY.goblin.vh=.6;ENEMY.dragon.vr=300;ENEMY.dragon.vh=.8;
// auto-aggro radius: any direction (walls still block) ~50% of sight range
ENEMY.slime.ar=64;ENEMY.knight.ar=76;ENEMY.goblin.ar=80;ENEMY.dragon.ar=150;   // awareness circle: ~2-2.5 tiles (scaled by type)
// level scaling per level above 1: hp / damage / attack speed / sight, xp+gold. Bosses scale gently and may resist freeze.
Object.values(ENEMY).forEach(d=>Object.assign(d,{hs:.17,ds:.10,as:.025,ss:.02,rs:.22,freezeImmune:false}));
Object.assign(ENEMY.dragon,{hs:.08,ds:.05,as:.01,ss:.01,rs:.03,freezeImmune:true,
  territory:{tx0:19,ty0:2,tx1:45,ty1:10}});   // generic per-enemy flag: tile rect (inclusive) the enemy may never leave - the castle interior
const TIERS={slime:['SLIME','ELDER','ANCIENT'],knight:['KNIGHT','CAPTAIN','WARLORD'],goblin:['GOBLIN','MARKSMAN','SNIPER'],dragon:['DRAGON','DRAGON','DRAGON']};
const TITLES={slime:['Gooey Slime','Elder Slime','Ancient Slime'],knight:['Skeleton Knight','Skeleton Captain','Skeleton Warlord'],goblin:['Goblin Archer','Goblin Marksman','Goblin Sniper'],dragon:['Emberfang','Emberfang','Emberfang']};
const TIER_TINT=[null,'#a86bff','#ffc23a'],TIER_SIZE=[1,1.08,1.16];

/* ---- Crypt of Hollow Kings ---- */
Object.assign(ENEMY,{
  bat:{name:'Crypt Bat',hp:230,xp:52,gold:[12,24],speed:44,chase:88,aggro:5*TS,spr:'bat',vr:150,vh:1.0,ar:72},
  wraith:{name:'Hollow Wraith',hp:370,xp:80,gold:[22,38],speed:30,chase:54,aggro:6*TS,spr:'wraith',vr:225,vh:.75,ar:80},
  lich:{name:'Lich King',hp:2700,xp:900,gold:[400,520],speed:22,chase:46,aggro:6*TS,spr:'lich',boss:true,big:true,vr:330,vh:.9,ar:170},
});
[ENEMY.bat,ENEMY.wraith,ENEMY.lich].forEach(d=>Object.assign(d,{hs:.17,ds:.10,as:.025,ss:.02,rs:.22,freezeImmune:false}));
Object.assign(ENEMY.lich,{hs:.07,ds:.05,as:.01,ss:.01,rs:.03,freezeImmune:true,p2at:.66,p3at:.33,
  territory:{tx0:17,ty0:51,tx1:46,ty1:61}});   // the throne hall: the Lich King never leaves it
Object.assign(ENEMY.dragon,{big:true,p2at:.5});
Object.assign(TIERS,{bat:['BAT','VAMPIRE','BLOOD BAT'],wraith:['WRAITH','SPECTER','BANSHEE'],lich:['LICH KING','LICH KING','LICH KING']});
Object.assign(TITLES,{bat:['Crypt Bat','Vampire Bat','Blood Bat'],wraith:['Hollow Wraith','Grave Specter','Banshee'],lich:['Lich King','Lich King','Lich King']});

/* ---- new regions: Frosthowl Pass / Mirewood Bog / Sundered Ruins ---- */
Object.assign(ENEMY,{
  wolf:    {name:'Frost Wolf',    hp:300,xp:90, gold:[18,30],speed:40,chase:86,aggro:6*TS,spr:'wolf',   vr:200,vh:.8,ar:80},
  yeti:    {name:'Rime Brute',    hp:620,xp:130,gold:[28,46],speed:26,chase:52,aggro:5*TS,spr:'yeti',   vr:170,vh:.8,ar:76},
  toad:    {name:'Bog Toad',      hp:420,xp:140,gold:[26,44],speed:30,chase:62,aggro:5*TS,spr:'toad',   vr:170,vh:.8,ar:72},
  witch:   {name:'Mire Witch',    hp:380,xp:170,gold:[34,56],speed:28,chase:50,aggro:6*TS,spr:'witch',  vr:240,vh:.7,ar:80},
  scorpion:{name:'Dune Scorpion', hp:480,xp:190,gold:[38,60],speed:38,chase:80,aggro:5*TS,spr:'scorpion',vr:190,vh:.8,ar:76},
  mummy:   {name:'Dust Mummy',    hp:760,xp:230,gold:[46,72],speed:24,chase:46,aggro:5*TS,spr:'mummy',  vr:170,vh:.8,ar:76},
  rimegar: {name:'Rimegar the Frost Titan',hp:3400,xp:1300,gold:[600,760],speed:22,chase:44,aggro:6*TS,spr:'rimegar', boss:true,big:true,vr:330,vh:.9,ar:170},
  mossback:{name:'Old Mossback the Bog Hydra',hp:4000,xp:1800,gold:[800,980],speed:22,chase:44,aggro:6*TS,spr:'mossback',boss:true,big:true,vr:330,vh:.9,ar:170},
  colossus:{name:'The Sundered Colossus',hp:4800,xp:2500,gold:[1000,1300],speed:20,chase:40,aggro:6*TS,spr:'colossus',boss:true,big:true,vr:330,vh:.9,ar:170},
});
['wolf','yeti','toad','witch','scorpion','mummy'].forEach(k=>Object.assign(ENEMY[k],{hs:.17,ds:.10,as:.025,ss:.02,rs:.22,freezeImmune:false}));
['rimegar','mossback','colossus'].forEach(k=>Object.assign(ENEMY[k],{hs:.07,ds:.05,as:.01,ss:.01,rs:.03,freezeImmune:true,p2at:.66,p3at:.33}));
Object.assign(ENEMY.rimegar,{territory:{tx0:12,ty0:ZONE_Y0.snow+1,tx1:60,ty1:ZONE_Y0.snow+8}});
Object.assign(ENEMY.mossback,{territory:{tx0:12,ty0:ZONE_Y0.swamp+1,tx1:60,ty1:ZONE_Y0.swamp+8}});
Object.assign(ENEMY.colossus,{territory:{tx0:12,ty0:ZONE_Y0.desert+1,tx1:60,ty1:ZONE_Y0.desert+8}});
Object.assign(TIERS,{wolf:['WOLF','DIRE WOLF','ALPHA'],yeti:['BRUTE','BERSERKER','WARLORD'],toad:['TOAD','BULLFROG','TYRANT'],witch:['WITCH','HAG','BOG QUEEN'],scorpion:['SCORPION','STINGER','KING STINGER'],mummy:['MUMMY','WIGHT','TOMB LORD'],
  rimegar:['FROST TITAN','FROST TITAN','FROST TITAN'],mossback:['BOG HYDRA','BOG HYDRA','BOG HYDRA'],colossus:['COLOSSUS','COLOSSUS','COLOSSUS']});
Object.assign(TITLES,{wolf:['Frost Wolf','Dire Wolf','Alpha Wolf'],yeti:['Rime Brute','Rime Berserker','Rime Warlord'],toad:['Bog Toad','Bog Bullfrog','Bog Tyrant'],witch:['Mire Witch','Mire Hag','Bog Queen'],scorpion:['Dune Scorpion','Dune Stinger','King Stinger'],mummy:['Dust Mummy','Dust Wight','Tomb Lord'],
  rimegar:['Rimegar','Rimegar','Rimegar'],mossback:['Old Mossback','Old Mossback','Old Mossback'],colossus:['The Colossus','The Colossus','The Colossus']});

/* ---- Goldenfield Farms (south of Oakvale): early-mid level field monsters ---- */
Object.assign(ENEMY,{
  boar:     {name:'Field Boar',       hp:340,xp:100,gold:[20,34],speed:36,chase:78,aggro:5*TS,spr:'boar',     vr:190,vh:.8,ar:76},
  scarecrow:{name:'Haunted Scarecrow',hp:470,xp:125,gold:[26,42],speed:24,chase:50,aggro:5*TS,spr:'scarecrow',vr:170,vh:.8,ar:72},
});
['boar','scarecrow'].forEach(k=>Object.assign(ENEMY[k],{hs:.17,ds:.10,as:.025,ss:.02,rs:.22,freezeImmune:false}));
Object.assign(TIERS,{boar:['BOAR','TUSKER','WARBOAR'],scarecrow:['SCARECROW','STRAWMAN','HARVESTER']});
Object.assign(TITLES,{boar:['Field Boar','Tusker Boar','War Boar'],scarecrow:['Haunted Scarecrow','Straw Revenant','Harvest Horror']});
