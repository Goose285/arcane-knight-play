/* =====================================================================
   FISHING DATA: fish, rods, levels. Catches sell for gold, can be cooked & eaten to heal, and drop Silver Scales for crafting.
   ===================================================================== */
const FISH_MAX_LV=70;   // t148u: fishing is its own skill, capped at 70
const fishNeed=l=>Math.round(28+10*(l-1)+.12*(l-1)*(l-1));   // t148u: gentle early, steeper later toward 70
const FISHES=[
  {id:'minnow',n:'Silverscale Minnow',tier:0,lv:1,w:10,price:6,  heal:.06,xp:6, dif:.8, rar:0,col:'#cfe3ff'},
  {id:'carp',  n:'Mudfin Carp',       tier:0,lv:1,w:8, price:11, heal:.10,xp:9, dif:1.0,rar:0,col:'#b08a5a'},
  {id:'trout', n:'Riverbell Trout',   tier:0,lv:2,w:4, price:22, heal:.14,xp:14,dif:1.15,rar:1,col:'#e8a8c8'},
  {id:'pike',  n:'Greenwood Pike',    tier:1,lv:3,w:8, price:34, heal:.20,xp:20,dif:1.3, rar:1,col:'#7ac060'},
  {id:'bass',  n:'Moonpetal Bass',    tier:1,lv:4,w:4, price:52, heal:.26,xp:28,dif:1.45,rar:2,col:'#c8b8ff'},
  {id:'eel',   n:'Bog Lurker Eel',    tier:2,lv:5,w:8, price:70, heal:.30,xp:36,dif:1.6, rar:2,col:'#8aa860'},
  {id:'gill',  n:'Glowgill',          tier:2,lv:6,w:4, price:105,heal:.36,xp:48,dif:1.75,rar:3,col:'#7dffd0'},
  {id:'perch', n:'Sunscale Perch',    tier:3,lv:7,w:8, price:130,heal:.42,xp:60,dif:1.9, rar:3,col:'#ffd23f'},
  {id:'koi',   n:'Mirage Koi',        tier:3,lv:8,w:3, price:210,heal:.55,xp:90,dif:2.1, rar:4,col:'#ff8a5a'},
  {id:'salmon',n:'Dawn Salmon',       tier:3,lv:12,w:5,price:160,heal:.45,xp:70,dif:2.0, rar:3,col:'#ff9a7a'},
  {id:'catfish',n:'Whisker Catfish',  tier:3,lv:18,w:6,price:190,heal:.48,xp:85,dif:2.15,rar:3,col:'#8a7a5a'},
  {id:'sturgeon',n:'Ironjaw Sturgeon',tier:4,lv:28,w:3,price:320,heal:.6,xp:120,dif:2.3, rar:4,col:'#b0c0d0'},
  {id:'goldfin',n:'Royal Goldfin',    tier:4,lv:40,w:2,price:480,heal:.7,xp:160,dif:2.5, rar:4,col:'#ffd23f'},
  {id:'levi',  n:'Leviathan Fry',     tier:4,lv:55,w:1,price:900,heal:.85,xp:260,dif:2.8, rar:4,col:'#7df9ff'},
  {id:'myth',  n:'Mythfin',           tier:4,lv:68,w:1,price:1400,heal:1,xp:400,dif:3.0, rar:4,col:'#ffe14d'},
];
const FISH_RARITY=[{n:'Common',col:'#cfd6e6'},{n:'Uncommon',col:'#7dff8a'},{n:'Rare',col:'#6ab8ff'},{n:'Epic',col:'#c58aff'},{n:'Legendary',col:'#ffb43a'}];
const FISH_JUNK=[
  {id:'boot', n:'Old Boot',  price:1, col:'#7a5a3a',junk:true,heal:0,xp:0},
  {id:'pearl',n:'Moon Pearl',price:75,col:'#f4f0ff',junk:true,heal:0,xp:0},
];
const FISH_BY={};FISHES.concat(FISH_JUNK).forEach(f=>{FISH_BY[f.id]=f;});
/* rods: bite = seconds you have to answer a Rare bite, waitMul = shorter gaps between catches, luck = better odds for rare fish (and rarer bites sooner) */
const RODS=[
  {id:'wood',n:'WOODEN ROD',    price:25, bite:4,waitMul:1,  luck:0,  col:'#c08a52',desc:'A plain pole - fine for the river.'},
  {id:'bog', n:'BOGWOOD ROD',   price:150,bite:4.4,waitMul:.88, luck:.15,col:'#9ad03a',desc:'Springy: fish bite a little sooner, better odds at rare ones.'},
  {id:'star',n:'STARLIGHT ROD', price:480,bite:4.8,waitMul:.76, luck:.35,col:'#9fd8ff',desc:'Silver-strung: quickest bites, rare fish love it, longer rare-bite window.'},
];
MATS.fscale={n:'Silver Scale',col:'#cfe6ff'};
RECIPES.push({id:'r_angler',name:"Angler's Band",slot:'ring',rar:'rare',mats:{fscale:5,shard:2},gold:110});
