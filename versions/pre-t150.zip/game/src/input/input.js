
/* ---------- input ---------- */
const keys={};let pressed={},released={};
addEventListener('keydown',e=>{
  if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Tab'].includes(e.code))e.preventDefault();
  if(!e.repeat){pressed[e.code]=true;}
  keys[e.code]=true;
  ensureAudio();
});
addEventListener('keyup',e=>{keys[e.code]=false;released[e.code]=true;});
addEventListener('blur',()=>{for(const k in keys)keys[k]=false;});
const held=(...c)=>c.some(k=>keys[k]);
const hit=(...c)=>c.some(k=>pressed[k]);
const rel=(...c)=>c.some(k=>released[k]);
const K_L=['KeyA','ArrowLeft'],K_R=['KeyD','ArrowRight'],K_U=['KeyW','ArrowUp'],K_D=['KeyS','ArrowDown'];
