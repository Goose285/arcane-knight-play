/* =====================================================================
   t148u FEATURES: planter boxes, blacksmith shop interior, tavern, water life,
   extra moss on the south wall. Fishing Lv70 + quest UI are patched elsewhere.
   ===================================================================== */
Object.assign(T,{PLB:98});
const PLANTERS=[];
(function placePlanters(){
  const spots0=[[18,32],[20,32],[22,32],[24,32],[13,35],[26,35],[16,38],[23,38],[19,41],[21,41],[14,33],[25,33],[17,36],[22,36]];
  const oy=typeof OWY0==='number'?OWY0:(typeof OY==='number'?OY:0);
  const spots=spots0.map(([x,y])=>[x,y+oy]);
  const mk=makeSprite(16,16,g=>{
    rect(g,0,0,16,16,'#5aaa45');rect(g,1,9,14,7,'#6b4423');rect(g,1,9,14,1,'#8a5a32');rect(g,1,15,14,1,'#3a2410');
    rect(g,2,10,12,5,'#4a3018');
    for(const [x,y,c] of [[3,6,'#ff6a8a'],[7,4,'#ffe14d'],[11,6,'#a78bff'],[5,3,'#ff9a3d'],[9,5,'#ff8ab8'],[6,7,'#8ab4ff']]){
      rect(g,x,y,2,2,c);rect(g,x,y+2,1,2,'#3d8530');}
  });
  TSPR[T.PLB]=[mk];TSPR.mini[T.PLB]='#8a5a32';XTILE_FN[T.PLB]=()=>mk;
  function apply(){if(PLANTERS.length>=8)return;if(typeof map==='undefined'||!map||!map.length||typeof TOWN==='undefined')return;
    const x0=Math.floor(TOWN.x0/TS)+2,x1=Math.floor(TOWN.x1/TS)-2,y0=Math.floor(TOWN.y0/TS)+2,y1=Math.floor(TOWN.y1/TS)-2;
    const cand=[];for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const t=map[y][x];if(t===T.G||t===T.L||t===T.K){
      // prefer grass next to a path or building
      let near=false;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const n=map[y+dy]&&map[y+dy][x+dx];if(n===T.P||n===T.H||n===T.D||n===T.F)near=true;}
      if(near)cand.push([x,y]);}}
    // space them out
    for(const [x,y] of cand){if(PLANTERS.length>=14)break;
      if(PLANTERS.some(([px,py])=>Math.hypot(px-x,py-y)<3))continue;
      map[y][x]=T.PLB;PLANTERS.push([x,y]);}}
  setTimeout(apply,0);setTimeout(apply,200);setTimeout(apply,800);
  {const _ts=tileSprite;tileSprite=function(id,x,y,time){if(id===T.PLB)return mk;return _ts.apply(this,arguments);};}
})();
(function moreMoss(){
  if(typeof SW==='undefined'||!SW.southTile)return;
  const _st=SW.southTile;
  SW.southTile=function(x,y){
    const s=_st(x,y);if(!s||s.width!==16)return s;
    if(!s._moss){const c=makeSprite(16,16,g=>{g.drawImage(s,0,0);
      const rnd=mulberry32((x*31+y*17)|0);
      for(let i=0;i<5;i++){const mx=1+Math.floor(rnd()*14),my=9+Math.floor(rnd()*6),h=2+Math.floor(rnd()*4);
        g.fillStyle=rnd()<.5?'#6fa24a':'#4a7a2a';g.fillRect(mx,my,1,h);if(rnd()<.45){g.fillStyle='#9ccc6a';g.fillRect(mx,my,1,1);}}
      if(((x+y)&3)===0){g.fillStyle='#5a8a3a';g.fillRect(3,11,4,3);g.fillRect(9,12,3,3);g.fillStyle='#9ccc6a';g.fillRect(4,11,1,1);}
    });c._moss=1;s._moss=c;}
    return s._moss;
  };
})();
const WLIFE={pads:[],reeds:[],fish:[],jumps:[],t:0,built:false};
function wlifeBuild(){
  if(typeof map==="undefined"||!map||!map.length)return;if(WLIFE.built&&WLIFE.pads.length)return;WLIFE.built=true;WLIFE.pads.length=0;WLIFE.reeds.length=0;WLIFE.fish.length=0;const rnd=mulberry32(90210);
  const yA=typeof OWY0==='number'?OWY0:0,yB=Math.min(MH,yA+(typeof OW_H==='number'?OW_H:MH));
  for(let y=yA;y<yB;y++)for(let x=0;x<MW;x++){
    if(map[y][x]!==T.W&&map[y][x]!==T.PW)continue;
    const r=rnd();
    if(r<(typeof perfOn==='function'&&perfOn()?.018:.035))WLIFE.pads.push({x:x*TS+8+rnd()*16,y:y*TS+10+rnd()*12,s:.7+rnd()*.5});
    else if(r<(typeof perfOn==='function'&&perfOn()?.03:.06))WLIFE.reeds.push({x:x*TS+4+rnd()*20,y:y*TS+18,ph:rnd()*6.28,h:8+rnd()*8});
    if(r>(typeof perfOn==='function'&&perfOn()?.985:.97))WLIFE.fish.push({x:x*TS+16,y:y*TS+16,a:rnd()*6.28,spd:.4+rnd()*.5,r:10+rnd()*18});
  }
}
function updateWlife(dt){
  if(!WLIFE.built)wlifeBuild();WLIFE.t+=dt;
  for(const f of WLIFE.fish){f.a+=dt*f.spd;f.wx=f.x+Math.cos(f.a)*f.r;f.wy=f.y+Math.sin(f.a)*f.r*.6;}
  if(Math.random()<dt*.08&&WLIFE.fish.length){
    const f=WLIFE.fish[Math.floor(Math.random()*WLIFE.fish.length)];
    const sx=f.wx||f.x,sy=f.wy||f.y;
    if(Math.abs(sx-cam.x-VW/2)<VW&&Math.abs(sy-cam.y-VH/2)<VH)WLIFE.jumps.push({x:sx,y:sy,t:0,dur:.9,col:'#cfe3ff'});
  }
  for(let i=WLIFE.jumps.length-1;i>=0;i--){WLIFE.jumps[i].t+=dt;if(WLIFE.jumps[i].t>=WLIFE.jumps[i].dur)WLIFE.jumps.splice(i,1);}
}
function drawWlife(){
  wlifeBuild();const cx=cam.x,cy=cam.y;
  for(const p of WLIFE.pads){const x=p.x-cx,y=p.y-cy;if(x<-20||y<-20||x>VW+20||y>VH+20)continue;
    ctx.fillStyle='#3a6a28';ctx.beginPath();ctx.ellipse(x,y,7*p.s,4*p.s,0,0,6.283);ctx.fill();
    ctx.fillStyle='#5a9a3a';ctx.beginPath();ctx.ellipse(x-1,y-1,5*p.s,3*p.s,0,0,6.283);ctx.fill();
    ctx.fillStyle='#2a4a18';ctx.fillRect(Math.round(x),Math.round(y-1),1,3);}
  for(const r of WLIFE.reeds){const x=r.x-cx,y=r.y-cy;if(x<-10||y<-30||x>VW+10||y>VH+10)continue;
    const sway=Math.sin(gtime*1.4+r.ph)*2;ctx.strokeStyle='#4a7a2a';ctx.lineWidth=1.5;
    for(let i=0;i<3;i++){ctx.beginPath();ctx.moveTo(x+i*3,y);ctx.quadraticCurveTo(x+i*3+sway,y-r.h/2,x+i*3+sway*1.4,y-r.h);ctx.stroke();}
    ctx.fillStyle='#7acc4a';ctx.fillRect(Math.round(x+sway*1.4),Math.round(y-r.h-2),3,2);}
  ctx.globalAlpha=.28;ctx.fillStyle='#0a1830';
  for(const f of WLIFE.fish){const x=(f.wx||f.x)-cx,y=(f.wy||f.y)-cy;if(x<-20||y<-20||x>VW+20||y>VH+20)continue;
    ctx.beginPath();ctx.ellipse(x,y,6,2.5,f.a,0,6.283);ctx.fill();}
  ctx.globalAlpha=1;
  for(const j of WLIFE.jumps){const p=j.t/j.dur,x=j.x-cx,y=j.y-cy-Math.sin(p*Math.PI)*18;
    ctx.globalAlpha=Math.max(0,1-Math.abs(p-.5)*1.6);ctx.fillStyle=j.col;ctx.beginPath();ctx.ellipse(x,y,5,2.5,0,0,6.283);ctx.fill();
    ctx.fillStyle='#fff';ctx.fillRect(Math.round(x+3),Math.round(y-1),2,1);
    if(p>.55){ctx.globalAlpha=.4*(1-p);ctx.strokeStyle='#a8d6ff';ctx.beginPath();ctx.arc(j.x-cx,j.y-cy,4+(p-.55)*16,0,6.283);ctx.stroke();}
    ctx.globalAlpha=1;}
  if(state==='play'){const tx=Math.floor(P.x/TS),ty=Math.floor(P.y/TS);
    for(const [dx,dy] of [[0,0],[1,0],[-1,0],[0,1],[0,-1]]){const t=map[ty+dy]&&map[ty+dy][tx+dx];if(t!==T.W&&t!==T.PW)continue;
      const px=(tx+dx+.5)*TS-cx,py=(ty+dy+.5)*TS-cy,ph=(gtime*2+dx+dy)%1;
      ctx.globalAlpha=.25*(1-ph);ctx.strokeStyle='#cfe8ff';ctx.beginPath();ctx.ellipse(px,py,4+ph*10,2+ph*4,0,0,6.283);ctx.stroke();ctx.globalAlpha=1;}}
}
{const _dw=drawWorld;drawWorld=function(){_dw();try{drawWlife();}catch(e){}};
 const _up=update;update=function(dt){try{updateWlife(dt);}catch(e){}return _up.apply(this,arguments);};}
const SMITH_SHOP={ready:false};
function buildSmithShop(){
  if(SMITH_SHOP.ready)return;const n=NPCS.find(q=>q.name==='Blacksmith Brum');if(!n)return;
  // find the door wall from Brum's ORIGINAL yard position (he stands south of the facade)
  let tx=Math.floor(n.x/TS),ty=Math.floor(n.y/TS),wy=null;
  for(let k=0;k<=5;k++){for(const dy of [-k,k?k:null]){if(dy==null)continue;const y=ty+dy;if(y<1||y>=MH)continue;
    for(let x=Math.max(0,tx-4);x<=Math.min(MW-1,tx+4);x++)if(map[y][x]===T.D){wy=y;tx=x;break;}if(wy!=null)break;}if(wy!=null)break;}
  if(wy==null){for(let k=1;k<=4;k++){const t=map[ty-k]&&map[ty-k][tx];if(t===T.D||t===T.H){wy=ty-k;break;}}}
  if(wy==null)return;
  let x0=tx;while(x0>1&&(map[wy][x0-1]===T.H||map[wy][x0-1]===T.D))x0--;
  let x1=tx;while(x1<MW-2&&(map[wy][x1+1]===T.H||map[wy][x1+1]===T.D))x1++;
  const iy1=wy-1,iy0=wy-4;if(iy0<2)return;
  for(let y=iy0;y<=iy1;y++)for(let x=x0;x<=x1;x++){
    if(y===iy0||x===x0||x===x1)map[y][x]=T.B;else map[y][x]=T.F;
  }
  const mx=(x0+x1)>>1;map[iy0][mx]=T.FRN;map[iy0+1][mx-1]=T.ANV;   // anvil + furnace INSIDE against the back wall only
  // clear any leftover yard ANV/FRN from older builds (they sat in the open near the waystone)
  for(let y=wy;y<=wy+3&&y<MH;y++)for(let x=x0-3;x<=x1+3&&x<MW;x++)if(x>=0&&(map[y][x]===T.ANV||map[y][x]===T.FRN)&&(y>wy||x<x0||x>x1))map[y][x]=T.G;
  // Brum stands just inside the doorway
  n.x=(tx+.5)*TS;n.y=(wy+.55)*TS;if(n.hx!=null){n.hx=n.x;n.hy=n.y;}
  SMITH_SHOP.ready=true;SMITH_SHOP.door={tx,wy,x0,x1};
}
setTimeout(buildSmithShop,50);setTimeout(buildSmithShop,400);
const TAVERN={ready:false};
function buildTavern(){
  if(TAVERN.ready)return;
  const x0=27,y0=31,w=5,h=4;if(y0+h>=MH||x0+w>=MW)return;
  for(let y=y0;y<y0+h;y++)for(let x=x0;x<x0+w;x++){
    if(y===y0)map[y][x]=T.R;
    else if(y===y0+h-1)map[y][x]=(x===x0+2)?T.D:T.H;
    else if(x===x0||x===x0+w-1)map[y][x]=T.H;
    else map[y][x]=T.F;
  }
  map[y0+1][x0+1]=T.Z;map[y0+1][x0+3]=T.Z;
  for(let y=y0+h;y<=y0+h+1&&y<MH;y++)if(map[y][x0+2]===T.G||map[y][x0+2]===T.L)map[y][x0+2]=T.P;
  if(!NPCS.some(n=>n.name==='Mara the Tapster')){
    NPCS.push({name:'Mara the Tapster',x:(x0+2.5)*TS,y:(y0+h-1.2)*TS,hx:(x0+2.5)*TS,hy:(y0+h-1.2)*TS,spr:'inn',tavern:true,inn:true,
      lines:['Welcome to the Oakvale Tap!','Stew\'ll put the spring back in your step.','Heard a rumor: bigger fish bite at dawn by the east pond.','Pull up a stool - first round\'s on the house... almost.']});
  }
  if(!NPCS.some(n=>n.name==='Tavern Sign')){
    NPCS.push({name:'Tavern Sign',x:(x0+4.5)*TS,y:(y0+h+.7)*TS,spr:'sign',sign:true,
      lines:['THE OAKVALE TAP','Hot stew, cold ale, warm rumors. Open from noon to late.']});
  }
  TAVERN.ready=true;
}
setTimeout(buildTavern,80);

/* t149u: remove any leftover yard anvil/furnace sitting in open grass (older builds) */
function clearStrayForge(){
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){
    if(map[y][x]!==T.ANV&&map[y][x]!==T.FRN)continue;
    // keep if surrounded by floor/walls (inside a building)
    let inside=0;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1]]){const t=map[y+dy]&&map[y+dy][x+dx];if(t===T.F||t===T.B||t===T.H||t===T.D||t===T.ANV||t===T.FRN)inside++;}
    if(inside<2)map[y][x]=T.G;
  }
}
setTimeout(clearStrayForge,120);setTimeout(clearStrayForge,600);
