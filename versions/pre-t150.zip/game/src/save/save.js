
/* ---- save / load (localStorage) ---- */
const SAVE_KEY='arcaneKnight.save.v1',NOSAVE=new URLSearchParams(location.search).has('nosave');
function readSave(){try{const s=JSON.parse(localStorage.getItem(SAVE_KEY)||'null');return s&&s.v===1&&s.P&&isFinite(s.P.x)?s:null;}catch(e){return null;}}
/* ---- safety net: the previous save is kept as a backup whenever it would be replaced by a clearly less advanced one (New Game, or a fresh hero
   overwriting a veteran), and the title screen offers to restore it ---- */
const BAK_KEY=SAVE_KEY+'.backup';
function readBackup(){try{const s=JSON.parse(localStorage.getItem(BAK_KEY)||'null');return s&&s.v===1&&s.P&&isFinite(s.P.x)?s:null;}catch(e){return null;}}
function backupSave(raw){   // raw = the JSON text about to be replaced; keep the most advanced one
  if(NOSAVE||!raw)return;try{const o=JSON.parse(raw),b=readBackup();if(!o||!o.P||!(o.P.lv>1||o.P.gold>0))return;if(b&&(b.P.lv>o.P.lv||(b.P.lv===o.P.lv&&b.P.gold>=o.P.gold)))return;localStorage.setItem(BAK_KEY,raw);}catch(e){}
}
function saveGame(why){
  if(NOSAVE||state==='title'||state==='fishlab'||P.hp<=0||RUSH.on)return false;
  try{const prev=localStorage.getItem(SAVE_KEY);if(prev){try{const o=JSON.parse(prev);if(o&&o.P&&P.lv<o.P.lv-1)backupSave(prev);}catch(e){}}}catch(e){}
  try{localStorage.setItem(SAVE_KEY,JSON.stringify({v:1,t:Date.now(),why,best:packBest(),area:areaCur,bossDown,lichDown,tod:DAY.t,kills,muted,cards:packCards(),gear:packGear(),quests:packQuests(),skills:packSkills(),craft:packCraft(),pets:packPets(),story:packStory(),daily:packDaily(),ach:packAch(),secrets:packSecrets(),spw:packSpawners(),fish:packFish(),
    fr:[OX,OY,OW_H],P:{x:Math.round(P.x),y:Math.round(P.y),dir:P.dir,hp:Math.max(1,Math.round(P.hp)),lv:P.lv,xp:P.xp,gold:P.gold,up:P.up}}));return true;}catch(e){return false;}
}
function loadSave(s){
  try{unpackBest(s.best);}catch(e){}
  unpackGear(s.gear);unpackQuests(s.quests);unpackSkills(s.skills);unpackCraft(s.craft);unpackPets(s.pets);unpackStory(s.story);unpackDaily(s.daily);unpackAch(s.ach);unpackSecrets(s.secrets);unpackSpawners(s.spw);unpackFish(s.fish);Object.assign(P,s.P);if(typeof edFrameFix==='function')edFrameFix(P,s.fr);P.moving=false;P.grace=3;P.regen=0;P.hp=clamp(P.hp,1,maxHp());
  bossDown=!!s.bossDown;lichDown=!!s.lichDown;if(typeof s.tod==='number'){DAY.t=s.tod;dayCompute();syncNight(true);}kills=s.kills|0;unpackCards(s.cards);if(typeof s.muted==='boolean')muted=s.muted;
  if(bossDown){const d=enemies.find(o=>o.type==='dragon');if(d){d.alive=false;d.respawn=150;}}
  if(lichDown){const d=enemies.find(o=>o.type==='lich');if(d){d.alive=false;d.respawn=240;}}
  try{sanitizeWorld('load');}catch(e){}
  snapCam();
}
function clearSave(){try{backupSave(localStorage.getItem(SAVE_KEY));localStorage.removeItem(SAVE_KEY);}catch(e){}}   // New Game keeps the old save as a backup
let saveTimer=0;
addEventListener('pagehide',()=>saveGame('hide'));
document.addEventListener('visibilitychange',()=>{if(document.hidden)saveGame('hide');});

/* t142u: load-time (and every few seconds) sanitizing so a corrupted or looping state recovers:
   non-finite hero position / numbers are repaired, NaN or runaway entities are dropped, leftover boss summons are removed. */
const SANITY={fixed:0,last:''};
function sanitizeWorld(why){
  let f=0;const fin=v=>typeof v==='number'&&isFinite(v);
  if(!fin(P.x)||!fin(P.y)||P.x<0||P.y<0||P.x>MW*TS||P.y>MH*TS){const s=typeof HOUSE_OUT!=='undefined'&&HOUSE_OUT?HOUSE_OUT:{x:TS*12,y:TS*(OWY0+30)};P.x=s.x;P.y=s.y;f++;}
  for(const k of ['hp','xp','gold','lv'])if(!fin(P[k])){P[k]=k==='lv'?1:k==='hp'?maxHp():0;f++;}
  if(P.lv<1){P.lv=1;f++;}if(P.xp<0){P.xp=0;f++;}if(P.xp>1e7){P.xp=0;f++;}if(P.hp>maxHp())P.hp=maxHp();
  if(!B){const n0=enemies.length;
    for(let i=enemies.length-1;i>=0;i--){const e=enemies[i];if(!e||!fin(e.x)||!fin(e.y)||!fin(e.hx)||!fin(e.hy)||e.tmp&&e.rush&&!(typeof RUSH!=='undefined'&&RUSH.on)){enemies.splice(i,1);f++;}else{if(!fin(e.hp)){e.hp=e.maxhp||1;f++;}e.engaged=false;}}
    if(enemies.length>2500){enemies.length=2500;f++;}}
  try{for(const s of SPW){if(!isFinite(s.hp)){s.hp=s.maxhp;f++;}const kids=enemies.filter(e=>e.spw===s);if(kids.length>12){let k=kids.length-12;for(let i=enemies.length-1;i>=0&&k>0;i--)if(enemies[i].spw===s&&!enemies[i].engaged){enemies.splice(i,1);k--;f++;}}}}catch(e){}
  if(f){SANITY.fixed+=f;SANITY.last=why;try{console.warn('[sanitize]',why,f);}catch(e){}}
  return f;
}
