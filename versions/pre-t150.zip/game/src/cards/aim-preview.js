/* ---- aim preview: while a ranged / area card is pressed and held, show where it will go ---- */
const AIMV={drawn:0,last:null};
const AIM_KIND={fire:'proj',lance:'line',frostbolt:'bolt',crimsonbolt:'bolt',curse:'bolt',drain:'bolt',chain:'chain',
  frostburst:'area',crimsonburst:'area',meteor:'area',poison:'area',quake:'self',dragonfire:'cone',shadow:'dash'};
const AIM_NEEDS_TARGET={bolt:1,chain:1,area:1};
const AIM_AREA_R={frostburst:70,crimsonburst:70,meteor:62,poison:68,quake:118};
function heldCardId(){
  const xid=typeof expAimId==='function'?expAimId():null;if(xid&&state==='play')return xid;                                   // the card under a finger/mouse that has not been swiped yet
  const t=cardTouch;
  if(!t||t.swiped||typeof B==='undefined'||!B||B.phase!=='fight'||state!=='play')return null;
  return B.hand[t.i]||null;
}
/* Pure geometry of where the card would go right now (null for cards with nothing to aim). */
function aimPlan(id){
  const ch=CARD[id],kind=AIM_KIND[id];if(!ch||!kind)return null;
  const pc=pcen(),tg=aimEnemy(),a=fireAngle(),dx=Math.cos(a),dy=Math.sin(a);
  const pl={id,kind,col:ch.col,from:pc,pts:[pc],end:pc,hits:[],target:tg||null,blocked:false,noTarget:false,r:0,a,w:0,len:0,rays:null};
  const along=(len,ang)=>{const l=clipLen(pc.x,pc.y,ang,len);return{x:pc.x+Math.cos(ang)*l,y:pc.y+Math.sin(ang)*l};};
  if(kind==='proj'){                                      // fireball: flies straight, stops at the first foe or wall
    const dist=clipLen(pc.x,pc.y,a,400);let stop=dist,hit=null;
    for(const e of B.ens){if(e.dying)continue;const c=ecen(e),rx=c.x-pc.x,ry=c.y-pc.y,t=rx*dx+ry*dy;
      if(t>0&&t<stop&&Math.abs(-rx*dy+ry*dx)<eRad(e)+8){stop=t;hit=e;}}
    pl.end={x:pc.x+dx*stop,y:pc.y+dy*stop};pl.pts=[pc,pl.end];if(hit)pl.hits=[hit];pl.r=8;
  } else if(kind==='line'){                               // lance: piercing band
    const z=Z.line(pc.x,pc.y,a,290,22,7);pl.len=z.len;pl.w=22;pl.end={x:pc.x+dx*z.len,y:pc.y+dy*z.len};pl.pts=[pc,pl.end];
    pl.hits=B.ens.filter(e=>!e.dying&&inZone(z,ecen(e),eRad(e)));
  } else if(kind==='self'){                               // quake: ring around the hero
    pl.r=AIM_AREA_R[id];pl.hits=foesIn(pc.x,pc.y,pl.r);
  } else if(kind==='cone'){
    const z=Z.cone(pc.x,pc.y,a,280,.6,7);pl.rays=z.rays;pl.half=z.half;pl.len=z.len;pl.end=along(z.len,a);pl.pts=[pc,pl.end];
    pl.hits=B.ens.filter(e=>!e.dying&&inZone(z,ecen(e),eRad(e)));
  } else if(kind==='dash'){
    const da=dashAngle(),to=stepDest(da,130);pl.a=da;pl.end={x:to.x,y:to.y-12};pl.pts=[pc,pl.end];
    pl.blocked=Math.hypot(to.x-P.x,to.y-P.y)<16;
  } else {                                                // bolt / chain / area: needs a foe with a clear line
    if(tg){
      const tc=ecen(tg);
      if(losW(pc,7,tc,7)){
        pl.end=tc;pl.pts=[pc,tc];pl.hits=[tg];
        if(kind==='chain'){const hit=[tg];let cur=tg;
          while(hit.length<4){const cc=ecen(cur);let best=null,bd=1e9;
            for(const o of B.ens){if(o.dying||hit.includes(o))continue;const oc=ecen(o),d=Math.hypot(oc.x-cc.x,oc.y-cc.y);if(d<150&&d<bd&&losW(cc,7,oc,7)){bd=d;best=o;}}
            if(!best)break;hit.push(best);pl.pts.push(ecen(best));cur=best;}
          pl.hits=hit;pl.end=pl.pts[pl.pts.length-1];}
      } else {pl.blocked=true;pl.end=clampRay(pc,7,tc,7);pl.pts=[pc,pl.end];pl.hits=[];}
    } else {pl.noTarget=true;pl.end=along(150,P.aim);pl.pts=[pc,pl.end];pl.a=P.aim;}
    if(kind==='area'){
      pl.r=AIM_AREA_R[id];
      if(!pl.blocked&&!pl.noTarget){const c={x:pl.end.x,y:pl.end.y+6};
        pl.hits=B.ens.filter(o=>!o.dying&&(o===tg||(Math.hypot(ecen(o).x-c.x,ecen(o).y-c.y)<pl.r+eRad(o)*.5&&losW(c,7,ecen(o),7))));}
    }
  }
  return pl;
}
/* No dashed beams, footprints or reticles any more (not while a card is held, dragged or selected): the only feedback is the AIM frame on the
   card, the banner (drawExpAim) and the ripple where the cast lands. aimPlan() stays as pure geometry for the card logic and tests. */
function drawAimPreview(){drawExpAim();}
