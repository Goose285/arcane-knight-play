/* TELEPORT card (rare): blink to the spot you tap (or 150px ahead with no aim), up to 220px away - over pits, walls and monsters, never into
   one. A short burst of invulnerability on arrival. */
{const c={id:'teleport',name:'TELEPORT',lab:'TELEPORT',col:'#9a7aff',pow:0,rar:'rare',desc:'Blink to a chosen spot (or ahead), i-frames'};CARDS.push(c);CARD.teleport=c;}
EXP_GROUND.add('teleport');
const TELEPORT_MAX=220;
function teleportDest(){
  const from={x:P.x,y:P.y};let to;
  if(B.xt){to={x:B.xt.x,y:B.xt.y+12};if(B.xt.e){const a=Math.atan2(to.y-from.y,to.x-from.x);to={x:to.x-Math.cos(a)*40,y:to.y-Math.sin(a)*40};}}
  else{const a=dashAngle();to={x:from.x+Math.cos(a)*150,y:from.y+Math.sin(a)*150};}
  let dx=to.x-from.x,dy=to.y-from.y,d=Math.hypot(dx,dy);if(d>TELEPORT_MAX){to={x:from.x+dx/d*TELEPORT_MAX,y:from.y+dy/d*TELEPORT_MAX};d=TELEPORT_MAX;}
  for(let k=d;k>=8;k-=6){const x=from.x+dx/(Math.hypot(dx,dy)||1)*k,y=from.y+dy/(Math.hypot(dx,dy)||1)*k;
    if(!bodyBlocked(x,y)&&!B.ens.some(e=>!e.dying&&Math.hypot(e.x-x,e.y-y)<eRad(e)+8))return {x,y};}
  return null;
}
CAST.teleport=function(){
  const to=teleportDest();if(!to){floatText(P.x,P.y-40,'NO ROOM','#ffb0a0',11);return;}
  const from={x:P.x,y:P.y};burst(from.x,from.y-12,'#9a7aff',16,140,.5);
  P.x=to.x;P.y=to.y;B.inv=Math.max(B.inv,.6);B.ghost=Math.max(B.ghost||0,.4);sfx('whoosh');
  burst(to.x,to.y-12,'#d8ccff',18,150,.6);floatText(to.x,to.y-46,'BLINK!','#d8ccff',12);
  if(P.rootT>0)P.rootT=0;
};
