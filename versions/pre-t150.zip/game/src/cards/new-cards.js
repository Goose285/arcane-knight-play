/* =====================================================================
   t135u CARDS
   - THUNDER FANG (epic): crackling lightning gathers in your hand, then you lunge in a straight line (up to 170px, never through walls),
     piercing EVERY foe on the way for heavy shock damage and a short stun. Invulnerable during the strike.
   - NINJA STAR (uncommon): a spinning steel star that pierces up to 2 foes and ricochets off walls twice.
   Plus CARD_INFO: a short, player-facing description of every card (the Cards menu shows it when you tap a card).
   ===================================================================== */
{const add=c=>{CARDS.push(c);CARD[c.id]=c;};
 add({id:'thunder',name:'THUNDER FANG',lab:'THUNDER',col:'#8fe8ff',pow:120,rar:'epic',desc:'Lightning lunge: pierces every foe on the line + stun'});
 add({id:'star',name:'NINJA STAR',lab:'STAR',col:'#c8d0e0',pow:34,rar:'uncommon',desc:'Spinning star: pierces 2 foes, bounces off walls'});}
(function(){
  SP.ic.thunder=makeSprite(16,16,g=>{rect(g,0,0,16,16,'#1a2a4a');ell(g,7,10,4,4,'#f2c9a0');rect(g,4,10,7,5,'#f2c9a0');rect(g,3,9,2,4,'#f2c9a0');
    line(g,8,1,5,6,'#ffffff');line(g,5,6,9,6,'#ffffff');line(g,9,6,6,11,'#bff6ff');line(g,12,2,10,7,'#8fe8ff');line(g,13,8,15,12,'#8fe8ff');line(g,1,4,3,8,'#8fe8ff');rect(g,7,9,1,1,'#ffffff');});
  SP.ic.star=makeSprite(16,16,g=>{tri(g,8,0,6,8,10,8,'#d8dce8');tri(g,8,16,6,8,10,8,'#9aa0b4');tri(g,0,8,8,6,8,10,'#c8ccd8');tri(g,16,8,8,6,8,10,'#aab0c4');ell(g,8,8,2,2,'#4a4e5e');rect(g,8,8,1,1,'#14182c');rect(g,7,3,1,1,'#ffffff');});
})();
CAST.thunder=function(ch,m,a){
  let ang=dashAngle();const l0=swordLock(170);if(l0)ang=l0.a;
  const pc=pcen();burst(pc.x,pc.y-4,'#bff6ff',14,90,.35);sfx('charge');B.inv=Math.max(B.inv,.5);
  schedule(.18,()=>{
    const from={x:P.x,y:P.y},to=stepDest(ang,170);
    const hit=new Set();
    for(const e of B.ens){if(e.dying)continue;const c=ecen(e);const dx=to.x-from.x,dy=to.y-from.y,L2=dx*dx+dy*dy||1;let t=((c.x-from.x)*dx+(c.y-12-from.y+12)*dy)/L2;t=clamp(t,0,1);
      if(Math.hypot(from.x+dx*t-c.x,from.y-12+dy*t-c.y)<eRad(e)+20)hit.add(e);}
    B.bolts.push({k:'zap',pts:[{x:from.x,y:from.y-12},{x:(from.x+to.x)/2+R(-8,8),y:(from.y+to.y)/2-12+R(-8,8)},{x:to.x,y:to.y-12}],t:0,dur:.45});
    P.x=to.x;P.y=to.y;P.aim=ang;P.dir=dirOfAngle(ang);B.inv=Math.max(B.inv,.5);B.ghost=Math.max(B.ghost||0,.3);sfx('zap');B.shake=Math.max(B.shake,.35);
    for(let i=0;i<14;i++){const u=i/13;B.parts.push({x:lerp(from.x,to.x,u),y:lerp(from.y,to.y,u)-R(6,20),vx:R(-30,30),vy:-R(10,50),t:0,life:.45,col:i%2?'#ffffff':'#8fe8ff',sz:3});}
    for(const e of hit){if(e.dying)continue;damageEnemy(e,ch.pow*m,'zap');if(!e.dying)stunEnemy(e,.8);const c=ecen(e);burst(c.x,c.y,'#bff6ff',10,140,.35);}
    if(hit.size)floatText(P.x,P.y-50,hit.size>1?'PIERCE x'+hit.size+'!':'THUNDER FANG!','#bff6ff',13);
  });
};
CAST.star=function(ch,m,a){
  const pc=pcen();B.shootAnim=.15;sfx('whoosh');
  B.shots.push({x:pc.x,y:pc.y,vx:Math.cos(a)*360,vy:Math.sin(a)*360,r:7,dmg:ch.pow*m,own:'p',kind:'star',life:1.8,a,pierce:2,bounce:2});
};
function bounceShot(s,dt){
  s.x-=s.vx*dt;s.y-=s.vy*dt;const solidAt=(x,y)=>solidTile(Math.floor(x/TS),Math.floor(y/TS));
  if(solidAt(s.x+s.vx*dt*2,s.y))s.vx=-s.vx;else if(solidAt(s.x,s.y+s.vy*dt*2))s.vy=-s.vy;else{s.vx=-s.vx;s.vy=-s.vy;}
  s.hits=null;burst(s.x,s.y,'#e8ecf8',5,80,.25);sfx('clang');
}
function drawStarShot(s){
  const r=s.r+1,sp=gtime*22;ctx.save();ctx.translate(s.x,s.y);ctx.rotate(sp);
  ctx.fillStyle='rgba(200,210,230,.25)';ctx.beginPath();ctx.arc(0,0,r+5,0,6.283);ctx.fill();
  for(let i=0;i<4;i++){ctx.rotate(Math.PI/2);ctx.fillStyle=i%2?'#c8ccd8':'#eef0f8';ctx.beginPath();ctx.moveTo(0,-r-3);ctx.lineTo(3,0);ctx.lineTo(-3,0);ctx.closePath();ctx.fill();}
  ctx.fillStyle='#4a4e5e';ctx.beginPath();ctx.arc(0,0,2.5,0,6.283);ctx.fill();ctx.restore();
}
/* short player-facing descriptions (tap a card in the Cards menu) */
const CARD_INFO={
  sword:'Swing your blade in a wide arc in front of you. Great up close.',
  fire:'Hurl a fireball. Foes it hits keep burning for a few seconds.',
  shield:'A magic barrier that blocks the next hit you take.',
  heal:'Restore 22% of your HP. Casting it again within 12s heals only half.',
  lance:'A spear of light that pierces through every foe in a line.',
  frostbolt:'Freeze one foe solid for a moment.',
  crimsonbolt:'Drain one foe: you heal a share of the damage.',
  chain:'Lightning jumps between up to 4 foes, a bit weaker each jump.',
  poison:'A toxic cloud that hurts foes standing in it for 5 seconds.',
  haste:'For 5s you move 45% faster and shoot 80% faster.',
  decoy:'A fake knight that pulls the monsters\' attention for 5s.',
  frostburst:'Freeze every foe in an area.',
  crimsonburst:'Drain every foe in an area to heal yourself.',
  quake:'A shockwave around you that stuns nearby foes.',
  shadow:'Dash through danger (never through walls). You cannot be hit while dashing.',
  ward:'A holy dome that blocks enemy shots for 3s.',
  reflect:'For 1.5s, shots that hit you bounce back at the shooter.',
  curse:'The target takes double damage for 6s.',
  wolf:'Summon a spirit wolf that hunts foes for 10s.',
  meteor:'Call a meteor: after a short delay it smashes the target area.',
  drain:'A 2s beam: you heal half of the damage it deals.',
  timestop:'Freeze all foes for 2s (bosses are only slowed).',
  dragonfire:'Breathe a huge cone of dragonfire.',
  teleport:'Blink to the spot you tap (or straight ahead). Brief invulnerability.',
  thunder:'Lightning gathers in your hand, then you lunge forward, piercing EVERY foe on the line and stunning them.',
  star:'Throw a spinning ninja star. It pierces 2 foes and ricochets off walls twice.'};
function cardInfo(id){const c=CARD[id];return CARD_INFO[id]||(c&&c.desc)||'';}
