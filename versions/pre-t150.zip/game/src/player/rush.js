/* =====================================================================
   BOSS RUSH: fight clones of the bosses back to back in the Ember Arena. Score + local leaderboard (own localStorage key).
   Rush bosses give half XP/gold, no story flags, no loot. Dying ends the run (no gold penalty); the exit rune leaves between rounds.
   ===================================================================== */
const RUSH={mode:'rush',boons:[],on:false,round:0,score:0,t:0,rt:0,wait:0,cur:null,ret:null,result:null};
const RUSH_KEY='arcaneKnight.rush.v1';
function rushLoadLB(){try{const a=JSON.parse(localStorage.getItem(RUSH_KEY)||'[]');return Array.isArray(a)?a.filter(r=>r&&isFinite(r.score)).sort((x,y)=>y.score-x.score).slice(0,RUSH_CFG.keep):[];}catch(e){return [];}}
let RUSHLB=rushLoadLB();
function rushSaveLB(){if(NOSAVE)return;try{localStorage.setItem(RUSH_KEY,JSON.stringify(RUSHLB));}catch(e){}}
const rushTime=s=>Math.floor(s/60)+':'+String(Math.floor(s%60)).padStart(2,'0');
// the boss of a given round index: [type, level, affixes]
function rushPlan(round){
  const [type,lv0]=RUSH_ORDER[round%RUSH_ORDER.length],lap=Math.floor(round/RUSH_ORDER.length);
  const aff=[];if(lap>=1){const a=AFFIX_IDS.filter(i=>i!=='volatile');aff.push(a[(round*3+lap)%a.length]);}
  if(lap>=2){const a=AFFIX_IDS.filter(i=>i!=='volatile'&&i!==aff[0]);aff.push(a[(round*5+lap)%a.length]);}
  return {type,lv:lv0+lap*3,aff};
}
const rushRoundScore=(round,sec)=>500+250*round+Math.max(0,Math.round((90-sec)*10))+Math.round(P.hp/maxHp()*200);
function rushStart(mode){
  if(RUSH.on||!canTravel())return false;
  Object.assign(RUSH,{mode:mode==='weekly'?'weekly':'rush',boons:[],on:true,round:0,score:0,t:0,rt:0,wait:RUSH_CFG.prep,cur:null,ret:{x:P.x,y:P.y},result:null});
  P.hp=maxHp();state='play';UI.mode=null;startWarp(ARENA.start);return true;
}
function rushSpawn(){
  const wk=RUSH.mode==='weekly',pl=wk?weeklyPlan(RUSH.round):rushPlan(RUSH.round),e=mkEnemyObj(pl.type,ARENA.boss.x,ARENA.boss.y);
  e.rush=true;e.terr={x0:ARENA_TERR.tx0*TS+10,x1:(ARENA_TERR.tx1+1)*TS-10,y0:ARENA_TERR.ty0*TS+8,y1:(ARENA_TERR.ty1+1)*TS-1};
  e.elite=pl.aff.length?pl.aff.slice():null;
  applyLevel(e,pl.lv);e.baseLv=pl.lv;e.xpv=Math.round(e.xpv*RUSH_CFG.xpMul);e.gm*=RUSH_CFG.goldMul;
  if(wk)weeklyBuff(e,pl);
  enemies.push(e);RUSH.cur=e;RUSH.rt=0;
  toast((wk?'FLOOR ':'ROUND ')+(RUSH.round+1)+(wk?'/'+WEEKLY_CFG.floors:'')+':  '+e.def.name.toUpperCase()+'  Lv '+pl.lv+(pl.aff.length?'  ('+eliteName(e)+')':''),3,'#ff9a6a');
  startEncounter(e,false);
}
function rushClear(){
  const c=RUSH.cur,wk=RUSH.mode==='weekly',pts=wk?weeklyScore(rushRoundScore(RUSH.round,RUSH.rt)):rushRoundScore(RUSH.round,RUSH.rt);RUSH.score+=pts;dailyEvent('arena');
  toast((wk?'FLOOR ':'ROUND ')+(RUSH.round+1)+' CLEARED   +'+pts+'   (total '+RUSH.score+')',3,'#7dffa0');sfx('win');
  RUSH.round++;const i=enemies.indexOf(c);if(i>=0)enemies.splice(i,1);RUSH.cur=null;
  P.hp=Math.min(maxHp(),P.hp+Math.round(maxHp()*RUSH_CFG.healPct));P.grace=2;RUSH.wait=RUSH_CFG.prep+.5;
  if(wk){if(RUSH.boons.includes('feast'))P.hp=Math.min(maxHp(),P.hp+Math.round(maxHp()*.12));
    if(RUSH.round>=WEEKLY_CFG.floors){RUSH.wait=1e9;rushFinish('won');}else boonOffer(RUSH.round-1);}
  if(wk)ACH.s.bestFloor=Math.max(ACH.s.bestFloor,RUSH.round);else ACH.s.rushBest=Math.max(ACH.s.rushBest,RUSH.round);
}
function updateRush(dt){
  if(!RUSH.on||RUSH.mode==='lab'||WARP||state!=='play'||DLG||zoneOfPx(P.y)!=='arena')return;
  RUSH.t+=dt;
  if(B){if(RUSH.cur)RUSH.rt+=dt;return;}
  const c=RUSH.cur;
  if(c){if(!c.alive)rushClear();else{RUSH.wait-=dt;if(RUSH.wait<=0){c.engaged=false;startEncounter(c,false);RUSH.wait=1;}}return;}
  RUSH.wait-=dt;if(RUSH.wait<=0)rushSpawn();
}
// end of a run: record the score, clean up, go home. why: 'fell' | 'quit'
function rushFinish(why){
  if(!RUSH.on)return null;
  for(let i=enemies.length-1;i>=0;i--)if(enemies[i].rush)enemies.splice(i,1);
  const res={score:RUSH.score,rounds:RUSH.round,time:Math.round(RUSH.t),lv:P.lv,date:Date.now(),why,rank:0};
  const wk=RUSH.mode==='weekly';res.mode=RUSH.mode;
  if(wk)weeklyFinish(res,why);
  else if(res.rounds>=3)awardTrophy('laurel');
  if(!wk&&res.rounds>0){RUSHLB.push(res);RUSHLB.sort((a,b)=>b.score-a.score);RUSHLB=RUSHLB.slice(0,RUSH_CFG.keep);res.rank=RUSHLB.indexOf(res)+1;rushSaveLB();}
  RUSH.result=res;RUSH.on=false;RUSH.cur=null;P.hp=maxHp();P.grace=3;
  const to={x:RUSH.ret.x,y:RUSH.ret.y,dir:'d'};
  if(!B&&!WARP)startWarp(to);else{P.x=to.x;P.y=to.y;snapCam();}
  DLG={name:'ARENA MASTER',lines:[res.rounds?`Run over: ${res.rounds} round${res.rounds>1?'s':''} cleared, score ${res.score}, time ${rushTime(res.time)}.`:'You never cleared a round. The arena will wait.',res.rank?(res.rank===1?'A new record! Your name tops the board.':'You placed #'+res.rank+' on the leaderboard.'):'Come back stronger.'],i:0,c:0};
  if(wk)DLG=weeklyDlg(res);
  return res;
}
function rushLeave(){if(!RUSH.on||B)return;rushFinish('quit');}
/* the Arena Master in Oakvale */
NPCS.push({name:'Arena Master',x:16.5*TS,y:41.6*TS,spr:'guard',rush:true,lines:[]});
function openArenaMaster(){
  DLG={name:'ARENA MASTER',lines:['Welcome to the Ember Arena! Five champions, one after another, each lap stronger.','Heal only a little between rounds. Fall, and your score is posted on the board. Ready?'],i:0,c:0,yes:'ENTER',no:'BOARD',
    choice(){rushStart();},noAct(){openUIMode('rush','play');}};
}
