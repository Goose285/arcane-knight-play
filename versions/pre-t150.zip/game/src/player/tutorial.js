/* =====================================================================
   TUTORIAL / ONBOARDING: short guided steps on a New Game (once per device; replayable from Settings).
   Steps complete by watching real play (walk, shoot, talk, open menu, start a battle). Skippable (Tab / SKIP button).
   window.__NOTUT disables it (test pages).
   ===================================================================== */
const TUT={on:false,i:0,px:0,py:0,gap:0,skipR:null,flash:0};
const tutOff=()=>window.__NOTUT===true;
function tutStart(){if(tutOff())return false;Object.assign(TUT,{on:true,i:0,px:P.x,py:P.y,gap:.8,flash:0});return true;}
function tutMaybeStart(){return !SET.tutDone&&tutStart();}
function tutFinish(skipped){
  if(!TUT.on)return;TUT.on=false;TUT.skipR=null;
  if(!SET.tutDone&&!skipped){P.gold+=50;toast('TUTORIAL COMPLETE!  +50 G   (Replay any time: Pause > SETTINGS)',4,'#7dffa0');sfx('level');}
  else if(skipped)toast('Tutorial skipped  (Replay any time: Pause > SETTINGS)',3,'#cfd0ff');
  SET.tutDone=true;setSave();
}
function tutDone(id){
  switch(id){
    case 'move':return Math.hypot(P.x-TUT.px,P.y-TUT.py)>=90;
    case 'shoot':return hit('KeyJ');
    case 'talk':return !!DLG||(isUI()&&state!=='paused');
    case 'pause':return state==='paused';
    case 'fight':return !!B;
  }
  return false;
}
/* training slime: the 'fight' step needs a monster, so one is spawned right next to you (harmless, never notices you, drops nothing) */
const tutDummyOf=()=>enemies.find(e=>e.tut);
function tutSpawnDummy(){
  const old=tutDummyOf();if(old&&old.alive&&!old.dying&&Math.hypot(old.x-P.x,old.y-P.y)<260)return;
  if(old)enemies.splice(enemies.indexOf(old),1);
  const eye={x:P.x,y:P.y-12};
  for(const r of [96,80,120,64])for(const off of [0,.5,-.5,1,-1,1.6,-1.6,2.4,-2.4,Math.PI]){
    const a=P.aim+off,x=P.x+Math.cos(a)*r,y=P.y+Math.sin(a)*r;
    if(bodyBlocked(x,y)||!losClear(eye,{x,y:y-12}))continue;
    const e=mkEnemyObj('slime',0,0);e.x=e.hx=x;e.y=e.hy=y;enemies.push(e);e.terr=null;
    applyLevel(e,1);e.baseLv=1;e.tut=true;e.rush=true;e.mt=1e9;e.lk=1e9;e.name='TRAINING SLIME';return;}
}
function tutDummyTick(){
  const d=tutDummyOf();if(!d)return;
  if(B&&B.ens.includes(d)){d.atkCd=Math.max(d.atkCd||0,3);return;}   // harmless while fought
  if(!B&&(!TUT.on||!d.alive||d.dying||d.engaged===false&&!d.alive))enemies.splice(enemies.indexOf(d),1);
}
function updateTut(dt){
  tutDummyTick();
  if(TUT.on&&!tutOff()&&!B&&state==='play'&&TUT_STEPS[TUT.i]&&TUT_STEPS[TUT.i].id==='fight')tutSpawnDummy();
  if(!TUT.on||tutOff()){return;}
  if(hit('Tab')){tutFinish(true);return;}
  if(state!=='play'&&state!=='paused'&&!isUI())return;
  TUT.flash=Math.max(0,TUT.flash-dt);
  if(TUT.gap>0){TUT.gap-=dt;if(!(state==='play'))return;if(TUT.gap>0)return;TUT.px=P.x;TUT.py=P.y;}
  const st=TUT_STEPS[TUT.i];if(!st){tutFinish(false);return;}
  if(tutDone(st.id)){TUT.i++;TUT.gap=1;TUT.flash=.6;sfx('select');
    if(TUT.i>=TUT_STEPS.length)tutFinish(false);}
}
function drawTut(){
  TUT.skipR=null;
  if(!TUT.on||tutOff()||state!=='play'||DLG||B||TUT.i>=TUT_STEPS.length)return;
  const dm=tutDummyOf();
  if(dm&&dm.alive&&TUT_STEPS[TUT.i].id==='fight'){const sx=dm.x-cam.x,sy=dm.y-cam.y-34+Math.sin(gtime*4)*3;
    txt('TRAINING SLIME',sx,sy-14,{size:10,align:'center',col:'#ffe14d',lw:3});ctx.fillStyle='#ffe14d';ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(sx-6,sy-8);ctx.lineTo(sx+6,sy-8);ctx.closePath();ctx.fill();}
  const st=TUT_STEPS[TUT.i],w=Math.min(VW-SL-SR-24,380),x=Math.round(VW/2-w/2),h=62,y=VH-SB-h-(TOUCH?(VH>VW?160:14):34);
  const txtS=TOUCH?st.t:st.k,font='bold '+scaleText(11)+'px "Courier New",monospace',ls=wrapText(txtS,w-24,font);
  const hh=Math.max(h,44+ls.length*14);const yy=y-(hh-h);
  ctx.save();ctx.globalAlpha=TUT.gap>0?.6:1;
  panel(x,yy,w,hh,{fill:'#0f1c34',border:'#7dd3ff'});
  txt('TUTORIAL  '+(TUT.i+1)+'/'+TUT_STEPS.length,x+10,yy+16,{size:10,col:'#7dd3ff',lw:2});
  ls.forEach((l,k)=>txt(l,x+10,yy+33+k*14,{size:11,out:false}));
  for(let i=0;i<TUT_STEPS.length;i++){ctx.fillStyle=i<TUT.i?'#7dffa0':i===TUT.i?'#ffe14d':'#2c3a5a';ctx.fillRect(x+10+i*14,yy+hh-12,10,5);}
  const sk={x:x+w-64,y:yy+hh-24,w:56,h:18};TUT.skipR=sk;ctx.fillStyle='#2a3a5a';ctx.fillRect(sk.x,sk.y,sk.w,sk.h);
  txt(TOUCH?'SKIP':'Tab: skip',sk.x+sk.w/2,sk.y+13,{size:9,align:'center',col:'#cfe0ff',out:false});
  ctx.restore();
}
