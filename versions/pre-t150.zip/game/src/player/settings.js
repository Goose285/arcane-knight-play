/* =====================================================================
   SETTINGS: volume (master/music/sfx), text size, colour-blind assist, left-handed touch layout, gamepad.
   Stored in their own localStorage key so they survive New Game and are shared by every save.
   ===================================================================== */
const SET={...SET_DEFAULT};
const cl01=v=>Math.round(clamp(+v,0,1)*10)/10;
function setLoad(){
  let o={};try{o=JSON.parse(localStorage.getItem(SET_KEY)||'{}')||{};}catch(e){}
  for(const k of ['master','music','sfx'])SET[k]=Number.isFinite(o[k])?cl01(o[k]):SET_DEFAULT[k];
  if('perf' in o)SET.perf=!!o.perf; else SET.perf=SET_DEFAULT.perf;
  if('fps' in o)SET.fps=!!o.fps; else SET.fps=SET_DEFAULT.fps;
  SET.text=Number.isFinite(o.text)?clamp(o.text|0,0,TEXT_SIZES.length-1):0;SET.cb=Number.isFinite(o.cb)?clamp(o.cb|0,0,CB_MODES.length-1):0;
  SET.pop=Number.isFinite(o.pop)?clamp(o.pop|0,0,POP_STYLES.length-1):0;SET.lefty=o.lefty===true;SET.pad=o.pad!==false;SET.tutDone=o.tutDone===true;
}
function setSave(){if(NOSAVE)return;try{localStorage.setItem(SET_KEY,JSON.stringify(SET));}catch(e){}}
const sfxVol=()=>SET.master*SET.sfx;
const musVol=()=>SET.master*SET.music;
function setVol(key,delta){SET[key]=cl01(SET[key]+delta);setSave();sfx('select');}
function cbMatrix(id){                                   // 4x5 colour matrix (20 numbers) or null for 'off':  out = I + E * (I - Sim)
  if(!CB_SIM[id])return null;const S=CB_SIM[id],E=CB_ERR[id],out=[];
  for(let r=0;r<3;r++){for(let c=0;c<3;c++){let v=r===c?1:0;for(let k=0;k<3;k++)v+=E[r][k]*((k===c?1:0)-S[k][c]);out.push(v);}out.push(0,0);}
  // rows are [r,g,b,a,offset]: the loop pushed r,g,b,0,0 per row
  out.push(0,0,0,1,0);return out;
}
function cbApply(){
  if(!document.getElementById('cb-defs')){
    const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg');svg.id='cb-defs';svg.setAttribute('width','0');svg.setAttribute('height','0');svg.style.position='absolute';
    const defs=document.createElementNS(ns,'defs');
    for(const m of CB_MODES){const mx=cbMatrix(m.id);if(!mx)continue;const f=document.createElementNS(ns,'filter');f.id='cbf-'+m.id;f.setAttribute('color-interpolation-filters','sRGB');
      const fe=document.createElementNS(ns,'feColorMatrix');fe.setAttribute('type','matrix');fe.setAttribute('values',mx.map(v=>v.toFixed(5)).join(' '));f.appendChild(fe);defs.appendChild(f);}
    svg.appendChild(defs);document.body.appendChild(svg);}
  const id=CB_MODES[SET.cb].id;cv.style.filter=id==='off'?'':'url(#cbf-'+id+')';
}
function setApply(){TXS=TEXT_SIZES[SET.text].k;LEFTY=SET.lefty;cbApply();if(typeof layoutTouch==='function')layoutTouch();try{if(typeof qualApply==='function')qualApply();}catch(e){}}
function setCycle(key,n,dir){SET[key]=(SET[key]+(dir||1)+n)%n;setSave();setApply();sfx('select');}
function setToggle(key){SET[key]=!SET[key];setSave();setApply();sfx('select');}
setLoad();
/* ---- gamepad: standard mapping. Stick / d-pad move (held keys), buttons press keys. ---- */
const PAD={on:false,id:'',held:{},axis:{x:0,y:0},mem:{}};
function padKey(code,down){
  if(down&&!PAD.held[code]){PAD.held[code]=true;keys[code]=true;pressed[code]=true;}
  else if(!down&&PAD.held[code]){PAD.held[code]=false;keys[code]=false;released[code]=true;}
}
function padReleaseAll(){for(const c in PAD.held)if(PAD.held[c])padKey(c,false);}
function pollPad(){
  let gp=null;try{const l=navigator.getGamepads?navigator.getGamepads():[];for(const g of l)if(g&&g.connected){gp=g;break;}}catch(e){}
  if(!gp||!SET.pad){if(PAD.on){padReleaseAll();PAD.on=false;}return;}
  if(!PAD.on){PAD.on=true;PAD.id=gp.id;toast('Gamepad connected: '+String(gp.id).slice(0,28),2.6,'#9ad0ff');}
  const ax=gp.axes||[],bt=gp.buttons||[],dz=.4,x=ax[0]||0,y=ax[1]||0,b=i=>!!(bt[i]&&(bt[i].pressed||bt[i].value>.5));
  PAD.axis.x=x;PAD.axis.y=y;
  padKey('KeyA',x<-dz);padKey('KeyD',x>dz);padKey('KeyW',y<-dz);padKey('KeyS',y>dz);
  const ui=state!=='play'||!!DLG,want={};
  for(const i in PAD_MAP){const c=PAD_MAP[i];want[c]=want[c]||b(+i);}
  want.Enter=b(0)&&ui;want.Escape=b(1)&&ui;want.KeyE=b(1)&&!ui;want.Space=b(0)&&state==='title';
  for(const c in want)padKey(c,!!want[c]);
}
