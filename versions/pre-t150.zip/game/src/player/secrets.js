/* =====================================================================
   SECRETS + FAST TRAVEL STATE: waystones, cracked walls, hidden chests, treasure maps
   ===================================================================== */
const SEC={ways:{village:true},broken:{},opened:{},maps:{},dug:{}};
function resetSecrets(){SEC.ways={village:true};SEC.broken={};SEC.opened={};SEC.maps={};SEC.dug={};SEC.chest2={};}
const keyOf=(tx,ty)=>tx+','+ty;
function applySecrets(){      // re-apply persistent world changes after load/new game
  for(const k in SEC.broken){const [x,y]=k.split(',').map(Number);if(map[y]&&map[y][x]===T.GB)map[y][x]=T.CV;}
  for(const c of CHESTS)map[c.ty][c.tx]=SEC.opened[c.id]?T.CO:T.CH;
}
function resetSecretWorld(){for(const id in ZONE_Y0)map[ZONE_Y0[id]+29][30]=T.GB;}
function packSecrets(){return {ways:SEC.ways,broken:SEC.broken,opened:SEC.opened,maps:SEC.maps,dug:SEC.dug,chest2:SEC.chest2};}
function unpackSecrets(s){resetSecretWorld();resetSecrets();if(s){for(const k of ['ways','broken','opened','maps','dug','chest2'])if(s[k]&&typeof s[k]==='object')for(const i in s[k])if(s[k][i])SEC[k][i]=true;SEC.ways.village=true;}applySecrets();}
function activateWay(id){
  if(SEC.ways[id])return false;SEC.ways[id]=true;
  const w=WAYSTONES.find(q=>q.id===id),n=NPCS.find(q=>q.way===id);
  toast('Waystone Unlocked: '+w.name,3.2,'#7df9ff');sfx('level');sfx('select');
  if(n){n.fxT=gtime;for(let i=0;i<3;i++)wfxBurst(n.x,n.y-22,i?'#d8fdff':'#7df9ff',16,i?60:130,1.1);}   // light-up burst; the rising sparkles are drawn with the stone
  return true;
}
/* walking within ~2 tiles of a waystone attunes it: no interaction needed */
const WAY_AUTO_R=2*TS;
function updateWaystones(){
  if(B||state!=='play'||WARP||DLG)return;
  for(const n of NPCS){if(!n.way||SEC.ways[n.way])continue;if(Math.hypot(n.x-P.x,n.y-22-(P.y-8))<=WAY_AUTO_R||Math.hypot(n.x-P.x,n.y-P.y)<=WAY_AUTO_R){activateWay(n.way);saveGame('waystone');}}
}
function wayDest(w){return w.zone?zoneArrive(w.zone):{...w.to,dir:'d'};}
const wayHere=()=>{const z=zoneOfPx(P.y);return ZONES[z]?z:null;};
function canTravel(){return !B&&!WARP&&state!=='title';}
function fastTravel(id){
  const w=WAYSTONES.find(q=>q.id===id);if(!w||!SEC.ways[id]||!canTravel())return false;
  state='play';UI.mode=null;startWarp(wayDest(w));return true;
}
/* waystone NPCs */
WAYSTONES.forEach(w=>{if(w.tx!=null)NPCS.push({name:w.name,way:w.id,x:(w.tx+.5)*TS,y:(w.ty+.9)*TS,spr:'waystone',lines:[]});});
WAYSTONES.filter(w=>w.zone).forEach(w=>{const a=zoneArrive(w.zone);NPCS.push({name:w.name,way:w.id,x:a.x+44,y:a.y-20,spr:'waystone',lines:[]});});
function openWaystone(n){
  const fresh=activateWay(n.way);
  DLG={name:n.name,lines:[fresh?'The stone flares with pale light. You can now travel here from any waystone.':'The waystone hums softly.','Travel to another waystone?'],i:0,c:0,yes:'TRAVEL',no:'STAY',
    choice(){openUIMode('travel','play');},noAct(){}};
}
/* world interaction in front of the hero: cracked walls, chests, treasure-map dig spots */
function frontTile(){const v={l:[-1,0],r:[1,0],u:[0,-1],d:[0,1]}[P.dir]||[0,1];return [Math.floor((P.x+v[0]*16)/TS),Math.floor((P.y-6+v[1]*16)/TS)];}
function chestReward(c){
  const lines=[],rar=['rare','rare','epic'][RI(0,2)],cc=randCardOf(rar);
  if(cc){const had=COL[cc.id]||0;grantCard(cc.id);lines.push((had>=RAR[cc.rar].own?'dupe ':'')+cc.name);}
  const g=genGear(null,Math.max(P.lv,8),'epic',false);addGear(g);lines.push(g.name);
  const gold=RI(150,260);P.gold+=gold;lines.push(gold+' G');addMat('shard',3);lines.push('3 Arcane Shards');
  return lines;
}
function tryInteract(){
  const [fx,fy]=frontTile();
  for(const [tx,ty] of [[fx,fy],[Math.floor(P.x/TS),Math.floor((P.y-6)/TS)]]){
    if(ty<0||ty>=MH||tx<0||tx>=MW)continue;
    const t=map[ty][tx];
    if(t===T.CHST&&openChestAt(tx,ty))return true;
    if(t===T.GB){SEC.broken[keyOf(tx,ty)]=true;map[ty][tx]=T.CV;sfx('quake');toast('The cracked wall crumbles!',2.6,'#ffe9a0');return true;}
    if(t===T.CH){const c=CHESTS.find(q=>q.tx===tx&&q.ty===ty);if(c){SEC.opened[c.id]=true;map[ty][tx]=T.CO;sfx('level');const l=chestReward(c);if(typeof revealChest==='function')revealChest(3,l);toast('HIDDEN CHEST: '+l.join(', '),4.5,'#ffd23f');saveGame('chest');return true;}}
  }
  for(const m of TMAPS){
    if(!SEC.maps[m.id]||SEC.dug[m.id])continue;
    if(Math.hypot(P.x-(m.x*TS+16),P.y-(m.y*TS+16))<30){SEC.dug[m.id]=true;sfx('coin');const had=COL[m.card]||0;grantCard(m.card);toast('You dig up a buried chest... '+CARD[m.card].name+'!',4,'#ffd23f');P.gold+=120;saveGame('dig');return true;}
  }
  return false;
}
function secretOnKill(e){
  for(const m of TMAPS)if(m.from===e.type&&!SEC.maps[m.id]){SEC.maps[m.id]=true;toast('Found a '+m.name+'! An X marks a spot in the overworld.',4.5,'#ffe9a0');}
  const w=WAYSTONES.find(q=>q.zone&&ZONES[q.zone].boss===e.type);
}
function drawMapMarks(){
  for(const m of TMAPS){if(!SEC.maps[m.id]||SEC.dug[m.id])continue;
    const x=m.x*TS+16-cam.x,y=m.y*TS+22-cam.y;if(x<-20||y<-20||x>VW+20||y>VH+20)continue;
    ctx.save();ctx.globalAlpha=.7+.3*Math.sin(gtime*5);ctx.strokeStyle='#3a1a0a';ctx.lineWidth=5;ctx.beginPath();ctx.moveTo(x-7,y-7);ctx.lineTo(x+7,y+7);ctx.moveTo(x+7,y-7);ctx.lineTo(x-7,y+7);ctx.stroke();
    ctx.strokeStyle='#ffd23f';ctx.lineWidth=3;ctx.stroke();ctx.restore();}
}
