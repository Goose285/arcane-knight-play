/* =====================================================================
   TAP-TO-TALK / TAP-TO-FISH: tap (or click) an NPC - or a rippling fishing spot - and you talk to them / cast a line when in range;
   if you are out of range you first walk there on a path around obstacles. Any steering input, a fight or a dialog cancels the walk.
   ===================================================================== */
const GOTO={k:null,ref:null,path:[],i:0,t:0,lx:0,ly:0,st:0};
const NPC_TALK_R=44;
function worldTapOk(){return state==='play'&&!B&&!DLG&&!WARP&&!RUSH.on&&!FISH.on&&!isUI()&&!STORY.cutting&&!(STORY.queue);}
/* what is under a screen point (generous boxes): {k:'npc',ref}|{k:'spot',ref}|null */
function worldTargetAt(p){
  if(!worldTapOk())return null;
  const wx=p.x+cam.x,wy=p.y+cam.y,zn=zoneOfPx(P.y);let best=null,bd=1e9;
  for(const n of NPCS){if(zoneOfPx(n.y)!==zn)continue;const dx=wx-n.x,dy=wy-(n.y-18);
    if(Math.abs(dx)<27&&dy>-36&&dy<32){const d=Math.hypot(dx,dy*.8);if(d<bd){bd=d;best={k:'npc',ref:n};}}}
  if(zn==='ow'&&wx>HOUSE_DOOR.tx*TS-10&&wx<(HOUSE_DOOR.tx+1)*TS+10&&wy>(HOUSE_DOOR.ty-1.6)*TS&&wy<(HOUSE_DOOR.ty+.7)*TS&&bd>1e8)best={k:'door',ref:HOUSE_FRONT};   // the front door of your house
  for(const s of FISH_SPOTS){const c=spotCenter(s);if(zoneOfPx(c.y)!==zn)continue;const r=s.pond?s.pond.w*TS*.5+14:34;
    if(Math.hypot(wx-c.x,(wy-c.y)*1.25)<r){const d=Math.hypot(wx-c.x,wy-c.y)+8;if(d<bd){bd=d;best={k:'spot',ref:s};}}}
  return best;
}
const gotoPos=t=>t.k==='npc'||t.k==='door'?{x:t.ref.x,y:t.ref.y}:spotCenter(t.ref);
function gotoInRange(t){return t.k==='npc'?Math.hypot(t.ref.x-P.x,t.ref.y-P.y)<NPC_TALK_R:t.k==='door'?Math.hypot(t.ref.x-P.x,t.ref.y-P.y)<22:spotDist(t.ref)<FISH_REACH;}
function gotoArrive(t){
  const c=gotoPos(t);P.moving=false;P.anim=0;
  if(t.k==='door'){P.dir='u';enterHouse();}
  else if(t.k==='npc'){const dx=c.x-P.x,dy=c.y-P.y;P.dir=Math.abs(dx)>Math.abs(dy)?(dx<0?'l':'r'):(dy<0?'u':'d');openDlg(t.ref);}
  else startFishing(t.ref);
}
const gotoBoxFree=(x,y)=>{for(const [cx,cy] of [[x-6,y-7],[x+6,y-7],[x-6,y],[x+6,y]])if(solidTile(Math.floor(cx/TS),Math.floor(cy/TS)))return false;return true;};
const gotoSegClear=(a,b)=>{const n=Math.ceil(Math.hypot(b.x-a.x,b.y-a.y)/5);for(let i=1;i<=n;i++){if(!gotoBoxFree(a.x+(b.x-a.x)*i/n,a.y+(b.y-a.y)*i/n))return false;}return true;};
function gotoPath(t){
  const c=gotoPos(t),W=MW,sx=Math.floor(P.x/TS),sy=Math.floor((P.y-4)/TS),goalR=t.k==='door'?18:t.k==='npc'?NPC_TALK_R-8:FISH_REACH-12;
  const isGoal=(x,y)=>{const px=x*TS+16,py=y*TS+24;
    if(t.k==='door')return Math.hypot(c.x-px,c.y-py)<=goalR;
    if(t.k==='npc'){if(Math.hypot(c.x-px,c.y-py)>goalR)return false;return !(Math.abs(c.x-px)<14&&Math.abs(c.y-py)<12);}
    return Math.hypot(c.x-px,c.y-10-py)<goalR||Math.hypot(c.x-px,c.y-py)<goalR;};
  const prev=new Int32Array(W*MH).fill(-2),q=[sy*W+sx];prev[sy*W+sx]=-1;let goal=-1;
  for(let h=0;h<q.length;h++){const cur=q[h],x=cur%W,y=(cur/W)|0;
    if(isGoal(x,y)&&gotoBoxFree(x*TS+16,y*TS+24)){goal=cur;break;}
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=W||ny>=MH||prev[ny*W+nx]!==-2)continue;
      if(solidTile(nx,ny))continue;prev[ny*W+nx]=cur;q.push(ny*W+nx);}}
  if(goal<0)return null;
  const tiles=[];for(let c2=goal;c2>=0;c2=prev[c2])tiles.push({x:(c2%W)*TS+16,y:((c2/W)|0)*TS+24});tiles.reverse();
  const out=[];let from={x:P.x,y:P.y};                                    // string-pull: skip waypoints we can walk to in a straight line
  for(let i=0;i<tiles.length;i++){const nxt=tiles[i+1];if(nxt&&gotoSegClear(from,nxt))continue;out.push(tiles[i]);from=tiles[i];}
  return out;
}
function setGoto(t){
  if(!t||!worldTapOk())return false;
  if(gotoInRange(t)){GOTO.k=null;gotoArrive(t);return true;}
  const path=gotoPath(t);if(!path){toast("You can't reach that from here",1.8,'#ffb0a0');return false;}
  Object.assign(GOTO,{k:t.k,ref:t.ref,path,i:0,t:0,lx:P.x,ly:P.y,st:0});sfx('select');return true;
}
const gotoManual=()=>held(...K_L)||held(...K_R)||held(...K_U)||held(...K_D)||(joy.on&&Math.hypot(joy.x,joy.y)>.2);
function updateGoto(dt){
  if(!GOTO.k)return;
  if(B||DLG||WARP||FISH.on||state!=='play'||gotoManual()){GOTO.k=null;return;}
  const t={k:GOTO.k,ref:GOTO.ref};
  if(gotoInRange(t)){GOTO.k=null;gotoArrive(t);return;}
  GOTO.t+=dt;if(GOTO.t>16){GOTO.k=null;return;}
  const wp=GOTO.path[GOTO.i];
  if(!wp){GOTO.k=null;return;}
  if(Math.hypot(wp.x-P.x,wp.y-P.y)<5){GOTO.i++;if(GOTO.i>=GOTO.path.length){GOTO.k=null;}return;}
  GOTO.st+=dt;if(GOTO.st>.5){if(Math.hypot(P.x-GOTO.lx,P.y-GOTO.ly)<6){GOTO.k=null;return;}GOTO.lx=P.x;GOTO.ly=P.y;GOTO.st=0;}
}
function gotoDir(){const wp=GOTO.k&&GOTO.path[GOTO.i];if(!wp)return null;const dx=wp.x-P.x,dy=wp.y-P.y,l=Math.hypot(dx,dy);return l<1?null:[dx/l,dy/l,1];}
/* a click / short tap on the world */
function worldTap(p){const t=worldTargetAt(p);if(!t)return false;return setGoto(t);}
/* destination marker while walking */
function drawGotoMark(){
  if(!GOTO.k)return;const c=GOTO.k==='npc'?{x:GOTO.ref.x,y:GOTO.ref.y-52}:spotCenter(GOTO.ref);
  ctx.save();ctx.globalAlpha=.7+.3*Math.sin(gtime*8);ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.beginPath();ctx.arc(c.x-cam.x,c.y-cam.y+(GOTO.k==='npc'?0:0),10+Math.sin(gtime*6)*2,0,6.283);ctx.stroke();ctx.restore();
}
