/* =====================================================================
   SKIPPING THE NIGHT: Innkeeper Rosa (the quiet house in the north-west of Oakvale) rents a bed until morning for a small fee, and
   Father Anselm lets you rest on a pew for free after his blessing. Both fade to morning, heal you fully, refill the wilds and save.
   Only offered from dusk to dawn.
   ===================================================================== */
NPCS.push({name:'Innkeeper Rosa',x:7.5*TS,y:33.4*TS,spr:'keeper',inn:true,lines:[]});
const innCost=()=>Math.min(40,8+P.lv*2);
function openInn(npc){
  const c=innCost();
  if(!isEvening()){
    DLG={name:'INNKEEPER ROSA',lines:['Welcome to the Oakvale Inn! The beds are warm and the soup is hot.','It is broad daylight, hero - the rooms are quiet until dusk. Come back when the sun goes down and I will let you sleep till morning.'],i:0,c:0};return;}
  let short=false;
  DLG={name:'INNKEEPER ROSA',lines:['Late on the road, are you? The wild is no place to be after dark.',`A bed until morning is ${c} gold. You will wake rested, and the valley will be fresh with the dawn.`],i:0,c:0,yes:`SLEEP  ${c}G`,no:'NO THANKS',
    choice(){short=P.gold<c;if(!short)sleepToMorning(c,'You sleep soundly at the inn... Good morning!');},
    after:()=>short?{name:'INNKEEPER ROSA',lines:['Oh, dear - you are a little short. Come back when you have '+c+' gold, hero.'],i:0,c:0}:null,noAct(){DLG=null;}};
}
function chapelRestDlg(word){
  return {name:'FATHER ANSELM',lines:[word,'The night still lies on the valley. You are welcome to rest on a pew until morning.'],i:0,c:0,yes:'REST',no:'NO',
    choice(){sleepToMorning(0,'You rest in the chapel until morning. Peace be with you.');},noAct(){DLG=null;}};
}
