/* =====================================================================
   GEAR STATE + LOGIC: inventory, equipped slots, stat totals, generation, drops, sell
   ===================================================================== */
const GEAR={inv:[],eq:{weapon:null,armor:null,ring:null},uid:1};
const INV_MAX=40;
function resetGear(){GEAR.inv=[];GEAR.eq={weapon:null,armor:null,ring:null};GEAR.uid=1;}
function gearStats(){
  const t={shot:0,hp:0,def:0,gauge:0,crit:0};
  for(const s of GEAR_SLOTS){const it=GEAR.eq[s];if(it)for(const k in it.st)t[k]+=it.st[k];}
  const sk=skillStats();for(const k in sk)t[k]+=sk[k];
  return t;
}
const gearScore=it=>!it?0:(it.st.shot||0)*3+(it.st.hp||0)/4+(it.st.def||0)*3+(it.st.gauge||0)*120+(it.st.crit||0)*160;
function pickGW(w){let t=0;for(const k in w)t+=w[k];let r=Math.random()*t;for(const k in w){r-=w[k];if(r<=0)return k;}return 'common';}
function genGear(slot,L,rar,boss){
  slot=slot||GEAR_SLOTS[RI(0,2)];L=Math.max(1,L|0);rar=rar||pickGW(gearRarityWeights(L));
  const ri=GEAR_RAR_ORDER.indexOf(rar),def=GEAR_RAR[rar],st={};
  const prim=GEAR_PRIMARY[slot]||GEAR_POOL.ring[RI(0,2)];                 // rings roll a random primary
  st[prim]=GEAR_ROLL[prim](L,def.mult);
  if(slot==='armor')st.def=GEAR_ROLL.def(L,def.mult*.8);
  const pool=GEAR_POOL[slot].filter(k=>!(k in st)),n=Math.min(def.aff,pool.length);
  for(let i=0;i<n;i++){const k=pool.splice(RI(0,pool.length-1),1)[0];st[k]=GEAR_ROLL[k](L,def.mult*.75);}
  const names=boss?GEAR_BASES_BOSS[slot]:GEAR_BASES[slot];
  let base=boss?names[ri>=4?1:0]:names[Math.min(names.length-1,ri)];
  const name=(!boss&&ri>=1)?base+' '+GEAR_SUFFIX[prim]:base;
  return {id:GEAR.uid++,slot,rar,lv:L,name,st,boss:!!boss};
}
const gearSell=it=>Math.round(GEAR_RAR[it.rar].sell*(1+it.lv*.22));
function addGear(it){
  if(GEAR.inv.length>=INV_MAX){ // backpack full: auto-sell the weakest non-equipped item
    let w=0;GEAR.inv.forEach((x,i)=>{if(gearScore(x)<gearScore(GEAR.inv[w]))w=i;});const gone=GEAR.inv.splice(w,1)[0];P.gold+=gearSell(gone);}
  GEAR.inv.push(it);if(typeof revealItem==='function'&&!window.__NOREVEAL_ITEM)revealItem(it);return it;
}
function equipGear(it){
  const i=GEAR.inv.indexOf(it);if(i<0)return false;
  const old=GEAR.eq[it.slot];GEAR.inv.splice(i,1);if(old)GEAR.inv.push(old);GEAR.eq[it.slot]=it;
  P.hp=Math.min(P.hp,maxHp());return true;
}
function unequipGear(slot){const it=GEAR.eq[slot];if(!it||GEAR.inv.length>=INV_MAX)return false;GEAR.eq[slot]=null;GEAR.inv.push(it);P.hp=Math.min(P.hp,maxHp());return true;}
function sellGear(it){const i=GEAR.inv.indexOf(it);if(i<0)return 0;GEAR.inv.splice(i,1);const g=gearSell(it);P.gold+=g;return g;}
const gearStatLine=it=>Object.keys(it.st).map(k=>(k==='gauge'||k==='crit'?'+'+Math.round(it.st[k]*100)+'%':'+'+it.st[k])+' '+GEAR_STAT_LABEL[k]).join('  ');
function packGear(){return {inv:GEAR.inv,eq:GEAR.eq,uid:GEAR.uid};}
function unpackGear(s){
  resetGear();if(!s)return;
  const ok=it=>it&&GEAR_SLOTS.includes(it.slot)&&GEAR_RAR[it.rar]&&it.st&&typeof it.st==='object';
  if(Array.isArray(s.inv))GEAR.inv=s.inv.filter(ok);
  for(const sl of GEAR_SLOTS)if(s.eq&&ok(s.eq[sl])&&s.eq[sl].slot===sl)GEAR.eq[sl]=s.eq[sl];
  GEAR.uid=Math.max(s.uid|0,1+Math.max(0,...GEAR.inv.map(x=>x.id|0),...GEAR_SLOTS.map(sl=>GEAR.eq[sl]?GEAR.eq[sl].id|0:0)));
}
/* drop roll on a kill (boss: guaranteed); returns the new item or null. The caller pushes it onto B.drops (full loot screen). */
function rollGearDrop(e){
  const L=e.lv||1,boss=!!(e.def&&e.def.boss);
  if(!boss&&Math.random()>(e.elite?Math.max(.7,gearDropChance(L)):gearDropChance(L)))return null;
  let rar;
  if(boss){rar=Math.random()<(e.type==='lich'?.5:.35)?'legendary':'epic';}
  else rar=pickGW(gearRarityWeights(L));
  return genGear(null,L,rar,boss);
}
