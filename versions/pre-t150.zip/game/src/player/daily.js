/* =====================================================================
   DAILY CHALLENGES + LOGIN CHEST (local clock; a new day = new seeded challenges and a chest).
   Disabled in the legacy test pages via window.__NOMETA so earlier suites keep exact gold/kill maths.
   ===================================================================== */
const metaOff=()=>window.__NOMETA===true;
let NOW_OVERRIDE=null;                                   // tests can freeze the clock
const nowMs=()=>NOW_OVERRIDE!=null?NOW_OVERRIDE:Date.now();
const setNow=ms=>{NOW_OVERRIDE=ms;};
function dayNum(ms){const d=new Date(ms==null?nowMs():ms);return Math.floor(Date.UTC(d.getFullYear(),d.getMonth(),d.getDate())/864e5);}
const weekNum=dn=>Math.floor(((dn==null?dayNum():dn)+3)/7);        // Monday-aligned week index
function seededRng(seed){let a=(seed>>>0)||1;return()=>{a=(a+0x6D2B79F5)>>>0;let t=a;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
const hashStr=s=>{let h=2166136261;for(let i=0;i<s.length;i++){h^=s.charCodeAt(i);h=Math.imul(h,16777619);}return h>>>0;};

const DAILY={day:-1,last:-1,streak:0,chestDay:-1,ch:[],bonus:false,total:0};
function resetDaily(){DAILY.day=-1;DAILY.last=-1;DAILY.streak=0;DAILY.chestDay=-1;DAILY.ch=[];DAILY.bonus=false;DAILY.total=0;}
function packDaily(){return {day:DAILY.day,last:DAILY.last,streak:DAILY.streak,chestDay:DAILY.chestDay,ch:DAILY.ch,bonus:DAILY.bonus,total:DAILY.total};}
function unpackDaily(s){resetDaily();if(!s)return;
  const n=v=>Number.isFinite(v)?Math.floor(v):-1;
  DAILY.day=n(s.day);DAILY.last=n(s.last);DAILY.streak=clamp(n(s.streak),0,9999);DAILY.chestDay=n(s.chestDay);DAILY.bonus=!!s.bonus;DAILY.total=clamp(n(s.total),0,99999);
  if(Array.isArray(s.ch))DAILY.ch=s.ch.filter(c=>c&&DAILY_KINDS.some(k=>k.k===c.k)&&c.n>0).slice(0,3).map(c=>({k:c.k,t:DAILY_TYPES[c.t]?c.t:'slime',n:clamp(c.n|0,1,999),p:clamp(c.p|0,0,999),done:!!c.done,gold:clamp(c.gold|0,0,999)}));}
/* ---- reward helper (gold / materials / card of a rarity / gear of a rarity) ---- */
function giveReward(r){
  const out=[];
  if(r.g){P.gold+=r.g;out.push('+'+r.g+' G');}
  if(r.mat)for(const k in r.mat){addMat(k,r.mat[k]);out.push('+'+r.mat[k]+' '+MATS[k].n);}
  if(r.card){const c=randCardOf(r.card);if(c){grantCard(c.id);out.push(c.name);}}
  if(r.gear){const it=genGear(null,Math.max(1,P.lv),r.gear,false);addGear(it);out.push(it.name);}
  return out;
}
/* ---- rolling today's challenges: same on every device for the same date ---- */
function dailyRoll(dn){
  const rng=seededRng(hashStr('daily:'+dn)),pool=DAILY_KINDS.filter(k=>!k.minLv||P.lv>=k.minLv),out=[];
  const bag=pool.slice();
  while(out.length<3&&bag.length){const k=bag.splice(Math.floor(rng()*bag.length),1)[0];
    const types=Object.keys(DAILY_TYPES);
    out.push({k:k.k,t:types[Math.floor(rng()*types.length)],n:k.min+Math.floor(rng()*(k.max-k.min+1)),p:0,done:false,gold:k.gold});}
  return out;
}
function dailyEnsure(){
  const dn=dayNum();if(DAILY.day===dn&&DAILY.ch.length)return false;
  DAILY.day=dn;DAILY.ch=dailyRoll(dn);DAILY.bonus=false;return true;
}
const chestReady=()=>DAILY.chestDay!==dayNum();
function chestPreview(){            // streak that claiming today would produce
  const dn=dayNum();return DAILY.last===dn-1?DAILY.streak+1:DAILY.last===dn?DAILY.streak:1;}
function claimChest(){
  const dn=dayNum();if(DAILY.chestDay===dn)return null;
  DAILY.streak=chestPreview();DAILY.last=dn;DAILY.chestDay=dn;
  ACH.s.streakBest=Math.max(ACH.s.streakBest,DAILY.streak);
  const r=LOGIN_REWARDS[(DAILY.streak-1)%LOGIN_REWARDS.length],got=giveReward(r);
  toast(`DAILY CHEST (${r.n}): ${got.join(', ')}`,4,'#ffd23f');sfx('level');
  if(!RUSH.on)saveGame('chest');
  return {r,got,streak:DAILY.streak};
}
/* ---- progress events ---- */
function dailyAdd(c,n){
  if(c.done)return;c.p=Math.min(c.n,c.p+n);
  if(c.p>=c.n){c.done=true;DAILY.total++;const got=giveReward({g:c.gold});
    toast(`DAILY DONE: ${dailyText(c)}  ${got.join(', ')}`,3.4,'#7dffa0');sfx('level');
    if(DAILY.ch.every(x=>x.done)&&!DAILY.bonus){DAILY.bonus=true;const b=giveReward(DAILY_BONUS);toast('ALL DAILIES DONE!  '+b.join(', '),4,'#ffd23f');}
    if(!RUSH.on)saveGame('daily');}
}
function dailyText(c){const k=DAILY_KINDS.find(x=>x.k===c.k);return k.txt(c.n,c.t);}
function dailyEvent(kind,arg){
  if(metaOff()||!DAILY.ch.length)return;
  for(const c of DAILY.ch){if(c.done)continue;
    if(c.k==='kills'&&kind==='kill')dailyAdd(c,1);
    else if(c.k==='type'&&kind==='kill'&&arg.type===c.t)dailyAdd(c,1);
    else if(c.k==='elite'&&kind==='kill'&&arg.elite&&!arg.rush)dailyAdd(c,1);
    else if(c.k==='cards'&&kind==='card')dailyAdd(c,1);
    else if(c.k==='gold'&&kind==='gold')dailyAdd(c,arg);
    else if(c.k==='arena'&&kind==='arena')dailyAdd(c,1);}
}
let dailyChk=0;
function updateDaily(dt){
  if(metaOff())return;
  dailyChk-=dt;if(dailyChk>0)return;dailyChk=4;
  if(introQuiet())return;   // daily challenges are introduced after the first quest
  if(dailyEnsure()&&state==='play')toast('New daily challenges are up!'+(chestReady()?'  Chest ready - open DAILY.':''),3.4,'#ffe14d');
  else if(chestReady()&&!DAILY.noted&&state==='play'){DAILY.noted=true;toast('Your daily chest is ready!  (Pause > DAILY)',3.4,'#ffd23f');}
  if(!chestReady())DAILY.noted=false;
}
/* ---- notice board in Oakvale ---- */
NPCS.push({name:'Notice Board',x:13.6*TS,y:40.6*TS,spr:'board',board:true,lines:[]});
