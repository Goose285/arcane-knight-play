/* =====================================================================
   COMBAT LAB: a practice room (the Ember Arena) with training dummies and a few real foes that respawn. Nothing there is saved or
   rewarded, the hero cannot fall, and it is where the EXPERIMENTAL card system lives:
     1. a hand of 4 cards at most;
     2. no full-hand refresh when the gauge fills - ONE new card every 2.5s into an empty slot (the timer waits while the hand is full);
     3. tapping an attack card only SELECTS it (reticle + range ring); the next tap / click in the world casts it THERE. Tap the card
        again or any HUD control to cancel. Non-targeted buffs (heal, barrier, haste, ward ...) still cast on a tap.
   The whole thing sits behind EXPCARD.enabled (forced on only while the Lab is open). Flip the flag to promote it to the main game.
   ===================================================================== */
const EXPCARD={enabled:true,hand:4,deal:2.5,snap:70,start:2};   // PROMOTED to the main game: hand of 4, one card per 2.5s, tap-to-aim
const labOn=()=>RUSH.on&&RUSH.mode==='lab';
const expCards=()=>EXPCARD.enabled||labOn();          // the lab's 4-card hand + one-card-every-2.5s dealing
const expAim=()=>true;                                  // tap-to-select / tap-the-world-to-cast targeting: main game AND lab
const EXP_INSTANT=new Set(['sword','shield','heal','haste','decoy','ward','reflect','timestop','quake','wolf','shadow']);   // no aim needed: cast on tap
const EXP_GROUND=new Set(['meteor','poison','frostburst','crimsonburst']);                                 // may land on bare ground
const EXP_NEEDS_FOE=new Set(['frostbolt','crimsonbolt','chain','curse','drain']);                          // must be pointed at a creature
const expAimed=id=>!!id&&!EXP_INSTANT.has(id)&&!(CARD[id]&&CARD[id].melee);   // melee cards (sword, quake, shadow ...) are ALWAYS one tap, never aim
/* ---- dealing: one card every EXPCARD.deal seconds into the first empty slot ---- */
function expDealInit(){B.hand=[];for(let i=0;i<EXPCARD.hand;i++)B.hand.push(null);B.sel=0;B.xsel=-1;B.xt=null;B.xptr=null;
  for(let i=0;i<EXPCARD.start;i++)B.hand[i]=drawFromDeck();B.xdeal=0;B.gauge=0;B.gaugeFlash=.6;sfx('deal');}   // a hand of 2 to open with, then one card per 2.5s
function expDealTick(dt){
  const free=B.hand.indexOf(null);
  if(free<0){B.xdeal=Math.min(B.xdeal,EXPCARD.deal);B.gauge=1;return;}      // full: the timer waits
  B.xdeal+=dt;B.gauge=clamp(B.xdeal/EXPCARD.deal,0,1);
  if(B.xdeal>=EXPCARD.deal){B.xdeal=0;B.hand[free]=drawFromDeck();if(!B.hand[B.sel])B.sel=free;B.gaugeFlash=.6;sfx('deal');}
}
/* ---- discard: swipe a card DOWN (or X on a keyboard) to throw it away; the empty slot starts refilling 0.5s sooner ---- */
const DISCARD_SAVE=.5;
function discardCard(i){
  if(!B||B.phase!=='fight'||B.cleared)return false;const id=B.hand[i];if(!id)return false;TEV.down++;
  const r=cardRects[i]||{cx:VW/2,cy:VH-60,w:56,h:68,rot:0};
  (B.discards||(B.discards=[])).push({id,r:{cx:r.cx!=null?r.cx:r.x+r.w/2,cy:r.cy!=null?r.cy:r.y+r.h/2,w:r.w,h:r.h,rot:r.rot||0},t0:performance.now(),dir:(i%2?1:-1)});
  B.hand[i]=null;if(B.xsel===i)B.xsel=-1;
  if(B.sel===i){for(let k=1;k<=B.hand.length;k++){const j=(i+k)%B.hand.length;if(B.hand[j]){B.sel=j;break;}}}
  if(B.hand.indexOf(null)>=0)B.xdeal=Math.min(EXPCARD.deal,(B.xdeal||0)+DISCARD_SAVE);   // a slot is empty, so the deal timer is running: skip 0.5s of it
  B.gauge=clamp(B.xdeal/EXPCARD.deal,0,1);sfx('whoosh');try{navigator.vibrate&&navigator.vibrate(10);}catch(e){}
  return true;
}
/* ---- selecting / casting ---- */
const expSelActive=()=>!!(B&&expAim()&&B.xsel>=0&&B.hand[B.xsel]&&B.phase==='fight');
function expCancel(){if(B&&B.xsel>=0){B.xsel=-1;}}
function expCardTap(i){   // a card was tapped / clicked / number-keyed
  if(!B||B.phase!=='fight')return;const id=B.hand[i];if(!id)return;
  if(!expAimed(id)){B.sel=i;useCard(i);return;}
  if(B.xsel===i){B.xsel=-1;sfx('select');return;}                    // tap the same card again = cancel
  B.xsel=i;B.xid=id;B.sel=i;sfx('select');try{navigator.vibrate&&navigator.vibrate(8);}catch(e){}
}
const cardUse=i=>{if(expAim())expCardTap(i);else useCard(i);};
/* what a world point means for a card: {x,y,e,tg}  (tg = a real foe, or a ground marker for area cards) */
function expPick(wx,wy,id){
  let best=null,bd=1e9;
  for(const e of B.ens){if(e.dying)continue;const c=ecen(e),d=Math.hypot(c.x-wx,c.y-wy);if(d<EXPCARD.snap+eRad(e)&&d<bd){bd=d;best=e;}}
  if(best){const c=ecen(best);return {x:c.x,y:c.y,e:best,tg:best};}
  if(EXP_GROUND.has(id))return {x:wx,y:wy,e:null,tg:{x:wx,y:wy,type:'slime',sz:0,def:{big:false},dying:false,pseudo:true}};
  return {x:wx,y:wy,e:null,tg:null};
}
function expWith(xt,fn){const old=B.xt;B.xt=xt;try{return fn();}finally{B.xt=old;}}
function expPointer(id){   // where the reticle sits: the mouse, else the nearest foe
  if(B.xptr)return expPick(B.xptr.x,B.xptr.y,id);
  const ne=(()=>{let b=null,bd=1e9;const pc=pcen();for(const e of B.ens){if(e.dying)continue;const c=ecen(e),d=Math.hypot(c.x-pc.x,c.y-pc.y);if(d<bd){bd=d;b=e;}}return b;})();
  if(ne){const c=ecen(ne);return {x:c.x,y:c.y,e:ne,tg:ne};}
  const pc=pcen();return {x:pc.x+Math.cos(P.aim)*120,y:pc.y+Math.sin(P.aim)*120,e:null,tg:null};
}
function expCastAt(wx,wy){
  if(!expSelActive())return false;
  const i=B.xsel,id=B.hand[i],xt=expPick(wx,wy,id);
  if(EXP_NEEDS_FOE.has(id)&&!xt.e){floatText(wx,wy-16,'NO TARGET','#ffb0a0',11);sfx('clang');return true;}
  const mv=P.moving;P.moving=false;
  TEV.aim++;expWith(xt,()=>useCard(i));P.moving=mv;
  if(!B)return true;
  B.swipeFlash={t:0,tx:xt.x,ty:xt.y,col:(CARD[id]||{}).col||'#fff'};
  if(!B.hand[i])B.xsel=-1;                                           // cast: selection is spent (a failed cast keeps card + selection)
  return true;
}
const expTapAt=(sx,sy)=>expCastAt(sx+cam.x,sy+cam.y);
const expAimId=()=>expSelActive()?B.hand[B.xsel]:null;
/* ---- drawing: reticle for aimed cards that have no preview shape, range ring, hint ---- */
function drawExpAim(){
  if(!B||!expAim()||B.phase!=='fight')return;
  const id=expAimId();if(!id)return;
  const ch=CARD[id],col=ch.col;   // (no ring / crosshair / beam any more: just the AIM frame on the card, this banner, and a ripple where the cast lands)
  const w=Math.min(300,VW-SL-SR-20),x=Math.round(SL+(VW-SL-SR)/2-w/2),y=Math.round(Math.max(COMBAT_HUD_BOT+(typeof TRK!=='undefined'&&trkVisible()?30:8),VH*.2));
  panel(x,y,w,34,{});txt(cardFullName(ch)+':  TAP A SPOT TO CAST',x+w/2,y+14,{size:9,align:'center',col,lw:2});
  txt('tap the card again or any button to cancel',x+w/2,y+27,{size:8,align:'center',col:'#cfd0ff',bold:false,lw:2});
}
function expMark(cw,ch){   // 'AIM' frame on the selected card (drawn inside the card transform)
  ctx.save();ctx.globalAlpha=.6+.4*Math.sin(gtime*8);ctx.strokeStyle='#7df9ff';ctx.lineWidth=3;ctx.strokeRect(-1.5,-1.5,cw+3,ch+3);ctx.restore();
  txt('AIM',cw/2,ch-4,{size:9,align:'center',col:'#7df9ff',lw:3});
}
/* ---- the lab itself ---- */
const LAB={set:false,units:[],ret:null};
const LAB_SPOTS=[['dummy',27,201],['dummy',32,201],['dummy',37,201],['slime',23,198],['knight',41,198],['goblin',32,196]];
function labMake(kind,tx,ty){
  const t=kind==='dummy'?'slime':kind,e=mkEnemyObj(t,tx,ty);
  e.rush=true;e.lab=true;e.terr={x0:ARENA_TERR.tx0*TS+10,x1:(ARENA_TERR.tx1+1)*TS-10,y0:ARENA_TERR.ty0*TS+8,y1:(ARENA_TERR.ty1+1)*TS-1};
  applyLevel(e,kind==='dummy'?1:2);e.baseLv=e.lv;e.xpv=0;e.gm=0;e.mt=1e9;e.lk=1e9;e.elite=null;e.calm=0;
  if(kind==='dummy'){e.dummy=true;e.mhp=e.maxhp=e.hp=6000;e.title='Training Dummy';e.tname='DUMMY';e.sz=1;e.name='TRAINING DUMMY';}
  return e;
}
function labStart(){
  if(RUSH.on||!canTravel())return false;
  Object.assign(RUSH,{mode:'lab',boons:[],on:true,round:0,score:0,t:0,rt:0,wait:0,cur:null,ret:{x:P.x,y:P.y},result:null});
  LAB.set=false;LAB.units=[];P.hp=maxHp();state='play';UI.mode=null;startWarp(ARENA.start);return true;
}
function labClean(){
  for(let i=enemies.length-1;i>=0;i--)if(enemies[i].lab)enemies.splice(i,1);
  LAB.units=[];LAB.set=false;
}
function labLeave(){
  if(!labOn())return;
  if(B){resetFighters(true);B=null;}
  labClean();RUSH.on=false;RUSH.mode='rush';P.hp=maxHp();P.grace=3;const to={x:RUSH.ret.x,y:RUSH.ret.y,dir:'d'};
  if(!WARP)startWarp(to);else{P.x=to.x;P.y=to.y;snapCam();}
}
function labKill(e){   // nothing dies for real in the lab: dummies reset, foes fade and respawn
  const c=ecen(e);
  if(e.dummy){e.hp=e.maxhp;floatText(c.x,c.y-34,'RESET','#9ad0ff',11);burst(c.x,c.y,'#d9b97a',8,90,.4);return;}
  e.dying=true;e.dyT=0;e.st='idle';e.cur=null;e.guard=0;e.dash=null;
  B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);
  sfx('boom');burst(c.x,c.y,'#ffb23f',14,140,.6);floatText(c.x,c.y-30,'DOWN','#ffe14d',12);
}
function updateLab(dt){
  if(!labOn())return;
  RUSH.t+=dt;
  if(WARP||state!=='play'||DLG||zoneOfPx(P.y)!=='arena')return;
  if(!LAB.set){
    LAB.set=true;LAB.units=LAB_SPOTS.map(([k,x,y])=>labMake(k,x,y));LAB.units.forEach(e=>enemies.push(e));
    if(!B){const first=LAB.units[1];P.grace=0;startEncounter(first,true);
      let k=0;for(const o of LAB.units){if(B.ens.includes(o))continue;initCombatEnemy(o,.2+k*.25);B.ens.push(o);k++;}B.total=LAB.units.length;}
    return;
  }
  if(!B)return;
  P.hp=Math.max(P.hp,maxHp()*.45);B.fleeT=0;                       // the lab keeps you in one piece
  for(const o of LAB.units)if(!o.alive&&o.respawn>4)o.respawn=4;      // quick respawns
  for(const o of LAB.units){                                       // respawned foes rejoin the fight
    if(o.alive&&!o.engaged&&!o.dying&&!B.ens.includes(o)){initCombatEnemy(o,.6);B.ens.push(o);}
  }
  if(B.xsel>=0&&!B.hand[B.xsel])B.xsel=-1;
}
