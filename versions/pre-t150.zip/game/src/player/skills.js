/* =====================================================================
   SKILL TREE STATE + EFFECTS. Ranks are saved; points are derived from the level so nothing can drift.
   ===================================================================== */
const SK={r:{}};
function resetSkills(){SK.r={};SKILL_NODES.forEach(n=>{SK.r[n.id]=0;});}
resetSkills();
const skillRank=id=>SK.r[id]|0;
const skillSpent=()=>SKILL_NODES.reduce((t,n)=>t+skillRank(n.id)*n.cost,0);
const skillPoints=()=>Math.max(0,P.lv-1-skillSpent());
const handN=()=>5+skillRank('slots');
function skillCan(n){const r=skillRank(n.id);if(r>=n.max)return 'MAX';if(P.lv<n.lvl(r))return 'Needs Lv '+n.lvl(r);if(skillPoints()<n.cost)return 'Need '+n.cost+' pt';return '';}
function buySkill(id){
  const n=SKILL[id];if(!n||skillCan(n))return false;SK.r[id]++;P.hp=Math.min(P.hp,maxHp());sfx('level');return true;
}
const respecCost=()=>skillSpent()?40*P.lv:0;
function respecSkills(){const c=respecCost();if(!c||P.gold<c)return false;P.gold-=c;resetSkills();P.hp=Math.min(P.hp,maxHp());return true;}
/* stat bonuses merged into gearStats() */
function skillStats(){return {hp:12*skillRank('hp'),gauge:.06*skillRank('gauge'),crit:.02*skillRank('crit')};}
const schoolOf=id=>CARD_SCHOOL[id]||null;
const schoolMult=id=>{const s=schoolOf(id);return s?1+.07*skillRank(s):1;};
const holyHeal=()=>1+(skillRank('holy')>=3?.1:0);
function packSkills(){return {r:SK.r};}
function unpackSkills(s){resetSkills();if(s&&s.r)SKILL_NODES.forEach(n=>{SK.r[n.id]=clamp(s.r[n.id]|0,0,n.max);});}
