/* STAIRS between the meadow and the Crypt of Hollow Kings: a short fade out / in, teleport at the midpoint */
let WARP=null;
const WARP_DEST={crypt:{...CRYPT_ARRIVE,dir:'u'},out:{...CRYPT_OUT,dir:'d'}};
function startWarp(to,opt){if(WARP||B)return;if(typeof to==='string')to=WARP_DEST[to]||(ZONES[to]&&zoneArrive(to))||(to==='ow'&&{x:SPAWN.x,y:SPAWN.y,dir:'d'});if(!to)return;WARP=Object.assign({t:0,to,done:false,k:1},opt||{});sfx('door');releaseAllTouch();P.moving=false;}
function checkStairs(){
  if(WARP||B)return;
  const tx=Math.floor(P.x/TS),ty=Math.floor((P.y-4)/TS);if(ty<0||ty>=MH)return;
  const t=map[ty][tx];
  if(t===T.CS)startWarp('crypt');else if(t===T.CX)startWarp('out');
  else if(t===T.GT){const z=GATES[tx+','+ty];if(z)startWarp(zoneArrive(z));}
  else if(t===T.GX){const z=ZEXITS[tx+','+ty];if(z==='arena'){if(labOn())labLeave();else rushLeave();}else if(z==='house')startWarp(HOUSE_OUT);else if(z)startWarp(zoneGateOut(z));}
}
function updateWarp(dt){
  WARP.t+=dt;const k=WARP.sleep?2.4:1;
  if(!WARP.done&&WARP.t>=.35*k){
    const d=WARP.to;P.x=d.x;P.y=d.y;P.dir=d.dir||'d';P.grace=Math.max(P.grace,1.5);
    WARP.done=true;snapCam();WS.length=0;if(WARP.mid)WARP.mid();
  }
  if(WARP.t>=.7*k)WARP=null;
}
function drawWarp(){
  if(!WARP)return;const k=WARP.sleep?2.4:1,a=WARP.t<.35*k?Math.min(1,WARP.t/(.35*k)*1.6):Math.max(0,(.7*k-WARP.t)/(.35*k)*1.6);
  ctx.fillStyle=`rgba(0,0,0,${a})`;ctx.fillRect(0,0,VW,VH);
}
