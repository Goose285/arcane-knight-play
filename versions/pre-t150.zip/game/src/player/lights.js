/* light slot state: owned lights, the equipped one, and an on/off toggle (V). Saved inside the craft block. */
const LGT={own:{},eq:null,on:true};
function resetLights(){LGT.own={};LGT.eq=null;LGT.on=true;}
function packLights(){return {own:LGT.own,eq:LGT.eq,on:LGT.on};}
function unpackLights(s){resetLights();if(!s||typeof s!=='object')return;
  if(s.own&&typeof s.own==='object')for(const k in s.own)if(LIGHT_BY[k]&&s.own[k])LGT.own[k]=true;
  if(s.eq&&LGT.own[s.eq])LGT.eq=s.eq;LGT.on=s.on!==false;}
const lightPrice=l=>storyGold(l.price);
function buyLight(id){
  const l=LIGHT_BY[id];if(!l||LGT.own[id])return false;const pr=lightPrice(l);if(P.gold<pr)return false;
  P.gold-=pr;LGT.own[id]=true;const cur=LIGHT_BY[LGT.eq];if(!cur||l.r>cur.r){LGT.eq=id;LGT.on=true;}return true;   // new light goes straight into the slot if it is better
}
function equipLight(id){if(id&&!LGT.own[id])return false;LGT.eq=id||null;if(id)LGT.on=true;return true;}
function toggleLight(){if(!LGT.eq){toast('No light equipped  (buy one at Brum\'s workbench)',2.2,'#ffd98a');return false;}
  LGT.on=!LGT.on;toast(LIGHT_BY[LGT.eq].name+(LGT.on?' lit':' put out'),1.4,LIGHT_BY[LGT.eq].col);sfx('select');return true;}
const activeLight=()=>LGT.eq&&LGT.on?LIGHT_BY[LGT.eq]:null;
