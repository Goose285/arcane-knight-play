/* =====================================================================
   TELEPORT HOME (pause menu): a short channel (2.5s) that carries you to the Oakvale waystone, then a 30s cooldown.
   Not available in a fight, in the Combat Lab / Rush arena, or while another fade is running. Taking damage, a fight starting
   or wandering off interrupts the cast (no cooldown is charged for an interrupted cast).
   ===================================================================== */
const HOME={cast:0,t:0,cd:0,hp:0,x:0,y:0,CAST:2.5,CD:30};
function homeBlock(){
  if(B)return 'Cannot teleport during a fight';
  if(WARP||RUSH.on||labOn()||zoneOfPx(P.y)==='arena')return 'Cannot teleport from here';
  if(HOME.cast>0)return 'Already teleporting';
  if(HOME.cd>0)return 'Teleport recharging ('+Math.ceil(HOME.cd)+'s)';
  return null;
}
function startHome(){
  const why=homeBlock();if(why){toast(why,1.8,'#ffb0a0');sfx('clang');return false;}
  HOME.cast=HOME.CAST;HOME.t=0;HOME.hp=P.hp;HOME.x=P.x;HOME.y=P.y;sfx('select');toast('Teleporting home... stand still',1.6,'#7df9ff');return true;
}
function homeCancel(msg){HOME.cast=0;toast(msg,1.6,'#ffb0a0');sfx('clang');}
function updateHome(dt){
  if(HOME.cd>0)HOME.cd=Math.max(0,HOME.cd-dt);
  if(HOME.cast<=0)return;
  if(B||WARP){homeCancel('Teleport interrupted');return;}
  if(P.hp<HOME.hp-.5){homeCancel('Teleport interrupted');return;}
  HOME.hp=P.hp;
  if(Math.hypot(P.x-HOME.x,P.y-HOME.y)>40){homeCancel('Teleport cancelled - you moved');return;}
  HOME.t+=dt;HOME.cast-=dt;
  if(Math.random()<dt*30)wfxBurst(P.x+R(-10,10),P.y-6,'#7df9ff',1,40,.5);
  if(HOME.cast<=0){HOME.cast=0;HOME.cd=HOME.CD;DLG=null;startWarp(wayDest(WAYSTONES[0]),{mid:()=>{P.hp=Math.max(P.hp,1);toast('You return to Oakvale',2.2,'#7df9ff');}});}
}
function drawHome(){
  if(HOME.cast<=0||B)return;
  const x=P.x-cam.x,y=P.y-cam.y-30,k=1-HOME.cast/HOME.CAST,pr=Math.sin(gtime*10)*.5+.5;
  ctx.save();ctx.globalAlpha=.55+.25*pr;ctx.strokeStyle='#7df9ff';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(x,y+26,12+k*8,5+k*3,0,0,6.283);ctx.stroke();ctx.restore();
  ctx.fillStyle='#14121e';ctx.fillRect(x-20,y-16,40,6);ctx.fillStyle='#7df9ff';ctx.fillRect(x-19,y-15,Math.round(38*k),4);
  txt('HOME',x,y-20,{size:9,align:'center',col:'#7df9ff',lw:3});
}
