/* =====================================================================
   MAIN QUESTLINE LOGIC: chapters, choices -> villager trust -> perks, endings.
   State: STORY.ch = chapters finished (0..5). Cutscene engine lives in ui/cutscene.js.
   ===================================================================== */
const STORY={ch:0,flags:{},trust:{orin:0,hale:0,brum:0,pip:0},ending:null,choices:[],queue:null,cutting:null,emberHp:0};
function resetStory(){STORY.ch=0;STORY.flags={};STORY.trust={orin:0,hale:0,brum:0,pip:0};STORY.ending=null;STORY.choices=[];STORY.queue=null;STORY.cutting=null;STORY.emberHp=0;}
function packStory(){return {ch:STORY.ch,f:STORY.flags,t:STORY.trust,e:STORY.ending,c:STORY.choices.slice(-12),h:STORY.emberHp};}
function unpackStory(s){resetStory();if(!s)return;
  STORY.ch=clamp(s.ch|0,0,CHAPTERS.length);
  if(s.f)for(const k in s.f)if(s.f[k])STORY.flags[k]=true;
  for(const k in STORY.trust)if(s.t&&typeof s.t[k]==='number')STORY.trust[k]=clamp(s.t[k]|0,-3,6);
  STORY.ending=ENDINGS[s.e]?s.e:null;STORY.choices=Array.isArray(s.c)?s.c.filter(c=>c&&typeof c.t==='string').slice(-12):[];STORY.emberHp=s.h?15:0;}
/* ---- perks: a villager helps once their trust reaches TRUST_NEED ---- */
const storyPerk=id=>STORY.trust[id]>=TRUST_NEED;
const storyHp=()=>(storyPerk('hale')?12:0)+STORY.emberHp;
const storyXp=()=>storyPerk('orin')?1.1:1;
const storyDrop=()=>storyPerk('pip')?1.25:1;
const storyGold=g=>storyPerk('brum')?Math.round(g*.8):g;
/* ---- effects of a chosen option ---- */
function storyApply(d){
  if(!d)return;
  if(d.flag)STORY.flags[d.flag]=true;
  if(d.trust)for(const k in d.trust){const old=STORY.trust[k];STORY.trust[k]=clamp(old+d.trust[k],-3,6);
    if(d.trust[k]>0&&old<TRUST_NEED&&STORY.trust[k]>=TRUST_NEED)toast(`${VILLAGERS[k].n} will help you now!  ${VILLAGERS[k].perk}`,3.6,'#7dffa0');
    else if(d.trust[k]!==0)toast(`${VILLAGERS[k].n} ${d.trust[k]>0?'trusts you more':'trusts you less'}`,2.2,d.trust[k]>0?'#9be09b':'#ff9a9a');}
  if(d.ending)STORY.ending=d.ending;
  if(d.reward)storyReward(d.reward);
}
function storyReward(id){
  if(id==='ember'){const it=genGear('ring',Math.max(8,P.lv),'legendary',true);it.name='Ember Crown Band';addGear(it);STORY.emberHp=15;P.hp=Math.min(maxHp(),P.hp+15);toast('You claim the crown: legendary ring + 15 max HP',3.6,'#ff9a3d');}
  else if(id==='warden'){P.gold+=500;const c=randCardOf('epic');if(c)grantCard(c.id);toast('The Warden\'s Oath: +500 G',3.2,'#7dffa0');}
  else if(id==='free'){P.gold+=250;P.xp+=400;while(P.xp>=xpNeed()){P.xp-=xpNeed();P.lv++;P.hp=maxHp();sfx('level');/* t139u: the LEVEL UP reveal shows it once */}
    const c=randCardOf('epic');if(c)grantCard(c.id);toast('The seal is shattered: +250 G, +400 XP',3.2,'#8fd8ff');}
}
/* ---- chapter progress ---- */
function storyChapterDone(id){
  const n=CHAPTERS.findIndex(c=>c.id===id)+1;if(n>STORY.ch)STORY.ch=n;
  toast(`CHAPTER ${n}: ${CHAPTERS[n-1].name.toUpperCase()} - Chronicle updated`,3.4,'#ffe14d');sfx('level');
  if(typeof saveGame==='function'&&!RUSH.on)saveGame('story');
}
function storyStart(id){return startCut(id,storyChapterDone);}
/* is there a story scene waiting at this NPC? returns the cut id or null */
function storyReady(npc){
  if(!npc)return null;const ch=STORY.ch;
  if(npc.name==='Elder Orin'){
    if(ch===0&&(P.lv>=3||QS.st.slimes==='done'))return 'c1';
    if(ch<4&&lichDown)return 'c4';
    if(ch===4&&STORY.ending)return 'c5';}
  if(npc.name==='Gate Guard'&&ch===1&&(QS.st.goblins==='done'||P.lv>=5))return 'c2';
  return null;
}
function storyTalk(npc){const id=storyReady(npc);if(!id)return false;return storyStart(id);}
/* per-frame: queued scenes (crypt entry, Lich King's fall) */
function updateStory(){
  if(DLG||B||WARP||state!=='play'||RUSH.on)return;
  if(STORY.queue){const q=STORY.queue;STORY.queue=null;storyStart(q);return;}
  if(STORY.ch===2&&areaCur===CRYPT_NAME)STORY.queue='c3';
}
function storyOnLich(){if(STORY.ch<4)STORY.queue='c4';}
function storyNextHint(){const c=CHAPTERS[STORY.ch];return c?c.hint:'The story is complete.';}
