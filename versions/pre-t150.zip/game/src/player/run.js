/* =====================================================================
   RUN (t136u): outside combat only. x1.6 walking speed with a dust trail.
   Keyboard: hold R.  Touch: the RUN button above the stick toggles it (or double-tap and hold the stick).
   Switches itself off - and the button greys out - while a monster is chasing you or a fight is on.
   ===================================================================== */
const RUN={on:false,hold:false,dust:[],dt:0,MUL:1.6,lastJoyT:0};
function runBlocked(){if(B)return 'combat';for(const e of enemies)if(e.alive&&!e.dying&&(e.chasing||e.engaged))return 'aggro';return null;}
function runActive(){return (RUN.on||RUN.hold||held('KeyR'))&&!runBlocked()&&state==='play';}
function runMul(){return runActive()?RUN.MUL:1;}
function runToggle(){if(runBlocked()){RUN.on=false;sfx('clang');toast('Cannot run - monsters are after you!',1.6,'#ffb0a0');return false;}RUN.on=!RUN.on;sfx('select');if(typeof TEV!=='undefined')TEV.run++;return true;}
function runBtn(){return {x:joy.dx+(LEFTY?-28:28),y:joy.dy-104,r:20};}
function updateRun(dt){
  if(runBlocked()){RUN.on=false;RUN.hold=false;}
  if(held('KeyR')&&typeof TEV!=='undefined'&&!RUN.kr){RUN.kr=true;TEV.run++;}if(!held('KeyR'))RUN.kr=false;
  for(const d of RUN.dust){d.t+=dt;d.y-=8*dt;d.x+=d.vx*dt;}RUN.dust=RUN.dust.filter(d=>d.t<.55);
  if(runActive()&&P.moving){RUN.dt-=dt;if(RUN.dt<=0){RUN.dt=.06;RUN.dust.push({x:P.x+R(-5,5),y:P.y-1,vx:R(-12,12),t:0,s:R(2,4)});}}
}
function drawRunDust(){for(const d of RUN.dust){const a=.45*(1-d.t/.55);ctx.fillStyle=`rgba(190,170,130,${a})`;const s=d.s+d.t*8;ctx.beginPath();ctx.arc(d.x-cam.x,d.y-cam.y,s,0,6.283);ctx.fill();}}
function drawRunBtn(){
  if(!TOUCH||state!=='play'||B)return;const b=runBtn(),blk=runBlocked(),on=runActive();
  ctx.globalAlpha=blk?.35:on?.92:.6;ctx.fillStyle=on?'#2d6a4f':'#14102e';ctx.beginPath();ctx.arc(b.x,b.y,b.r,0,6.283);ctx.fill();
  ctx.strokeStyle=blk?'#777':on?'#9be8a0':'#cfd0ff';ctx.lineWidth=2.5;ctx.stroke();
  txt('RUN',b.x,b.y+4,{size:9,align:'center',col:blk?'#999':'#fff',lw:2});ctx.globalAlpha=1;
}
