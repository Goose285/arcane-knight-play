/* =====================================================================
   CRAFTING STATE + LOGIC: monster parts, gear crafting, card upgrades ("Fireball+")
   ===================================================================== */
const CR={mat:{},upg:{}};
function resetCraft(){CR.mat={};CR.upg={};resetLights();}
const matCount=k=>CR.mat[k]|0;
const upgLvl=id=>CR.upg[id]|0;
const upgMult=id=>1+.15*upgLvl(id);
const cardLabel=c=>(c.lab||c.name)+(upgLvl(c.id)?'+'.repeat(Math.min(3,upgLvl(c.id))):'');
const cardFullName=c=>c.name+(upgLvl(c.id)?'+'.repeat(upgLvl(c.id)):'');
function addMat(k,n=1){if(!MATS[k])return;CR.mat[k]=Math.min(99,matCount(k)+n);}
const canPay=(mats,gold)=>P.gold>=storyGold(gold)&&Object.keys(mats).every(k=>matCount(k)>=mats[k]);
function pay(mats,gold){P.gold-=storyGold(gold);for(const k in mats)CR.mat[k]-=mats[k];}
/* a kill: parts drop (guaranteed 2-4 from bosses); returns text lines for the popup */
function rollMats(e){
  const out=[],boss=!!(e.def&&e.def.boss),k=MAT_DROP[e.type];
  if(k){const n=boss?RI(3,4):(Math.random()<.6?1:0);if(n){addMat(k,n);out.push(`+${n} ${MATS[k].n}`);}}
  if(boss||e.elite||Math.random()<.18){const n=boss?RI(2,3):e.elite?RI(1,2):1;addMat('shard',n);out.push(`+${n} ${MATS.shard.n}`);}
  return out;
}
function craftGear(r){
  if(!canPay(r.mats,r.gold))return null;
  pay(r.mats,r.gold);ACH.s.crafts++;
  const it=genGear(r.slot,Math.max(1,P.lv+1),r.rar,false);it.name=r.name;it.crafted=true;
  addGear(it);return it;
}
function upgradeCard(id){
  const c=CARD[id];if(!c||!(COL[id]>0))return false;const l=upgLvl(id);if(l>=UPG_MAX)return false;
  const cs=upgCost(id,l);if(!canPay(cs.mats,cs.gold))return false;pay(cs.mats,cs.gold);CR.upg[id]=l+1;return true;
}
const costText=(mats,gold)=>Object.keys(mats).map(k=>mats[k]+' '+MATS[k].n).join(', ')+(gold?', '+gold+' G':'');
function packCraft(){return {mat:CR.mat,upg:CR.upg,light:packLights()};}
function unpackCraft(s){resetCraft();if(!s)return;unpackLights(s.light);
  if(s.mat)for(const k in s.mat)if(MATS[k])CR.mat[k]=clamp(s.mat[k]|0,0,99);
  if(s.upg)for(const k in s.upg)if(CARD[k])CR.upg[k]=clamp(s.upg[k]|0,0,UPG_MAX);}
