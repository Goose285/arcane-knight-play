/* =====================================================================
   DAY / NIGHT ROUTINES: shopkeepers and villagers live in the houses. In the morning each walks out of their front door to their work
   spot (staggered a little), in the evening they walk home and go inside. A shop only trades while its keeper is at work: talk to them
   on the way and they tell you; at night a CLOSED sign hangs where they stand by day. The inn stays open all night.
   ===================================================================== */
const ROUT={on:false,list:[],lastT:-1,OPEN:.22,CLOSE:.78,SPEED:46};
const ROUT_NAMES=['Blacksmith Brum','Baker Wren','Mason Dov','Pip','Marlo the Keeper','Orchard Keeper Mira','Farmer Hale'];
const rtOpenAt=i=>ROUT.OPEN+i*.005,rtCloseAt=i=>ROUT.CLOSE+i*.006;
function rtShouldWork(i,t){return t>=rtOpenAt(i)&&t<rtCloseAt(i);}
function rtPath(sx,sy,goal){       // BFS over walkable tiles; goal(x,y) -> true
  const key=(x,y)=>y*MW+x,prev=new Map([[key(sx,sy),-1]]),q=[[sx,sy]];let n=0;
  while(q.length&&n++<6000){const [x,y]=q.shift();if(goal(x,y)){const out=[];let k=key(x,y);while(k!==-1){out.push([k%MW,Math.floor(k/MW)]);k=prev.get(k);}return out.reverse();}
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=key(nx,ny);if(prev.has(k)||nx<0||ny<0||nx>=MW||ny>=MH||solidTile(nx,ny))continue;prev.set(k,key(x,y));q.push([nx,ny]);}}
  return null;
}
function rtInit(){
  ROUT.list=[];
  NPCS.forEach(n=>{const i=ROUT_NAMES.indexOf(n.name);if(i<0||n.x<0)return;
    const wx=Math.floor(n.x/TS),wy=Math.floor((n.y-4)/TS);
    const p=rtPath(wx,wy,(x,y)=>map[y-1]&&map[y-1][x]===T.D&&!(typeof inInn==='function'&&inInn(x,y-1)));
    if(!p)return;const [hx,hy]=p[p.length-1];
    n.rt={i,work:{x:n.x,y:n.y},home:{x:(hx+.5)*TS,y:(hy+.35)*TS},st:'work',path:null,pi:0};ROUT.list.push(n);});
  ROUT.on=true;
}
function rtSnap(n,t){const r=n.rt;if(rtShouldWork(r.i,t)){r.st='work';n.x=r.work.x;n.y=r.work.y;}else{r.st='home';n.x=-9999;n.y=-9999;}r.path=null;}
function rtGo(n,to,st){const r=n.rt,sx=Math.floor((n.x<0?r.home.x:n.x)/TS),sy=Math.floor(((n.x<0?r.home.y:n.y)-4)/TS),gx=Math.floor(to.x/TS),gy=Math.floor((to.y-4)/TS);
  if(n.x<0){n.x=r.home.x;n.y=r.home.y;}
  const p=rtPath(sx,sy,(x,y)=>x===gx&&y===gy);r.st=st;r.path=p?p.map(([x,y])=>[(x+.5)*TS,(y+.75)*TS]):[[to.x,to.y]];r.path.push([to.x,to.y]);r.pi=0;}
function updateRoutines(dt){
  if(window.__NOROUTINE)return;
  if(state==='editor'){if(ROUT.on){for(const n of ROUT.list){n.x=n.rt.work.x;n.y=n.rt.work.y;delete n.rt;}ROUT.on=false;ROUT.list=[];}return;}
  if(!ROUT.on){if(state!=='play')return;rtInit();for(const n of ROUT.list)rtSnap(n,DAY.t);ROUT.lastT=DAY.t;return;}
  const t=DAY.t,jump=Math.abs(t-ROUT.lastT)>.05&&Math.abs(t-ROUT.lastT)<.95;ROUT.lastT=t;
  for(const n of ROUT.list){const r=n.rt;
    if(jump){rtSnap(n,t);continue;}
    const want=rtShouldWork(r.i,t);
    if(want&&(r.st==='home'||r.st==='toHome'))rtGo(n,r.work,'toWork');
    else if(!want&&(r.st==='work'||r.st==='toWork'))rtGo(n,r.home,'toHome');
    if(r.path){const tg=r.path[r.pi];if(!tg){r.path=null;continue;}
      const dx=tg[0]-n.x,dy=tg[1]-n.y,d=Math.hypot(dx,dy),s=ROUT.SPEED*dt;
      if(d<=s){n.x=tg[0];n.y=tg[1];r.pi++;if(r.pi>=r.path.length){r.path=null;if(r.st==='toWork')r.st='work';else{r.st='home';n.x=-9999;n.y=-9999;}}}
      else{n.x+=dx/d*s;n.y+=dy/d*s;}}
  }
}
function rtShopClosed(npc){return !!(npc.rt&&npc.rt.st!=='work'&&(npc.smith||npc.pets||npc.name==='Baker Wren'));}
function rtClosedDlg(npc){
  const going=npc.rt.st==='toWork';
  DLG={name:npc.name,lines:[going?'Morning! I am just on my way to open up - give me a moment.':'The shop is closed for the night. Come back in the morning!'],i:0,c:0};
}
function drawRoutineSigns(){
  for(const n of ROUT.list){if(n.rt.st!=='home'||!(n.smith||n.pets||n.name==='Baker Wren'))continue;
    const x=n.rt.work.x-cam.x,y=n.rt.work.y-cam.y;if(x<-40||y<-40||x>VW+40||y>VH+40)continue;
    ctx.fillStyle='#5a3416';ctx.fillRect(Math.round(x)-1,Math.round(y)-22,3,22);ctx.fillStyle='#8a5a2c';ctx.fillRect(Math.round(x)-17,Math.round(y)-34,34,13);
    ctx.strokeStyle='#14182c';ctx.lineWidth=1;ctx.strokeRect(Math.round(x)-17.5,Math.round(y)-34.5,35,14);txt('CLOSED',x,y-24,{size:8,align:'center',col:'#ffe9a0',lw:0});}
}
