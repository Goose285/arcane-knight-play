/* =====================================================================
   TREASURE CHESTS (T.CHST): wooden (0), iron (1) and golden (2). Placed by hand in the editor or scattered through the regions.
   Walk into one (or press interact) to open it: the lid flips, coins and sparkles burst out and the loot is shown. Opened chests stay
   open (saved in SEC.chest2, keyed in overworld-relative tiles so an editor EXPAND does not lose them).
   ===================================================================== */
SEC.chest2={};
const CHEST_TIER={};                     // 'rx,ry' -> tier for the scattered chests (editor chests default by region)
const chKey=(x,y)=>(x-OX)+','+(y-OY);
function chestTier(x,y){const k=chKey(x,y);if(CHEST_TIER[k]!=null)return CHEST_TIER[k];let r=null;try{r=eastRegion(x,y);}catch(e){}return r==='rift'?2:r?1:0;}
function chestOpened(x,y){return !!SEC.chest2[chKey(x,y)];}
const CHFX=[];
function chestLoot(tier){
  const lines=[],gold=[RI(30,60),RI(80,140),RI(180,280)][tier];P.gold+=gold;lines.push(gold+' G');
  const mats=Object.keys(MATS);const mk=mats[RI(0,mats.length-1)],n=tier+1+RI(0,1);addMat(mk,n);lines.push(n+' '+(MATS[mk].n||mk));
  if(Math.random()<[.25,.55,1][tier]){const g=genGear(null,Math.max(P.lv,2+tier*4),['uncommon','rare','epic'][tier],false);addGear(g);lines.push(g.name);}
  if(Math.random()<[.12,.3,.6][tier]){const c=randCardOf(['common','rare','epic'][tier]||'rare');if(c){grantCard(c.id);lines.push(c.name);}}
  return lines;
}
function openChestAt(tx,ty){
  if(map[ty][tx]!==T.CHST||chestOpened(tx,ty))return false;
  const tier=chestTier(tx,ty);SEC.chest2[chKey(tx,ty)]=true;sfx('level');
  const cx=tx*TS+16,cy=ty*TS+12;
  for(let i=0;i<22;i++){const a=-Math.PI*R(.1,.9),s=R(60,160);CHFX.push({x:cx,y:cy,vx:Math.cos(a)*s,vy:Math.sin(a)*s,t:0,life:R(.6,1.1),col:i%3?'#ffd23f':'#fff6c8',coin:i%3!==0});}
  CHFX.push({ring:1,x:cx,y:cy,t:0,life:.6});
  const l=chestLoot(tier);revealChest(tier,l);toast(['CHEST','IRON CHEST','GOLDEN CHEST'][tier]+': '+l.join(', '),4,'#ffd23f');saveGame('chest');
  return true;
}
let chestBumpT=0;
function updateChests(dt){
  for(const f of CHFX){f.t+=dt;if(!f.ring){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=320*dt;}}
  for(let i=CHFX.length-1;i>=0;i--)if(CHFX[i].t>CHFX[i].life)CHFX.splice(i,1);
  if(state!=='play'||B||DLG)return;
  chestBumpT=Math.max(0,chestBumpT-dt);
  if(P.moving&&!chestBumpT){const [fx,fy]=frontTile();if(map[fy]&&map[fy][fx]===T.CHST&&!chestOpened(fx,fy)){chestBumpT=.5;openChestAt(fx,fy);}}
}
function drawChestFx(){
  for(const f of CHFX){const x=f.x-cam.x,y=f.y-cam.y,a=1-f.t/f.life;
    if(f.ring){ctx.strokeStyle=`rgba(255,230,120,${a})`;ctx.lineWidth=3;ctx.beginPath();ctx.arc(x,y,8+f.t*80,0,6.283);ctx.stroke();continue;}
    ctx.globalAlpha=Math.min(1,a*1.5);ctx.fillStyle=f.col;ctx.fillRect(Math.round(x)-2,Math.round(y)-2,f.coin?4:3,f.coin?4:3);}
  ctx.globalAlpha=1;
}
/* unopened chests glimmer */
function drawChestGlints(){
  const x0=Math.floor(cam.x/TS)-1,y0=Math.floor(cam.y/TS)-1,x1=x0+Math.ceil(VW/TS)+2,y1=y0+Math.ceil(VH/TS)+2;
  for(let y=Math.max(0,y0);y<=Math.min(MH-1,y1);y++)for(let x=Math.max(0,x0);x<=Math.min(MW-1,x1);x++){
    if(map[y][x]!==T.CHST||chestOpened(x,y))continue;const p=(gtime*1.3+x*.37+y*.71)%2;if(p>.5)continue;
    const a=Math.sin(p/.5*Math.PI),px=x*TS-cam.x+8+((x*7+y*3)%16),py=y*TS-cam.y+6;ctx.fillStyle=`rgba(255,250,210,${a})`;ctx.fillRect(px-1,py-3,2,6);ctx.fillRect(px-3,py-1,6,2);}
}
