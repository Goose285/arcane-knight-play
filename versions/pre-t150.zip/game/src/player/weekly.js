/* =====================================================================
   WEEKLY CRYPT: a seeded 7-floor roguelike run built on the arena (RUSH.mode==='weekly').
   Same seed for everyone in a given week. After each floor you pick 1 of 3 boons that last the run.
   Its own leaderboard + one-time weekly reward chest.
   ===================================================================== */
const WK_KEY='arcaneKnight.weekly.v1';
const WK={week:-1,lb:[],claimed:false,best:0};
function wkLoad(){try{const o=JSON.parse(localStorage.getItem(WK_KEY)||'{}'),w=weekNum();
  if(o&&o.week===w){WK.week=w;WK.lb=(Array.isArray(o.lb)?o.lb:[]).filter(r=>r&&isFinite(r.score)).sort((a,b)=>b.score-a.score).slice(0,WEEKLY_CFG.keep);WK.claimed=!!o.claimed;WK.best=o.best|0;}
  else{WK.week=w;WK.lb=[];WK.claimed=false;WK.best=0;}}catch(e){WK.week=weekNum();WK.lb=[];WK.claimed=false;WK.best=0;}}
function wkSave(){if(NOSAVE)return;try{localStorage.setItem(WK_KEY,JSON.stringify({week:WK.week,lb:WK.lb,claimed:WK.claimed,best:WK.best}));}catch(e){}}
function wkEnsure(){if(WK.week!==weekNum())wkLoad();}
wkLoad();
const weeklySeed=()=>hashStr('weekly:'+weekNum());
function weeklyName(){const r=seededRng(weeklySeed());return WEEKLY_NAMES[Math.floor(r()*WEEKLY_NAMES.length)]+' '+WEEKLY_NAMES2[Math.floor(r()*WEEKLY_NAMES2.length)];}
// floor index 0..6 -> {type,lv,aff,hpMul,dmMul}; deterministic per week + floor
function weeklyPlan(floor){
  const rng=seededRng(hashStr('weekly:'+weekNum()+':'+floor)),last=floor>=WEEKLY_CFG.floors-1;
  const type=last?WEEKLY_CFG.boss[Math.floor(rng()*WEEKLY_CFG.boss.length)]:WEEKLY_CFG.pool[Math.floor(rng()*WEEKLY_CFG.pool.length)];
  const lv=last?Math.max(14,P.lv)+2:Math.max(6,P.lv)+floor;
  const n=last?(rng()<.5?2:1):floor>=4?2:floor>=2?1:0,ids=AFFIX_IDS.filter(i=>i!=='volatile'),aff=[];
  while(aff.length<n&&ids.length)aff.push(ids.splice(Math.floor(rng()*ids.length),1)[0]);
  return {type,lv:clamp(lv,6,45),aff,hpMul:last?1:1.7+.3*floor,dmMul:1+.05*floor};
}
// three seeded boons for the choice after `floor` (never repeats a boon you already hold if avoidable)
function boonChoices(floor){
  const rng=seededRng(hashStr('boons:'+weekNum()+':'+floor)),have=RUSH.boons||[];
  let pool=BOONS.filter(b=>!have.includes(b.id));if(pool.length<3)pool=BOONS.slice();
  const out=[];while(out.length<3&&pool.length)out.push(pool.splice(Math.floor(rng()*pool.length),1)[0]);return out;
}
const boonSum=k=>(RUSH.on&&RUSH.mode==='weekly'?RUSH.boons:[]).reduce((s,id)=>s+((BOONS.find(b=>b.id===id)||{})[k]||0),0);
const boonDmg=()=>1+boonSum('dmg');
const boonDef=()=>Math.max(.4,1-boonSum('def'));
const boonHp=()=>Math.round(boonSum('hp'))+Math.round((80+15*(P.lv-1))*boonSum('hpPct'));
const boonScore=()=>1+boonSum('score');
function boonTake(id){
  const b=BOONS.find(x=>x.id===id);if(!b||RUSH.boons.includes(id))return false;RUSH.boons.push(id);
  if(b.hp)P.hp=Math.min(maxHp(),P.hp+b.hp);P.hp=Math.min(P.hp,maxHp());toast('BOON: '+b.n+' - '+b.d,3,'#ffe14d');sfx('level');return true;
}
// scene between floors: reuses the cutscene engine with a dynamic choice
function boonOffer(floor){
  const ch=boonChoices(floor).map(b=>({t:b.n+': '+b.d,fn:()=>boonTake(b.id),then:[]}));
  return startCut('boon',null,[{w:'narr',t:`FLOOR ${floor+1} CLEARED. A hollow altar offers a boon for the rest of this run.`,ch}]);
}
function weeklyBuff(e,pl){
  e.mhp=Math.round(e.mhp*pl.hpMul);e.hp=e.maxhp=e.mhp;e.dm*=pl.dmMul;
}
const weeklyScore=pts=>Math.round(pts*boonScore());
// run ended: leaderboard, one-time chest on a full clear, best floor for achievements
function weeklyFinish(res,why){
  wkEnsure();res.floors=RUSH.round;res.name=weeklyName();res.won=why==='won';
  ACH.s.bestFloor=Math.max(ACH.s.bestFloor,res.floors);WK.best=Math.max(WK.best,res.floors);
  if(res.floors>0){WK.lb.push(res);WK.lb.sort((a,b)=>b.score-a.score);WK.lb=WK.lb.slice(0,WEEKLY_CFG.keep);res.rank=WK.lb.indexOf(res)+1;}
  res.reward=null;
  if(res.won&&!WK.claimed){WK.claimed=true;res.reward=giveReward(WEEKLY_CFG.reward);ACH.s.weeklyWins++;}
  wkSave();return res;
}
function weeklyDlg(res){
  const L=[];
  L.push(res.won?`The ${res.name} is conquered! All ${WEEKLY_CFG.floors} floors cleared, score ${res.score}, time ${rushTime(res.time)}.`
    :res.floors?`You fell on floor ${res.floors+1} of the ${res.name}: ${res.floors} cleared, score ${res.score}.`:'You never cleared a floor. The crypt will keep until next week.');
  if(res.reward)L.push('Weekly chest: '+res.reward.join(', ')+'.');
  else if(res.won)L.push('You already claimed this week\'s chest. Come back when the seed changes.');
  else if(res.rank)L.push(res.rank===1?'Top of this week\'s board!':'You placed #'+res.rank+' this week.');
  return {name:'ARENA MASTER',lines:L,i:0,c:0};
}
