
/* ---------- audio (WebAudio synth, no files) ---------- */
let AC=null,muted=false;
function ensureAudio(){try{if(!AC)AC=new (window.AudioContext||window.webkitAudioContext)();if(AC&&AC.state!=='running')AC.resume();
  if(AC&&!ensureAudio.u){ensureAudio.u=1;const b=AC.createBuffer(1,1,22050),s=AC.createBufferSource();s.buffer=b;s.connect(AC.destination);s.start(0);}}catch(e){}}
document.addEventListener('visibilitychange',()=>{if(!document.hidden)ensureAudio();});
/* t138u: softer SFX - everything goes through one bus: a low-pass filter (less treble) + a gentle master level.
   Harsh square/sawtooth voices are swapped for triangle/sine, every note fades in over a few ms and out smoothly. */
const SFX_SOFT={lp:2000,nlp:1300,vol:.62,attack:.012};
let sfxBus=null;
function sfxOut(){if(sfxBus&&sfxBus.ctx===AC)return sfxBus.in;
  const lp=AC.createBiquadFilter();lp.type='lowpass';lp.frequency.value=SFX_SOFT.lp;lp.Q.value=.5;
  const g=AC.createGain();g.gain.value=SFX_SOFT.vol;lp.connect(g);g.connect(AC.destination);sfxBus={ctx:AC,in:lp,g};return lp;}
const softWave=w=>w==='square'||w==='sawtooth'?'triangle':w;
function softEnv(g,v,t,d){const a=Math.min(SFX_SOFT.attack,d*.3);g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(v,t+a);g.gain.setTargetAtTime(0.0001,t+a,Math.max(.02,(d-a)/3.2));}
function tone(f0,f1,d,w='square',v=.05,delay=0){
  if(muted||!AC)return;v*=sfxVol();if(w==='square'||w==='sawtooth')v*=1.25;   // triangle is quieter than square: keep the level roughly even
  const t=AC.currentTime+delay,o=AC.createOscillator(),g=AC.createGain();
  o.type=softWave(w);o.frequency.setValueAtTime(Math.min(f0,1800),t);o.frequency.exponentialRampToValueAtTime(Math.max(20,Math.min(f1,1800)),t+d);
  softEnv(g,v,t,d);o.connect(g);g.connect(sfxOut());o.start(t);o.stop(t+d+.25);
}
let noiseBuf=null;
function noise(d,v=.08,delay=0){
  if(muted||!AC)return;v*=sfxVol()*.75;
  if(!noiseBuf){noiseBuf=AC.createBuffer(1,AC.sampleRate*.5,AC.sampleRate);const a=noiseBuf.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;}
  const t=AC.currentTime+delay,s=AC.createBufferSource(),g=AC.createGain(),f=AC.createBiquadFilter();f.type='lowpass';f.frequency.value=SFX_SOFT.nlp;
  s.buffer=noiseBuf;softEnv(g,v,t,d);s.connect(f);f.connect(g);g.connect(sfxOut());s.start(t);s.stop(t+d+.25);
}
const SFXT={
  shoot:()=>tone(950,320,.08,'square',.04),
  charge:()=>tone(260,900,.3,'sawtooth',.035),
  cshot:()=>{tone(180,1300,.22,'sawtooth',.06);noise(.16,.05)},
  hit:()=>{tone(320,90,.1,'square',.05);noise(.07,.04)},
  clang:()=>{tone(1800,900,.12,'triangle',.06);tone(2400,1200,.08,'square',.03)},
  hurt:()=>{tone(240,60,.28,'sawtooth',.08);noise(.18,.06)},
  chip:()=>{tone(600,900,.07,'triangle',.06);tone(900,1400,.1,'triangle',.06,.06)},
  deal:()=>{for(let i=0;i<5;i++)tone(500+i*90,520+i*90,.05,'square',.03,i*.05)},
  select:()=>tone(720,720,.04,'square',.035),
  step:()=>tone(420,380,.03,'square',.02),
  heal:()=>[0,.08,.16].forEach((d,i)=>tone(500+i*200,700+i*200,.12,'sine',.07,d)),
  shield:()=>tone(380,1100,.22,'triangle',.06),
  boom:()=>{noise(.38,.1);tone(130,35,.32,'sawtooth',.07)},
  slash:()=>{noise(.12,.06);tone(1400,300,.14,'sawtooth',.04)},
  warn:()=>tone(1050,1050,.05,'square',.025),
  encounter:()=>[0,.09,.18,.27].forEach((d,i)=>tone(300+i*160,300+i*160,.08,'square',.06,d)),
  win:()=>[0,.12,.24,.4].forEach((d,i)=>tone([523,659,784,1046][i],[523,659,784,1046][i],.18,'square',.06,d)),
  level:()=>[0,.1,.2,.3,.4].forEach((d,i)=>tone([392,523,659,784,1046][i],[392,523,659,784,1046][i],.16,'triangle',.08,d)),
  questdone:()=>{[0,.11,.22,.34,.5].forEach((d,i)=>{const f=[523,659,784,1046,1319][i];tone(f,f*1.004,i===4?.55:.26,'sine',.07,d);tone(f*2,f*2.01,i===4?.4:.16,'triangle',.022,d+.01);});[.5,.56,.62].forEach((d,i)=>tone(2093+i*330,2093+i*330,.14,'sine',.016,d));tone(262,262,.7,'triangle',.035,.34)},   // warm rising chime ending on a held, shimmering C-major
  catch:()=>{noise(.04,.025);tone(784,880,.14,'sine',.055);tone(1175,1240,.2,'sine',.045,.09)},
  catchrare:()=>{noise(.05,.03);[0,.09,.18,.3].forEach((d,i)=>tone([784,988,1175,1568][i],[784,988,1175,1568][i]*1.01,.22,'sine',.06,d));[.28,.38].forEach((d,i)=>tone(2400+i*400,2600+i*400,.1,'sine',.025,d))},
  coin:()=>{tone(1200,1600,.07,'square',.04);tone(1600,1900,.1,'square',.04,.06)},
  talk:()=>tone(520,560,.03,'square',.02),
  lose:()=>[0,.18,.36,.6].forEach((d,i)=>tone([400,330,260,160][i],[380,310,240,120][i],.25,'sawtooth',.06,d)),
  zap:()=>{[0,.04,.08,.12].forEach((d,i)=>tone(1800-i*300,300,.09,'sawtooth',.06,d));noise(.18,.07);tone(90,60,.2,'square',.05,.05)},
  quake:()=>{noise(.5,.14);tone(70,28,.5,'sawtooth',.12);tone(45,25,.55,'sine',.12,.05)},
  meteor:()=>{noise(.6,.16);tone(140,24,.6,'sawtooth',.1);tone(60,20,.7,'sine',.14,.05)},
  poison:()=>{[300,380,260,340].forEach((f,i)=>tone(f,f*.6,.16,'sine',.05,i*.07));noise(.3,.03)},
  whoosh:()=>{noise(.2,.07);tone(900,200,.2,'triangle',.05)},
  howl:()=>{tone(300,520,.35,'sine',.07);tone(520,420,.35,'sine',.06,.3)},
  bite:()=>{noise(.07,.08);tone(220,110,.08,'square',.05)},
  curse:()=>{tone(180,90,.4,'sawtooth',.06);tone(120,70,.5,'triangle',.06,.1);[0,.15].forEach(d=>tone(700,350,.2,'sine',.04,d))},
  timestop:()=>{tone(1200,300,.5,'sine',.07);tone(600,150,.8,'triangle',.06,.1);[0,.25,.5].forEach(d=>tone(1500,1500,.04,'square',.05,d))},
  dragonfire:()=>{noise(.9,.14);tone(100,40,.9,'sawtooth',.1);tone(200,60,.7,'sawtooth',.06,.1)},
  steam:()=>{noise(.55,.12);tone(900,300,.5,'triangle',.05);tone(120,60,.4,'sawtooth',.06)},
  combo:()=>{[523,659,784,1047,1319].forEach((f,i)=>tone(f,f,.12,'square',.06,i*.06));tone(1568,1568,.35,'triangle',.07,.3)},
  ice:()=>{[2200,2900,3500,2600].forEach((f,i)=>tone(f,f*.7,.14,'triangle',.05,i*.045));noise(.22,.06);tone(300,80,.3,'sawtooth',.04)},
  thaw:()=>{tone(1500,600,.18,'triangle',.04);noise(.1,.04)},
  blood:()=>{tone(220,70,.4,'sawtooth',.07);tone(110,55,.45,'sine',.09,.05);noise(.2,.05);[0,.2,.4].forEach((d,i)=>tone(300+i*120,420+i*140,.12,'sine',.05,.3+d))},
  start:()=>[0,.08,.16,.24,.32].forEach((d,i)=>tone(400+i*120,400+i*120,.1,'square',.05,d)),
};
function sfx(n){try{SFXT[n]&&SFXT[n]();}catch(e){}}
