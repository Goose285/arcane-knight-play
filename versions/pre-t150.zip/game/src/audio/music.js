/* =====================================================================
   MUSIC - synthesized looping tracks (no files), one per area + battle + boss, smooth crossfades.
   Each track is data: tempo, key, chord per bar, melody (semitones over the key, null = rest), bass/arp/pad/drum patterns.
   ===================================================================== */
const CHORD_Q={M:[0,4,7],m:[0,3,7],d:[0,3,6],'7':[0,4,7,10]};
const TRACKS={
  village:{bpm:96,key:60,prog:[[0,'M'],[9,'m'],[5,'M'],[7,'M']],lead:{w:'triangle',v:.055,oct:0,pat:[12,null,16,14,12,null,9,null, 9,null,12,11,9,null,4,null, 5,null,9,7,5,null,9,12, 14,null,11,null,7,null,null,null]},
    bass:{w:'triangle',v:.07,pat:[0,null,null,null,2,null,null,null]},arp:{w:'sine',v:.03,pat:[0,1,2,1,0,1,2,1]},pad:{w:'sine',v:.02}},
  meadow:{bpm:112,key:62,prog:[[0,'M'],[5,'M'],[7,'M'],[0,'M']],lead:{w:'square',v:.032,oct:0,pat:[16,17,19,null,17,16,12,null, 17,19,21,null,19,17,14,null, 19,21,23,24,23,null,21,19, 16,null,12,null,7,null,null,null]},
    bass:{w:'triangle',v:.07,pat:[0,null,2,null,0,null,2,null]},arp:{w:'triangle',v:.03,pat:[0,1,2,3,2,1,2,1]},drums:{k:'x...x...',h:'..x...x.'}},
  forest:{bpm:80,key:64,prog:[[0,'m'],[8,'M'],[10,'M'],[0,'m']],lead:{w:'sine',v:.07,oct:0,pat:[null,12,null,15,null,14,12,null, 12,null,15,null,19,null,15,null, 14,null,17,null,22,null,17,null, 19,null,15,null,12,null,null,null]},
    bass:{w:'sine',v:.08,pat:[0,null,null,null,null,null,2,null]},arp:{w:'triangle',v:.02,pat:[0,2,1,2,0,2,1,2]},pad:{w:'triangle',v:.024}},
  castle:{bpm:84,key:62,prog:[[0,'m'],[8,'M'],[10,'M'],[7,'M']],lead:{w:'sawtooth',v:.026,oct:0,pat:[12,null,null,12,15,null,14,null, 12,null,15,null,17,null,15,null, 14,null,17,null,19,null,17,null, 14,null,11,null,7,null,null,null]},
    bass:{w:'sawtooth',v:.04,pat:[0,null,0,null,2,null,0,null]},pad:{w:'triangle',v:.03},drums:{k:'x.....x.',s:'....x...'}},
  dungeon:{bpm:62,key:48,prog:[[0,'m'],[1,'M'],[0,'m'],[7,'M']],lead:{w:'triangle',v:.06,oct:0,pat:[null,null,15,null,null,null,14,null, null,null,13,null,null,null,12,null, null,null,15,null,null,null,18,null, null,null,17,null,null,null,null,null]},
    bass:{w:'sine',v:.1,pat:[0,null,null,null,null,null,null,null]},pad:{w:'sawtooth',v:.016},arp:{w:'sine',v:.02,pat:[null,null,2,null,null,null,1,null]}},
  boss:{bpm:150,key:52,prog:[[0,'m'],[8,'M'],[10,'M'],[7,'7']],lead:{w:'sawtooth',v:.03,oct:0,pat:[24,null,27,24,22,null,24,null, 24,null,27,null,32,31,27,null, 26,null,29,null,34,null,29,26, 31,null,35,null,29,null,26,null]},
    bass:{w:'sawtooth',v:.05,pat:[0,0,null,0,0,null,0,0]},arp:{w:'square',v:.02,pat:[0,1,2,3,2,1,2,3]},drums:{k:'x.x.x.x.',s:'..x...x.',h:'xxxxxxxx'}},
  battle:{bpm:138,key:57,prog:[[0,'m'],[8,'M'],[10,'M'],[7,'M']],lead:{w:'square',v:.03,oct:0,pat:[12,null,15,12,17,null,15,12, 15,null,12,null,8,null,12,15, 14,null,17,null,22,null,17,14, 14,null,11,null,7,null,11,null]},
    bass:{w:'triangle',v:.08,pat:[0,null,0,null,2,null,0,null]},arp:{w:'square',v:.016,pat:[0,1,2,1,0,1,2,1]},drums:{k:'x...x...',s:'....x...',h:'.x.x.x.x'}},
};
Object.assign(TRACKS,{
  snow:{bpm:68,key:57,prog:[[0,'m'],[8,'M'],[3,'M'],[7,'M']],lead:{w:'sine',v:.06,oct:0,pat:[null,19,null,null,22,null,21,null, null,17,null,null,19,null,null,null, null,19,null,22,null,24,null,22, null,null,21,null,19,null,null,null]},
    bass:{w:'sine',v:.07,pat:[0,null,null,null,null,null,null,null]},arp:{w:'triangle',v:.02,pat:[0,2,1,2,0,2,1,2]},pad:{w:'triangle',v:.03}},
  swamp:{bpm:74,key:50,prog:[[0,'m'],[1,'M'],[0,'m'],[10,'M']],lead:{w:'triangle',v:.055,oct:0,pat:[12,null,null,13,null,12,null,null, 15,null,13,null,12,null,null,null, 10,null,null,12,null,13,null,null, 12,null,null,null,null,null,null,null]},
    bass:{w:'sawtooth',v:.035,pat:[0,null,null,0,null,null,2,null]},arp:{w:'sine',v:.022,pat:[0,null,1,null,2,null,1,null]},pad:{w:'sawtooth',v:.012},drums:{k:'x.....x.',h:'..x...x.'}},
  desert:{bpm:104,key:57,prog:[[0,'m'],[1,'M'],[0,'m'],[1,'M']],lead:{w:'square',v:.03,oct:0,pat:[12,13,16,13,12,null,13,null, 16,17,16,13,12,null,null,null, 12,13,16,17,19,17,16,13, 12,null,13,12,null,null,null,null]},
    bass:{w:'triangle',v:.07,pat:[0,null,0,0,null,0,2,null]},arp:{w:'triangle',v:.026,pat:[0,1,2,1,0,1,2,1]},drums:{k:'x..x..x.',s:'....x...',h:'x.x.x.x.'}},
});
const MUS={master:null,live:[],name:'',notes:0,vol:.34,target:0,nb:null};
const mfreq=m=>440*Math.pow(2,(m-69)/12);
function musInit(){if(!AC||MUS.master)return;MUS.master=AC.createGain();MUS.master.gain.value=0;MUS.master.connect(AC.destination);}
function mnote(tr,t,midi,dur,w,v){
  const o=AC.createOscillator(),g=AC.createGain();o.type=w;o.frequency.setValueAtTime(mfreq(midi),t);
  g.gain.setValueAtTime(0.0001,t);g.gain.linearRampToValueAtTime(v,t+.012);g.gain.exponentialRampToValueAtTime(0.0001,t+dur);
  o.connect(g);g.connect(tr.g);o.start(t);o.stop(t+dur+.05);MUS.notes++;
}
function mdrum(tr,t,kind){
  if(kind==='k'){const o=AC.createOscillator(),g=AC.createGain();o.frequency.setValueAtTime(140,t);o.frequency.exponentialRampToValueAtTime(42,t+.12);g.gain.setValueAtTime(.16,t);g.gain.exponentialRampToValueAtTime(.0001,t+.16);o.connect(g);g.connect(tr.g);o.start(t);o.stop(t+.2);}
  else{
    if(!MUS.nb){MUS.nb=AC.createBuffer(1,AC.sampleRate*.3,AC.sampleRate);const a=MUS.nb.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;}
    const s=AC.createBufferSource(),g=AC.createGain(),f=AC.createBiquadFilter();s.buffer=MUS.nb;f.type='highpass';f.frequency.value=kind==='h'?6500:1800;
    g.gain.setValueAtTime(kind==='h'?.03:.07,t);g.gain.exponentialRampToValueAtTime(.0001,t+(kind==='h'?.04:.13));s.connect(f);f.connect(g);g.connect(tr.g);s.start(t);s.stop(t+.16);
  }
  MUS.notes++;
}
function musStep(tr,t){
  const d=tr.d,sd=60/d.bpm/2,bar=Math.floor(tr.step/8)%d.prog.length,sb=tr.step%8,[root,q]=d.prog[bar],iv=CHORD_Q[q],base=d.key+root;
  const lp=d.lead.pat[tr.step%d.lead.pat.length];if(lp!=null)mnote(tr,t,d.key+lp+(d.lead.oct||0),sd*1.8,d.lead.w,d.lead.v);
  if(d.bass){const bi=d.bass.pat[sb];if(bi!=null)mnote(tr,t,base-24+iv[Math.min(bi,iv.length-1)],sd*1.9,d.bass.w,d.bass.v);}
  if(d.arp){const ai=d.arp.pat[sb];if(ai!=null){const n=iv[ai%iv.length]+(ai>=iv.length?12:0);mnote(tr,t,base+n+12,sd*1.2,d.arp.w,d.arp.v);}}
  if(d.pad&&sb===0)for(const i of iv)mnote(tr,t,base+i,sd*7.6,d.pad.w,d.pad.v);
  if(d.drums){for(const k of ['k','s','h'])if(d.drums[k]&&d.drums[k][sb]==='x')mdrum(tr,t,k);}
}
function musSet(name){
  if(!AC||!MUS.master||name===MUS.name||!TRACKS[name])return;
  const now=AC.currentTime;MUS.name=name;
  for(const o of MUS.live){if(o.dead)continue;o.g.gain.cancelScheduledValues(now);o.g.gain.setValueAtTime(o.g.gain.value,now);o.g.gain.linearRampToValueAtTime(0,now+1.6);o.dead=now+2;}   // old track fades out...
  const g=AC.createGain();g.gain.setValueAtTime(0,now);g.gain.linearRampToValueAtTime(1,now+1.6);g.connect(MUS.master);        // ...while the new one fades in
  MUS.live.push({name,d:TRACKS[name],g,step:0,next:now+.08,dead:0});
}
function musWant(){
  if(state==='title'||state==='fishlab')return 'village';
  if(B&&B.phase!=='win'&&B.phase!=='reward'&&B.phase!=='lose')return B.ens.some(e=>e.def.boss&&!e.dying)?'boss':'battle';
  switch(areaName(Math.floor(P.x/TS),Math.floor(P.y/TS))){
    case 'OAKVALE VILLAGE':case FARM_NAME:return 'village';case 'WHISPERWOOD':return 'forest';case 'CASTLE DRACORYN':return 'castle';case CRYPT_NAME:return 'dungeon';case ARENA_NAME:return 'castle';case HOUSE_NAME:return 'village';case ZONE_NAME.snow:return 'snow';case ZONE_NAME.swamp:return 'swamp';case ZONE_NAME.desert:return 'desert';
    default:return 'meadow';}
}
function musUpdate(dt){
  if(!AC)return;musInit();if(!MUS.master)return;
  const want=musWant();if(want!==MUS.name)musSet(want);
  const tgt=muted?0:MUS.vol*musVol()*(state==='paused'||isUI()?.45:1);                                   // mute toggle silences music; menus duck it
  if(Math.abs(tgt-MUS.target)>1e-4){MUS.target=tgt;MUS.master.gain.setTargetAtTime(tgt,AC.currentTime,.12);}
  const now=AC.currentTime;
  for(let i=MUS.live.length-1;i>=0;i--){
    const tr=MUS.live[i];
    if(tr.dead&&now>tr.dead){tr.g.disconnect();MUS.live.splice(i,1);continue;}
    if(muted){tr.next=Math.max(tr.next,now);continue;}                                         // keep the beat counter, schedule nothing
    if(tr.next<now-.15)tr.next=now+.03;
    while(tr.next<now+.3){musStep(tr,tr.next);tr.next+=60/tr.d.bpm/2;tr.step++;}
  }
}
