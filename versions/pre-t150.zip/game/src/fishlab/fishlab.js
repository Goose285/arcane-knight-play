/* =====================================================================
   FISHING LAB (prototype): a small pond test area on the title menu with 5 fishing mechanics to try out.
   Totally isolated: own state (FL), own fish table, never touches FISH / the main game's fishing / the save (saveGame is blocked in this state).
   Every mode is deliberately slow and relaxed.  Tunables are all in FLCFG.
   ===================================================================== */
const FLCFG={
  // timing bar
  tWait:[3,6.5],tSpeed:.42,tSpeedRar:.03,tZone:.34,tZoneRar:.05,tTimeout:9,   // needle: ~2.4s per sweep; zone shrinks with rarity (common 34% -> legendary 14%)
  // tug of war
  gWait:[3,6.5],gHold:.20,gHoldRar:.02,gRelease:.36,gGain:.12,gLoss:.012,gSurgeEvery:[2.6,4.2],gSurge:.10,gSlackMax:5.5,gStart:.25,
  // idle
  iCatch:[8,15],iRare:[35,60],iBiteWin:4,
  // shadows
  sCount:7,sSpeed:[9,20],sWait:[2.5,4],sSpook:.04,sRespawn:2.5,
  // hybrid
  hCatch:[8,15],hRare:[35,60],hBanner:1.2,
};
const FL_RAR=[{n:'Common',col:'#cfd6e6',w:55},{n:'Uncommon',col:'#7dff8a',w:26},{n:'Rare',col:'#6ab8ff',w:12},{n:'Epic',col:'#c58aff',w:5},{n:'Legendary',col:'#ffb43a',w:2}];
const FL_FISH=[['Silverscale Minnow',0,'#cfe3ff'],['Mudfin Carp',0,'#b08a5a'],['Riverbell Trout',1,'#e8a8c8'],['Greenwood Pike',1,'#7ac060'],['Moonpetal Bass',2,'#c8b8ff'],
  ['Bog Lurker Eel',2,'#8aa860'],['Glowgill',3,'#7dffd0'],['Sunscale Perch',3,'#ffd23f'],['Mirage Koi',4,'#ff8a5a']].map(a=>({n:a[0],rar:a[1],col:a[2]}));
const FL_MODES=[
  {n:'TIMING BAR',tab:'1 TIMING',how:'Tap to cast. When something bites, tap while the needle is inside the green zone. Rarer fish = smaller zone.',note:'Pace: relaxed. Bites take ~3-6s, the needle needs ~2.5s per sweep.'},
  {n:'TUG OF WAR',tab:'2 TUG',how:'Tap to cast. On a bite HOLD to reel and let go to ease the tension. Line snaps at max tension; fish escapes if you stay slack too long.',note:'Pace: gentle. Tension builds slowly, plenty of time to let go.'},
  {n:'IDLE FISHING',tab:'3 IDLE',how:'Cast once and relax: a fish is caught by itself every few seconds. Now and then a RARE BITE pops up - tap within 4s to land it.',note:'Pace: very slow. A catch every ~8-15s, rare bite about once a minute.'},
  {n:'SHADOW SPOTTING',tab:'4 SHADOW',how:'Fish shadows drift in the pond - bigger shadow = rarer fish. Tap a shadow to cast at it, wait a moment, and it is yours.',note:'Pace: lazy. Shadows drift slowly, ~3s wait after casting.'},
  {n:'HYBRID (RECOMMENDED)',tab:'5 HYBRID*',how:'Cast once: common fish bite on their own. A RARE BITE launches a short, easy timing or tug minigame - win it to land the big one.',note:'Pace: relaxed. Idle catch every ~8-15s; rare bites are slow minigames.'},
];
const FL={on:false,mode:0,t:0,m:null,pops:[],bob:null,down:false,ripples:[],cfg:FLCFG,rng:()=>Math.random(),
  stats:FL_MODES.map(()=>({n:0,by:[0,0,0,0,0],esc:0,log:[]}))};
const flR=(a,b)=>a+(b-a)*FL.rng();
const flRr=r=>flR(r[0],r[1]);
function flRoll(lo,hi){   // rarity-weighted fish pick between two rarity tiers
  let tot=0;for(let r=lo;r<=hi;r++)tot+=FL_RAR[r].w;let x=FL.rng()*tot,rar=lo;
  for(let r=lo;r<=hi;r++){x-=FL_RAR[r].w;if(x<=0){rar=r;break;}}
  const pool=FL_FISH.filter(f=>f.rar===rar);return pool[Math.floor(FL.rng()*pool.length)%pool.length];
}
function flGeom(){
  const L=SL+8,R=VW-SR-8,T=ST+6,B=VH-SB-8,th=28,top=T+th+8,pw=Math.floor((R-L)*.62);
  const g={L,R,T,B,back:{x:L,y:T,w:54,h:th},tabs:[],pond:{x:L,y:top,w:pw,h:B-top},side:{x:L+pw+8,y:top,w:R-L-pw-8,h:B-top}};
  const tx=L+60,tw=Math.floor((R-tx-4*4)/5);for(let i=0;i<5;i++)g.tabs.push({x:tx+i*(tw+4),y:T,w:tw,h:th});
  const p=g.pond;g.dock={x:p.x,y:p.y+Math.round(p.h*.6)};g.tip={x:p.x+58,y:g.dock.y-34};
  g.game={x:p.x+10,y:p.y+p.h-66,w:p.w-20,h:58};g.reel={x:p.x+p.w-96,y:p.y+p.h-34,w:86,h:24};
  return g;
}
const flBobXY=(g,b)=>({x:g.pond.x+b.u*g.pond.w,y:g.pond.y+b.v*g.pond.h});
function flPop(s,col,x,y){FL.pops.push({s,col:col||'#fff',x,y,t:0});if(FL.pops.length>6)FL.pops.shift();}
function flCenterPop(s,col){const g=flGeom();flPop(s,col,g.pond.x+g.pond.w*.55,g.pond.y+g.pond.h*.28);}
function flCatch(f){
  const st=FL.stats[FL.mode];st.n++;st.by[f.rar]++;st.log.unshift({n:f.n,rar:f.rar,col:f.col});if(st.log.length>7)st.log.pop();
  const r=FL_RAR[f.rar];flCenterPop(f.n+'!  ('+r.n+')',r.col);sfx(f.rar>=3?'level':f.rar>=2?'coin':'select');
  if(FL.bob)FL.ripples.push({u:FL.bob.u,v:FL.bob.v,t:0});
}
function flEscape(why){FL.stats[FL.mode].esc++;flCenterPop(why||'It got away...','#ff9a8a');sfx('clang');}
/* ---- mini-games (shared by timing, tug and hybrid) ---- */
function flTimingNew(rar,quick){const c=FL.cfg,zw=c.tZone-c.tZoneRar*rar,sp=(c.tSpeed+c.tSpeedRar*rar)*(quick?1.1:1);
  return {k:'timing',rar,pos:0,dir:1,sp,zw,zc:flR(zw/2+.06,1-zw/2-.06),t:0,max:c.tTimeout,done:null};}
function flTimingUpdate(g,dt){if(g.done)return;g.t+=dt;g.pos+=g.dir*g.sp*dt;if(g.pos>=1){g.pos=1;g.dir=-1;}if(g.pos<=0){g.pos=0;g.dir=1;}if(g.t>g.max){g.done='lose';g.why='Too slow - it got away...';}}
function flTimingTap(g){if(g.done)return;if(Math.abs(g.pos-g.zc)<=g.zw/2)g.done='win';else{g.done='lose';g.why='Missed the zone - it got away...';}}
function flTugNew(rar,quick){const c=FL.cfg;return {k:'tug',rar,ten:c.gStart,prog:quick?.4:.12,hold:false,surge:0,surgeT:flRr(c.gSurgeEvery),slack:0,quick:!!quick,t:0,done:null};}
function flTugUpdate(g,dt,hold){if(g.done)return;const c=FL.cfg;g.t+=dt;g.hold=hold;
  if(g.surge>0){g.surge-=dt;}else{g.surgeT-=dt;if(g.surgeT<=0){g.surge=1+.15*g.rar;g.surgeT=flRr(c.gSurgeEvery);}}
  const sg=g.surge>0;
  if(hold){g.ten+=(c.gHold+c.gHoldRar*g.rar+(sg?c.gSurge+.015*g.rar:0))*dt;g.prog+=(c.gGain*(g.quick?1.5:1)-(sg?.03:0))*dt;}
  else{g.ten-=(c.gRelease-(sg?.14:0))*dt;g.prog-=(c.gLoss+(sg?.025:0))*dt;}
  g.ten=Math.max(0,g.ten);g.prog=clamp(g.prog,0,1);
  if(!hold&&g.ten<.05)g.slack+=dt;else g.slack=Math.max(0,g.slack-dt*2);
  if(g.ten>=1){g.ten=1;g.done='lose';g.why='SNAP! The line broke...';}
  else if(g.slack>c.gSlackMax){g.done='lose';g.why='Too much slack - it swam off...';}
  else if(g.prog>=1)g.done='win';}
/* ---- per-mode state ---- */
function flSetMode(i){
  FL.mode=i;FL.m={ph:'idle',t:0};FL.bob=null;FL.down=false;FL.pops.length=0;FL.ripples.length=0;
  if(i===3)flShadowInit();
  sfx('select');
}
function flCastTo(u,v){FL.bob={u,v};FL.m.cast=0;sfx('whoosh');}
function flShadowInit(){const g=flGeom(),m=FL.m;m.sh=[];for(let k=0;k<FL.cfg.sCount;k++)m.sh.push(flShadowMake(g,true));m.respawn=[];}
function flShadowMake(g,anywhere){
  const p=g.pond,rr=flRoll(0,4).rar,f=flRoll(rr,rr),a=FL.rng()*6.283,sp=flRr(FL.cfg.sSpeed);
  return {x:anywhere?flR(p.w*.18,p.w*.92):p.w+10,y:flR(p.h*.12,p.h*.8),vx:Math.cos(a)*sp,vy:Math.sin(a)*sp*.6,rar:rr,f,r:7+rr*4.5,tt:flR(2,5),tap:0};
}
function flStartIdle(m,cfg){m.ph='on';m.next=flRr(cfg.iCatch||cfg.hCatch);m.rare=flRr(cfg.iRare||cfg.hRare);m.t=0;}
/* tap handling: returns nothing, acts on the current mode.  p = pointer position (or null for the keyboard) */
function flAct(p){
  const m=FL.m,g=flGeom(),md=FL.mode,pd=g.pond;
  const inPond=p&&p.x>=pd.x&&p.x<=pd.x+pd.w&&p.y>=pd.y&&p.y<=pd.y+pd.h;
  if(md===0||md===1){
    if(m.ph==='idle'){flCastTo(flR(.55,.85),flR(.3,.62));m.ph='cast';m.t=0;}
    else if(m.ph==='game'&&md===0)flTimingTap(m.g);
    return;}
  if(md===2||md===4){
    if(m.ph==='idle'){flCastTo(flR(.55,.85),flR(.3,.62));m.ph='cast';m.t=0;return;}
    if(p&&m.ph!=='cast'&&m.ph!=='game'&&m.ph!=='banner'&&inRect(p,g.reel)){m.ph='idle';FL.bob=null;flCenterPop('Reeled in','#cfe0ff');sfx('select');return;}
    if(md===2&&m.ph==='rare'){const f=flRoll(2,4);flCatch(f);m.ph='on';m.next=flRr(FL.cfg.iCatch);m.rare=flRr(FL.cfg.iRare);return;}
    if(md===4&&m.ph==='game'&&m.g.k==='timing')flTimingTap(m.g);
    return;}
  if(md===3&&p&&inPond&&m.ph==='idle'){
    let best=null,bd=1e9;for(const s of m.sh){const d=Math.hypot(pd.x+s.x-p.x,pd.y+s.y-p.y);if(d<s.r*1.6+12&&d<bd){bd=d;best=s;}}
    if(best){m.tgt=best;m.ph='cast';m.t=0;FL.bob={u:best.x/pd.w,v:best.y/pd.h};m.cast=0;sfx('whoosh');}
    else{FL.ripples.push({u:(p.x-pd.x)/pd.w,v:(p.y-pd.y)/pd.h,t:0});flPop('Nothing there - tap a shadow','#9fd8ff',p.x,p.y-14);}
  }
}
function flUpdate(dt){
  FL.t+=dt;const m=FL.m,c=FL.cfg,md=FL.mode,g=flGeom();
  FL.pops.forEach(q=>q.t+=dt);FL.pops=FL.pops.filter(q=>q.t<2.6);FL.ripples.forEach(r=>r.t+=dt);FL.ripples=FL.ripples.filter(r=>r.t<1.4);
  if(m.cast!=null&&m.cast<1)m.cast=Math.min(1,m.cast+dt/.7);
  const hold=FL.down||held('Space','KeyJ');
  if(md===0||md===1){
    const tug=md===1;
    if(m.ph==='cast'){m.t+=dt;if(m.t>=.7){m.ph='wait';m.t=0;m.wait=flRr(tug?c.gWait:c.tWait);}}
    else if(m.ph==='wait'){m.t+=dt;if(m.t>=m.wait){m.ph='bite';m.t=0;m.f=flRoll(0,4);sfx('warn');}}
    else if(m.ph==='bite'){m.t+=dt;if(m.t>=1){m.ph='game';m.g=tug?flTugNew(m.f.rar):flTimingNew(m.f.rar);}}
    else if(m.ph==='game'){if(tug)flTugUpdate(m.g,dt,hold);else flTimingUpdate(m.g,dt);if(m.g.done){m.ph='result';m.t=0;if(m.g.done==='win')flCatch(m.f);else flEscape(m.g.why);}}
    else if(m.ph==='result'){m.t+=dt;if(m.t>=1.6){m.ph='idle';FL.bob=null;}}
  }
  else if(md===2||md===4){
    const hy=md===4;
    if(m.ph==='cast'){m.t+=dt;if(m.t>=.7)flStartIdle(m,hy?{hCatch:c.hCatch,hRare:c.hRare}:c);}
    else if(m.ph==='on'){
      m.next-=dt;m.rare-=dt;
      if(m.next<=0){flCatch(flRoll(0,1));m.next=flRr(hy?c.hCatch:c.iCatch);}
      if(m.rare<=0){m.rare=flRr(hy?c.hRare:c.iRare);
        if(hy){m.ph='banner';m.t=0;m.f=flRoll(2,4);sfx('warn');}else{m.ph='rare';m.t=0;sfx('warn');}}
    }
    else if(m.ph==='rare'){m.t+=dt;if(m.t>=c.iBiteWin){m.ph='on';flEscape('Too slow - it got away...');m.next=Math.max(m.next,flRr([4,8]));}}
    else if(m.ph==='banner'){m.t+=dt;if(m.t>=c.hBanner){m.ph='game';m.g=FL.rng()<.5?flTimingNew(m.f.rar,true):flTugNew(m.f.rar,true);}}
    else if(m.ph==='game'){const gg=m.g;if(gg.k==='tug')flTugUpdate(gg,dt,hold);else flTimingUpdate(gg,dt);
      if(gg.done){m.ph='result';m.t=0;if(gg.done==='win')flCatch(m.f);else flEscape(gg.why);}}
    else if(m.ph==='result'){m.t+=dt;if(m.t>=1.5){m.ph='on';m.next=Math.max(m.next,flRr([4,8]));}}
  }
  else if(md===3){
    const p=g.pond;
    for(const s of m.sh){
      s.tt-=dt;if(s.tt<=0){s.tt=flR(2,5);const a=FL.rng()*6.283,sp=flRr(c.sSpeed);s.vx=Math.cos(a)*sp;s.vy=Math.sin(a)*sp*.6;}
      if(m.tgt===s&&(m.ph==='wait'||m.ph==='cast')){const bx=FL.bob.u*p.w,by=FL.bob.v*p.h;s.vx=(bx-s.x)*.8;s.vy=(by-s.y)*.8;s.tap=1;}
      s.x+=s.vx*dt;s.y+=s.vy*dt;
      if(s.x<12){s.x=12;s.vx=Math.abs(s.vx);}if(s.x>p.w-12){s.x=p.w-12;s.vx=-Math.abs(s.vx);}
      if(s.y<14){s.y=14;s.vy=Math.abs(s.vy);}if(s.y>p.h*.88){s.y=p.h*.88;s.vy=-Math.abs(s.vy);}
    }
    if(m.ph==='cast'){m.t+=dt;if(m.t>=.7){m.ph='wait';m.t=0;m.wait=flRr(c.sWait);}}
    else if(m.ph==='wait'){m.t+=dt;
      if(m.tgt&&m.sh.includes(m.tgt)){const s=m.tgt;FL.bob.u=s.x/p.w;FL.bob.v=s.y/p.h;}
      if(m.t>=m.wait){const s=m.tgt;m.sh.splice(m.sh.indexOf(s),1);m.respawn.push(c.sRespawn);
        if(FL.rng()<c.sSpook*s.rar){flEscape('It spooked and swam off...');}else flCatch(s.f);
        m.ph='result';m.t=0;m.tgt=null;}}
    else if(m.ph==='result'){m.t+=dt;if(m.t>=1.2){m.ph='idle';FL.bob=null;}}
    m.respawn=m.respawn.map(x=>x-dt).filter(x=>{if(x<=0){m.sh.push(flShadowMake(g,false));return false;}return true;});
  }
}
function flEnter(){FL.on=true;state='fishlab';releaseAllTouch();flSetMode(FL.mode||0);}
function flExit(){
  FL.on=false;FL.down=false;state='title';releaseAllTouch();sfx('select');
  titleMenu.items.length=0;initTitleMenu();const i=titleMenu.items.indexOf('Fishing Lab');if(i>=0)titleMenu.sel=i;
}
function updateFishLab(dt){
  if(hit('Escape','Backspace')){flExit();return;}
  for(let i=0;i<5;i++)if(hit('Digit'+(i+1))&&FL.mode!==i)flSetMode(i);
  if(hit('KeyQ','ArrowLeft')&&FL.mode>0)flSetMode(FL.mode-1);
  if(hit('KeyE','ArrowRight')&&FL.mode<4)flSetMode(FL.mode+1);
  if(hit('Space','Enter','KeyJ'))flAct(null);
  flUpdate(dt);
}
/* pointer input (routed from touch.js / mouse) */
function flDown(p){
  const g=flGeom();
  if(inRect(p,g.back)){flExit();return;}
  const i=g.tabs.findIndex(r=>inRect(p,r));
  if(i>=0){if(i!==FL.mode)flSetMode(i);return;}
  FL.down=true;flAct(p);
}
function flUp(){FL.down=false;}
