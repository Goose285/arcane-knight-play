/* ---- Fishing Lab drawing (landscape-first: pond on the left, mode info + catch counters on the right) ---- */
function flButton(r,label,o={}){
  ctx.fillStyle=o.sel?'#3a5a2a':'#1a1630';ctx.fillRect(r.x,r.y,r.w,r.h);
  ctx.strokeStyle=o.sel?'#ffe14d':'#8a86b8';ctx.lineWidth=o.sel?3:2;ctx.strokeRect(r.x+1,r.y+1,r.w-2,r.h-2);
  txt(label,r.x+r.w/2,r.y+r.h/2+4,{size:o.size||10,align:'center',col:o.sel?'#fff':'#cfd0ff',lw:3});
}
function flFishIcon(x,y,len,col,dir,alpha){
  ctx.save();ctx.globalAlpha=alpha==null?1:alpha;ctx.translate(x,y);ctx.scale(dir<0?-1:1,1);ctx.fillStyle=col;
  ctx.beginPath();ctx.ellipse(0,0,len/2,len/4,0,0,6.283);ctx.fill();
  ctx.beginPath();ctx.moveTo(-len/2+2,0);ctx.lineTo(-len/2-len*.28,-len*.2);ctx.lineTo(-len/2-len*.28,len*.2);ctx.fill();
  ctx.fillStyle='rgba(0,0,0,.55)';ctx.fillRect(len*.22,-len*.08,Math.max(2,len*.07),Math.max(2,len*.07));ctx.restore();
}
function flDrawPond(g){
  const p=g.pond;ctx.save();
  ctx.fillStyle='#2c5a2a';ctx.fillRect(p.x,p.y,p.w,p.h);
  const gr=ctx.createLinearGradient(0,p.y,0,p.y+p.h);gr.addColorStop(0,'#2a7ba6');gr.addColorStop(1,'#14477a');
  ctx.fillStyle=gr;ctx.fillRect(p.x+4,p.y+4,p.w-8,p.h-8);
  ctx.beginPath();ctx.rect(p.x+4,p.y+4,p.w-8,p.h-8);ctx.clip();
  ctx.strokeStyle='rgba(255,255,255,.14)';ctx.lineWidth=2;
  for(let i=0;i<14;i++){const yy=p.y+20+(i*37)%(p.h-40),xx=p.x+((i*83+gtime*8*(1+i%3*.3))%(p.w+40))-20;ctx.beginPath();ctx.moveTo(xx,yy);ctx.lineTo(xx+16,yy);ctx.stroke();}
  [[.3,.2],[.82,.72],[.5,.82],[.9,.2]].forEach(([u,v],i)=>{const x=p.x+u*p.w,y=p.y+v*p.h+Math.sin(gtime*.6+i)*1.5;ctx.fillStyle='#3f8a3a';ctx.beginPath();ctx.ellipse(x,y,13,7,0,0,6.283);ctx.fill();ctx.fillStyle='#ffb0d0';ctx.fillRect(x-2,y-2,4,4);});
  ctx.restore();
  ctx.strokeStyle='#e8e0c8';ctx.lineWidth=2;ctx.strokeRect(p.x+1,p.y+1,p.w-2,p.h-2);
  // dock + angler
  ctx.fillStyle='#8a5a2a';ctx.fillRect(g.dock.x+2,g.dock.y,64,12);ctx.fillStyle='#6a4018';for(let i=0;i<4;i++)ctx.fillRect(g.dock.x+8+i*16,g.dock.y,3,12);
  const hs=SP.hero&&SP.hero.r&&SP.hero.r[1];if(hs){const s=2;draw(hs,g.dock.x+14,g.dock.y-hs.height*s+4,s);}
  ctx.strokeStyle='#c08a52';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(g.dock.x+36,g.dock.y-12);ctx.lineTo(g.tip.x,g.tip.y);ctx.stroke();
}
function flBobPos(g){
  const m=FL.m;if(!FL.bob)return null;const t=flBobXY(g,FL.bob),k=m.cast!=null?m.cast:1;
  if(k>=1)return t;const x=g.tip.x+(t.x-g.tip.x)*k,y=g.tip.y+(t.y-g.tip.y)*k-Math.sin(k*Math.PI)*40;return {x,y};
}
function flDrawLineBob(g){
  const b=flBobPos(g);if(!b)return;const m=FL.m;
  const taut=m.ph==='game'&&m.g&&m.g.k==='tug'?clamp(m.g.ten,0,1):.15,sag=(1-taut)*22+4;
  ctx.strokeStyle='rgba(255,255,255,.8)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(g.tip.x,g.tip.y);ctx.quadraticCurveTo((g.tip.x+b.x)/2,(g.tip.y+b.y)/2+sag,b.x,b.y);ctx.stroke();
  const dip=(m.ph==='bite'||(m.ph==='game'&&FL.mode!==2))?Math.abs(Math.sin(gtime*7))*4:(m.ph==='rare'?Math.abs(Math.sin(gtime*7))*4:Math.sin(gtime*1.6)*1.2),by=b.y+dip;
  ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(b.x,by,5,0,6.283);ctx.fill();ctx.fillStyle='#e8504a';ctx.beginPath();ctx.arc(b.x,by-1.5,4,Math.PI,6.283);ctx.fill();
  for(const r of FL.ripples){const q=flBobXY(g,r);ctx.strokeStyle='rgba(255,255,255,'+(.6*(1-r.t/1.4))+')';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(q.x,q.y,6+r.t*26,3+r.t*12,0,0,6.283);ctx.stroke();}
}
function flDrawGame(g,gm){
  const r=g.game;panel(r.x,r.y,r.w,r.h,{fill:'#10142a'});
  if(gm.k==='timing'){
    const bx=r.x+16,bw=r.w-32,by=r.y+26,bh=18;
    ctx.fillStyle='#000';ctx.fillRect(bx-2,by-2,bw+4,bh+4);ctx.fillStyle='#3a2a2a';ctx.fillRect(bx,by,bw,bh);
    ctx.fillStyle=FL_RAR[gm.rar].col;ctx.globalAlpha=.35;ctx.fillRect(bx+(gm.zc-gm.zw/2)*bw-2,by-2,gm.zw*bw+4,bh+4);ctx.globalAlpha=1;
    ctx.fillStyle='#4fdc6a';ctx.fillRect(bx+(gm.zc-gm.zw/2)*bw,by,gm.zw*bw,bh);
    const nx=bx+gm.pos*bw;ctx.fillStyle='#fff';ctx.fillRect(nx-2,by-6,4,bh+12);
    txt('TAP when the needle is in the green!   ('+FL_RAR[gm.rar].n+' fish)',r.x+r.w/2,r.y+16,{size:10,align:'center',col:'#e8e0c8',lw:3});
  } else {
    const bx=r.x+16,bw=r.w-32;
    txt('HOLD to reel - let go to ease the line  ('+FL_RAR[gm.rar].n+' fish)',r.x+r.w/2,r.y+14,{size:10,align:'center',col:'#e8e0c8',lw:3});
    ctx.fillStyle='#000';ctx.fillRect(bx-2,r.y+19,bw+4,16);ctx.fillStyle='#233';ctx.fillRect(bx,r.y+21,bw,12);
    ctx.fillStyle='#2a5a2a';ctx.fillRect(bx+bw*.08,r.y+21,bw*.62,12);ctx.fillStyle='#6a2a2a';ctx.fillRect(bx+bw*.8,r.y+21,bw*.2,12);
    ctx.fillStyle=gm.ten>.8?'#ff5a4a':gm.ten>.6?'#ffd23f':'#7dffa0';ctx.fillRect(bx,r.y+21,bw*gm.ten,12);
    txt('TENSION',bx+4,r.y+31,{size:8,col:'#fff',lw:2});
    ctx.fillStyle='#000';ctx.fillRect(bx-2,r.y+38,bw+4,14);ctx.fillStyle='#223';ctx.fillRect(bx,r.y+40,bw,10);ctx.fillStyle='#7dc8ff';ctx.fillRect(bx,r.y+40,bw*gm.prog,10);
    txt('REELED',bx+4,r.y+49,{size:8,col:'#fff',lw:2});
  }
}
function flDrawPond2(g){
  const p=g.pond,m=FL.m,md=FL.mode;
  // shadows (mode 4)
  if(md===3&&m.sh)for(const s of m.sh){
    const sel=m.tgt===s;flFishIcon(p.x+s.x,p.y+s.y,s.r*2.4,'#04182c',s.vx<0?-1:1,.55+(sel?.2:0));
    if(!m.tgt)ctx.globalAlpha=1;
  }
  // the hooked fish, swimming under the bobber, during a game
  if(m.ph==='game'||m.ph==='bite'){const b=flBobPos(g);if(b&&m.f){const k=m.g?(m.g.k==='tug'?m.g.prog:.5):.5;flFishIcon(b.x+Math.sin(gtime*1.3)*14*(1-k*.6),b.y+10+Math.cos(gtime*1.1)*5,16+m.f.rar*5,'rgba(4,24,44,.7)',Math.cos(gtime*1.3)>0?1:-1,.75);}}
  flDrawLineBob(g);
  // prompts
  const cx=p.x+p.w/2,py=p.y+p.h*.2;
  const cast=(md===3)?'TAP A SHADOW TO CAST':'TAP TO CAST';
  if(m.ph==='idle')txt(cast,cx,py,{size:15,align:'center',col:'#fff',lw:5,alpha:.7+.3*Math.sin(gtime*3)});
  if(m.ph==='wait'||(m.ph==='cast'&&md<2))txt('waiting for a bite...',cx,py,{size:11,align:'center',col:'#cfe0ff',lw:3,alpha:.8});
  if(m.ph==='bite')txt('SOMETHING BIT!',cx,py,{size:18,align:'center',col:'#ffe14d',lw:5});
  if((md===2||md===4)&&m.ph==='on'){
    txt('fishing...  relax',cx,py,{size:12,align:'center',col:'#cfe0ff',lw:3,alpha:.8});
    flButton(g.reel,'REEL IN',{size:9});
  }
  if(md===2&&m.ph==='rare'){
    const f=1-m.t/FL.cfg.iBiteWin;txt('RARE BITE!',cx,p.y+p.h*.36,{size:24,align:'center',col:'#ffb43a',lw:6});
    txt('TAP NOW!',cx,p.y+p.h*.36+22,{size:14,align:'center',col:'#fff',lw:4});
    ctx.strokeStyle='#ffe14d';ctx.lineWidth=5;ctx.beginPath();ctx.arc(cx,p.y+p.h*.58,26,-Math.PI/2,-Math.PI/2+f*6.283);ctx.stroke();
    txt(Math.ceil(FL.cfg.iBiteWin-m.t)+'',cx,p.y+p.h*.58+5,{size:15,align:'center',col:'#fff',lw:4});
  }
  if(md===4&&m.ph==='banner'){txt('RARE BITE!',cx,p.y+p.h*.36,{size:24,align:'center',col:'#ffb43a',lw:6});txt('get ready...',cx,p.y+p.h*.36+20,{size:12,align:'center',col:'#fff',lw:4});}
  if(m.ph==='game'&&m.g)flDrawGame(g,m.g);
  for(const q of FL.pops){const a=q.t<2?1:1-(q.t-2)/.6;txt(q.s,q.x,q.y-q.t*8,{size:13,align:'center',col:q.col,lw:4,alpha:a});}
}
function flDrawSide(g){
  const s=g.side,md=FL_MODES[FL.mode],st=FL.stats[FL.mode];panel(s.x,s.y,s.w,s.h,{fill:'#14102a'});
  let y=s.y+18;const x=s.x+10,w=s.w-20,font='bold '+scaleText(9)+'px "Courier New",monospace';
  txt(md.n,x,y,{size:12,col:'#ffcf3a',lw:4});y+=14;
  for(const l of wrapText(md.note,w,font)){txt(l,x,y,{size:9,col:'#9fe8ff',lw:3});y+=11;}y+=3;
  for(const l of wrapText(md.how,w,font)){txt(l,x,y,{size:9,col:'#e8e0c8',lw:3});y+=11;}
  y=Math.max(y+6,s.y+s.h-132);
  txt('CAUGHT '+st.n,x,y,{size:13,col:'#fff',lw:4});txt('escaped '+st.esc,x+w,y,{size:9,align:'right',col:'#ff9a8a',lw:3});y+=8;
  const cw=Math.floor(w/5);
  for(let i=0;i<5;i++){const cx=x+i*cw;ctx.fillStyle=FL_RAR[i].col;ctx.globalAlpha=st.by[i]?1:.3;ctx.fillRect(cx,y,cw-3,13);ctx.globalAlpha=1;
    txt(st.by[i]+'',cx+(cw-3)/2,y+10,{size:10,align:'center',col:'#10142a',out:false});txt(FL_RAR[i].n.slice(0,4),cx+(cw-3)/2,y+24,{size:7,align:'center',col:FL_RAR[i].col,lw:2});}
  y+=36;
  if(!st.log.length)txt('(no catches yet)',x,y,{size:9,col:'#8a86b8',lw:2});
  st.log.slice(0,Math.max(1,Math.floor((s.y+s.h-6-y)/11))).forEach((e,i)=>{txt(e.n,x,y+i*11,{size:9,col:e.col,lw:3,alpha:1-i*.08});txt(FL_RAR[e.rar].n,x+w,y+i*11,{size:8,align:'right',col:FL_RAR[e.rar].col,lw:2});});
}
function drawFishLab(){
  const g=flGeom();
  const gr=ctx.createLinearGradient(0,0,0,VH);gr.addColorStop(0,'#10122e');gr.addColorStop(1,'#1c2a3a');ctx.fillStyle=gr;ctx.fillRect(0,0,VW,VH);
  flButton(g.back,'< BACK');
  FL_MODES.forEach((m,i)=>flButton(g.tabs[i],m.tab,{sel:i===FL.mode,size:VW<700?9:10}));
  flDrawPond(g);flDrawPond2(g);flDrawSide(g);
}
