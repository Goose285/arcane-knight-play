/* =====================================================================
   POISON (t138u): a damage-over-time status. Only creatures where it makes sense can inflict it, each with a chance per hit and
   a per-monster cooldown so it can't be stacked again right away. While poisoned you lose a little HP every second (it never
   kills: it stops at 1 HP), the screen edges turn green and a POISON icon with the seconds left sits on the HUD.
   Cured by: the HEAL card, a night at the Inn (or the chapel), sleeping in your own bed. It also wears off.
   ===================================================================== */
const POISONERS={            // chance per landed hit, seconds, cooldown (s) before that monster can poison again
  toad:    {ch:.25,dur:5,cd:7, why:'Bog Toad - toxic skin (swamp)'},
  witch:   {ch:.35,dur:6,cd:9, why:'Mire Witch - poison brew (swamp)'},
  mossback:{ch:.40,dur:7,cd:8, why:'Old Mossback the Bog Hydra - venom bite (swamp boss)'},
  scorpion:{ch:.30,dur:5,cd:7, why:'Dune Scorpion - tail sting (desert)'},
  shscorp: {ch:.30,dur:5,cd:7, why:'Shale Scorpion - tail sting (Shardstone Caverns)'},
  spitter: {ch:.35,dur:4,cd:6, why:'Spore Spitter - toxic spores (Glowcap Grove)'},
  spore:   {ch:.25,dur:4,cd:8, why:'Sir Spore - spore cloud (Glowcap Grove)'},
  colony:  {ch:.30,dur:6,cd:9, why:'The Wandering Colony - spore cloud (Glowcap boss)'},
};
const PSN={t:0,tick:0,dps:0,src:''};
const poisoned=()=>PSN.t>0;
function poisonTry(src){
  const e=src&&src.def?src:null;if(!e)return false;const p=POISONERS[e.type];if(!p)return false;
  if((e.psnCd||0)>gtime)return false;if(Math.random()>=p.ch)return false;
  e.psnCd=gtime+p.cd;return poisonApply(p.dur,e.def.name||e.type);
}
function poisonApply(dur,from){const fresh=PSN.t<=0;PSN.t=Math.max(PSN.t,dur);PSN.src=from||'';if(fresh)PSN.tick=1;PSN.dps=Math.max(1,Math.round(maxHp()*.015));
  try{const c=B?pcen():{x:P.x,y:P.y-20};floatText(c.x,c.y-40,'POISONED!','#8cff6a',12);}catch(e){}sfx('hurt');return true;}
function poisonCure(){if(PSN.t>0){PSN.t=0;try{const c=B?pcen():{x:P.x,y:P.y-20};floatText(c.x,c.y-40,'CURED','#bfffd0',11);}catch(e){}}}
function updatePoison(dt){
  if(PSN.t<=0||state!=='play')return;
  PSN.t-=dt;PSN.tick-=dt;
  if(PSN.tick<=0){PSN.tick+=1;if(P.hp>1){const d=Math.min(PSN.dps,P.hp-1);P.hp-=d;try{const c=B?pcen():{x:P.x,y:P.y-20};floatText(c.x+R(-6,6),c.y-30,String(d),'#8cff6a',11);}catch(e){}}}
  if(PSN.t<=0)PSN.t=0;
}
function drawPoison(){
  if(PSN.t<=0)return;const a=.18+.06*Math.sin(gtime*4);
  const g=ctx.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*.35,VW/2,VH/2,Math.max(VW,VH)*.75);g.addColorStop(0,'rgba(60,200,60,0)');g.addColorStop(1,`rgba(60,200,60,${a})`);ctx.fillStyle=g;ctx.fillRect(0,0,VW,VH);
  // HUD icon: a green droplet with a skull dot + seconds left (under the HP panel)
  const x=SL+380,y=ST+22;
  ctx.fillStyle='#14182c';ctx.fillRect(x-2,y-2,70,24);ctx.fillStyle='#2a6a2a';ctx.fillRect(x,y,66,20);
  ctx.fillStyle='#8cff6a';ctx.beginPath();ctx.moveTo(x+11,y+2);ctx.quadraticCurveTo(x+18,y+11,x+11,y+18);ctx.quadraticCurveTo(x+4,y+11,x+11,y+2);ctx.fill();
  ctx.fillStyle='#14182c';ctx.fillRect(x+9,y+10,2,2);ctx.fillRect(x+12,y+10,2,2);
  txt('POISON '+Math.ceil(PSN.t),x+22,y+14,{size:8,col:'#eaffd8',lw:2});
}
