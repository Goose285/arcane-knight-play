/* =====================================================================
   TELEGRAPH TYPES (t140u): every enemy / boss warning now says WHAT is coming, by colour + shape + an icon above the attacker
   (colour-blind friendly: each type also has its own pattern and icon):
     PROJECTILE  cyan    dashed aim line + arrow head toward you, a glowing charge on the enemy      icon: arrow
     DASH        orange  a long lane with >>> chevrons along the dash path, dust puffs at the enemy  icon: double chevron
     MELEE       red     a wedge / arc in front of the enemy with slash marks                        icon: claw (3 slashes)
     AREA / SLAM purple  a filled circle at the impact spot with rings + a cross-hair                icon: burst
   ===================================================================== */
const TELE={proj:{n:'Projectile',col:'#4ad8ff',rgb:'74,216,255',desc:'Cyan aim line + arrow: something is fired along it. Step sideways.'},
  dash:{n:'Dash / charge',col:'#ff9a2a',rgb:'255,154,42',desc:'Orange lane with >>> chevrons: the enemy charges down it. Leave the lane.'},
  melee:{n:'Melee swipe',col:'#ff4a4a',rgb:'255,74,74',desc:'Red wedge in front: a close-range swipe or bite. Back off or go round.'},
  aoe:{n:'Area / slam',col:'#c070ff',rgb:'192,112,255',desc:'Purple circle with a cross-hair: a blast lands there. Get out of the circle.'}};
const TELE_STATS={proj:0,dash:0,melee:0,aoe:0};
function teleKindOf(a,z){
  const src=a&&a.strike?String(a.strike):'';
  if(/\.dash\s*=|dash:/.test(src)&&z.k==='line')return 'dash';
  if(/fireProj|Proj\(/.test(src)&&z.k==='line')return 'proj';
  if(z.k==='cone')return 'melee';
  if(z.k==='line')return /fireProj|Proj\(|beam|bolt/i.test(src)||!src?'proj':'dash';
  return 'aoe';
}
{const _sa=startAttack;startAttack=function(e,a){if(a&&a.zones)for(const z of a.zones)z.tk=teleKindOf(a,z);return _sa(e,a);};
 const _wz=warnZones;warnZones=function(zs,dur){for(const z of zs){if(!z.tk)z.tk=teleKindOf(null,z);TELE_STATS[z.tk]++;}return _wz(zs,dur);};}
function teleIcon(k,x,y,s,alpha){   // small pixel icon in a dark rounded badge
  ctx.save();ctx.globalAlpha=alpha==null?1:alpha;const T0=TELE[k];
  ctx.fillStyle='#14182c';ctx.beginPath();ctx.arc(x,y,9*s,0,6.283);ctx.fill();ctx.fillStyle=T0.col;ctx.beginPath();ctx.arc(x,y,7.5*s,0,6.283);ctx.fill();
  ctx.fillStyle='#14182c';ctx.strokeStyle='#14182c';ctx.lineWidth=2*s;const r=(a,b,w,h)=>ctx.fillRect(x+a*s,y+b*s,w*s,h*s);
  if(k==='proj'){r(-5,-1,7,2);ctx.beginPath();ctx.moveTo(x+5*s,y);ctx.lineTo(x+1*s,y-4*s);ctx.lineTo(x+1*s,y+4*s);ctx.fill();r(-6,-3,2,2);r(-6,1,2,2);}
  else if(k==='dash'){for(const o of [-4,1]){ctx.beginPath();ctx.moveTo(x+o*s,y-4*s);ctx.lineTo(x+(o+4)*s,y);ctx.lineTo(x+o*s,y+4*s);ctx.stroke();}}
  else if(k==='melee'){for(const o of [-3,0,3]){ctx.beginPath();ctx.moveTo(x+(o-2)*s,y+4*s);ctx.lineTo(x+(o+2)*s,y-4*s);ctx.stroke();}}
  else{ctx.beginPath();ctx.arc(x,y,3*s,0,6.283);ctx.fill();for(let i=0;i<8;i++){const q=i/8*6.283;ctx.fillRect(x+Math.cos(q)*5*s-1,y+Math.sin(q)*5*s-1,2*s,2*s);}}
  ctx.restore();
}
function drawTeleZone(w){
  const k=w.tk||(w.k==='line'?'proj':w.k==='cone'?'melee':'aoe'),C=TELE[k],p=w.t/w.dur,last=p>.72,fl=Math.floor(gtime*12)%2===0,rgb=C.rgb;
  ctx.save();
  if(k==='proj'){   // dashed aim line + arrow head at the end
    const dx=Math.cos(w.a),dy=Math.sin(w.a),L=w.len;shapePath(w);ctx.fillStyle=`rgba(${rgb},${last?.32:.16})`;ctx.fill();
    ctx.strokeStyle=last&&fl?'#ffffff':C.col;ctx.lineWidth=3;ctx.setLineDash([10,7]);ctx.lineDashOffset=-gtime*60;ctx.beginPath();ctx.moveTo(w.x,w.y);ctx.lineTo(w.x+dx*L,w.y+dy*L);ctx.stroke();ctx.setLineDash([]);
    const hx=w.x+dx*L,hy=w.y+dy*L;ctx.fillStyle=C.col;ctx.beginPath();ctx.moveTo(hx,hy);ctx.lineTo(hx-dx*14-dy*8,hy-dy*14+dx*8);ctx.lineTo(hx-dx*14+dy*8,hy-dy*14-dx*8);ctx.closePath();ctx.fill();
    const fx=w.x+dx*L*p,fy=w.y+dy*L*p;ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(fx,fy,3,0,6.283);ctx.fill();}
  else if(k==='dash'){   // lane + chevrons marching along it
    shapePath(w);ctx.fillStyle=`rgba(${rgb},${last?(fl?.5:.38):.24})`;ctx.fill();shapePath(w);ctx.strokeStyle=last?'#fff':C.col;ctx.lineWidth=2;ctx.stroke();
    const dx=Math.cos(w.a),dy=Math.sin(w.a),nx=-dy,ny=dx,hw=Math.max(6,w.w*.32);ctx.strokeStyle='rgba(255,240,210,.9)';ctx.lineWidth=3;
    for(let s=((gtime*90)%34)+14;s<w.len-8;s+=34){const cx=w.x+dx*s,cy=w.y+dy*s;ctx.beginPath();ctx.moveTo(cx-dx*8+nx*hw,cy-dy*8+ny*hw);ctx.lineTo(cx,cy);ctx.lineTo(cx-dx*8-nx*hw,cy-dy*8-ny*hw);ctx.stroke();}
    ctx.fillStyle='rgba(200,170,120,.55)';for(let i=0;i<4;i++){const q=gtime*6+i*1.7,rr=6+(i*5+gtime*20)%12;ctx.beginPath();ctx.arc(w.x-dx*10+Math.cos(q)*rr,w.y-dy*10+Math.sin(q)*rr*.5+6,3+(i%2),0,6.283);ctx.fill();}}
  else if(k==='melee'){   // wedge + slash marks
    shapePath(w);ctx.fillStyle=`rgba(${rgb},${last?(fl?.55:.42):.26})`;ctx.fill();shapePath(w,p);ctx.fillStyle=`rgba(${rgb},.3)`;ctx.fill();shapePath(w);ctx.strokeStyle=last?'#fff':C.col;ctx.lineWidth=2;ctx.stroke();
    if(w.k==='cone'){ctx.strokeStyle='rgba(255,235,235,.85)';ctx.lineWidth=2;for(let i=-1;i<=1;i++){const q=w.a+i*w.half*.5,r=Math.min(w.len*.75,coneRay(w,q)*.8);ctx.beginPath();ctx.arc(w.x,w.y,r,q-.18,q+.18);ctx.stroke();}}}
  else{   // filled circle + rings + crosshair
    shapePath(w);ctx.fillStyle=`rgba(${rgb},${last?(fl?.55:.42):.25})`;ctx.fill();shapePath(w,p);ctx.fillStyle=`rgba(${rgb},.35)`;ctx.fill();
    shapePath(w);ctx.strokeStyle=last?'#fff':C.col;ctx.lineWidth=2;ctx.stroke();
    if(w.k==='circle'){ctx.strokeStyle='rgba(255,255,255,.7)';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(w.x,w.y,w.r*.55,0,6.283);ctx.stroke();ctx.beginPath();ctx.moveTo(w.x-8,w.y);ctx.lineTo(w.x+8,w.y);ctx.moveTo(w.x,w.y-8);ctx.lineTo(w.x,w.y+8);ctx.stroke();}}
  ctx.restore();
}
function drawTeleOwners(){   // the icon over each attacker winding up (+ a charge glow for projectiles)
  if(!B)return;const seen=new Set();
  for(const w of B.zones){const o=w.o;if(!o||o.dying||seen.has(o))continue;seen.add(o);const k=w.tk||'aoe';let c;try{c=ecen(o);}catch(e){continue;}
    const top=c.y-(o.def&&o.def.big?96:46)-Math.sin(gtime*6)*2;
    if(k==='proj'){const g=ctx.createRadialGradient(c.x,c.y,1,c.x,c.y,16+4*Math.sin(gtime*14));g.addColorStop(0,'rgba(220,250,255,.9)');g.addColorStop(1,'rgba(74,216,255,0)');ctx.fillStyle=g;ctx.beginPath();ctx.arc(c.x,c.y,20,0,6.283);ctx.fill();}
    teleIcon(k,c.x,top,1.15,.95);}
}
