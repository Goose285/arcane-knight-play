/* =====================================================================
   ROCK SPECIES (t139u): creatures made of stone, crystal or rock shrug off POISON and BURN (and the Cinder Golem takes no FIRE damage).
   An IMMUNE popup (grey stone colour) shows when it happens, at most twice a second per foe.
   ===================================================================== */
const ROCK_TYPES=new Set(['scamp','shscorp','sentinel','maw','tortoise','fbat','bboar','geode','crawler','mgolem','cgolem','warden','colossus']);
const FIRE_IMMUNE=new Set(['cgolem']);
const isRock=e=>!!e&&ROCK_TYPES.has(e.type);
function immunePop(e,what){if(!e||e.dying)return;const now=typeof gtime==='number'?gtime:0;if((e.immT||0)>now)return;e.immT=now+.5;IMMUNE_LOG.n++;
  try{const c=ecen(e);floatText(c.x,c.y-(e.def.big?64:36),'IMMUNE'+(what?' ('+what+')':''),'#c8c8d8',12);}catch(err){}}
const IMMUNE_LOG={n:0};
{ // wrap damageEnemy: poison-cloud ticks and fire on fire-immune foes do nothing
  const _de=damageEnemy;
  damageEnemy=function(e,d,k){
    if(e&&k==='dot'&&isRock(e)){immunePop(e,'poison');return false;}
    if(e&&k==='fire'&&FIRE_IMMUNE.has(e.type)){immunePop(e,'fire');return false;}
    return _de(e,d,k);};
}
function rockBurnCheck(e){if(e&&e.burn>0&&isRock(e)){e.burn=0;e.burnT=0;immunePop(e,'burn');return true;}return false;}
