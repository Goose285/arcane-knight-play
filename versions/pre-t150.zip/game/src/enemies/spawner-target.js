/* =====================================================================
   SPAWNERS AS TARGETS (t142u): every attack hurts spawners and auto-aim can pick them.
   A live spawner in the fight's zone gets a small PROXY object that looks like a foe to the targeting code (nearestEnemy / aimEnemy,
   foesIn area checks). Damage to a proxy goes to hurtSpawner; stuns / knockback / statuses on it are ignored. Live monsters in
   range always win the auto-aim; a spawner is picked when no monster is nearer than it (or none is left).
   Plus explicit spawner hits for the cards that sweep B.ens directly (Dragonfire, Thunder Fang, Phantom Slash, Judgment, magic splash).
   ===================================================================== */
const SPW_PROXY=new Map();
function spwProxy(s){let p=SPW_PROXY.get(s);if(!p){p={spwProxy:s,type:'spawner',def:{name:'Spawner',big:false,freezeImmune:true,boss:false},sz:1,lv:1,engaged:true,alive:true,tmp:true,face:1,bob:0};SPW_PROXY.set(s,p);}
  Object.assign(p,{x:s.x,y:s.y,hx:s.x,hy:s.y,hp:s.hp,maxhp:s.maxhp,dying:!spwLive(s)});return p;}
const isSpwProxy=e=>!!(e&&e.spwProxy);
function spwTargets(maxD){const pc=pcen(),o=[];for(const s of SPW){if(!spwLive(s)||!spwSameZone(s))continue;const c=spwCenter(s);if(Math.hypot(c.x-pc.x,c.y-pc.y)<(maxD||SPW_RANGE))o.push(spwProxy(s));}return o;}
{
  const _de=damageEnemy;damageEnemy=function(e,d,k){if(isSpwProxy(e))return hurtSpawner(e.spwProxy,d,k);return _de.apply(this,arguments);};
  const _st=stunEnemy;stunEnemy=function(e){if(isSpwProxy(e))return false;return _st.apply(this,arguments);};
  if(typeof knock==='function'){const _kn=knock;knock=function(e){if(isSpwProxy(e))return;return _kn.apply(this,arguments);};}
  const _fi=foesIn;foesIn=function(x,y,r){const o=_fi.apply(this,arguments);if(B)for(const p of spwTargets(1e9)){const c=spwCenter(p.spwProxy);if(Math.hypot(c.x-x,c.y-y)<r+SPW_REACH)o.push(p);}return o;};
  const _ne=nearestEnemy;nearestEnemy=function(){const e=_ne.apply(this,arguments);const sp=spwTargets();if(!sp.length)return e;
    const pc=pcen();let best=null,bd=1e9;for(const p of sp){const c=spwCenter(p.spwProxy),d=Math.hypot(c.x-pc.x,c.y-pc.y);if(d<bd){bd=d;best=p;}}
    if(!e||e.dying)return best;const c=ecen(e);return Math.hypot(c.x-pc.x,c.y-pc.y)<=bd+40?e:best;};   // monsters win ties (40px bias)
  const _cm=castMagic;castMagic=function(id,ch,m){const tg=aimEnemy();const r=_cm.apply(this,arguments);if(isSpwProxy(tg)){const cfg=MAGIC[id];const c=spwCenter(tg.spwProxy);hurtSpawner(tg.spwProxy,ch.pow*m,id);}return r;};
  const wrapCast=(id,after)=>{const f=CAST[id];if(!f)return;CAST[id]=function(ch,m,a,pc){const r=f.apply(this,arguments);try{after(ch,m,a,pc||pcen());}catch(e){}return r;};};
  wrapCast('dragonfire',(ch,m,a,pc)=>{const z=Z.cone(pc.x,pc.y,a,280,.6);schedule(.1,()=>spwHitZone(z,ch.pow*m,'fire'));});
  wrapCast('thunder',(ch,m,a)=>{const from={x:P.x,y:P.y};schedule(.19,()=>{const to={x:P.x,y:P.y};for(const s of SPW){if(!spwLive(s)||!spwSameZone(s))continue;const c=spwCenter(s);
      const dx=to.x-from.x,dy=to.y-from.y,L2=dx*dx+dy*dy||1;let t=clamp(((c.x-from.x)*dx+(c.y-from.y+12)*dy)/L2,0,1);if(Math.hypot(from.x+dx*t-c.x,from.y-12+dy*t-c.y)<SPW_REACH+40||Math.hypot(to.x-c.x,to.y-12-c.y)<64)hurtSpawner(s,ch.pow*m,'zap');}});});
  // drain / spirit wolf: when no monster is in reach they keep working on the nearest spawner
  const liveNear=r=>{const pc=pcen();return B.ens.some(e=>!e.dying&&Math.hypot(ecen(e).x-pc.x,ecen(e).y-pc.y)<r);};
  const nearSpw=r=>{const pc=pcen();let b=null,bd=r;for(const p of spwTargets(1e9)){const c=spwCenter(p.spwProxy),d=Math.hypot(c.x-pc.x,c.y-pc.y);if(d<bd){bd=d;b=p.spwProxy;}}return b;};
  wrapCast('drain',(ch,m)=>{for(let i=1;i<=8;i++)schedule(i*.25,()=>{if(!B||!B.channel||liveNear(250))return;const s=nearSpw(250);if(s){hurtSpawner(s,ch.pow*m,'dot');}});});
  wrapCast('wolf',(ch,m)=>{for(let i=1;i<=12;i++)schedule(i*.8,()=>{if(!B||!B.wolf||liveNear(200))return;const s=nearSpw(220);if(s){hurtSpawner(s,B.wolf.dmg||ch.pow*m,'pet');const c=spwCenter(s);burst(c.x,c.y,'#bcd0f5',6,80,.3);}});});
}
{const cf=COMBO_FX;
 const _ps=cf['PHANTOM SLASH'];cf['PHANTOM SLASH']=function(m){const r=_ps.apply(this,arguments);schedule(.09,()=>spwHitRadius(P.x,P.y-12,84,160*m,'sword'));return r;};
 const _j=cf['JUDGMENT'];cf['JUDGMENT']=function(m){const r=_j.apply(this,arguments);let n=0;for(const p of spwTargets()){newMeteor(p.x,p.y,150*m,62,1.2+n*.12);n++;}return r;};}
