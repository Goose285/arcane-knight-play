/* =====================================================================
   NEW FOES: the Glowcap Grove mushroom folk and the Shardstone Caverns rock creatures (+ Cinder Golems on the Ember Rift).
   Every one has its own trick (see FOE_NOTES); they use the shared combat kit (telegraphed zones, projectiles, pools, summons) plus a
   per-frame hook (foeTick) and a damage hook (foeDmgMult) for armour, shells, splitting and the warden's core.
   Player statuses they can inflict: PINNED (can't move; a dash breaks it), ASLEEP (wakes on a hit or after a moment), SLOWED.
   ===================================================================== */
const FOE_NOTES={
  shscorp:'pins you with its claws, then drops a crystal tail strike on the spot',sentinel:'splits into floating stones to dodge your shots',
  maw:'rolls at you, then bites at the end of the roll',tortoise:'shells up (takes little damage), then fires shards in all directions',
  fbat:'hangs still, then swoops straight through you',bboar:'charges; if it hits a wall it is stunned',geode:'looks like a geode - snaps when you get close',
  cgolem:'leaves burning ground behind it',scamp:'disguised as a rock, then rolls at you',crawler:'scuttles sideways firing crystal shards to both sides',
  mgolem:'ground-slam shockwaves ripple outwards',warden:'BOSS: armoured - its chest core opens after a heavy attack (double damage)',
  spore:'raises an acorn shield, then charges',lantern:'its lantern lures; sleep spores put you to sleep',chestcap:'looks like treasure... until it bites',
  colony:'BOSS: walking stump that drops mushroom passengers into the fight',ironcap:'armoured and slow (takes 40% less damage)',spitter:'spits poison spores that leave toxic puddles',
  frostcap:'chilling aura slows you nearby',shadowcap:'vanishes, then strikes from behind',babyshroom:'tiny, comes in swarms',brute:'huge armoured slammer',
  mking:'BOSS: fairy rings, spore storms and a court of mushrooms',redcap:'hop slam',shroom:'drowsy puff',greencap:'poison puff',ambercap:'bursts into embers'};
Object.assign(MATS,{spore:{n:'Glow Spore',col:'#c890f0'},crystal:{n:'Rift Crystal',col:'#7df9ff'},ember:{n:'Cinder Ember',col:'#ff9a2a'}});
(function defineFoes(){
  const D=(name,hp,xp,g0,g1,speed,chase,spr,o={})=>Object.assign({name,hp,xp,gold:[g0,g1],speed,chase,aggro:5*TS,spr,vr:180,vh:.8,ar:74,hs:.17,ds:.10,as:.025,ss:.02,rs:.22,freezeImmune:false},o);
  Object.assign(ENEMY,{
    // Glowcap Grove
    redcap:D('Red Cap',380,90,16,28,30,60,'redcap'),shroom:D('Dozy Cap',360,92,16,28,26,54,'shroom'),greencap:D('Mossy Cap',360,92,16,28,28,56,'greencap'),ambercap:D('Ember Cap',340,95,16,30,32,62,'ambercap'),
    babyshroom:D('Baby Shroom',120,24,4,9,40,80,'babyshroom',{ar:64}),
    spore:D('Sir Spore',520,140,26,40,30,66,'spore'),lantern:D('Lanterncap',420,130,24,38,24,48,'lantern',{vr:230}),chestcap:D('Chestcap Mimic',640,190,60,110,30,70,'chestcap',{disg:'chestcapD',ar:40,vr:40,vh:.3}),
    ironcap:D('Ironcap',820,170,30,46,20,40,'ironcap'),spitter:D('Spore Spitter',430,140,24,36,24,48,'spitter',{vr:240}),frostcap:D('Frostcap',470,150,26,40,26,52,'frostcap'),shadowcap:D('Shadowcap',450,160,28,44,34,74,'shadowcap'),
    brute:D('Ironcap Brute',1500,330,60,90,18,38,'brute',{sz:1.5}),
    colony:D('The Wandering Colony',3600,1500,700,860,18,38,'colony',{boss:true,big:true,vr:330,vh:.9,ar:170,hs:.07,ds:.05,as:.01,ss:.01,rs:.03,freezeImmune:true,p2at:.66,p3at:.33}),
    mking:D('The Mushroom King',4400,2100,900,1100,18,38,'mking',{boss:true,big:true,vr:330,vh:.9,ar:170,hs:.07,ds:.05,as:.01,ss:.01,rs:.03,freezeImmune:true,p2at:.66,p3at:.33}),
    // Shardstone Caverns
    scamp:D('Pebble Scamp',300,90,14,26,40,84,'scamp',{disg:'scampD',ar:46,vr:60}),shscorp:D('Shale Scorpion',620,170,30,46,32,66,'shscorp'),sentinel:D('Rune Sentinel',540,170,30,46,26,52,'sentinel',{vr:240}),
    maw:D('Boulder Maw',760,190,34,52,26,58,'maw'),tortoise:D('Crystal Tortoise',980,220,40,60,16,32,'tortoise'),fbat:D('Flint Bat',360,140,22,34,44,90,'fbat'),
    bboar:D('Boulder Boar',720,190,34,50,34,76,'bboar'),geode:D('Geode Mimic',700,220,70,120,0,40,'geode',{disg:'geodeD',ar:44,vr:44,vh:.3}),
    crawler:D('Crystal Crawler',520,170,30,44,34,62,'crawler'),mgolem:D('Mossback Golem',1300,300,60,90,20,40,'mgolem',{sz:1.35}),cgolem:D('Cinder Golem',1400,340,70,100,20,40,'cgolem',{sz:1.35}),
    warden:D('The Ruin Warden',5200,2600,1100,1400,16,34,'warden',{boss:true,big:true,vr:330,vh:.9,ar:170,hs:.07,ds:.05,as:.01,ss:.01,rs:.03,freezeImmune:true,p2at:.66,p3at:.33}),
  });
  const er={redcap:13,shroom:13,greencap:13,ambercap:13,babyshroom:8,spore:13,lantern:13,chestcap:14,ironcap:14,spitter:13,frostcap:13,shadowcap:13,brute:20,colony:30,mking:30,
    scamp:11,shscorp:14,sentinel:13,maw:15,tortoise:16,fbat:12,bboar:15,geode:14,crawler:14,mgolem:18,cgolem:18,warden:30};
  Object.assign(ER,er);
  for(const k in er){SHORT[k]=ENEMY[k].name.replace(/^The /,'').toUpperCase().slice(0,14);TIERS[k]=[SHORT[k],'ELDER '+SHORT[k].split(' ').pop(),'ANCIENT '+SHORT[k].split(' ').pop()];TITLES[k]=[ENEMY[k].name,'Elder '+ENEMY[k].name.replace(/^The /,''),'Ancient '+ENEMY[k].name.replace(/^The /,'')];}
  Object.assign(BAND,{redcap:[26,70],shroom:[60,120],greencap:[40,100],ambercap:[30,80],babyshroom:[20,50],spore:[28,70],lantern:[110,190],chestcap:[24,60],ironcap:[28,60],spitter:[120,200],frostcap:[40,90],shadowcap:[30,80],brute:[30,70],
    colony:[130,215],mking:[130,215],scamp:[24,70],shscorp:[28,70],sentinel:[120,200],maw:[30,90],tortoise:[60,120],fbat:[30,100],bboar:[30,110],geode:[24,60],crawler:[70,140],mgolem:[30,70],cgolem:[30,70],warden:[130,215]});
  Object.assign(DODGE_BASE,{redcap:.14,shroom:.1,greencap:.1,ambercap:.14,babyshroom:.2,spore:.18,lantern:.16,chestcap:.08,ironcap:.04,spitter:.18,frostcap:.14,shadowcap:.3,brute:.04,
    scamp:.3,shscorp:.2,sentinel:.1,maw:.08,tortoise:.04,fbat:.34,bboar:.12,geode:.06,crawler:.24,mgolem:.06,cgolem:.06});
  ['redcap','greencap','ambercap','babyshroom','spore','ironcap','frostcap','shadowcap','brute','scamp','shscorp','maw','bboar','mgolem','cgolem','fbat'].forEach(k=>FLANKERS.add(k));
  ['shadowcap','fbat','scamp','crawler','spore'].forEach(k=>RETREATERS.add(k));
  Object.assign(MAT_DROP,{redcap:'spore',shroom:'spore',greencap:'spore',ambercap:'spore',babyshroom:'spore',spore:'spore',lantern:'spore',chestcap:'spore',ironcap:'spore',spitter:'spore',frostcap:'spore',shadowcap:'spore',brute:'spore',colony:'spore',mking:'spore',
    scamp:'crystal',shscorp:'crystal',sentinel:'crystal',maw:'crystal',tortoise:'crystal',fbat:'crystal',bboar:'crystal',geode:'crystal',crawler:'crystal',mgolem:'crystal',warden:'crystal',cgolem:'ember'});
})();
/* ---- player statuses ---- */
function playerStatus(k,dur,label,col){P[k]=Math.max(P[k]||0,dur);const p=pcen();if(B)floatText(p.x,p.y-44,label,col,13);}
function statusTick(dt){for(const k of ['slowT','rootT','sleepT'])if(P[k]>0)P[k]=Math.max(0,P[k]-dt);if(!B){P.slowT=0;P.rootT=0;P.sleepT=0;}}
const playerSpeedMul=()=>(P.rootT>0||P.sleepT>0)?0:(P.slowT>0?.55:1);
const playerHitIn=z=>!!B&&B.inv<=0&&inZone(z,pcen());
/* ---- attacks ---- */
const ringWave=(c,n,r0,step,dmg,fx,co)=>{for(let i=0;i<n;i++)schedule(i*.32,()=>{if(B.phase!=='fight')return;const z=Z.ring(c.x,c.y,r0+i*step,r0+i*step+30,co);warnZones([z],.45);schedule(.45,()=>{if(B.phase==='fight')hitZones([z],dmg,fx);});});};
Object.assign(ATK,{
  redcap(e){const c=ecen(e),p=aimPos(),q=clampRay(c,7,p,7),z=Z.circle(q.x,q.y,40);return{windup:.85,zones:[z],recover:.5,strike(e){e.hop=.35;hitZones([z],18,'boom');}};},
  shroom(e){const c=ecen(e),p=aimPos(),q=clampRay(c,7,p,7),z=Z.circle(q.x,q.y,46);return{windup:1.0,zones:[z],recover:.6,strike(e){const s=playerHitIn(z);hitZones([z],12,'void');if(s)playerStatus('sleepT',1.0,'DROWSY','#d8c8ff');}};},
  greencap(e){const c=ecen(e),z=Z.circle(c.x,c.y,70,eOff(e));return{windup:.9,zones:[z],recover:.6,strike(e){hitZones([z],14,'mire');addPool(c.x,c.y+8,40,3.5,5,'mire');}};},
  ambercap(e){const c=ecen(e),p=aimPos(),zs=scatterZones(c,p,3,34,40,90);return{windup:1.0,zones:zs,recover:.6,strike(e){hitZones(zs,16,'fire');addPool(zs[0].x,zs[0].y,30,2.5,5,'fire');}};},
  babyshroom(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);return dashAtk(e,c,a,d,.55,8,'slash',560,22);},
  spore(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);
    if(!(e.guard>0)&&Math.random()<.45)return{windup:.25,zones:[],recover:.4,strike(e){e.guard=2.2;sfx('shield');floatText(c.x,c.y-34,'ACORN SHIELD','#e8c890',11);}};
    return dashAtk(e,c,a,d,.75,22,'slash',680,32);},
  lantern(e){const c=ecen(e),p=aimPos(),a=angTo(c,p);
    if(Math.random()<.5){const q=clampRay(c,7,p,7),z=Z.circle(q.x,q.y,58);return{windup:1.15,zones:[z],recover:.7,start(e){e.charge=1;},strike(e){e.charge=0;const s=playerHitIn(z);hitZones([z],10,'void');if(s)playerStatus('sleepT',1.6,'ASLEEP!','#d8c8ff');}};}
    // lure: the lantern pulls you a little toward it
    const z=Z.cone(c.x,c.y,a,200,.5);return{windup:.9,zones:[z],recover:.6,strike(e){if(playerHitIn(z)){knockPlayer(P.x*2-c.x,P.y*2-c.y,50);floatText(P.x,P.y-44,'LURED','#ffd23f',12);}hitZones([z],8,'void');}};},
  chestcap(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);
    if(d<90)return coneAtk(e,c,a,90,.9,.45,30,'slash');return dashAtk(e,c,a,d,.7,24,'slash',640,30);},
  ironcap(e){const c=ecen(e),z=Z.circle(c.x,c.y,80,eOff(e));return{windup:1.2,zones:[z],recover:.9,strike(e){e.hop=.3;hitZones([z],28,'boom');}};},
  spitter(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),as=[a-.25,a,a+.25],zs=as.map(q=>Z.line(c.x,c.y,q,420,13));
    return{windup:.95,zones:zs,recover:.6,strike(e){as.forEach(q=>fireProj(c.x,c.y,q,280,12,'spore',6));const q=clampRay(c,7,p,7);addPool(q.x,q.y,36,4,6,'mire');}};},
  frostcap(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),z=Z.line(c.x,c.y,a,360,16);return{windup:.85,zones:[z],recover:.6,strike(e){fireProj(c.x,c.y,a,320,14,'ice',7);}};},
  shadowcap(e){const c=ecen(e),p=aimPos();
    return{windup:.6,zones:[],recover:.4,start(e){e.vanish=1.1;burst(c.x,c.y,'#8e3a7a',14,120,.5);},strike(e){
      const back=P.aim+Math.PI,dest=bossSpotNear(e,{x:P.x+Math.cos(back)*46,y:P.y+Math.sin(back)*46},30);if(dest)bossTeleport(e,dest);
      const c2=ecen(e),z=Z.cone(c2.x,c2.y,angTo(c2,pcen()),80,.9);warnZones([z],.35);schedule(.35,()=>{if(B.phase==='fight'){e.vanish=0;hitZones([z],26,'void');}});}};},
  brute(e){const c=ecen(e),p=aimPos(),a=angTo(c,p);if(Math.random()<.5){const z=Z.circle(c.x,c.y,100,eOff(e));return{windup:1.3,zones:[z],recover:1.0,strike(e){e.hop=.4;hitZones([z],34,'boom');B.shake=.4;}};}
    return coneAtk(e,c,a,120,1.0,1.1,32,'slash');},
  scamp(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);return dashAtk(e,c,a,d,.5,14,'boom',760,24);},
  shscorp(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y),len=clamp(d+40,90,220),z=Z.line(c.x,c.y,a,len,30);
    return{windup:.7,zones:[z],recover:.9,strike(e){e.dash={vx:Math.cos(a)*600,vy:Math.sin(a)*600,t:len/600};const pin=playerHitIn(z);hitZones([z],16,'slash');
      if(pin){playerStatus('rootT',1.1,'PINNED!','#e0c0ff');const at={x:P.x,y:P.y-12};schedule(.15,()=>{if(B.phase!=='fight')return;const t=Z.circle(at.x,at.y,34);warnZones([t],.8);schedule(.8,()=>{if(B.phase==='fight')hitZones([t],28,'void');});});}}};},
  sentinel(e){const c=ecen(e),p=aimPos(),a=angTo(c,p);
    if(Math.random()<.55){const as=[a-.2,a+.2],zs=as.map(q=>Z.line(c.x,c.y,q,440,12));return{windup:.9,zones:zs,recover:.6,strike(e){as.forEach(q=>fireProj(c.x,c.y,q,340,14,'soul',6));}};}
    const zs=scatterZones(c,p,4,34,40,110);return{windup:1.1,zones:zs,recover:.6,strike(e){hitZones(zs,18,'boom');}};},
  maw(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y),len=clamp(d+60,140,300),z=Z.line(c.x,c.y,a,len,36);
    return{windup:.85,zones:[z],recover:.9,strike(e){e.dash={vx:Math.cos(a)*620,vy:Math.sin(a)*620,t:len/620};hitZones([z],20,'boom');
      schedule(len/620+.05,()=>{if(B.phase!=='fight')return;const c2=ecen(e),b=Z.cone(c2.x,c2.y,angTo(c2,pcen()),86,.8);warnZones([b],.35);schedule(.35,()=>{if(B.phase==='fight'){e.lunge=.25;hitZones([b],30,'slash');}});});}};},
  tortoise(e){const c=ecen(e);
    return{windup:.5,zones:[],recover:1.6,start(e){e.shellT=2.6;floatText(c.x,c.y-30,'SHELL UP','#e0c0ff',12);sfx('shield');},strike(e){
      schedule(1.2,()=>{if(B.phase!=='fight')return;const o=Math.random()*6.283;for(let i=0;i<8;i++){const q=o+i*Math.PI/4;fireProj(c.x,c.y,q,260,15,'ice',7);}burst(c.x,c.y,'#e0c0ff',18,140,.6);});}};},
  fbat(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y),len=clamp(d+120,180,340),z=Z.line(c.x,c.y,a,len,30);
    return{windup:1.05,zones:[z],recover:.5,start(e){e.hangT=1;},strike(e){e.hangT=0;e.dash={vx:Math.cos(a)*820,vy:Math.sin(a)*820,t:len/820};hitZones([z],20,'slash');}};},
  bboar(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),len=330,z=Z.line(c.x,c.y,a,clipLen(c.x,c.y,a,len)+20,38);
    return{windup:.9,zones:[z],recover:.6,strike(e){e.charging=true;e.dash={vx:Math.cos(a)*700,vy:Math.sin(a)*700,t:len/700};hitZones([z],26,'boom');}};},
  geode(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);
    if(d<96)return coneAtk(e,c,a,96,1.0,.4,34,'slash');
    const as=[a-.3,a,a+.3],zs=as.map(q=>Z.line(c.x,c.y,q,400,12));return{windup:1.0,zones:zs,recover:.6,strike(e){as.forEach(q=>fireProj(c.x,c.y,q,300,14,'ice',6));}};},
  crawler(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),as=[a+Math.PI/2,a-Math.PI/2,a],zs=as.map(q=>Z.line(c.x,c.y,q,380,12));
    return{windup:.85,zones:zs,recover:.5,strike(e){e.slideT=.8;e.slide=Math.random()<.5?1:-1;as.forEach(q=>fireProj(c.x,c.y,q,320,13,'ice',6));}};},
  mgolem(e){const c=ecen(e);return{windup:1.0,zones:[Z.circle(c.x,c.y,70,eOff(e))],recover:1.2,strike(e){e.hop=.4;hitZones([Z.circle(c.x,c.y,70,eOff(e))],26,'boom');B.shake=.35;ringWave(c,3,80,55,18,'boom',eOff(e));}};},
  cgolem(e){const c=ecen(e),p=aimPos(),a=angTo(c,p);if(Math.random()<.5){const z=Z.circle(c.x,c.y,86,eOff(e));return{windup:1.1,zones:[z],recover:.9,strike(e){e.hop=.35;hitZones([z],28,'fire');addPool(c.x,c.y+10,60,4,7,'fire');}};}
    return coneAtk(e,c,a,110,.8,1.0,30,'fire');},
});
ATK.colony=mkBoss({proj:'spore',fx:'mire',w:[30,35,45],uniq:(e,c,p,a,ph)=>({windup:.9*ph,zones:[],recover:1.0,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;
  const kinds=['babyshroom','babyshroom','redcap','greencap'];summonMinions(e,kinds[Math.floor(Math.random()*kinds.length)],e.p2?3:2,Math.max(1,e.lv-4));floatText(c.x,c.y-70,'PASSENGERS DROP OFF!','#c8f0a0',12);}})});
ATK.mking=mkBoss({proj:'spore',fx:'void',w:[30,30,50],uniq:(e,c,p,a,ph)=>{
  if(Math.random()<.5){const zs=[];const n=e.p2?10:8,r=120;for(let i=0;i<n;i++){const q=i/n*6.283;const w=scatterSpot(c,c,Math.cos(q)*r,Math.sin(q)*r,19);zs.push(Z.circle(w.x,w.y,30));}
    return{windup:1.0*ph,zones:zs,recover:.9,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;hitZones(zs,24,'void');floatText(c.x,c.y-70,'FAIRY RING!','#e0c0ff',13);}};}
  return{windup:.8,zones:[],recover:1.0,strike(e){summonMinions(e,Math.random()<.5?'babyshroom':'shroom',3,Math.max(1,e.lv-5));const q=clampRay(c,19,p,7);addPool(q.x,q.y,70,5,7,'mire');}};}});
ATK.warden=mkBoss({proj:'soul',fx:'boom',w:[25,30,55],uniq:(e,c,p,a,ph)=>{const z=Z.circle(c.x,c.y,150,19);
  return{windup:1.4*ph,zones:[z],recover:1.3,start(e){e.charge=1;floatText(c.x,c.y-80,'HEAVY SLAM','#ffd23f',13);},strike(e){e.charge=0;e.hop=.5;hitZones([z],38,'boom');B.shake=.6;e.coreT=3.2;floatText(c.x,c.y-80,'CORE EXPOSED!','#7df9ff',15);setBanner('HIT THE CORE!',1.3,'#7df9ff');}};}});
/* ---- per-frame tricks (called from updateEnemyCombat) ---- */
function foeTick(e,dt){
  if(e.coreT>0)e.coreT-=dt;if(e.shellT>0)e.shellT-=dt;if(e.vanish>0)e.vanish-=dt;
  const t=e.type;
  if(t==='cgolem'){e.trail=(e.trail||0)-dt;if(e.trail<=0&&Math.hypot(e.x-(e.lx||0),e.y-(e.ly||0))>14){e.trail=.7;e.lx=e.x;e.ly=e.y;B.owner=e;addPool(e.x,e.y-2,24,3.2,5,'fire');}}
  if(t==='frostcap'&&Math.hypot(P.x-e.x,P.y-e.y)<92){if(!(P.slowT>0))floatText(P.x,P.y-44,'CHILLED','#bfe6ff',11);P.slowT=Math.max(P.slowT||0,.3);}
  if(t==='bboar'&&e.charging){if(!e.dash){e.charging=false;}else{const a=Math.atan2(e.dash.vy,e.dash.vx);if(wallT(e.x+Math.cos(a)*16,e.y+Math.sin(a)*16-4)||solidTile(Math.floor((e.x+Math.cos(a)*14)/TS),Math.floor((e.y+Math.sin(a)*14-4)/TS))){
    e.dash=null;e.charging=false;stunEnemy(e,1.8);const c=ecen(e);floatText(c.x,c.y-34,'CRASH! STUNNED','#ffe14d',13);burst(c.x,c.y,'#cfcfd8',14,120,.5);B.shake=.3;sfx('quake');}}}
  if(t==='sentinel'&&!(e.splitCd>0)){for(const s of B.shots){if(s.own!=='p'||s.life<=0)continue;const c=ecen(e);if(Math.hypot(s.x-c.x,s.y-c.y)<48){e.splitCd=2.2;e.split=.6;s.life=0;floatText(c.x,c.y-34,'SPLIT!','#7df9ff',12);burst(c.x,c.y,'#d8c098',10,120,.4);break;}}}
  if(e.splitCd>0)e.splitCd-=dt;if(e.split>0)e.split-=dt;
}
function foeDmgMult(e,kind){
  const t=e.type;let m=1;
  if(t==='ironcap'||t==='brute')m*=.6;
  if(e.shellT>0)m*=.2;
  if(e.vanish>0)m*=0;
  if(t==='warden')m*=e.coreT>0?2:.5;
  return m;
}
/* overworld levels of the new regions (null = not ours) */
function foeLevel(type,tx,ty){
  const b={colony:16,mking:19,warden:21}[type];if(b)return b;
  try{if(!EAST.on)return null;}catch(x){return null;}if(zoneOfTy(ty)!=='ow')return null;
  const r=eastRegion(tx,ty);if(!r)return null;
  const lv={grove:[9,13],caves:[13,17],rift:[17,19]}[r],t=clamp((tx-EAST.x0)/EAST.W,0,1);
  return clamp(Math.round(lv[0]+(lv[1]-lv[0])*t+R(-.6,.6)),lv[0],lv[1]);
}

['redcap','babyshroom','bboar','shscorp','crawler','scamp','shroom','greencap','spore','fbat','sentinel'].forEach(t=>FLANKERS.add(t));
