/* =====================================================================
   t143u LICH KING REWORK: about 37% less HP at Lv16 (5535 -> 3500) (base 2700 -> 2000, per-level HP growth .07 -> .05) and a fight that changes as it goes:
   PHASE 1 (100-66%)  bolts / grave rain / sweep + RAISE DEAD, PHASE STEP, and new BONE GRASP (hands burst up in a cross under you)
   PHASE 2 (66-33%)   + spiral, SOUL WARD, new WRAITH CALL (two wraiths) and FROST CHAINS (three sweeping lines in a fan, one after another)
   PHASE 3 (<33%)     + ray / nova, faster casts, new SOUL STORM (rotating blasts around him; get close or get out) and he stops raising knights
   ===================================================================== */
Object.assign(ENEMY.lich,{hp:2000,hs:.05});for(const e of enemies)if(e.type==='lich')applyLevel(e,e.lv);   // Lv16: 5535 HP -> 3500
{const base=BOSS_MOVES.lich;
 BOSS_MOVES.lich=(e,c,p,a)=>Object.assign(base(e,c,p,a),{
  grasp:()=>{const q=clampRay(c,19,p,7),zs=[[0,0],[44,0],[-44,0],[0,40],[0,-40]].map(([dx,dy])=>Z.circle(q.x+dx,q.y+dy,26,7));
    return{windup:.9,zones:zs,recover:.6,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.4;hitZones(zs,22,'void');for(const z of zs)burst(z.x,z.y,'#e8e0c8',6,90,.4);}};},
  wraiths:()=>{const sp=[0,1].map(i=>scatterSpot(c,c,Math.cos(a+(i?1:-1)*1.6)*90,Math.sin(a+(i?1:-1)*1.6)*90,eOff(e))),zs=sp.map(s=>Z.circle(s.x,s.y,28,7));
    return{windup:1.0,zones:zs,recover:.8,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;summonMinions(e,'wraith',2,Math.max(3,(e.lv||16)*.5),sp);}};},
  chains:()=>{const zs=[-.45,0,.45].map(o=>Z.line(c.x,c.y,a+o,380,22,19));
    return{windup:.7,zones:[zs[0]],recover:1.2,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.4;hitZones([zs[0]],18,'frost');
      zs.slice(1).forEach((z,i)=>schedule(.35*(i+1),()=>{if(B.phase!=='fight')return;warnZones([z],.45);schedule(.45,()=>{if(B.phase==='fight')hitZones([z],18,'frost');});}));}};},
  storm:()=>{const ring=k=>{const zs=[];for(let i=0;i<8;i++){const q=k+i*Math.PI/4,w=scatterSpot(c,c,Math.cos(q)*120,Math.sin(q)*120,19);zs.push(Z.circle(w.x,w.y,40));}return zs;};
    const r1=ring(0),r2=ring(Math.PI/8);
    return{windup:1.0,zones:r1,recover:1.2,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.6;B.shake=Math.max(B.shake,.4);hitZones(r1,24,'void');
      schedule(.3,()=>{if(B.phase!=='fight')return;warnZones(r2,.6);schedule(.6,()=>{if(B.phase==='fight')hitZones(r2,24,'void');});});}};},
 });
 BOSS_BOOK.lich=[['raise',16,e=>!e.p3],['step',9,e=>true],['grasp',7,e=>true],['wraiths',18,e=>e.p2&&!e.p3],['chains',9,e=>e.p2],['storm',10,e=>e.p3]];
 const _mp=bossMechPhase;bossMechPhase=function(e){const r=_mp.apply(this,arguments);if(e.type==='lich')setBanner(e.p3?'FINAL FORM - SOUL STORM!':'THE KING RISES - WRAITHS ANSWER!',1.6,e.p3?'#d49bff':'#9dffb0');return r;};
}
/* ---- t143u: story choices that used to only set a flag now also have a small, visible effect ---- */
const CHOICE_FX={
  lore:  {gold:0, xp:60,  msg:'Orin\'s tale stays with you:  +60 XP'},
  kept:  {gold:80,xp:0,   msg:'Hale slips you his pay for the week:  +80 G'},
  told:  {gold:0, xp:40,  msg:'The village thanks you for the truth:  +40 XP'},
  end:   {gold:0, xp:0,   msg:'Resolve: +10% damage to the Lich King'},
  listen:{gold:0, xp:0,   msg:'Aldric hesitates: the Lich King starts weakened (-10% HP)'},
  greed: {gold:150,xp:0,  msg:'You pocket a fistful of crown-gold:  +150 G'},
};
{const _sa=storyApply;storyApply=function(d){const had=d&&d.flag&&STORY.flags[d.flag];const r=_sa.apply(this,arguments);
  const fx=d&&d.flag&&!had&&CHOICE_FX[d.flag];if(fx){if(fx.gold)P.gold+=fx.gold;if(fx.xp)P.xp+=fx.xp;toast(fx.msg,3.2,'#ffd23f');}return r;};}
{const _de=damageEnemy;damageEnemy=function(e,d,k){if(e&&e.type==='lich'&&STORY.flags.end&&d>0)d*=1.1;return _de.call(this,e,d,k);};}
{const _ic=initCombatEnemy;initCombatEnemy=function(e){const r=_ic.apply(this,arguments);if(e&&e.type==='lich'&&STORY.flags.listen&&e.hp>=e.maxhp)e.hp=Math.round(e.maxhp*.9);return r;};}
