/* =====================================================================
   MONSTER SPAWNERS (runed, caged braziers). While you are near one it keeps summoning its themed monsters (up to a cap).
   It has HP: arcane shots, charged shots, fire, sword / lance / quake / meteor cards all damage it. Destroying one pays XP, gold,
   crafting parts and sometimes a card; it re-kindles after SPW_RESPAWN seconds of play. State saved as {id: seconds-left} for destroyed ones.
   ===================================================================== */
const SPW_RANGE=330,SPW_RESPAWN=600,SPW_SHOT_MULT=2.5,SPW_REACH=17;
const SPW_THEME={
  warren:{flame:'#ff9a3d',flame2:'#ffe14d',rune:'#ffb060',iron:'#4a3a2a',iron2:'#6a5640',glow:'255,150,60'},
  bone:  {flame:'#9fdcff',flame2:'#ffffff',rune:'#cfe6ff',iron:'#555868',iron2:'#7a7e94',glow:'150,210,255'},
  bog:   {flame:'#7dff6a',flame2:'#d8ffb0',rune:'#9aff7a',iron:'#2e4a36',iron2:'#4a7058',glow:'110,255,100'},
  sun:   {flame:'#ffd23f',flame2:'#fff6c0',rune:'#ffe46b',iron:'#6a5430',iron2:'#9a7c46',glow:'255,210,80'},
  grave: {flame:'#b07dff',flame2:'#e8d0ff',rune:'#c9a0ff',iron:'#2a2640',iron2:'#4a4468',glow:'170,120,255'},
};
/* sprite: 24x28 cage of iron bars on a runed stone plinth (the flame is drawn live behind the bars) */
function mkSpwSprite(th){
  return autoOutline(makeSprite(24,28,g=>{
    rect(g,1,22,22,6,'#4a465e');rect(g,1,22,22,1,'#8a86a4');rect(g,2,27,20,1,'#2c2a3c');rect(g,3,23,18,1,'#5c5876');
    [[4,25],[9,25],[14,25],[19,25]].forEach(([x,y],i)=>{rect(g,x,y,1,2,th.rune);rect(g,x+(i%2?1:-1),y,1,1,th.rune);});     // glowing runes on the plinth
    rect(g,5,17,14,5,th.iron);rect(g,5,17,14,1,th.iron2);rect(g,4,20,16,2,th.iron);rect(g,4,20,16,1,th.iron2);                    // bowl
    for(const x of [4,8,12,15,19]){rect(g,x,4,1,16,th.iron);rect(g,x,4,1,2,th.iron2);}                                         // bars
    rect(g,4,4,16,1,th.iron2);rect(g,3,3,18,2,th.iron);rect(g,3,3,18,1,th.iron2);                                              // top ring
    rect(g,10,0,4,3,th.iron);rect(g,11,0,2,1,th.iron2);rect(g,11,10,2,1,th.rune);                                                // finial + a rune on the bars
    rect(g,3,19,18,1,th.iron);rect(g,3,12,18,1,th.iron);}),'#14101e');
}
function mkSpwRubble(th){return autoOutline(makeSprite(24,12,g=>{rect(g,1,6,22,6,'#4a465e');rect(g,2,5,8,4,'#6a6680');rect(g,13,4,8,5,'#5a5670');rect(g,5,3,5,3,'#7a7690');rect(g,6,10,3,1,th.rune);rect(g,16,9,2,1,th.rune);rect(g,10,8,3,2,'#2c2a3c');}),'#14101e');}
const SPW_ART={};for(const k in SPW_THEME)SPW_ART[k]={spr:mkSpwSprite(SPW_THEME[k]),rub:mkSpwRubble(SPW_THEME[k])};
const WFX=[];                                    // world-space floating text + sparks (works in and out of battle)
function wfxText(x,y,s,col='#fff',size=13,dur=1.0){WFX.push({k:'t',x,y,s,col,size,t:0,dur});}
function wfxBurst(x,y,col,n=10,sp=100,life=.6){for(let i=0;i<n;i++){const a=Math.random()*6.283,v=R(.3,1)*sp;WFX.push({k:'p',x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-40,t:0,dur:life*R(.6,1),col,sz:RI(2,3)});}}
function initSpawners(){
  SPW.length=0;
  for(const d of SPAWNER_DEFS)SPW.push({def:d,id:d.id,x:(d.tx+.5)*TS,y:(d.ty+.92)*TS,hp:d.hp,maxhp:d.hp,alive:true,dying:false,dyT:0,left:0,t:2.5,flash:0,pulse:Math.random()*6,near:false,pop:0});
}
initSpawners();
function resetSpawners(){for(const s of SPW){s.hp=s.maxhp;s.alive=true;s.dying=false;s.left=0;s.t=2.5;s.flash=0;}
  for(let i=enemies.length-1;i>=0;i--)if(enemies[i].spw&&!enemies[i].engaged)enemies.splice(i,1);}
function packSpawners(){const o={};for(const s of SPW)if(!s.alive||s.dying)o[s.id]=Math.max(1,Math.round(s.left||SPW_RESPAWN));return o;}
function unpackSpawners(m){resetSpawners();if(!m||typeof m!=='object')return;for(const s of SPW)if(Number.isFinite(m[s.id])){s.alive=false;s.dying=false;s.left=clamp(m[s.id],1,SPW_RESPAWN);}}
const spwLive=s=>s.alive&&!s.dying;
const spwCenter=s=>({x:s.x,y:s.y-16});
const spwMinions=s=>enemies.filter(e=>e.spw===s&&e.alive&&!e.dying);
const spwSameZone=s=>zoneOfPx(s.y)===zoneOfPx(P.y);
/* damage entry point used by shots and cards */
function hurtSpawner(s,dmg,kind){
  if(!spwLive(s)||!(dmg>0))return false;
  dmg=Math.max(1,Math.round(dmg*boonDmg()));
  s.hp-=dmg;s.flash=.16;sfx('hit');
  wfxText(s.x+R(-10,10),s.y-52,String(dmg),kind==='charged'?'#7df9ff':'#fff',kind==='charged'?17:13);
  wfxBurst(s.x,s.y-18,SPW_THEME[s.def.theme].flame,5,90,.45);
  if(s.hp<=0){s.hp=0;destroySpawner(s);}
  return true;
}
function destroySpawner(s){
  const d=s.def;s.dying=true;s.dyT=0;s.left=SPW_RESPAWN;
  sfx('boom');if(B)B.shake=Math.max(B.shake,.5);
  wfxBurst(s.x,s.y-18,SPW_THEME[d.theme].flame,26,170,.9);wfxBurst(s.x,s.y-10,'#d8d4e8',12,120,.8);
  const xp=Math.round(d.xp*storyXp()),g=RI(d.gold[0],d.gold[1]),lines=[];
  questGiveXp(xp);P.gold+=g;ACH.s.spw=(ACH.s.spw|0)+1;
  wfxText(s.x,s.y-70,'+'+xp+' XP','#9ad0ff',14);wfxText(s.x,s.y-86,'+'+g+' G','#ffd23f',14);
  addMat('shard',d.mats);lines.push('+'+d.mats+' '+MATS.shard.n);
  const mk=MAT_DROP[d.mobs[0]];if(mk){addMat(mk,2);lines.push('+2 '+MATS[mk].n);}
  let got=null;
  if(Math.random()<d.card){const c=randCardOf(pickRarity({common:30,uncommon:38,rare:26,epic:6}));if(c){grantCard(c.id);got=c.name;}}
  guarGrant('spawner',GUAR_SPAWNER,{x:s.x,y:s.y});
  toast('SPAWNER DESTROYED!  +'+xp+' XP  +'+g+' G'+(got?'  +CARD: '+got:''),3.8,'#ffe14d');
  toast(lines.join('  '),2.6,'#7df9ff');
  if(B)B.saveSoon=true;else saveGame('spawner');
}
function spwRevive(s){s.alive=true;s.dying=false;s.hp=s.maxhp;s.left=0;s.t=2.5;wfxBurst(s.x,s.y-18,SPW_THEME[s.def.theme].flame,14,110,.7);}
/* shots (world + battle): returns true when the shot hit a spawner */
function hitSpawnerShot(sh){
  if(sh.own!=='p'||sh.kind==='pet')return false;
  for(const s of SPW){if(!spwLive(s)||!spwSameZone(s))continue;const c=spwCenter(s);
    if(Math.hypot(sh.x-c.x,sh.y-c.y)<sh.r+SPW_REACH){const arc=sh.kind==='arcane'||sh.kind==='charged';hurtSpawner(s,sh.dmg*(arc?SPW_SHOT_MULT:1),sh.kind);return true;}}
  return false;
}
function spwHitArc(o,a,range,half,dmg,kind){for(const s of SPW){if(!spwLive(s)||!spwSameZone(s))continue;const c=spwCenter(s),d=Math.hypot(c.x-o.x,c.y-o.y);
  if(d<range+SPW_REACH&&Math.abs(angDiff(angTo(o,c),a))<half)hurtSpawner(s,dmg,kind);}}
function spwHitRadius(x,y,r,dmg,kind){for(const s of SPW){if(!spwLive(s)||!spwSameZone(s))continue;const c=spwCenter(s);if(Math.hypot(c.x-x,c.y-y)<r+SPW_REACH)hurtSpawner(s,dmg,kind);}}
function spwHitZone(z,dmg,kind){for(const s of SPW){if(!spwLive(s)||!spwSameZone(s))continue;if(inZone(z,spwCenter(s),SPW_REACH))hurtSpawner(s,dmg,kind);}}
function spwSolidAt(x,y,hw,h){for(const s of SPW){if(!spwLive(s))continue;if(Math.abs(s.x-x)<hw+11&&Math.abs(s.y-y)<h+6&&y>s.y-26)return true;}return false;}
/* summoning */
function spwSpawnOne(s){
  const d=s.def,type=d.mobs[RI(0,d.mobs.length-1)];
  for(let k=0;k<14;k++){
    const a=Math.random()*6.283,r=R(38,66),x=s.x+Math.cos(a)*r,y=s.y+Math.sin(a)*r*.8;
    if(solidTile(Math.floor(x/TS),Math.floor(y/TS))||solidTile(Math.floor((x-8)/TS),Math.floor(y/TS))||solidTile(Math.floor((x+8)/TS),Math.floor(y/TS))||solidTile(Math.floor(x/TS),Math.floor((y-8)/TS)))continue;
    if(Math.hypot(x-P.x,y-P.y)<72||!losClear({x:s.x,y:s.y-8},{x,y:y-8}))continue;
    const tx=Math.floor(x/TS),ty=Math.floor(y/TS),e=mkEnemyObj(type,tx,ty);
    e.x=x;e.y=y;e.hx=s.x;e.hy=s.y+6;e.spw=s;initTerritory(e);applyLevel(e,levelFor(type,tx,ty));e.baseLv=e.lv;
    e.xpv=Math.round(e.xpv*.6);e.gm*=.6;e.fa=Math.atan2(P.y-y,P.x-x);       // summoned monsters are worth a bit less, so farming a spawner is not the best XP
    enemies.push(e);wfxBurst(x,y-8,SPW_THEME[d.theme].flame,10,90,.5);sfx('warn');s.pop=.5;return true;}
  return false;
}
function updateSpawners(dt){
  for(let i=WFX.length-1;i>=0;i--){const f=WFX[i];f.t+=dt;if(f.k==='p'){f.x+=f.vx*dt;f.y+=f.vy*dt;f.vy+=160*dt;}else f.y-=24*dt;if(f.t>=f.dur)WFX.splice(i,1);}
  for(const s of SPW){
    s.pulse+=dt;s.flash=Math.max(0,s.flash-dt);s.pop=Math.max(0,s.pop-dt);
    if(s.dying){s.dyT+=dt;if(Math.random()<dt*14)wfxBurst(s.x+R(-12,12),s.y-R(8,30),SPW_THEME[s.def.theme].flame,2,70,.5);if(s.dyT>1){s.dying=false;s.alive=false;}continue;}
    if(!s.alive){if(!B)s.left-=dt;if(s.left<=0)spwRevive(s);continue;}
    if(B||state!=='play'||FISH.on)continue;
    s.near=spwSameZone(s)&&Math.hypot(P.x-s.x,P.y-s.y)<SPW_RANGE;
    if(!s.near){s.t=Math.min(s.t,3);continue;}
    if(spwMinions(s).length>=s.def.cap){s.t=Math.max(s.t,s.def.every*.5);continue;}
    s.t-=dt;if(s.t<=0){if(spwSpawnOne(s))s.t=s.def.every*R(.85,1.15);else s.t=1.5;}
  }
  if(!B)for(let i=enemies.length-1;i>=0;i--){const e=enemies[i];if(e.spw&&!e.alive&&!e.engaged)enemies.splice(i,1);}
}
/* ---- drawing ---- */
function drawSpawner(s){
  const th=SPW_THEME[s.def.theme],art=SPW_ART[s.def.theme],sx=Math.round(s.x-cam.x),sy=Math.round(s.y-cam.y);
  if(sx<-60||sx>VW+60||sy<-80||sy>VH+80)return;
  if(!s.alive){drawEntShadow(s.x,s.y,14);draw(art.rub,sx-24,sy-24,2);
    if(Math.random()<.04)wfxBurst(s.x+R(-10,10),s.y-8,'#9a96b0',1,20,.9);return;}
  const dy=s.dying?Math.min(1,s.dyT):0,fl=Math.sin(s.pulse*9)*.5+Math.sin(s.pulse*5.3)*.5;
  drawEntShadow(s.x,s.y,17);
  // glow + live flame behind the bars
  const fx=sx,fy=sy-26,k=s.dying?1-dy:1,r=(46+fl*5+(s.near?10:0))*k;
  ctx.save();ctx.globalCompositeOperation='lighter';
  const gr=ctx.createRadialGradient(fx,fy,2,fx,fy,r);gr.addColorStop(0,`rgba(${th.glow},${.55*k})`);gr.addColorStop(1,`rgba(${th.glow},0)`);ctx.fillStyle=gr;ctx.fillRect(fx-r,fy-r,r*2,r*2);ctx.restore();
  const fh=(14+fl*3)*k;
  ctx.fillStyle=th.flame;ctx.beginPath();ctx.moveTo(fx-7,fy+8);ctx.quadraticCurveTo(fx-9,fy-fh*.4,fx+fl*2,fy-fh);ctx.quadraticCurveTo(fx+9,fy-fh*.4,fx+7,fy+8);ctx.closePath();ctx.fill();
  ctx.fillStyle=th.flame2;ctx.beginPath();ctx.moveTo(fx-3.5,fy+8);ctx.quadraticCurveTo(fx-4,fy-fh*.2,fx+fl,fy-fh*.6);ctx.quadraticCurveTo(fx+4,fy-fh*.2,fx+3.5,fy+8);ctx.closePath();ctx.fill();
  if(Math.random()<.25&&!s.dying)WFX.push({k:'p',x:s.x+R(-6,6),y:s.y-30,vx:R(-12,12),vy:-R(30,60),t:0,dur:R(.4,.8),col:th.flame2,sz:2});
  // the cage
  const bob=s.pop>0?Math.sin(s.pop/.5*Math.PI)*3:0;
  draw(art.spr,sx-24,sy-56+2-bob,2);
  if(s.flash>0){ctx.globalAlpha=.85;draw(whiteOf(art.spr),sx-24,sy-56+2-bob,2);ctx.globalAlpha=1;}
  // glowing runes pulse
  ctx.save();ctx.globalAlpha=.25+.2*Math.sin(s.pulse*3);ctx.fillStyle=th.rune;for(let i=0;i<4;i++)ctx.fillRect(sx-20+i*10+(i%2?1:0),sy-6,2,4);ctx.restore();
  // cracks as it takes damage
  const hf=s.hp/s.maxhp;
  if(hf<.7){ctx.fillStyle='#14101e';ctx.fillRect(sx-8,sy-40,2,10);ctx.fillRect(sx-6,sy-32,2,6);ctx.fillRect(sx+4,sy-44,2,8);}
  if(hf<.35){ctx.fillStyle='#14101e';ctx.fillRect(sx-14,sy-30,2,12);ctx.fillRect(sx+8,sy-34,2,12);ctx.fillRect(sx+10,sy-24,3,2);ctx.fillStyle=th.flame2;ctx.fillRect(sx-13,sy-27,1,5);}
  // name + hp bar when near or hurt
  const dd=Math.hypot(s.x-P.x,s.y-P.y);
  if(!s.dying&&(s.hp<s.maxhp||dd<230)){const bw=54,by=sy-70;bar(sx-bw/2,by,bw,5,hf,hf>.35?'#e8504a':'#ff9a3d');txt(s.def.name,sx,by-4,{size:8,align:'center',col:th.rune,lw:3});}
}
function drawWorldFx(){
  for(const f of WFX){const x=f.x-cam.x,y=f.y-cam.y;
    if(f.k==='t')txt(f.s,Math.round(x),Math.round(y),{size:f.size,align:'center',col:f.col,alpha:clamp(2*(1-f.t/f.dur),0,1),lw:3});
    else{ctx.globalAlpha=clamp(1-f.t/f.dur,0,1);ctx.fillStyle=f.col;ctx.fillRect(Math.round(x),Math.round(y),f.sz,f.sz);ctx.globalAlpha=1;}}
}
