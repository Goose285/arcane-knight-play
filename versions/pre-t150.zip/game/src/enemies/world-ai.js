function camMinY(){return zoneOfPx(P.y)==='ow'?OWY0*TS:0;}   // (OWY0 is 0 until the world is expanded north / south: the overworld then sits lower in the map)
function snapCam(){if(state==='editor')return;const y0=camMinY();cam.x=clamp(P.x-VW/2,0,Math.max(0,MW*TS-VW));cam.y=clamp(P.y-VH/2-10,y0,Math.max(y0,MH*TS-VH));}
const npcNear=()=>NPCS.some(n=>Math.hypot(n.x-P.x,n.y-P.y)<46);
const sightTile=(tx,ty)=>{if(tx<0||ty<0||tx>=MW||ty>=MH)return true;const t=map[ty][tx];return t===T.T||t===T.B||t===T.BT||t===T.R||t===T.RL||t===T.H||t===T.D||t===T.Z||t===T.S||t===T.PR||t===T.CW||t===T.CP||t===T.CK||t===T.CT;};
const eEye=e=>({x:e.x,y:e.y-(e.def.big?26:13)});
function losClear(a,b){const d=Math.hypot(b.x-a.x,b.y-a.y),n=Math.ceil(d/6);for(let i=1;i<n;i++){const x=a.x+(b.x-a.x)*i/n,y=a.y+(b.y-a.y)*i/n;if(sightTile(Math.floor(x/TS),Math.floor(y/TS)))return false;}return true;}
// Two ranges: a short AUTO radius (any direction, walls still block) and the longer vision CONE (facing + clear line of sight)
const trivial=e=>!e.def.boss&&P.lv-e.lv>=5;   // far below your level: ignores you unless you attack it
// awareness circle (~2-2.5 tiles, by type): inside it an enemy notices you even outside its sight cone. A decoy or a shadow-step shrinks it.
const awareR=e=>e.ar*((typeof B!=='undefined'&&B&&(B.ghost>0||(B.decoy&&B.decoy.hp>0)))?.6:1);
function sensed(e){
  if(e.tut||trivial(e)||e.calm>0)return false;
  if(e.terr&&!inTerr(e,P.x,P.y,6))return false;     // territorial: only notices you inside its own turf
  const c=eEye(e),p={x:P.x,y:P.y-12},d=Math.hypot(p.x-c.x,p.y-c.y);
  if(d>e.vr)return false;
  const inAuto=d<=awareR(e);
  const ang=Math.atan2(p.y-c.y,p.x-c.x),inCone=d<=14||Math.abs(Math.atan2(Math.sin(ang-e.fa),Math.cos(ang-e.fa)))<=e.def.vh;
  if(!inAuto&&!inCone)return false;
  if(!losClear(c,p))return false;
  return inAuto?'auto':'cone';
}
const sees=e=>!!sensed(e);
function fanPoly(e,a0,a1,R0,n){
  const c=eEye(e),pts=[];
  for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n,dx=Math.cos(a),dy=Math.sin(a);let r=0;
    while(r<R0){const nr=Math.min(R0,r+6);if(sightTile(Math.floor((c.x+dx*nr)/TS),Math.floor((c.y+dy*nr)/TS)))break;r=nr;}
    pts.push({x:c.x+dx*r,y:c.y+dy*r});}
  return pts;
}
function visionPoly(e,n=26){const c=eEye(e);return [c,...fanPoly(e,e.fa-e.def.vh,e.fa+e.def.vh,e.vr,n)];}
function wanderEnemy(e,dt){
  const ad=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
  const home=Math.hypot(e.hx-e.x,e.hy-e.y),boss=!!e.def.boss;
  e.mt-=dt;
  if(e.mode==='walk'){
    const sp=e.def.speed,hw=boss?12:7,bx=e.x,by=e.y;
    moveBox(e,Math.cos(e.fa)*sp*dt,0,hw,8);moveBox(e,0,Math.sin(e.fa)*sp*dt,hw,8);
    e.stuck=Math.hypot(e.x-bx,e.y-by)<sp*dt*.3?e.stuck+dt:0;
    if(e.mt<=0||e.stuck>.25){const ws=e.stuck>.25;e.mode='look';e.mt=R(1.4,3.2);e.lk=R(.5,1);e.ta=e.fa+(ws?Math.PI:0)+R(-1.4,1.4);e.stuck=0;}
  } else {
    e.lk-=dt;
    if(e.lk<=0){e.lk=R(.7,1.4);e.ta=e.fa+R(-2.4,2.4);if(home>(boss?3:5)*TS)e.ta=Math.atan2(e.hy-e.y,e.hx-e.x);}
    const df=ad(e.ta,e.fa),rate=2.3*dt;e.fa+=Math.max(-rate,Math.min(rate,df));
    if(e.mt<=0&&Math.abs(df)<.25&&!(boss&&Math.random()<.7)){e.mode='walk';e.mt=R(1.2,3);}
    else if(e.mt<=0)e.mt=R(.8,2);
  }
  if(Math.abs(Math.cos(e.fa))>.2)e.face=Math.cos(e.fa)<0?1:-1;
}
function updateEnemyWorld(e,dt){
  e.bob+=dt*5;e.alert=Math.max(0,e.alert-dt);
  const wx0=e.x,wy0=e.y;lifeEnemy(e,dt);wanderEnemy(e,dt);
  if(inTownPx(e.x,e.y-8)){e.x=wx0;e.y=wy0;e.mode='look';e.mt=1.2;e.ta=e.fa+Math.PI;e.fa=e.ta;}   // the village is off limits
  if(!B&&P.grace<=0&&!DLG&&state==='play'&&!(e.calm>0)&&!playerInTown()&&sees(e))startEncounter(e);
}
// ---- shooting an unaware monster from range starts the fight too ----
/* hold SHOT while exploring to charge; release = normal shot (tap) or a piercing-guard charged shot (full charge) */
const WCH={on:false,t:0};
function updateWorldCharge(dt){
  if(!WCH.on)return;
  if(B||state!=='play'||DLG){WCH.on=false;WCH.t=0;return;}
  if(held('KeyJ')){const b=WCH.t;WCH.t=Math.min(1.3,WCH.t+dt);if(b<.3&&WCH.t>=.3)sfx('charge');if(b<1&&WCH.t>=1)sfx('select');}
  if(rel('KeyJ')||!held('KeyJ')){const full=WCH.t>=1;WCH.on=false;WCH.t=0;fireWorldShot(full);}
}
function fireWorldShot(charged){
  if(!charged&&wcd>0)return;wcd=charged?.4:.28;
  let a=P.aim,best=.45;
  for(const e of enemies){if(!e.alive||e.engaged)continue;const c=ecen(e),d=Math.hypot(c.x-P.x,c.y-(P.y-12));if(d>360)continue;const df=Math.abs(angDiff(angTo({x:P.x,y:P.y-12},c),P.aim));if(df<best){best=df;a=angTo({x:P.x,y:P.y-12},c);}}
  if(charged){P.aim=a;P.dir=dirOfAngle(a);WS.push({x:P.x,y:P.y-12,vx:Math.cos(a)*420,vy:Math.sin(a)*420,r:12,life:1.1,kind:'charged',a,own:'p',dmg:arcaneDmg()*5});sfx('cshot');return;}
  WS.push({x:P.x,y:P.y-12,vx:Math.cos(a)*380,vy:Math.sin(a)*380,r:5,life:1.0,kind:'arcane',a,own:'p',dmg:arcaneDmg()});
  sfx('shoot');
}
function updateWorldShots(dt){
  for(const s of WS){
    s.life-=dt;if(s.life<=0){s.dead=true;continue;}
    if(sweepShot(s,dt)){s.dead=true;continue;}
    if(hitSpawnerShot(s)){s.dead=true;continue;}
    for(const e of enemies){
      if(!e.alive||e.engaged||e.dying)continue;
      const c=ecen(e);
      if(Math.hypot(s.x-c.x,s.y-c.y)<s.r+eRad(e)){s.dead=true;if(!B){startEncounter(e,true);if(s.kind==='charged')B.loud=1;damageEnemy(e,s.dmg,s.kind);if(s.kind==='pet')petOnHit(s,e);}break;}
    }
  }
  for(let i=WS.length-1;i>=0;i--)if(WS[i].dead)WS.splice(i,1);
}
function drawVision(){
  for(const e of enemies){
    if(!e.alive||e.engaged||trivial(e))continue;
    const c=eEye(e),dx=c.x-P.x,dy=c.y-P.y,d=Math.hypot(dx,dy);
    if(Math.abs(c.x-cam.x-VW/2)>VW/2+e.vr||Math.abs(c.y-cam.y-VH/2)>VH/2+e.vr)continue;
    const near=clamp(1.15-d/(e.vr*1.7),0,1),a=.05+.2*near;
    const sm=!B&&sensed(e),spotted=!!sm,poly=visionPoly(e);
    const g=ctx.createRadialGradient(c.x,c.y,6,c.x,c.y,e.vr);
    const col=spotted?'255,80,60':'255,226,110';
    g.addColorStop(0,`rgba(${col},${a*1.35})`);g.addColorStop(1,`rgba(${col},${a*.15})`);
    ctx.beginPath();poly.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();
    ctx.fillStyle=g;ctx.fill();
    ctx.strokeStyle=`rgba(${col},${.04+.3*near})`;ctx.lineWidth=1;ctx.stroke();
    // short auto-aggro radius (any direction, wall-occluded): faint dashed ring
    const ar=awareR(e),nar=clamp(1.35-d/(ar*2.4),0,1);       // fades in as you approach the circle
    if(nar>0||sm==='auto'){
      const ap=fanPoly(e,0,Math.PI*2,ar,40),acol=sm==='auto'?'255,80,60':'255,170,90';
      ctx.beginPath();ap.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.closePath();
      ctx.fillStyle=`rgba(${acol},${.02+.07*nar})`;ctx.fill();
      ctx.save();ctx.setLineDash([4,5]);ctx.strokeStyle=`rgba(${acol},${.07+.3*nar})`;ctx.lineWidth=1;ctx.stroke();ctx.restore();}
  }
}
