/* =====================================================================
   ELITE ENEMIES: affix rolls, stat changes, and the per-affix combat hooks (called from combat.js)
   ===================================================================== */
const hasAff=(e,id)=>!!(e&&e.elite&&e.elite.includes(id));
const eliteName=e=>e.elite.map(i=>AFFIX[i].n).join(' ');
// roll (or clear) the affixes of a regular monster. Bosses, rush clones and the starter meadow are never elite.
function eliteRoll(e,force){
  e.elite=null;
  if(e.def.boss||e.rush||(e.baseLv||e.lv||1)<ELITE.minLv)return;
  const ids=force||(Math.random()<ELITE.chance?(()=>{const a=AFFIX_IDS.slice(),n=(e.baseLv||e.lv)>=9&&Math.random()<.3?2:1,o=[];while(o.length<n)o.push(a.splice(RI(0,a.length-1),1)[0]);return o;})():null);
  if(ids&&ids.length)e.elite=ids.slice();
}
// give an enemy these affixes right now (used by tests, the rush and the debug hooks)
function makeElite(e,ids){e.elite=(ids&&ids.length)?ids.slice():null;applyLevel(e,e.lv);return e;}
// called at the end of applyLevel: stat bonuses + names. applyLevel recomputes from the base def, so this is idempotent.
function eliteApply(e){
  if(!e.elite||!e.elite.length)return;
  const n=e.elite.length;
  e.mhp=Math.round(e.mhp*(ELITE.hp+ELITE.hpExtra*(n-1)));e.hp=e.maxhp=e.mhp;e.dm*=ELITE.dm;
  e.xpv=Math.round(e.xpv*ELITE.reward);e.gm*=ELITE.reward;
  if(hasAff(e,'swift'))e.as*=1.3;
  const nm=eliteName(e);e.title=nm+' '+e.title;e.tname=nm+' '+e.tname;
}
function eliteInit(e){                                    // when a fight starts
  e.shield=hasAff(e,'shielded')?Math.round(e.mhp*.4):0;e.maxShield=e.shield;e.frenzy=false;
}
// shield soaks damage first. returns the damage that gets through (0 = fully absorbed)
function eliteShield(e,d,c,top){
  if(!(e.shield>0))return d;
  const ab=Math.min(e.shield,d);e.shield-=ab;d-=ab;e.flash=.08;sfx('clang');
  floatText(c.x,top-12,e.shield>0?'SHIELD':'SHIELD BROKEN','#7fd8ff',11);
  if(e.shield<=0)burst(c.x,c.y,'#7fd8ff',14,130,.5);
  return d;
}
function eliteAfterHit(e,d,kind){
  if(hasAff(e,'thorned')&&kind!=='dot'&&kind!=='wolf'&&kind!=='pet'&&P.hp>1){
    const r=Math.max(1,Math.min(24,Math.round(d*ELITE.thorns)));P.hp=Math.max(1,P.hp-r);const p=pcen();
    floatText(p.x+14,p.y-18,'-'+r+' THORNS','#9bd84a',10);B.flash=Math.max(B.flash,.08);
  }
  if(hasAff(e,'frenzied')&&!e.frenzy&&e.hp>0&&e.hp<e.maxhp*.4){e.frenzy=true;e.as*=1.5;const c=ecen(e);floatText(c.x,c.y-44,'FRENZY!','#d49bff',13);burst(c.x,c.y,'#d49bff',16,140,.6);sfx('warn');}
}
function eliteLeech(src,d){
  if(!src||!hasAff(src,'vampiric')||src.dying||src.hp<=0)return;
  const h=Math.max(1,Math.round(d*ELITE.leech)),c=ecen(src);src.hp=Math.min(src.maxhp,src.hp+h);
  floatText(c.x,c.y-30,'+'+h,'#ff5a7a',11);burst(c.x,c.y,'#ff5a7a',6,70,.4);
}
function eliteDeath(e,c){
  if(!hasAff(e,'volatile'))return;
  const z=Z.circle(c.x,c.y,ELITE.volatileR),dmg=Math.round(ELITE.volatileDmg*e.dm),own=e;
  B.owner=e;warnZones([z],.7);B.zones[B.zones.length-1].vol=true;
  B.timers.push({t:.7,o:null,vol:true,fn(){if(!B)return;B.owner=own;hitZones([z],ELITE.volatileDmg,'boom');}});
}
// rewards: elites always drop something extra
const eliteGearBoost=e=>!!(e&&e.elite);
// rendering: a pulsing coloured ring under the monster, a shield bubble, and a tiny affix pip over its head
function drawEliteAura(e,sx,sy){
  if(!e.elite)return;
  const col=AFFIX[e.elite[0]].col,pulse=.55+.25*Math.sin(gtime*5+e.x*.1);
  ctx.save();ctx.globalAlpha=pulse;ctx.strokeStyle=col;ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(sx,sy+2,15*e.sz,6*e.sz,0,0,6.283);ctx.stroke();
  if(e.elite.length>1){ctx.strokeStyle=AFFIX[e.elite[1]].col;ctx.beginPath();ctx.ellipse(sx,sy+2,19*e.sz,8*e.sz,0,0,6.283);ctx.stroke();}
  ctx.restore();
  if(e.shield>0){ctx.save();ctx.globalAlpha=.25+.2*Math.sin(gtime*7);ctx.fillStyle='#7fd8ff';ctx.beginPath();ctx.ellipse(sx,sy-14*e.sz,17*e.sz,20*e.sz,0,0,6.283);ctx.fill();ctx.globalAlpha=.7;ctx.strokeStyle='#dff6ff';ctx.lineWidth=1.5;ctx.stroke();ctx.restore();}
}
