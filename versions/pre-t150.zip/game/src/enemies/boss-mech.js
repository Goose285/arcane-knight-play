/* =====================================================================
   BOSS MECHANICS: every boss gets its own signature moves on top of the shared telegraphed attack kit (see docs/bosses.md).
   Primitives: knockback (push the hero), lingering hazard pools, summoned minions, breakable shields (break = a stagger), teleports.
   Each boss tries a signature move on ~40% of its attacks (cooldown per move); otherwise its usual pattern plays.
   ===================================================================== */
/* push the hero away from a point over ~.28s (walls still stop him) */
function knockPlayer(fx,fy,dist){
  const p=pcen(),a=Math.atan2(p.y-fy,p.x-fx),T=.28;
  B.pk={vx:Math.cos(a)*dist/T,vy:Math.sin(a)*dist/T,t:T};
  burst(p.x,p.y,'#e8f0ff',8,110,.4);floatText(p.x,p.y-32,'KNOCKED BACK','#dfeaff',11);
}
/* a lingering hazard on the ground: ticks the hero every .5s while he stands in it */
function addPool(x,y,r,dur,dmg,fx){
  B.pools=B.pools||[];const o=B.owner;B.pools.push({x,y,r,t:0,dur,dmg:Math.round(dmg*(o&&o.dm||1)),fx,tk:.35,o});
}
/* summon minions (never more than 4 alive): they carry no loot / xp, fall with their master and are removed from the world afterwards */
function summonMinions(e,type,n,lv,spots){
  const c=ecen(e),alive=B.ens.filter(o=>o.tmp&&!o.dying).length;n=Math.min(n,4-alive);const made=[];
  for(let i=0;i<n;i++){
    const sp=spots&&spots[i]||scatterSpot(c,c,Math.cos(i*2.4+Math.random())*80,Math.sin(i*2.4+Math.random())*80,eOff(e)),o=mkEnemyObj(type,0,0);
    o.x=o.hx=sp.x;o.y=o.hy=sp.y+13;applyLevel(o,Math.max(1,Math.round(lv)));o.baseLv=o.lv;o.xpv=0;o.gm=0;o.elite=null;o.tmp=true;o.rush=true;
    enemies.push(o);initCombatEnemy(o,.6);B.ens.push(o);made.push(o);burst(sp.x,sp.y,'#b99cff',12,110,.6);
  }
  if(made.length){sfx('warn');floatText(c.x,c.y-60,'SUMMONED!','#d4b3ff',12);}
  return made;
}
/* a shield the hero has to break: it soaks damage; breaking it staggers the boss; it fades after `dur` seconds */
function giveShield(e,frac,dur=14,msg='SHIELDED - BREAK IT!'){
  e.bshield=e.bshieldMax=Math.max(20,Math.round(e.maxhp*frac));e.bshieldT=dur;
  setBanner(msg,1.3,'#9ad0ff');sfx('shield');const c=ecen(e);burst(c.x,c.y,'#9ad0ff',18,140,.7);
}
function bossShieldHit(e,d,c,top){
  e.bshield-=d;sfx('clang');floatText(c.x+R(-8,8),top,String(Math.round(d)),'#9ad0ff',12);burst(c.x,c.y,'#cfefff',6,100,.35);
  if(e.bshield<=0){
    e.bshield=0;e.stun=2.6;e.stunK='stun';B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);e.st='idle';e.cur=null;e.charge=0;e.atkCd=2.8;e.dash=null;
    setBanner('SHIELD BROKEN!',1.1,'#ffe14d');floatText(c.x,top-14,'STAGGERED!','#ffe14d',14);sfx('boom');B.shake=Math.max(B.shake,.3);burst(c.x,c.y,'#ffffff',22,170,.7);
  }
  return true;
}
/* a teleport: the landing spot is telegraphed first; the boss reappears there with a slam */
function bossSpotNear(e,p,r){
  for(let i=0;i<12;i++){const a=Math.random()*6.283,x=p.x+Math.cos(a)*r,y=p.y+Math.sin(a)*r,q=clampRay(p,7,{x,y},7);
    if(!solidTile(Math.floor((q.x-12)/TS),Math.floor((q.y+20)/TS))&&!solidTile(Math.floor((q.x+12)/TS),Math.floor((q.y+20)/TS))&&Math.hypot(q.x-p.x,q.y-p.y)>r*.6)return q;}
  return clampRay(p,7,{x:p.x+r,y:p.y},7);
}
function bossTeleport(e,dest){const dy=ecen(e).y-e.y;e.x=dest.x;e.y=dest.y-dy;e.dash=null;burst(dest.x,dest.y,'#d4b3ff',16,130,.6);}

/* ---- per-boss move books: name -> () => attack ---- */
const BOSS_MOVES={
  dragon:(e,c,p,a)=>({
    gust:()=>{const z=Z.cone(c.x,c.y,a,205,.9);return{windup:.95,zones:[z],recover:.7,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;e.hop=.3;const hit=inZone(z,pcen());hitZones([z],14,'slash');if(hit&&B.phase==='fight')knockPlayer(c.x,c.y,125);}};},   // WING GUST: damage + knockback
    flamewall:()=>{const z=Z.cone(c.x,c.y,a,235,.6);return{windup:.9,zones:[z],recover:.9,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.6;hitZones([z],28,'fire');
      for(const k of [85,145,205]){const q=clampRay(c,19,{x:c.x+Math.cos(a)*k,y:c.y+Math.sin(a)*k},7);addPool(q.x,q.y,32,7,9,'fire');}}};},   // phase 2: the breath leaves FLAME POOLS
  }),
  lich:(e,c,p,a)=>({
    raise:()=>{const sp=[0,1].map(i=>scatterSpot(c,c,Math.cos(a+(i?1:-1)*1.1)*95,Math.sin(a+(i?1:-1)*1.1)*95,eOff(e))),zs=sp.map(s=>Z.circle(s.x,s.y,30,7));
      return{windup:1.05,zones:zs,recover:.8,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;summonMinions(e,'knight',2,Math.max(3,(e.lv||16)*.55),sp);}};},   // RAISE THE DEAD
    step:()=>{const d=bossSpotNear(e,pcen(),125),z=Z.circle(d.x,d.y,78,7);
      return{windup:.95,zones:[z],recover:.7,start(e){e.charge=1;},strike(e){e.charge=0;bossTeleport(e,d);e.dragonOpen=.5;hitZones([z],26,'void');}};},   // PHASE STEP: teleports onto a marked spot
  }),
  rimegar:(e,c,p,a)=>({
    slam:()=>{const q=clampRay(c,19,p,7),z=Z.circle(q.x,q.y,100,7),z2=Z.ring(q.x,q.y,100,215,7);
      return{windup:1.25,zones:[z],recover:.9,start(e){e.charge=1;},strike(e){e.charge=0;e.hop=.4;e.dragonOpen=.4;hitZones([z],30,'frost');
        schedule(.3,()=>{if(B.phase!=='fight')return;warnZones([z2],.7);schedule(.7,()=>{if(B.phase==='fight')hitZones([z2],22,'frost');});});}};},   // GLACIAL SLAM + shockwave ring
    gale:()=>{const z=Z.cone(c.x,c.y,a,215,.95);return{windup:1.0,zones:[z],recover:.8,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;const hit=inZone(z,pcen());hitZones([z],16,'frost');if(hit&&B.phase==='fight')knockPlayer(c.x,c.y,110);}};},   // BITTER GALE knockback
  }),
  mossback:(e,c,p,a)=>({
    spit:()=>{const zs=scatterZones(c,p,3,38,40,120,19);return{windup:1.05,zones:zs,recover:.8,strike(e){e.hop=.3;e.dragonOpen=.4;hitZones(zs,16,'mire');zs.forEach(z=>addPool(z.x,z.y,34,7,8,'mire'));}};},   // POISON SPIT leaves toxic pools
    hatch:()=>{const sp=[0,1].map(i=>scatterSpot(c,c,Math.cos(a+(i?1:-1)*1.3)*90,Math.sin(a+(i?1:-1)*1.3)*90,eOff(e))),zs=sp.map(s=>Z.circle(s.x,s.y,28,7));
      return{windup:1.0,zones:zs,recover:.8,strike(e){e.dragonOpen=.4;summonMinions(e,'toad',2,Math.max(2,(e.lv||17)*.45),sp);}};},   // HATCH: bog toads
  }),
  colossus:(e,c,p,a)=>({
    storm:()=>{const z=Z.ring(c.x,c.y,0,205,19);return{windup:1.1,zones:[z],recover:.9,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;e.hop=.4;const hit=inZone(z,pcen());hitZones([z],14,'sand');if(hit&&B.phase==='fight')knockPlayer(c.x,c.y,150);}};},   // SANDSTORM: blasts everything outward
    burrow:()=>{const q=clampRay(c,19,pcen(),7),z=Z.circle(q.x,q.y,85,7);return{windup:1.35,zones:[z],recover:.9,start(e){e.charge=1;},strike(e){e.charge=0;bossTeleport(e,q);e.dragonOpen=.5;e.hop=.4;hitZones([z],30,'sand');}};},   // BURROW: erupts where you were standing
  }),
};
/* which moves each boss tries, with cooldowns (s) and conditions */
const BOSS_BOOK={
  dragon:[['gust',9,(e,d)=>d<230],['flamewall',10,(e)=>e.p2]],
  lich:[['raise',16,e=>true],['step',9,e=>true]],
  rimegar:[['slam',9,e=>true],['gale',9,(e,d)=>d<230]],
  mossback:[['spit',8,e=>true],['hatch',17,e=>e.p2||true]],
  colossus:[['storm',9,(e,d)=>d<230],['burrow',10,e=>true]],
};
function bossMove(e,name){B.owner=e;ZOFF=eOff(e);const c=ecen(e),p=aimPos();return BOSS_MOVES[e.type](e,c,p,angTo(c,p))[name]();}
/* wrap each boss's normal attack picker */
for(const t in BOSS_BOOK){
  const base=ATK[t];
  ATK[t]=function(e){
    const c=ecen(e),p=aimPos(),d=Math.hypot(p.x-c.x,p.y-c.y),mm=e.mc=e.mc||{};
    if(Math.random()<(e.p3?.55:e.p2?.48:.38)){
      const book=BOSS_BOOK[t].filter(([k,cd,cond])=>(B.t-(mm[k]===undefined?-99:mm[k]))>=cd&&cond(e,d));
      if(book.length){const k=book[RI(0,book.length-1)][0];mm[k]=B.t;return BOSS_MOVES[t](e,c,p,angTo(c,p))[k]();}
    }
    return base(e);
  };
}
/* phase changes: new mechanics arrive with the new phase */
function bossMechPhase(e){
  const c=ecen(e),ph=e.p3?3:2;
  if(e.type==='dragon'){for(let i=0;i<4;i++){const q=clampRay(c,19,{x:c.x+Math.cos(i*1.57+.6)*115,y:c.y+Math.sin(i*1.57+.6)*115},7);addPool(q.x,q.y,36,8,10,'fire');}setBanner('FLAMES ERUPT!',1.3,'#ff9a3d');}
  else if(e.type==='lich')giveShield(e,ph===3?.07:.05,16,'SOUL WARD - BREAK IT!');
  else if(e.type==='rimegar')giveShield(e,.06,15,'ICE ARMOR - BREAK IT!');
  else if(e.type==='colossus')giveShield(e,ph===3?.08:.06,15,'STONE SKIN - BREAK IT!');
  else if(e.type==='mossback'){summonMinions(e,'toad',2,Math.max(2,(e.lv||17)*.45));}
}
function updateBossMech(dt){
  if(B.pk){const s=Math.min(dt,B.pk.t);moveBox(P,B.pk.vx*s,0,6,7);moveBox(P,0,B.pk.vy*s,6,7);B.pk.t-=dt;if(B.pk.t<=0)B.pk=null;}
  if(B.pools&&B.pools.length){
    for(const q of B.pools){
      q.t+=dt;if(B.phase!=='fight'||(q.o&&q.o.dying)){q.t=q.dur;continue;}
      q.tk-=dt;if(q.tk<=0){q.tk=.5;const p=pcen();if(Math.hypot(p.x-q.x,p.y-q.y)<=q.r+6){damagePlayer(q.dmg,q.o);}}
    }
    B.pools=B.pools.filter(q=>q.t<q.dur);
  }
  for(const e of B.ens)if(e.bshield>0){e.bshieldT-=dt;if(e.bshieldT<=0){e.bshield=0;const c=ecen(e);burst(c.x,c.y,'#9ad0ff',14,120,.6);floatText(c.x,c.y-50,'WARD FADES','#9ad0ff',11);}}
}
function drawBossPools(){
  if(!B||!B.pools)return;
  for(const q of B.pools){
    const k=Math.min(1,(q.dur-q.t)/1.2,q.t/.25),fire=q.fx==='fire',pul=.5+.5*Math.sin(gtime*7+q.x);
    ctx.save();ctx.globalAlpha=(.38+.18*pul)*k;ctx.fillStyle=fire?'#ff6a1f':'#7bbf2a';ctx.beginPath();ctx.ellipse(q.x,q.y+4,q.r,q.r*.62,0,0,6.283);ctx.fill();
    ctx.globalAlpha=.7*k;ctx.strokeStyle=fire?'#ffd23f':'#d3f08a';ctx.lineWidth=2;ctx.stroke();
    ctx.fillStyle=fire?'#ffe27a':'#e6ffb0';for(let i=0;i<4;i++){const u=(gtime*.9+i/4+q.x*.01)%1;ctx.globalAlpha=(1-u)*.8*k;ctx.fillRect(Math.round(q.x-q.r*.5+i*q.r*.33),Math.round(q.y-u*20),2,3);}
    ctx.restore();
  }
}
function drawBossShields(){
  if(!B)return;
  for(const e of B.ens){
    if(!(e.bshield>0)||e.dying)continue;const c=ecen(e),r=e.def.big?42:30,f=e.bshield/e.bshieldMax,pul=.5+.5*Math.sin(gtime*6);
    ctx.save();ctx.globalAlpha=.25+.15*pul;ctx.fillStyle='#9ad0ff';ctx.beginPath();ctx.arc(c.x,c.y,r,0,6.283);ctx.fill();
    ctx.globalAlpha=.8;ctx.strokeStyle='#e6f6ff';ctx.lineWidth=2;ctx.beginPath();ctx.arc(c.x,c.y,r,-1.57,-1.57+6.283*f);ctx.stroke();ctx.restore();
  }
}
