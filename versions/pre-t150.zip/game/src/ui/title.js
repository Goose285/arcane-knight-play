/* ---- title menu ---- */
const titleMenu={items:[],sel:0,rects:[],confirm:false,save:null};
function initTitleMenu(){
  titleMenu.save=readSave();const bk=readBackup();titleMenu.bak=bk&&(!titleMenu.save||bk.P.lv>titleMenu.save.P.lv||(bk.P.lv===titleMenu.save.P.lv&&bk.P.gold>titleMenu.save.P.gold))?bk:null;   // a more advanced backup exists
  titleMenu.items=titleMenu.save?['Continue','New Game']:['New Game'];if(titleMenu.bak)titleMenu.items.push('Restore Backup');titleMenu.items.push('Fishing Lab');titleMenu.sel=0;titleMenu.confirm=false;}
function startFromTitle(){
  const it=titleMenu.items[titleMenu.sel];
  if(it==='Fishing Lab'){flEnter();return;}
  if(it==='Restore Backup'){const b=titleMenu.bak;try{localStorage.setItem(SAVE_KEY,JSON.stringify(b));}catch(e){}titleMenu.save=b;loadSave(b);}
  else if(it==='Continue'){loadSave(titleMenu.save);}
  else if(titleMenu.save&&!titleMenu.confirm){titleMenu.confirm=true;sfx('select');return;}   // erasing a save needs a second press
  else{clearSave();Object.assign(P,{x:SPAWN.x,y:SPAWN.y,dir:'d',aim:Math.PI/2,moving:false,hp:80,lv:1,xp:0,gold:0,up:0,grace:3,regen:0});P.hp=maxHp();snapCam();resetCards();resetGear();resetQuests();resetSkills();resetCraft();resetPets();resetStory();resetDaily();resetAch();unpackSecrets(null);resetSpawners();resetFish();if(!introStart())tutMaybeStart();RUSH.on=false;RUSH.cur=null;lichDown=false;DAY.t=.3;dayCompute();syncNight(true);}
  state='play';sfx('start');if(it==='Continue'||!introActive())toast(it==='Continue'?'Welcome back, hero!':'Stay out of sight cones - or shoot first!',3.5,'#ffe9a0');areaCur='';if(introActive())areaT=0;
}
/* ---- title ---- */
const embers=Array.from({length:40},()=>({x:Math.random()*640,y:Math.random()*448,s:R(8,30),a:Math.random()*6}));
const TSTEP=()=>titleMenu.items.length>=4?46:52;
function drawTitle(){
  const s=Math.min(VW/640,VH/448),ox=(VW-640*s)/2,oy=(VH-448*s)/2;
  const gr=ctx.createLinearGradient(0,0,0,VH);gr.addColorStop(0,'#0c0a24');gr.addColorStop(.62,'#3a1c4a');gr.addColorStop(1,'#c4562e');ctx.fillStyle=gr;ctx.fillRect(0,0,VW,VH);
  for(let i=0;i<90;i++){const x=(i*97)%VW,y=(i*53)%(VH*.5);ctx.fillStyle=`rgba(255,255,255,${.4+.4*Math.sin(gtime*2+i)})`;ctx.fillRect(x,y,i%7===0?2:1,i%7===0?2:1);}
  ctx.save();ctx.translate(ox,oy);ctx.scale(s,s);
  ctx.fillStyle='#f4e8c0';ctx.beginPath();ctx.arc(520,90,34,0,6.283);ctx.fill();ctx.fillStyle='#e0d0a0';ctx.beginPath();ctx.arc(510,80,6,0,6.283);ctx.fill();
  ctx.fillStyle='#1a1030';ctx.beginPath();ctx.moveTo(-600,330);for(let x=-600;x<=1240;x+=20)ctx.lineTo(x,320+Math.sin(x*.02)*14);ctx.lineTo(1240,3000);ctx.lineTo(-600,3000);ctx.fill();
  ctx.fillStyle='#120a22';const cx0=210;ctx.fillRect(cx0,250,220,90);for(let i=0;i<7;i++)ctx.fillRect(cx0+i*32,238,16,14);
  ctx.fillRect(cx0-20,215,44,125);ctx.fillRect(cx0+196,215,44,125);ctx.fillRect(cx0+88,200,44,140);
  [cx0-20,cx0+196,cx0+88].forEach(x=>{const o=x===cx0+88?-15:0;ctx.beginPath();ctx.moveTo(x-4,215+o);ctx.lineTo(x+22,185+o);ctx.lineTo(x+48,215+o);ctx.fill();});
  ctx.fillStyle='#ffcf5a';[[cx0+104,230],[cx0+2,250],[cx0+212,250],[cx0+60,285],[cx0+150,285]].forEach(([x,y])=>ctx.fillRect(x,y,6,10));
  const dx=((gtime*40)%1300)-300;draw(SP.dragon,dx,110+Math.sin(gtime*2)*8,2,true);
  ctx.fillStyle='#0f2a1a';ctx.fillRect(-600,372,1840,3000);
  draw(SP.hero.r[Math.floor(gtime*4)%2?1:2],130,320,4);
  const sq=1+Math.sin(gtime*5)*.08;ctx.drawImage(SP.slime,430,372-64*sq,64*(2-sq),64*sq);
  embers.forEach(e=>{e.y-=e.s*.016;e.x+=Math.sin(gtime+e.a)*.2;if(e.y<0){e.y=448;e.x=Math.random()*640;}ctx.fillStyle=`rgba(255,${150+e.a*15|0},60,.7)`;ctx.fillRect(Math.round(e.x),Math.round(e.y),2,2);});
  txt('ARCANE KNIGHT',320,98,{size:50,align:'center',col:'#ffcf3a',out:'#3a0a0a',lw:10});
  txt('ARCANE KNIGHT',320,94,{size:50,align:'center',col:'#ff7a2a',out:false});
  txt('~ Realm of Embers ~',320,128,{size:16,align:'center',col:'#cfe0ff',lw:4});
  titleMenu.rects=[];
  titleMenu.items.forEach((it,i)=>{
    const yc=178+i*TSTEP(),sel=i===titleMenu.sel,lab=it==='New Game'&&titleMenu.confirm?'Erase save? Press again':it;
    if(sel){ctx.fillStyle='rgba(255,207,58,.16)';ctx.fillRect(320-150,yc-26,300,46);ctx.strokeStyle=`rgba(255,207,58,${.55+.3*Math.sin(gtime*5)})`;ctx.lineWidth=2;ctx.strokeRect(320-150,yc-26,300,46);}
    txt(lab,320,yc,{size:titleMenu.confirm&&sel&&it==='New Game'?18:(it==='Fishing Lab'?20:24),align:'center',col:sel?'#fff':(it==='Fishing Lab'?'#8fd8e8':'#a8a0c0'),lw:6});
    if(it==='Fishing Lab')txt('prototype fishing mechanics',320,yc+13,{size:9,align:'center',col:'#9fe8ff',lw:3});
    if(it==='Restore Backup'&&titleMenu.bak){const sv=titleMenu.bak;txt('Lv '+sv.P.lv+'  -  '+(sv.area||'Realm')+'  -  '+sv.P.gold+' G',320,yc+14,{size:9,align:'center',col:'#9dffb0',lw:3});}
    if(it==='Continue'&&titleMenu.save){const sv=titleMenu.save;txt('Lv '+sv.P.lv+'  -  '+(sv.area||'Realm')+'  -  '+sv.P.gold+' G',320,yc+14,{size:9,align:'center',col:'#ffe9a0',lw:3});}
    titleMenu.rects.push({x:ox+(320-150)*s,y:oy+(yc-26)*s,w:300*s,h:46*s});
  });
  if(!TOUCH)txt('W/S or Arrows: choose   SPACE: select',320,230+(titleMenu.items.length-1)*TSTEP(),{size:10,align:'center',col:'#cfe0ff',lw:3});
  panel(100,396,440,44,{fill:'#120e24'});
  if(TOUCH){txt('Left thumb: joystick     SHOT: shoot (hold = charge)',320,414,{size:11,align:'center',col:'#e8e0c8',out:false});txt('Tap a card: cast     Swipe it down: discard',320,430,{size:11,align:'center',col:'#e8e0c8',out:false});}
  else{txt('WASD / Arrows: walk     J: arcane shot (hold = charge)',320,414,{size:11,align:'center',col:'#e8e0c8',out:false});txt('L: next card   K: cast card   E: talk   Avoid sight cones!',320,430,{size:11,align:'center',col:'#e8e0c8',out:false});}
  ctx.restore();
  titleMenu.gear={x:VW-SR-46,y:VH-SB-46,w:36,h:36};
  panel(titleMenu.gear.x,titleMenu.gear.y,36,36,{fill:'#120e24'});txt('SET',titleMenu.gear.x+18,titleMenu.gear.y+23,{size:10,align:'center',col:'#cfe0ff',out:false});
  if(!TOUCH)txt('O: settings',VW-SR-52,VH-SB-6,{size:9,align:'right',col:'#cfe0ff',alpha:.7,lw:2});
}
