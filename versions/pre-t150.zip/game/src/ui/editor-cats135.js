/* =====================================================================
   EDITOR TRAY (t135u): categories reorganised into
   Ground, Paths, Water, Trees, Plants, Walls, Buildings, Props, Regions, NPCs/Enemies, All.
   Every tree (incl. the big-tree variants) and every ground tile in the game is paintable; "All" lists every item.
   ===================================================================== */
{
  const add=(cat,kind,id,name)=>{const key=kind+':'+id;if(ED_ITEM_BY[key]){ED_ITEM_BY[key].cat=cat;return;}const it={cat,kind,id,name,key};ED_ITEMS.push(it);ED_ITEM_BY[key]=it;};
  // extra ground: ice, sandstone floor, cave floor, crypt floor, quarry, moss...
  [['IC','Ice'],['SR','Sandstone floor'],['CV','Cave floor'],['CF','Crypt floor'],['SC','Sand cobbles']].forEach(([k,n])=>{if(T[k]!=null&&TSPR[T[k]]){add('Ground','t',T[k],n);ED_GROUNDSET.add(T[k]);ED_OKSET.add(T[k]);ED_PROPSET.delete(T[k]);}});
  const S=a=>new Set(a.map(k=>T[k]).filter(v=>v!=null));
  const GROUND=S(['G','K','L','SD','MD','SN','C','MO','RG','VB','IC','SR','CV','CF','SC']),PATHS=S(['P','F','J']),WATER=S(['W','RE','MR','U']),
    TREES=new Set([...TREE_IDS,...BIGTREE_IDS].filter(t=>t!==T.RE&&t!==T.BU)),PLANTS=S(['BU','PL1','PL2','PL3','PL4','MS1','MS2','MS3']),
    WALLS=new Set([...WALL_IDS,T.N,T.WSB,T.WPI,T.WOC,T.WIC,T.WTB,T.WPT,T.WGP]),REG=S(['RK','CR1','CR2','CL','VR','LV']),
    BLD=S(['B','S','BT','R','H','D','RL','CW','CP','CK','CT','CS','CX','GT','GX','GB','CH','CO','RU','CHS','CHR','CHW','CHP','CHA','CHC','CHF','CHB','CWL']);
  const TREE_NAMES={[T.T]:'Oak tree',[T.PN]:'Pine tree',[T.PM]:'Palm tree',[T.AC]:'Acacia tree',[T.ST]:'Tree stump'};
  for(const id of TREES)add('Trees','p',id,TREE_NAMES[id]||'Tree');
  const all=ED_ITEMS.slice();
  for(const it of all){
    if(it.kind==='e'||it.kind==='n'){it.cat='NPCs/Enemies';continue;}
    if(it.kind==='b'){it.cat='Buildings';continue;}
    const id=it.id;
    it.cat=GROUND.has(id)?'Ground':PATHS.has(id)?'Paths':WATER.has(id)?'Water':TREES.has(id)?'Trees':PLANTS.has(id)?'Plants':WALLS.has(id)?'Walls':REG.has(id)?'Regions':BLD.has(id)?'Buildings':'Props';
    if(it.name&&/^Tile /.test(it.name))it.name=it.name.replace('Tile ',it.cat==='Buildings'?'Building piece ':'Piece ');
  }
  ED_CATS.length=0;ED_CATS.push('Ground','Paths','Water','Trees','Plants','Walls','Buildings','Props','Regions','NPCs/Enemies','All');
}
const edCatItems=c=>c==='All'?ED_ITEMS.slice():ED_ITEMS.filter(i=>i.cat===c);
