/* =====================================================================
   BESTIARY (t139u) + HELP / GUIDE (t139u) menu tabs.
   BESTIARY: every monster you have SEEN (near you, on screen) gets an entry; unseen ones are dark silhouettes. Each entry: sprite,
   region, level range, abilities in plain words, attack warnings, immunities, poison, drops, a personality + lore line, defeated count.
   Saved per save file (save key 'best').  HELP: the text from the old town signposts + the attack-warning legend, in one place.
   ===================================================================== */
const BEST={seen:{},kills:{},sel:null,page:0};
// type: [region, abilities (plain words), personality, lore]
const BEST_INFO={
  slime:['Slime Meadow','Hops onto you (purple slam circle) or spits a goo ball (cyan line).','Cheerful, wobbly, always hungry.','Slimes eat the meadow flowers and split the sweetness with no one.'],
  knight:['Old Crypt','Sword slash (red wedge), shield charge down a lane (orange), or raises its guard.','Proud and rattly.','Once a castle guard; still salutes when no one is looking.'],
  goblin:['Castle Road','Aimed arrows and 3-arrow volleys (cyan lines), lobbed bombs (purple circles).','Sneaky, giggles a lot.','Goblin archers practise on scarecrows. The scarecrows remember.'],
  dragon:['Castle Dracoryn','Fire breath cone, tail swipes and fireball rain. Phase 2 flies faster.','Vain and very old.','Emberfang sleeps on a hoard of things it does not understand.'],
  bat:['Old Crypt','Dives at you down a lane (orange) or screeches around itself (purple).','Twitchy and loud.','Crypt bats hang from the ceiling and gossip upside down.'],
  wraith:['Old Crypt','Wails (purple circle), fires soul bolts (cyan) and drains life.','Mournful, sighs a lot.','A wraith is a memory that forgot whose it was.'],
  lich:['Old Crypt (boss)','Soul storms, summoned skeletons and void zones in three phases.','Cold and patient.','The Lich King counts every candle in his crypt, every night.'],
  wolf:['Frostpeak','Lunges down a lane (orange) and bites (red wedge).','Loyal to its pack, nobody else.','Frost wolves howl when the snow is about to fall.'],
  yeti:['Frostpeak','Ground slams (purple) and thrown ice boulders (cyan).','Grumpy, hates noise.','Rime brutes nap for a whole season and wake up hungry.'],
  toad:['Mirewood Swamp','Tongue lash (red wedge) and leaps (purple). Can POISON.','Lazy and smug.','A Bog Toad\'s skin is toxic - never lick one.'],
  witch:['Mirewood Swamp','Brews poison clouds (purple) and hexed bolts (cyan). Can POISON.','Cackling and nosy.','Mire witches trade recipes, never ingredients.'],
  scorpion:['Sunscar Desert','Tail sting (red wedge) and a scuttling charge (orange). Can POISON.','Snappy and territorial.','Dune scorpions glow faintly under the moon.'],
  mummy:['Sunscar Desert','Sand blasts (purple) and grasping wraps (red).','Slow and very, very tired.','Dust mummies still guard tombs no one remembers.'],
  rimegar:['Frostpeak (boss)','Avalanche slams, ice spikes and frost beams in three phases.','Silent as a glacier.','Rimegar was carved from the mountain\'s first winter.'],
  mossback:['Mirewood Swamp (boss)','Venom bites, mire pools and head swipes. Can POISON.','Ancient and grumbling.','Old Mossback has three heads and three opinions.'],
  colossus:['Sunscar Desert (boss)','Crushing slams, sand waves and stone rain.','Heavy, thoughtful.','The Sundered Colossus was built to guard a city that blew away.'],
  boar:['Goldenfield Farms','Charges straight at you (orange lane).','Stubborn.','Field boars dig up turnips purely out of spite.'],
  scarecrow:['Goldenfield Farms','Scythe sweeps (red wedge) and crow swarms (cyan).','Bad-tempered.','Nobody built these scarecrows. They just appeared one autumn.'],
  redcap:['Glowcap Grove','Hops and bonks (purple).','Hot-headed.','Red caps fight over the sunniest log.'],
  shroom:['Glowcap Grove','Sleepy spore puffs (purple) that make you drowsy.','Always yawning.','Dozy caps only wake up to complain.'],
  greencap:['Glowcap Grove','Mossy slams (purple) and rolling (orange).','Gentle unless stepped on.','Mossy caps grow a new cap every spring.'],
  ambercap:['Glowcap Grove','Ember spores (cyan) that sting.','Warm and prickly.','Ember caps keep the grove warm at night.'],
  babyshroom:['Glowcap Grove','Tiny bonks. Comes in crowds.','Curious.','Baby shrooms follow anything that glows.'],
  spore:['Glowcap Grove','Spore clouds (purple) and lunges. Can POISON.','Pompous.','Sir Spore was knighted by nobody in particular.'],
  lantern:['Glowcap Grove','Light flashes (purple) and glowing orbs (cyan).','Shy.','Lanterncaps lead lost travellers home - usually.'],
  chestcap:['Glowcap Grove','Pretends to be a chest, then bites (red wedge).','A prankster.','If a chest yawns, walk away.'],
  ironcap:['Glowcap Grove','Armoured headbutts (orange lane).','Tough and proud.','Ironcaps grow in old mine carts.'],
  spitter:['Glowcap Grove','Spits toxic spores (cyan lines). Can POISON.','Rude.','Spore spitters aim for your boots on purpose.'],
  frostcap:['Glowcap Grove','Frost puffs (purple) that chill.','Aloof.','Frostcaps grow where snow never falls.'],
  shadowcap:['Glowcap Grove','Blinks through shadows and strikes (red).','Mysterious.','Nobody has seen a shadowcap in daylight.'],
  brute:['Glowcap Grove','Huge slams (purple) and charges (orange).','Big and slow to anger.','An Ironcap Brute once carried a whole cottage.'],
  colony:['Glowcap Grove (boss)','Spore storms and summoned caps in three phases. Can POISON.','Many voices.','The Wandering Colony is a whole forest that decided to walk.'],
  mking:['Glowcap Grove (boss)','Royal slams, spore crowns and summoned guards.','Regal and a little silly.','The Mushroom King has never once taken off his crown.'],
  scamp:['Shardstone Caverns','Pretends to be a pebble, then pelts you (cyan). ROCK: immune to poison and burn.','Mischievous.','Pebble scamps steal shiny things and hide them in walls.'],
  shscorp:['Shardstone Caverns','Tail sting (red) and charges (orange). Can POISON. ROCK: immune to poison and burn.','Grumpy.','Shale scorpions moult into thin slate.'],
  sentinel:['Shardstone Caverns','Rune beams (cyan) and slams (purple). ROCK: immune to poison and burn.','Dutiful.','Rune sentinels still follow orders from a king long gone.'],
  maw:['Shardstone Caverns','Chomps (red wedge) and rolls (orange). ROCK: immune to poison and burn.','Always hungry.','A boulder maw once ate a minecart. It is still digesting.'],
  tortoise:['Shardstone Caverns','Crystal spikes (purple) and a slow shell slam. ROCK: immune to poison and burn.','Patient.','Crystal tortoises grow one crystal every hundred years.'],
  fbat:['Shardstone Caverns','Dives down a lane (orange). ROCK: immune to poison and burn.','Jittery.','Flint bats spark when they bump into each other.'],
  bboar:['Shardstone Caverns','Rolling charges (orange lane). ROCK: immune to poison and burn.','Headstrong.','Boulder boars sharpen their tusks on the cavern walls.'],
  geode:['Shardstone Caverns','Pretends to be a geode, then snaps (red). ROCK: immune to poison and burn.','Sly.','Geode mimics are pretty on the inside. Mostly teeth.'],
  crawler:['Shardstone Caverns','Crystal shards (cyan) and scuttling bites. ROCK: immune to poison and burn.','Nervous.','Crystal crawlers hum when they are happy.'],
  mgolem:['Shardstone Caverns','Heavy slams (purple) and thrown rocks (cyan). ROCK: immune to poison and burn.','Calm, mossy.','Mossback golems let birds nest on their shoulders.'],
  cgolem:['Ember Rift','Molten slams (purple) and fire bolts (cyan). ROCK: immune to poison and burn; takes no FIRE damage.','Hot-tempered.','Cinder golems were forged by the rift itself.'],
  warden:['Shardstone Caverns (boss)','Rune storms, stone walls and slams in three phases. ROCK: immune to poison and burn.','Stern.','The Ruin Warden guards the last door of an empty city.'],
};
function bestSeen(t){return !!BEST.seen[t];}
function bestMark(t){if(!t||BEST.seen[t])return;BEST.seen[t]=1;BEST.newT=gtime;}
function updateBestiary(){if(state!=='play'||!P)return;
  for(const e of enemies){if(!e.alive||e.dying||e.disg&&!e.engaged||BEST.seen[e.type])continue;if(Math.hypot(e.x-P.x,e.y-P.y)<260)bestMark(e.type);}
  if(B)for(const e of B.ens)bestMark(e.type);}
{const _k=killEnemy;killEnemy=function(e){if(e&&e.type&&!e.tmp&&!e.dummy){BEST.kills[e.type]=(BEST.kills[e.type]|0)+1;bestMark(e.type);}return _k.apply(this,arguments);};}
const packBest=()=>({s:Object.keys(BEST.seen),k:BEST.kills,tips:Object.keys(TIPS.done)});
function unpackBest(b){BEST.seen={};BEST.kills={};if(!b)return;(b.s||[]).forEach(t=>BEST.seen[t]=1);Object.assign(BEST.kills,b.k||{});TIPS.done={};(b.tips||[]).forEach(k=>TIPS.done[k]=1);}
const BEST_SIL=new Map();
function bestSil(spr){let s=BEST_SIL.get(spr);if(s)return s;s=document.createElement('canvas');s.width=spr.width;s.height=spr.height;const g=s.getContext('2d');g.drawImage(spr,0,0);g.globalCompositeOperation='source-in';g.fillStyle='#3a2a1a';g.fillRect(0,0,s.width,s.height);BEST_SIL.set(spr,s);return s;}
function bestSprite(t){const d=ENEMY[t];const s=d&&SP[d.spr];return Array.isArray(s)?s[0]:s;}
function bestLevels(t){let lo=1e9,hi=0;for(const e of enemies)if(e.type===t&&e.lv){lo=Math.min(lo,e.lv);hi=Math.max(hi,e.lv);}return hi?(lo===hi?'Lv '+lo:'Lv '+lo+'-'+hi):'Lv ?';}
function bestTele(t){const i=(BEST_INFO[t]||[])[1]||'';const ks=[];if(/cyan/.test(i))ks.push('proj');if(/orange/.test(i))ks.push('dash');if(/red/.test(i))ks.push('melee');if(/purple/.test(i))ks.push('aoe');return ks;}
const BEST_ORDER=()=>Object.keys(ENEMY).filter(t=>BEST_INFO[t]);
PM_TABS.splice(PM_TABS.findIndex(t=>t[0]==='world')+1,0,['bestiary','BESTIARY','paw']);
PM_TABS.splice(PM_TABS.findIndex(t=>t[0]==='settings'),0,['help','HELP','excl']);
PM_DRAW.bestiary=function(x,y,w,h){
  const all=BEST_ORDER(),seenN=all.filter(bestSeen).length;pmTitle('BESTIARY',x,y+16);pmText(seenN+' / '+all.length+' seen',x+w,y+16,{size:10,align:'right',col:PMC.ink2});
  const lw=Math.min(250,Math.round(w*.44)),cs=34,cols=Math.max(3,Math.floor(lw/(cs+4))),rows=Math.max(2,Math.floor((h-62)/(cs+4))),per=cols*rows,pages=Math.max(1,Math.ceil(all.length/per));
  BEST.page=Math.min(BEST.page,pages-1);if(!BEST.sel||!BEST_INFO[BEST.sel])BEST.sel=all.find(bestSeen)||all[0];
  all.slice(BEST.page*per,BEST.page*per+per).forEach((t,i)=>{const cx=x+(i%cols)*(cs+4),cy=y+28+Math.floor(i/cols)*(cs+4),r=pmReg(cx,cy,cs,cs,{id:'best:'+t,lab:t,act:()=>{BEST.sel=t;sfx('select');}});
    rr(cx,cy,cs,cs,4);ctx.fillStyle=BEST.sel===t?PMC.green:PMC.edge;ctx.fill();rr(cx+2,cy+2,cs-4,cs-4,3);ctx.fillStyle=bestSeen(t)?'#fbf1da':'#c8b48c';ctx.fill();
    const s=bestSprite(t);if(s){const sc=Math.min((cs-8)/s.width,(cs-8)/s.height);ctx.drawImage(bestSeen(t)?s:bestSil(s),Math.round(cx+cs/2-s.width*sc/2),Math.round(cy+cs/2-s.height*sc/2),s.width*sc,s.height*sc);}
    if(ENEMY[t].boss){ctx.fillStyle='#e8b84a';ctx.fillRect(cx+cs-9,cy+3,6,6);}if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(cx,cy,cs,cs,4);ctx.stroke();}});
  const py=y+28+rows*(cs+4)+2;pmSq(x,py,22,'<',()=>{BEST.page=(BEST.page+pages-1)%pages;},'bpg-');pmText((BEST.page+1)+'/'+pages,x+lw/2,py+15,{size:10,align:'center'});pmSq(x+lw-22,py,22,'>',()=>{BEST.page=(BEST.page+1)%pages;},'bpg+');
  // detail card
  const t=BEST.sel,d=ENEMY[t],I=BEST_INFO[t],dx=x+lw+12,dw=w-lw-12,dh=h-30;pmParch(dx,y+26,dw,dh,6);pmCorners(dx+2,y+28,dw-4,dh-4,5);
  if(!bestSeen(t)){const s=bestSprite(t);if(s){const sc=Math.min(4,70/s.height);ctx.drawImage(bestSil(s),dx+dw/2-s.width*sc/2,y+44,s.width*sc,s.height*sc);}pmText('???',dx+dw/2,y+140,{size:16,align:'center'});pmText('Not seen yet. Explore '+I[0]+'.',dx+dw/2,y+160,{size:9,align:'center',col:PMC.ink2});return;}
  const s=bestSprite(t);if(s){const sc=Math.min(3,56/s.height);ctx.drawImage(s,dx+12,y+36,s.width*sc,s.height*sc);}
  const tx=dx+84,fnt='bold '+scaleText(7)+'px "Courier New",monospace';
  pmText(d.name.toUpperCase(),tx,y+48,{size:pmFit(d.name.toUpperCase(),dw-96,12,7)});pmText(I[0]+'  -  '+bestLevels(t)+(d.boss?'  -  BOSS':''),tx,y+62,{size:8,col:PMC.ink2});
  pmText('Defeated: '+(BEST.kills[t]|0),tx,y+76,{size:9,col:PMC.green});
  let yy=y+94;const line=(lab,s,col,mx)=>{if(yy>y+26+dh-8)return;pmText(lab,dx+12,yy,{size:7,col:col||PMC.ink});const ls=wrapText(s,dw-84,fnt).slice(0,mx||2);ls.forEach((l,i)=>{pmText(l,dx+66,yy+i*9,{size:7,col:PMC.ink2});});yy+=ls.length*9+3;};
  line('MOVES',I[1],null,3);
  const tk=bestTele(t);if(tk.length){pmText('WARNS',dx+12,yy,{size:7});tk.forEach((k,i)=>{teleIcon(k,dx+72+i*18,yy-3,.7);});yy+=13;}
  const im=[];if(ROCK_TYPES.has(t))im.push('poison','burn');if(FIRE_IMMUNE.has(t))im.push('fire damage');if(d.freezeImmune)im.push('freeze (gets slowed instead)');line('IMMUNE',im.length?im.join(', '):'nothing');
  const pz=POISONERS[t];line('POISON',pz?Math.round(pz.ch*100)+'% per hit, '+pz.dur+'s (cure: Heal card, Inn, bed)':'no');
  line('DROPS','Gold '+(d.gold?d.gold[0]+'-'+d.gold[1]:'?')+', '+(d.xp|0)+' XP'+(d.boss?', boss chest + rare gear':', sometimes gear'));
  line('LORE',I[2]+' '+I[3],null,3);
};
const HELP_SECT=[
 ['Controls','Move: WASD / arrows or the left stick.  Shoot: J or SHOT.  Talk / use: E or tap.  Run: hold RUN.  Pause: P or II.  In fights: K cast a card, L next card, X discard, hold J to charge a shot.'],
 ['Town & shops','Brum\'s Smithy (anvil sign): cards and shot upgrades, morning to dusk.  The Inn (mug sign): rest to heal, cure poison and skip to morning - it saves.  Wren\'s Bakery (bread sign).  The Pet Pen (paw sign): adopt a pet.  The Chapel (cross): the priest heals and blesses.  Fisher Tobin (fish sign) buys your fish.  Monsters never follow you into town.'],
 ['Waystones','Touch a waystone to wake it. Then travel between woken waystones from WORLD > TRAVEL or by tapping a waystone.'],
 ['Dungeon gates','A gate leads into a dungeon. Monsters you defeat inside stay down until you leave. The boss waits at the far end; the exit rune is at the start.'],
 ['Attack warnings','Every enemy shows what it is about to do, with a colour, a shape and an icon above it:'],
 ['Poison & immunity','Swamp, desert, cavern and grove poisoners can poison you: green screen edges and a timer. It never kills. Cure: HEAL card, the Inn, your bed.  Rock, stone and crystal creatures are immune to poison and burn (IMMUNE pops up). Cinder Golems take no fire damage.'],
 ['World editor','Menu > EDITOR: move houses, paint ground, place walls, trees, chests and monsters. UNDO / REDO at the top. COPY stamps whole areas. EXPORT gives the JSON.'],
];
const HELP={i:0};
PM_DRAW.help=function(x,y,w,h){
  pmTitle('HELP & GUIDE',x,y+16);const lw=Math.min(170,Math.round(w*.3));
  HELP_SECT.forEach(([n],i)=>{const yy=y+28+i*30;const r=pmReg(x,yy,lw,26,{id:'help:'+i,lab:n,act:()=>{HELP.i=i;sfx('select');}});const on=HELP.i===i;
    rr(x,yy,lw,26,4);ctx.fillStyle=on?PMC.greenD:PMC.edge;ctx.fill();rr(x+2,yy+2,lw-4,22,3);ctx.fillStyle=on?PMC.green:'#f8ead0';ctx.fill();
    pmText(n,x+10,yy+17,{size:pmFit(n,lw-16,10,7),col:on?'#fff8e0':PMC.ink,lw:on?2:0,out:on?'#163a12':false});if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(x,yy,lw,26,4);ctx.stroke();}});
  const dx=x+lw+12,dw=w-lw-12,dh=h-30;pmParch(dx,y+26,dw,dh,6);pmCorners(dx+2,y+28,dw-4,dh-4,5);
  const [n,body]=HELP_SECT[HELP.i]||HELP_SECT[0];pmText(n.toUpperCase(),dx+14,y+50,{size:13});
  const fnt='bold '+scaleText(9)+'px "Courier New",monospace',ls=wrapText(body,dw-28,fnt);ls.forEach((l,i)=>pmText(l,dx+14,y+70+i*13,{size:9,col:PMC.ink2}));
  if(n==='Attack warnings'){let yy=y+70+ls.length*13+8;for(const k of ['proj','dash','melee','aoe']){teleIcon(k,dx+24,yy,1.1);pmText(TELE[k].n.toUpperCase(),dx+42,yy+4,{size:9,col:TELE[k].col==='#ffffff'?PMC.ink:PMC.ink});
      wrapText(TELE[k].desc,dw-60,fnt).slice(0,2).forEach((l,i)=>pmText(l,dx+42,yy+16+i*11,{size:8,col:PMC.ink2}));yy+=33;}}
};
/* first-time tips: walking near a waystone / dungeon gate the first time shows the old signpost text once */
const TIPS={done:{}};
function updateTips(){if(state!=='play'||B||DLG)return;
  const tip=(id,msg)=>{if(TIPS.done[id])return;TIPS.done[id]=1;toast(msg,4.5,'#ffe9a0');};
  for(const w of WAYSTONES){if(w.tx==null)continue;if(Math.hypot((w.tx+.5)*TS-P.x,(w.ty+.5)*TS-P.y)<90){tip('way','TIP: touch a waystone to wake it - then travel between woken ones from WORLD > TRAVEL (more in HELP).');break;}}
  for(const k in GATES){const [x,y]=k.split(',').map(Number);if(Math.hypot((x+.5)*TS-P.x,(y+.5)*TS-P.y)<90){tip('gate','TIP: a dungeon gate. Defeated monsters inside stay down until you leave; the boss waits at the far end (more in HELP).');break;}}
}
