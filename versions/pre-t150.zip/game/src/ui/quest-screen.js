/* QUEST LOG (t148u): OSRS-style list with MAIN QUESTS and SIDE QUESTS sections.
   Colours: not started = red, in progress = yellow, done = green. Tap a quest for a short
   description + story blurb; TRACK pins it to the HUD. */
function openQuests(){openUIMode('quests');QUESTR.sel=null;}
const QUESTR={sel:null};
function qStatusKind(id){
  const s=questStatus(id);
  if(s==='done')return 'done';
  if(s==='active'||s==='ready')return 'prog';
  return 'new';   // avail / locked
}
function qCol(kind){return kind==='done'?'#5dcf6a':kind==='prog'?'#ffe14d':'#e8504a';}
function qLabel(kind,s){return kind==='done'?'Completed':s==='ready'?'Ready to hand in':kind==='prog'?'In progress':'Not started';}
function questStory(q){
  if(q.story)return q.story;
  if(q.offer&&q.offer.length)return q.offer[0];
  if(q.prog&&q.prog.length)return q.prog[0];
  return 'Speak with '+q.giver+' to learn more.';
}
function questDetail(q){
  const st=questStatus(q.id),kind=qStatusKind(q.id),col=qCol(kind);
  return {h:170,sel:false,draw(x0,y,W,hh){
    panel(x0,y,W,hh,{fill:'#1c120c'});
    txt(q.name,x0+12,y+18,{size:13,col:'#fff3d0',lw:3,out:'#1c0e06'});
    txt(qLabel(kind,st),x0+W-12,y+18,{size:10,align:'right',col,lw:2});
    txt('Giver: '+q.giver,x0+12,y+34,{size:9,col:'#e8d4a8',lw:2});
    const lines=wrapText(questStory(q),W-24,'bold '+scaleText(10)+'px "Courier New",monospace').slice(0,3);
    lines.forEach((l,i)=>txt(l,x0+12,y+52+i*14,{size:10,col:'#cfd0ff',bold:false,out:false}));
    const goal=typeof questGoalText==='function'?questGoalText(q):(q.obj&&q.obj.k)||'';
    txt('Objective: '+goal,x0+12,y+100,{size:9,col:'#ffe9a0',lw:2});
    if(st==='active'||st==='ready'){
      const prog=questProgress(q),need=questNeed(q),bw=W-24;
      ctx.fillStyle='#140c08';ctx.fillRect(x0+12,y+110,bw,8);ctx.fillStyle=col;ctx.fillRect(x0+12,y+110,Math.round(bw*prog/Math.max(1,need)),8);
      txt(prog+'/'+need,x0+W-12,y+117,{size:8,align:'right',col:'#fff',lw:2});
    }
    txt('Reward: '+questRewardText(q.reward),x0+12,y+136,{size:9,col:'#ffd23f',lw:2});
    const id='q:'+q.id,on=TRK.id===id;
    uiButton(x0+W-150,y+hh-28,64,22,on?'TRACKING':'TRACK',!on,()=>{if(!on){trackQuest(id);uiMsg('Tracking on your HUD',false);}},{tag:'track:'+id,clip:true,size:8});
    uiButton(x0+W-78,y+hh-28,66,22,'CLOSE',true,()=>{QUESTR.sel=null;},{tag:'qclose',clip:true,size:8});
  }};
}
function questListRow(q){
  const st=questStatus(q.id),kind=qStatusKind(q.id),col=qCol(kind),main=typeof isMainQuest==='function'&&isMainQuest(q);
  return {h:28,sel:true,act:()=>{QUESTR.sel=q.id;},tap:()=>{QUESTR.sel=q.id;},draw(x0,y,W,hh,isSel){
    ctx.fillStyle=isSel||QUESTR.sel===q.id?'#2a1a10':'#171008';ctx.fillRect(x0,y,W,hh);
    ctx.fillStyle=col;ctx.fillRect(x0,y,4,hh);
    // OSRS-ish bullet
    ctx.fillStyle=col;ctx.beginPath();ctx.arc(x0+14,y+hh/2,4,0,6.283);ctx.fill();
    txt(q.name,x0+24,y+18,{size:11,col:kind==='done'?'#8a9a7a':'#fff3d0',lw:2});
    txt(qLabel(kind,st),x0+W-10,y+18,{size:9,align:'right',col,lw:2});
  }};
}
UI_MODES.quests={title:()=>'QUEST LIST',sub:()=>{
  const done=QUESTS.filter(q=>questStatus(q.id)==='done').length;
  return [done+' / '+QUESTS.length+' completed   (tap a quest for its story)','#e8d4a8'];
},rows(){
  const r=[];
  if(QUESTR.sel){const q=QUESTS.find(q=>q.id===QUESTR.sel);if(q){r.push(questDetail(q));return r;}}
  const main=QUESTS.filter(q=>typeof isMainQuest==='function'&&isMainQuest(q));
  const side=QUESTS.filter(q=>!(typeof isMainQuest==='function'&&isMainQuest(q)));
  const order=arr=>{const a=arr.slice();a.sort((x,y)=>{const kx=qStatusKind(x.id),ky=qStatusKind(y.id),o={prog:0,new:1,done:2};return (o[kx]-o[ky])||x.name.localeCompare(y.name);});return a;};
  r.push({t:'head',s:'MAIN QUESTS'});
  order(main).forEach(q=>r.push(questListRow(q)));
  if(!main.length)r.push({t:'head',s:'  (none yet)'});
  r.push({t:'head',s:'SIDE QUESTS'});
  order(side).forEach(q=>r.push(questListRow(q)));
  // story chapter + dailies as trackable extras under side
  const ex=typeof trkEntries==='function'?trkEntries().filter(e=>e.kind==='story'||e.kind==='daily'):[];
  if(ex.length){r.push({t:'head',s:'STORY & DAILY'});ex.forEach(e=>{
    const col=e.kind==='story'?'#c9a3ff':'#ffd23f';
    r.push({h:28,sel:true,act:()=>{trackQuest(e.id);uiMsg('Tracking '+e.name,false);},tap:()=>{trackQuest(e.id);uiMsg('Tracking '+e.name,false);},draw(x0,y,W,hh,isSel){
      ctx.fillStyle=isSel?'#2a1a10':'#171008';ctx.fillRect(x0,y,W,hh);ctx.fillStyle=col;ctx.fillRect(x0,y,4,hh);
      ctx.beginPath();ctx.arc(x0+14,y+hh/2,4,0,6.283);ctx.fillStyle=col;ctx.fill();
      txt(e.name,x0+24,y+18,{size:11,col:'#fff3d0',lw:2});
      txt(e.ready?'Ready':'In progress',x0+W-10,y+18,{size:9,align:'right',col:e.ready?'#5dcf6a':'#ffe14d',lw:2});
    }});
  });}
  return r;
}};
