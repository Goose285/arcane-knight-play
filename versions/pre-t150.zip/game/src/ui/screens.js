
/* =====================================================================
   DECK + BLACKSMITH SCREENS (touch + keyboard). One scrollable list UI shared by both.
   ===================================================================== */
const UI={mode:null,scroll:0,sel:0,rects:[],from:'play',msg:'',msgT:0,top:0,bot:0,total:0,offs:[]};
function uiMsg(s,bad=true){UI.msg=s;UI.msgT=2.2;UI.bad=bad;}
function openDeck(){openUIMode('deck');}
function openShop(){ensureShop();openUIMode('shop','play');}
const UI_STATES=['deck','shop','gear','quests','skills','craft','travel'];
const isUI=()=>UI_STATES.includes(state);
function openUIMode(m,from){UI.mode=m;UI.scroll=0;UI.sel=0;UI.from=from||state;state=m;releaseAllTouch();sfx('select');}
function closeUI(){
  if(UI.mode==='deck'&&DECK.length<DECK_MIN){uiMsg(`Deck needs at least ${DECK_MIN} cards`);sfx('clang');return;}
  if(UI.mode==='deck'&&B)B.pile=null;                 // new deck applies from the next deal
  state=UI.mode==='shop'?'play':UI.from;UI.mode=null;if(UI.from!=='title')saveGame('menu');sfx('select');
}
// each UI mode: title(), sub() -> [text,color], rows() -> row list. Rows are {t:'head'|'card'|'combo'|'shot'|'buy'} or custom {h,sel,draw(x0,y,W,h,isSel,si),act(which)}
const UI_MODES={
  deck:{title:()=>'DECK',sub:()=>[`${DECK.length}/${DECK_MAX} cards   (min ${DECK_MIN})`,DECK.length<DECK_MIN?'#ff8a8a':'#cfd0ff'],rows(){
    const r=[];r.push({t:'head',s:'YOUR CARDS   (+ / - to edit the deck)'});
    CARDS.filter(c=>COL[c.id]>0).sort((a,b)=>RAR_ORDER.indexOf(a.rar)-RAR_ORDER.indexOf(b.rar)||a.name.localeCompare(b.name)).forEach(c=>r.push({t:'card',id:c.id}));
    r.push({t:'head',s:'COMBOS  (cast a pair within 1.5s)'});COMBOS.forEach(c=>r.push({t:'combo',c}));return r;}},
  shop:{title:()=>'BLACKSMITH BRUM',sub:()=>[`Your gold: ${P.gold} G`,'#ffd23f'],rows(){
    const r=[];r.push({t:'head',s:'FORGE'});r.push({t:'shot'});
    r.push({t:'head',s:'SPELL CARDS FOR SALE'});SHOP.stock.forEach(id=>r.push({t:'buy',id}));
    r.push({t:'head',s:`New stock after ${Math.max(0,5-(kills-SHOP.kills))} more kills`});
    r.push({t:'head',s:'LIGHTS  (widen your glow at night / in the crypt)'});LIGHTS.forEach(l=>r.push(lightRow(l)));
    r.push({t:'head',s:'FISHING RODS  (tap rippling water to fish)'});RODS.forEach((_,i)=>r.push(rodRow(i)));return r;}},
};
function uiRows(){return UI_MODES[UI.mode].rows();}
const rowH=r=>r.h||(r.t==='head'?24:r.t==='combo'?38:52);
const uiSelRows=rows=>rows.filter(r=>r.sel||r.t==='card'||r.t==='buy'||r.t==='shot');
function deckAdd(id){
  if(DECK.length>=DECK_MAX){uiMsg(`Deck is full (${DECK_MAX})`);sfx('clang');return;}
  const lim=deckLimit(id);if(deckCount(id)>=lim){uiMsg((COL[id]||0)<RAR[CARD[id].rar].max?`You only own ${COL[id]} of those`:`Deck limit: ${lim} per ${RAR[CARD[id].rar].n.toLowerCase()} card`);sfx('clang');return;}
  DECK.push(id);sfx('select');
}
function deckRemove(id){
  if(deckCount(id)<=0)return;
  if(DECK.length<=DECK_MIN){uiMsg(`Deck needs at least ${DECK_MIN} cards`);sfx('clang');return;}
  DECK.splice(DECK.lastIndexOf(id),1);sfx('select');
}
const shotCost=()=>60+50*P.up;
function buyShot(){const c=shotCost();if(P.gold<c){uiMsg('Not enough gold');sfx('clang');return;}P.gold-=c;P.up++;sfx('level');uiMsg('Arcane Shot reforged! (+2 dmg, stronger cards)',false);saveGame('shop');}
function buyCard(id){
  const c=CARD[id],pr=RAR[c.rar].price;
  if(SHOP.sold[id]){uiMsg('Sold out');sfx('clang');return;}
  if(P.gold<pr){uiMsg('Not enough gold');sfx('clang');return;}
  if((COL[id]||0)>=RAR[c.rar].own){uiMsg('You own the maximum');sfx('clang');return;}
  P.gold-=pr;COL[id]=(COL[id]||0)+1;SHOP.sold[id]=true;
  const room=DECK.length<DECK_MAX&&deckCount(id)<deckLimit(id);if(room)DECK.push(id);
  sfx('coin');uiMsg(`Bought ${c.name}${room?' (added to deck)':''}`,false);saveGame('shop');
}
function uiAct(r,which){          // which: 'main' | 'minus'
  if(r.act){r.act(which);return;}
  if(r.t==='card'){which==='minus'?deckRemove(r.id):deckAdd(r.id);}
  else if(r.t==='buy')buyCard(r.id);
  else if(r.t==='shot')buyShot();
}
function uiTap(p){
  for(let i=UI.rects.length-1;i>=0;i--){const q=UI.rects[i];
    if(inRect(p,q)&&(!q.clip||(p.y>=UI.top&&p.y<=UI.bot))){
      if(q.sel!=null)UI.sel=q.sel;
      q.act();return true;}}
  return false;
}
function uiScrollBy(d){UI.scroll=clamp(UI.scroll+d,0,Math.max(0,UI.total-(UI.bot-UI.top)));}
function updateUI(dt){
  UI.msgT=Math.max(0,UI.msgT-dt);
  const rows=uiRows(),sels=uiSelRows(rows);
  if(hit('Escape','KeyP','Backspace')){closeUI();return;}
  UI.sel=clamp(UI.sel,0,Math.max(0,sels.length-1));
  const mv=hit('ArrowDown','KeyS')?1:hit('ArrowUp','KeyW')?-1:0;
  if(mv){UI.sel=clamp(UI.sel+mv,0,sels.length-1);sfx('select');
    const o=UI.offs.find(q=>q.r===sels[UI.sel]);if(o){const vh=UI.bot-UI.top;if(o.y<UI.scroll)UI.scroll=o.y-24;else if(o.y+o.h>UI.scroll+vh)UI.scroll=o.y+o.h-vh+4;}}
  const cur=sels[UI.sel];
  if(cur){if(hit('ArrowRight','KeyD','Enter','Space'))uiAct(cur,'main');if(hit('ArrowLeft','KeyA'))uiAct(cur,'minus');}
  uiScrollBy(0);
}
function uiButton(x,y,w,h,label,on,act,o={}){
  ctx.fillStyle=on?(o.bg||'#2d6a4f'):'#2a2740';ctx.fillRect(x,y,w,h);
  ctx.strokeStyle=on?(o.bd||'#7dffa0'):'#4a4470';ctx.lineWidth=2;ctx.strokeRect(x+1,y+1,w-2,h-2);
  txt(label,x+w/2,y+h/2+(o.size||16)*.35,{size:o.size||16,align:'center',col:on?'#fff':'#777',lw:2});
  UI.rects.push({x,y,w,h,act,clip:!!o.clip,sel:o.sel,tag:o.tag});
}
function drawUI(){
  const deck=UI.mode==='deck',MD=UI_MODES[UI.mode];
  {const bg=ctx.createLinearGradient(0,0,0,VH);bg.addColorStop(0,'#1a1008');bg.addColorStop(1,'#0c0806');ctx.fillStyle=bg;ctx.fillRect(0,0,VW,VH);}   // t143u: warm backdrop
  const split=!!MD.split&&VW>=VH*1.4;   // landscape: a map column + a list column (World Map)
  let W=Math.min(VW-SL-SR-14,split?820:520),x0=Math.round((VW-W)/2);const top=ST+(split?50:60),bot=VH-SB-(split?56:68);
  UI.top=top;UI.bot=bot;UI.rects=[];UI.offs=[];
  {const fx=Math.max(SL+2,x0-10),fw=Math.min(VW-SR-2,x0+W+10)-fx;panel(fx,top-8,fw,bot-top+16,{fill:'#140e16'});   // t143u: leather frame around the list
   ctx.font='bold '+scaleText(20)+'px "Courier New",monospace';const tw=Math.min(VW-40,ctx.measureText(MD.title()).width+56),tx=Math.round(VW/2-tw/2);
   ctx.fillStyle='#1e1008';ctx.fillRect(tx-6,ST+10,tw+12,24);ctx.fillStyle='#7a2a1a';ctx.fillRect(tx-4,ST+12,tw+8,20);   // banner tails
   panel(tx,ST+4,tw,34,{border:'#f0cf7a',fill:'#4a2c18'});}
  txt(MD.title(),VW/2,ST+28,{size:20,align:'center',col:'#ffe14d',lw:5,out:'#1e1008'});
  {const sb=MD.sub();txt(sb[0],VW/2,ST+51,{size:11,align:'center',col:sb[1],lw:3,out:'#1e1008'});}
  const rows0=uiRows(),sels=uiSelRows(rows0);let yy=0;
  const rows=split?rows0.slice(1):rows0;
  if(split){const lw=MD.splitW(bot-top,W);rows0[0].draw(x0,top,lw,bot-top);x0+=lw+8;W-=lw+8;}   // the map row is fixed on the left, the rest scrolls on the right
  rows.forEach(r=>{const h=rowH(r);UI.offs.push({r,y:yy,h});yy+=h+(r.t==='head'?0:4);});UI.total=yy+4;
  uiScrollBy(0);
  ctx.save();ctx.beginPath();ctx.rect(split?x0-2:0,top,VW,bot-top);ctx.clip();
  for(const o of UI.offs){
    const r=o.r,y=top+o.y-UI.scroll,h=o.h;if(y+h<top-2||y>bot+2)continue;
    const si=sels.indexOf(r),isSel=si===UI.sel&&si>=0;
    if(r.t==='head'){txt(r.s,x0+4,y+16,{size:10,col:'#9aa0ff',lw:2});continue;}
    if(r.draw){if(r.sel)UI.rects.push({x:x0,y,w:W,h,act:()=>{},clip:true,sel:si});   // tapping a row only highlights it; the right-hand button does the action
    r.draw(x0,y,W,h,isSel,si);continue;}
    if(r.t==='combo'){
      ctx.fillStyle='#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=r.c.col;ctx.fillRect(x0,y,3,h);
      const A=CARD[r.c.a],B2=CARD[r.c.b];
      draw(SP.ic[A.id],x0+8,y+7,1.5);txt('+',x0+34,y+23,{size:12,col:'#fff'});draw(SP.ic[B2.id],x0+44,y+7,1.5);
      txt('= '+r.c.name,x0+74,y+15,{size:10,col:r.c.col,lw:2});txt(r.c.desc,x0+74,y+29,{size:8,col:'#b9b4d8',bold:false});
      continue;
    }
    const c=r.t==='shot'?null:CARD[r.id],rc=c?RAR[c.rar]:null;
    ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);
    ctx.fillStyle=rc?rc.col:'#ffd23f';ctx.fillRect(x0,y,3,h);
    if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
    UI.rects.push({x:x0,y,w:W,h,act:()=>{},clip:true,sel:si});
    if(r.t==='shot'){
      draw(SP.ic.sword,x0+8,y+10,2);
      txt('REFORGE ARCANE SHOT',x0+48,y+20,{size:10,col:'#fff',lw:2});txt(`+2 shot dmg & stronger cards  (now +${P.up})`,x0+48,y+34,{size:8,col:'#b9b4d8',bold:false});
      const ok=P.gold>=shotCost();uiButton(x0+W-96,y+10,88,32,shotCost()+' G',ok,buyShot,{tag:'shot',clip:true,size:13,sel:si});
      continue;
    }
    ctx.fillStyle=c.col;ctx.fillRect(x0+7,y+9,34,34);ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(x0+7,y+9,34,8);
    draw(SP.ic[c.id],x0+8,y+10,2);
    txt(c.name,x0+48,y+17,{size:10,col:'#fff',lw:2});
    txt(`${rc.n}${c.pow?'  PWR '+Math.round(c.pow*cardMult()*schoolMult(c.id)*upgMult(c.id)):''}`,x0+48,y+29,{size:8,col:rc.col,lw:2});
    txt(c.desc,x0+48,y+42,{size:8,col:'#b9b4d8',bold:false});
    if(r.t==='card'){
      const n=deckCount(r.id),lim=deckLimit(r.id),bx=x0+W-100;
      uiButton(bx,y+11,30,30,'-',n>0&&DECK.length>DECK_MIN,()=>deckRemove(r.id),{tag:'minus:'+r.id,clip:true,size:20,bg:'#7a2e3a',bd:'#ff9aa8',sel:si});
      txt(String(n),bx+47,y+27,{size:14,align:'center',col:'#fff',lw:3});txt(`own ${COL[r.id]}  max ${lim}`,bx+47,y+49,{size:7,align:'center',col:'#9aa0ff',bold:false});
      uiButton(bx+64,y+11,30,30,'+',n<lim&&DECK.length<DECK_MAX,()=>deckAdd(r.id),{tag:'plus:'+r.id,clip:true,size:20,sel:si});
    } else {
      const pr=rc.price,sold=SHOP.sold[r.id],ok=!sold&&P.gold>=pr;
      uiButton(x0+W-96,y+10,88,32,sold?'SOLD':pr+' G',ok,()=>buyCard(r.id),{tag:'buy:'+r.id,clip:true,size:13,sel:si});
      txt(`own ${COL[r.id]||0}`,x0+W-52,y+50,{size:7,align:'center',col:'#9aa0ff',bold:false});
    }
  }
  ctx.restore();
  // scrollbar
  const vh=bot-top;if(UI.total>vh){const bh=Math.max(24,vh*vh/UI.total),by=top+(vh-bh)*UI.scroll/(UI.total-vh);ctx.fillStyle='rgba(255,255,255,.25)';ctx.fillRect(Math.min(VW-SR-5,x0+W+3),by,3,bh);}
  // footer
  const ok=!deck||DECK.length>=DECK_MIN;
  uiButton(Math.round(VW/2-75),VH-SB-48,150,38,'DONE',ok,closeUI,{tag:'done',size:16});
  if(UI.msgT>0)txt(UI.msg,VW/2,VH-SB-58,{size:11,align:'center',col:UI.bad?'#ff9a9a':'#9affb0',alpha:Math.min(1,UI.msgT*2),lw:3});
  if(!TOUCH)txt('Up/Down select   Left/Right or A/D  - / +   Esc done',VW/2,VH-SB-4,{size:8,align:'center',col:'#8a86b8',bold:false});
}
cv.addEventListener('wheel',e=>{if(isUI()){e.preventDefault();uiScrollBy(e.deltaY);}},{passive:false});
