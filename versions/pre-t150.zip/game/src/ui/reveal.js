/* =====================================================================
   REVEAL: getting something new is an event. NEW CARD / NEW ITEM / LEVEL UP / TREASURE each get a short showcase over the world:
   a white flash, rotating light rays, a sparkle burst, a fanfare and the thing itself, big, with its name and what it does.
   Queued; shown outside fights and dialogue; tap / any key (or 3.4s) moves on.
   ===================================================================== */
const REV={q:[],cur:null,t:0,parts:[],lastLv:0,seen:0};
const REV_TITLES={card:'NEW CARD!',item:'NEW ITEM!',level:'LEVEL UP!',chest:'TREASURE!'};
function revealPush(o){if(window.__NOREVEAL)return;REV.q.push(o);REV.seen++;}
function revealCard(id){const c=CARD[id];if(c)revealPush({k:'card',id,name:c.name,col:RAR[c.rar].col,sub:RAR[c.rar].n+' card',info:typeof cardInfo==='function'?cardInfo(id):c.desc});}
function revealItem(it){if(!it||!GEAR_RAR[it.rar])return;revealPush({k:'item',it,name:it.name,col:GEAR_RAR[it.rar].col,sub:GEAR_RAR[it.rar].n+' '+(GEAR_SLOT_NAME[it.slot]||'').toLowerCase()+'  Lv'+it.lv});}
function revealLevel(lv,from){   // t139u: ONE screen per level-up event; several levels at once = one combined screen; never repeats a level
  from=from||lv-1;if(lv<=from)return;REV.shownLv=Math.max(REV.shownLv||0,lv);
  const n=lv-from,old=REV.q.find(q=>q.k==='level');
  if(old){old.from=Math.min(old.from,from+1);old.lv=lv;}else{revealPush({k:'level',lv,from:from+1});}
  const o=old||REV.q[REV.q.length-1];if(!o||o.k!=='level')return;const m=o.lv-o.from+1;
  Object.assign(o,{name:m>1?'LEVEL '+o.from+' - '+o.lv:'LEVEL '+o.lv,col:'#7dffa0',sub:m>1?m+' levels!  HP restored  -  +'+m+' skill points':'HP restored  -  +1 skill point',info:'Max HP '+maxHp()+'.  Spend skill points in the menu (SKILLS).'});}
function revealChest(tier,lines){revealPush({k:'chest',tier,name:['Wooden Chest','Iron Chest','Golden Chest','Hidden Chest'][tier]||'Chest',col:'#ffd23f',sub:lines.slice(0,4).join('  -  ')});}
const revealBusy=()=>!!REV.cur;
function updateReveal(dt){
  for(const p of REV.parts){p.t+=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=60*dt;}REV.parts=REV.parts.filter(p=>p.t<p.life);
  if(state==='title'){REV.q.length=0;REV.cur=null;REV.lastLv=0;return;}
  if(state==='play'){if(!REV.lastLv||P.lvSeen==null){REV.lastLv=Math.max(P.lv,P.lvSeen|0);P.lvSeen=REV.lastLv;}   // a loaded save never replays its old level-ups
    if(P.lv>REV.lastLv&&P.lv>(P.lvSeen|0)){revealLevel(P.lv,Math.max(REV.lastLv,P.lvSeen|0));P.lvSeen=P.lv;}REV.lastLv=Math.max(REV.lastLv,P.lv);}
  if(REV.cur){REV.t+=dt;if(REV.t>3.4)REV.cur=null;else if(REV.t>.5&&hit('Enter','Space','KeyJ','KeyE','Escape'))REV.cur=null;return;}
  if(!REV.q.length||state!=='play'||B||DLG||(typeof introHold==='function'&&introHold()))return;
  REV.cur=REV.q.shift();REV.t=0;sfx(REV.cur.k==='level'?'level':REV.cur.k==='chest'?'coin':'questdone');setTimeout(()=>sfx('select'),180);
  for(let i=0;i<24;i++){const a=Math.random()*6.283,s=R(60,260);REV.parts.push({x:VW/2,y:VH*.3,vx:Math.cos(a)*s*.6,vy:Math.sin(a)*s*.6-30,t:0,life:R(.6,1.2),col:i%3?'#ffe9a0':'#fff8e0',sz:R(1,3)|0});}
}
function revealTap(){if(REV.cur&&REV.t>.35){REV.cur=null;return true;}return !!REV.cur;}
function drawReveal(){   // t139u: cozy parchment + dark-wood card (matches the pause menu), soft gold glow, rarity tile, bounce-in
  for(const p of REV.parts){ctx.globalAlpha=Math.max(0,1-p.t/p.life);ctx.fillStyle=p.col;ctx.fillRect(Math.round(p.x),Math.round(p.y),p.sz,p.sz);}ctx.globalAlpha=1;
  const r=REV.cur;if(!r)return;
  const t=REV.t,cx=VW/2,cy=VH*.46,inA=Math.min(1,t/.25),outA=t>3?Math.max(0,1-(t-3)/.4):1,a=inA*outA;
  ctx.fillStyle=`rgba(20,12,6,${.5*a})`;ctx.fillRect(0,0,VW,VH);
  // soft warm glow + a few gentle gold rays
  ctx.save();ctx.globalAlpha=a;const gl=ctx.createRadialGradient(cx,cy,10,cx,cy,Math.min(VW,VH)*.6);gl.addColorStop(0,'rgba(255,214,120,.35)');gl.addColorStop(1,'rgba(255,214,120,0)');ctx.fillStyle=gl;ctx.fillRect(0,0,VW,VH);
  ctx.translate(cx,cy);ctx.rotate(t*.15);for(let i=0;i<8;i++){ctx.rotate(Math.PI/4);const gr=ctx.createLinearGradient(0,0,0,-VH*.55);gr.addColorStop(0,'rgba(255,224,140,.16)');gr.addColorStop(1,'rgba(255,224,140,0)');ctx.fillStyle=gr;ctx.beginPath();ctx.moveTo(-6,0);ctx.lineTo(-30,-VH*.55);ctx.lineTo(30,-VH*.55);ctx.lineTo(6,0);ctx.fill();}ctx.restore();
  // bounce-in scale (overshoot then settle)
  const k=Math.min(1,t/.45),sc=(k<1?1-Math.pow(1-k,3)*Math.cos(k*7):1)*(t>3?1-.05*(t-3):1);
  const W=Math.min(VW*.46,230),H=Math.min(VH*.62,176);
  ctx.save();ctx.translate(cx,cy);ctx.scale(sc,sc);ctx.globalAlpha=a;
  const x0=-W/2,y0=-H/2;
  ctx.fillStyle='rgba(0,0,0,.35)';ctx.fillRect(x0+4,y0+6,W,H);
  ctx.fillStyle='#1e1008';ctx.fillRect(x0-4,y0-4,W+8,H+8);ctx.fillStyle='#c8963c';ctx.fillRect(x0-2,y0-2,W+4,H+4);   // t143u: heavier outline + brass rim
  ctx.fillStyle='#6b4423';ctx.fillRect(x0,y0,W,H);ctx.fillStyle='#8a5a32';ctx.fillRect(x0,y0,W,3);ctx.fillStyle='#4a2c18';ctx.fillRect(x0,y0+H-3,W,3);
  ctx.fillStyle='#3a2414';ctx.fillRect(x0+6,y0+6,W-12,H-12);
  {const pg=ctx.createLinearGradient(0,y0+7,0,y0+H-7);pg.addColorStop(0,'#fbf0d2');pg.addColorStop(1,'#ead7aa');ctx.fillStyle=pg;}ctx.fillRect(x0+7,y0+7,W-14,H-14);
  ctx.fillStyle='rgba(120,80,30,.18)';ctx.fillRect(x0+7,y0+7,W-14,3);ctx.fillRect(x0+7,y0+7,3,H-14);ctx.fillStyle='#d8c08a';ctx.fillRect(x0+7,y0+H-12,W-14,5);
  ctx.strokeStyle='rgba(140,96,40,.55)';ctx.lineWidth=1;ctx.strokeRect(x0+12.5,y0+16.5,W-25,H-29);
  for(const [qx,qy] of [[x0+3,y0+3],[x0+W-9,y0+3],[x0+3,y0+H-9],[x0+W-9,y0+H-9]]){ctx.fillStyle='#e0b43a';ctx.fillRect(qx,qy,6,6);ctx.fillStyle='#fbe08a';ctx.fillRect(qx+1,qy+1,2,2);}
  // title ribbon
  const tw=Math.min(W-40,200);ctx.fillStyle='#1e1008';ctx.fillRect(-tw/2-10,y0-8,tw+20,14);ctx.fillStyle='#2d5a2a';ctx.fillRect(-tw/2-8,y0-6,tw+16,10);   // ribbon tails
  ctx.fillStyle='#1e1008';ctx.fillRect(-tw/2-3,y0-16,tw+6,30);ctx.fillStyle='#c8963c';ctx.fillRect(-tw/2-1,y0-14,tw+2,26);ctx.fillStyle='#3f7a3a';ctx.fillRect(-tw/2+1,y0-12,tw-2,22);ctx.fillStyle='#5ea050';ctx.fillRect(-tw/2+1,y0-12,tw-2,3);ctx.fillStyle='#2d5a2a';ctx.fillRect(-tw/2+1,y0+7,tw-2,3);
  txt(REV_TITLES[r.k]||'NEW!',0,y0+4,{size:16,align:'center',col:'#ffe14d',lw:4,out:'#2a160a'});
  // the thing on a rarity-coloured tile
  const ts=64,ty=y0+18;ctx.fillStyle='#2a160a';ctx.fillRect(-ts/2-2,ty-2,ts+4,ts+4);ctx.fillStyle=r.col;ctx.fillRect(-ts/2,ty,ts,ts);
  const tg=ctx.createRadialGradient(0,ty+ts/2,4,0,ty+ts/2,ts*.7);tg.addColorStop(0,'rgba(255,255,255,.55)');tg.addColorStop(1,'rgba(0,0,0,.25)');ctx.fillStyle=tg;ctx.fillRect(-ts/2,ty,ts,ts);
  const bob=Math.sin(t*3)*2;ctx.save();ctx.translate(0,ty+ts/2+bob);
  if(r.k==='card'){const cw=42,ch=58;ctx.translate(-cw/2,-ch/2);drawCardFace(r.id,cw,ch,true,null);}
  else if(r.k==='item'){gearIconBox(-26,-26,r.it,52);}
  else if(r.k==='level'){ctx.fillStyle='#14182c';ctx.beginPath();ctx.arc(0,0,26,0,6.283);ctx.fill();ctx.fillStyle='#ffe14d';ctx.beginPath();ctx.arc(0,0,22,0,6.283);ctx.fill();txt(String(r.lv||P.lv),0,10,{size:26,align:'center',col:'#2a160a',lw:0,out:false});}
  else{draw(TSPR[T.CHST]?TSPR[T.CHST][0]:SP.ic.sword,-24,-24,3);}
  ctx.restore();
  const ny=ty+ts+16;txt(r.name,0,ny,{size:15,align:'center',col:r.k==='level'?'#3f7a3a':r.col,lw:3,out:'#2a160a'});
  if(r.sub)txt(r.sub,0,ny+17,{size:9,align:'center',col:'#5a3a1e',lw:0,out:false});
  const info=r.info||(r.k==='item'&&r.it&&typeof gearStatLine==='function'?gearStatLine(r.it):'');
  if(info){const font='bold '+scaleText(9)+'px "Courier New",monospace',ls=wrapText(info,W-40,font);ls.slice(0,3).forEach((l,i)=>txt(l,0,ny+33+i*12,{size:9,align:'center',col:'#2a1a0e',lw:0,out:false}));}
  ctx.restore();ctx.globalAlpha=1;
  if(t>.6)txt(TOUCH?'tap to continue':'press Enter',cx,VH-SB-16,{size:9,align:'center',col:'rgba(255,240,210,.8)',lw:2});
}
