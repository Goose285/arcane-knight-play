/* =====================================================================
   NEW-GAME INTRO: one thing at a time.  story panel (tap to close) -> the village name -> ONE objective ("Talk to Elder Orin by the
   fountain", tracker + arrow). Until the first quest (Slime Trouble) is handed in, daily-challenge notices, combat tips, the story
   tracker and the tutorial stay quiet; afterwards they are introduced one at a time through the toast queue.
   Only new games get it (flag QS.met.__intro, saved with the quests), so existing saves are untouched.  window.__NOINTRO disables it.
   ===================================================================== */
const INTRO={ph:null};
const introOff=()=>window.__NOINTRO===true;
const introActive=()=>!!(QS.met&&QS.met.__intro);
const introQuiet=()=>introActive()&&QS.st.slimes!=='done';
const introHold=()=>INTRO.ph==='story'||INTRO.ph==='banner';      // nothing transient shows while these run
const INTRO_STORY=['Embers drift over the Realm again, and every night the monsters creep closer to the quiet village of Oakvale.',
  'You are its newest Arcane Knight. Elder Orin waits by the fountain - start there.'];
const INTRO_LATER=[['TIP: Monsters see in a cone. Sneak behind them - or shoot first!',4,'#ffe9a0'],
  ['NEW: Daily challenges unlocked  (Pause > DAILY)',3.6,'#ffe14d'],['NEW: Your story continues - talk to Elder Orin again',3.6,'#cfd0ff']];
function introStart(){
  if(introOff())return false;
  QS.met.__intro=1;INTRO.ph='story';areaT=0;TRK.id=null;TRK.auto=true;
  DLG={name:'OAKVALE',lines:INTRO_STORY.slice(),i:0,c:0};
  return true;
}
function updateIntro(){
  if(!introActive()){INTRO.ph=null;return;}
  if(INTRO.ph==='story'){areaT=0;if(!DLG){INTRO.ph='banner';areaT=2.4;}return;}
  if(INTRO.ph==='banner'){if(areaT<=0){INTRO.ph='obj';TRK.flash=1;TRK.fk='';TRK.sig=null;sfx('select');}return;}
  if(!INTRO.ph)INTRO.ph='obj';                                   // a save made mid-intro
  if(QS.st.slimes==='done'&&!DLG&&state==='play'){             // first quest handed in: introduce the rest, one toast at a time
    for(const t of INTRO_LATER)toast(t[0],t[1],t[2]);
    delete QS.met.__intro;INTRO.ph=null;if(typeof dailyChk!=='undefined')dailyChk=12;saveGame('intro');
  }
}
/* the single first objective for the tracker */
function introEntry(){
  if(!introQuiet())return null;const s=QS.st.slimes;if(s==='active'||s==='ready')return null;
  return {id:'intro',kind:'intro',name:'First Steps',obj:'Talk to Elder Orin by the fountain',short:'Step',prog:0,need:1,ready:false,order:99};
}
/* the free strip between the tracker (left) and the minimap (right) where transient text goes, so nothing overlaps */
function hudBand(){
  const L=SL+8+Math.max(178,TRK.rect?TRK.rect.x+TRK.rect.w-SL-8:0)+8,R=VW-SR-8-132-8;
  if(R-L>=220)return {x0:L,x1:R,y:ST+30};
  return {x0:SL+8,x1:VW-SR-8,y:Math.max(ST+(TRK.rect?TRK.rect.y+TRK.rect.h-ST:120)+14,VH*.2)};   // too narrow: go below the tracker
}
