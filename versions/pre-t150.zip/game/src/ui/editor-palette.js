/* =====================================================================
   WORLD EDITOR PALETTE: every paintable tile / placeable prop / building / enemy / NPC as an item with a thumbnail of its real in-game art.
   Items live in categories (Ground, Water, Roads, Nature, Props, Enemies, NPCs). kind: 't' ground tile (painted with a brush, road + water edges
   auto-blend because they are drawn from the map), 'p' single prop tile, 'b' house (w tiles wide), 'e' enemy spawn, 'n' NPC / sign.
   ===================================================================== */
const ED_CATS=['Ground','Water','Roads','Nature','Props','Enemies','NPCs'];
const ED_NPC_DEFS={
  elder:{name:'Villager',spr:'elder',lines:['Hello, traveler!']},kid:{name:'Child',spr:'kid',lines:['Hi! Want to play?']},guard:{name:'Guard',spr:'guard',lines:['Move along, citizen.']},
  smith:{name:'Smith',spr:'smith',lines:['Fine steel, made right here.']},priest:{name:'Priest',spr:'priest',lines:['Peace be with you.']},fisher:{name:'Angler',spr:'fisher',lines:['The fish are biting today.']},
  keeper:{name:'Keeper',spr:'keeper',lines:['Welcome, friend.']},sign:{name:'Sign',spr:'houseSign',lines:['A weathered wooden sign.']}};
const ED_ITEMS=[
  {cat:'Ground',kind:'t',id:T.G,name:'Grass'},{cat:'Ground',kind:'t',id:T.K,name:'Dark grass'},{cat:'Ground',kind:'t',id:T.L,name:'Flowers'},{cat:'Ground',kind:'t',id:T.SD,name:'Sand'},
  {cat:'Ground',kind:'t',id:T.MD,name:'Mud'},{cat:'Ground',kind:'t',id:T.SN,name:'Snow'},{cat:'Ground',kind:'t',id:T.C,name:'Red carpet'},
  {cat:'Water',kind:'t',id:T.W,name:'Water (banks blend)'},{cat:'Water',kind:'p',id:T.RE,name:'Reeds'},
  {cat:'Roads',kind:'t',id:T.P,name:'Gravel road (edges blend)'},{cat:'Roads',kind:'t',id:T.F,name:'Stone paving'},{cat:'Roads',kind:'t',id:T.J,name:'Wooden bridge'},
  {cat:'Nature',kind:'p',id:T.T,name:'Tree'},{cat:'Nature',kind:'p',id:T.PN,name:'Pine'},{cat:'Nature',kind:'p',id:T.PM,name:'Palm'},{cat:'Nature',kind:'p',id:T.AC,name:'Acacia'},
  {cat:'Nature',kind:'p',id:T.BU,name:'Bush'},{cat:'Nature',kind:'p',id:T.ST,name:'Stump'},{cat:'Nature',kind:'p',id:T.RK,name:'Rock'},
  {cat:'Props',kind:'p',id:T.N,name:'Fence'},{cat:'Props',kind:'p',id:T.LN,name:'Lantern'},{cat:'Props',kind:'p',id:T.FR,name:'Campfire'},{cat:'Props',kind:'p',id:T.Z,name:'Brazier'},
  {cat:'Props',kind:'b',w:3,name:'Small house'},{cat:'Props',kind:'b',w:4,name:'House'},{cat:'Props',kind:'b',w:5,name:'Large house'},{cat:'Props',kind:'n',npc:'sign',name:'Sign post'},
  ...['slime','knight','goblin','wraith','bat','wolf','yeti','toad','witch','scorpion','mummy','boar','scarecrow'].map(t=>({cat:'Enemies',kind:'e',type:t,name:(ENEMY[t].name||t)+' spawn'})),
  ...['elder','kid','guard','smith','priest','fisher','keeper'].map(k=>({cat:'NPCs',kind:'n',npc:k,name:ED_NPC_DEFS[k].name})),
];
for(const it of ED_ITEMS)it.key=it.kind+':'+(it.kind==='t'||it.kind==='p'?it.id:it.kind==='b'?it.w:it.kind==='e'?it.type:it.npc);
const ED_ITEM_BY=Object.fromEntries(ED_ITEMS.map(i=>[i.key,i]));
const ED_PROPSET=new Set([T.T,T.BU,T.LN,T.RK,T.N,T.ST,T.PN,T.PM,T.AC,T.RE,T.FR,T.Z]);                 // tiles that count as movable / deletable props
const ED_GROUNDSET=new Set([T.G,T.K,T.L,T.P,T.W,T.SD,T.MD,T.SN,T.C,T.F,T.J]);                         // ground that can be painted over
const ED_OKSET=new Set([...ED_PROPSET,...ED_GROUNDSET]);                                              // buildings, the castle... are never overwritten
/* ---- thumbnails (real art) ---- */
function edArt(it){
  if(it._a)return it._a;
  let a={};const sx=20+OX,sy=8+OY;
  if(it.kind==='t'||it.kind==='p'){
    const id=it.id;
    if(typeof BIGTREE_IDS!=='undefined'&&BIGTREE&&BIGTREE_IDS.has(id)){const L=treeLayers(id,sx,sy);a={tile:L.bg,fg:L.fg};}
    else if(typeof TREE_IDS!=='undefined'&&TREE_IDS.has(id))a={tile:treeSprite(id,sx,sy)};
    else a={tile:TSPR[id][0]};
  }else if(it.kind==='b'){
    const w=it.w;a={spr:makeSprite(w*16,48,g=>{for(let c=0;c<w;c++){g.drawImage(TSPR[T.R][0],c*16,0);g.drawImage(TSPR[T.RL][0],c*16,16);g.drawImage(TSPR[c===(w>>1)?T.D:T.H][0],c*16,32);}})};
  }else if(it.kind==='e')a={spr:SP[ENEMY[it.type].spr]};
  else a={spr:SP[ED_NPC_DEFS[it.npc].spr]};
  return it._a=a;
}
/* draw item art inside a box (x,y = top-left, a = integer art scale; ground tiles fill the box, sprites sit on its floor) */
function edDrawArt(it,x,y,a,alpha){
  const A=edArt(it);ctx.save();ctx.globalAlpha=alpha==null?1:alpha;ctx.imageSmoothingEnabled=false;
  if(A.tile){ctx.drawImage(A.tile,x,y,16*a,16*a);if(A.fg)ctx.drawImage(A.fg,x,y,16*a,16*a);}
  else if(A.spr){const m=Math.max(A.spr.width,A.spr.height),sc=m>16?a*16/m:a,w=A.spr.width*sc,h=A.spr.height*sc;ctx.drawImage(A.spr,Math.round(x+(16*a-w)/2),Math.round(y+16*a-h),w,h);}
  ctx.restore();
}
/* ---- rules: why an item cannot go on a tile (null = fine) ---- */
function edWhy(it,tx,ty){
  if(!it)return 'Pick something from the tray';
  if(it.kind==='t')return edIn(tx,ty)&&ED_OKSET.has(map[ty][tx])&&!isVillagePondTile(tx,ty)?null:'Cannot paint there';
  if(it.kind==='p'){if(!edIn(tx,ty)||!ED_OKSET.has(map[ty][tx])||map[ty][tx]===T.W||isVillagePondTile(tx,ty))return 'Cannot place there';return map[ty][tx]===it.id?'Already there':null;}
  if(it.kind==='b'){const x0=tx-(it.w>>1),y0=ty-2;for(let r=0;r<3;r++)for(let c=0;c<it.w;c++){const x=x0+c,y=y0+r;if(!edIn(x,y)||!ED_OKSET.has(map[y][x])||map[y][x]===T.W||isVillagePondTile(x,y))return 'No room for a house there';}return null;}
  if(it.kind==='e')return edIn(tx,ty)&&!solidTile(tx,ty)&&!isVillagePondTile(tx,ty)&&!inTownPx(tx*TS+16,ty*TS+16)?null:'Cannot place a spawn there';
  if(it.kind==='n')return edIn(tx,ty)&&!solidTile(tx,ty)&&!isVillagePondTile(tx,ty)?null:'Cannot place that there';
  return 'Cannot place there';
}
/* the op that places an item on a tile (the door tile for houses) */
function edPlaceOp(it,tx,ty){
  if(it.kind==='p')return {k:'tiles',t:[[tx,ty,it.id]]};
  if(it.kind==='b'){const x0=tx-(it.w>>1),y0=ty-2,t=[];for(let r=0;r<3;r++)for(let c=0;c<it.w;c++)t.push([x0+c,y0+r,r===0?T.R:r===1?T.RL:c===(it.w>>1)?T.D:T.H]);return {k:'tiles',t};}
  if(it.kind==='e')return {k:'eadd',type:it.type,tx,ty};
  if(it.kind==='n')return {k:'nadd',key:it.npc,tx,ty};
  return null;
}
