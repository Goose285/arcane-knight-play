/* =====================================================================
   PAUSE MENU: a clean main screen of big buttons + a few small sub-pages, each with a BACK button.
   PAUSE_ITEMS stays the flat registry of every feature (keyboard shortcut + action); the pages below just group them.
   ===================================================================== */
const pauseRects=[];
const PAUSE={page:'main',sel:0,cols:1,qAt:-99,kbd:false,tip:null,ptr:null,slotRects:[],sat:null,tipItem:null,tipAt:null};
const PAUSE_ITEMS=[
  {k:'KeyP',lab:()=>'RESUME',home:'main',act:()=>{pressed.KeyP=true;}},
  {k:'KeyD',lab:()=>'DECK / CARDS',home:'main',act:()=>openDeck()},
  {k:'KeyG',lab:()=>'EQUIPMENT',home:'main',act:()=>openGear()},
  {k:'KeyQ',lab:()=>{const n=QUESTS.filter(q=>questStatus(q.id)==='ready').length;return 'QUESTS'+(n?'  ('+n+' ready!)':'');},home:'journal',act:()=>openQuests()},
  {k:'KeyT',lab:()=>{const n=skillPoints();return 'SKILLS'+(n?'  ('+n+' pts!)':'');},home:'skills',act:()=>openSkills()},
  {k:'KeyO',lab:()=>'PETS'+(PET.active?'  ('+PETS[PET.active].name+')':''),home:'character',act:()=>openPets()},
  {k:'KeyB',lab:()=>'CHRONICLE'+(NPCS.some(n=>storyReady(n))?'  (new!)':''),home:'journal',act:()=>openUIMode('story')},
  {k:'KeyV',lab:()=>'DAILY'+(chestReady()&&!metaOff()?'  (chest!)':''),home:'character',act:()=>openDaily()},
  {k:'KeyH',lab:()=>'ACHIEVEMENTS',home:'character',act:()=>openAch()},
  {k:'KeyC',lab:()=>'WORKBENCH',home:'skills',act:()=>openCraft()},
  {k:'KeyI',lab:()=>'FISHING'+(FSH.rod>=0?'  ('+fishCount()+')':''),home:'skills',act:()=>openFishing()},
  {k:'KeyF',lab:()=>'FAST TRAVEL',home:'main',act:()=>openTravel()},
  {k:'KeyN',lab:()=>'SETTINGS',home:'main',act:()=>openSettings('paused')},
  {k:'KeyU',lab:()=>labOn()?'LEAVE COMBAT LAB':'COMBAT LAB',home:'character',act:()=>{if(labOn()){pressed.KeyP=true;labLeave();}else{if(!labStart())toast('Cannot start practice right now',1.6,'#ffb0a0');else pauseReset();}}},
  {k:'KeyH2',lab:()=>'TELEPORT HOME',home:'main',act:()=>{if(homeBlock()){toast(homeBlock(),1.8,'#ffb0a0');sfx('clang');return;}pressed.KeyP=true;startHome();}},
  {k:'KeyM',lab:()=>'SOUND: '+(muted?'OFF':'ON'),home:'main',act:()=>{muted=!muted;sfx('select');}},
];
const pauseItem=k=>PAUSE_ITEMS.find(i=>i.k===k);
function pauseGo(k){const it=pauseItem(k);PAUSE.page='main';const t={character:'character',journal:'journal',skills:'skills'}[it.home];if(t)PM.tab=t;it.act();}   // t135u: features return to the tabbed panel   // opening a feature remembers which page to come back to
function pauseOpenPage(p){PAUSE.page=p;PAUSE.sel=0;PAUSE.qAt=-99;sfx('select');}
function pauseReset(){PAUSE.page='main';PAUSE.sel=0;PAUSE.qAt=-99;PAUSE.tip=null;}
function pauseQuit(){   // save + back to the title screen (second tap confirms)
  if(gtime-PAUSE.qAt>3){PAUSE.qAt=gtime;sfx('select');return;}
  saveGame('menu');
  if(B){resetFighters(false);B=null;}
  DLG=null;if(labOn())labClean();RUSH.on=false;pauseReset();state='title';titleMenu.items.length=0;releaseAllTouch();sfx('select');
}
const pauseReadyQ=()=>QUESTS.filter(q=>questStatus(q.id)==='ready').length;
const pauseStoryNew=()=>NPCS.filter(n=>storyReady(n)).length;
const pauseDaily=()=>(chestReady()&&!metaOff())?1:0;
function pauseEntries(page){
  const E=(id,lab,ic,col,o)=>Object.assign({id,lab,ic,col},o);
  const leaf=(id,lab,ic,col,k,sub,badge)=>E(id,lab,ic,col,{sub,badge,act:()=>pauseGo(k)});
  const nav=(id,lab,ic,col,p,sub,badge)=>E(id,lab,ic,col,{sub,badge,act:()=>pauseOpenPage(p)});
  if(page==='main')return [
    E('resume','RESUME','play','#2d6a4f',{act:()=>{pressed.KeyP=true;},wide:true}),
    nav('character','CHARACTER','hero','#5a3a7a','character','',()=>pauseDaily()?'!':''),
    leaf('cards','CARDS','cards','#2d4f8a','KeyD'),
    leaf('inventory','INVENTORY','bag','#7a5530','KeyG'),
    nav('journal','JOURNAL','scroll','#2a5a4a','journal','',()=>{const n=pauseReadyQ()+pauseStoryNew();return n?String(n):'';}),
    leaf('world','WORLD MAP','map','#2a4a6a','KeyF'),
    nav('skills','SKILLS','star','#6a3a8a','skills','',()=>skillPoints()?String(skillPoints()):''),
    leaf('settings','SETTINGS','cog','#34406a','KeyN'),
    leaf('home','TELEPORT HOME','home','#2a6a6a','KeyH2',HOME.cd>0?Math.ceil(HOME.cd)+'s':'',()=>''),
    E('quit','SAVE & QUIT','door','#7a2a2a',{act:pauseQuit,quit:true})];
  if(page==='character')return [
    leaf('pets','PETS','paw','#5a2a5a','KeyO','Companions & their house',()=>''),
    leaf('ach','ACHIEVEMENTS','trophy','#7a5a1a','KeyH','Trophies and titles'),
    leaf('daily','DAILY','chest','#8a6a1a','KeyV','Rewards and weekly goals',()=>pauseDaily()?'!':''),
    leaf('lab',labOn()?'LEAVE COMBAT LAB':'COMBAT LAB','sword','#1f5a7a','KeyU',labOn()?'Back to where you were':'Practice: dummies + the new card system')];
  if(page==='journal')return [
    leaf('quests','QUESTS','scroll','#2a5a4a','KeyQ','Active and finished',()=>pauseReadyQ()?String(pauseReadyQ()):''),
    leaf('story','CHRONICLE','book','#7a4a2a','KeyB','Stories of the villagers',()=>pauseStoryNew()?String(pauseStoryNew()):'')];
  if(page==='skills')return [
    leaf('tree','SKILL TREE','star','#6a3a8a','KeyT','Spend your skill points',()=>skillPoints()?String(skillPoints()):''),
    leaf('fish','FISHING','fish','#1f5a7a','KeyI','Rods and your catch',()=>''),
    leaf('craft','CRAFTING','hammer','#6a5a2a','KeyC','Workbench: craft and upgrade')];
  return [];
}
const PAUSE_TITLES={main:'PAUSED',character:'CHARACTER',journal:'JOURNAL',skills:'SKILLS'};
/* tiny 10x10 pixel icons */
function pauseIcon(id,x,y,s){
  const r=(a,b,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(x+a*s,y+b*s,w*s,h*s);},W='#fff',G='#ffe27a',D='#14182c';
  switch(id){
    case 'play':r(1,0,2,10,W);r(3,1,2,8,W);r(5,2,2,6,W);r(7,3,2,4,W);r(9,4,1,2,W);break;
    case 'hero':r(2,0,6,4,G);r(3,0,4,1,'#fff6d8');r(3,2,4,3,'#f2c9a0');r(3,3,1,1,D);r(6,3,1,1,D);r(0,6,10,4,'#f6ecd2');r(0,6,3,2,G);r(7,6,3,2,G);r(4,7,2,2,G);break;
    case 'cards':r(0,2,6,8,'#9ab8ff');r(1,3,4,6,'#3a5aa8');r(4,0,6,8,W);r(5,1,4,6,'#e8504a');r(6,3,2,2,W);break;
    case 'bag':r(2,0,6,3,'#a8741a');r(3,1,4,2,'#7a5530');r(1,3,8,7,'#d9a05b');r(1,3,8,2,'#e8b878');r(4,5,2,2,G);break;
    case 'scroll':r(1,0,8,10,'#f6ecd2');r(2,2,6,1,'#8a6a3a');r(2,4,6,1,'#8a6a3a');r(2,6,4,1,'#8a6a3a');r(7,7,2,2,'#e8504a');break;
    case 'home':r(1,4,8,5,'#e8e0c0');r(0,3,10,1,'#c8503a');r(1,2,8,1,'#c8503a');r(2,1,6,1,'#c8503a');r(4,6,2,3,'#6a4a2a');break;
    case 'map':r(0,1,10,8,'#cdb98a');r(4,1,1,8,'#8a6a3a');r(1,3,3,1,'#8a6a3a');r(6,6,3,1,'#8a6a3a');r(6,3,2,2,'#e8504a');break;
    case 'star':r(4,0,2,3,G);r(0,3,10,2,G);r(2,5,6,2,G);r(1,7,3,3,G);r(6,7,3,3,G);r(4,3,2,2,'#fff6d8');break;
    case 'cog':r(4,0,2,10,'#cfd8ff');r(0,4,10,2,'#cfd8ff');r(1,1,8,8,'#cfd8ff');r(3,3,4,4,'#34406a');r(4,4,2,2,'#cfd8ff');break;
    case 'door':r(1,0,6,10,'#e8b88a');r(2,1,4,8,'#6a3a1a');r(5,5,1,1,G);r(7,4,3,2,W);r(8,3,1,4,W);break;
    case 'paw':r(0,3,2,2,W);r(8,3,2,2,W);r(2,0,2,3,W);r(6,0,2,3,W);r(3,5,4,4,W);r(2,6,6,2,W);break;
    case 'trophy':r(2,0,6,5,G);r(0,1,2,3,G);r(8,1,2,3,G);r(4,5,2,3,'#d9a02a');r(2,8,6,2,G);break;
    case 'chest':r(0,2,10,8,'#a8741a');r(0,2,10,3,'#d9a05b');r(4,4,2,3,G);r(0,5,10,1,'#6a4a10');break;
    case 'book':r(0,1,10,9,'#7a4a2a');r(1,2,8,7,'#f6ecd2');r(4,2,2,7,'#7a4a2a');r(2,4,2,1,'#8a6a3a');r(6,4,2,1,'#8a6a3a');break;
    case 'fish':r(0,3,7,5,'#7dd3ff');r(7,2,3,7,'#5ab0e0');r(2,4,1,1,D);r(3,7,3,1,'#4a90c0');break;
    case 'sword':r(7,0,3,3,'#dfe9f2');r(5,2,3,3,'#dfe9f2');r(3,4,3,3,'#bfc8d8');r(1,6,3,2,'#a8741a');r(0,8,3,2,'#7a5530');r(2,5,1,1,'#ffe27a');r(4,7,1,1,'#ffe27a');break;
    case 'hammer':r(0,0,8,4,'#bfc8d8');r(0,0,8,1,W);r(3,4,3,6,'#a8741a');break;
    case 'sound':r(0,3,3,4,W);r(3,2,2,6,W);r(5,1,1,8,W);if(muted){r(7,1,3,1,'#e8504a');r(8,2,1,6,'#e8504a');}else{r(7,3,1,4,W);r(9,2,1,6,W);}break;
  }
}
function pauseLayout(){
  const page=PAUSE.page,items=pauseEntries(page),rects=[],gap=10;
  const L=SL+14,R=VW-SR-14,W=Math.round(Math.min(R-L,page==='main'?560:380)),x0=Math.round((VW-W)/2),top=ST+12,bot=VH-SB-14;
  if(page==='main'){   // the leather satchel: tabs along the top, item slots in the body, straps (Resume / Teleport home / Save & Quit) at the bottom
    const SG=6,avH=VH-ST-SB,tabH=Math.max(32,Math.min(46,Math.round(avH*.13))),strapH=Math.max(28,Math.min(40,Math.round(avH*.11))),tabsY=ST+(avH<340?6:10)+12;
    let bodyY=tabsY+tabH-3,bodyB=VH-SB-6-(strapH-12),bodyH=bodyB-bodyY;const infoH=18,padT=12,padB=14+8;let gridH=bodyH-padT-infoH-padB-4;
    const availW=VW-SL-SR-16;
    let s_=Math.max(34,Math.min(72,Math.floor((gridH-2*SG)/3)));
    let cols=Math.max(4,Math.ceil((340-28+SG)/(s_+SG)));cols=Math.max(3,Math.min(cols,Math.floor((availW-28+SG)/(s_+SG))));
    const rows=Math.max(2,Math.min(4,Math.floor((gridH+SG)/(s_+SG)))),Wb=cols*(s_+SG)-SG+28,bx=Math.round(SL+(VW-SL-SR-Wb)/2);
    // shrink-wrap the body when the slots do not fill it, and centre the whole bag vertically
    const need=padT+infoH+4+rows*(s_+SG)-SG+8+padB,slack=bodyH-need;let dy=0;if(slack>2){bodyH=need;bodyB=bodyY+bodyH;dy=Math.floor(slack/2);}
    const tabsY0=tabsY;if(dy){bodyY+=dy;bodyB+=dy;}const tabsYc=tabsY0+dy;
    const tabs=items.slice(1,8),tgap=3,tabW=Math.floor((Wb-14-(tabs.length-1)*tgap)/tabs.length);
    tabs.forEach((e,i)=>rects.push({x:bx+7+i*(tabW+tgap),y:tabsYc,w:tabW,h:tabH,e,kind:'tab'}));
    const straps=[items[0],items[8],items[9]],sg=8,sw=Math.floor((Wb-36-sg*2)/3),sy=bodyB-12;
    // reorder so the rect list reads resume, tabs..., home, quit (same ids as before)
    const sr=straps.map((e,i)=>({x:bx+18+i*(sw+sg),y:sy,w:sw,h:strapH,e,kind:'strap'}));
    rects.unshift(sr[0]);rects.push(sr[1],sr[2]);
    PAUSE.cols=7;PAUSE.sat={bx,Wb,bodyY,bodyB,bodyH,tabsY:tabsYc,tabH,strapH,s:s_,cols,rows,gx:bx+14,gy:bodyY+padT+infoH+4,SG,infoY:bodyY+padT};
    return {rects,hdr:0,x0:bx,W:Wb,top:tabsYc};
  }
  const hdr=(page==='character'&&VH>=470)?128:(VH<430?56:60),backH=Math.max(42,Math.min(54,Math.round(VH*.09))),n=items.length;
  const sg=VH<430?6:gap,rh=Math.max(VH<430?40:46,Math.min(68,Math.floor((bot-top-hdr-backH-sg*(n+1))/n)));
  items.forEach((e,i)=>rects.push({x:x0,y:top+hdr+i*(rh+sg),w:W,h:rh,e}));
  rects.push({x:x0,y:bot-backH,w:W,h:backH,e:{id:'back',lab:'BACK',ic:'',col:'#2a2740',back:true,act:()=>pauseOpenPage('main')}});
  PAUSE.cols=1;return {rects,hdr,x0,W,top};
}
function pauseButton(r,sel){
  const e=r.e,x=r.x,y=r.y,w=r.w,h=r.h,warn=e.quit&&gtime-PAUSE.qAt<=3;
  if(r.kind==='tab'){   // bookmark tab with its icon
    const ty=satTab(x,y,w,h,sel),is=h>=34?2:1,isz=10*is,ex=h>=42&&w>=50;
    pauseIcon(e.ic,Math.round(x+w/2-isz/2),Math.round(ty+(ex?5:Math.max(4,(h-9-isz)/2))),is);
    if(ex){const lab=e.lab.split(' ')[0];txt(lab,x+w/2,ty+h-14,{size:7,align:'center',col:'#f6e6c0',lw:2,out:'#2a160a'});}
    const b=e.badge?e.badge():'';if(b){const bx=x+w-6,by=ty+7;ctx.fillStyle='#14182c';ctx.beginPath();ctx.arc(bx,by,8,0,6.283);ctx.fill();ctx.fillStyle='#e8504a';ctx.beginPath();ctx.arc(bx,by,6.5,0,6.283);ctx.fill();txt(b,bx,by+3,{size:b.length>1?7:9,align:'center',col:'#fff',lw:2});}
    return;
  }
  if(r.kind==='strap'){   // leather strap with a brass buckle at the end
    satStrap(x,y,w,h,sel,warn);
    const bw=Math.min(24,Math.round(w*.2)),bh=Math.min(20,h-10),bcx=x+w-bw/2-9;satBuckle(bcx,y+Math.round((h-bh)/2)+2,bw,bh);
    const lab=warn?'TAP AGAIN':e.id==='home'?(HOME.cd>0?'HOME '+Math.ceil(HOME.cd)+'s':'HOME'):e.id==='quit'?'SAVE & QUIT':'RESUME',maxW=w-bw-26;
    let sz=11;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';while(sz>7&&ctx.measureText(lab).width>maxW){sz--;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';}
    txt(lab,x+10+maxW/2,y+Math.round(h*.42)+4,{size:sz,align:'center',col:warn?'#ffb0a0':'#fff3d0',lw:3,out:'#2a160a'});
    return;
  }
  if(e.id==='editor'){satBrass(x,y,w,h);txt('EDITOR',x+w/2,y+h-5,{size:8,align:'center',col:'#3a2208',lw:0,out:false});return;}
  if(e.id==='sound'){satBrass(x,y,w,h);pauseIcon('sound',x+5,y+Math.round((h-14)/2),1.4);if(w>40)txt(muted?'OFF':'ON',x+26,y+h-5,{size:9,col:muted?'#7a1a1a':'#1a4a1a',lw:0,out:false});return;}
  // sub-page rows: stitched leather strips with a brass icon plate
  satLeather(x,y,w,h,{cut:2,tone:'rgba(30,14,4,.18)',sc:'#c89858'});
  if(sel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=3;ctx.strokeRect(x+2,y+2,w-4,h-4);}
  const is=h>=60?3:2,isz=10*is,iy=y+Math.round((h-isz)/2),lab=warn?'TAP AGAIN TO QUIT':e.lab;
  if(e.ic){const px=x+10;ctx.fillStyle=e.col;ctx.fillRect(px-3,iy-3,isz+6,isz+6);ctx.strokeStyle='#2a160a';ctx.lineWidth=2;ctx.strokeRect(px-3,iy-3,isz+6,isz+6);pauseIcon(e.ic,px,iy,is);}
  if(e.back)txt(lab,x+w/2,y+h/2+6,{size:17,align:'center',col:'#fff3d0',lw:3,out:'#2a160a'});
  else{
    const tx=x+10+isz+16,sz0=lab.length>8&&w<150?11:lab.length>10&&w<170?12:14,sz=Math.max(8,Math.min(sz0,Math.floor((w-(tx-x)-8)/(lab.length*.64))));
    if(e.sub)txt(lab,tx,y+h/2-1,{size:15,col:'#fff3d0',lw:3,out:'#2a160a'}),txt(e.sub,tx,y+h/2+15,{size:9,col:'#e8d4a8',lw:2,out:'#2a160a'});
    else txt(lab,tx,y+h/2+5,{size:sz,col:'#fff3d0',lw:3,out:'#2a160a'});
  }
  const b=e.badge?e.badge():'';
  if(b){const bx=x+w-14,by=y+14;ctx.fillStyle='#14182c';ctx.beginPath();ctx.arc(bx,by,11,0,6.283);ctx.fill();ctx.fillStyle='#e8504a';ctx.beginPath();ctx.arc(bx,by,9,0,6.283);ctx.fill();txt(b,bx,by+4,{size:b.length>1?9:12,align:'center',col:'#fff',lw:2});}
}
function pauseSatchelMain(lay){
  const S=PAUSE.sat,cx=Math.round(S.bx+S.Wb/2),items=satItems(),n=S.cols*S.rows;
  // body + top handle with a small buckle
  satLeather(S.bx,S.bodyY,S.Wb,S.bodyH);
  const hw=Math.min(46,Math.round(S.Wb*.14));satLeather(cx-hw/2,S.tabsY-12,hw,18,{cut:2,stitch:false});satBuckle(cx,S.tabsY-9,18,12);
  // recessed interior
  const ih=S.gy+S.rows*(S.s+S.SG)-S.SG+8-(S.bodyY+8);satWell(S.bx+10,S.bodyY+8,S.Wb-20,ih);
  txt(`Lv ${P.lv}   HP ${Math.max(0,P.hp|0)}/${maxHp()}   ${P.gold} G`,S.bx+18,S.infoY+11,{size:10,col:'#f6e6c0',lw:3,out:'#1c0e06'});
  // slots
  PAUSE.slotRects=[];const tip=PAUSE.tip&&gtime-PAUSE.tip.t<4?PAUSE.tip.i:-1;
  const ptr=PAUSE.ptr,ov=items.length>n;
  for(let i=0;i<n;i++){
    const c=i%S.cols,r=Math.floor(i/S.cols),x=S.gx+c*(S.s+S.SG),y=S.gy+r*(S.s+S.SG);
    PAUSE.slotRects.push({x,y,w:S.s,h:S.s,i});
    const it=i===n-1&&ov?{name:'+'+(items.length-n+1)+' more',sub:'Open INVENTORY to see them all',col:'#ffe27a',more:true}:items[i];
    const hov=ptr&&ptr.x>=x&&ptr.x<x+S.s&&ptr.y>=y&&ptr.y<y+S.s,gl=it?(i===tip?1:hov?.8:(PAUSE.kbd&&PAUSE.sel===-1-i?1:0)):(hov?.25:0);
    satSlot(x,y,S.s,gl);
    if(it){if(it.more)txt(it.name,x+S.s/2,y+S.s/2+4,{size:10,align:'center',col:'#ffe27a',lw:3,out:'#1c0e06'});else satItemIcon(it,x,y,S.s);
      if(it.count>1)txt(String(it.count),x+S.s-4,y+S.s-5,{size:9,align:'right',col:'#fff',lw:3,out:'#1c0e06'});
      if(it.eq){ctx.fillStyle='#e0b44a';ctx.fillRect(x+3,y+3,9,9);txt('E',x+7.5,y+11,{size:8,align:'center',col:'#3a2208',lw:0,out:false});}}
  }
  if(!items.length)txt('Your bag is empty - gear, fish and materials will show up here',S.bx+S.Wb/2,S.gy+S.rows*(S.s+S.SG)/2,{size:9,align:'center',col:'#a8845a',lw:2,out:'#1c0e06',bold:false});
  PAUSE.tipItem=tip>=0?(items.length>n&&tip===n-1?{name:'+'+(items.length-n+1)+' more',sub:'Open INVENTORY to see them all',col:'#3a2210'}:items[tip]):null;
  if(PAUSE.tipItem){const r=PAUSE.slotRects[tip];PAUSE.tipAt={cx:r.x+r.w/2,by:r.y,bounds:{x:S.bx,y:ST,w:S.Wb,h:S.bodyB}};}
  // sound toggle sits in the info row
  const sw=VW<420?30:66,sr={x:S.bx+S.Wb-18-sw,y:S.infoY+1,w:sw,h:18,e:{id:'sound',ic:'sound',lab:'SOUND',act:()=>{muted=!muted;sfx('select');}},kind:'sound'};
  const ew=62;PAUSE.er=S.Wb>200?{x:sr.x-ew-6,y:sr.y,w:ew,h:18,e:{id:'editor',ic:'',lab:'EDITOR',act:edOpen},kind:'editor'}:null;   // world editor (tap-only, next to the sound toggle)
  return sr;
}
function drawPause(){
  const page=PAUSE.page;ctx.fillStyle=page==='main'?'rgba(10,6,2,.66)':'rgba(10,6,2,.9)';ctx.fillRect(0,0,VW,VH);
  const lay=pauseLayout();
  pauseRects.length=0;lay.rects.forEach(r=>pauseRects.push(r));
  if(PAUSE.sel>=pauseRects.length)PAUSE.sel=pauseRects.length-1;
  const cx=VW/2,top=lay.top;
  if(page==='main'){pmDraw();return;}
  if(page==='main'){
    const sr=pauseSatchelMain(lay);
    pauseRects.forEach((r,i)=>pauseButton(r,PAUSE.kbd&&i===PAUSE.sel));
    pauseRects.push(sr);pauseButton(sr,false);if(PAUSE.er){pauseRects.push(PAUSE.er);pauseButton(PAUSE.er,false);}
    if(PAUSE.tipItem){const T=PAUSE.tipAt;satTip(T.cx,T.by,PAUSE.tipItem.name,PAUSE.tipItem.sub,'#3a2210',T.bounds);}
    return;
  }
  // sub-pages: the same leather, as a taller flap holding the list
  satLeather(lay.x0-16,top-8,lay.W+32,VH-SB-14-top+14);
  txt(PAUSE_TITLES[page]||'PAUSED',cx,top+26,{size:Math.min(30,Math.round(VH*.06)+10),align:'center',col:'#ffe9a0',lw:6,out:'#2a160a'});
  const info=`Lv ${P.lv}    HP ${Math.max(0,P.hp|0)}/${maxHp()}    ${P.gold} G`;
  if(page==='character'){
    if(lay.hdr>=120){const px=cx-lay.W/2;satWell(px,top+38,lay.W,84);
      ctx.fillStyle='#14182c';ctx.fillRect(px+8,top+46,68,68);ctx.strokeStyle='#e0b44a';ctx.lineWidth=2;ctx.strokeRect(px+9,top+47,66,66);draw(SP.port.hero,px+10,top+48,2.75);
      txt('HERO',px+88,top+64,{size:15,col:'#ffe9a0',lw:3});txt('Sun Paladin   Lv '+P.lv,px+88,top+82,{size:11,col:'#f6e6c0',lw:3});
      txt('HP '+Math.max(0,P.hp|0)+'/'+maxHp()+'    '+P.gold+' G',px+88,top+98,{size:11,col:'#9be8a0',lw:3});txt('Foes beaten: '+kills,px+88,top+112,{size:9,col:'#d8b888',lw:2});}
    else txt(info,cx,top+44,{size:11,align:'center',col:'#f6e6c0',lw:3});
  }
  if(page!=='character'){const sb=page==='skills'?[skillPoints()+' skill point'+(skillPoints()===1?'':'s')+' to spend',skillPoints()?'#ffe27a':'#d8b888']:[pauseReadyQ()+' quest'+(pauseReadyQ()===1?'':'s')+' ready to turn in',pauseReadyQ()?'#ffe27a':'#d8b888'];txt(sb[0],cx,top+46,{size:11,align:'center',col:sb[1],lw:3});}
  pauseRects.forEach((r,i)=>pauseButton(r,PAUSE.kbd&&i===PAUSE.sel));
}
function pauseTap(p){
  if(PAUSE.page==='main'){pmTap(p);return;}
  PAUSE.kbd=false;
  const r=pauseRects.find(q=>inRect(p,q));
  if(r){PAUSE.tip=null;r.e.act();return;}
  if(PAUSE.page==='main'&&PAUSE.slotRects){const sl=PAUSE.slotRects.find(q=>inRect(p,q));
    if(sl){const items=satItems();if(items[sl.i]||(items.length>PAUSE.slotRects.length&&sl.i===PAUSE.slotRects.length-1)){PAUSE.tip=PAUSE.tip&&PAUSE.tip.i===sl.i&&gtime-PAUSE.tip.t<4?null:{i:sl.i,t:gtime};sfx('select');}else PAUSE.tip=null;return;}
    PAUSE.tip=null;}
}
function updatePauseKeys(){   // keyboard / gamepad: arrows + Enter, hotkeys, Esc = back
  for(const it of PAUSE_ITEMS)if(it.k!=='KeyP'&&it.k!=='KeyM'&&hit(it.k)){pauseGo(it.k);return true;}
  if(PAUSE.page==='main')return pmKeys();
  const n=pauseRects.length-(PAUSE.page==='main'?pauseRects.filter(q=>q.e.id==='sound'||q.e.id==='editor').length:0);   // (the sound button is tap-only)
  const mv=d=>{PAUSE.kbd=true;PAUSE.sel=Math.max(0,Math.min(n-1,PAUSE.sel+d));sfx('select');};
  if(PAUSE.page==='main'){
    const go=i=>{PAUSE.kbd=true;PAUSE.sel=Math.max(0,Math.min(n-1,i));sfx('select');};   // order: 0 resume, 1-7 tabs, 8 home, 9 quit
    if(hit('ArrowDown','KeyS'))go(PAUSE.sel>=1&&PAUSE.sel<=7?(PAUSE.sel<=3?0:PAUSE.sel<=5?8:9):PAUSE.sel);
    else if(hit('ArrowUp','KeyW'))go(PAUSE.sel===0?2:PAUSE.sel===8?5:PAUSE.sel===9?7:PAUSE.sel);
    else if(hit('ArrowRight'))mv(1);else if(hit('ArrowLeft'))mv(-1);
  }else{if(hit('ArrowDown','KeyS','ArrowRight'))mv(1);else if(hit('ArrowUp','KeyW','ArrowLeft'))mv(-1);}
  if(hit('Enter','Space')){const r=pauseRects[PAUSE.sel];if(r&&PAUSE.kbd){r.e.act();return true;}PAUSE.kbd=true;}
  if(PAUSE.page!=='main'&&hit('Escape','Backspace')){pauseOpenPage('main');return true;}
  return false;
}
