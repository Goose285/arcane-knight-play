/* =====================================================================
   SKILL TREE SCREEN (pause menu -> SKILLS)
   ===================================================================== */
function openSkills(){openUIMode('skills');}
function skillRow(n){
  const r=skillRank(n.id),why=skillCan(n),can=!why;
  const buy=()=>{UI.sel=0;if(buySkill(n.id)){uiMsg(n.name+' rank '+skillRank(n.id),false);saveGame('skill');}else{uiMsg(why||'Cannot learn',true);sfx('clang');}};
  return {sel:true,h:52,act:buy,tap:buy,
    draw(x0,y,W,h,isSel,si){
      ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=n.col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      txt(n.name,x0+10,y+14,{size:11,col:n.col,lw:2});
      for(let i=0;i<n.max;i++){ctx.fillStyle=i<r?n.col:'#2c2850';ctx.fillRect(x0+10+i*14,y+20,11,8);ctx.strokeStyle='#6a66a0';ctx.lineWidth=1;ctx.strokeRect(x0+10.5+i*14,y+20.5,10,7);}
      txt(n.eff,x0+10,y+42,{size:8,col:'#b9b4d8',bold:false});
      uiButton(x0+W-78,y+9,70,32,why==='MAX'?'MAX':can?'LEARN '+n.cost:why,can,buy,{tag:'skill:'+n.id,clip:true,size:why&&why!=='MAX'?8:11,sel:si});
    }};
}
UI_MODES.skills={title:()=>'SKILLS',sub:()=>[`Points: ${skillPoints()}    Lv ${P.lv}    Gold ${P.gold} G`,skillPoints()?'#7dffa0':'#cfd0ff'],rows(){
  const r=[{t:'head',s:'STATS   (1 point per level)'}];
  SKILL_NODES.filter(n=>n.g==='STATS').forEach(n=>r.push(skillRow(n)));
  r.push({t:'head',s:'SPELL SCHOOLS   (passive perks for that school\'s cards)'});
  SKILL_NODES.filter(n=>n.g==='SCHOOL').forEach(n=>r.push(skillRow(n)));
  const rc=respecCost();
  r.push({sel:true,h:40,act(){if(!rc)uiMsg('Nothing to reset');else if(!respecSkills())uiMsg('Need '+rc+' G');else{uiMsg('Skills reset',false);saveGame('skill');}},
    tap(){this.act();},
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#120f26';ctx.fillRect(x0,y,W,h);txt('RESET ALL SKILLS',x0+10,y+17,{size:10,col:'#ffb0a0',lw:2});txt(rc?'Refund every point for '+rc+' G':'Nothing to reset',x0+10,y+32,{size:8,col:'#9aa0ff',bold:false});
      uiButton(x0+W-78,y+5,70,30,rc?rc+' G':'--',!!rc&&P.gold>=rc,()=>{UI.sel=si;if(respecSkills()){uiMsg('Skills reset',false);saveGame('skill');}else uiMsg(rc?'Need '+rc+' G':'Nothing to reset');},{tag:'respec',clip:true,size:10,bg:'#7a2e3a',bd:'#ff9aa8',sel:si});}});
  return r;}};
