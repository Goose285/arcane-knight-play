/* =====================================================================
   FISHING SCREEN (pause menu "FISHING" / Fisher Tobin): your catch - sell for gold or cook & eat to heal; rod + spot info.
   Rods are sold at Brum's forge (rodRow, used by the shop screen).
   ===================================================================== */
UI_STATES.push('fish');
/* t138u: fishing gives fish, not gold - fish are SOLD at the fishmonger (Fisher Tobin), priced by rarity */
const FSH_SHOP={on:false};
function openFishing(from,shop){FSH_SHOP.on=!!shop;openUIMode('fish',from);}
function sellFish(id,all){
  const f=FISH_BY[id],n=FSH.fish[id]|0;if(!f||n<=0)return 0;if(!FSH_SHOP.on){uiMsg('Sell fish to Fisher Tobin, the fishmonger by the river');sfx('clang');return 0;}const k=all?n:1,g=Math.round(f.price*k*(f.junk?1:1+.04*fishLv()));
  FSH.fish[id]=n-k;if(!FSH.fish[id])delete FSH.fish[id];P.gold+=g;sfx('coin');saveGame('fish');return g;
}
function eatFish(id){
  const f=FISH_BY[id];if(!f||f.junk||!(FSH.fish[id]>0))return -1;
  if(P.hp>=maxHp())return -2;
  const h=Math.max(1,Math.ceil(maxHp()*f.heal));P.hp=Math.min(maxHp(),P.hp+h);FSH.fish[id]--;if(!FSH.fish[id])delete FSH.fish[id];sfx('heal');saveGame('fish');return h;
}
const sellAllValue=()=>Object.keys(FSH.fish).reduce((a,k)=>{const f=FISH_BY[k];return a+(f?Math.round(f.price*FSH.fish[k]*(f.junk?1:1+.04*fishLv())):0);},0);
function fishRow(f){
  const n=FSH.fish[f.id]|0,val=Math.round(f.price*(f.junk?1:1+.04*fishLv()));
  const sell=()=>{const g=sellFish(f.id,false);if(g)uiMsg('Sold '+f.n+' for '+g+' G',false);};
  const eat=()=>{const h=eatFish(f.id);if(h===-2){uiMsg('You are already at full health');sfx('clang');}else if(h>0)uiMsg('Cooked & ate '+f.n+'  +'+h+' HP',false);};
  return {sel:true,h:52,act:which=>{if(which==='minus')eat();else sell();},tap:sell,
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=f.col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      ctx.fillStyle='#0c0a1c';ctx.fillRect(x0+6,y+10,32,32);draw(SP.fishIcon,x0+6,y+10,2);ctx.globalAlpha=.55;ctx.fillStyle=f.col;ctx.fillRect(x0+6,y+10,32,32);ctx.globalAlpha=1;draw(SP.fishIcon,x0+6,y+10,2);
      txt(f.n+'  x'+n,x0+46,y+17,{size:10,col:f.col,lw:2});
      txt(f.junk?'Junk - sells for a little':'Heals '+Math.round(f.heal*100)+'% HP when cooked   Sells '+val+' G',x0+46,y+30,{size:7,col:'#b9b4d8',bold:false,lw:2});
      txt(f.junk?'':FISH_RARITY[f.rar].n+'  -  Fishing XP '+f.xp,x0+46,y+43,{size:7,col:f.junk?'#7df9ff':FISH_RARITY[f.rar].col,bold:false,lw:2});
      if(!f.junk)uiButton(x0+W-150,y+11,70,30,'COOK',P.hp<maxHp(),()=>{UI.sel=si;eat();},{tag:'eat:'+f.id,clip:true,size:9,sel:si,bg:'#7a4a1a',bd:'#ffb86b'});
      uiButton(x0+W-74,y+11,66,30,FSH_SHOP.on?'SELL '+val:val+' G',FSH_SHOP.on,()=>{UI.sel=si;sell();},{tag:'sell:'+f.id,clip:true,size:9,sel:si});}};
}
UI_MODES.fish={title:()=>'FISHING',sub:()=>{const [a,b]=fishXpInto();return [`Lv ${fishLv()}${fishLv()>=FISH_MAX_LV?' (MAX)':'   XP '+a+'/'+b}   Rod: ${FSH.rod>=0?RODS[FSH.rod].n:'none (Brum sells them)'}   Gold ${P.gold}`,'#7df9ff'];},rows(){
  const r=[];
  r.push({t:'head',s:'FISHING SPOTS  (tap rippling water: cast once, fish bite on their own)'});
  FISH_SPOTS.forEach(s=>r.push({t:'head',s:'  '+(fishLv()>=s.lv?'+ ':'- ')+s.name+'  -  Lv '+s.lv+(fishLv()>=s.lv?'':'  (locked)')}));
  r.push({t:'head',s:FSH_SHOP.on?'YOUR CATCH  (Tobin buys fish - rarer fish pay more)':'YOUR CATCH  (cook & eat to heal - sell them to Fisher Tobin for gold)'});
  const have=FISHES.concat(FISH_JUNK).filter(f=>(FSH.fish[f.id]|0)>0);
  if(!have.length)r.push({t:'head',s:'  Nothing yet - cast a line at a rippling spot and relax!'});
  else{have.forEach(f=>r.push(fishRow(f)));if(!FSH_SHOP.on)return r;
    const all=()=>{const v=sellAllValue();if(!v){return;}Object.keys(FSH.fish).forEach(k=>sellFish(k,true));uiMsg('Sold everything for '+v+' G',false);};
    r.push({sel:true,h:44,act:all,tap:all,draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle='#ffd23f';ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      txt('SELL EVERYTHING',x0+14,y+19,{size:10,col:'#fff',lw:2});txt('Keep a few to cook!  (Silver Scales are for crafting)',x0+14,y+33,{size:7,col:'#b9b4d8',bold:false,lw:2});
      uiButton(x0+W-110,y+7,102,30,'SELL ALL '+sellAllValue(),sellAllValue()>0,()=>{UI.sel=si;all();},{tag:'sellall',clip:true,size:9,sel:si});}});}
  return r;}};
/* Brum's shop: fishing rods */
function rodRow(i){
  const r=RODS[i],own=FSH.rod>=i,eq=FSH.rod===i,pr=rodPrice(r),can=!own&&P.gold>=pr;
  const go=()=>{if(own){uiMsg(eq?'Already your rod':'You have a better rod',false);return;}
    if(buyRod(i)){sfx('level');uiMsg('Bought '+r.n+'!',false);saveGame('rod');}else{uiMsg('Not enough gold');sfx('clang');}};
  return {sel:true,h:50,act:go,tap:go,
    draw(x0,y,W,h,isSel,si){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=r.col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      ctx.fillStyle='#0c0a1c';ctx.fillRect(x0+6,y+9,32,32);draw(SP.rodIcon,x0+6,y+9,2);
      txt(r.n,x0+46,y+15,{size:10,col:r.col,lw:2});txt(r.desc,x0+46,y+28,{size:7,col:'#b9b4d8',bold:false,lw:2});
      txt(own?(eq?'EQUIPPED':'owned'):pr+' G',x0+46,y+42,{size:8,col:own?(eq?'#7dffa0':'#b9b4d8'):P.gold>=pr?'#ffd23f':'#ff9a9a',lw:2});
      uiButton(x0+W-74,y+10,66,30,own?'OWNED':'BUY',can,()=>{UI.sel=si;go();},{tag:'rod:'+r.id,clip:true,size:9,sel:si});}};
}
