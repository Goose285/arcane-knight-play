/* =====================================================================
   EQUIPMENT SCREEN (pause menu -> EQUIPMENT) + gear drawn on the hero
   ===================================================================== */
const gearIcon=it=>it.slot==='armor'?SP.ic.g_armor:it.slot==='ring'?SP.ic.g_ring:SP.ic.sword;
function openGear(){openUIMode('gear');}
function gearIconBox(x,y,it,sz=32){
  const c=it?GEAR_RAR[it.rar].col:'#3a3660';ctx.fillStyle=it?c:'#1d1a38';ctx.fillRect(x,y,sz,sz);ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(x,y,sz,8);
  if(it){draw(gearIcon(it),x+1,y+1,sz/16);ctx.globalAlpha=.35;draw(tintOf(gearIcon(it),c),x+1,y+1,sz/16);ctx.globalAlpha=1;}
}
function slotRow(slot){
  const it=GEAR.eq[slot];
  return {sel:true,h:46,act(){if(!it){uiMsg('Nothing equipped');return;}if(unequipGear(slot)){sfx('select');saveGame('gear');}else uiMsg('Backpack is full');},
    draw(x0,y,W,h,isSel,si){
      ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=it?GEAR_RAR[it.rar].col:'#4a4470';ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      gearIconBox(x0+7,y+7,it);
      txt(GEAR_SLOT_NAME[slot],x0+48,y+13,{size:8,col:'#9aa0ff',lw:2});
      if(it){txt(`${it.name}  Lv${it.lv}`,x0+48,y+26,{size:10,col:GEAR_RAR[it.rar].col,lw:2});txt(gearStatLine(it),x0+48,y+39,{size:8,col:'#cfd0ff',bold:false});
        uiButton(x0+W-74,y+9,66,28,'REMOVE',true,()=>{UI.sel=si;if(unequipGear(slot)){sfx('select');saveGame('gear');}else uiMsg('Backpack is full');},{tag:'unequip:'+slot,clip:true,size:10,bg:'#7a2e3a',bd:'#ff9aa8',sel:si});}
      else txt('- empty -',x0+48,y+31,{size:10,col:'#6a6690'});
    }};
}
function statsRow(){
  return {h:46,draw(x0,y,W,h){
    const s=gearStats();ctx.fillStyle='#2a1a12';ctx.fillRect(x0,y,W,h);
    const cells=[['SHOT',arcaneDmg(),'#ffe14d'],['HP',maxHp(),'#7dffa0'],['DEF',s.def,'#9ad0ff'],['DEAL','+'+Math.round(s.gauge*100)+'%','#ffb86b'],['CRIT',Math.round((.05+s.crit)*100)+'%','#ff8a8a']];
    const cw=W/cells.length;cells.forEach((c,i)=>{txt(c[0],x0+cw*(i+.5),y+16,{size:8,align:'center',col:'#9aa0ff',lw:2});txt(String(c[1]),x0+cw*(i+.5),y+36,{size:14,align:'center',col:c[2],lw:3});});
  }};
}
function itemRow(it){
  const eq=GEAR.eq[it.slot],diff=gearScore(it)-gearScore(eq),col=GEAR_RAR[it.rar].col;
  const doEq=()=>{if(equipGear(it)){sfx('select');uiMsg('Equipped '+it.name,false);saveGame('gear');}};
  return {sel:true,h:56,act:doEq,tap:doEq,
    draw(x0,y,W,h,isSel,si){
      ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      gearIconBox(x0+7,y+12,it);
      txt(it.name,x0+48,y+14,{size:10,col,lw:2});
      txt(`${GEAR_RAR[it.rar].n} ${GEAR_SLOT_NAME[it.slot]}  Lv${it.lv}`,x0+48,y+26,{size:8,col:'#b9b4d8',lw:2});
      txt(gearStatLine(it),x0+48,y+37,{size:8,col:'#cfd0ff',bold:false});
      txt(!eq?'NEW SLOT':diff>0.01?'UPGRADE':diff<-0.01?'weaker':'same',x0+48,y+49,{size:8,col:!eq||diff>0.01?'#7dffa0':diff<-0.01?'#ff9a9a':'#9aa0ff',lw:2});
      uiButton(x0+W-78,y+5,70,23,'EQUIP',true,()=>{UI.sel=si;if(equipGear(it)){sfx('select');uiMsg('Equipped '+it.name,false);saveGame('gear');}},{tag:'equip:'+it.id,clip:true,size:11,sel:si});
      uiButton(x0+W-78,y+30,70,21,'SELL '+gearSell(it),true,()=>{UI.sel=si;const g=sellGear(it);sfx('coin');uiMsg(`Sold for ${g} G`,false);saveGame('gear');},{tag:'sell:'+it.id,clip:true,size:9,bg:'#6a5a1a',bd:'#ffd23f',sel:si});
    }};
}
/* ---- t143u: two pages - BACKPACK (every item with green / red stat changes vs what you wear, EQUIP right there) and EQUIPPED
   (only the slots the game has: weapon, armor, ring) where each slot can REMOVE or COMPARE (lists the backpack items for that slot) ---- */
const GEARV={tab:'bag',cmp:null};
function gearDeltas(it,eq){const ks=new Set([...Object.keys(it.st),...Object.keys(eq?eq.st:{})]),o=[];
  for(const k of ks){const d=(it.st[k]||0)-(eq&&eq.st[k]||0);if(Math.abs(d)<1e-6)continue;const pct=k==='gauge'||k==='crit';o.push({k,d,s:(d>0?'+':'-')+(pct?Math.round(Math.abs(d)*100)+'%':Math.round(Math.abs(d)))+' '+GEAR_STAT_LABEL[k]});}
  return o;}
function drawDeltas(list,x,y,maxW){let cx=x;ctx.font='bold '+scaleText(8)+'px "Courier New",monospace';
  if(!list.length){txt('no change',x,y,{size:8,col:'#b9b4d8',lw:2});return;}
  for(const q of list){const w=ctx.measureText(q.s).width+8;if(cx+w>x+maxW)break;txt(q.s,cx,y,{size:8,col:q.d>0?'#7dff8a':'#ff7a7a',lw:2});cx+=w;}}
function tabRow(){return {h:36,draw(x0,y,W,h){const bw=(W-12)/2;
  uiButton(x0+4,y+4,bw,28,'BACKPACK ('+GEAR.inv.length+')',GEARV.tab==='bag',()=>{GEARV.tab='bag';GEARV.cmp=null;UI.scroll=0;sfx('select');},{tag:'gtab:bag',clip:true,size:11,bg:'#6b4423',bd:'#f0cf7a'});
  uiButton(x0+8+bw,y+4,bw,28,'EQUIPPED SLOTS',GEARV.tab==='worn',()=>{GEARV.tab='worn';UI.scroll=0;sfx('select');},{tag:'gtab:worn',clip:true,size:11,bg:'#6b4423',bd:'#f0cf7a'});}};}
const doEquip=it=>{if(equipGear(it)){sfx('select');uiMsg('Equipped '+it.name,false);saveGame('gear');}};
function bagRow(it){
  const eq=GEAR.eq[it.slot],col=GEAR_RAR[it.rar].col,dl=gearDeltas(it,eq),diff=gearScore(it)-gearScore(eq);
  return {sel:true,h:60,act:()=>doEquip(it),tap:()=>doEquip(it),
    draw(x0,y,W,h,isSel,si){
      ctx.fillStyle=isSel?'#3a2618':'#2a1a12';ctx.fillRect(x0,y,W,h);ctx.fillStyle=col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      gearIconBox(x0+8,y+13,it);
      txt(it.name,x0+48,y+14,{size:10,col,lw:2});
      txt(`${GEAR_RAR[it.rar].n} ${GEAR_SLOT_NAME[it.slot]}  Lv${it.lv}`+(eq?'   vs '+eq.name:'   (slot empty)'),x0+48,y+26,{size:8,col:'#d8c8a8',lw:2});
      drawDeltas(dl,x0+48,y+40,W-140);
      txt(!eq?'NEW SLOT':diff>0.01?'UPGRADE':diff<-0.01?'WEAKER':'SAME',x0+48,y+53,{size:8,col:!eq||diff>0.01?'#7dff8a':diff<-0.01?'#ff7a7a':'#b9b4d8',lw:2});
      uiButton(x0+W-82,y+5,74,26,'EQUIP',true,()=>{UI.sel=si;doEquip(it);},{tag:'equip:'+it.id,clip:true,size:11,sel:si});
      uiButton(x0+W-82,y+34,74,21,'SELL '+gearSell(it),true,()=>{UI.sel=si;const g=sellGear(it);sfx('coin');uiMsg(`Sold for ${g} G`,false);saveGame('gear');},{tag:'sell:'+it.id,clip:true,size:9,bg:'#6a5a1a',bd:'#ffd23f',sel:si});
    }};
}
function wornRow(slot){
  const it=GEAR.eq[slot],n=GEAR.inv.filter(q=>q.slot===slot).length,open=GEARV.cmp===slot;
  return {sel:true,h:50,act(){GEARV.cmp=open?null:slot;},
    draw(x0,y,W,h,isSel,si){
      ctx.fillStyle=isSel||open?'#3a2618':'#2a1a12';ctx.fillRect(x0,y,W,h);ctx.fillStyle=it?GEAR_RAR[it.rar].col:'#6b5a48';ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      gearIconBox(x0+8,y+9,it);txt(GEAR_SLOT_NAME[slot],x0+48,y+13,{size:8,col:'#f0cf7a',lw:2});
      if(it){txt(`${it.name}  Lv${it.lv}`,x0+48,y+27,{size:10,col:GEAR_RAR[it.rar].col,lw:2});txt(gearStatLine(it),x0+48,y+41,{size:8,col:'#e8dcc0',bold:false});}
      else txt('- empty -',x0+48,y+31,{size:10,col:'#8a7a68'});
      const bw=70;
      uiButton(x0+W-bw*2-14,y+11,bw,28,open?'CLOSE':'COMPARE'+(n?' '+n:''),n>0||open,()=>{UI.sel=si;GEARV.cmp=open?null:slot;sfx('select');},{tag:'cmp:'+slot,clip:true,size:10,bg:'#2a4a6a',bd:'#9ad0ff',sel:si});
      uiButton(x0+W-bw-6,y+11,bw,28,'REMOVE',!!it,()=>{UI.sel=si;if(!it)return;if(unequipGear(slot)){sfx('select');saveGame('gear');}else uiMsg('Backpack is full');},{tag:'unequip:'+slot,clip:true,size:10,bg:'#7a2e3a',bd:'#ff9aa8',sel:si});
    }};
}
UI_MODES.gear={title:()=>'EQUIPMENT',sub:()=>[`Gold ${P.gold} G    Backpack ${GEAR.inv.length}/${INV_MAX}`,'#ffd23f'],rows(){
  const r=[tabRow(),{t:'head',s:'YOUR STATS'},statsRow()];
  const sorted=list=>list.slice().sort((a,b)=>(gearScore(b)-gearScore(GEAR.eq[b.slot]))-(gearScore(a)-gearScore(GEAR.eq[a.slot]))||b.lv-a.lv);
  if(GEARV.tab==='worn'){r.push({t:'head',s:'EQUIPPED  (compare / remove)'});
    for(const s of GEAR_SLOTS){r.push(wornRow(s));if(GEARV.cmp===s){const l=sorted(GEAR.inv.filter(q=>q.slot===s));if(!l.length)r.push({t:'head',s:'    nothing in the backpack for this slot'});l.forEach(it=>r.push(bagRow(it)));}}
    return r;}
  r.push({t:'head',s:'BACKPACK  (green = better than what you wear)'});
  const inv=sorted(GEAR.inv);
  if(!inv.length)r.push({t:'head',s:'  (empty - defeat monsters to find gear)'});
  inv.forEach(it=>r.push(bagRow(it)));return r;}};
/* ---- gear visible on the hero: armor tints the tunic, the weapon is held in hand, rings sparkle, legendary gear glows ---- */
function drawGearOnPlayer(spr,px,py){
  const w=GEAR.eq.weapon,a=GEAR.eq.armor,r=GEAR.eq.ring;if(!w&&!a&&!r)return;
  const leg=GEAR_SLOTS.some(s=>GEAR.eq[s]&&GEAR.eq[s].rar==='legendary');
  if(leg){ctx.save();ctx.globalAlpha=.25+.12*Math.sin(gtime*5);ctx.fillStyle='#ffb02e';ctx.beginPath();ctx.ellipse(px+16,py+31,17,6,0,0,6.283);ctx.fill();ctx.restore();}
  if(a){ctx.fillStyle='rgba(0,0,0,.45)';ctx.fillRect(px+13,py+21,7,3);ctx.fillStyle=GEAR_RAR[a.rar].col;ctx.fillRect(px+14,py+21,5,2);}   // t143u: armor = a small rarity-coloured belt clasp (the old whole-body tint turned the hero green with uncommon armor)
  if(w){const c=GEAR_RAR[w.rar].col,d=P.dir,sx=d==='l'?px-10:d==='r'?px+19:d==='u'?px+20:px+19,sy=d==='u'?py+10:py+13;
    ctx.save();draw(SP.ic.sword,sx,sy,1.5,d==='l');ctx.globalAlpha=.55;draw(tintOf(SP.ic.sword,c),sx,sy,1.5,d==='l');ctx.restore();
    if(w.rar==='epic'||w.rar==='legendary'){ctx.fillStyle=c;const k=(gtime*3)%1;ctx.globalAlpha=1-k;ctx.fillRect(Math.round(sx+4+Math.sin(gtime*9)*5),Math.round(sy+4-k*10),2,2);ctx.globalAlpha=1;}}
  if(r&&(r.rar==='rare'||r.rar==='epic'||r.rar==='legendary')){ctx.fillStyle=GEAR_RAR[r.rar].col;ctx.globalAlpha=.5+.5*Math.sin(gtime*8);ctx.fillRect(px+(P.dir==='l'?4:22),py+22,2,2);ctx.globalAlpha=1;}
}
