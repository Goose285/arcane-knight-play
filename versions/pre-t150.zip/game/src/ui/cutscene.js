/* =====================================================================
   CUTSCENE ENGINE: a portrait-dialogue overlay riding on DLG (so every existing
   freeze / touch-tap rule still applies). DLG.cut=true, DLG.steps=[...], DLG.opts when a choice is shown.
   ===================================================================== */
function wrapText(s,maxW,font){ctx.font=font;const out=[];let line='';for(const wd of s.split(' ')){const t=line?line+' '+wd:wd;if(ctx.measureText(t).width>maxW&&line){out.push(line);line=wd;}else line=t;}if(line)out.push(line);return out;}
function startCut(id,onEnd,custom){
  const raw=custom||CUTS[id];if(!raw||DLG)return false;
  const steps=raw.filter(s=>!s.if||s.if(STORY));
  DLG={cut:id,name:'',steps,lines:steps.map(s=>s.t),i:0,c:0,sel:0,onEnd:onEnd||null,t:0};
  if(CUTS[id])STORY.cutting=id;sfx('select');return true;
}
function cutSetSteps(d){d.lines=d.steps.map(s=>s.t);}
function cutEnd(d){
  const id=d.cut;DLG=null;if(CUTS[id])STORY.cutting=null;
  if(d.onEnd)d.onEnd(id);
}
function updateCut(d,dt){
  d.t+=dt;
  const st=d.steps[d.i],line=st.t;
  if(d.c<line.length){d.c=Math.min(line.length,d.c+dt*55);if(((d.c|0)%3)===0&&Math.random()<.4)sfx('talk');}
  const full=d.c>=line.length;
  if(st.ch&&full){
    const n=st.ch.length;
    if(hit('ArrowUp','KeyW'))d.sel=(d.sel+n-1)%n;
    if(hit('ArrowDown','KeyS'))d.sel=(d.sel+1)%n;
    for(let k=0;k<n;k++)if(hit('Digit'+(k+1)))d.sel=k;
    if(hit('Enter','Space','KeyE','KeyJ')){
      const o=st.ch[d.sel];if(!o)return;
      storyApply(o.do);if(o.fn)o.fn();sfx('select');if(CUTS[d.cut])STORY.choices.push({ch:d.cut,t:o.t});
      d.steps.splice(d.i+1,0,...(o.then||[]).filter(s=>!s.if||s.if(STORY)));st.ch=null;st.picked=o.t;cutSetSteps(d);
      d.i++;d.c=0;d.sel=0;if(d.i>=d.steps.length)cutEnd(d);
    }
    return;
  }
  if(hit('Enter','KeyE','Space','KeyJ')){
    if(!full)d.c=line.length;
    else if(d.i<d.steps.length-1){d.i++;d.c=0;d.sel=0;}
    else cutEnd(d);
  }
}
function drawCut(d){
  const st=d.steps[d.i],who=WHO[st.w]||WHO.narr,a=Math.min(1,d.t*2.2);
  const bar=Math.round(34*a);
  ctx.fillStyle=`rgba(4,4,14,${.55*a})`;ctx.fillRect(0,0,VW,VH);
  ctx.fillStyle='#000';ctx.fillRect(0,0,VW,ST+bar);ctx.fillRect(0,VH-SB-bar,VW,SB+bar);
  const L=SL+12,W=VW-SL-SR-24,fs=Math.round(13*(1+(TXS-1)*1.4)),lh=Math.round(fs*1.32),font='bold '+fs+'px "Courier New",monospace',all=wrapText(st.t,W-96,font);let left=Math.floor(d.c);const lines=[];for(const l of all){if(left<=0)break;lines.push(l.slice(0,left));left-=l.length+1;}
  const full=d.c>=st.t.length,opts=full&&st.ch?st.ch:null;
  const bh=Math.max(96,30+all.length*lh+8),by=VH-SB-bar-bh-(TOUCH?(VH>VW?130:8):10);
  dlgRects={box:{x:L,y:by,w:W,h:bh}};
  // portrait frame
  const ps=72,px=L,py=by-ps-24;
  panel(px-3,py-3,ps+6,ps+6+18,{fill:'#10122a'});
  const img=SP.port[st.w]||SP.port.narr;
  ctx.save();ctx.fillStyle='#1c2048';ctx.fillRect(px,py,ps,ps);ctx.imageSmoothingEnabled=false;
  if(st.w==='aldric'){const gl=.5+.5*Math.sin(gtime*3);ctx.fillStyle=`rgba(125,255,160,${.12+.1*gl})`;ctx.fillRect(px,py,ps,ps);}
  ctx.drawImage(img,px,py+Math.round(Math.sin(gtime*2)*1),ps,ps);ctx.restore();
  txt(who.n||'...',px+ps/2,py+ps+14,{size:8,col:who.col,align:'center',lw:2});
  // text box
  panel(L,by,W,bh,{});
  let ly=by+24;for(const l of lines){txt(l,L+14,ly,{size:fs,out:false});ly+=lh;}
  if(full&&!st.ch&&Math.floor(gtime*3)%2===0)txt(TOUCH?'tap v':'v',L+W-16,by+bh-10,{size:12,col:'#ffe14d',out:false,align:TOUCH?'right':'left'});
  // choices
  if(opts){
    dlgRects.opts=[];const oh=30,gap=6,ow=Math.min(W-92,380),ox=L+W-ow;let oy=by-opts.length*(oh+gap)-4;
    for(let k=0;k<opts.length;k++){
      const r={x:ox,y:oy,w:ow,h:oh},sel=k===d.sel;dlgRects.opts.push(r);
      panel(r.x,r.y,r.w,r.h,{fill:sel?'#2a4a8a':'#14183a'});
      const ol=wrapText((TOUCH?'':(k+1)+'. ')+opts[k].t,ow-16,'bold 11px "Courier New",monospace');
      txt(ol[0]+(ol[1]?'..':''),r.x+8,r.y+19,{size:11,col:sel?'#fff':'#c8d0ff',out:false});
      oy+=oh+gap;
    }
  }
}
