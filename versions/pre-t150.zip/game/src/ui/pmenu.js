/* =====================================================================
   PAUSE MENU (t138u restyle, after the concept sheet): a dark-wood tab bar with icon tabs (active tab GREEN), a cream parchment
   panel in a dark wood frame with gold corner brackets and a teal gem, bold dark-brown titles, green pill buttons with icons
   (RESUME / HOME / SAVE & QUIT), card art tiles with red - / green + buttons, recessed slot grids.
   Tabs: CHARACTER CARDS INVENTORY JOURNAL WORLD SKILLS SETTINGS.  Rect ids are stable for tests / keyboard.
   ===================================================================== */
const PM_TABS=[['character','CHARACTER','hero'],['cards','CARDS','cards'],['inventory','INVENTORY','bag'],['journal','JOURNAL','scroll'],['world','WORLD','map'],['skills','SKILLS','plus'],['settings','SETTINGS','cog']];
const PM={tab:'inventory',cat:'potions',card:null,scroll:0,sel:null};
const PMC={ink:'#3a2210',ink2:'#7a5a3a',parch:'#f4e4c1',parch2:'#e8d2a4',edge:'#b08a5a',wood:'#6b4022',wood2:'#3a2010',woodL:'#8a5a32',gold:'#e8b84a',goldD:'#8a5a10',green:'#3f8f3a',greenL:'#7cd06a',greenD:'#1f4a1c',red:'#b8423a',redD:'#5a1a14'};
function pmText(s,x,y,o){txt(s,x,y,Object.assign({size:10,col:PMC.ink,lw:0,out:false},o||{}));}
function rr(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.lineTo(x+w-r,y);ctx.quadraticCurveTo(x+w,y,x+w,y+r);ctx.lineTo(x+w,y+h-r);ctx.quadraticCurveTo(x+w,y+h,x+w-r,y+h);ctx.lineTo(x+r,y+h);ctx.quadraticCurveTo(x,y+h,x,y+h-r);ctx.lineTo(x,y+r);ctx.quadraticCurveTo(x,y,x+r,y);ctx.closePath();}
function pmFit(lab,w,sz,min){ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';while(sz>(min||6)&&ctx.measureText(lab).width>w){sz--;ctx.font='bold '+scaleText(sz)+'px "Courier New",monospace';}return sz;}
/* extra icons (10x10 grid) on top of pauseIcon */
function pmIcon(id,x,y,s){
  const r=(a,b,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(x+a*s,y+b*s,w*s,h*s);};
  switch(id){
    case 'paw':r(0,3,2,3,'#b8743a');r(8,3,2,3,'#b8743a');r(2,0,2,3,'#b8743a');r(6,0,2,3,'#b8743a');r(3,5,4,4,'#b8743a');r(2,6,6,3,'#b8743a');r(4,6,2,1,'#e8a868');break;
    case 'play':r(1,0,2,10,'#fff8e0');r(3,1,2,8,'#fff8e0');r(5,2,2,6,'#fff8e0');r(7,3,2,4,'#fff8e0');r(9,4,1,2,'#fff8e0');break;
    case 'plus':r(3,0,4,10,'#ffd84a');r(0,3,10,4,'#ffd84a');r(4,1,2,8,'#fff3a0');r(1,4,8,2,'#fff3a0');break;
    case 'potion':r(4,0,2,1,'#8a5a32');r(3,1,4,2,'#d8d8e8');r(1,3,8,7,'#d8323a');r(2,4,2,2,'#ff9a9a');r(1,8,8,2,'#901a20');break;
    case 'gem':r(1,3,3,6,'#4a8aff');r(4,1,3,8,'#7ab8ff');r(7,4,2,5,'#3a6ad8');r(5,2,1,3,'#e0f0ff');break;
    case 'key':r(0,1,4,4,'#e8b84a');r(1,2,2,2,'#6b4022');r(4,2,6,2,'#e8b84a');r(7,4,1,2,'#e8b84a');r(9,4,1,3,'#e8b84a');break;
    case 'cal':r(0,1,10,9,'#f4f0e8');r(0,1,10,3,'#d8323a');r(2,0,1,2,'#3a2210');r(7,0,1,2,'#3a2210');for(let i=0;i<3;i++)for(let j=0;j<2;j++)r(1+i*3,5+j*2,2,1,'#d8323a');break;
    case 'swords':r(0,0,2,2,'#dfe9f2');r(2,2,2,2,'#dfe9f2');r(4,4,2,2,'#bfc8d8');r(8,0,2,2,'#dfe9f2');r(6,2,2,2,'#dfe9f2');r(1,7,2,2,'#a8741a');r(7,7,2,2,'#a8741a');r(0,9,2,1,'#6b4022');r(8,9,2,1,'#6b4022');break;
    case 'speaker':r(0,3,3,4,'#3a2210');r(3,2,2,6,'#3a2210');r(5,1,1,8,'#3a2210');r(7,3,1,4,'#3a2210');r(9,2,1,6,'#3a2210');break;
    case 'note':r(2,0,6,2,'#3a2210');r(2,0,1,8,'#3a2210');r(7,0,1,7,'#3a2210');r(0,7,3,3,'#3a2210');r(5,6,3,3,'#3a2210');break;
    case 'bars':r(0,6,2,4,'#3a2210');r(3,4,2,6,'#3a2210');r(6,2,2,8,'#3a2210');r(9,0,1,10,'#3a2210');break;
    case 'pencil':r(7,0,3,3,'#e8b84a');r(5,2,3,3,'#e8d8a0');r(3,4,3,3,'#e8d8a0');r(1,6,3,3,'#e8d8a0');r(0,9,2,1,'#3a2210');break;
    case 'excl':ctx.fillStyle='#d8323a';ctx.beginPath();ctx.arc(x+5*s,y+5*s,5*s,0,6.283);ctx.fill();r(4,2,2,4,'#fff');r(4,7,2,1,'#fff');break;
    case 'check':r(0,5,2,2,'#2f8a2a');r(2,7,2,2,'#2f8a2a');r(4,5,2,2,'#2f8a2a');r(6,3,2,2,'#2f8a2a');r(8,1,2,2,'#2f8a2a');break;
    case 'lock':r(2,0,6,1,'#5a5a66');r(2,0,1,4,'#5a5a66');r(7,0,1,4,'#5a5a66');r(1,4,8,6,'#7a7a88');r(4,6,2,2,'#2a2a30');break;
    case 'arrow':r(2,0,2,10,'#fff3d0');r(4,2,2,6,'#fff3d0');r(6,4,2,2,'#fff3d0');break;
    case 'larrow':r(6,0,2,10,'#fff3d0');r(4,2,2,6,'#fff3d0');r(2,4,2,2,'#fff3d0');break;
    case 'coin':ctx.fillStyle='#8a5a10';ctx.beginPath();ctx.arc(x+5*s,y+5*s,5*s,0,6.283);ctx.fill();ctx.fillStyle='#ffd23f';ctx.beginPath();ctx.arc(x+5*s,y+5*s,4*s,0,6.283);ctx.fill();r(4,2,2,6,'#e0a020');break;
    default:pauseIcon(id,x,y,s);
  }
}
function pmCorners(x,y,w,h,k){k=k||7;for(const [cx,cy,sx,sy] of [[x,y,1,1],[x+w,y,-1,1],[x,y+h,1,-1],[x+w,y+h,-1,-1]]){
  ctx.fillStyle=PMC.goldD;ctx.fillRect(cx-sx*1-(sx<0?k+2:0)+ (sx<0?0:0),cy-(sy<0?k+1:1),k+2,k+2);
  ctx.fillStyle=PMC.gold;ctx.fillRect(sx>0?cx:cx-k,sy>0?cy:cy-k,k,k);ctx.fillStyle='#fff0a0';ctx.fillRect(sx>0?cx+1:cx-k+1,sy>0?cy+1:cy-k+1,2,2);
  ctx.fillStyle=PMC.wood2;ctx.fillRect(sx>0?cx+3:cx-k+3,sy>0?cy+3:cy-k+3,k-4,k-4);ctx.fillStyle=PMC.gold;ctx.fillRect(sx>0?cx+3:cx-k+3,sy>0?cy+3:cy-k+3,2,2);}}
function pmWood(x,y,w,h){rr(x,y,w,h,6);ctx.fillStyle=PMC.wood2;ctx.fill();rr(x+3,y+3,w-6,h-6,4);ctx.fillStyle=PMC.wood;ctx.fill();
  ctx.save();rr(x+3,y+3,w-6,h-6,4);ctx.clip();for(let i=0;i<h;i+=5){ctx.fillStyle=i%10?'rgba(0,0,0,.07)':'rgba(255,220,170,.05)';ctx.fillRect(x,y+i,w,2);}ctx.restore();
  ctx.strokeStyle='rgba(255,210,150,.25)';ctx.lineWidth=1;rr(x+3.5,y+3.5,w-7,h-7,4);ctx.stroke();}
function pmParch(x,y,w,h,r){rr(x,y,w,h,r||4);ctx.fillStyle=PMC.edge;ctx.fill();rr(x+2,y+2,w-4,h-4,(r||4)-1);ctx.fillStyle=PMC.parch;ctx.fill();
  const g=ctx.createRadialGradient(x+w/2,y+h/2,Math.min(w,h)*.3,x+w/2,y+h/2,Math.max(w,h)*.7);g.addColorStop(0,'rgba(255,250,230,0)');g.addColorStop(1,'rgba(160,110,50,.18)');rr(x+2,y+2,w-4,h-4,3);ctx.fillStyle=g;ctx.fill();}
function pmReg(x,y,w,h,e,kind){const r={x,y,w,h,e,kind:kind||'pm'};pauseRects.push(r);return r;}
const pmSel=r=>PAUSE.kbd&&pauseRects[PAUSE.sel]===r;
/* green pill with an icon */
function pmPill(x,y,w,h,lab,ic,act,id,o){o=o||{};const r=pmReg(x,y,w,h,Object.assign({id,lab,act},o));
  const c=o.col||PMC.green,cl=o.colL||PMC.greenL,cd=o.colD||PMC.greenD;
  rr(x,y,w,h,5);ctx.fillStyle=cd;ctx.fill();rr(x+2,y+2,w-4,h-4,4);ctx.fillStyle=cl;ctx.fill();rr(x+3,y+3,w-6,h-6,3);ctx.fillStyle=o.dis?'#7a7a6a':c;ctx.fill();
  ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(x+5,y+4,w-10,Math.max(2,Math.round(h*.18)));
  if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(x+1,y+1,w-2,h-2,5);ctx.stroke();}
  const is=h>=30?2:1.5,iw=ic?10*is+6:0,sz=pmFit(lab,w-iw-12,o.size||12,6),tw=ctx.measureText(lab).width,sx=x+(w-(iw+tw))/2;
  if(ic)pmIcon(ic,Math.round(sx),Math.round(y+h/2-5*is),is);
  if(o.chev){ctx.fillStyle='#fff8e0';const cx=x+w-18,cy=y+h/2;ctx.beginPath();ctx.moveTo(cx-4,cy-8);ctx.lineTo(cx+5,cy);ctx.lineTo(cx-4,cy+8);ctx.lineTo(cx-7,cy+5);ctx.lineTo(cx-1,cy);ctx.lineTo(cx-7,cy-5);ctx.fill();}
  txt(lab,sx+iw+tw/2,y+h/2+sz*.36,{size:sz,align:'center',col:'#fff8e0',lw:3,out:'#163a12'});return r;}
/* small square +/- or arrow buttons */
function pmSq(x,y,s,kind,act,id){const r=pmReg(x,y,s,s,{id,lab:kind,act});const g=kind==='+'||kind==='>'||kind==='<';
  rr(x,y,s,s,3);ctx.fillStyle=g?PMC.greenD:PMC.redD;ctx.fill();rr(x+2,y+2,s-4,s-4,2);ctx.fillStyle=g?PMC.green:PMC.red;ctx.fill();ctx.fillStyle='rgba(255,255,255,.18)';ctx.fillRect(x+3,y+3,s-6,2);
  const m=Math.round(s/2),t=Math.max(2,Math.round(s/8)),L=Math.round(s*.28);ctx.fillStyle='#fff8e0';
  if(kind==='+'){ctx.fillRect(x+m-L,y+m-t/2,2*L,t);ctx.fillRect(x+m-t/2,y+m-L,t,2*L);}else if(kind==='-')ctx.fillRect(x+m-L,y+m-t/2,2*L,t);
  else{ctx.beginPath();if(kind==='>'){ctx.moveTo(x+m-L*.6,y+m-L);ctx.lineTo(x+m+L*.8,y+m);ctx.lineTo(x+m-L*.6,y+m+L);}else{ctx.moveTo(x+m+L*.6,y+m-L);ctx.lineTo(x+m-L*.8,y+m);ctx.lineTo(x+m+L*.6,y+m+L);}ctx.fill();}
  if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x,y,s,s);}return r;}
/* cream raised tile button: icon on top, label below (Character: PETS / ACHIEVEMENTS ...) */
function pmTile(x,y,w,h,lab,ic,act,id,badge){const r=pmReg(x,y,w,h,{id,lab,act});
  rr(x,y+2,w,h,5);ctx.fillStyle='rgba(90,50,20,.35)';ctx.fill();rr(x,y,w,h,5);ctx.fillStyle=PMC.edge;ctx.fill();rr(x+2,y+2,w-4,h-4,4);ctx.fillStyle='#f8ead0';ctx.fill();
  ctx.fillStyle='rgba(160,110,50,.12)';ctx.fillRect(x+3,y+h-9,w-6,6);
  const is=h>=56?2.4:h>=44?2:1.5;pmIcon(ic,Math.round(x+w/2-5*is),Math.round(y+Math.max(4,h*.16)),is);
  const sz=pmFit(lab,w-8,10,6);pmText(lab,x+w/2,y+h-Math.max(6,h*.14),{size:sz,align:'center'});
  if(badge){ctx.fillStyle='#d8323a';ctx.beginPath();ctx.arc(x+w-8,y+8,6,0,6.283);ctx.fill();txt(badge,x+w-8,y+11,{size:8,align:'center',col:'#fff',lw:0,out:false});}
  if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(x,y,w,h,5);ctx.stroke();}return r;}
function pmTitle(s,x,y,ic){let tx=x;if(ic){pmIcon(ic,x,y-15,1.8);tx+=24;}pmText(s,tx,y,{size:17,col:'#3a2210'});
  ctx.font='bold '+scaleText(17)+'px "Courier New",monospace';const w=ctx.measureText(s).width+(tx-x)+10;
  const g=ctx.createLinearGradient(x,0,x+w+30,0);g.addColorStop(0,'rgba(120,80,40,.7)');g.addColorStop(1,'rgba(120,80,40,0)');ctx.fillStyle=g;ctx.fillRect(x,y+5,w+30,2);}
function pmGoldPill(x,y,s){ctx.font='bold '+scaleText(11)+'px "Courier New",monospace';const w=ctx.measureText(s).width+34;rr(x-w,y,w,22,10);ctx.fillStyle='#3a2210';ctx.fill();rr(x-w+1,y+1,w-2,20,9);ctx.fillStyle='#5a3418';ctx.fill();
  pmIcon('coin',x-w+5,y+3,1.6);pmText(s,x-w+26,y+15,{size:11,col:'#fff3d0'});}
function pmSlot(x,y,s,gl){rr(x,y,s,s,4);ctx.fillStyle=PMC.edge;ctx.fill();rr(x+2,y+2,s-4,s-4,3);ctx.fillStyle=gl?'#f8e8c0':PMC.parch2;ctx.fill();ctx.fillStyle='rgba(120,80,40,.15)';ctx.fillRect(x+3,y+3,s-6,3);
  if(gl){ctx.strokeStyle='#3f8f3a';ctx.lineWidth=2;rr(x+1,y+1,s-2,s-2,4);ctx.stroke();}}
function pmDraw(){
  pauseRects.length=0;
  ctx.fillStyle='rgba(10,6,2,.55)';ctx.fillRect(0,0,VW,VH);
  const L=SL+6,R=VW-SR-6,W=Math.min(R-L,700),x=Math.round((VW-W)/2),y=ST+4,H=Math.min(VH-ST-SB-8,480),tabH=Math.max(40,Math.min(56,Math.round(H*.13))),barH=Math.max(28,Math.min(36,Math.round(H*.085)));
  PM.box={x,y,W,H};
  // tab bar
  pmWood(x,y,W,tabH+10);pmCorners(x+2,y+2,W-4,tabH+6,6);
  const tw=Math.floor((W-24)/PM_TABS.length);
  PM_TABS.forEach(([id,lab,ic],i)=>{const tx=x+12+i*tw,ty=y+5,on=PM.tab===id,w=tw-4,h=tabH;
    const r=pmReg(tx,ty,w,h,{id,lab,act:()=>{PM.tab=id;PM.scroll=0;PM.card=null;PM.sel=null;sfx('select');}},'pmtab');
    rr(tx,ty,w,h,4);ctx.fillStyle=on?PMC.greenD:'#2a160a';ctx.fill();rr(tx+2,ty+2,w-4,h-4,3);ctx.fillStyle=on?PMC.greenL:'#5a3418';ctx.fill();rr(tx+3,ty+3,w-6,h-6,3);ctx.fillStyle=on?PMC.green:'#6b4022';ctx.fill();
    if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(tx,ty,w,h,4);ctx.stroke();}
    const is=h>=50&&w>=60?2:1.6;pmIcon(ic,Math.round(tx+w/2-5*is),Math.round(ty+5),is);
    const sz=pmFit(lab,w-6,9,5);txt(lab,tx+w/2,ty+h-6,{size:sz,align:'center',col:'#fff3d0',lw:2,out:on?'#163a12':'#2a160a'});
    const b=id==='journal'?pauseReadyQ()+pauseStoryNew():id==='skills'?skillPoints():id==='character'?pauseDaily():0;
    if(b){ctx.fillStyle='#d8323a';ctx.beginPath();ctx.arc(tx+w-6,ty+6,5,0,6.283);ctx.fill();}});
  // main panel
  const by=y+tabH+12,bh=H-tabH-12;pmWood(x,by,W,bh);pmCorners(x+2,by+2,W-4,bh-4,7);
  const px=x+10,py=by+10,pw=W-20,ph=bh-20;pmParch(px,py,pw,ph,5);
  ctx.save();ctx.translate(x+W/2,by+4);ctx.rotate(Math.PI/4);ctx.fillStyle='#14504a';ctx.fillRect(-7,-7,14,14);ctx.fillStyle='#3fd8c8';ctx.fillRect(-5,-5,10,10);ctx.fillStyle='#bff8f0';ctx.fillRect(-5,-5,4,4);ctx.restore();
  const cx0=px+12,cy0=py+10,cw=pw-24,ch=ph-barH-26;PM.content={x:cx0,y:cy0,w:cw,h:ch};
  ctx.save();ctx.beginPath();ctx.rect(cx0-4,cy0-4,cw+8,ch+8);ctx.clip();
  try{(PM_DRAW[PM.tab]||(()=>{}))(cx0,cy0,cw,ch);}catch(err){console.error(err);}
  ctx.restore();
  // bottom bar: green pills + small editor / sound
  const yb=py+ph-barH-8,warn=gtime-PAUSE.qAt<=3,sq=barH,gap=Math.min(26,Math.round(cw*.04)),bw=Math.min(190,Math.floor((cw-2*sq-gap*3-12)/3)),tot=bw*3+gap*2,bx=Math.round(cx0+(cw-2*sq-8-tot)/2);
  pmPill(bx,yb,bw,barH,'RESUME','play',()=>{pressed.KeyP=true;},'resume');
  pmPill(bx+bw+gap,yb,bw,barH,HOME.cd>0?'HOME '+Math.ceil(HOME.cd)+'s':'HOME','home',()=>pauseGo('KeyH2'),'home');
  pmPill(bx+2*(bw+gap),yb,bw,barH,warn?'TAP AGAIN':'SAVE & QUIT','door',pauseQuit,'quit',{quit:true});
  const ex=cx0+cw-2*sq-4;
  pmTile(ex,yb,sq,sq,'EDIT','pencil',()=>edOpen(),'editor');
  pmTile(ex+sq+4,yb,sq,sq,muted?'OFF':'ON','speaker',()=>{muted=!muted;sfx('select');},'sound');
}
/* ---------- tab contents ---------- */
const CARD_TINT={sword:'#6aa8f0',fire:'#f08a4a',shield:'#5ac06a',heal:'#5ac06a',lance:'#b08ae0'};
function cardTint(id){const c=CARD[id];return CARD_TINT[id]||(c&&c.col)||RAR[c.rar].col;}
const PM_DRAW={
  character(x,y,w,h){
    const ps=Math.min(h-10,Math.round(w*.24),150);pmParch(x,y,ps,ps,4);rr(x+4,y+4,ps-8,ps-8,3);ctx.fillStyle='#2f5a3a';ctx.fill();
    try{const sc=(ps-14)/24;draw(SP.port.hero,x+7,y+7,sc);}catch(e){}pmCorners(x+2,y+2,ps-4,ps-4,6);
    const mx=x+ps+16,mw=Math.round(w*.36);pmText('CHARACTER',mx,y+20,{size:16});
    rr(mx,y+30,66,22,6);ctx.fillStyle='#3a2210';ctx.fill();rr(mx+1,y+31,64,20,5);ctx.fillStyle='#5a3418';ctx.fill();pmText('Lv '+P.lv,mx+33,y+46,{size:12,align:'center',col:'#fff3d0'});
    ctx.fillStyle='rgba(120,80,40,.35)';ctx.fillRect(mx,y+60,mw,1);
    const hp=Math.max(0,P.hp|0),mh=maxHp();pmText('HP',mx,y+80,{size:13});pmText(hp+' / '+mh,mx+mw,y+80,{size:13,align:'right'});
    rr(mx,y+88,mw,12,6);ctx.fillStyle='#2a3a20';ctx.fill();const f=Math.max(0,Math.min(1,hp/mh));if(f>0){rr(mx+2,y+90,Math.max(8,(mw-4)*f),8,4);ctx.fillStyle='#4ad04a';ctx.fill();ctx.fillStyle='rgba(255,255,255,.35)';ctx.fillRect(mx+5,y+91,Math.max(2,(mw-10)*f),2);}
    const st=gearStats();if(h>130)pmText('Shot +'+st.shot+'  DEF +'+st.def+'  Crit +'+st.crit+'   '+P.gold+' G',mx,y+118,{size:9,col:PMC.ink2});
    if(PET.active&&h>146)pmText('Pet: '+PETS[PET.active].name,mx,y+134,{size:9,col:PMC.ink2});
    ctx.fillStyle='rgba(120,80,40,.3)';ctx.fillRect(mx+mw+10,y+6,1,Math.min(h-12,140));
    const gx=mx+mw+20,gw=x+w-gx,tw=Math.floor((gw-10)/2),th=Math.min(70,Math.floor((Math.min(h,150)-10)/2));
    pmTile(gx,y,tw,th,'PETS','paw',()=>openPets(),'pets');pmTile(gx+tw+10,y,tw,th,'ACHIEVEMENTS','trophy',()=>openAch(),'ach');
    pmTile(gx,y+th+10,tw,th,'DAILY','cal',()=>openDaily(),'daily',pauseDaily()?'!':'');pmTile(gx+tw+10,y+th+10,tw,th,labOn()?'LEAVE LAB':'COMBAT LAB','swords',()=>pauseItem('KeyU').act(),'lab');
  },
  cards(x,y,w,h){
    const own=Object.keys(COL).filter(id=>COL[id]>0&&CARD[id]);
    pmTitle('DECK',x,y+16);pmText(DECK.length+' / '+DECK_MAX+' CARDS',x+w,y+16,{size:12,align:'right',col:DECK.length<DECK_MIN?'#a02020':PMC.ink});
    pmPill(x+w-250,y+2,88,20,'EDIT','cards',()=>openDeck(),'deckedit',{size:9});
    const per=Math.max(3,Math.min(6,Math.floor((w+12)/96))),cw=Math.min(112,Math.floor((w-(per-1)*12)/per)),sqs=Math.max(18,Math.min(24,Math.round(cw*.22))),chh=Math.min(Math.round(cw*1.22),h-40-sqs-8),pages=Math.max(1,Math.ceil(own.length/per));
    PM.scroll=Math.min(PM.scroll,pages-1);const list=own.slice(PM.scroll*per,PM.scroll*per+per),x0=x+Math.round((w-(list.length*cw+(list.length-1)*12))/2),cy=y+30;
    list.forEach((id,i)=>{const c=CARD[id],cx=x0+i*(cw+12),tint=cardTint(id);
      const r=pmReg(cx,cy,cw,chh,{id:'card:'+id,lab:c.name,act:()=>{PM.card=PM.card===id?null:id;sfx('select');}},'pmcard');
      rr(cx,cy,cw,chh,5);ctx.fillStyle='#3a2210';ctx.fill();rr(cx+2,cy+2,cw-4,chh-4,4);ctx.fillStyle=PMC.gold;ctx.fill();rr(cx+4,cy+4,cw-8,chh-8,3);ctx.fillStyle=tint;ctx.fill();
      const g=ctx.createLinearGradient(0,cy,0,cy+chh);g.addColorStop(0,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(0,0,0,.12)');ctx.fillStyle=g;rr(cx+4,cy+4,cw-8,chh-8,3);ctx.fill();
      try{const sc=Math.max(1,Math.floor((cw*.5)/16));draw(SP.ic[id],Math.round(cx+cw/2-8*sc),Math.round(cy+chh*.12),sc);}catch(e){}
      ctx.fillStyle='rgba(255,255,255,.5)';ctx.fillRect(cx+6,cy+chh-26,cw-12,18);const sz=pmFit(c.name,cw-14,10,6);pmText(c.name,cx+cw/2,cy+chh-13,{size:sz,align:'center'});
      pmCorners(cx+3,cy+3,cw-6,chh-6,5);if(PM.card===id||pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=3;rr(cx,cy,cw,chh,5);ctx.stroke();}
      const ry=cy+chh+8;pmSq(cx+cw/2-sqs-14,ry,sqs,'-',()=>deckRemove(id),'dec:'+id);pmText(String(deckCount(id)),cx+cw/2,ry+sqs*.72,{size:13,align:'center'});pmSq(cx+cw/2+14,ry,sqs,'+',()=>deckAdd(id),'inc:'+id);});
    if(pages>1){pmSq(x,cy+chh/2-12,24,'<',()=>{PM.scroll=Math.max(0,PM.scroll-1);},'pgprev');pmSq(x+w-24,cy+chh/2-12,24,'>',()=>{PM.scroll=Math.min(pages-1,PM.scroll+1);},'pgnext');}
    if(PM.card&&CARD[PM.card]){const c=CARD[PM.card],dw=Math.min(300,w-40),dh=Math.min(h-20,190),dx=x+(w-dw)/2,dy=y+(h-dh)/2;
      ctx.fillStyle='rgba(40,20,5,.35)';ctx.fillRect(x-4,y-4,w+8,h+8);pmParch(dx,dy,dw,dh,6);pmCorners(dx+2,dy+2,dw-4,dh-4,6);
      pmReg(dx,dy,dw,dh,{id:'carddetail',lab:'close',act:()=>{PM.card=null;sfx('select');}},'pmcard');
      rr(dx+12,dy+14,52,52,4);ctx.fillStyle=cardTint(PM.card);ctx.fill();try{draw(SP.ic[PM.card],dx+14,dy+16,3);}catch(e){}
      pmText(c.name,dx+76,dy+34,{size:14});pmText(RAR[c.rar].n+' CARD',dx+76,dy+52,{size:9,col:RAR[c.rar].col,lw:2,out:'#3a2210'});
      wrapText(cardInfo(PM.card),dw-28,'bold '+scaleText(10)+'px "Courier New",monospace').slice(0,6).forEach((l,i)=>pmText(l,dx+14,dy+88+i*14,{size:10}));
      pmText('In deck '+deckCount(PM.card)+'  -  owned '+(COL[PM.card]|0)+'   (tap to close)',dx+14,dy+dh-10,{size:8,col:PMC.ink2});}
  },
  inventory(x,y,w,h){
    pmTitle('INVENTORY',x,y+16);pmGoldPill(x+w,y,P.gold+' G');
    const cats=[['potions','POTIONS','potion'],['items','ITEMS','bag'],['materials','MATERIALS','gem'],['key','KEY ITEMS','key']],sw=Math.min(150,Math.round(w*.27)),rh=Math.min(30,Math.floor((h-34)/4)-4);
    cats.forEach(([id,lab,ic],i)=>{const on=PM.cat===id,yy=y+32+i*(rh+4);const r=pmReg(x,yy,sw,rh,{id:'cat:'+id,lab,act:()=>{PM.cat=id;PM.sel=null;sfx('select');}});
      rr(x,yy,sw,rh,4);ctx.fillStyle=on?PMC.greenD:PMC.edge;ctx.fill();rr(x+2,yy+2,sw-4,rh-4,3);ctx.fillStyle=on?PMC.green:'#f8ead0';ctx.fill();
      pmIcon(ic,x+8,yy+rh/2-8,1.6);const sz=pmFit(lab,sw-40,11,7);pmText(lab,x+34,yy+rh/2+4,{size:sz,col:on?'#fff8e0':PMC.ink,lw:on?2:0,out:on?'#163a12':false});if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(x,yy,sw,rh,4);ctx.stroke();}});
    const items=pmItems(PM.cat),gx=x+sw+14,gw=w-sw-14,s=Math.max(36,Math.min(58,Math.floor((h-46)/2)-6)),cols=Math.max(1,Math.floor((gw+8)/(s+8))),rows=Math.max(1,Math.floor((h-44)/(s+8)));
    const gx0=gx+Math.floor((gw-(cols*(s+8)-8))/2);
    for(let i=0;i<cols*rows;i++){const sx=gx0+(i%cols)*(s+8),sy=y+32+Math.floor(i/cols)*(s+8),it=items[i];pmSlot(sx,sy,s,PM.sel===i);
      if(it){pmReg(sx,sy,s,s,{id:'slot:'+i,lab:it.name,act:()=>{PM.sel=PM.sel===i?null:i;sfx('select');}},'pmslot');
        if(it.key)pmIcon('key',sx+s/2-10,sy+s/2-10,2);else satItemIcon(it,sx,sy,s);
        if(it.count>1)txt(String(it.count),sx+s-5,sy+s-5,{size:10,align:'right',col:'#fff',lw:3,out:'#2a160a'});
        if(it.eq){ctx.fillStyle='#3f8f3a';ctx.fillRect(sx+4,sy+4,10,10);txt('E',sx+9,sy+12,{size:8,align:'center',col:'#fff',lw:0,out:false});}}}
    const sel=PM.sel!=null&&items[PM.sel];
    if(sel){pmText(sel.name+'  -  '+(sel.sub||''),gx0,y+h-2,{size:9});}
    else if(!items.length)pmText(PM.cat==='potions'?'No potions yet - heal with your Heal card, the Inn or your bed.':'Nothing here yet.',gx0,y+h-2,{size:9,col:PMC.ink2});
    if(PM.cat==='items')pmPill(x,y+h-24,sw,22,'EQUIPMENT','sword',()=>openGear(),'gear',{size:9});
  },
  journal(x,y,w,h){
    pmTitle('JOURNAL',x,y+16);
    const sw=Math.min(150,Math.round(w*.27)),rq=pauseReadyQ();
    [['quests','QUESTS','excl',()=>openQuests(),true],['story','CHRONICLE','book',()=>openUIMode('story'),false]].forEach(([id,lab,ic,act,on],i)=>{const yy=y+32+i*38;const r=pmReg(x,yy,sw,32,{id,lab,act});
      rr(x,yy,sw,32,4);ctx.fillStyle=on?PMC.greenD:PMC.edge;ctx.fill();rr(x+2,yy+2,sw-4,28,3);ctx.fillStyle=on?PMC.green:'#f8ead0';ctx.fill();pmIcon(ic,x+8,yy+7,1.8);
      pmText(lab,x+34,yy+21,{size:pmFit(lab,sw-40,11,7),col:on?'#fff8e0':PMC.ink,lw:on?2:0,out:on?'#163a12':false});if(pmSel(r)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(x,yy,sw,32,4);ctx.stroke();}});
    const act=QUESTS.filter(q=>{const s=questStatus(q.id);return s==='active'||s==='ready';});
    const q=act.find(q=>TRK&&TRK.id==='q:'+q.id)||act[0],qx=x+sw+16,qw=w-sw-16,qh=Math.min(h-30,170);
    pmParch(qx,y+28,qw,qh,6);pmCorners(qx+2,y+30,qw-4,qh-4,5);
    if(q){const qrd=questStatus(q.id)==='ready';rr(qx+12,y+40,22,22,5);ctx.fillStyle=qrd?QMARK_COL.ready:isMainQuest(q)?QMARK_COL.story:QMARK_COL.avail;ctx.fill();pmText(qrd?'?':'!',qx+23,y+57,{size:15,align:'center',col:'#fff',lw:3,out:qrd?'#5a3a00':'#123a6a'});pmText(q.name.toUpperCase(),qx+40,y+57,{size:pmFit(q.name.toUpperCase(),qw-56,14,8)});
      const d=(q.prog&&q.prog[0])||'';wrapText(d,qw-28,'bold '+scaleText(9)+'px "Courier New",monospace').slice(0,3).forEach((l,i)=>pmText(l,qx+14,y+80+i*13,{size:9,col:PMC.ink2}));
      const o=q.obj||{},n=o.n||1;let p=0;try{p=Math.min(n,questProgress(q)|0);}catch(e){}const rd=questStatus(q.id)==='ready';
      const oy=y+28+qh-34;rr(qx+14,oy,16,16,2);ctx.fillStyle=PMC.edge;ctx.fill();rr(qx+16,oy+2,12,12,2);ctx.fillStyle='#fffaf0';ctx.fill();if(rd)pmIcon('check',qx+17,oy+3,1);
      const ol=(o.k==='kill'?'Defeat '+((ENEMY[o.type]&&ENEMY[o.type].name)||o.type||'foes'):o.k==='collect'?'Collect':o.k==='find'?'Find':'Objective')+'  ('+p+' / '+n+')';pmText(rd?'Return to '+(q.giver||'the giver'):ol,qx+38,oy+12,{size:10});
      if(act.length>1)pmText('+'+(act.length-1)+' more quest'+(act.length>2?'s':''),qx+qw-10,oy+12,{size:8,align:'right',col:PMC.ink2});}
    else pmText('No active quests - talk to the villagers!',qx+14,y+60,{size:10,col:PMC.ink2});
  },
  world(x,y,w,h){
    pmTitle('WORLD MAP',x,y+16);
    const lw=Math.min(210,Math.round(w*.32)),mw=w-lw-14,mh=h-30;rr(x,y+26,mw,mh,4);ctx.fillStyle=PMC.wood2;ctx.fill();
    try{travelMapRow().draw(x+3,y+29,mw-6,mh-6);}catch(e){}pmCorners(x+1,y+27,mw-2,mh-2,6);
    const lx=x+mw+14;pmIcon('map',lx,y+28,1.6);pmText('WAYSTONES',lx+22,y+40,{size:12});
    const rows=Math.max(1,Math.floor((h-100)/30));let i=0;
    for(const q of WAYSTONES){if(i>=rows)break;const found=SEC.ways[q.id],yy=y+50+i*30;i++;
      rr(lx,yy,lw,26,4);ctx.fillStyle=PMC.edge;ctx.fill();rr(lx+2,yy+2,lw-4,22,3);ctx.fillStyle=found?'#f8ead0':PMC.parch2;ctx.fill();
      pmIcon(found?'star':'lock',lx+6,yy+6,1.4);const nm=found?q.name.replace(' Waystone',''):'???';pmText(nm,lx+26,yy+12,{size:pmFit(nm,lw-50,10,7)});
      pmText(found?'Discovered':'Undiscovered',lx+26,yy+22,{size:7,col:PMC.ink2});if(found)pmIcon('check',lx+lw-18,yy+8,1.2);}
    pmPill(lx+10,y+h-32,lw-20,30,'TRAVEL','arrow',()=>openTravel(),'travel',{chev:true});
  },
  skills(x,y,w,h){
    pmTitle('SKILLS',x,y+16);
    const sp=skillPoints(),tw=Math.round(w*.5),th=h-30;
    rr(x+w-200,y,200,22,10);ctx.fillStyle='#3a2210';ctx.fill();rr(x+w-199,y+1,198,20,9);ctx.fillStyle='#5a3418';ctx.fill();pmIcon('gem',x+w-192,y+3,1.5);pmText('SKILL POINTS: '+sp,x+w-170,y+15,{size:10,col:'#fff3d0'});
    // tree
    const tr=pmReg(x,y+28,tw,th,{id:'tree',lab:'SKILL TREE',act:()=>openSkills()});rr(x,y+28,tw,th,5);ctx.fillStyle=PMC.edge;ctx.fill();rr(x+2,y+30,tw-4,th-4,4);ctx.fillStyle=PMC.parch2;ctx.fill();
    if(pmSel(tr)){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;rr(x,y+28,tw,th,5);ctx.stroke();}
    const nodes=SKILL_NODES.slice(0,7),cx=x+tw/2,ns=Math.min(34,Math.round(th/4.4)),lv=[[cx,y+36+ns*.2]],r1=[[cx-tw*.25,y+36+ns*1.6],[cx,y+36+ns*1.6],[cx+tw*.25,y+36+ns*1.6]],r2=[[cx-tw*.37,y+36+ns*3],[cx-tw*.12,y+36+ns*3],[cx+tw*.12,y+36+ns*3],[cx+tw*.37,y+36+ns*3]];
    const pos=[...lv,...r1,...r2].slice(0,nodes.length);
    ctx.strokeStyle='#5a3418';ctx.lineWidth=3;for(let i=1;i<pos.length;i++){const p=i<=3?pos[0]:pos[Math.min(3,Math.ceil((i-3)/1.4))];ctx.beginPath();ctx.moveTo(p[0],p[1]+ns/2);ctx.lineTo(p[0],p[1]+ns*.8);ctx.lineTo(pos[i][0],p[1]+ns*.8);ctx.lineTo(pos[i][0],pos[i][1]);ctx.stroke();}
    nodes.forEach((n,i)=>{const [nx,ny]=pos[i],rk=skillRank(n.id),lock=P.lv<n.lvl(0);rr(nx-ns/2,ny,ns,ns,4);ctx.fillStyle=PMC.wood2;ctx.fill();rr(nx-ns/2+2,ny+2,ns-4,ns-4,3);ctx.fillStyle=lock?'#6a6a6a':rk>0?PMC.green:'#3a6a3a';ctx.fill();
      if(lock)pmIcon('lock',nx-7,ny+ns/2-7,1.4);else{ctx.fillStyle=n.col;ctx.fillRect(nx-5,ny+ns/2-5,10,10);ctx.fillStyle='rgba(255,255,255,.6)';ctx.fillRect(nx-5,ny+ns/2-5,3,3);}
      if(rk)txt(String(rk),nx+ns/2-4,ny+ns-3,{size:8,align:'right',col:'#fff',lw:2});});
    pmText('Tap the tree to spend points',x+tw/2,y+28+th-8,{size:8,align:'center',col:PMC.ink2});
    const bx=x+tw+16,bw=w-tw-16,bh=Math.min(54,Math.floor((th-10)/2));
    pmPill(bx,y+28+th/2-bh-5,bw,bh,'FISHING','fish',()=>openFishing(),'fish',{size:14,chev:true});pmPill(bx,y+28+th/2+5,bw,bh,'CRAFTING','hammer',()=>openCraft(),'craft',{size:14,chev:true});
  },
  settings(x,y,w,h){
    pmTitle('SETTINGS',x,y+16);
    const lw=Math.round(w*.6),rows=[['master','MASTER VOLUME','speaker'],['music','MUSIC','note'],['sfx','SOUND EFFECTS','bars']];
    rows.forEach(([k,lab,ic],i)=>{const yy=y+40+i*40;pmIcon(ic,x,yy-2,1.6);pmText(lab,x+24,yy+8,{size:pmFit(lab,lw*.42,11,7)});
      const sx=x+Math.round(lw*.46),sw=Math.round(lw*.4),v=SET[k];
      const r=pmReg(sx-6,yy-6,sw+12,26,{id:k,lab,act:p=>{}},'slider');r.slide=(px)=>{SET[k]=Math.max(0,Math.min(1,Math.round((px-sx)/sw*10)/10));setSave();sfx('select');};
      rr(sx,yy+2,sw,10,5);ctx.fillStyle='#3a2210';ctx.fill();rr(sx+1,yy+3,sw-2,8,4);ctx.fillStyle='#d8c49a';ctx.fill();if(v>0){rr(sx+1,yy+3,Math.max(8,(sw-2)*v),8,4);ctx.fillStyle='#4ab04a';ctx.fill();}
      const kx=sx+sw*v;rr(kx-7,yy-3,14,20,3);ctx.fillStyle='#3a2210';ctx.fill();rr(kx-5,yy-1,10,16,2);ctx.fillStyle='#9ad0ff';ctx.fill();ctx.fillStyle='#e0f0ff';ctx.fillRect(kx-4,yy,3,5);
      pmText(Math.round(v*100)+'%',sx+sw+38,yy+11,{size:11,align:'right'});
      pmReg(sx-6,yy-6,(sw+12)/2,26,{id:k+'-',lab:'-',act:()=>setVol(k,-.1)},'half');pmReg(sx-6+(sw+12)/2,yy-6,(sw+12)/2,26,{id:k+'+',lab:'+',act:()=>setVol(k,.1)},'half');});
    const rx=x+lw+20,rw=w-lw-20;
    const cyc=(yy,lab,val,id,n)=>{pmText(lab,rx+rw/2,yy,{size:pmFit(lab,rw,11,7),align:'center'});const s=24;pmSq(rx,yy+8,s,'<',()=>setCycle(id,n,-1),id+'-');
      rr(rx+s+4,yy+8,rw-2*s-8,s,4);ctx.fillStyle=PMC.edge;ctx.fill();rr(rx+s+5,yy+9,rw-2*s-10,s-2,3);ctx.fillStyle='#f8ead0';ctx.fill();pmText(val,rx+rw/2,yy+24,{size:pmFit(val,rw-2*s-14,10,6),align:'center'});pmSq(rx+rw-s,yy+8,s,'>',()=>setCycle(id,n,1),id+'+');};
    cyc(y+40,'TEXT SIZE',TEXT_SIZES[SET.text].n,'text',TEXT_SIZES.length);
    cyc(y+92,'COLOUR-BLIND MODE',CB_MODES[SET.cb].n.split(' ')[0],'cb',CB_MODES.length);
    const by=y+h-30;pmPill(x,by,150,28,'MORE SETTINGS','cog',()=>openSettings('paused'),'moreset',{size:9});pmPill(x+160,by,170,28,'CONTROLS GUIDE','scroll',()=>{pressed.KeyP=true;openGuide();},'guide',{size:9});
  }
};
function pmItems(cat){
  const all=satItems();
  if(cat==='items')return all.filter(i=>i.spr);
  if(cat==='materials')return all.filter(i=>i.gem||i.fish);
  if(cat==='key')return Object.keys(QS.items||{}).filter(k=>QS.items[k]>0).map(k=>({name:k.replace(/[_-]/g,' ').replace(/\b\w/g,c=>c.toUpperCase()),sub:'Key item',count:QS.items[k]|0,key:true}));
  return [];
}
function pmTap(p){
  PAUSE.kbd=false;const r=pauseRects.slice().reverse().find(q=>inRect(p,q)&&q.kind!=='slider');
  const sl=pauseRects.find(q=>q.kind==='slider'&&inRect(p,q));if(sl){sl.slide(p.x);return true;}
  if(r){r.e.act();return true;}return false;
}
function pmKeys(){
  const i=PM_TABS.findIndex(t=>t[0]===PM.tab);
  if(hit('BracketRight','Tab','KeyE')){PM.tab=PM_TABS[(i+1)%PM_TABS.length][0];PM.scroll=0;PM.card=null;sfx('select');return true;}
  if(hit('BracketLeft')){PM.tab=PM_TABS[(i+PM_TABS.length-1)%PM_TABS.length][0];PM.scroll=0;PM.card=null;sfx('select');return true;}
  const nav=pauseRects.filter(r=>r.kind!=='slider'&&r.kind!=='half'),n=nav.length,cur=Math.max(0,nav.indexOf(pauseRects[PAUSE.sel])),mv=d=>{PAUSE.kbd=true;PAUSE.sel=pauseRects.indexOf(nav[((cur+d)%n+n)%n]);sfx('select');};
  if(hit('ArrowRight','ArrowDown','KeyS'))mv(1);else if(hit('ArrowLeft','ArrowUp','KeyW'))mv(-1);
  if(hit('Enter','Space')){const r=pauseRects[PAUSE.sel];if(r&&PAUSE.kbd){r.e.act();return true;}PAUSE.kbd=true;}
  return false;
}
