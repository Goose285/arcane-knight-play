/* M18: ground clutter pass - walkable bushes (T.BU) and stumps (T.ST) scattered on open grass and zone floors.
   Walkable on purpose (no collision / pathing change). Seeded, so the world is identical every run. Runs before places.js,
   which then re-clears ponds, spawner pads and the chapel. */
const ORCHARD=[[5,40],[7,42],[5,44],[9,43],[10,40],[16,43],[17,44],[15,40],[4,41],[10,42]];
const inOrchard=(x,y)=>ORCHARD.some(o=>o[0]===x&&o[1]===y);
function buildVegetation(){
  const r=mulberry32(18018),calm=new Set([T.G,T.K,T.T,T.BU,T.ST,T.L]);
  const open=(x,y)=>{for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const xx=x+dx,yy=y+dy;if(xx<0||yy<0||xx>=MW||yy>=MH)return false;if(!calm.has(map[yy][xx]))return false;}return true;};
  // overworld grass: not on the village green, roads or beside buildings
  for(let y=1;y<OW_H-1;y++)for(let x=2;x<MW-2;x++){
    const t=map[y][x];if(t!==T.G&&t!==T.K)continue;const q=r();
    if(regions.castle(x,y))continue;
    const vill=regions.village(x,y);
    if(q<(vill?.012:.052)&&open(x,y))map[y][x]=T.BU;
    else if(!vill&&q>.985&&open(x,y))map[y][x]=T.ST;
  }
  // a small apple orchard + a few shade trees on the village green (open ground only; never on roads, houses or the river bank)
  for(const [x,y] of ORCHARD)if(map[y][x]===T.G)map[y][x]=T.T;
  for(const id in ZONES){
    const z=ZONES[id],y0=z.y0;
    for(let y=y0+1;y<=y0+28;y++)for(let x=2;x<=61;x++){
      if(map[y][x]!==z.floor)continue;const q=r();
      if(q<.032&&open2(x,y,z))map[y][x]=T.BU;else if(q>.992&&open2(x,y,z))map[y][x]=T.ST;
    }
  }
  function open2(x,y,z){return !ZEXITS[x+','+y];}
}
buildVegetation();
