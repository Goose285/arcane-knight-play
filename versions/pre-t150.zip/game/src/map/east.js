/* =====================================================================
   THE EASTERN REACHES: 48 new columns east of the old world (grown through edGeom like the south).
   - GLOWCAP GROVE (north-east): moss, giant mushrooms, the mushroom folk; bosses The Wandering Colony and The Mushroom King.
     Reached by following the Whisperwood road east.
   - SHARDSTONE CAVERNS (south-east quarry): rubble, crystal clusters, cliffs; rock & crystal monsters; boss the Ruin Warden.
     Reached by following the Goldenfield farm road east over the river.
   - EMBER RIFT (far south-east corner): basalt and lava pools; Cinder Golems leave hot ground.
   Region edges are organic (noise), never ruler-straight. Authored coordinates are overworld-relative (x 0..111, y 0..103).
   Also: ORGANIC BORDERS for the old regions (forest / meadow / farm edges dithered by noise; the town is left alone).
   ===================================================================== */
let EAST_NPCS=0;
const EAST={on:false,x0:64,W:46,reg:null,COLS:48,SEED:7311};
const EREG_NAME={grove:'GLOWCAP GROVE',caves:'SHARDSTONE CAVERNS',rift:'EMBER RIFT'};
function eastRegion(tx,ty){
  if(!EAST.on||!EAST.reg)return null;const x=tx-OX,y=ty-OY;if(x<EAST.x0-2||x>=EAST.x0+EAST.COLS||y<0||y>=OW_H)return null;
  return [null,'grove','caves','rift'][EAST.reg[y*EAST.COLS+(x-(EAST.x0-2))]|0]||null;
}
const ehashN=(x,y,s)=>{let h=(x*374761393+y*668265263+s*982451653)|0;h=(h^(h>>>13))*1274126177|0;return ((h^(h>>>16))>>>0)/4294967296;};
function evnoise(x,y,s,f){const X=Math.floor(x/f),Y=Math.floor(y/f),fx=x/f-X,fy=y/f-Y,u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy);
  const a=ehashN(X,Y,s),b=ehashN(X+1,Y,s),c=ehashN(X,Y+1,s),d=ehashN(X+1,Y+1,s);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v;}
function buildEast(){
  const rnd=mulberry32(EAST.SEED),X=x=>x+OX,Y=y=>y+OY,C0=EAST.x0-2;
  const set=(x,y,t)=>{const mx=X(x),my=Y(y);if(mx>=0&&my>=0&&mx<MW&&my<MH)map[my][mx]=t;};
  const get=(x,y)=>{const r=map[Y(y)];return r?r[X(x)]:undefined;};
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  const H=OW_H,R=EAST.reg=new Uint8Array(H*EAST.COLS);
  const n=(x,y,s,f)=>evnoise(x,y,s,f);EAST.on=true;
  // frame
  fill(110,0,111,H-1,T.T);fill(62,0,111,1,T.T);fill(62,H-2,111,H-1,T.T);
  // ---- region map: ridge line between grove and caverns, rift in the south-east corner, a wavy tree belt on the west seam
  const ridge=x=>46+Math.round((n(x,0,3,9)-.5)*8);
  const seam=y=>65+Math.round(n(0,y,5,6)*3);
  const riftEdge=(x,y)=>(x-90)*.9+(y-66)*.75+(n(x,y,9,5)-.5)*9>14;
  for(let y=2;y<H-2;y++)for(let x=62;x<110;x++){
    const sx=seam(y);if(x<sx){set(x,y,rnd()<.75?T.T:T.K);continue;}
    const rg=ridge(x),reg=y<rg-1?1:y>rg+1?(riftEdge(x,y)?3:2):0;R[y*EAST.COLS+(x-C0)]=reg||(y<rg?1:2);
    if(!reg){set(x,y,n(x,y,4,2)<.55?T.CL:T.CR1);continue;}          // the ridge: cliffs and crystal
    const r=rnd(),nz=n(x,y,6,4);
    if(reg===1){set(x,y,nz<.3?T.G:T.MO);
      if(r<.055)set(x,y,T.MS1);else if(r<.09)set(x,y,T.MS2);else if(r<.16)set(x,y,T.MS3);else if(r<.2)set(x,y,T.T);}
    else if(reg===2){set(x,y,T.RG);
      if(nz>.78)set(x,y,T.CL);else if(r<.04)set(x,y,T.CR1);else if(r<.07)set(x,y,T.CR2);else if(r<.1)set(x,y,T.RK);}
    else{set(x,y,T.VB);if(nz>.7&&n(x,y,8,3)>.45)set(x,y,T.LV);else if(r<.07)set(x,y,T.VR);else if(r<.1)set(x,y,T.RK);}
  }
  // seam belt for the old east edge (x 58..65): a wavy treeline instead of the straight border
  for(let y=2;y<H-2;y++)for(let x=58;x<62;x++){if(n(x,y,12,3)<.35+(x-58)*.15&&(get(x,y)===T.K||get(x,y)===T.G))set(x,y,T.T);}
  // ---- roads (2 passes: the Whisperwood road east; the farm road east), meandering
  const road=(pts,t=T.P)=>{for(let i=0;i<pts.length-1;i++){let [x,y]=pts[i];const [x1,y1]=pts[i+1];while(x!==x1||y!==y1){set(x,y,t);set(x,y+1,t);if(x!==x1)x+=Math.sign(x1-x);else y+=Math.sign(y1-y);}set(x,y,t);set(x,y+1,t);}};
  road([[56,18],[72,18],[72,22],[86,22],[86,14],[100,14]]);road([[86,22],[86,34],[98,34]]);
  road([[51,70],[66,70],[74,70],[74,64],[84,64],[84,58]]);road([[84,58],[85,49],[85,40],[86,34]]);  // up through the ridge pass to the grove
  road([[74,70],[74,82],[90,82],[90,90],[100,90]]);
  fill(57,17,65,20,T.K);road([[56,18],[66,18]]);fill(51,69,65,72,T.G);road([[51,70],[66,70]]);
  // clear road shoulders
  for(let y=2;y<H-2;y++)for(let x=56;x<110;x++){const t=get(x,y);if(t!==T.P)continue;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const u=get(x+dx,y+dy);if([T.T,T.MS1,T.MS2,T.CL,T.CR1,T.CR2,T.RK,T.LV].includes(u)){const reg=eastRegion(X(x+dx),Y(y+dy));set(x+dx,y+dy,reg==='grove'?T.MO:reg==='caves'?T.RG:reg==='rift'?T.VB:T.K);}}}
  // boss clearings
  const clear=(cx,cy,r,t)=>{for(let y=cy-r;y<=cy+r;y++)for(let x=cx-r;x<=cx+r;x++)if((x-cx)**2+(y-cy)**2<=r*r+1)set(x,y,t);};
  clear(101,12,4,T.MO);clear(101,34,4,T.MO);clear(92,94,4,T.RG);clear(104,90,3,T.VB);
  for(let a=0;a<12;a++){const x=Math.round(101+Math.cos(a/12*6.283)*4.6),y=Math.round(34+Math.sin(a/12*6.283)*4.6);if(get(x,y)===T.MO)set(x,y,T.MS3);}   // fairy ring
  // ---- chests (tier) and waystones
  for(const [x,y,t] of [[78,8,0],[94,26,1],[106,40,1],[68,40,0],[80,56,1],[100,60,1],[70,92,0],[82,98,1],[101,92,2],[98,80,2],[104,6,1],[92,44,0]]){
    clear(x,y,1,eastRegion(X(x),Y(y))==='rift'?T.VB:eastRegion(X(x),Y(y))==='caves'?T.RG:T.MO);set(x,y,T.CHST);CHEST_TIER[x+','+y]=t;}
  edMapChanged();
  const free=(tx,ty)=>{for(let r=0;r<5;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const x=tx+dx,y=ty+dy;if(!solidTile(X(x),Y(y))&&get(x,y)!==T.W&&get(x,y)!==T.LV)return [x,y];}return [tx,ty];};
  for(const [id,name,wx,wy] of [['grove','Glowcap Waystone',70,20],['caves','Shardstone Waystone',70,67]]){
    const [x,y]=free(wx,wy);WAYSTONES.push({id,name,tx:X(x),ty:Y(y),to:{x:X(x+1)*TS+16,y:Y(y+1)*TS+28}});
    EAST_NPCS++;NPCS.push({name,way:id,x:(X(x)+.5)*TS,y:(Y(y)+.9)*TS,spr:'waystone',lines:[]});}
  EAST_NPCS+=2;NPCS.push({name:'Roadside Sign',x:(X(66)+.5)*TS,y:(Y(17)+.9)*TS,spr:'houseSign',lines:['EAST: GLOWCAP GROVE','The mushrooms walk at night. Some of them are not mushrooms at all.']});
  NPCS.push({name:'Quarry Sign',x:(X(66)+.5)*TS,y:(Y(69)+.9)*TS,spr:'houseSign',lines:['EAST: SHARDSTONE CAVERNS','Falling rocks. Walking rocks. Rocks that bite. Beyond the quarry: the Ember Rift.']});
  REGION_LABELS.push({name:EREG_NAME.grove,tx:X(86),ty:Y(24)},{name:EREG_NAME.caves,tx:X(78),ty:Y(76)},{name:EREG_NAME.rift,tx:X(102),ty:Y(86)});
  // ---- monsters
  const eadd=(type,tx,ty)=>{const [x,y]=free(tx,ty);if(ENEMY[type])addEnemy(type,X(x),Y(y));};
  const grove=['redcap','shroom','greencap','ambercap','babyshroom','babyshroom','lantern','chestcap','ironcap','spitter','frostcap','shadowcap','spore','brute'];
  const caves=['shscorp','sentinel','maw','tortoise','fbat','fbat','bboar','geode','crawler','scamp','scamp','mgolem'];
  const rift=['cgolem','cgolem','crawler','bboar','fbat'];
  const scatter=(list,reg,count)=>{let k=0,tries=0;while(k<count&&tries++<4000){const x=66+Math.floor(rnd()*43),y=3+Math.floor(rnd()*(H-6));
    if(eastRegion(X(x),Y(y))!==reg||solidTile(X(x),Y(y))||get(x,y)===T.P)continue;eadd(list[k%list.length],x,y);k++;}};
  scatter(grove,'grove',30);scatter(caves,'caves',26);scatter(rift,'rift',8);
  eadd('colony',101,12);eadd('mking',101,34);eadd('warden',92,94);
  EAST.on=true;
}
/* organic borders for the old overworld: where forest floor meets meadow (or farmland meets forest) the edge is dithered by noise,
   so no region boundary runs ruler-straight. The town (village / chapel), roads, water and buildings are never touched. */
function organicBorders(){
  const soft=new Set([T.G,T.K,T.L]);
  const W=MW,H=OW_H,snap=[];for(let y=0;y<H;y++)snap.push(map[OY+y].slice());
  for(let y=2;y<H-2;y++)for(let x=2;x<W-2;x++){
    const tx=x,ty=OY+y;if(regions.village(tx,ty)||regions.castle(tx,ty)||inChapel(tx,ty)||(typeof inTownPx==='function'&&inTownPx(tx*TS+16,ty*TS+16)))continue;
    const t=snap[y][x];if(!soft.has(t)&&t!==T.T)continue;
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const u=snap[y+dy][x+dx];
      if(u===t||!(soft.has(u)||u===T.T))continue;
      if((t===T.G||t===T.L)&&u===T.L||(t===T.L&&u===T.G))continue;
      const nz=evnoise(x,y,21,3);if(nz<.42){map[ty][tx]=u===T.T&&ehashN(x,y,5)<.5?T.BU:u;break;}}
  }
  edMapChanged();
}
if(growOn()){edGeom(0,0,EAST.COLS,EXP0.S);EXP0.E=EAST.COLS;buildEast();organicBorders();}
