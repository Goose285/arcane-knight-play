/* M18: Oakvale village dressing - the stone fountain pool by the arena gate becomes a sparkling lily pond (same tiles, still solid), with a
   campfire beside it and lanterns along the paths. Lanterns/fire go on grass only, so the walkable layout is unchanged. */
const VILLAGE_POND={x0:14,y0:33,x1:17,y1:36};            // rim ring; the water is the inner 2x2
const VILLAGE_FIRE={x:16,y:32};
const VILLAGE_LANTERNS=[[14,32],[17,32],[11,28],[11,31],[9,35],[5,40],[9,40],[17,40],[18,39],[11,42],[14,42],[11,33]];
const NPCS_EARLY=[[11,36],[6,35],[20,37],[19,33],[24,41],[11,34],[19,44],[9,41],[13,40],[16,41]];   // NPCS is filled later: keep their tiles clear here
function buildVillageDecor(){
  const P0=VILLAGE_POND;
  for(let y=P0.y0;y<=P0.y1;y++)for(let x=P0.x0;x<=P0.x1;x++)map[y][x]=(x>P0.x0&&x<P0.x1&&y>P0.y0&&y<P0.y1)?T.PW:T.PR;
  map[VILLAGE_FIRE.y][VILLAGE_FIRE.x]=T.FR;
  [[4,33],[8,33]].forEach(([x,y])=>{if(map[y][x]===T.G||map[y][x]===T.L)map[y][x]=T.LN;});   // the Inn's porch lanterns
  const near=(x,y)=>NPCS_EARLY.some(n=>Math.abs(n[0]-x)<=1&&Math.abs(n[1]-y)<=1);
  VILLAGE_LANTERNS.forEach(([x,y])=>{const t=map[y][x];if((t===T.G||t===T.BU||t===T.ST||t===T.L)&&!near(x,y))map[y][x]=T.LN;});
}
buildVillageDecor();
/* ---- the pond is drawn as ONE round basin over its 4x4 tiles: thin stone ring, circular water, grass in the corners (the 16 tiles stay solid) ---- */
const POND_R_OUT=28.6,POND_R_IN=24.6;      // in 16px-tile pixels (the 4x4 block is 64x64): a ~4px ring, drawn at 2x = ~8px thick
const POND_CACHE={};
function pondBlock(f){
  return makeSprite(64,64,g=>{
    const P0=VILLAGE_POND;
    for(let ty=0;ty<4;ty++)for(let tx=0;tx<4;tx++){const gs=TSPR[T.G],a=gs[hash2(P0.x0+tx,P0.y0+ty)%gs.length];g.drawImage(a,tx*16,ty*16);}
    const wf=TSPR[T.PW];const wv=[];for(let ty=0;ty<4;ty++)for(let tx=0;tx<4;tx++)wv.push(wf[(f&3)+4*(hash2(P0.x0+tx,P0.y0+ty)&1)]);
    const wc=makeSprite(64,64,w=>{for(let i=0;i<16;i++)w.drawImage(wv[i],(i%4)*16,Math.floor(i/4)*16);});
    const src=wc.getContext('2d').getImageData(0,0,64,64),dst=g.getImageData(0,0,64,64);
    const put=(x,y,hex)=>{const i=(y*64+x)*4,n=parseInt(hex.slice(1),16);dst.data[i]=n>>16;dst.data[i+1]=(n>>8)&255;dst.data[i+2]=n&255;dst.data[i+3]=255;};
    for(let y=0;y<64;y++)for(let x=0;x<64;x++){
      const dx=x+.5-32,dy=y+.5-32,d=Math.hypot(dx,dy);
      if(d>POND_R_OUT+1.2){   // soft irregular dirt + pebble bank around the stone rim, like the path edges
        const ang=Math.atan2(dy,dx),wob=31.3+1.0*Math.sin(ang*5+1.3)+.7*Math.sin(ang*11+.4),r=hash2(x,y+91)/4294967296;
        if(d<wob+(r-.5)*1.2){const q=wob-d;put(x,y,q>1.6?'#5b4430':(r<.15?'#b9b5a6':(r<.5?'#7c5f3b':'#98784a')));}
        continue;}
      if(d>POND_R_OUT){put(x,y,'#3a3d4c');continue;}                       // thin dark outline / drop edge
      if(d>POND_R_IN){                                                       // the stone ring
        const ang=Math.atan2(dy,dx),seg=Math.floor((ang+Math.PI)/(Math.PI*2)*28),edge=Math.abs(((ang+Math.PI)/(Math.PI*2)*28)%1);
        let c=(seg+hash2(seg,7))%3===0?'#a4a7b6':(seg%2?'#8e91a0':'#9a9dac');
        if(edge<.07||edge>.93)c='#5a5e70';                                   // mortar between the stones
        if(d>POND_R_OUT-1.1)c='#6a6e80';else if(d<POND_R_IN+1.1)c=dy<0?'#c4c7d4':'#7a7d8e';   // lit inner lip on the far side, shaded on the near side
        put(x,y,c);continue;}
      const i=(y*64+x)*4;dst.data[i]=src.data[i];dst.data[i+1]=src.data[i+1];dst.data[i+2]=src.data[i+2];dst.data[i+3]=255;
      if(d>POND_R_IN-2.2){dst.data[i]*=.72;dst.data[i+1]*=.8;dst.data[i+2]*=.9;}   // soft darker water at the rim
    }
    g.putImageData(dst,0,0);
    // lilies + lotus on the water (a pair of pads, one bloom)
    [[22,24,3],[39,38,3],[34,21,2]].forEach(([px,py,r],k)=>{ell(g,px,py,r+1,r,'#2c8a3c');ell(g,px,py,r,r-1,'#4cb04c');rect(g,px,py,r+1,1,'#2f72c8');if(k===0){rect(g,px-1,py-2,3,2,'#ffb0d0');rect(g,px,py-2,1,1,'#ffe98a');}});
  });
}
function pondTile(x,y,time){
  const P0=VILLAGE_POND,f=Math.floor(time*2.2)&3,tx=x-P0.x0,ty=y-P0.y0,key=f+'_'+tx+'_'+ty;
  let s=POND_CACHE[key];
  if(!s){const b=POND_CACHE['b'+f]||(POND_CACHE['b'+f]=(typeof WELLOPT!=='undefined'&&WELLOPT)?wellBlock(WELLOPT,f):pondBlock(f));s=POND_CACHE[key]=makeSprite(16,16,g=>g.drawImage(b,tx*16,ty*16,16,16,0,0,16,16));}
  return s;
}
const isVillagePond=(x,y)=>x>=VILLAGE_POND.x0&&x<=VILLAGE_POND.x1&&y>=VILLAGE_POND.y0&&y<=VILLAGE_POND.y1;
