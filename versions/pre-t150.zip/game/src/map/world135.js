/* =====================================================================
   t135u WORLD PASS
   - ROUND REGIONS: the dungeon zones' straight band walls and outer frame get noisy bumps and rounded corners (corridors keep >= 3
     tiles), and the overworld region edges get a second, wider organic dither, so no region reads as a rectangle any more.
   - SIGNS at every important place (shops, inn, chapel, pet pen, waystones, dungeon gates, region roads, the editor spot) and a
     CONTROLS GUIDE sign by the fountain that re-opens the full guide.
   - THE PET PEN: a fenced paddock beside Marlo in Oakvale where your pets (and the ones still up for adoption) potter about.
   NPCs added here are counted (NEW_NPCS_T135) so older editor layers keep their NPC indices (see edMigrate).
   ===================================================================== */
let NEW_NPCS_T135=0;
function roundZones(){
  for(const id in ZONES){
    const z=ZONES[id],y0=z.y0,W=z.wall,F=z.floor;
    const keep=[[52,21,61,23],[2,13,11,15],[46,8,61,10],[2,23,12,28],[30,1,44,8],[3,25,9,28]];for(const [k,x,dy] of ZONE_SPAWNS)keep.push([x-2,dy-2,x+2,dy+2]);
    const kept=(x,dy)=>keep.some(([a,b,c,d])=>x>=a&&x<=c&&dy>=b&&dy<=d);
    const put=(x,dy)=>{const y=y0+dy;if(kept(x,dy))return;const t=map[y][x];if(t===T.GB||t===T.CH||t===T.GX||t===T.CV)return;map[y][x]=W;};
    const nz=(x,s)=>evnoise(x,0,s+z.seed,3);
    // band walls: one-sided bumps (a corridor never loses more than 1 row at any column)
    for(const [row,x0,x1] of [[22,2,51],[14,12,61],[9,2,45]])for(let x=x0;x<=x1;x++){const n=nz(x,row);if(n>.62)put(x,row+1);else if(n<.36)put(x,row-1);}
    // outer frame: bumps on the top / bottom rows and the side columns
    for(let x=2;x<=61;x++){if(nz(x,101)>.58)put(x,1);if(nz(x,102)>.6)put(x,28);}
    for(let dy=1;dy<=28;dy++){if(evnoise(0,dy,z.seed+7,3)>.6)put(2,dy);if(evnoise(0,dy,z.seed+8,3)>.6)put(61,dy);}
    // rounded corners in every corridor end
    for(const [cx,cy,sx,sy] of [[2,1,1,1],[61,1,-1,1],[2,28,1,-1],[61,28,-1,-1],[2,10,1,1],[61,15,-1,1],[45,8,-1,-1],[51,21,-1,-1],[12,13,1,-1]])
      for(let a=0;a<3;a++)for(let b=0;b<3;b++)if(a+b<2)put(cx+a*sx,cy+b*sy);
  }
}
function roundOverworld(){
  // second, wider pass of the organic edge dither (different seed + scale) over the overworld incl. the east regions
  const soft=new Set([T.G,T.K,T.L,T.MO,T.RG,T.VB]);const H=OW_H,snap=[];for(let y=0;y<H;y++)snap.push(map[OY+y].slice());
  for(let y=2;y<H-2;y++)for(let x=2;x<MW-2;x++){
    const ty=OY+y;if(regions.village(x,ty)||regions.castle(x,ty)||inChapel(x,ty)||inTownPx(x*TS+16,ty*TS+16))continue;
    const t=snap[y][x];if(!soft.has(t)&&t!==T.T)continue;
    for(const [dx,dy] of [[2,0],[-2,0],[0,2],[0,-2],[1,1],[-1,-1]]){const u=snap[y+dy]&&snap[y+dy][x+dx];if(u==null||u===t||!(soft.has(u)||u===T.T))continue;
      if((t===T.G||t===T.L)&&(u===T.G||u===T.L))continue;
      if(evnoise(x,y,57,4)<.34){map[ty][x]=u;break;}}
  }
}
/* ---- signs ---- */
function signAt(tx,ty,name,lines,extra){
  for(let r=0;r<4;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const x=tx+dx,y=ty+dy;if(y<0||x<0||y>=MH||x>=MW)continue;if(solidTile(x,y)||map[y][x]===T.W||map[y][x]===T.P&&r<2)continue;
    if(NPCS.some(n=>Math.abs(n.x-(x+.5)*TS)<20&&Math.abs(n.y-(y+.9)*TS)<20))continue;
    NPCS.push(Object.assign({name,x:(x+.5)*TS,y:(y+.9)*TS,spr:'houseSign',lines,sign135:true},extra||{}));NEW_NPCS_T135++;return true;}
  return false;
}
function placeSigns(){
  const N=nm=>NPCS.find(n=>n.name===nm),near=(n,dx,dy,name,lines,ex)=>{if(n)signAt(Math.floor(n.x/TS)+dx,Math.floor(n.y/TS)+dy,name,lines,ex);};
  const orin=N('Elder Orin');
  near(orin,2,1,'Controls Guide',[],{guide:true});
  near(N('Blacksmith Brum'),2,0,'Smithy Sign',['BRUM\'S SMITHY - open from morning to dusk.','Talk to Brum to buy cards and arcane shot upgrades. Cards you buy go into your deck (menu > CARDS).']);
  near(N('Innkeeper Rosa'),2,1,'Inn Sign',['THE OAKVALE INN - open day and night.','Rest here to restore HP and skip to morning. Your game is saved when you rest.']);
  near(N('Marlo the Keeper'),-2,1,'Pet Pen Sign',['THE PET PEN','Talk to Marlo to adopt a pet. Your pet follows you, helps in fights and gives a small perk.','Pets you own wander the pen when they are not with you.']);
  near(N('Baker Wren'),2,1,'Bakery Sign',['WREN\'S BAKERY - open from morning to dusk.','At night the shopkeepers go home: a CLOSED sign hangs where they stand.']);
  signAt(CHAPEL.door+2,CHAPEL.y1+1,'Chapel Sign',['OAKVALE CHAPEL','Talk to the priest to be healed and blessed.']);
  for(const w of WAYSTONES){if(w.tx==null)continue;signAt(w.tx+1,w.ty+1,'Waystone Sign',['WAYSTONE: '+w.name,'Touch a waystone to wake it. Then travel between woken waystones from the menu (WORLD > TRAVEL) or by tapping a waystone.']);}
  for(const k in GATES){const [x,y]=k.split(',').map(Number),id=GATES[k];signAt(x+2,y+1,'Gate Sign',['GATE: '+ZONES[id].name,'A dungeon. Monsters you defeat inside stay down until you leave and come back.','Boss at the far end. Find the exit rune at the start to leave.']);}
  if(orin)signAt(Math.floor(orin.x/TS)-3,Math.floor(orin.y/TS)+2,'Editor Sign',['WORLD EDITOR','Open the menu (II / P) and tap EDITOR to move houses, paint ground, place walls, trees, chests and monsters.','UNDO / REDO sit at the top. COPY stamps whole areas.']);
  const X=x=>x+OX,Y=y=>y+OY;
  signAt(X(26),Y(18),'Road Sign',['WHISPERWOOD','A dark forest. Fog rolls in at times - stay on the road. Keep east for Glowcap Grove.']);
  signAt(X(14),Y(12),'Road Sign',['CASTLE ROAD','North to Castle Dracoryn. Dangerous for beginners.']);
  signAt(X(15),Y(43),'Slime Meadow Sign',['SLIME MEADOW','Shoot the slimes to start a fight. Your first fight is a lesson: it waits for you at every step.']);
  declutterTown();
}
/* t139u: far fewer signposts in town. Shop signs become small HANGING signs with an icon (still tappable); waystone, gate and editor
   posts are retired (their text lives in menu > HELP + first-time tips). Retired posts keep their NPC slot (parked off-map) so
   editor layers that point at NPCs by index stay valid. Doubled-up lanterns in town are thinned out. */
const HANG_ICON={'Smithy Sign':'anvil','Inn Sign':'mug','Pet Pen Sign':'paw','Bakery Sign':'bread','Chapel Sign':'cross'};
const DECLUTTER={retired:0,hang:0,lanterns:0};
function declutterTown(){
  for(const n of NPCS){if(!n.sign135)continue;
    if(HANG_ICON[n.name]){n.spr='hang_'+HANG_ICON[n.name];n.hang=true;DECLUTTER.hang++;}
    else if(n.name==='Waystone Sign'||n.name==='Gate Sign'||n.name==='Editor Sign'){n.x=n.hx=-9999;n.y=n.hy=-9999;n.retired=true;DECLUTTER.retired++;}}
  try{const tx0=Math.floor(TOWN.x0/TS),tx1=Math.ceil(TOWN.x1/TS),ty0=Math.floor(TOWN.y0/TS),ty1=Math.ceil(TOWN.y1/TS),kept=[];
    for(let y=ty0;y<=ty1;y++)for(let x=tx0;x<=tx1;x++){if(map[y][x]!==T.LN)continue;if(kept.some(([a,b])=>Math.abs(a-x)<=3&&Math.abs(b-y)<=3)){map[y][x]=T.G;DECLUTTER.lanterns++;}else kept.push([x,y]);}}catch(e){}
}
/* ---- the pet pen ---- */
const PEN={x0:0,y0:0,x1:0,y1:0,on:false,pets:[]};
function buildPen(){
  const m=NPCS.find(n=>n.pets);if(!m)return;const mx=Math.floor(m.x/TS),my=Math.floor(m.y/TS);
  const ok=(x0,y0)=>{for(let y=y0;y<y0+5;y++)for(let x=x0;x<x0+6;x++){const t=map[y]&&map[y][x];if(t!==T.G&&t!==T.L&&t!==T.K&&t!==T.T&&t!==T.BU&&t!==T.ST)return false;if(inChapel(x,y))return false;}return true;};   // (a few trees / bushes get cleared for the paddock)
  let best=null;for(let r=1;r<18&&!best;r++)for(let dy=-r;dy<=r&&!best;dy++)for(let dx=-r;dx<=r&&!best;dx++){const x0=mx+dx,y0=my+dy;if(ok(x0,y0))best=[x0,y0];}
  if(!best)return;const [x0,y0]=best;Object.assign(PEN,{x0,y0,x1:x0+5,y1:y0+4,on:true});
  for(let x=x0;x<=x0+5;x++){map[y0][x]=T.N;map[y0+4][x]=T.N;}for(let y=y0;y<=y0+4;y++){map[y][x0]=T.N;map[y][x0+5]=T.N;}
  map[y0+4][x0+2]=T.G;   // the gate
  for(let y=y0+1;y<=y0+3;y++)for(let x=x0+1;x<=x0+4;x++)map[y][x]=(x+y)%3?T.G:T.L;
  PEN.pets=PET_IDS.map((id,i)=>({id,x:(x0+1.5+i)*TS,y:(y0+2+(i%2)*.8)*TS,tx:0,ty:0,wt:R(.5,2),face:1}));
}
/* ---- villagers with something to do (see player/life.js) ---- */
function placeVillagers(){
  const free=(x,y)=>!solidTile(Math.floor(x/TS),Math.floor(y/TS));
  // a grass tile right next to the fountain (never inside the chapel)
  let bx=0,by=0;outer:for(let r=1;r<6;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const tx=OX+15+dx,ty=OY+34+dy;if(map[ty]&&(map[ty][tx]===T.G||map[ty][tx]===T.L)&&!inChapel(tx,ty)&&!solidTile(tx,ty)&&!solidTile(tx-1,ty)&&!solidTile(tx+1,ty)){bx=(tx+.5)*TS;by=(ty+.6)*TS;break outer;}}
  NPCS.push({name:'Old Tom',x:bx,y:by,spr:'elder',bench:true,lines:['Ahh, nothing beats a sit by the fountain.','In my day the slimes only ate dandelions!','Mind the fog in Whisperwood, youngster.']});NEW_NPCS_T135++;
  const sp=[[5.5,31.6],[9.5,31.6],[7.5,33.4]].map(([x,y])=>[(OX+x)*TS,(OY+y)*TS]).filter(([x,y])=>free(x,y));
  if(sp.length){NPCS.push({name:'Gardener Lyn',x:sp[0][0],y:sp[0][1],spr:'keeper',garden:{spots:sp,i:0,t:0},lines:['These flowers need water every day!','If you see a slime munching my tulips... well, they do grow back.']});NEW_NPCS_T135++;}
}
function placeWorld135(){roundZones();roundOverworld();buildPen();edMapChanged();placeSigns();placeVillagers();}
placeWorld135();
