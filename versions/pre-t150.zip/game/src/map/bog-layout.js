/* =====================================================================
   t142u MIREWOOD BOG LAYOUT REDO
   The old bog was the shared serpentine of straight bands. It is now carved from a winding ROUTE (a polyline from the arrival to the
   Hydra's arena), widened by noise, so every edge is rounded. Along the way:
   - three WATER POCKETS the route crosses on a winding BOARDWALK (new walkable tile T.BWK, planks over dark water),
   - a ring of REEDS / dead cypress (T.RE, drawn by tree-art) around the water and the outer edge, bog water beyond, rock furthest out,
   - MOSSY ISLANDS (T.MO) dotted over the mud, a few bushes and dead stumps,
   - two CHEST SIDE POCKETS (west and east) reached by short spurs, each with an iron chest,
   - the arrival / exit rune, Mirewood Pool (fishing), the hidden cave's cracked wall and the boss arena stay where they were,
   - the bog's monsters are re-spaced along the route (about 7 tiles apart, never inside the arena).
   ===================================================================== */
Object.assign(T,{BWK:94});
const BOG={
  route:[[5,26],[11,24.5],[17,21.5],[24,22],[31,24.6],[38,23],[45,20.5],[51,17],[50,13],[43,11.6],[34,13.2],[26,15],[19,12.8],[16,9],[21,6.5],[28,5]],
  spurs:[[[17,9],[12,7],[8,5.5]],[[38,23],[46,24.5],[53,25.5],[57,25]],[[31,24.6],[30.5,27.2]],[[5,26],[3.5,27]]],
  water:[[28,23.4,2.7],[40.5,12.3,2.5],[17.6,11.2,2.2],[47.6,23.4,1.8]],           // [x, dy, r] - the route / spur crossing them is boardwalk
  pockets:[[7.5,5,2.9,6,5],[57,25,2.7,58,25]],                                       // [x, dy, r, chest x, chest dy]
  arena:[36,4.6,24.5,4.3],
  spawns:ZONES.swamp.spawns,
};
function bogSegDist(px,py,pts){let best=1e9;for(let i=0;i<pts.length-1;i++){const [ax,ay]=pts[i],[bx,by]=pts[i+1],dx=bx-ax,dy=by-ay,L=dx*dx+dy*dy||1;
  const t=clamp(((px-ax)*dx+(py-ay)*dy)/L,0,1);best=Math.min(best,Math.hypot(ax+dx*t-px,ay+dy*t-py));}return best;}
function buildBog(){
  const z=ZONES.swamp,y0=z.y0,F=z.floor,WL=z.wall,rnd=mulberry32(9142);
  const set=(x,dy,t)=>{if(x>=0&&x<MW&&dy>=0&&dy<ZONE_H)map[y0+dy][x]=t;};
  const routeD=(x,y)=>Math.min(bogSegDist(x,y,BOG.route),...BOG.spurs.map(s=>bogSegDist(x,y,s)+.5));
  const inArena=(x,y)=>{const [cx,cy,rx,ry]=BOG.arena;return ((x-cx)/rx)**2+((y-cy)/ry)**2<1-.18*evnoise(x,y,911,3);};
  const inPocket=(x,y)=>BOG.pockets.some(([cx,cy,r])=>Math.hypot(x-cx,y-cy)<r+.6*evnoise(x,y,913,2));
  const waterOf=(x,y)=>BOG.water.find(([cx,cy,r])=>Math.hypot(x-cx,(y-cy)*1.15)<r+.5*evnoise(x,y,917,2));
  for(let dy=1;dy<=28;dy++)for(let x=2;x<=61;x++){
    const d=routeD(x,dy),n=evnoise(x,dy,903,3),rad=1.7+1.5*n,walk=d<rad||inArena(x,dy)||inPocket(x,dy);
    let t;
    if(walk){t=F;const w=waterOf(x,dy);if(w&&!inArena(x,dy))t=d<1.05?T.BWK:(d<1.6&&Math.hypot(x-w[0],dy-w[1])>w[2]-.4?F:T.W);
      else if(evnoise(x,dy,931,2)>.66&&d>.9)t=T.MO;}
    else{const edge=d-rad;t=edge<1.4?(rnd()<.62?T.RE:T.W):edge<3.2&&evnoise(x,dy,941,3)>.4?T.W:edge<3.2?T.RE:WL;}
    set(x,dy,t);
  }
  // outer frame stays rock; the bottom rows keep the hidden cave
  for(let x=0;x<MW;x++){set(x,0,WL);set(x,29,WL);}for(let dy=0;dy<30;dy++){set(0,dy,WL);set(1,dy,WL);set(62,dy,WL);set(63,dy,WL);}
  set(30,29,T.GB);set(30,28,F);set(30,27,F);
  // arrival + exit rune
  for(let dy=24;dy<=28;dy++)for(let x=3;x<=8;x++)if(map[y0+dy][x]!==F&&map[y0+dy][x]!==T.MO)set(x,dy,F);
  set(3,27,T.GX);ZEXITS[3+','+(y0+27)]=ZEXITS[3+','+(y0+27)]||'swamp';
  // Mirewood Pool (fishing spot) + its bank
  const fs=(typeof FISH_SPOTS!=='undefined'?FISH_SPOTS:[]).find(s=>s.id==='bog');
  if(fs&&fs.pond){const p=fs.pond;for(let y=p.y;y<p.y+p.h;y++)for(let x=p.x;x<p.x+p.w;x++)map[y][x]=T.W;const [bx,by]=fs.bank;map[by][bx]=F;}
  // the boss arena floor is plain mud; spawners and spawn spots are clear ground
  for(let dy=1;dy<=8;dy++)for(let x=12;x<=60;x++)if(inArena(x,dy)&&map[y0+dy][x]!==F)set(x,dy,F);
  for(const d of SPAWNER_DEFS)if(d.id.startsWith('sp_swamp'))for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const t=map[d.ty+b][d.tx+a];if(SOLID.has(t)||t===T.W)map[d.ty+b][d.tx+a]=F;}
  for(const [k,x,dy] of BOG.spawns){const X=Math.round(x),Y=Math.round(dy);for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++){const t=map[y0+Y+b][X+a];if(SOLID.has(t)||t===T.W)set(X+a,Y+b,F);}}
  // chest pockets
  for(const [cx,cy,r,hx,hy] of BOG.pockets){set(hx,hy,T.CHST);CHEST_TIER[(hx-OX)+','+(y0+hy-OY)]=1;}
  // sparse bushes / dead stumps on open mud away from the route
  for(let dy=2;dy<=27;dy++)for(let x=3;x<=60;x++){if(map[y0+dy][x]!==F||inArena(x,dy)||routeD(x,dy)<1.4)continue;const q=rnd();if(q<.05)set(x,dy,T.BU);else if(q<.075)set(x,dy,T.ST);}
  // monsters: the bog's regular foes spawn at ZONES.swamp.spawns (set in zones.js, used by populate)
  // map caches
  try{const m=MINI.swamp.spr.getContext('2d');for(let y=0;y<ZONE_H;y++)for(let x=0;x<MW;x++){m.fillStyle=TSPR.mini[map[y0+y][x]]||'#000';m.fillRect(x*2,y*2,2,2);}}catch(e){}
  try{edMapChanged();}catch(e){}
}
/* boardwalk planks: they run along the route (horizontal when the walk continues left/right, else vertical), dark water peeks at the sides */
(function(){
  const C=new Map(),isB=(x,y)=>map[y]&&map[y][x]===T.BWK,isW=(x,y)=>map[y]&&(map[y][x]===T.BWK||!SOLID.has(map[y][x])&&map[y][x]!==T.W);
  const draw=(hz,x,y)=>{const k=(hz?1:0)+''+((x*7+y*3)&3);let s=C.get(k);if(s)return s;
    s=makeSprite(16,16,g=>{rect(g,0,0,16,16,'#1d3a34');rect(g,0,0,16,2,'#24463e');rect(g,2,9,3,1,'#3a6a5a');rect(g,11,4,2,1,'#3a6a5a');
      const v=(x*7+y*3)&3,W1='#8a6a42',W2='#6e5232',OL='#3e2c1a';
      if(hz){rect(g,0,3,16,10,OL);for(let i=0;i<4;i++){rect(g,i*4,4,3,8,(i+v)%2?W1:W2);rect(g,i*4,4,3,1,'#a8865a');}rect(g,0,12,16,1,'#2a1e12');rect(g,1,13,1,3,OL);rect(g,14,13,1,3,OL);}
      else{rect(g,3,0,10,16,OL);for(let i=0;i<4;i++){rect(g,4,i*4,8,3,(i+v)%2?W1:W2);rect(g,4,i*4,8,1,'#a8865a');}rect(g,12,0,1,16,'#2a1e12');}
      rect(g,hz?7:5,hz?8:6,1,1,'#3e2c1a');});
    C.set(k,s);return s;};
  XTILE_FN[T.BWK]=(x,y)=>{const hz=(isB(x-1,y)||isB(x+1,y)||isW(x-1,y)&&isW(x+1,y))&&!(isB(x,y-1)&&isB(x,y+1));return draw(hz,x,y);};
  TSPR[T.BWK]=[draw(true,0,0)];TSPR.mini[T.BWK]='#8a6a42';
})();
buildBog();
