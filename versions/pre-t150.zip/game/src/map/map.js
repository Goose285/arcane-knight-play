
/* =====================================================================
   WORLD MAP  (village SW, meadow NW, forest E, castle N)
   ===================================================================== */
let MW=64,MH=224,OW_H=48;const CRY0=50,CRY_END=87;
let OX=0,OY=0,OWY0=0;   // world-editor expansion: the overworld is shifted by (OX,OY) tiles from its authored position; OWY0 = first overworld row (0, or 224 once expanded north/south)
const ZONE_Y0={snow:90,swamp:124,desert:158},ZONE_H=32;
const ARENA_Y0=192,ARENA_H=16,ARENA_NAME='EMBER ARENA';     // boss rush arena: rows 192..207
const HOUSE_Y0=208,HOUSE_H=16,HOUSE_NAME='YOUR HOUSE';   // the player's house interior: rows 208..223      // overworld = rows 0..47, Crypt of Hollow Kings = rows 50..87 (entered by stairs)
const CRYPT_NAME='CRYPT OF HOLLOW KINGS';
const CRYPT_IN={x:5,y:19},CRYPT_ARRIVE={x:31.5*TS,y:83*TS+28},CRYPT_OUT={x:5*TS+16,y:20*TS+28};
const map=[];
const SPAWN={x:12.5*TS,y:38*TS};
const regions={castle:(x,y)=>(x-=OX,y-=OY,x>=18&&x<=46&&y>=1&&y<=11),village:(x,y)=>(x-=OX,y-=OY,x>=3&&x<=24&&y>=29&&y<=(window.__NOGROW===true?44:60)),farm:(x,y)=>(x-=OX,y-=OY,x>=2&&x<=61&&y>=62&&y<=101&&window.__NOGROW!==true),forest:(x,y)=>(x-=OX,y-=OY,x>=27&&y>=14&&y<=45&&x<=61),crypt:(x,y)=>y>=CRY0&&y<=CRY_END};
const zoneOfTy=ty=>(ty>=OWY0&&ty<OWY0+OW_H)?'ow':ty<=CRY_END?'crypt':ty>=HOUSE_Y0?'house':ty>=ARENA_Y0?'arena':ty>=ZONE_Y0.desert?'desert':ty>=ZONE_Y0.swamp?'swamp':ty>=ZONE_Y0.snow?'snow':'gap';
const zoneOfPx=y=>zoneOfTy(Math.floor(y/TS));
const FARM_NAME='GOLDENFIELD FARMS';
const ZONE_NAME={snow:'FROSTHOWL PASS',swamp:'MIREWOOD BOG',desert:'SUNDERED RUINS'};
const inCryptPx=(x,y)=>{const z=zoneOfPx(y);return z==='crypt'||z==='arena';};   // torch-lit indoor lighting
function areaName(tx,ty){if(regions.crypt(tx,ty))return CRYPT_NAME;const zn=zoneOfTy(ty);if(zn==='arena')return ARENA_NAME;if(zn==='house')return HOUSE_NAME;if(ZONE_NAME[zn])return ZONE_NAME[zn];if(zn==='ow'){let er=null;try{er=eastRegion(tx,ty);}catch(e){}if(er)return EREG_NAME[er];}if(regions.castle(tx,ty))return 'CASTLE DRACORYN';if(zn==='ow'&&regions.farm(tx,ty))return FARM_NAME;if(inChapel(tx,ty))return CHAPEL.name;if(regions.village(tx,ty))return 'OAKVALE VILLAGE';if(regions.forest(tx,ty))return 'WHISPERWOOD';if(ty-OY<14&&tx-OX>=18)return 'CASTLE ROAD';return 'GREENMEADOW';}
function buildMap(){
  for(let y=0;y<MH;y++){map[y]=[];for(let x=0;x<MW;x++)map[y][x]=T.G;}
  const set=(x,y,t)=>{if(x>=0&&y>=0&&x<MW&&y<MH)map[y][x]=t;};
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  // border + scattered trees outside of the key zones
  for(let y=0;y<OW_H;y++)for(let x=0;x<MW;x++){
    if(x<2||x>=62||y>=46||y===0)set(x,y,T.T);
    else if(regions.forest(x,y))set(x,y,wrnd()<0.40+0.14*Math.sin(x*.7+y*.35)?T.T:T.K);
    else if((x<18||x>46)&&y<14)set(x,y,wrnd()<.45?T.T:T.G);
    else if(!regions.village(x,y)&&!regions.castle(x,y)&&wrnd()<.07)set(x,y,T.T);
  }
  // forest south-east filler strip beyond bottom border handled by region; river
  fill(25,14,26,45,T.W);
  // castle
  fill(18,1,46,11,T.B);fill(19,2,45,10,T.F);fill(18,1,46,1,T.BT);
  for(let y=2;y<=10;y++)for(let x=19;x<=45;x++)if(((x>>1)+(y>>1))%3===0&&wrnd()<.5)map[y][x]=T.F;
  [[23,5],[23,8],[27,5],[27,8],[36,5],[36,8],[40,5],[40,8],[22,3],[41,3]].forEach(([x,y])=>set(x,y,T.Z));
  fill(31,2,32,10,T.C);fill(28,2,35,3,T.C);fill(31,11,32,11,T.P);
  // roads
  const pth=(x0,y0,x1,y1)=>fill(x0,y0,x1,y1,T.P);
  pth(12,12,32,13);pth(12,13,13,44);pth(3,37,44,38);pth(31,12,32,44);
  set(25,37,T.J);set(26,37,T.J);set(25,38,T.J);set(26,38,T.J);
  // forest clearings + connectors
  [[42,22,3],[53,27,3],[44,35,3],[55,41,3],[38,29,2],[56,18,3],[46,43,2]].forEach(([cx,cy,r])=>{
    for(let y=cy-r;y<=cy+r;y++)for(let x=cx-r;x<=cx+r;x++)if((x-cx)**2+(y-cy)**2<=r*r+1)set(x,y,T.K);
    pth(Math.min(32,cx),cy,Math.max(32,cx),cy);pth(cx,Math.min(cy,38),cx,Math.max(cy,38));
  });
  // re-assert river & bridge
  fill(25,14,26,36,T.W);fill(25,39,26,45,T.W);fill(25,37,26,38,T.J);
  // village
  const house=(x,y,w)=>{fill(x,y,x+w-1,y,T.R);fill(x,y+1,x+w-1,y+1,T.RL);fill(x,y+2,x+w-1,y+2,T.H);set(x+(w>>1),y+2,T.D);};
  house(4,30,5);house(19,30,5);house(4,41,5);house(17,41,5);
  pth(6,33,6,36);pth(21,33,21,36);pth(6,39,6,40);pth(19,39,19,40);
  // fountain
  fill(14,33,17,36,T.S);fill(15,34,16,35,T.U);
  // fences
  for(let x=3;x<=23;x++)if(x<12||x>13)set(x,29,T.N);
  // flowers
  for(let y=14;y<=44;y++)for(let x=3;x<=24;x++)if(map[y][x]===T.G&&wrnd()<(regions.village(x,y)?.05:.03))set(x,y,T.L);
  for(let x=19;x<=45;x++){}
}
buildMap();
/* crypt stairs on the meadow (north-west) + the crypt itself */
function buildCrypt(){
  const set=(x,y,t)=>{if(x>=0&&y>=0&&x<MW&&y<MH)map[y][x]=t;};
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  // entrance arch in the meadow
  fill(3,17,7,18,T.B);fill(3,19,4,19,T.B);fill(6,19,7,19,T.B);set(CRYPT_IN.x,CRYPT_IN.y,T.CS);fill(4,20,6,20,T.P);fill(5,21,5,21,T.P);set(4,17,T.BT);set(5,17,T.BT);set(6,17,T.BT);
  // crypt: solid rock, then carve the halls
  fill(0,CRY0,MW-1,CRY_END,T.CW);
  const room=(x0,y0,x1,y1)=>{fill(x0,y0,x1,y1,T.CF);for(let x=x0+1;x<x1;x+=4)set(x,y0-1,T.CT);};
  room(27,78,36,84);room(31,73,32,77);room(19,66,44,72);room(31,62,32,65);room(17,51,46,61);          // entry hall, corridor, hub, corridor, throne hall
  room(5,64,14,78);fill(15,68,18,69,T.CF);room(49,64,58,78);
  fill(45,68,48,69,T.CF);
  // pillars, sarcophagi
  [[21,67],[21,71],[25,67],[25,71],[38,67],[38,71],[42,67],[42,71]].forEach(([x,y])=>set(x,y,T.CP));
  [[19,53],[19,59],[44,53],[44,59],[25,53],[25,59],[38,53],[38,59]].forEach(([x,y])=>set(x,y,T.CP));
  [[7,66],[7,70],[7,74],[12,66],[12,70],[12,74],[51,66],[51,70],[51,74],[56,66],[56,70],[56,74]].forEach(([x,y])=>set(x,y,T.CK));
  // bones / moss variety is hashed per tile; stairs back up
  fill(31,85,32,85,T.CX);fill(31,84,32,84,T.CF);
  // throne dais (decor): sarcophagus-style block at the back of the throne hall
  fill(30,51,33,51,T.CK);
}
buildCrypt();
const solidTile=(tx,ty)=>tx<0||ty<0||tx>=MW||ty>=MH||SOLID.has(map[ty][tx]);
function tileSprite(id,x,y,time){
  const xf=XTILE_FN[id];if(xf)return xf(x,y,time);
  const a=TSPR[id];
  if((id===T.B||id===T.BT||id===T.P)&&typeof SW!=='undefined'){const sw=SW.southTile(x,y);if(sw)return sw;}   // t139u grey stone south wall
  if(HOUSEWALL&&P.y>=HOUSE_Y0*TS){   // inside the house: ?housewall walls + ?housevoid surroundings (the arena wall just above the house is never shown from inside)
    if(y<HOUSE_Y0&&y>=HOUSE_Y0-6)return hwOut(x,y);
    if(y>=HOUSE_Y0&&y<HOUSE_Y0+HOUSE_H&&(id===T.B||id===T.BT||id===T.F))return houseTile(id,x,y,a[hash2(x,y)%a.length]);}
  if((id===T.R||id===T.RL||id===T.H||id===T.D)&&inInn(x,y))return innTile(id,x,y);
  if((id===T.PW||id===T.PR)&&isVillagePond(x,y))return pondTile(x,y,time);
  if(id===T.W||id===T.U)return weCompose(a[(Math.floor(time*2.2)+(x>>1)+(y>>1)+(id===T.U?x:0))&3],x,y,id);
  if(id===T.PW)return a[((Math.floor(time*2.2)+(x>>1)+(y>>1))&3)+4*(hash2(x,y)&1)];
  if(id===T.FR)return a[Math.floor(time*7)&3];
  if(TREE_IDS.has(id))return treeSprite(id,x,y);
  if(id===T.P)return pathTileSprite(x,y);
  if((id===T.G||id===T.K)&&grassNearRoad(x,y))return pathTileSprite(x,y);
  if(WE_LAND.has(id))return weCompose(a[hash2(x,y)%a.length],x,y,id);
  return a[hash2(x,y)%a.length];
}
// reachability from spawn
const reach=(()=>{const r=Array.from({length:MH},()=>new Array(MW).fill(false));const sx=Math.floor(SPAWN.x/TS),sy=Math.floor(SPAWN.y/TS);const q=[[sx,sy]];r[sy][sx]=true;
  while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(!solidTile(nx,ny)&&!r[ny][nx]){r[ny][nx]=true;q.push([nx,ny]);}}}return r;})();
// minimap
const miniMap=makeSprite(MW*2,OW_H*2,g=>{for(let y=0;y<OW_H;y++)for(let x=0;x<MW;x++){g.fillStyle=TSPR.mini[map[y][x]]||'#000';g.fillRect(x*2,y*2,2,2);}});
const miniCrypt=makeSprite(MW*2,(CRY_END+1-CRY0)*2,g=>{g.fillStyle='#0a0814';g.fillRect(0,0,MW*2,(CRY_END+1-CRY0)*2);for(let y=CRY0;y<=CRY_END;y++)for(let x=0;x<MW;x++){g.fillStyle=TSPR.mini[map[y][x]]||'#000';g.fillRect(x*2,(y-CRY0)*2,2,2);}});
