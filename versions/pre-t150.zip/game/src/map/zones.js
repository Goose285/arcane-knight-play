/* =====================================================================
   NEW REGIONS: Frosthowl Pass (snow), Mirewood Bog (swamp), Sundered Ruins (desert).
   Each is a 64x32 block of the shared map array, entered through a gate arch on the overworld and left by the exit rune.
   Layout (same for all): a serpentine pass - bottom corridor -> east gap -> middle corridor -> west gap -> upper corridor -> east gap -> boss arena.
   ===================================================================== */
const ZONES={
  snow:  {y0:ZONE_Y0.snow,  name:ZONE_NAME.snow,  floor:T.SN,wall:T.RK,deco:[[T.PN,.095],[T.IC,.05]],seed:11,gate:{x:54,y:6},  mobs:['wolf','yeti'],boss:'rimegar'},
  swamp: {y0:ZONE_Y0.swamp, name:ZONE_NAME.swamp, floor:T.MD,wall:T.MR,deco:[[T.RE,.085],[T.MR,.045]],  seed:22,gate:{x:50,y:43}, mobs:['toad','witch'],boss:'mossback'},
  desert:{y0:ZONE_Y0.desert,name:ZONE_NAME.desert,floor:T.SD,wall:T.SR,deco:[[T.SC,.04],[T.RU,.07],[T.PM,.03],[T.AC,.03]],   seed:33,gate:{x:58,y:30}, mobs:['scorpion','mummy'],boss:'colossus'},
};
ZONES.swamp.spawns=[[0,13,24],[0,24,21],[1,35,24.5],[0,44,21.5],[1,51,15],[0,45,11],[1,33,13.5],[0,25,15],[1,18,19],[0,52,25]];   // t142u bog layout (see map/bog-layout.js)
const zoneArrive=id=>({x:5*TS+16,y:(ZONES[id].y0+26)*TS+28,dir:'u'});
const zoneGateOut=id=>({x:ZONES[id].gate.x*TS+16,y:(ZONES[id].gate.y+1)*TS+28,dir:'d'});
const zoneBossArena=id=>({tx0:12,ty0:ZONES[id].y0+1,tx1:60,ty1:ZONES[id].y0+8});
/* enemy spawn plan per zone (relative to y0): [kind(0=first mob,1=second mob), x, dy] */
const ZONE_SPAWNS=[[0,14,26],[0,27,25],[0,41,27],[1,50,18],[0,34,17],[1,22,19],[0,10,12],[1,26,11],[0,39,12],[1,53,12]];
const GATES={};          // 'tx,ty' -> zone id (overworld gate tiles)
const ZEXITS={};         // 'tx,ty' -> zone id (exit rune tiles)
function buildZones(){
  const set=(x,y,t)=>{if(x>=0&&y>=0&&x<MW&&y<MH)map[y][x]=t;};
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  for(const id in ZONES){
    const z=ZONES[id],y0=z.y0,rnd=mulberry32(z.seed);
    fill(0,y0,MW-1,y0+31,z.wall);fill(2,y0+1,61,y0+28,z.floor);
    for(let y=y0+1;y<=y0+28;y++)for(let x=2;x<=61;x++){const r=rnd();let a=0;for(const [t,p] of z.deco){a+=p;if(r<a){set(x,y,t);break;}}}
    fill(2,y0+22,51,y0+22,z.wall);fill(12,y0+14,61,y0+14,z.wall);fill(2,y0+9,45,y0+9,z.wall);       // the three bands
    // keep gaps, arrival, boss arena and spawn spots clear
    fill(52,y0+21,61,y0+23,z.floor);fill(2,y0+13,11,y0+15,z.floor);fill(46,y0+8,61,y0+10,z.floor);
    fill(2,y0+23,12,y0+28,z.floor);fill(30,y0+1,44,y0+8,z.floor);
    for(const [k,x,dy] of ZONE_SPAWNS)fill(x-1,y0+dy-1,x+1,y0+dy+1,z.floor);
    fill(4,y0+25,8,y0+27,z.floor);set(3,y0+27,T.GX);ZEXITS[3+','+(y0+27)]=id;
    // hidden cave under the bottom wall: cracked wall -> chamber with a chest
    set(30,y0+29,T.GB);fill(24,y0+30,36,y0+31,T.CV);set(30,y0+31,T.CH);
  }
  // overworld gate arches + roads to them
  const pth=(x0,y0,x1,y1)=>fill(x0,y0,x1,y1,T.P);
  pth(32,12,54,12);pth(54,7,54,12);pth(46,44,50,44);pth(53,30,53,31);pth(53,31,58,31);
  for(const id in ZONES){const g=ZONES[id].gate;fill(g.x-1,g.y-1,g.x+1,g.y-1,T.B);set(g.x-1,g.y,T.B);set(g.x+1,g.y,T.B);set(g.x,g.y,T.GT);set(g.x,g.y+1,T.P);GATES[g.x+','+g.y]=id;}
  // road tidy: a grass/tree tile boxed in by road on 3+ sides is a notch in the road - pave it
  for(let y=37;y<=38;y++)for(let x=3;x<=44;x++){const t=map[y][x];if(t===T.G||t===T.K||t===T.L||t===T.T)map[y][x]=T.P;}   // the main east-west road (a forest clearing had nicked it)
  for(const [x,y] of [[54,38],[47,41]])if(map[y][x]===T.K||map[y][x]===T.G)map[y][x]=T.P;   // single-tile gaps where two connector roads meet
  for(let pass=0;pass<3;pass++)
  for(let y=1;y<MH-1;y++)for(let x=1;x<MW-1;x++){const t=map[y][x];if(t!==T.G&&t!==T.K&&t!==T.L&&t!==T.T)continue;
    const n=(map[y-1][x]===T.P)+(map[y+1][x]===T.P)+(map[y][x-1]===T.P)+(map[y][x+1]===T.P);if(n>=3)map[y][x]=T.P;}
  // treasure-map dig spots and waystone sites must be walkable
  for(const [x,y,t] of [[12,24,T.G],[38,33,T.K],[20,16,T.G],[11,34,T.G],[30,16,T.P],[44,32,T.K]])if(SOLID.has(map[y][x]))set(x,y,t);   // only clear it if blocked (never carve a grass notch out of a road)
}
buildZones();
const miniZone=id=>{const y0=ZONES[id].y0;return makeSprite(MW*2,ZONE_H*2,g=>{for(let y=0;y<ZONE_H;y++)for(let x=0;x<MW;x++){g.fillStyle=TSPR.mini[map[y0+y][x]]||'#000';g.fillRect(x*2,y*2,2,2);}});};
const MINI={ow:{spr:miniMap,y0:0},crypt:{spr:miniCrypt,y0:CRY0}};
for(const id in ZONES)MINI[id]={spr:miniZone(id),y0:ZONES[id].y0};
// the new gate roads connect the overworld: refresh walkability (in place)
(function(){for(const r of reach)r.fill(false);const sx=Math.floor(SPAWN.x/TS),sy=Math.floor(SPAWN.y/TS),q=[[sx,sy]];reach[sy][sx]=true;
  while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(!solidTile(nx,ny)&&!reach[ny][nx]){reach[ny][nx]=true;q.push([nx,ny]);}}}})();
