/* =====================================================================
   OAKVALE SOUTH QUARTER + GOLDENFIELD FARMS. The village is doubled in size (a second block of houses, lanes, a market square and a gatehouse
   to the south) and a new sunny farmland region lies beyond the gate: orchard, barley fields, a river crossing, a lake, field monsters, an
   NPC family, a waystone and a quest. The world is grown through the same machinery as the editor's EXPAND (edGeom), so every position
   (NPCs, doors, gates, quests, spawns...) stays consistent; EXP0 records the shipped size so edits / RESET add to it. Tests can opt out with
   window.__NOGROW=true (the old 64x48 overworld).
   Authored coordinates below are in the overworld's own frame (x 0..63, y 0..103); X()/Y() move them to where the overworld now sits.
   ===================================================================== */
const growOn=()=>window.__NOGROW!==true;
const GROW={S:56,TOWN_ROWS:16,SEED:4242};
/* the two new field monsters borrow the fighting style of a wolf (charging bites) and a mummy (slow, heavy swings) */
Object.assign(ER,{boar:14,scarecrow:14});Object.assign(SHORT,{boar:'BOAR',scarecrow:'SCARECROW'});Object.assign(BAND,{boar:[26,80],scarecrow:[30,70]});
Object.assign(DODGE_BASE,{boar:.22,scarecrow:.08});Object.assign(MAT_DROP,{boar:'fur',scarecrow:'hide'});FLANKERS.add('boar');FLANKERS.add('scarecrow');
ATK.boar=ATK.wolf;ATK.scarecrow=ATK.mummy;
let GROW_NPC0=NPCS.length,GROW_NPC_ADDED=0;
function buildSouth(){
  const rnd=mulberry32(GROW.SEED),X=x=>x+OX,Y=y=>y+OY;
  const set=(x,y,t)=>{const mx=X(x),my=Y(y);if(mx>=0&&my>=0&&mx<MW&&my<MH)map[my][mx]=t;};
  const get=(x,y)=>map[Y(y)][X(x)];
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  const pth=(x0,y0,x1,y1)=>fill(x0,y0,x1,y1,T.P);
  const house=(x,y,w)=>{fill(x,y,x+w-1,y,T.R);fill(x,y+1,x+w-1,y+1,T.RL);fill(x,y+2,x+w-1,y+2,T.H);set(x+(w>>1),y+2,T.D);};
  const lamp=(x,y)=>{if(get(x,y)===T.G||get(x,y)===T.L)set(x,y,T.LN);};
  const OWB=OW_H;                                   // rows 0..OWB-1 of the overworld; the last two are the tree border
  // --- frame: tree border down both sides and along the bottom
  fill(0,46,1,OWB-1,T.T);fill(62,46,63,OWB-1,T.T);fill(0,OWB-2,63,OWB-1,T.T);
  // --- the village's southern quarter: meadow where the old border rows were
  fill(2,46,24,60,T.G);
  for(let y=46;y<=60;y++)for(let x=2;x<=24;x++)if(get(x,y)===T.G&&rnd()<.05)set(x,y,T.L);
  // forest east of the river (dense; the way on is the gate road)
  for(let y=46;y<=61;y++)for(let x=27;x<=61;x++)set(x,y,rnd()<.62?T.T:T.K);
  // river continues south of the village
  fill(25,46,26,82,T.W);
  // --- houses, lanes, market square
  pth(12,45,13,71);                                                  // the main road runs on through the new quarter, the gate and the farms
  pth(3,49,24,50);pth(3,57,24,58);                                   // two cross lanes
  house(4,46,5);house(19,46,5);                                      // row B (doors face lane 1)
  house(4,52,5);house(9,52,3);house(15,52,4);house(20,52,4);       // row C (doors face lane 2 through short paths)
  for(const dx of [6,10,17,22])pth(dx,55,dx,56);
  fill(9,46,16,47,T.F);fill(9,48,11,48,T.F);fill(14,48,16,48,T.F);  // market square (stone) around the road
  pth(12,46,13,48);
  [[9,46],[16,46],[9,48],[16,48],[3,51],[24,51],[7,56],[18,56],[11,56],[14,56]].forEach(([x,y])=>lamp(x,y));
  [[10,47],[15,47]].forEach(([x,y])=>{if(get(x,y)===T.F)set(x,y,T.BU);});
  for(const [x,y] of [[4,51],[8,51],[5,56],[8,56],[20,51],[23,51],[3,59],[6,59],[19,59],[22,59]])if(get(x,y)===T.G||get(x,y)===T.L)set(x,y,T.BU);
  // --- the south gatehouse: wall across the village, towers either side of the road
  fill(2,60,9,60,T.BT);fill(2,61,9,61,T.B);fill(16,60,24,60,T.BT);fill(16,61,24,61,T.B);
  fill(10,59,11,59,T.BT);fill(10,60,11,62,T.B);fill(14,59,15,59,T.BT);fill(14,60,15,62,T.B);
  pth(12,59,13,63);lamp(9,59);lamp(16,59);set(12,59,T.P);
  // --- GOLDENFIELD FARMS: sunny meadow, flowers, a few bushes and stones
  fill(2,62,61,OWB-3,T.G);
  pth(12,59,13,71);
  for(let y=62;y<=OWB-3;y++)for(let x=2;x<=61;x++){const r=rnd();if(get(x,y)!==T.G)continue;if(r<.11)set(x,y,T.L);else if(r<.125)set(x,y,T.BU);else if(r<.132)set(x,y,T.RK);}
  fill(25,62,26,82,T.W);                                            // river
  // lake at the river's end (soft oval) with a sandy shore
  for(let y=79;y<=96;y++)for(let x=14;x<=38;x++){const d=((x-26)/10.5)**2+((y-88)/6.2)**2;if(d<=1)set(x,y,T.W);else if(d<=1.45&&get(x,y)===T.G)set(x,y,T.SD);}
  // roads: the farm road (east across the bridge), a west spur, the field lane south
  pth(3,70,50,71);fill(25,70,26,71,T.J);                           // the river crossing
  pth(12,72,13,93);                                                // lane south along the orchard
  pth(39,72,40,97);                                                // lane between the barley fields
  pth(49,62,50,69);                                                // lane up to the barn yard
  // farmstead: farmhouse + barn, yard fence
  house(42,64,5);house(52,64,5);pth(44,67,44,69);pth(54,67,54,69);
  for(let x=40;x<=58;x++)if(x<48||x>50)set(x,62,T.N);
  fill(40,63,40,69,T.N);fill(58,63,58,69,T.N);set(40,70,T.P);
  // orchard keeper's cottage
  house(5,64,3);pth(6,67,6,69);
  // barley fields: fenced plots of tilled soil with crop rows
  const plot=(x0,y0,x1,y1)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const edge=x===x0||x===x1||y===y0||y===y1;set(x,y,edge?T.N:((y-y0)%2===0?T.MD:T.L));}set((x0+x1)>>1,y0,T.G);set((x0+x1)>>1,y1,T.G);};
  plot(29,74,37,80);plot(42,74,50,80);plot(29,86,37,92);plot(42,86,50,92);plot(53,74,60,82);
  // lake-side reeds
  for(const [x,y] of [[17,88],[18,93],[36,92],[37,86],[24,96],[30,96]])if(get(x,y)===T.G||get(x,y)===T.SD)set(x,y,T.RE);
  // orchard: rows of apple trees west of the lane, clear of water, roads and the cottage
  const orch=[];
  for(const y of [74,77,80,83,86,89,92])for(const x of [4,7,10,16,19,22])if(get(x,y)===T.G||get(x,y)===T.L){set(x,y,T.T);orch.push([X(x),Y(y)]);}
  for(const o of orch)ORCHARD.push(o);
  // lantern posts along the gate road, bridge approach and the barn yard
  [[11,63],[14,63],[11,69],[14,69],[24,69],[27,69],[41,69],[48,69]].forEach(([x,y])=>lamp(x,y));
  // --- make sure the road tiles beside the new bridge have no tree / bush stuck in them, then fix walkability + minimap + caches
  for(let y=62;y<=OWB-3;y++)for(let x=2;x<=61;x++){const t=get(x,y);if((t===T.BU||t===T.RK)&&['P','J'].some(k=>[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>get(x+dx,y+dy)===T[k])))set(x,y,T.G);}
  edMapChanged();
  // --- Oakvale grows with the village: the town rules (no wandering monsters, guards) cover the new quarter too
  TOWN.y1+=GROW.TOWN_ROWS*TS;
  // --- people (feet on the tile; px) and the guards
  const free=(tx,ty)=>{for(let r=0;r<4;r++)for(let dy=-r;dy<=r;dy++)for(let dx=-r;dx<=r;dx++){const x=tx+dx,y=ty+dy;if(!solidTile(X(x),Y(y))&&get(x,y)!==T.W&&get(x,y)!==T.N)return [x,y];}return [tx,ty];};
  const npc=(name,spr,tx,ty,lines,extra)=>{const [x,y]=free(tx,ty);NPCS.push(Object.assign({name,x:(X(x)+.5)*TS,y:(Y(y)+.9)*TS,spr,lines},extra||{}));GROW_NPC_ADDED++;};
  npc('Baker Wren','keeper',10,50,['Fresh loaves! The Goldenfield barley makes the best crust in the valley.','They finally built the south quarter - the old village was bursting at the seams.']);
  npc('Mason Dov','smith',20,55,['Stone by stone: I laid every block of that gatehouse myself.','Past the gate the road runs through Goldenfield Farms. Sunny country - mind the boars.']);
  npc('Gate Warden Hollis','guard',15,63,['Welcome to the south gate of Oakvale.','Beyond lie the Goldenfield Farms: orchards, barley and a river to cross. The farmers could use a hero.','Field Boars have been getting bold. They are tougher than slimes, so bring your best cards.']);
  npc('Farmer Hale','elder',44,69,['This is Goldenfield, traveler: the best soil in the valley.'],{});
  npc('Orchard Keeper Mira','fisher',8,69,['My apples are the sweetest this side of the river.','The orchard trees are heavy this year. The boars love them just as much as I do!','If you fish the river from the bank, the trout here are shy but plump.']);
  npc('Roadside Sign','houseSign',14,64,['GOLDENFIELD FARMS','Orchard west of the lane - Barley fields east of the river. Beware of boars and bad-tempered scarecrows.']);
  for(const [tx,ty,lines] of [[8.4,50.5,['Oakvale\'s Guard, now with a south quarter to watch.','Nothing hostile gets past these streets.']],[14.4,58.6,['The gatehouse is ours. Run back through it if a fight turns against you.','Monsters do not set foot in Oakvale - the south quarter included.']]]){
    NPCS.push({name:'Town Guard',x:(X(tx)+0)*TS,y:(Y(ty)+0)*TS,hx:(X(tx))*TS,hy:(Y(ty))*TS,gcd:0,spr:'tguard',tguard:true,lv:TOWN.lv,lines});GROW_NPC_ADDED++;}
  // waystone beside the bridge, a fishing spot on the river, labels
  const wx=28,wy=68;WAYSTONES.push({id:'farm',name:'Goldenfield Waystone',tx:X(wx),ty:Y(wy),to:{x:X(29)*TS+16,y:Y(69)*TS+28}});
  NPCS.push({name:'Goldenfield Waystone',way:'farm',x:(X(wx)+.5)*TS,y:(Y(wy)+.9)*TS,spr:'waystone',lines:[]});GROW_NPC_ADDED++;
  FISH_SPOTS.push({id:'farm1',name:'Goldenfield River',tx:X(25),ty:Y(76),lv:2,tier:1,bank:[X(24),Y(76)]});
  REGION_LABELS.push({name:'OAKVALE SOUTH',tx:X(13),ty:Y(54)},{name:FARM_NAME,tx:X(30),ty:Y(66)},{name:'LAKE',tx:X(26),ty:Y(88)});
  // --- field monsters: boars roam the orchard and western meadow, scarecrows haunt the barley fields
  const eadd=(type,tx,ty)=>{const [x,y]=free(tx,ty);addEnemy(type,X(x),Y(y));};
  [[9,82],[15,78],[6,90],[20,86],[9,96],[23,74]].forEach(([x,y])=>eadd('boar',x,y));
  [[33,77],[46,77],[33,89],[46,89],[57,78]].forEach(([x,y])=>eadd('scarecrow',x,y));
  [[44,96],[54,90]].forEach(([x,y])=>eadd('boar',x,y));
}
if(growOn()){edGeom(0,0,0,GROW.S);EXP0.S=GROW.S;buildSouth();}
