/* =====================================================================
   PLACES: Oakvale Chapel (replaces the north-east cottage), fishing ponds, cleared ground under the monster spawners.
   Runs after the zones are built; refreshes the walkability map (reach) at the end.
   ===================================================================== */
function buildPlaces(){
  const set=(x,y,t)=>{if(x>=0&&y>=0&&x<MW&&y<MH)map[y][x]=t;};
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  // ---- Oakvale Chapel ----
  const C=CHAPEL,mid=C.door;
  fill(C.x0,C.y0,C.x1,C.y0,T.CHR);fill(C.x0,C.y0+1,C.x1,C.y0+1,T.CHS);                       // slate roof with a ridge
  fill(C.x0,C.y0+2,C.x1,C.y1,T.CHB);                                                          // limestone walls
  for(const wx of [19,21,23])set(wx,C.y0+2,T.CHW);                                            // stained glass behind the altar
  fill(C.x0+1,C.y0+3,C.x1-1,C.y1-1,T.CHF);                                                    // nave floor
  fill(mid,C.y0+4,mid,C.y1,T.CHC);                                                            // aisle carpet through the door
  set(mid,C.y0+3,T.CHA);                                                                      // altar
  for(const px of [19,20,22,23])for(const py of [C.y1-3,C.y1-2,C.y1-1])set(px,py,T.CHP);   // two rows of three pews              // pews
  set(19,C.y1,T.CHW);set(23,C.y1,T.CHW);                                                      // front windows
  // thin walls (t135u): the side columns and the front row become slim wall strips around a wider nave
  for(let y=C.y0+3;y<=C.y1;y++){set(C.x0,y,T.CWL);set(C.x1,y,T.CWL);}for(let x=C.x0+1;x<C.x1;x++)if(x!==mid)set(x,C.y1,T.CWL);
  // a little paved forecourt
  fill(20,C.y1+1,22,C.y1+1,T.P);
  // ---- fishing ponds ----
  for(const s of FISH_SPOTS){
    if(s.pond){const p=s.pond,zn=zoneOfTy(s.ty),floor=zn==='ow'?T.K:ZONES[zn].floor;
      fill(p.x-1,p.y-1,p.x+p.w,p.y+p.h,floor);fill(p.x,p.y,p.x+p.w-1,p.y+p.h-1,T.W);}
    else set(s.tx,s.ty,T.W);
    const [bx,by]=s.bank;if(solidTile(bx,by)||map[by][bx]===T.T)set(bx,by,zoneOfTy(by)==='ow'?(regions.forest(bx,by)?T.K:T.G):ZONES[zoneOfTy(by)].floor);
  }
  // ---- spawner sites: a clear 3x3 patch of the local ground ----
  for(const d of SPAWNER_DEFS){
    const zn=zoneOfTy(d.ty),fl=zn==='crypt'?T.CF:zn==='ow'?T.K:ZONES[zn].floor;
    fill(d.tx-1,d.ty-1,d.tx+1,d.ty+1,fl);
  }
}
buildPlaces();
(function(){for(const r of reach)r.fill(false);const sx=Math.floor(SPAWN.x/TS),sy=Math.floor(SPAWN.y/TS),q=[[sx,sy]];reach[sy][sx]=true;
  while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(!solidTile(nx,ny)&&!reach[ny][nx]){reach[ny][nx]=true;q.push([nx,ny]);}}}})();
// the minimaps were drawn before the chapel / ponds existed: redraw them
(function(){const g=miniMap.getContext('2d');for(let y=0;y<OW_H;y++)for(let x=0;x<MW;x++){g.fillStyle=TSPR.mini[map[y][x]]||'#000';g.fillRect(x*2,y*2,2,2);}
  for(const id in ZONES){const y0=ZONES[id].y0,m=MINI[id].spr.getContext('2d');for(let y=0;y<ZONE_H;y++)for(let x=0;x<MW;x++){m.fillStyle=TSPR.mini[map[y0+y][x]]||'#000';m.fillRect(x*2,y*2,2,2);}}})();
