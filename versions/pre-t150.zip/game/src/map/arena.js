/* =====================================================================
   THE EMBER ARENA: a torch-lit stone hall (rows 192..207 of the shared map) used by the boss rush.
   Reached only from the Arena Master in Oakvale; the exit rune is in the south-west corner.
   ===================================================================== */
const ARENA={x0:14,x1:49,y0:ARENA_Y0+2,y1:ARENA_Y0+13,exit:{x:16,y:ARENA_Y0+13},
  start:{x:32*TS+16,y:(ARENA_Y0+13)*TS+28,dir:'u'},boss:{x:32,y:ARENA_Y0+4}};
const ARENA_TERR={tx0:ARENA.x0+1,ty0:ARENA.y0,tx1:ARENA.x1-1,ty1:ARENA.y1};
function buildArena(){
  const set=(x,y,t)=>{if(x>=0&&y>=0&&x<MW&&y<MH)map[y][x]=t;};
  const fill=(x0,y0,x1,y1,t)=>{for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)set(x,y,t);};
  fill(0,ARENA_Y0-2,MW-1,ARENA_Y0+ARENA_H-1,T.CW);     // (also the two spare rows above, so the camera never shows grass)
  fill(ARENA.x0,ARENA.y0,ARENA.x1,ARENA.y1,T.CF);
  for(let x=ARENA.x0+2;x<=ARENA.x1-2;x+=6)set(x,ARENA.y0-1,T.CT);                       // wall torches
  [[22,ARENA.y0+3],[41,ARENA.y0+3],[22,ARENA.y0+8],[41,ARENA.y0+8]].forEach(([x,y])=>set(x,y,T.CP));   // four pillars to dodge around
  set(ARENA.exit.x,ARENA.exit.y,T.GX);ZEXITS[ARENA.exit.x+','+ARENA.exit.y]='arena';
}
buildArena();
MINI.arena={spr:makeSprite(MW*2,ARENA_H*2,g=>{g.fillStyle='#0a0814';g.fillRect(0,0,MW*2,ARENA_H*2);for(let y=0;y<ARENA_H;y++)for(let x=0;x<MW;x++){g.fillStyle=TSPR.mini[map[ARENA_Y0+y][x]]||'#000';g.fillRect(x*2,y*2,2,2);}}),y0:ARENA_Y0};
