/* =====================================================================
   CRYPT OF HOLLOW KINGS - tiles + monster sprites (all code-drawn)
   ===================================================================== */
(function buildCryptArt(){
  const stoneSpeck=(g,seed,cols,n)=>sprinkle(g,seed,cols,n);
  TSPR[T.CW]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3b3550');for(let y=0;y<16;y+=4){rect(g,0,y+3,16,1,'#241f35');const off=(y/4+v)%2?0:4;for(let x=off;x<16;x+=8)rect(g,x,y,1,3,'#241f35');}
    rect(g,0,0,16,1,'#5a5278');stoneSpeck(g,v+41,['#2e2942','#4a4466'],10);}));
  TSPR[T.CF]=[0,1,2,3].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#4a465e');rect(g,0,0,8,8,'#524e68');rect(g,8,8,8,8,'#524e68');
    rect(g,0,0,16,1,'#5e5a76');rect(g,0,0,1,16,'#5e5a76');rect(g,8,0,1,16,'#35314a');rect(g,0,8,16,1,'#35314a');stoneSpeck(g,v+51,['#3e3a54','#5c5874'],8);
    if(v===2){rect(g,3,10,4,1,'#e8e0c8');rect(g,4,9,1,3,'#e8e0c8');rect(g,10,4,3,1,'#cfc8b0');}   // scattered bones
    if(v===3){rect(g,4,4,1,1,'#2a7a4a');rect(g,10,11,1,1,'#2a7a4a');rect(g,11,10,1,1,'#3aaa6a');}}));
  TSPR[T.CP]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#4a465e');rect(g,2,12,12,3,'#2a2640');rect(g,3,11,10,2,'#6a6688');rect(g,4,1,8,11,'#3b3550');rect(g,5,1,6,11,'#7a7698');rect(g,6,1,2,11,'#a8a4c4');rect(g,3,0,10,2,'#8a86a8');rect(g,3,0,10,1,'#bab6d4');}));
  TSPR[T.CK]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#4a465e');rect(g,1,3,14,11,'#2a2640');rect(g,2,2,12,11,'#7a7698');rect(g,2,2,12,2,'#a8a4c4');rect(g,3,5,10,6,'#5e5a7c');rect(g,7,5,2,6,'#a8a4c4');rect(g,5,7,6,2,'#a8a4c4');rect(g,2,13,12,1,'#1c1830');}));
  TSPR[T.CT]=[0,1,2,3].map(f=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3b3550');for(let y=0;y<16;y+=4){rect(g,0,y+3,16,1,'#241f35');}rect(g,0,0,16,1,'#5a5278');
    rect(g,7,7,2,6,'#6b4423');rect(g,6,6,4,2,'#4a2c14');const h=[5,6,5,4][f];
    rect(g,6,6-h,4,h,'#ff8a1f');rect(g,7,6-h-1,2,h,'#ffd23f');rect(g,7,5-(h>>1),2,2,'#fff6c0');}));
  TSPR[T.CS]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#241f35');for(let i=0;i<6;i++){rect(g,0,i*3,16,3,i%2?'#4a465e':'#35314a');rect(g,0,i*3,16,1,'#6a6688');}rect(g,0,0,16,16,'rgba(8,4,24,.45)');rect(g,0,13,16,3,'#0a0818');}));
  TSPR[T.CX]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#4a465e');for(let i=0;i<5;i++){rect(g,2+i,15-i*3-3,12-i*2,3,i%2?'#a8a4c4':'#8a86a8');rect(g,2+i,15-i*3-3,12-i*2,1,'#d0cce4');}rect(g,6,0,4,3,'#ffe9a0');}));
  Object.assign(TSPR.mini,{[T.CW]:'#3b3550',[T.CF]:'#524e68',[T.CP]:'#8a86a8',[T.CK]:'#7a7698',[T.CT]:'#ff8a1f',[T.CS]:'#ffe14d',[T.CX]:'#ffe14d'});
  // ---- bat (16x16, drawn 2x; wings flap by squashing width) ----
  SP.bat=fromMap([
    '................','................','.b..........b...','.bb...bbbb..bb..','.bbb.bbbbbb.bbb.',
    '.bwbbbbbbbbbbwb.','..bwbbeppebbwb..','..bbbbbbbbbbbb..','...bbbbbbbbbb...','....bbwbbwbb....',
    '.....bbbbbb.....','......b..b......','................','................','................','................'],
    {b:'#4a3a6a',w:'#6e5a96',e:'#ff4a6a',p:'#fff'});
  autoOutline(SP.bat,'#140d22');
  // ---- wraith (16x16): hooded spectre with a ragged hem ----
  SP.wraith=fromMap([
    '.....oooooo.....','....ohhhhhho....','...ohhhhhhhho...','...ohhddddhho...','...ohdeddedho...',
    '...ohddddddho...','...ohhdwwdhho...','..ohhhddddhhho..','..ohhhhhhhhhho..','.ohhhhhhhhhhhho.',
    '.ohhhhhhhhhhhho.','.ohhhhhhhhhhhho.','.ohhohhhhhhohho.','.oh.ohhhhho.ho..','..o..ohhho..o...','.......oo.......'],
    {o:'#1a2a3e',h:'#7bb8d6',d:'#1a2230',e:'#7dffd0',w:'#d8fff0'});
  // ---- Lich King (32x32 -> drawn at 2x like the dragon): crowned skeleton in tattered robes with a soul staff ----
  SP.lich=autoOutline(makeSprite(32,32,g=>{
    const robe='#3a2a66',robeD='#241846',robeL='#5a44a0',bone='#e8e0c8',boneD='#b8b09a',gold='#e0b841',glow='#7dffa0';
    // robe
    tri(g,16,10,4,31,28,31,robe);tri(g,16,12,9,31,23,31,robeD);rect(g,8,28,16,3,robeD);
    for(let i=0;i<5;i++)rect(g,5+i*5,29+(i%2),3,2,robeL);
    rect(g,12,12,8,3,robeL);rect(g,9,13,14,3,robe);rect(g,7,15,4,7,robe);rect(g,21,15,4,7,robe);
    // ribs / chest
    rect(g,14,15,4,7,robeD);rect(g,14,16,4,1,boneD);rect(g,14,18,4,1,boneD);rect(g,14,20,4,1,boneD);
    // skull
    rect(g,11,3,10,9,bone);rect(g,12,2,8,2,bone);rect(g,12,11,8,3,boneD);rect(g,13,12,1,2,'#241846');rect(g,15,12,1,2,'#241846');rect(g,17,12,1,2,'#241846');
    rect(g,12,6,3,3,'#150d28');rect(g,17,6,3,3,'#150d28');rect(g,13,7,1,1,glow);rect(g,18,7,1,1,glow);rect(g,15,9,2,2,'#150d28');
    // crown
    rect(g,10,1,12,2,gold);tri(g,10,1,11,-1,12,1,gold);tri(g,15,1,16,-2,17,1,gold);tri(g,20,1,21,-1,22,1,gold);rect(g,15,0,2,2,'#e8407a');rect(g,11,1,1,1,'#7df9ff');rect(g,20,1,1,1,'#7df9ff');
    // hands + staff (right)
    rect(g,5,21,3,3,bone);rect(g,24,21,3,3,bone);rect(g,28,4,2,27,'#6b4423');rect(g,27,3,4,1,'#8a5a2c');
    ell(g,29,3,3,3,glow);ell(g,29,3,1,1,'#fff');
    // shoulders (spiked pauldrons)
    tri(g,5,13,7,9,9,14,'#241846');tri(g,27,13,25,9,23,14,'#241846');rect(g,6,13,3,2,gold);rect(g,23,13,3,2,gold);
  }),'#0e0820');
})();
