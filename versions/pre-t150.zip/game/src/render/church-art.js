/* =====================================================================
   OAKVALE CHAPEL ART (tiles, cross, priest) + world-art for the new features (fishing spot ripples, spawner brazier). All code-drawn, original.
   ===================================================================== */
Object.assign(T,{CHS:43,CHR:44,CHW:45,CHP:46,CHA:47,CHC:48,CHF:49,CHB:50});
['CHS','CHR','CHW','CHP','CHA','CHB'].forEach(k=>SOLID.add(T[k]));
(function buildChurchArt(){
  const sp=(g,seed,cols,n)=>sprinkle(g,seed,cols,n);
  // limestone chapel wall
  TSPR[T.CHB]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#d9d3c1');for(let y=0;y<16;y+=4){rect(g,0,y+3,16,1,'#b3ab96');const off=(y/4+v)%2?0:5;for(let x=off;x<16;x+=10)rect(g,x,y,1,3,'#b3ab96');}
    rect(g,0,0,16,1,'#ede8d8');sp(g,v+101,['#cbc4b0','#e4dfcf'],8);}));
  // slate roof + ridge
  TSPR[T.CHS]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3c4768');for(let y=0;y<16;y+=4){rect(g,0,y+3,16,1,'#252c46');const off=((y/4)+v)%2?0:4;for(let x=off;x<16;x+=8)rect(g,x,y,1,3,'#2c3452');rect(g,0,y,16,1,'#5a6a94');}}));
  TSPR[T.CHR]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3c4768');for(let y=6;y<16;y+=4){rect(g,0,y+3,16,1,'#252c46');rect(g,(y/4)%2?0:4,y,1,3,'#2c3452');rect(g,0,y,16,1,'#5a6a94');}
    rect(g,0,0,16,6,'#2a3150');rect(g,0,0,16,2,'#8d9bc4');rect(g,0,2,16,1,'#6c7ca8');rect(g,0,5,16,1,'#1c2138');}));
  // stained-glass window set into the wall (three colourways)
  const GL=[['#e24a4a','#4a7ae2','#f0c53a','#fff1b0'],['#4ac2e2','#a24ae2','#e2884a','#d8f6ff'],['#4ae28a','#e24a8a','#f0e03a','#eaffd0']];
  TSPR[T.CHW]=GL.map((c,v)=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#d9d3c1');rect(g,0,0,16,1,'#ede8d8');rect(g,0,15,16,1,'#b3ab96');
    rect(g,3,1,10,15,'#2a2438');rect(g,4,3,8,12,c[0]);rect(g,5,2,6,1,c[0]);rect(g,6,1,4,1,'#2a2438');
    rect(g,4,3,4,6,c[0]);rect(g,8,3,4,6,c[1]);rect(g,4,9,4,6,c[2]);rect(g,8,9,4,6,c[0]);
    rect(g,7,2,2,13,'#2a2438');rect(g,4,8,8,1,'#2a2438');rect(g,4,12,8,1,'#2a2438');
    rect(g,6,4,1,3,c[3]);rect(g,9,10,1,2,c[3]);rect(g,5,10,1,1,c[3]);
    rect(g,7,3,2,1,'#f6e9a0');}));                                  // a little cross-light at the top
  // pews, altar, carpet, floor
  const floor=g=>{rect(g,0,0,16,16,'#cfc8b3');rect(g,0,0,8,8,'#c4bda7');rect(g,8,8,8,8,'#c4bda7');rect(g,0,0,16,1,'#ddd7c4');rect(g,0,8,16,1,'#a9a28c');rect(g,8,0,1,16,'#a9a28c');};
  TSPR[T.CHF]=[0].map(()=>makeSprite(16,16,g=>{floor(g);sp(g,7,['#bab39d','#d9d3c0'],8);}));
  TSPR[T.CHC]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#8e1f2a');rect(g,0,0,2,16,'#d9b84a');rect(g,14,0,2,16,'#d9b84a');rect(g,3,0,1,16,'#6a1420');rect(g,12,0,1,16,'#6a1420');
    for(let y=v?4:0;y<16;y+=8){rect(g,6,y,4,4,'#b13a48');rect(g,7,y+1,2,2,'#d9b84a');}}));
  TSPR[T.CHP]=[0].map(()=>makeSprite(16,16,g=>{floor(g);rect(g,0,12,16,3,'rgba(60,40,20,.28)');rect(g,0,3,16,4,'#6a3f1e');rect(g,0,3,16,1,'#8a5a2c');rect(g,0,6,16,1,'#4a2a12');
    rect(g,1,7,14,5,'#a8703c');rect(g,1,7,14,1,'#c8904e');rect(g,1,11,14,1,'#7a4c22');rect(g,0,3,2,10,'#5a3416');rect(g,14,3,2,10,'#5a3416');}));
  TSPR[T.CHA]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#8e1f2a');rect(g,0,0,2,16,'#d9b84a');rect(g,14,0,2,16,'#d9b84a');   // altar standing on the carpet
    rect(g,1,13,14,2,'rgba(0,0,0,.3)');rect(g,1,5,14,9,'#f2efe4');rect(g,1,5,14,1,'#fff');rect(g,1,13,14,1,'#c9c4b2');rect(g,1,9,14,1,'#d9b84a');
    rect(g,7,6,2,6,'#d9b84a');rect(g,5,7,6,2,'#d9b84a');rect(g,7,6,2,1,'#fff3b0');                       // gold cross on the cloth
    rect(g,2,1,2,5,'#fffdf0');rect(g,12,1,2,5,'#fffdf0');rect(g,2,0,2,1,'#ffd34d');rect(g,12,0,2,1,'#ffd34d');}));
  TSPR.mini[T.CHB]='#d9d3c1';TSPR.mini[T.CHS]='#3c4768';TSPR.mini[T.CHR]='#5a6a94';TSPR.mini[T.CHW]='#e24a4a';TSPR.mini[T.CHP]='#a8703c';TSPR.mini[T.CHA]='#f2efe4';TSPR.mini[T.CHC]='#8e1f2a';TSPR.mini[T.CHF]='#cfc8b3';
  // the cross on the roof peak (12x18) and the priest
  SP.chapelCross=autoOutline(makeSprite(12,18,g=>{rect(g,5,0,2,18,'#f1eddd');rect(g,1,4,10,2,'#f1eddd');rect(g,5,0,1,18,'#fffdf0');rect(g,1,4,10,1,'#fffdf0');rect(g,6,5,1,13,'#c9c3ae');rect(g,3,6,8,1,'#c9c3ae');rect(g,5,15,2,3,'#b3ab96');}),'#1c2138');
  SP.priest=person({body:'#f0ecdc',bodyL:'#ffffff',bodyD:'#b9b29a',hair:'#bdbdc8',skin:'#f2c9a0',dir:'d',belt:'#7a4ab0'});
  {const g=SP.priest.getContext('2d');rect(g,7,7,2,4,'#7a4ab0');rect(g,7,8,2,1,'#f6e9a0');rect(g,4,0,8,1,'#14182c');                    // purple stole + a small gold cross
    rect(g,6,12,4,1,'#7a4ab0');}
  SP.fisher=person({body:'#2f6f8a',bodyL:'#68b4d0',bodyD:'#1d4658',hair:'#8a6a3a',skin:'#e8b88a',dir:'d',belt:'#6a4a2a',hat:'#d8c068',beard:'#9a7a4a'});
  // fishing spot: a ring of ripples + silver glints (animated in drawFishSpots)
  SP.rodIcon=autoOutline(makeSprite(16,16,g=>{line(g,2,14,13,2,'#8a5a2c');rect(g,13,2,1,1,'#d9b84a');line(g,13,3,14,10,'#e8e8f0');rect(g,13,11,3,2,'#e24a4a');rect(g,14,11,1,2,'#fff');}),'#14121e');
  SP.fishIcon=autoOutline(makeSprite(16,16,g=>{ell(g,7,8,5,3,'#8fc8e8');rect(g,5,6,6,1,'#c8e8f8');tri(g,11,8,15,4,15,12,'#6aa8d0');rect(g,4,7,1,1,'#14182c');rect(g,6,9,4,1,'#5a98c0');}),'#14121e');
})();
/* coloured light falling through the chapel's windows onto the nave, drawn over the floor */
function drawChurchFx(){
  const cx=Math.round(cam.x),cy=Math.round(cam.y),x0=CHAPEL.x0*TS-cx,y0=CHAPEL.y0*TS-cy;
  if(x0>VW+20||y0>VH+20||x0+(CHAPEL.x1-CHAPEL.x0+1)*TS<-20||y0+(CHAPEL.y1-CHAPEL.y0+1)*TS<-20)return;
  const cols=['rgba(226,74,74,','rgba(74,122,226,','rgba(240,197,58,'],ws=[19,21,23];
  ctx.save();
  ws.forEach((wx,i)=>{const bx=wx*TS-cx,by=(CHAPEL.y0+3)*TS-cy,a=.10+.04*Math.sin(gtime*.8+i*2);
    ctx.fillStyle=cols[i]+a+')';ctx.beginPath();ctx.moveTo(bx+4,by);ctx.lineTo(bx+28,by);ctx.lineTo(bx+28+34,by+TS*3);ctx.lineTo(bx+4+34,by+TS*3);ctx.closePath();ctx.fill();});
  for(let k=0;k<6;k++){const t=(gtime*.12+k/6)%1;ctx.fillStyle=`rgba(255,244,200,${.5*(1-Math.abs(t-.5)*2)})`;ctx.fillRect(Math.round(x0+TS*1.5+((k*37)%5)*TS*.9+Math.sin(gtime+k)*3),Math.round(y0+TS*3.2+t*TS*3),2,2);}
  ctx.restore();
}

