/* =====================================================================
   M23 GRAVEL PATHS: every dirt-path tile is drawn per pixel from WORLD coordinates, so neighbouring tiles line up perfectly.
   The road edge is a soft, wobbling line (value noise) instead of the tile grid: grass creeps onto the road edge, dirt spills a
   little onto the grass, with gravel speckle, pebbles and little grass tufts on the border. Built lazily per tile and cached.
   ===================================================================== */
const PATH_CACHE=new Map();
function ph(x,y,s){let h=(Math.imul(x|0,374761393)+Math.imul(y|0,668265263)+Math.imul(s,1274126177))|0;h=Math.imul(h^(h>>>13),1274126177);h^=h>>>16;return (h>>>0)/4294967296;}
function pnoise(x,y,sc,s){
  const gx=x/sc,gy=y/sc,x0=Math.floor(gx),y0=Math.floor(gy),fx=gx-x0,fy=gy-y0,u=fx*fx*(3-2*fx),v=fy*fy*(3-2*fy);
  const a=ph(x0,y0,s),b=ph(x0+1,y0,s),c=ph(x0,y0+1,s),d=ph(x0+1,y0+1,s);
  return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v;
}
const pathWobble=(wx,wy)=>-1.5+4.1*(.62*pnoise(wx,wy,7,1)+.38*pnoise(wx,wy,3.5,2));   // boundary offset in px, -1.5 .. +2.6
function isGrassyTile(tx,ty){
  if(tx<0||ty<0||tx>=MW||ty>=MH)return false;const t=map[ty][tx];
  return t===T.G||t===T.K||t===T.L||t===T.T||t===T.BU||t===T.ST||t===T.LN||(typeof TREE_IDS!=='undefined'&&TREE_IDS.has(t));
}
const isPathTile=(tx,ty)=>tx>=0&&ty>=0&&tx<MW&&ty<MH&&map[ty][tx]===T.P;
const rectDist=(px,py,rx,ry)=>{const dx=Math.max(rx-px,0,px-(rx+16)),dy=Math.max(ry-py,0,py-(ry+16));return Math.hypot(dx,dy);};
// signed distance (px) from the pixel to the tile-grid boundary between road and grass: >0 inside the road, <0 on the grass side, null = nowhere near a boundary
function pathEdgeS(wx,wy,tx,ty,onPath){
  const px=wx+.5,py=wy+.5;let best=1e9;
  for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){
    const nx=tx+dx,ny=ty+dy;if(!dx&&!dy)continue;
    if(onPath?isGrassyTile(nx,ny):isPathTile(nx,ny)){const d=rectDist(px,py,nx*16,ny*16);if(d<best)best=d;}
  }
  return best>=1e8?null:(onPath?best:-best);
}
function dirtColour(wx,wy,e){   // e = distance (px) inside the wobbly road edge; 1e9 = deep inside
  const h=ph(wx,wy,3),n2=pnoise(wx,wy,9,5);
  let c=n2>.64?'#d6ba85':n2<.28?'#e2c897':'#dcc18f';
  if(h<.06)c='#cfb07a';else if(h<.10)c='#e8d1a2';else if(h<.125)c='#c7a770';else if(h<.15)c='#eed8aa';
  if(e>2.2){   // pebbles (2x2), on a loose 6px grid
    const cx=Math.floor(wx/6),cy=Math.floor(wy/6);
    if(ph(cx,cy,9)<.38){const px0=cx*6+1+Math.floor(ph(cx,cy,10)*3),py0=cy*6+1+Math.floor(ph(cx,cy,11)*3),ix=wx-px0,iy=wy-py0;
      if(ix>=0&&ix<2&&iy>=0&&iy<2)c=iy===1?'#a8906a':ix===0?'#d8cdb4':'#b9a98c';}
  }
  if(e<1.5){if(ph(wx,wy,4)<.6)c='#c9ad7c';if(e<.8&&ph(wx,wy,8)<.5)c='#bfa371';}   // darker gravel lip
  return c;
}
function pathTileSprite(tx,ty){
  const key=ty*MW+tx,hit=PATH_CACHE.get(key);if(hit)return hit;
  const onPath=map[ty][tx]===T.P;
  let baseSpr=null;
  if(onPath){   // grass showing through the road edge: take the neighbouring grass type
    let kind=T.G;for(const [dx,dy] of [[0,-1],[0,1],[-1,0],[1,0],[-1,-1],[1,-1],[-1,1],[1,1]]){const nx=tx+dx,ny=ty+dy;if(isGrassyTile(nx,ny)){kind=map[ny][nx]===T.K?T.K:T.G;break;}}
    baseSpr=TSPR[kind][hash2(tx,ty)%TSPR[kind].length];
  }else{const a=TSPR[map[ty][tx]];baseSpr=a[hash2(tx,ty)%a.length];}
  const spr=makeSprite(16,16,g=>{
    g.drawImage(baseSpr,0,0);
    for(let py=0;py<16;py++)for(let px=0;px<16;px++){
      const wx=tx*16+px,wy=ty*16+py,s=pathEdgeS(wx,wy,tx,ty,onPath);
      let e;
      if(s===null){if(!onPath)continue;e=1e9;}
      else{e=s-pathWobble(wx,wy);}
      if(e>0){
        let c=dirtColour(wx,wy,e);
        if(e<2.2&&ph(wx,wy,6)<.07)c=ph(wx,wy,12)<.5?'#5aaa45':'#7ccc62';   // a blade of grass poking onto the road edge
        g.fillStyle=c;g.fillRect(px,py,1,1);
      }else if(e>-3.2&&ph(wx,wy,7)<.11){     // little tufts creeping along the grass side
        g.fillStyle=ph(wx,wy,13)<.5?'#7ccc62':'#3d8530';g.fillRect(px,py,1,1);
        if(py>0&&ph(wx,wy,14)<.5){g.fillStyle='#7ccc62';g.fillRect(px,py-1,1,1);}
      }
    }
  });
  PATH_CACHE.set(key,spr);return spr;
}
// grass tile next to a road? (memoised)
let EDGE_MEMO=null;   // 0 unknown, 1 plain, 2 has road neighbour
function grassNearRoad(tx,ty){
  if(!EDGE_MEMO)EDGE_MEMO=new Int8Array(MW*MH);const k=ty*MW+tx,m=EDGE_MEMO[k];if(m)return m===2;
  let r=false;for(let dy=-1;dy<=1&&!r;dy++)for(let dx=-1;dx<=1;dx++)if((dx||dy)&&isPathTile(tx+dx,ty+dy)){r=true;break;}
  EDGE_MEMO[k]=r?2:1;return r;
}
