/* =====================================================================
   ANIMATION (t138u): procedural idle / walk cycles on top of the code sprites.
   - ENEMIES by body plan: slimes squash-and-hop, flyers flap (wing squeeze + bob), four-legged beasts trot (rock + bob),
     walkers step (tilt + bounce), mushrooms wobble, floaters drift; everyone breathes when idle.
   - NPCs: a walk cycle when they move (bounce + sway), idle breathing, blinking, and a talk gesture while you speak with them.
   - PLAYER: idle breathe, a walk cycle, a separate RUN cycle (faster stride, forward lean, bigger bounce), a dash pose
     (stretched + leaning), shoot recoil, a charge crouch with shiver, and a red hurt flash.
   ===================================================================== */
const ANIM_PLAN={slime:'slime',gel:'slime',bat:'fly',fbat:'fly',wraith:'float',lantern:'float',spore:'float',
  wolf:'beast',boar:'beast',bboar:'beast',scorpion:'beast',shscorp:'beast',crawler:'beast',tortoise:'beast',toad:'hop',
  redcap:'shroom',shroom:'shroom',greencap:'shroom',ambercap:'shroom',babyshroom:'shroom',ironcap:'shroom',spitter:'shroom',frostcap:'shroom',shadowcap:'shroom',chestcap:'shroom',brute:'shroom'};
const animPlan=t=>ANIM_PLAN[t]||'walk';
/* returns scale x/y, rotation, lift (px up) */
function enemyAnim(e,fighting){
  const t=e.bob||0,moving=fighting||e.chasing||e.mode==='walk'||e.ret,plan=animPlan(e.type);let sx=1,sy=1,rot=0,lift=0;
  switch(plan){
    case 'slime':{const ph=(t*(moving?1.6:.9))%(Math.PI*2),s=Math.sin(ph);if(moving){lift=Math.max(0,s)*7;const land=Math.max(0,-s);sy=1+(s>0?.12*s:-.18*land);sx=2-sy;}else{sy=1+Math.sin(t*1.4)*.05;sx=2-sy;}break;}
    case 'hop':{const s=Math.sin(t*(moving?2:1));lift=moving?Math.max(0,s)*6:0;sy=1+(moving?(s>0?.08:-.1)*Math.abs(s):Math.sin(t)*.03);sx=2-sy;break;}
    case 'fly':{const f=Math.sin(t*(moving?9:6));sx=1+f*.18;sy=1-f*.06;lift=9+Math.sin(t*.9)*3;rot=Math.sin(t*1.3)*.06;break;}
    case 'float':{lift=5+Math.sin(t*.7)*3;rot=Math.sin(t*.9)*.05;sy=1+Math.sin(t*1.4)*.03;break;}
    case 'beast':{if(moving){const s=Math.sin(t*3.2);lift=Math.abs(s)*2.5;rot=s*.06;sy=1-Math.abs(s)*.04;}else sy=1+Math.sin(t*1.1)*.025;break;}
    case 'shroom':{if(moving){const s=Math.sin(t*2.6);rot=s*.09;lift=Math.abs(s)*2.5;sy=1+Math.abs(Math.cos(t*2.6))*.05;}else{sy=1+Math.sin(t*1.3)*.035;rot=Math.sin(t*.7)*.025;}break;}
    default:{if(moving){const s=Math.sin(t*2.8);lift=Math.abs(s)*2.2;rot=s*.05;sy=1+Math.abs(Math.cos(t*2.8))*.03;}else sy=1+Math.sin(t*1.2)*.025;}
  }
  return {sx,sy,rot,lift};
}
/* ---- NPCs ---- */
const NPC_BLINK=new Map();
function blinkOf(spr){   // closes the eyes: dark pixels in the face area with lighter pixels left/right get painted with the pixel above
  if(NPC_BLINK.has(spr))return NPC_BLINK.get(spr);let out=null;
  try{const w=spr.width,h=spr.height,c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.drawImage(spr,0,0);
    const d=g.getImageData(0,0,w,h),a=d.data,px=(x,y)=>(y*w+x)*4,lum=i=>a[i]*.3+a[i+1]*.59+a[i+2]*.11;let n=0;
    for(let y=Math.floor(h*.18);y<Math.floor(h*.5);y++)for(let x=1;x<w-1;x++){const i=px(x,y);if(a[i+3]<200||lum(i)>70)continue;const l=px(x-1,y),r=px(x+1,y),u=px(x,y-1);
      const skin=j=>a[j+3]>200&&a[j]>150&&a[j]>a[j+2]&&lum(j)>120;
      if((skin(l)||skin(r))&&skin(u)){a[i]=a[u];a[i+1]=a[u+1];a[i+2]=a[u+2];n++;}}
    if(n>0&&n<=6){g.putImageData(d,0,0);out=c;}}catch(e){}
  NPC_BLINK.set(spr,out);return out;
}
function npcAnim(n){
  const mv=n._lx!=null&&Math.hypot(n.x-n._lx,n.y-n._ly)>.05;n._lx=n.x;n._ly=n.y;
  n._wt=mv?(n._wt||0)+.16:0;const ph=gtime*1.7+n.x*.013;
  const talking=!!(DLG&&DLG.name&&(DLG.name===n.name||DLG.name===(n.label||'').toUpperCase()||DLG.name===n.name.toUpperCase())&&Math.hypot(n.x-P.x,n.y-P.y)<120);
  let sx=1,sy=1,rot=0,lift=0;
  if(mv){const s=Math.sin(n._wt*3);lift=Math.abs(s)*2;rot=s*.05;}
  else if(n.bench){lift=-4;sy=.94+Math.sin(ph)*.012;}
  else sy=1+Math.sin(ph)*.022;
  if(talking){rot+=Math.sin(gtime*7)*.045;lift+=Math.abs(Math.sin(gtime*5))*1.2;}
  const blink=!mv&&((gtime+n.x*.37)%4.2)<.13;
  return {sx,sy,rot,lift,blink,talking};
}
function drawNpcAnimated(n){
  const spr=n.way&&!SEC.ways[n.way]?SP.waystoneOff:SP[n.spr];if(!spr)return;
  if(n.way||n.sign135||n.spr==='houseSign'||n.spr==='waystone'||n.house){draw(spr,n.x-cam.x-16,n.y-cam.y-31+Math.round(Math.sin(gtime*2+n.x)*.6),2);return;}
  const a=npcAnim(n),bx=Math.round(n.x-cam.x),by=Math.round(n.y-cam.y+1-a.lift);
  ctx.save();ctx.translate(bx,by);ctx.rotate(a.rot);ctx.scale(a.sx,a.sy);
  const img=a.blink&&blinkOf(spr)||spr;ctx.drawImage(img,-16,-32,spr.width*2,spr.height*2);ctx.restore();
  if(a.talking){const k=Math.floor(gtime*6)%3;ctx.fillStyle='#fff8e0';for(let i=0;i<3;i++)if(i<=k)ctx.fillRect(bx+10+i*4,by-36-i*2,2,2);}
}
/* ---- player ---- */
const PANIM={hurt:0,lastHp:null};
function playerAnim(){
  if(PANIM.lastHp!=null&&P.hp<PANIM.lastHp-.5)PANIM.hurt=.35;PANIM.lastHp=P.hp;PANIM.hurt=Math.max(0,PANIM.hurt-1/60);
  const run=typeof runActive==='function'&&runActive()&&P.moving,dashing=DASH.t>0,dx=P.dir==='r'?1:P.dir==='l'?-1:0;
  let sx=1,sy=1,rot=0,lift=0,ox=0,pose='idle';
  if(dashing){pose='dash';sx=1.18;sy=.86;rot=dx*.22;}
  else if(B&&B.charging&&B.charge>.15){pose='charge';sy=.93;sx=1.05;ox=Math.sin(gtime*60)*(B.charge>=1?1.2:.5);}
  else if(B&&B.shootAnim>0){pose='shoot';ox=-dx*3*B.shootAnim/.12;sy=.97;}
  else if(run){pose='run';const s=Math.sin(P.anim*1.15);lift=Math.abs(s)*3.2;rot=dx*.1+s*.03;sy=1+Math.abs(Math.cos(P.anim*1.15))*.05;}
  else if(P.moving){pose='walk';const s=Math.sin(P.anim*.9);lift=Math.abs(s)*1.4;rot=s*.025;}
  else{sy=1+Math.sin(gtime*2.2)*.02;}
  return {sx,sy,rot,lift,ox,pose,hurt:PANIM.hurt};
}
