
/* ---------- pixel-art helpers (all art is drawn in code) ---------- */
function makeSprite(w,h,fn){const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.imageSmoothingEnabled=false;fn(g);return c;}
const rect=(g,x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(x,y,w,h);};
function ell(g,cx,cy,rx,ry,c){g.fillStyle=c;for(let y=-ry;y<=ry;y++)for(let x=-rx;x<=rx;x++){if((x*x)/(rx*rx+.3)+(y*y)/(ry*ry+.3)<=1)g.fillRect(Math.round(cx+x),Math.round(cy+y),1,1);}}
function tri(g,x1,y1,x2,y2,x3,y3,c){g.fillStyle=c;const minx=Math.floor(Math.min(x1,x2,x3)),maxx=Math.ceil(Math.max(x1,x2,x3)),miny=Math.floor(Math.min(y1,y2,y3)),maxy=Math.ceil(Math.max(y1,y2,y3));
  const d=(x2-x1)*(y3-y1)-(x3-x1)*(y2-y1);if(!d)return;
  for(let y=miny;y<=maxy;y++)for(let x=minx;x<=maxx;x++){const px=x+.5,py=y+.5;const a=((x2-px)*(y3-py)-(x3-px)*(y2-py))/d,b=((x3-px)*(y1-py)-(x1-px)*(y3-py))/d,cc=1-a-b;if(a>=0&&b>=0&&cc>=0)g.fillRect(x,y,1,1);}}
function line(g,x0,y0,x1,y1,c,t=1){g.fillStyle=c;const n=Math.max(Math.abs(x1-x0),Math.abs(y1-y0));for(let i=0;i<=n;i++){const x=Math.round(lerp(x0,x1,n?i/n:0)),y=Math.round(lerp(y0,y1,n?i/n:0));g.fillRect(x,y,t,t);}}
function fromMap(rows,pal){const w=Math.max(...rows.map(r=>r.length));return makeSprite(w,rows.length,g=>{rows.forEach((r,y)=>{for(let x=0;x<r.length;x++){const ch=r[x];if(ch!=='.'&&pal[ch]){g.fillStyle=pal[ch];g.fillRect(x,y,1,1);}}});});}
function flipH(c){return makeSprite(c.width,c.height,g=>{g.translate(c.width,0);g.scale(-1,1);g.drawImage(c,0,0);});}
const whiteCache=new Map();
function whiteOf(c){let w=whiteCache.get(c);if(!w){w=makeSprite(c.width,c.height,g=>{g.drawImage(c,0,0);g.globalCompositeOperation='source-atop';g.fillStyle='#fff';g.fillRect(0,0,c.width,c.height);});whiteCache.set(c,w);}return w;}
function autoOutline(c,col){const g=c.getContext('2d'),w=c.width,h=c.height,d=g.getImageData(0,0,w,h),o=new Uint8ClampedArray(d.data);
  const r=parseInt(col.slice(1,3),16),gg=parseInt(col.slice(3,5),16),b=parseInt(col.slice(5,7),16);
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){const i=(y*w+x)*4;if(d.data[i+3]===0){const n=[[1,0],[-1,0],[0,1],[0,-1]].some(([dx,dy])=>{const xx=x+dx,yy=y+dy;return xx>=0&&yy>=0&&xx<w&&yy<h&&d.data[(yy*w+xx)*4+3]>0;});if(n){o[i]=r;o[i+1]=gg;o[i+2]=b;o[i+3]=255;}}}
  g.putImageData(new ImageData(o,w,h),0,0);return c;}
function draw(c,x,y,s=1,flip=false){const w=c.width*s,h=c.height*s;if(flip){ctx.save();ctx.translate(Math.round(x)+w,Math.round(y));ctx.scale(-1,1);ctx.drawImage(c,0,0,w,h);ctx.restore();}else ctx.drawImage(c,Math.round(x),Math.round(y),w,h);}

/* text helpers */
let TXS=1;                                   // text-size setting (settings.js): small UI text grows, big text is left alone
const scaleText=z=>z<=11?Math.round(z*TXS*2)/2:z;
function txt(s,x,y,o={}){const size=scaleText(o.size||12);ctx.font=(o.bold===false?'':'bold ')+size+'px "Courier New",monospace';ctx.textAlign=o.align||'left';ctx.textBaseline=o.base||'alphabetic';
  ctx.globalAlpha=o.alpha==null?1:o.alpha;
  if(o.out!==false){ctx.lineWidth=o.lw||3;ctx.lineJoin='round';ctx.strokeStyle=o.out||'#000';ctx.strokeText(s,x,y);}
  ctx.fillStyle=o.col||'#fff';ctx.fillText(s,x,y);ctx.globalAlpha=1;}
function panel(x,y,w,h,o={}){ctx.fillStyle=o.shadow||'rgba(0,0,0,.45)';ctx.fillRect(x+3,y+3,w,h);ctx.fillStyle=o.border||'#e8e0c8';ctx.fillRect(x,y,w,h);ctx.fillStyle=o.fill||'#1a1630';ctx.fillRect(x+2,y+2,w-4,h-4);ctx.fillStyle=o.inner||'#2c2650';ctx.fillRect(x+3,y+3,w-6,2);}
function bar(x,y,w,h,f,col,bg='#120e20',bd='#000'){ctx.fillStyle=bd;ctx.fillRect(x-1,y-1,w+2,h+2);ctx.fillStyle=bg;ctx.fillRect(x,y,w,h);ctx.fillStyle=col;ctx.fillRect(x,y,Math.round(w*clamp(f,0,1)),h);ctx.fillStyle='rgba(255,255,255,.25)';ctx.fillRect(x,y,Math.round(w*clamp(f,0,1)),Math.max(1,h>>2));}
