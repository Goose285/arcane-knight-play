/* =====================================================================
   t143u DUNGEON ENTRANCES + ENCLOSED INTERIORS
   - Each dungeon door on the overworld gets its own facade (drawn over its existing tiles; collision unchanged):
       CRYPT (Lich King): a slate mausoleum - pointed roof, pillars, a skull keystone, green soul-braziers, stairs down
       FROSTHOWL: an ice-stone arch with a snow cap and icicles     MIREWOOD: a twisted root arch with moss and hanging lanterns
       SUNDERED RUINS: sandstone pillars with glyph bands and a sun disk
   - Inside a dungeon (crypt / snow / swamp / desert) nothing of another area is drawn: the gap rows between areas and any column
     outside the 64-wide interior show solid cave darkness instead of overworld grass.
   ===================================================================== */
const ENTR=(()=>{
  const O='#1a1420',r=(g,x,y,w,h,c)=>rect(g,x,y,w,h,c);
  const art={
    crypt:{w:5,h:3,f(g){const S='#5a5868',L='#7a7888',D='#3a3848';
      r(g,8,10,64,38,O);r(g,9,11,62,37,S);for(let y=14;y<46;y+=5)for(let x=9+((y/5|0)%2)*5;x<70;x+=10){r(g,x,y,9,1,D);r(g,x,y-4,1,4,D);}
      tri(g,4,14,40,0,76,14,O);tri(g,8,13,40,2,72,13,'#4a4858');r(g,6,13,68,3,L);                         // roof
      for(const px of [12,60]){r(g,px,16,8,32,O);r(g,px+1,16,6,32,L);r(g,px+1,16,2,32,'#9a98a8');}         // pillars
      r(g,30,22,20,26,O);r(g,32,24,16,24,'#0c0a12');ell(g,40,24,8,6,'#0c0a12');                             // doorway
      for(let i=0;i<4;i++)r(g,33,36+i*3,14,1,'#2a2834');                                                    // stairs down
      ell(g,40,15,4,4,'#e8e0c8');r(g,38,14,1,2,O);r(g,41,14,1,2,O);r(g,39,18,3,1,O);                       // skull keystone
      for(const bx of [2,70]){r(g,bx,36,8,12,O);r(g,bx+1,37,6,10,'#3a3848');ell(g,bx+4,33,3,4,'#5dff9a');ell(g,bx+4,34,2,2,'#c8ffd8');}}},  // soul braziers
    snow:{w:3,h:2,f(g){const S='#b8d4e8',L='#e8f6ff',D='#7aa0c0';
      r(g,0,6,48,26,O);r(g,1,7,46,25,S);r(g,14,12,20,20,'#0c1420');ell(g,24,13,10,7,'#0c1420');
      for(let y=10;y<30;y+=5)for(let x=1+((y/5|0)%2)*4;x<46;x+=8)if(x<13||x>34)r(g,x,y,7,1,D);
      ell(g,24,6,24,5,'#ffffff');r(g,0,4,48,4,L);                                                          // snow cap
      for(const ix of [4,10,18,28,36,43])tri(g,ix,8,ix+3,8,ix+1.5,14+(ix%3)*2,'#dff4ff');}},              // icicles
    swamp:{w:3,h:2,f(g){const W='#5a3a22',L='#7a5432',M='#5f9a3a';
      r(g,2,8,9,24,O);r(g,37,8,9,24,O);r(g,3,8,7,24,W);r(g,38,8,7,24,W);r(g,4,8,2,24,L);r(g,39,8,2,24,L);    // root posts
      for(let i=0;i<48;i++){const y=6+Math.round(Math.abs(i-24)*.22);r(g,i,y,1,5,O);r(g,i,y+1,1,3,i%5?W:L);}   // twisted lintel
      r(g,11,14,26,18,'#0e140c');for(const mx of [3,9,16,27,33,41])r(g,mx,5+(mx%4),3,2,M);                    // dark way + moss
      for(const lx of [14,32]){r(g,lx,10,1,5,'#2a2a2a');r(g,lx-2,15,5,6,O);r(g,lx-1,16,3,4,'#ffd060');}}},    // lanterns
    desert:{w:3,h:2,f(g){const S='#d8b878',L='#f0d8a0',D='#a88850';
      for(const px of [1,35]){r(g,px,6,12,26,O);r(g,px+1,6,10,26,S);r(g,px+1,6,3,26,L);for(let y=12;y<30;y+=6){r(g,px+2,y,8,1,D);r(g,px+4,y+2,1,2,D);r(g,px+7,y+2,2,1,D);}}
      r(g,0,3,48,6,O);r(g,1,4,46,4,L);r(g,13,9,22,23,'#140e08');                                            // lintel + dark way
      ell(g,24,4,5,5,'#ffb02e');ell(g,24,4,3,3,'#ffe14d');}},                                               // sun disk
  };
  const cache=new Map();
  function facade(kind){let c=cache.get(kind);if(!c){const a=art[kind];c=makeSprite(a.w*16,a.h*16,a.f);cache.set(kind,c);}return c;}
  function piece(kind,i,j){const k=kind+i+','+j;let s=cache.get(k);if(!s){const fc=facade(kind);s=makeSprite(16,16,g=>{g.drawImage(TSPR[T.G][0],0,0);g.drawImage(fc,i*16,j*16,16,16,0,0,16,16);});cache.set(k,s);}return s;}
  let IDX=null,IDXT=-1;
  function index(){if(IDX&&gtime-IDXT<2)return IDX;IDXT=gtime;IDX=new Map();
    const add=(kind,x0,y0)=>{const a=art[kind];for(let j=0;j<a.h;j++)for(let i=0;i<a.w;i++)IDX.set((x0+i)+','+(y0+j),[kind,i,j]);};
    try{add('crypt',CRYPT_IN.x-2,CRYPT_IN.y-2);}catch(e){}
    try{for(const k in GATES){const [x,y]=k.split(',').map(Number);add(GATES[k],x-1,y-1);}}catch(e){}
    return IDX;}
  const DUN=new Set(['crypt','snow','swamp','desert']);
  let dark=null;
  function darkTile(x,y){if(!dark)dark=[0,1,2,3].map(v=>makeSprite(16,16,g=>{r(g,0,0,16,16,'#07060a');for(let i=0;i<5;i++){const h=hash2(v*31+i,i*7)>>>0;r(g,h%14,(h>>>4)%14,2,1,'#100c14');}}));return dark[(hash2(x,y)>>>3)&3];}
  function tile(id,x,y){
    const pz=zoneOfPx(P.y);
    if(DUN.has(pz)){const out=pz==='crypt'?(y<CRY0||y>CRY_END):(y<ZONES[pz].y0||y>=ZONES[pz].y0+ZONE_H);if(out||x>=64)return darkTile(x,y);return null;}
    if(pz!=='ow')return null;
    const e=index().get(x+','+y);if(e)return piece(e[0],e[1],e[2]);
    return null;
  }
  return {tile,art,index};
})();
{const _ts=tileSprite;tileSprite=function(id,x,y,time){const s=ENTR.tile(id,x,y);return s||_ts.apply(this,arguments);};}
