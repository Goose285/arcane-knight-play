/* ---- MOCKUP ONLY (off by default): ?wellopt=1..4 swaps the village pond for one of four alternative well / fountain designs so they can be screenshotted
   in the town square (store/well-option-N.png). Nothing changes without the URL parameter: same 4x4 solid tiles, same collision, the real well is untouched. ---- */
const WELLOPT=(()=>{const v=+(new URLSearchParams(location.search).get('wellopt')||0);return v>=1&&v<=4?v:0;})();
const WM_NOISE=(x,y,s)=>{let h=Math.imul(x+1,374761393)^Math.imul(y+7,668265263)^Math.imul((s|0)+13,2246822519);h=Math.imul(h^h>>>13,1274126177);return((h^h>>>16)>>>0)/4294967296;};
function wmGrass(g){const P0=VILLAGE_POND;for(let ty=0;ty<4;ty++)for(let tx=0;tx<4;tx++){const gs=TSPR[T.G];g.drawImage(gs[hash2(P0.x0+tx,P0.y0+ty)%gs.length],tx*16,ty*16);}}
function wmWaterData(f){   // the game's animated water texture over the whole 64x64 block
  const P0=VILLAGE_POND,wf=TSPR[T.PW],wc=makeSprite(64,64,w=>{for(let i=0;i<16;i++)w.drawImage(wf[(f&3)+4*(hash2(P0.x0+(i%4),P0.y0+(i>>2))&1)],(i%4)*16,(i>>2)*16);});
  return wc.getContext('2d').getImageData(0,0,64,64);
}
// paint water where fn(x,y) returns a brightness factor (falsy = not water)
function wmWater(g,f,fn){const src=wmWaterData(f),dst=g.getImageData(0,0,64,64);
  for(let y=0;y<64;y++)for(let x=0;x<64;x++){const k=fn(x+.5,y+.5);if(!k)continue;const i=(y*64+x)*4;dst.data[i]=src.data[i]*k;dst.data[i+1]=src.data[i+1]*k;dst.data[i+2]=src.data[i+2]*k;dst.data[i+3]=255;}
  g.putImageData(dst,0,0);}
function wmShadow(g,cx,cy,rx,ry,a){for(let y=-ry;y<=ry;y++)for(let x=-rx;x<=rx;x++)if(x*x/(rx*rx)+y*y/(ry*ry)<=1){g.fillStyle='rgba(10,24,16,'+a+')';g.fillRect(Math.round(cx+x),Math.round(cy+y),1,1);}}
function wmStone(x,y,s,lit){const r=WM_NOISE(x>>1,y>>1,s),c=r<.25?'#a4a7b6':r<.6?'#9a9dac':'#8e91a0';return c;}
/* option 1: classic round stone well with a wooden roof, rope and bucket (ground part: the stone cylinder) */
function wmBlock1(f){return makeSprite(64,64,g=>{wmGrass(g);wmShadow(g,36,50,19,5,.22);
  const cx=32,cyT=33,rx=15,ry=8,hgt=11;
  for(let y=0;y<64;y++)for(let x=0;x<64;x++){const px=x+.5-cx;
    const top=(px*px)/(rx*rx)+((y+.5-cyT)*(y+.5-cyT))/(ry*ry)<=1,bot=(px*px)/(rx*rx)+((y+.5-cyT-hgt)*(y+.5-cyT-hgt))/(ry*ry)<=1,mid=Math.abs(px)<=rx&&y+.5>=cyT&&y+.5<=cyT+hgt;
    if(!(top||bot||mid))continue;
    if(top){const d=Math.hypot(px/rx,(y+.5-cyT)/ry);g.fillStyle=d>.78?(WM_NOISE(x>>1,y>>1,3)<.5?'#c4c7d4':'#b4b7c6'):d>.62?'#6a6e80':'#262a3c';g.fillRect(x,y,1,1);continue;}
    const row=Math.floor((y-cyT)/3.6),off=(row&1)*3,col=Math.floor((x+off)/6),edge=((x+off)%6===0)||((y-cyT)%3.6<1&&false);
    let c=wmStone(col,row,5);if((x+off)%6===0)c='#5a5e70';if(Math.floor(y-cyT)%4===3)c='#5a5e70';
    const sh=px/rx;if(sh>.55)c=c==='#5a5e70'?c:'#7c8092';if(sh<-.6)c=c==='#5a5e70'?c:'#aeb1c0';g.fillStyle=c;g.fillRect(x,y,1,1);}
  const R=15;
  wmWater(g,f,(x,y)=>{const d=Math.hypot((x-cx)/(rx*.68),(y-cyT)/(ry*.62));return d<=1?(.6+.2*d):0;});
  // inner wall shading on the far side of the rim
  for(let x=-9;x<=9;x++){g.fillStyle='rgba(20,24,40,.55)';g.fillRect(cx+x,cyT-Math.round(ry*.62*Math.sqrt(Math.max(0,1-(x/(rx*.68))**2))),1,1);}
});}
function wmOver1(ox,oy,t){const R=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(ox+x*2),Math.round(oy+y*2),w*2,h*2);};
  // rope + bucket swinging a hair
  const sw=Math.round(Math.sin(t*1.4)*.6);
  R(31,17,1,10,'#d8c8a0');R(33,17,1,10,'#bfae86');
  R(29+sw,27,6,1,'#c8cad4');R(28+sw,28,8,5,'#8a5a30');R(28+sw,28,8,1,'#a8743e');R(28+sw,30,8,1,'#5a5e70');R(28+sw,32,8,1,'#5a3a1c');R(36+sw,28,1,5,'#4a2c14');R(28+sw,28,1,5,'#a8743e');
  R(30+sw,26,4,1,'#4a4e60');
  // posts
  for(const px of [17,45]){R(px,2,3,34,'#7a4a28');R(px,2,1,34,'#9a6a3c');R(px+2,2,1,34,'#5a341a');R(px-1,34,5,2,'#5a5e70');}
  // crossbeam + crank
  R(17,16,31,3,'#7a4a28');R(17,16,31,1,'#9a6a3c');R(17,18,31,1,'#5a341a');R(29,15,6,5,'#5a341a');R(46,17,6,1,'#4a2c14');R(52,15,1,5,'#c8a060');
  // roof: gable shingles
  for(let yy=-4;yy<=11;yy++){const hw=Math.round(5+(yy+4)*1.5+ (yy>8?2:0)),row=Math.floor((yy+4)/2)&1;
    R(32-hw,yy,hw*2,1,row?'#a8452e':'#8e3724');
    if(yy%2===0)for(let k=-hw;k<hw;k+=4)R(32+k+((yy/2|0)&1)*2,yy,1,1,'#6e281a');
    R(32-hw,yy,1,1,'#c8604a');R(31+hw,yy,1,1,'#5a2218');}
  R(14,11,37,2,'#5a2218');R(15,13,35,1,'#3c150e');
  R(29,-6,6,3,'#7a4a28');R(30,-7,4,2,'#9a6a3c');   // ridge cap + finial
}
/* option 2: tiered stone fountain (ground part: wide round basin + the lower pedestal) */
function wmBlock2(f){return makeSprite(64,64,g=>{wmGrass(g);wmShadow(g,35,50,28,6,.2);
  const cx=32,cy=36,rx=29,ry=22;
  for(let y=0;y<64;y++)for(let x=0;x<64;x++){const dx=x+.5-cx,dy=y+.5-cy,d=Math.hypot(dx/rx,dy/ry);if(d>1.05)continue;
    if(d>1){g.fillStyle='#3a3d4c';g.fillRect(x,y,1,1);continue;}
    if(d>.86){const ang=Math.atan2(dy,dx),seg=Math.floor((ang+Math.PI)/(Math.PI*2)*30),e=((ang+Math.PI)/(Math.PI*2)*30)%1;let c=seg%3===0?'#a4a7b6':(seg%2?'#8e91a0':'#9a9dac');if(e<.08||e>.92)c='#5a5e70';if(d>.96)c='#6a6e80';else if(d<.9)c=dy<0?'#c4c7d4':'#7a7d8e';g.fillStyle=c;g.fillRect(x,y,1,1);}}
  wmWater(g,f,(x,y)=>{const d=Math.hypot((x-cx)/rx,(y-cy)/ry);return d<=.86?(d>.72?.7:.9):0;});
  // pedestal base (a low stone drum in the middle)
  for(let y=0;y<64;y++)for(let x=0;x<64;x++){const dx=x+.5-cx,dy=y+.5-(cy+2),d=Math.hypot(dx/11,dy/7);if(d>1)continue;g.fillStyle=d>.78?'#6a6e80':(WM_NOISE(x>>1,y>>1,9)<.4?'#b4b7c6':'#a4a7b6');g.fillRect(x,y,1,1);}
  ell(g,32,36,8,4,'#7ec8f0');ell(g,32,36,6,3,'#a8e0ff');
  // ripples where the water falls
  const rr=4+((f&3)*2);for(let a=0;a<28;a++){const an=a/28*6.283;g.fillStyle='rgba(235,248,255,.65)';g.fillRect(Math.round(32+Math.cos(an)*(rr+8)),Math.round(36+Math.sin(an)*(rr+8)*.7),1,1);}
});}
function wmOver2(ox,oy,t){const R=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(ox+x*2),Math.round(oy+y*2),w*2,h*2);};
  const E=(cx,cy,rx,ry,c)=>{ctx.fillStyle=c;for(let y=-ry;y<=ry;y++)for(let x=-rx;x<=rx;x++)if(x*x/(rx*rx+.3)+y*y/(ry*ry+.3)<=1)ctx.fillRect(Math.round(ox+(cx+x)*2),Math.round(oy+(cy+y)*2),2,2);};
  // column + two stacked bowls
  R(29,14,6,22,'#9a9dac');R(29,14,2,22,'#c4c7d4');R(33,14,2,22,'#6a6e80');R(28,34,8,3,'#8e91a0');
  E(32,26,12,5,'#6a6e80');E(32,25,11,4,'#b4b7c6');E(32,25,9,3,'#7ec8f0');E(32,25,7,2,'#a8e0ff');   // middle bowl
  R(30,16,4,10,'#9a9dac');R(30,16,1,10,'#c4c7d4');
  E(32,13,8,3,'#6a6e80');E(32,12,7,3,'#b4b7c6');E(32,12,5,2,'#7ec8f0');                              // top bowl
  E(32,7,3,3,'#a4a7b6');E(31,6,1,1,'#e4e6f0');R(31,3,2,3,'#8e91a0');                                  // finial
  // jets: a fountain of droplets from the top, spilling over both bowls
  const col=['#dff4ff','#a8e0ff','#7ec8f0'];
  for(let i=0;i<14;i++){const ph=(t*1.3+i/14)%1;                 // central jet
    const hgt=Math.sin(ph*Math.PI)*8;R(31+(i%3)-1+((i*7)%3===0?1:0),Math.round(5-hgt+ph*2),1,1,col[i%3]);}
  for(let i=0;i<28;i++){const side=i%2?1:-1,ph=(t*1.1+i/28)%1,reach=ph*(i%4<2?8:15),fall=(ph*ph)*(i%4<2?10:16),y0=i%4<2?12:25;
    R(Math.round(32+side*(3+reach)),Math.round(y0-Math.sin(ph*Math.PI)*4+fall*.8),1,1,col[(i>>1)%3]);}
}
/* option 3: small square stone well + two lantern posts on a cobbled pad (ground part) */
function wmBlock3(f){return makeSprite(64,64,g=>{wmGrass(g);
  // cobbled pad
  for(let y=14;y<58;y++)for(let x=8;x<56;x++){const dx=Math.abs(x-32)/24,dy=Math.abs(y-36)/22;if(Math.max(dx,dy)>1-.05*WM_NOISE(x,y,2)*2)continue;
    const cx=Math.floor(x/4),cy=Math.floor(y/3.5),off=(cy&1)*2,cc=Math.floor((x+off)/4),r=WM_NOISE(cc,cy,4);let c=r<.3?'#b8a47c':r<.7?'#a8946c':'#9a865e';if((x+off)%4===0||Math.floor(y)%4===0&&false)c='#7a6a48';if(y%4===3)c='#7a6a48';g.fillStyle=c;g.fillRect(x,y,1,1);}
  wmShadow(g,35,51,16,4,.26);
  // the well: a squat square block seen from above-front
  const x0=19,x1=45,yT0=25,yT1=41,yF1=51;
  for(let y=yT0;y<yF1;y++)for(let x=x0;x<x1;x++){
    if(y<yT1){const edge=x<x0+3||x>=x1-3||y<yT0+3||y>=yT1-3;g.fillStyle=edge?(WM_NOISE(x>>1,y>>1,6)<.5?'#c4c7d4':'#b4b7c6'):'#2a2e40';g.fillRect(x,y,1,1);}
    else{const row=Math.floor((y-yT1)/3.3),off=(row&1)*3,col=Math.floor((x+off)/6);let c=wmStone(col,row,8);if((x+off)%6===0||(y-yT1)%3===2)c='#5a5e70';if(x>=x1-3)c='#6a6e80';g.fillStyle=c;g.fillRect(x,y,1,1);}}
  wmWater(g,f,(x,y)=>(x>=x0+3&&x<x1-3&&y>=yT0+3&&y<yT1-3)?(.55+(y-yT0)/60):0);
  rect(g,x0,yT0,x1-x0,1,'#e0e2ec');rect(g,x0,yF1-1,x1-x0,1,'#3c4050');rect(g,x0-1,yT0,1,yF1-yT0,'#3a3d4c');rect(g,x1,yT0,1,yF1-yT0,'#3a3d4c');
  rect(g,x0+3,yT0+3,x1-x0-6,1,'#1a1c2a');   // inner shadow on the far wall
});}
function wmOver3(ox,oy,t){const R=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(ox+x*2),Math.round(oy+y*2),w*2,h*2);};
  const fl=.85+.15*Math.sin(t*9)+.05*Math.sin(t*23);
  for(const [px,face] of [[10,1],[54,-1]]){ctx.save();ctx.translate(0,16);
    // glow pool on the ground + in the air
    const gx=Math.round(ox+px*2),gy=Math.round(oy+(-6)*2+0);ctx.save();ctx.globalCompositeOperation='lighter';
    const gr=ctx.createRadialGradient(gx+1,gy+10,2,gx+1,gy+10,64);gr.addColorStop(0,'rgba(255,190,90,'+(.38*fl)+')');gr.addColorStop(1,'rgba(255,150,60,0)');ctx.fillStyle=gr;ctx.fillRect(gx-70,gy-60,142,150);
    const g2=ctx.createRadialGradient(gx+1,oy+(50)*2,2,gx+1,oy+50*2,50);g2.addColorStop(0,'rgba(255,200,110,'+(.22*fl)+')');g2.addColorStop(1,'rgba(255,150,60,0)');ctx.fillStyle=g2;ctx.fillRect(gx-60,oy+30*2,122,60);ctx.restore();
    // iron post with a curled arm
    R(px,-8,2,60,'#3a3d4c');R(px,-8,1,60,'#5a5e70');R(px-2,50,6,3,'#4a4e60');R(px-1,47,4,3,'#3a3d4c');
    R(px+(face>0?2:-5),-8,5,1,'#3a3d4c');R(px+(face>0?6:-5),-8,1,3,'#3a3d4c');
    const lx=px+(face>0?3:-6);
    // the lantern
    R(lx,-4,4,1,'#2a2d3a');R(lx-1,-3,6,1,'#4a4e60');R(lx,-2,4,6,'rgba(255,208,110,'+(.9*fl)+')');R(lx+1,-1,2,4,'#fff4c0');R(lx-1,-2,1,6,'#3a3d4c');R(lx+4,-2,1,6,'#3a3d4c');R(lx-1,4,6,1,'#3a3d4c');R(lx,-5,4,1,'#2a2d3a');R(lx+1,-6,2,1,'#2a2d3a');ctx.restore();
  }
  // bucket on the rim + a short rope, and a wooden roller beam above the well
  R(20,19,2,14,'#7a4a28');R(42,19,2,14,'#7a4a28');R(20,19,1,14,'#9a6a3c');R(42,19,1,14,'#9a6a3c');R(19,18,26,2,'#8a5a30');R(19,18,26,1,'#a8743e');R(30,16,4,5,'#5a341a');
  R(31,20,1,5,'#d8c8a0');R(29,25,5,4,'#8a5a30');R(29,25,5,1,'#a8743e');R(29,27,5,1,'#5a5e70');
}
/* option 4: natural spring pond: irregular pool, dirt/pebble bank, stepping stones, lily pads (ground part) */
function wmBlock4(f){return makeSprite(64,64,g=>{wmGrass(g);
  const cx=32,cy=35,rad=(a)=>21+3.2*Math.sin(a*2+1.1)+2.4*Math.sin(a*3+.3)+1.4*Math.sin(a*5+2);
  const dist=(x,y)=>{const dx=x-cx,dy=(y-cy)/.8,a=Math.atan2(dy,dx),r=Math.hypot(dx,dy);return [r,rad(a)];};
  // bank: dirt + pebbles in an irregular ring (like the path edges)
  for(let y=0;y<64;y++)for(let x=0;x<64;x++){const [r,R]=dist(x+.5,y+.5),q=R+4.4+(WM_NOISE(x,y,40)-.5)*1.6-r;if(q<=0||r<R)continue;
    const n=WM_NOISE(x,y,41);g.fillStyle=q<1.2?(n<.5?'#6f6a3c':'#98784a'):q<2.4?(n<.8?'#98784a':'#7c5f3b'):(n<.85?'#7c5f3b':'#5b4430');g.fillRect(x,y,1,1);
    if(q>1.4&&n>.93){g.fillStyle=n>.97?'#d2cdbd':'#b9b5a6';g.fillRect(x,y,1,1);}}
  wmWater(g,f,(x,y)=>{const [r,R]=dist(x,y);if(r>R)return 0;const k=R-r;return k<1.6?1.18:k<3.6?.8:k<6?.88:.7;});
  // shallow rim: a turquoise lip right at the bank
  for(let y=0;y<64;y++)for(let x=0;x<64;x++){const [r,R]=dist(x+.5,y+.5);if(r<=R&&r>R-1.4){g.fillStyle='rgba(170,240,225,.45)';g.fillRect(x,y,1,1);}}
  // stepping stones across the pool
  [[17,41,4,2],[23,38,4,3],[30,36,3,2],[37,33,4,3],[44,31,3,2]].forEach(([x,y,rx,ry])=>{wmShadow(g,x+1,y+2,rx+1,ry,.3);ell(g,x,y,rx,ry,'#6a675d');ell(g,x,y-1,rx,ry,'#9a978a');ell(g,x-1,y-1,Math.max(1,rx-2),Math.max(1,ry-1),'#bdb9aa');});
  // lily pads + lotus + little white flowers
  [[26,28,3],[40,42,3],[33,45,2],[47,38,2]].forEach(([px,py,r],k)=>{ell(g,px,py,r+1,r,'#2c8a3c');ell(g,px,py,r,r-1,'#4cb04c');rect(g,px,py,r+1,1,'#2f72c8');if(k%2===0){rect(g,px-1,py-2,3,2,'#ffb0d0');rect(g,px,py-2,1,1,'#ffe98a');}else rect(g,px,py-1,2,1,'#ffffff');});
  // ripple from the spring (NE)
  const rr=2+(f&3)*2;for(let a=0;a<24;a++){const an=a/24*6.283;g.fillStyle='rgba(235,248,255,.6)';g.fillRect(Math.round(45+Math.cos(an)*rr),Math.round(25+Math.sin(an)*rr*.7),1,1);}
});}
function wmOver4(ox,oy,t){const R=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(ox+x*2),Math.round(oy+y*2),w*2,h*2);};
  // mossy rocks where the spring bubbles out (NE bank) with a thin trickle
  const rk=(x,y,w,h)=>{R(x,y,w,h,'#6a675d');R(x,y,w,h-1,'#8f8c80');R(x+1,y,w-3,1,'#bdb9aa');R(x,y,w,1,'#6f9a52');R(x+w-2,y+1,2,1,'#5a8444');};
  rk(46,17,8,5);rk(50,13,7,5);rk(42,19,5,3);
  R(47,22,1,3,'#7ec8f0');R(47,22,1,1,'#dff4ff');R(52,18,1,5,'#7ec8f0');R(52+((t*3|0)&1),21,1,1,'#dff4ff');
  // reeds on the west and south banks: green blades with cattail heads, swaying
  const reed=(x,y,h,k)=>{const sw=Math.round(Math.sin(t*1.6+k)*.8);for(let i=0;i<h;i++){R(x+(i>h*.6?sw:0),y-i,1,1,i%3?'#4f8a3a':'#6aa84a');}R(x+sw-0,y-h-3,2,3,'#7a4a28');R(x+sw,y-h-3,1,1,'#a8743e');};
  [[13,44,10,0],[15,46,8,1],[11,41,9,2],[17,48,9,3],[46,50,9,4],[50,49,10,5],[52,47,8,6],[24,52,7,7]].forEach(([x,y,h,k])=>reed(x,y,h,k));
  // a few flowers in the grass
  for(const [x,y,c] of [[8,38,'#ffd24d'],[10,32,'#ff8ab8'],[55,30,'#c890ff'],[54,44,'#ffffff'],[7,48,'#ffffff']])R(x,y,1,1,c);
}
function wellBlock(n,f){return n===1?wmBlock1(f):n===2?wmBlock2(f):n===3?wmBlock3(f):wmBlock4(f);}
function drawWellOverlay(){const P0=VILLAGE_POND,ox=P0.x0*TS-Math.round(cam.x),oy=P0.y0*TS-Math.round(cam.y),t=gtime;
  if(WELLOPT===1)wmOver1(ox,oy,t);else if(WELLOPT===2)wmOver2(ox,oy,t);else if(WELLOPT===3)wmOver3(ox,oy,t);else wmOver4(ox,oy,t);}
