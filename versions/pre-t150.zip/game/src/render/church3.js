/* =====================================================================
   CHURCH, third pass (t138u, closer to Seth's reference): a gabled cream-stone belfry with the bell in an arched opening and a gold
   cross on top, sitting on a deep navy slate roof with a cream eave trim; the back wall gets pilasters between three ARCHED
   stained-glass windows (gold cross in each, the centre one tallest); the altar stands on a raised stone dais with a white,
   gold-trimmed cloth, a gold cross and two candles. Softer shading on the stone throughout.
   ===================================================================== */
(function church3(){
  const O='#14182c',ST='#e8dcbc',STL='#f8f0dc',STD='#bcae8a',STD2='#9a8c6c',SL='#2e3a62',SLL='#4e5e8e',SLD='#1c2442',GO='#f0c840',GOL='#fff0a0',GOD='#a87a18';
  const r=(g,x,y,w,h,c)=>rect(g,x,y,w,h,c);
  const glass=(g,x,y,w,h,seed)=>{const C=['#3a6ae0','#e24a4a','#3ac06a','#f0c53a','#9a4ae2'];for(let yy=0;yy<h;yy+=3)for(let xx=0;xx<w;xx+=3)r(g,x+xx,y+yy,Math.min(3,w-xx),Math.min(3,h-yy),C[(xx/3+yy/3*2+seed)%5|0]);
    for(let yy=0;yy<h;yy+=3)r(g,x,y+yy,w,1,'#2a2438');};
  // ---- stone back wall with a pilaster ----
  TSPR[T.CHB]=[0,1].map(v=>makeSprite(16,16,g=>{r(g,0,0,16,16,ST);for(let y=0;y<16;y+=4){r(g,0,y+3,16,1,STD);const off=(y/4+v)%2?0:5;for(let x=off;x<16;x+=10)r(g,x,y,1,3,STD);}
    r(g,0,0,16,1,STL);r(g,5,0,6,16,STL);r(g,5,0,1,16,STD);r(g,10,0,1,16,STD2);r(g,6,0,4,2,'#fffaf0');r(g,4,2,8,1,STD);r(g,4,14,8,2,STD);r(g,4,14,8,1,STL);}));
  // ---- arched stained-glass window ----
  TSPR[T.CHW]=[0,1,2].map(v=>makeSprite(16,16,g=>{r(g,0,0,16,16,ST);r(g,0,0,16,1,STL);
    r(g,3,2,10,13,STD2);r(g,4,1,8,1,STD2);r(g,4,3,8,11,'#2a2438');r(g,5,2,6,1,'#2a2438');glass(g,5,4,6,9,v);r(g,5,3,6,1,'#5a8af0');
    r(g,7,4,2,9,GO);r(g,5,6,6,2,GO);r(g,7,4,1,9,GOL);r(g,3,14,10,1,STL);r(g,2,15,12,1,STD);}));
  // ---- slate roof: deep navy, staggered slates, a cream eave trim at the bottom row ----
  TSPR[T.CHS]=[0,1].map(v=>makeSprite(16,16,g=>{r(g,0,0,16,16,SL);for(let y=0;y<16;y+=4){r(g,0,y+3,16,1,SLD);const off=((y/4)+v)%2?0:4;for(let x=off;x<16;x+=8)r(g,x,y,1,3,SLD);r(g,0,y,16,1,SLL);}
    r(g,0,13,16,1,SLD);r(g,0,14,16,2,ST);r(g,0,14,16,1,STL);}));
  TSPR[T.CHR]=[0].map(()=>makeSprite(16,16,g=>{grassBase(9,false)(g);r(g,0,6,16,10,SL);for(let y=6;y<16;y+=4){r(g,0,y+3,16,1,SLD);r(g,0,y,16,1,SLL);}r(g,0,5,16,1,'#3a3a50');r(g,0,6,16,1,SLL);}));
  // ---- belfry: gable, arched opening with the bell, cornice, cross ----
  SP.bellTower=autoOutline(makeSprite(26,46,g=>{
    r(g,12,0,2,10,GO);r(g,9,3,8,2,GO);r(g,12,0,1,10,GOL);r(g,9,3,8,1,GOL);                                   // cross
    for(let i=0;i<9;i++){const w=4+i*2.4|0;r(g,13-w/2|0,10+i,w,1,i===8?STD:ST);r(g,13-w/2|0,10+i,1,1,STL);r(g,13+w/2-1|0,10+i,1,1,STD);}   // gable
    for(let i=0;i<9;i++){const w=6+i*2.4|0;r(g,13-w/2-1|0,9+i,1,1,SLD);r(g,13+w/2|0,9+i,1,1,SLD);}           // slate verges
    r(g,2,19,22,2,STD2);r(g,2,19,22,1,STL);                                                                    // cornice
    r(g,4,21,18,25,ST);r(g,4,21,2,25,STL);r(g,20,21,2,25,STD);for(let y=25;y<46;y+=4){r(g,4,y,18,1,STD);const o=(y/4)%2?6:11;for(let x=o;x<21;x+=9)r(g,x,y-3,1,3,STD);}
    r(g,8,24,10,12,'#22202e');r(g,9,23,8,1,'#22202e');r(g,10,22,6,1,'#22202e');r(g,7,23,1,13,STD2);r(g,18,23,1,13,STD2);   // arched opening
    r(g,12,24,2,2,'#5a4a2a');ell(g,13,29,4,3,'#d9a83a');r(g,9,30,8,3,'#d9a83a');r(g,10,27,2,3,'#ffe48a');r(g,9,32,8,1,GOD);r(g,12,33,2,2,GOD);  // bell
    r(g,6,36,14,1,STD2);r(g,6,37,14,1,STL);                                                                     // sill
  }),O);
  // ---- big centre window: tall arch with a gold cross ----
  SP.chWinBig=autoOutline(makeSprite(18,26,g=>{r(g,1,4,16,22,STD2);ell(g,9,5,8,5,STD2);r(g,3,5,12,20,'#2a2438');ell(g,9,6,6,4,'#2a2438');
    glass(g,4,6,10,18,2);ell(g,9,7,5,3,'#4a7ae2');r(g,8,5,2,19,GO);r(g,4,10,10,2,GO);r(g,8,5,1,19,GOL);r(g,0,25,18,1,STD);}),O);
  // ---- altar on a dais ----
  SP.chDais=makeSprite(48,20,g=>{r(g,0,4,48,16,STD);r(g,0,4,48,2,STL);r(g,2,6,44,10,ST);r(g,0,16,48,4,STD2);r(g,0,16,48,1,STL);for(let x=4;x<48;x+=8)r(g,x,7,1,8,STD);});
  SP.chAltar=autoOutline(makeSprite(30,18,g=>{r(g,1,6,28,12,'#f6f2e8');r(g,1,6,28,2,'#ffffff');r(g,1,15,28,3,'#d8d0c0');r(g,1,13,28,1,GO);r(g,1,6,1,12,'#d8d0c0');
    r(g,13,8,4,8,GO);r(g,11,10,8,2,GO);r(g,13,8,1,8,GOL);r(g,10,2,10,4,'#8e1f2a');r(g,10,2,10,1,GO);   // gold cross on the cloth + a red runner
    r(g,3,0,3,6,'#fffdf0');r(g,24,0,3,6,'#fffdf0');}),O);
})();
drawChapelCross=function(){
  const x=(CHAPEL.door+.5)*TS-cam.x,y=CHAPEL.y0*TS-cam.y+TS*1.25;
  draw(SP.bellTower,Math.round(x-26),Math.round(y-90),2);
};
// the dais + altar are drawn by drawChurch2's overlay hook below
const _drawChurch2Base=drawChurch2;
drawChurch2=function(){
  const C=CHAPEL,cx=Math.round(cam.x),cy=Math.round(cam.y),ax=C.door*TS-cx,ay=(C.y0+3)*TS-cy;
  if(ax>-120&&ax<VW+120&&ay>-120&&ay<VH+120){draw(SP.chDais,ax-TS-8+TS/2-16+8,ay+2,2);}
  _drawChurch2Base();
  if(ax>-120&&ax<VW+120&&ay>-120&&ay<VH+120){draw(SP.chAltar,ax+TS/2-30,ay-4,2);
    for(const dx of [-22,22]){ctx.fillStyle=`rgba(255,200,90,${.2+.08*Math.sin(gtime*9+dx)})`;ctx.beginPath();ctx.arc(ax+TS/2+dx+1,ay-6,8,0,6.283);ctx.fill();ctx.fillStyle='#ffb84a';ctx.fillRect(ax+TS/2+dx,ay-8+Math.round(Math.sin(gtime*12+dx)),2,3);}}
};
