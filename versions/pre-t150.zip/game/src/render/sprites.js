
/* =====================================================================
   SPRITES
   ===================================================================== */
const SP={};
function person(o){
  const O='#14182c';
  const {body,bodyL,bodyD,skin='#f2c9a0',boots='#5a3b1e',belt='#c9a227',dir='d',f=0,helm=false,plume='#e04646',hair='#5b3a1e',hat=null,gun=false,apron=null,beard=null}=o;
  return makeSprite(16,16,g=>{
    const l1=f===1?1:0,l2=f===2?1:0;
    if(dir==='d'||dir==='u'){
      rect(g,5,12,2,2,bodyD);rect(g,9,12,2,2,bodyD);
      rect(g,5,14-l1,2,2,boots);rect(g,9,14-l2,2,2,boots);
      rect(g,2,7+l2,2,4,bodyD);rect(g,12,7+l1,2,4,bodyD);
      rect(g,2,10+l2,2,1,skin);rect(g,12,10+l1,2,1,skin);
      rect(g,4,6,8,6,O);rect(g,5,7,6,4,dir==='u'?bodyD:body);
      if(dir==='d'){rect(g,5,7,6,1,bodyL);rect(g,7,8,2,2,bodyL);if(apron)rect(g,5,9,6,3,apron);rect(g,5,10,6,1,belt);}
      else{rect(g,6,8,4,3,bodyL);rect(g,5,10,6,1,belt);}
      if(helm){rect(g,4,0,8,7,O);rect(g,5,1,6,2,body);rect(g,5,1,6,1,bodyL);rect(g,6,0,4,1,plume);rect(g,7,0,2,1,plume);
        if(dir==='d'){rect(g,5,3,6,3,skin);rect(g,6,4,1,1,O);rect(g,9,4,1,1,O);rect(g,5,3,6,1,bodyD);}
        else rect(g,5,3,6,3,body);}
      else{rect(g,4,1,8,6,O);rect(g,5,1,6,2,hair);rect(g,4,2,1,3,hair);rect(g,11,2,1,3,hair);
        if(dir==='d'){rect(g,5,3,6,3,skin);rect(g,6,4,1,1,O);rect(g,9,4,1,1,O);if(beard)rect(g,5,5,6,2,beard);}
        else rect(g,5,3,6,3,hair);
        if(hat){rect(g,3,1,10,2,hat);rect(g,5,0,6,2,hat);}}
    } else { // right
      rect(g,6,12,2,2,bodyD);rect(g,8,12,2,2,bodyD);
      const a=f===1?-1:f===2?1:0;
      rect(g,6+a,14-(f===1?1:0),2,2,boots);rect(g,8-a,14-(f===2?1:0),2,2,boots);
      rect(g,5,6,6,6,O);rect(g,6,7,4,4,body);rect(g,6,7,4,1,bodyL);rect(g,6,10,4,1,belt);if(apron)rect(g,8,9,2,3,apron);
      rect(g,4,7,2,4,bodyD);
      if(helm){rect(g,4,0,8,7,O);rect(g,5,1,6,2,body);rect(g,5,1,6,1,bodyL);rect(g,3,1,3,2,plume);rect(g,2,2,2,2,plume);rect(g,8,3,3,3,skin);rect(g,9,4,1,1,O);rect(g,5,3,3,3,body);rect(g,10,3,1,1,bodyD);}
      else{rect(g,4,1,8,6,O);rect(g,5,1,6,2,hair);rect(g,4,2,3,4,hair);rect(g,8,3,3,3,skin);rect(g,9,4,1,1,O);if(beard)rect(g,8,5,3,2,beard);if(hat){rect(g,3,1,10,2,hat);rect(g,5,0,6,2,hat);}}
      if(gun){rect(g,9,7,3,3,O);rect(g,10,8,5,2,'#4b5870');rect(g,12,7,3,4,'#5d6c8a');rect(g,12,8,3,2,'#8ea0c4');rect(g,15,8,1,2,'#7df9ff');}
      else{rect(g,9,8,2,3,bodyD);rect(g,9,10,2,1,skin);}
    }
    personDetail(g,o,dir,f);
  });
}
/* richer NPC detail (light from the top-left, like the fountain / terrain): hair + cloth highlights, right-side shade, collar, cuffs,
   cheeks, boot shine; then one consistent #14182c outline around the whole silhouette */
const npcShade=(h,k)=>{const n=parseInt(h.slice(1),16);let r=n>>16,g=(n>>8)&255,b=n&255;const f=v=>Math.max(0,Math.min(255,Math.round(k>0?v+(255-v)*k:v*(1+k))));return '#'+((1<<24)|(f(r)<<16)|(f(g)<<8)|f(b)).toString(16).slice(1);};
function personDetail(g,o,dir,f){
  const {body,bodyL,bodyD,skin='#f2c9a0',boots='#5a3b1e',helm=false,hair='#5b3a1e',hat=null,beard=null,apron=null}=o,l1=f===1?1:0,l2=f===2?1:0;
  const skD=npcShade(skin,-.18),bdDD=npcShade(bodyD,-.25);
  if(dir==='d'){
    rect(g,10,7,1,3,bodyD);rect(g,5,8,1,2,bodyL);                    // cloth: lit left, shaded right
    if(!apron){rect(g,7,7,2,1,npcShade(bodyL,.35));rect(g,8,9,1,1,bdDD);}   // collar + a button
    rect(g,2,7+l2,1,2,bodyL);rect(g,12,7+l1,1,2,bodyL);rect(g,13,9+l1,1,1,bdDD);   // sleeves: highlight + cuff shade
    rect(g,5,14-l1,1,1,npcShade(boots,.35));rect(g,9,14-l2,1,1,npcShade(boots,.35));
    if(helm){rect(g,5,1,2,1,npcShade(bodyL,.5));rect(g,10,2,1,1,bodyD);}
    else{rect(g,5,1,3,1,npcShade(hair,.35));rect(g,10,3,1,2,skD);if(!beard){rect(g,6,5,1,1,'#e8a08a');rect(g,9,5,1,1,'#e8a08a');}else rect(g,6,6,4,1,npcShade(beard,-.15));
      if(hat)rect(g,5,0,3,1,npcShade(hat,.35));}
  }else if(dir==='u'){rect(g,10,7,1,4,bdDD);if(!helm)rect(g,5,1,3,1,npcShade(hair,.3));}
  else{rect(g,6,7,1,3,bodyL);rect(g,9,8,1,2,bodyD);if(!helm)rect(g,5,1,3,1,npcShade(hair,.35));rect(g,6,14,1,1,npcShade(boots,.35));}
  // outline: every empty pixel touching the figure becomes the shared outline colour
  const im=g.getImageData(0,0,16,16),d=im.data,A=(x,y)=>x>=0&&y>=0&&x<16&&y<16&&d[(y*16+x)*4+3]>0,add=[];
  for(let y=0;y<16;y++)for(let x=0;x<16;x++)if(!A(x,y)&&(A(x-1,y)||A(x+1,y)||A(x,y-1)||A(x,y+1)))add.push([x,y]);
  for(const [x,y] of add)rect(g,x,y,1,1,'#14182c');
}
/* ---- SUN PALADIN (the hero): ivory + gold plate, gold helm with a small cream plume, short cream cape with a gold sun on the back, round gold sun shield.
   16x16, same frames / anchor as every other person(). gun=true = combat pose (arcane gauntlet raised). ---- */
const PAL={O:'#14182c',cr:'#f6ecd2',crL:'#fffaf0',crD:'#cdbf9c',crDD:'#a89a76',au:'#e8b83a',auL:'#ffe27a',auD:'#a8741a',sk:'#f2c9a0',bt:'#6a4a2a',btD:'#44301a',plume:'#fff6d8'};
function paladinSun(g,x,y){const {au,auL}=PAL;rect(g,x-1,y,4,2,au);rect(g,x,y-1,2,4,au);rect(g,x,y,2,2,auL);}      // gold sun mark, 4x4 plus-shape with a bright core
function paladinShield(g,cx,cy){const {O,au,auL,auD}=PAL;ell(g,cx,cy,3,3,O);ell(g,cx,cy,2,2,auD);ell(g,cx,cy,1,1,au);rect(g,cx,cy,1,1,auL);rect(g,cx-1,cy-2,2,1,au);rect(g,cx-2,cy-1,1,1,au);}
function paladin(o){
  const {dir='d',f=0,gun=false}=o,{O,cr,crL,crD,crDD,au,auL,auD,sk,bt,btD,plume}=PAL;
  return makeSprite(16,16,g=>{
    const l1=f===1?1:0,l2=f===2?1:0;
    if(dir==='d'||dir==='u'){
      rect(g,5,12,2,2,crD);rect(g,9,12,2,2,crD);rect(g,5,12,2,1,crDD);rect(g,9,12,2,1,crDD);                       // greaves
      rect(g,5,14-l1,2,2,bt);rect(g,9,14-l2,2,2,bt);rect(g,5,15-l1,2,1,btD);rect(g,9,15-l2,2,1,btD);               // boots
      if(dir==='u')paladinShield(g,3,10);                                                                            // shield arm peeks out behind (character's left = screen left)
      rect(g,2,8+l2,2,3,crD);rect(g,2,10+l2,2,1,au);                                                                 // arms + gauntlets
      if(dir==='d'){rect(g,12,8+l1,2,3,crD);rect(g,12,10+l1,2,1,au);}
      rect(g,4,6,8,6,O);
      if(dir==='d'){
        rect(g,5,7,6,4,cr);rect(g,5,7,6,1,crL);rect(g,5,10,6,1,au);rect(g,5,11,6,1,crD);                            // breastplate, gold belt, tasset
        rect(g,7,8,2,2,au);rect(g,7,8,1,1,auL);rect(g,6,8,1,2,crD);rect(g,9,8,1,2,crD);                             // sun chest-mark
      } else {
        rect(g,5,7,6,5,cr);rect(g,5,7,6,1,crL);rect(g,5,11,6,1,crD);rect(g,4,12,1,1,crD);rect(g,11,12,1,1,crD);      // short cape
        paladinSun(g,7,8);rect(g,5,9,1,3,crD);rect(g,10,9,1,3,crD);
      }
      rect(g,2,6,3,2,au);rect(g,11,6,3,2,au);rect(g,2,6,3,1,auL);rect(g,11,6,3,1,auL);rect(g,2,7,1,1,auD);rect(g,13,7,1,1,auD);   // pauldrons
      rect(g,4,0,8,7,O);                                                                                              // helm
      rect(g,5,1,6,2,au);rect(g,5,1,6,1,auL);
      if(dir==='d'){rect(g,5,3,6,3,sk);rect(g,6,4,1,1,O);rect(g,9,4,1,1,O);rect(g,5,3,6,1,auD);rect(g,5,3,1,3,au);rect(g,10,3,1,3,au);rect(g,5,5,1,1,auD);rect(g,10,5,1,1,auD);}
      else{rect(g,5,3,6,3,au);rect(g,5,3,6,1,auL);rect(g,7,3,2,3,auD);rect(g,5,5,6,1,auD);}
      rect(g,7,0,2,2,plume);rect(g,6,1,4,1,plume);rect(g,7,0,1,1,'#fff');                                               // small crest / plume
      if(dir==='d')paladinShield(g,12,10);                                                                            // round sun shield on the left arm
    } else { // facing right
      const a=f===1?-1:f===2?1:0;
      rect(g,6,12,2,2,crD);rect(g,8,12,2,2,crD);
      rect(g,6+a,14-(f===1?1:0),2,2,bt);rect(g,8-a,14-(f===2?1:0),2,2,bt);rect(g,6+a,15-(f===1?1:0),2,1,btD);rect(g,8-a,15-(f===2?1:0),2,1,btD);
      paladinShield(g,3,10);                                                                                            // sun shield slung on the far arm, peeking out behind
      rect(g,5,6,6,6,O);rect(g,6,7,4,4,cr);rect(g,6,7,4,1,crL);rect(g,6,10,4,1,au);rect(g,6,11,4,1,crD);rect(g,7,8,2,2,au);rect(g,7,8,1,1,auL);
      rect(g,3,6,3,7,O);rect(g,4,7,2,5,cr);rect(g,4,7,1,5,crL);rect(g,4,11+(f===0?0:1),2,1,crD);rect(g,4,8,1,2,au);   // short cape hanging behind (gold sun edge)
      rect(g,4,6,3,2,au);rect(g,4,6,3,1,auL);rect(g,4,7,1,1,auD);                                                     // pauldron
      rect(g,4,0,8,7,O);rect(g,5,1,6,2,au);rect(g,5,1,6,1,auL);rect(g,8,3,3,3,sk);rect(g,9,4,1,1,O);rect(g,5,3,3,3,au);rect(g,5,3,3,1,auL);rect(g,10,3,1,3,auD);rect(g,8,3,3,1,auD);rect(g,5,5,3,1,auD);
      rect(g,3,1,3,2,plume);rect(g,2,2,2,2,plume);rect(g,2,2,1,1,crD);                                                  // plume sweeping back
      if(gun){rect(g,9,7,3,3,O);rect(g,10,8,5,2,'#4b5870');rect(g,12,7,3,4,'#5d6c8a');rect(g,12,8,3,2,'#8ea0c4');rect(g,15,8,1,2,'#7df9ff');rect(g,9,8,2,2,au);}   // arcane gauntlet
      else{rect(g,9,8,2,3,crD);rect(g,9,10,2,1,au);}
    }
  });
}
function buildSprites(){
  SP.hero={d:[],u:[],r:[],l:[]};
  for(const dir of ['d','u','r'])for(let f=0;f<3;f++)SP.hero[dir][f]=paladin({dir,f});
  SP.hero.l=SP.hero.r.map(flipH);
  SP.heroB=[0,1].map(f=>paladin({dir:'r',f:0,gun:true}));
  SP.heroBHurt=paladin({dir:'r',f:0,gun:true});
  SP.heroIcon=makeSprite(8,8,g=>{g.drawImage(SP.hero.d[0],4,0,8,8,0,0,8,8);});   // head crop for the HUD name plate
  // NPCs
  SP.elder=person({body:'#6b3fa0',bodyL:'#a67fdc',bodyD:'#472a70',hair:'#d8d8e0',beard:'#e8e8f0',dir:'d',belt:'#c9a227'});
  SP.smith=person({body:'#8a5a2e',bodyL:'#c08a52',bodyD:'#5a3a1c',hair:'#2a1a10',apron:'#444a58',dir:'d',belt:'#222'});
  SP.kid=person({body:'#3fa05a',bodyL:'#7be09a',bodyD:'#27703a',hair:'#e8c860',dir:'d',belt:'#7a5a2a'});
  SP.guard=person({body:'#a02828',bodyL:'#e06a6a',bodyD:'#701818',helm:true,plume:'#f0d040',dir:'d'});
  {const base=person({body:'#8fa6bd',bodyL:'#d4e4f4',bodyD:'#566c84',helm:true,plume:'#ffffff',belt:'#2a4a9a',boots:'#3a4658',dir:'d'});   // Town Guard: heavy steel plate, blue tabard, halberd
   SP.tguard=makeSprite(16,16,g=>{g.drawImage(base,0,0);rect(g,14,1,1,14,'#6a4a2a');rect(g,13,0,3,3,'#dfe9f2');rect(g,13,0,1,1,'#fff');rect(g,6,8,4,3,'#2a4a9a');rect(g,7,8,2,1,'#6a8ae8');rect(g,3,7,3,3,'#b8cde0');rect(g,10,7,3,3,'#b8cde0');});}
   SP.dummy=makeSprite(16,16,g=>{rect(g,4,14,8,2,'#5a3e22');rect(g,7,6,2,9,'#7a5530');rect(g,1,6,14,2,'#8a6540');rect(g,3,5,10,8,'#d9b97a');rect(g,3,5,10,1,'#f0d9a0');rect(g,3,12,10,1,'#b8955a');
     rect(g,5,0,6,5,'#e8cf94');rect(g,5,0,6,1,'#f6e6b8');rect(g,6,2,1,1,'#3a2a14');rect(g,9,2,1,1,'#3a2a14');rect(g,7,3,2,1,'#3a2a14');
     rect(g,5,6,6,5,'#c0392b');rect(g,6,7,4,3,'#f6ecd2');rect(g,7,8,2,1,'#c0392b');rect(g,0,5,2,3,'#d9b97a');rect(g,14,5,2,3,'#d9b97a');});
  // Slime
  SP.slime=fromMap([
    '................','................','................','................',
    '.....oooooo.....','....oabbbaao....','...oabbbaaaao...','..oabbaaaaaaco..',
    '..oaaaaaaaaaco..','.oaaeepaaeepaco.','.oaaeepaaeepaco.','.oaaaaaaaaaaaco.',
    '.oaaaammmmaaaco.','.occaaaaaaaaaco.','..occcccccccco..','...oooooooooo...'],
    {o:'#14301f',a:'#5fd35f',b:'#a6f5a0',c:'#2fa04a',e:'#fff',p:'#111',m:'#14301f'});
  // Skeleton knight
  SP.knight=fromMap([
    '......rrrr......','.....rrrrrr.....','....oiiiiiio....','....ohiiiiio....',
    '....oddddddo....','....odeddedo....','....owwwwwwo....','.....owswso.....',
    '..ooiiiiiiiioo..','.oddoihhiiiobo..','.odyoiiiiiiobbo.','.odyoiiddiiobbo.',
    '.oddoiiiiiiobo..','..oooiooooiobo..','....owo..owo....','...oooo..oooo...'],
    {o:'#1e1b2b',i:'#9aa3b8',d:'#4d5a7a',h:'#d6ddef',r:'#cf3b3b',w:'#ece6d4',s:'#b9b29c',e:'#ff3d3d',y:'#e0b841',b:'#d8dce8'});
  // Goblin archer
  SP.goblin=fromMap([
    '................','...o........o...','..ogo.oooo.ogo..','..oggoohhhhoggo.',
    '...ogohhhhhhogo.','....ohhhhhhho...','....ohgeggego...','....ohgggggo....',
    '.....ogtttgo.b..','....occccccobs..','...ogocCCcogobs.','...ogocccco.obs.',
    '....oocccoo.obs.','.....ogoogo..b..','.....oCo.oCo....','....ooCo.oCoo...'],
    {o:'#18241a',g:'#6dbb4a',h:'#3f7a3a',e:'#ffe14d',t:'#fff',c:'#8b5a2b',C:'#5e3b1b',b:'#a0713a',s:'#dcdcdc'});
  // Dragon (procedural, faces left)
  SP.dragon=autoOutline(makeSprite(36,32,g=>{
    g.translate(2,2);
    const red='#d44a36',dark='#a53226',belly='#f2d28c',wing='#8a2530',wingL='#b8404a';
    // tail
    ell(g,27,21,5,3,dark);ell(g,30,18,3,2,dark);tri(g,31,16,33,12,33,18,'#f2b43a');
    // wings
    tri(g,15,13,19,0,28,11,wing);tri(g,19,12,30,3,31,14,wingL);tri(g,15,13,19,0,21,9,wingL);
    line(g,16,12,19,1,dark);line(g,20,12,29,4,dark);
    // body
    ell(g,17,18,9,6,red);ell(g,15,21,6,3,belly);
    for(let i=0;i<5;i++)tri(g,11+i*3,12,12+i*3,9,13+i*3,12,'#f2b43a');
    // legs
    rect(g,10,22,3,5,dark);rect(g,20,22,3,5,dark);rect(g,9,26,5,1,'#efe5c6');rect(g,19,26,5,1,'#efe5c6');
    // neck & head
    ell(g,9,13,4,5,red);ell(g,6,9,5,4,red);ell(g,3,11,3,2,'#e8654d');
    rect(g,0,12,7,1,dark);rect(g,1,13,1,1,'#fff');rect(g,3,13,1,1,'#fff');rect(g,5,13,1,1,'#fff');
    rect(g,5,7,3,2,'#ffe14d');rect(g,6,8,1,1,'#000');
    tri(g,7,6,9,-1,10,6,'#efe5c6');tri(g,4,5,3,0,6,5,'#efe5c6');
    rect(g,1,10,1,1,'#7a1d14');rect(g,2,10,1,1,'#7a1d14');
  }),'#2a0f14');
  // chip icons
  SP.ic={};
  SP.ic.sword=makeSprite(16,16,g=>{line(g,3,12,11,4,'#dfe9ff',2);line(g,4,13,12,5,'#7fa6e8',1);rect(g,2,10,5,2,'#c9a227');line(g,4,9,7,12,'#c9a227',2);rect(g,1,13,3,3,'#6b4423');tri(g,11,3,14,1,13,6,'#fff');});
  SP.ic.fire=makeSprite(16,16,g=>{tri(g,8,0,3,8,12,8,'#ff5a1f');ell(g,8,10,5,5,'#ff7a2a');ell(g,8,11,3,3,'#ffd23f');tri(g,8,5,6,10,10,10,'#ffe99a');});
  SP.ic.shield=makeSprite(16,16,g=>{rect(g,3,2,10,7,'#2c8a5a');tri(g,3,8,13,8,8,15,'#2c8a5a');rect(g,4,3,8,5,'#7be0a5');tri(g,4,8,12,8,8,13,'#7be0a5');rect(g,7,3,2,9,'#fff');rect(g,4,6,8,1,'#fff');});
  SP.ic.heal=makeSprite(16,16,g=>{rect(g,6,1,4,14,'#2fbf5a');rect(g,1,6,14,4,'#2fbf5a');rect(g,7,2,2,12,'#b8ffcb');rect(g,2,7,12,2,'#b8ffcb');});
  SP.ic.frostbolt=makeSprite(16,16,g=>{tri(g,8,0,3,8,13,8,'#7fd8ff');tri(g,3,8,13,8,8,15,'#5ab8f0');tri(g,8,1,5,8,8,8,'#d9f6ff');tri(g,8,8,5,8,8,14,'#a8e8ff');rect(g,7,3,1,4,'#fff');rect(g,1,2,1,3,'#fff');rect(g,0,3,3,1,'#fff');rect(g,14,11,1,3,'#fff');rect(g,13,12,3,1,'#fff');});
  SP.ic.frostburst=makeSprite(16,16,g=>{tri(g,8,0,4,7,12,7,'#7fd8ff');tri(g,8,0,8,7,4,7,'#d9f6ff');rect(g,7,7,2,1,'#5ab8f0');tri(g,3,5,0,12,6,12,'#5ab8f0');tri(g,3,5,3,12,0,12,'#bff1ff');tri(g,13,5,10,12,16,12,'#5ab8f0');tri(g,13,5,13,12,16,12,'#bff1ff');rect(g,0,12,16,2,'#e8fbff');rect(g,2,14,12,1,'#7fd8ff');rect(g,8,2,1,3,'#fff');});
  SP.ic.crimsonbolt=makeSprite(16,16,g=>{tri(g,8,0,3,9,13,9,'#6a0f1e');ell(g,8,10,5,5,'#c0243a');ell(g,8,10,3,4,'#ff4a5e');rect(g,5,8,2,2,'#ffc0c8');rect(g,7,3,1,3,'#ff8a98');});
  SP.ic.crimsonburst=makeSprite(16,16,g=>{ell(g,8,5,4,4,'#6a0f1e');ell(g,8,5,3,3,'#c0243a');rect(g,7,3,2,1,'#ffc0c8');ell(g,4,11,4,4,'#6a0f1e');ell(g,4,11,3,3,'#e0364c');rect(g,3,9,1,1,'#ffc0c8');ell(g,12,11,4,4,'#6a0f1e');ell(g,12,11,3,3,'#e0364c');rect(g,11,9,1,1,'#ffc0c8');});
  SP.ic.chain=makeSprite(16,16,g=>{line(g,10,0,5,6,'#fff6a0',2);line(g,5,6,11,8,'#ffe14d',2);line(g,11,8,5,15,'#fff6a0',2);rect(g,1,2,1,1,'#fff');rect(g,13,11,2,1,'#fff');rect(g,13,3,1,3,'#ffe14d');rect(g,2,10,1,3,'#ffe14d');});
  SP.ic.quake=makeSprite(16,16,g=>{rect(g,0,10,16,6,'#7a5a36');rect(g,0,10,16,2,'#b98a52');line(g,3,10,7,15,'#2a1a0e',1);line(g,7,15,9,11,'#2a1a0e',1);line(g,9,11,13,15,'#2a1a0e',1);tri(g,3,9,6,2,9,9,'#8a8d9c');tri(g,8,9,11,4,14,9,'#b8bbc8');rect(g,5,4,1,2,'#fff');});
  SP.ic.meteor=makeSprite(16,16,g=>{tri(g,0,0,10,5,5,10,'#ff9a3d');tri(g,0,3,7,8,3,9,'#ffd23f');ell(g,10,10,5,5,'#5a3a2a');ell(g,10,10,4,4,'#8a5a3a');rect(g,9,8,3,2,'#ff7a2a');rect(g,12,12,2,2,'#2a1a14');rect(g,8,12,1,1,'#2a1a14');});
  SP.ic.poison=makeSprite(16,16,g=>{ell(g,5,8,4,3,'#6aa82e');ell(g,10,7,5,4,'#8fd03a');ell(g,8,10,6,3,'#7cbc34');rect(g,6,6,2,2,'#d8f59a');rect(g,11,9,1,1,'#d8f59a');rect(g,6,9,1,2,'#2a4a14');rect(g,9,9,1,2,'#2a4a14');rect(g,7,11,2,1,'#2a4a14');rect(g,3,2,2,2,'#b6f06a');rect(g,12,2,1,1,'#b6f06a');rect(g,8,13,1,2,'#8fd03a');});
  SP.ic.shadow=makeSprite(16,16,g=>{ell(g,11,5,3,3,'#8a6bd6');rect(g,9,8,5,6,'#5a3fa0');rect(g,10,9,1,1,'#fff');rect(g,12,9,1,1,'#fff');ell(g,6,7,2,2,'#4a3a7a');rect(g,4,9,4,4,'#3a2a66');ell(g,2,9,1,1,'#2a1a4a');rect(g,0,11,3,1,'#6a4fc0');rect(g,1,13,2,1,'#6a4fc0');});
  SP.ic.ward=makeSprite(16,16,g=>{ell(g,8,9,7,6,'#fff0a8');ell(g,8,9,5,4,'#ffd45a');rect(g,0,10,16,6,'#17142b');rect(g,7,4,2,9,'#fff');rect(g,4,7,8,2,'#fff');rect(g,1,9,1,1,'#fff');rect(g,14,9,1,1,'#fff');});
  SP.ic.reflect=makeSprite(16,16,g=>{ell(g,8,8,7,7,'#6aa8d8');ell(g,8,8,6,6,'#d8f0ff');tri(g,3,12,12,3,12,10,'#fff');rect(g,4,10,2,2,'#7fb8e8');line(g,5,11,11,5,'#4a88c8',1);rect(g,11,4,3,1,'#fff');rect(g,13,4,1,3,'#fff');});
  SP.ic.haste=makeSprite(16,16,g=>{rect(g,6,3,5,8,'#e8789e');rect(g,6,10,9,4,'#c05080');rect(g,7,4,2,5,'#ffd0e8');tri(g,6,6,0,4,2,8,'#fff');rect(g,0,9,5,1,'#ffd0e8');rect(g,1,12,4,1,'#ffd0e8');rect(g,12,11,2,1,'#fff');});
  SP.ic.wolf=makeSprite(16,16,g=>{tri(g,3,1,5,6,1,6,'#9fb6d8');tri(g,13,1,15,6,11,6,'#9fb6d8');rect(g,3,5,10,7,'#bcd0f5');tri(g,3,11,13,11,8,16,'#8aa0c8');rect(g,5,7,2,2,'#17142b');rect(g,9,7,2,2,'#17142b');rect(g,5,7,1,1,'#7df9ff');rect(g,9,7,1,1,'#7df9ff');rect(g,7,11,2,2,'#17142b');rect(g,6,13,1,2,'#fff');rect(g,9,13,1,2,'#fff');});
  SP.ic.decoy=makeSprite(16,16,g=>{rect(g,4,2,8,9,'#9aa0b0');rect(g,3,4,2,6,'#7a8090');rect(g,11,4,2,6,'#7a8090');rect(g,5,6,6,2,'#17142b');rect(g,7,1,2,2,'#c9a227');rect(g,4,11,8,4,'#b8a98f');rect(g,6,12,4,3,'#d8cfae');rect(g,0,0,1,1,'#fff');rect(g,14,13,2,1,'#fff');});
  SP.ic.curse=makeSprite(16,16,g=>{ell(g,8,7,5,5,'#d8c8f0');rect(g,4,10,8,4,'#d8c8f0');rect(g,5,6,2,3,'#3a1a5a');rect(g,9,6,2,3,'#3a1a5a');rect(g,7,9,2,1,'#3a1a5a');rect(g,6,13,1,2,'#17142b');rect(g,9,13,1,2,'#17142b');rect(g,0,0,2,2,'#a85fd0');rect(g,14,1,2,2,'#a85fd0');rect(g,1,13,2,2,'#a85fd0');rect(g,13,12,2,2,'#a85fd0');});
  SP.ic.drain=makeSprite(16,16,g=>{ell(g,8,8,7,7,'#6a0f2e');ell(g,8,8,5,5,'#d0306a');ell(g,8,8,3,3,'#ff7aa8');rect(g,7,7,2,2,'#fff');line(g,0,2,6,7,'#ff9ac0',1);line(g,15,14,10,9,'#ff9ac0',1);rect(g,13,1,2,2,'#ffd0e0');rect(g,1,13,2,2,'#ffd0e0');});
  SP.ic.timestop=makeSprite(16,16,g=>{ell(g,8,8,7,7,'#8a6a1a');ell(g,8,8,6,6,'#fff0b8');rect(g,7,3,2,6,'#3a2a0a');rect(g,8,8,4,2,'#3a2a0a');rect(g,7,2,2,1,'#ff8a1a');rect(g,7,13,2,1,'#3a2a0a');rect(g,2,7,1,2,'#3a2a0a');rect(g,13,7,1,2,'#3a2a0a');rect(g,0,0,3,1,'#ffd23f');rect(g,13,15,3,1,'#ffd23f');});
  SP.ic.dragonfire=makeSprite(16,16,g=>{tri(g,0,6,10,2,10,12,'#8a1a1a');tri(g,2,6,9,3,9,10,'#d83a1a');rect(g,3,6,2,2,'#ffe14d');rect(g,2,9,2,1,'#fff');tri(g,10,5,16,2,16,14,'#ff8a1f');tri(g,10,7,16,5,16,12,'#ffd23f');tri(g,10,8,15,7,15,11,'#fff6c0');tri(g,2,5,3,0,5,4,'#c9a227');});
  SP.ic.g_armor=makeSprite(16,16,g=>{rect(g,3,3,10,10,'#7a8090');rect(g,4,4,8,8,'#b4bccd');rect(g,1,3,3,5,'#8a92a4');rect(g,12,3,3,5,'#8a92a4');rect(g,6,2,4,2,'#17142b');rect(g,7,6,2,6,'#8a92a4');rect(g,4,12,8,2,'#5a6070');rect(g,5,5,2,2,'#fff');});
  SP.ic.g_ring=makeSprite(16,16,g=>{ell(g,8,9,5,5,'#c9a227');ell(g,8,9,3,3,'#00000000');g.clearRect(6,7,4,4);rect(g,6,1,4,4,'#7df9ff');rect(g,7,2,2,2,'#fff');rect(g,4,12,8,1,'#8a6d12');});
  SP.ic.lance=makeSprite(16,16,g=>{line(g,1,14,12,3,'#8a5a2e',2);tri(g,10,0,15,0,15,5,'#e8f0ff');tri(g,9,2,13,6,15,1,'#bcd0f5');rect(g,5,9,3,2,'#c9a227');});
}
buildSprites();
