/* =====================================================================
   TREE VARIETY (M18). Every tree is still ONE solid 16x16 tile (collision / pathing / line-of-sight unchanged), but the picture
   is chosen per tile from a species table by zone, region, nearby water and a smooth noise field (so forests form patches),
   then varied by size (3), tint (3) and mirror (2). Sprites are drawn lazily once and cached, so the per-frame cost is one
   drawImage per tile - same as before. All art is procedural and original.
   New tiles: PM palm + AC acacia (solid, Sundered Ruins), BU bush + ST stump (walkable ground clutter, every zone).
   ===================================================================== */
Object.assign(T,{BU:51,ST:52,PM:53,AC:54});
SOLID.add(T.PM);SOLID.add(T.AC);
Object.assign(TSPR.mini,{[T.BU]:'#3d8a3a',[T.ST]:'#8a5a2c',[T.PM]:'#3a8a3a',[T.AC]:'#8a9a3a'});
const TREE_IDS=new Set([T.T,T.PN,T.RE,T.PM,T.AC,T.BU,T.ST]);
const TREE_CACHE=new Map();
let BLOSSOM=new Uint8Array(64*224);   // 1 where the tile at (x,y) is a purple-blossom tree (set when drawn; used for the falling petals)
function shadeHex(c,f){const n=parseInt(c.slice(1),16);const q=v=>Math.max(0,Math.min(255,Math.round(v*f)));return '#'+((1<<24)|(q((n>>16)&255)<<16)|(q((n>>8)&255)<<8)|q(n&255)).toString(16).slice(1);}
const shadeAll=(a,f)=>f===1?a:a.map(c=>shadeHex(c,f));
const TRUNK=['#4a2c14','#6b4423'];
// ---- species drawers: (g, o) with o={sz:0..2, tn:0..2, dark:bool, r:rng} on top of the floor already painted ----
const TREE_ART={
  oak(g,o){const P=[['#1d6430','#2f8d3d','#5ab85a'],['#2a6a26','#4f9a2c','#8bd04a'],['#16584a','#238a6a','#4cc29a']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.72:1);
    const rr=[5,6,7][o.sz],ry=[4,5,6][o.sz],cy=[10,8,7][o.sz],tw=o.sz?4:2;
    rect(g,8-tw/2,cy+2,tw,16-cy-2,TRUNK[0]);rect(g,8-tw/2+1,cy+2,Math.max(1,tw-2),16-cy-2,TRUNK[1]);
    ell(g,8,cy,rr,ry,c1);ell(g,8-(rr>>1),cy-1,rr-3,ry-2,c2);ell(g,8+(rr>>1),cy-1,rr-3,ry-2,c2);ell(g,8,cy-ry+2,rr-3,2,c2);
    rect(g,8-rr+2,cy-ry+2,2,2,c3);rect(g,8,cy-ry+1,2,1,c3);rect(g,8+rr-3,cy-2,1,2,c3);sprinkle(g,o.s+77,[c1],5);},
  blossom(g,o){const P=[['#8a4aa8','#b46cd0','#e6b0f4'],['#a8509a','#d078c0','#f8bce8'],['#6a50b0','#9478d8','#cdb8fa']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.8:1);
    const rr=[5,6,7][o.sz],ry=[4,5,5][o.sz],cy=[10,8,7][o.sz];
    rect(g,7,cy+2,2,16-cy-2,'#4a2c24');rect(g,7,cy+2,1,16-cy-2,'#6b4434');rect(g,6,15,4,1,'#4a2c24');
    ell(g,8,cy,rr,ry,c1);ell(g,8-(rr>>1),cy-1,rr-2,ry-2,c2);ell(g,8+(rr>>1),cy-1,rr-2,ry-2,c2);ell(g,8,cy-ry+2,rr-3,2,c2);
    for(let i=0;i<7+o.sz*2;i++){const a=o.r()*6.28,d=o.r()*rr*.85;rect(g,Math.round(8+Math.cos(a)*d),Math.round(cy+Math.sin(a)*d*ry/rr),1,1,i%3?c3:'#fff');}
    rect(g,3+o.sz,15,1,1,c3);rect(g,11,14,1,1,c2);rect(g,13,15,1,1,c3);},
  maple(g,o){const P=[['#a8321c','#d8531f','#f0903a'],['#c8661c','#e8903a','#ffc85a'],['#8a2a2a','#b84030','#e0703a']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.82:1);
    const rr=[5,6,7][o.sz],ry=[4,5,5][o.sz],cy=[10,8,7][o.sz];
    rect(g,7,cy+2,2,16-cy-2,TRUNK[0]);rect(g,7,cy+2,1,16-cy-2,TRUNK[1]);rect(g,6,15,4,1,TRUNK[0]);
    ell(g,8,cy,rr,ry,c1);ell(g,8-(rr>>1),cy-1,rr-3,ry-2,c2);ell(g,8+(rr>>1),cy,rr-3,ry-2,c2);ell(g,8,cy-ry+2,rr-3,2,c2);
    rect(g,8-rr+3,cy-ry+3,2,1,c3);rect(g,8+1,cy-ry+2,2,1,c3);rect(g,8+rr-4,cy-1,2,1,c3);sprinkle(g,o.s+5,[c1,c3],4);
    rect(g,3,15,1,1,c2);rect(g,11,14,1,1,c3);rect(g,13,15,1,1,c1);},
  apple(g,o){const P=[['#2a7a30','#3fa040','#6ad060'],['#3a7a2a','#58a838','#8ed058'],['#1f6a40','#2f9a58','#5ad090']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.8:1);
    const rr=[4,5,6][o.sz],ry=[4,4,5][o.sz],cy=[10,9,8][o.sz],fr=['#e03a3a','#ffd23f','#ff7aa8'][o.tn===2?2:o.tn===1?1:0];
    rect(g,7,cy+2,2,16-cy-2,TRUNK[0]);rect(g,7,cy+2,1,16-cy-2,TRUNK[1]);rect(g,6,15,4,1,TRUNK[0]);
    ell(g,8,cy,rr,ry,c1);ell(g,8-(rr>>1),cy-1,rr-2,ry-2,c2);ell(g,8+(rr>>1),cy-1,rr-2,ry-2,c2);rect(g,8-rr+2,cy-ry+1,2,1,c3);
    for(let i=0;i<4+o.sz;i++){const a=o.r()*6.28,d=o.r()*rr*.8;rect(g,Math.round(8+Math.cos(a)*d),Math.round(cy+Math.sin(a)*d*ry/rr),1,1,fr);}
    rect(g,4+o.sz,15,1,1,fr);},
  birch(g,o){const P=[['#5fa84a','#8fd05a','#b8e878'],['#7aa83a','#a8cf4a','#d0e86a'],['#4f9a58','#7acc7a','#a8e8a0']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.78:1);
    const rr=[3,4,5][o.sz],cy=[8,7,6][o.sz];
    rect(g,7,cy+1,2,16-cy-1,'#ece8da');rect(g,8,cy+1,1,16-cy-1,'#c9c4b0');for(let y=cy+3;y<16;y+=3){rect(g,7,y,o.r()<.5?1:2,1,'#33302c');}rect(g,6,15,4,1,'#8a8678');
    ell(g,8-1,cy-1,rr,rr-1,c1);ell(g,8+2,cy,rr-1,rr-1,c1);ell(g,8,cy-rr+2,rr-1,2,c2);ell(g,8-2,cy-1,rr-2,rr-2,c2);rect(g,8-rr+1,cy-2,2,1,c3);rect(g,8+1,cy-rr+1,2,1,c3);
    rect(g,8-rr-1,cy+1,1,2,c1);rect(g,8+rr+1,cy+1,1,1,c1);},
  pine(g,o){const P=[['#1d5a34','#2a7a4e','#4a9a68'],['#1a4a4a','#2a6a66','#4a8a86'],['#16401f','#25602f','#3a8048']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.82:1);
    const n=[2,3,3][o.sz],top=[4,2,0][o.sz],step=Math.floor((13-top)/n),wd=[3,3.5,4][o.sz];
    rect(g,7,12,2,4,TRUNK[0]);rect(g,7,12,1,4,TRUNK[1]);
    for(let i=0;i<n;i++){const ty=top+i*step,w=Math.round(wd+i*2.2),by=ty+step+3;tri(g,8,ty,8-w,by,8+w,by,c1);tri(g,8,ty+1,8-w+1,by-1,8,by-1,c2);tri(g,8,ty,8-Math.floor(w/2),ty+Math.floor(step*.7),8,ty+Math.floor(step*.7),c3);}},
  fir(g,o){const P=[['#16401f','#25602f','#3a8048'],['#17463a','#256a58','#3a8a76'],['#233c1c','#386a2c','#548a40']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.85:1);
    const n=[3,4,4][o.sz],top=[3,1,0][o.sz],step=Math.floor((14-top)/n);
    rect(g,7,13,2,3,TRUNK[0]);
    for(let i=0;i<n;i++){const ty=top+i*step,w=2+i+(o.sz?1:0),by=ty+step+2;tri(g,8,ty,8-w,by,8+w,by,c1);tri(g,8,ty+1,8-w+1,by-1,8,by-1,c2);rect(g,8-1,ty+1,1,1,c3);}},
  willow(g,o){const P=[['#4a8a4a','#7ab85a','#a8d878'],['#5a9a6a','#8ad08a','#b8f0b0'],['#6a9a3a','#a0c850','#cce878']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.8:1);
    const rr=[5,6,7][o.sz],cy=[6,5,4][o.sz];
    rect(g,6,cy+2,4,16-cy-2,TRUNK[0]);rect(g,7,cy+2,2,16-cy-2,'#8a6a46');rect(g,5,15,6,1,TRUNK[0]);
    ell(g,8,cy,rr,3,c1);ell(g,8,cy-1,rr-2,2,c2);
    for(let x=8-rr+1;x<=8+rr-1;x++){const len=3+Math.floor(o.r()*(4+o.sz)),col=(x+o.sz)%2?c2:c1;if(Math.abs(x-8)<2)continue;rect(g,x,cy+1,1,len,col);if(o.r()<.4)rect(g,x,cy+len,1,1,c3);}
    rect(g,8-rr+2,cy-2,2,1,c3);},
  dead(g,o){const P=[['#4a3a2e','#6a5646'],['#5a5a5a','#8a8a84'],['#3a2a22','#5a4638']][o.tn],[c1,c2]=shadeAll(P,o.dark?.8:1);
    const h=[7,5,3][o.sz];
    rect(g,7,h+2,2,16-h-2,c1);rect(g,7,h+2,1,16-h-2,c2);rect(g,6,14,4,2,c1);rect(g,5,15,2,1,c1);rect(g,10,15,2,1,c1);
    line(g,8,h+4,3,h-(o.r()<.5?1:0),c1);line(g,8,h+2,13,h-1,c1);line(g,8,h+6,12,h+4,c1);line(g,8,h+7,4,h+6,c1);
    line(g,3,h,2,h-2,c1);line(g,13,h-1,14,h-3,c1);rect(g,8,h,1,2,c1);rect(g,3,h+1,1,1,c2);rect(g,12,h,1,1,c2);},
  // ---- Frosthowl ----
  spine(g,o){const P=[['#1d5a3a','#2a7a4e'],['#1a4a50','#2a6a72'],['#224a2c','#34703e']][o.tn];
    const n=[2,3,3][o.sz],top=[4,2,0][o.sz],step=Math.floor((13-top)/n),wd=[3,3.5,4][o.sz];
    rect(g,7,12,2,4,TRUNK[0]);
    for(let i=0;i<n;i++){const ty=top+i*step,w=Math.round(wd+i*2.2),by=ty+step+3;tri(g,8,ty,8-w,by,8+w,by,P[0]);tri(g,8,ty+1,8-w+1,by-1,8,by-1,P[1]);
      tri(g,8,ty,8-Math.round(w*.6),ty+Math.ceil(step*.8),8+Math.round(w*.6),ty+Math.ceil(step*.8),'#f2f7ff');rect(g,8-w,by-1,2,1,'#f2f7ff');rect(g,8+w-1,by-1,2,1,'#f2f7ff');}},
  sfir(g,o){const P=[['#17463a','#256a58'],['#16401f','#25602f'],['#1a3a4a','#28607a']][o.tn];
    const n=[3,4,4][o.sz],top=[3,1,0][o.sz],step=Math.floor((14-top)/n);
    rect(g,7,13,2,3,TRUNK[0]);
    for(let i=0;i<n;i++){const ty=top+i*step,w=2+i+(o.sz?1:0),by=ty+step+2;tri(g,8,ty,8-w,by,8+w,by,P[0]);tri(g,8,ty+1,8-w+1,by-1,8,by-1,P[1]);tri(g,8,ty,8-w+1,by-1,8+w-1,by-1,'rgba(244,248,255,.55)');rect(g,8-w,by-1,w*2+1,1,'#f2f7ff');}},
  sdead(g,o){const c1=['#4a4a52','#5a4a46','#3c3c46'][o.tn],h=[7,5,3][o.sz];
    rect(g,7,h+2,2,16-h-2,c1);rect(g,6,14,4,2,c1);line(g,8,h+4,3,h,c1);line(g,8,h+2,13,h-1,c1);line(g,8,h+6,12,h+4,c1);
    rect(g,7,h+1,2,1,'#f2f7ff');rect(g,3,h-1,2,1,'#f2f7ff');rect(g,12,h-2,2,1,'#f2f7ff');rect(g,11,h+3,2,1,'#f2f7ff');rect(g,5,14,6,1,'#f2f7ff');},
  // ---- Mirewood ----
  cypress(g,o){const P=[['#2f5a34','#4a7a44'],['#3a5a3a','#5a8a50'],['#2a4a38','#3e6e58']][o.tn],tr=['#4a3a28','#6a5a40'];
    const cy=[5,4,3][o.sz],rr=[5,6,7][o.sz];
    ell(g,8,15,6,1,'#2c4a3e');rect(g,6,cy+2,4,13,tr[0]);rect(g,7,cy+2,1,13,tr[1]);tri(g,8,10,3,15,13,15,tr[0]);rect(g,2,14,1,2,tr[0]);rect(g,13,14,1,2,tr[0]);rect(g,4,15,1,1,tr[1]);
    ell(g,8,cy,rr,3,P[0]);ell(g,8,cy-1,rr-2,2,P[1]);
    for(let x=8-rr+1;x<=8+rr-1;x+=2){const len=2+Math.floor(o.r()*(4+o.sz));rect(g,x,cy+1,1,len,'#8aa86a');rect(g,x,cy+len,1,1,'#aac484');}},
  mangrove(g,o){const P=[['#2a6a3a','#46903f'],['#336a30','#5a9a3c'],['#1f5a4a','#2f8a68']][o.tn],tr=['#4a3424','#6a4c34'];
    const cy=[6,5,4][o.sz],rr=[4,5,6][o.sz];
    ell(g,8,15,6,1,'#2c4a3e');
    line(g,8,cy+3,3,15,tr[0]);line(g,8,cy+3,13,15,tr[0]);line(g,8,cy+4,6,15,tr[0]);line(g,8,cy+4,10,15,tr[0]);rect(g,7,cy+2,2,4,tr[1]);line(g,3,15,2,15,tr[0]);line(g,13,15,14,15,tr[0]);
    ell(g,8,cy,rr,3,P[0]);ell(g,8-1,cy-1,rr-2,2,P[1]);rect(g,8-rr,cy+1,1,3,P[0]);rect(g,8+rr,cy+1,1,2,P[0]);rect(g,8+rr-2,cy-3,2,1,P[1]);},
  // ---- Sundered Ruins ----
  palm(g,o){const th=[8,10,12][o.sz],bend=o.tn===1?-2:o.tn===2?3:2,tx=8+bend,ty=15-th,gr=[['#2a7a2a','#4aa83a'],['#3a7a30','#68b040'],['#4a7a2a','#a0b840']][o.tn];
    const tr=['#8a6a3a','#b08a4a'];
    for(let i=0;i<=th;i++){const f=i/th,x=Math.round(8+bend*f*f),y=15-i;rect(g,x-1,y,2,1,i%3===0?tr[0]:tr[1]);}
    rect(g,6,15,5,1,tr[0]);ell(g,8,15,5,1,'rgba(120,90,40,.45)');
    const L=4+o.sz;
    for(const [dx,dy] of [[-L,1],[-L+1,-1],[0,-3],[L-1,-1],[L,1],[-2,2],[2,2]]){line(g,tx,ty,tx+dx,ty+dy,gr[0]);line(g,tx,ty+1,tx+dx,ty+dy+1,gr[1]);}
    rect(g,tx-1,ty,2,2,'#6a4a22');rect(g,tx+1,ty+2,1,1,'#6a4a22');},
  acacia(g,o){const P=[['#5a7a2a','#8aa83a'],['#7a8a30','#a8b848'],['#6a6a28','#9a9a40']][o.tn],tr=['#4a3220','#6a4a30'];
    const cy=[6,5,4][o.sz];
    rect(g,7,cy+2,2,14-cy,tr[0]);rect(g,7,cy+2,1,14-cy,tr[1]);rect(g,6,15,4,1,tr[0]);line(g,8,cy+3,4,cy,tr[0]);line(g,8,cy+3,12,cy,tr[0]);
    ell(g,8,cy-1,7,2,P[0]);ell(g,4,cy,3,2,P[0]);ell(g,12,cy,3,2,P[0]);ell(g,8,cy-2,5,1,P[1]);rect(g,3,cy-1,2,1,P[1]);rect(g,11,cy-1,2,1,P[1]);},
  ddead(g,o){const c1='#7a6a4a',c2='#cdb98a',h=[7,5,3][o.sz];
    rect(g,7,h+2,2,16-h-2,c1);rect(g,7,h+2,1,16-h-2,c2);rect(g,6,14,4,2,c1);line(g,8,h+4,3,h+1,c1);line(g,8,h+2,12,h-1,c1);line(g,8,h+6,12,h+5,c1);rect(g,3,h,1,1,c2);rect(g,12,h-2,1,1,c2);},
  // ---- ground clutter (walkable) ----
  bush(g,o){const P=[['#2a6a2c','#3d8a3a','#6ac060'],['#23602e','#368a4a','#5ac080'],['#3a6a22','#5a9a30','#90d050']][o.tn],[c1,c2,c3]=shadeAll(P,o.dark?.78:1),b=['#e03a5a','#7a7aff','#ffd23f'][o.tn];
    const w=[3,4,5][o.sz];ell(g,8,13,w+1,1,'rgba(0,0,0,.18)');ell(g,8,11,w,3,c1);ell(g,8-(w>>1),10,w-2,2,c2);ell(g,8+(w>>1),10,w-2,2,c2);rect(g,8-w+2,9,2,1,c3);
    for(let i=0;i<3;i++)rect(g,8-w+2+Math.floor(o.r()*(2*w-3)),9+Math.floor(o.r()*4),1,1,b);},
  fern(g,o){const P=[['#245a2c','#3a8a3a'],['#1f5a40','#2f8a5a'],['#3a5a1f','#5a8a2f']][o.tn],[c1,c2]=shadeAll(P,o.dark?.8:1);
    for(const [dx,dy] of [[-5,-2],[-3,-5],[0,-6],[3,-5],[5,-2],[-4,0],[4,0]]){line(g,8,13,8+dx,13+dy+(o.sz?-1:1),c1);line(g,8,13,8+dx,14+dy+(o.sz?-1:1),c2);}},
  sbush(g,o){const c1=['#1d5a3a','#2a6a58','#355a2c'][o.tn],w=[3,4,5][o.sz];ell(g,8,13,w+1,1,'rgba(40,60,100,.2)');ell(g,8,11,w,3,c1);rect(g,8-w+1,9,w*2-1,2,'#f2f7ff');rect(g,8-w,11,2,1,'#dce8f6');rect(g,8+w-2,10,2,1,'#f2f7ff');rect(g,8-1,8,3,1,'#f2f7ff');},
  shrub(g,o){const c=['#b8924a','#a8a05a','#c8a468'][o.tn],d='#8a6a34',w=[3,4,5][o.sz];ell(g,8,13,w+1,1,'rgba(90,60,20,.25)');
    for(const dx of [-w,-w+2,0,w-2,w]){line(g,8,13,8+dx,13-3-Math.floor(o.r()*3),d);rect(g,8+dx,13-3-Math.floor(o.r()*2)-1,1,1,c);}rect(g,7,11,2,2,c);rect(g,5,12,1,1,c);rect(g,10,12,1,1,c);},
  stump(g,o){const c=['#c9a06a','#d8b080','#b88c58'][o.tn];const w=[2,3,3][o.sz];
    ell(g,8,13,w+2,1,'rgba(0,0,0,.2)');rect(g,8-w,9,w*2,4,TRUNK[1]);rect(g,8-w,9,2,4,TRUNK[0]);rect(g,8-w-1,13,2,1,TRUNK[0]);rect(g,8+w-1,13,2,1,TRUNK[0]);
    ell(g,8,9,w,1,c);rect(g,7,9,2,1,TRUNK[1]);
    if(o.dark){rect(g,11,12,1,1,'#e8e0d0');rect(g,11,11,2,1,'#c0392b');}},
  sstump(g,o){const w=[2,3,3][o.sz];ell(g,8,13,w+2,1,'rgba(40,60,100,.2)');rect(g,8-w,9,w*2,4,'#5a4636');rect(g,8-w,9,2,4,'#3a2c22');ell(g,8,9,w+1,1,'#f2f7ff');rect(g,8-w,8,w*2,1,'#e4edf8');},
  mstump(g,o){const w=[2,3,3][o.sz];ell(g,8,14,w+2,1,'#2c4a3e');rect(g,8-w,9,w*2,5,'#4a3a28');rect(g,8-w,9,2,5,'#33281c');ell(g,8,9,w,1,'#7a6a48');rect(g,8-w,10,w*2,1,'#6a8a46');rect(g,8+w-2,12,2,1,'#6a8a46');rect(g,8-1,8,2,1,'#8aa86a');},
  rocks(g,o){const w=[2,3,4][o.sz];ell(g,8,13,w+3,1,'rgba(90,60,20,.25)');ell(g,8-1,11,w,w-1,'#9c8a6a');ell(g,8-1,10,w-1,w-2,'#c0ae88');ell(g,8+w,12,2,2,'#a89672');rect(g,8-w,9,2,1,'#d8c8a0');},
};
// ---- which species grow where ----
function vnoise(x,y,s){const fx=x*s,fy=y*s,xi=Math.floor(fx),yi=Math.floor(fy),tx=fx-xi,ty=fy-yi,sx=tx*tx*(3-2*tx),sy=ty*ty*(3-2*ty);
  const h=(a,b)=>(hash2(a+101,b+57)%1024)/1024;return lerp(lerp(h(xi,yi),h(xi+1,yi),sx),lerp(h(xi,yi+1),h(xi+1,yi+1),sx),sy);}
function pickTreeW(r,tbl){let t=0;for(const e of tbl)t+=e[1];r*=t;for(const e of tbl){if((r-=e[1])<0)return e[0];}return tbl[0][0];}
function nearWater(x,y){for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++){const xx=x+dx,yy=y+dy;if(xx>=0&&yy>=0&&xx<MW&&yy<MH&&map[yy][xx]===T.W)return true;}return false;}
function treeKind(id,x,y,r,zone){
  if(id===T.PM)return 'palm';
  if(id===T.AC)return r<.7?'acacia':'ddead';
  if(zone==='snow')return id===T.PN?pickTreeW(r,[['spine',52],['sfir',30],['sdead',12]]):(r<.8?'sbush':'sstump');
  if(zone==='swamp')return id===T.RE?pickTreeW(r,[['reedtile',30],['cypress',36],['mangrove',22],['mdead',12]]):(r<.7?'fern':'mstump');
  if(zone==='desert')return r<.8?'shrub':'rocks';
  // overworld
  const dark=regions.forest(x,y);
  if(id===T.BU)return dark&&r<.4?'fern':'bush';
  if(id===T.ST)return 'stump';
  const n=vnoise(x,y,.17);
  if(nearWater(x,y)&&r<.55)return 'willow';
  if(inOrchard(x,y))return r<.62?'apple':r<.84?'blossom':'birch';
  if(regions.village(x,y))return pickTreeW(r,[['oak',28],['apple',20],['birch',16],['blossom',16],['maple',8],['pine',8],['fir',4]]);
  if(dark){
    if(n<.38)return pickTreeW(r,[['pine',34],['fir',26],['oak',16],['dead',9],['birch',7],['maple',8]]);
    if(n<.66)return pickTreeW(r,[['oak',30],['maple',22],['pine',14],['birch',12],['blossom',8],['apple',4],['dead',6],['fir',4]]);
    return pickTreeW(r,[['maple',40],['blossom',14],['birch',18],['oak',12],['fir',6],['dead',10]]);
  }
  if(y-OY<14&&x-OX>=18)return pickTreeW(r,[['pine',30],['fir',20],['oak',25],['dead',10],['birch',15]]);
  if(n<.45)return pickTreeW(r,[['oak',24],['birch',20],['blossom',20],['apple',12],['maple',10],['pine',8],['dead',3],['fir',3]]);
  return pickTreeW(r,[['birch',24],['maple',18],['oak',20],['blossom',16],['pine',12],['fir',4],['apple',6]]);
}
function treeHash(x,y){let m=(Math.imul(x+11,0x9E3779B1)^Math.imul(y+7,0x85EBCA6B))>>>0;m^=m>>>15;m=Math.imul(m,0x2C1B3C6D)>>>0;m^=m>>>12;return m>>>0;}
const treeKindAt=(id,x,y)=>treeKind(id,x,y,(treeHash(x,y)&1023)/1024,zoneOfTy(y));
let TREE_TILE=new Array(64*224),TREE_TILE_ID=new Uint8Array(64*224);   // per-tile memo: after the first draw a tree tile costs one array read
function treeSprite(id,x,y){
  const ti=y*MW+x;if(TREE_TILE_ID[ti]===id&&TREE_TILE[ti])return TREE_TILE[ti];
  const c=treeSpriteBuild(id,x,y);TREE_TILE[ti]=c;TREE_TILE_ID[ti]=id;return c;
}
function treeSpriteBuild(id,x,y){
  const m=treeHash(x,y);
  const zone=zoneOfTy(y),r=(m&1023)/1024,s3=(m>>>10)&15,sz=s3<4?0:s3<12?1:2,tn=((m>>>14)&3)%3,flip=(m>>>16)&1,bgv=(m>>>17)&1;
  let kind=treeKind(id,x,y,r,zone);
  BLOSSOM[y*MW+x]=kind==='blossom'?1:0;
  const dark=zone==='ow'&&regions.forest(x,y);
  const key=kind+'|'+zone+'|'+(dark?1:0)+'|'+sz+tn+flip+bgv;
  let c=TREE_CACHE.get(key);if(c)return c;
  const floor=zone==='snow'?TSPR[T.SN]:zone==='swamp'?TSPR[T.MD]:zone==='desert'?TSPR[T.SD]:(dark?TSPR[T.K]:TSPR[T.G]);
  const bg=floor[bgv?2:0];
  if(kind==='reedtile'){c=TSPR[T.RE][bgv];TREE_CACHE.set(key,c);return c;}
  if(kind==='mdead')kind='dead';
  const art=TREE_ART[kind]||TREE_ART.oak;
  const o={sz,tn,dark,s:m&255,r:mulberry32(m||1)};
  c=makeSprite(16,16,g=>{g.drawImage(bg,0,0);
    if(flip){const t=makeSprite(16,16,gg=>art(gg,o));g.save();g.translate(16,0);g.scale(-1,1);g.drawImage(t,0,0);g.restore();}
    else art(g,o);
    if(kind==='dead'&&zone==='swamp'){rect(g,6,9,1,3,'#8aa86a');rect(g,10,8,1,4,'#8aa86a');rect(g,9,10,1,2,'#aac484');}});
  TREE_CACHE.set(key,c);return c;
}

/* ---- Big trees (default ON): trees are drawn ~2x so they tower over the characters; bushes / stumps / reeds stay character-sized.
   Collision, spawns and the map are unchanged (the solid tile is still just the trunk tile); the canopy is drawn y-sorted so it covers the hero
   when walking behind it and fades while anything is under it. ?bigtrees=0 turns it off, ?bigtrees=1.5 etc. changes the scale. ---- */
const BIGTREE=Math.min(2.4,Math.max(0,(()=>{const v=new URLSearchParams(location.search).get('bigtrees');return v===null||v===''||isNaN(+v)?2:+v;})()));
const BIGTREE_IDS=new Set([T.T,T.PN,T.PM,T.AC]);
const BIGT_CACHE=new Map();
function treeLayers(id,x,y){   // {bg: the ground tile, fg: the tree alone on a transparent tile}
  const ti=y*MW+x,key=ti+'|'+id;let r=BIGT_CACHE.get(key);if(r)return r;
  const m=treeHash(x,y),zone=zoneOfTy(y),rr=(m&1023)/1024,s3=(m>>>10)&15,sz=s3<4?0:s3<12?1:2,tn=((m>>>14)&3)%3,flip=(m>>>16)&1,bgv=(m>>>17)&1;
  let kind=treeKind(id,x,y,rr,zone);if(kind==='mdead')kind='dead';
  const dark=zone==='ow'&&regions.forest(x,y);
  const floor=zone==='snow'?TSPR[T.SN]:zone==='swamp'?TSPR[T.MD]:zone==='desert'?TSPR[T.SD]:(dark?TSPR[T.K]:TSPR[T.G]);
  const art=TREE_ART[kind]||TREE_ART.oak,o={sz,tn,dark,s:m&255,r:mulberry32(m||1)};
  const fg=makeSprite(16,16,g=>{if(flip){const t=makeSprite(16,16,gg=>art(gg,o));g.save();g.translate(16,0);g.scale(-1,1);g.drawImage(t,0,0);g.restore();}else art(g,o);});
  r={bg:floor[bgv?2:0],fg};BIGT_CACHE.set(key,r);return r;
}
