/* =====================================================================
   t145u HIGH-DEFINITION PASS. Every static 16x16 tile (and every small sprite drawn at 2x: hero, NPCs, enemies, pets, props,
   icons) is re-rendered once into a 32x32 canvas and cached, so the 16-px grid and the 2x look stay exactly the same, but the
   art gets a second layer of crisp pixel detail at the screen's real resolution:
   - Scale2x edge smoothing (crisp pixel-art diagonals, no blur)
   - material-aware micro texture picked per source pixel colour:
       grass   -> per-subpixel colour noise + little blade strokes (light tip, dark root)
       dirt    -> colour noise + scattered pebbles with a lit top and a shadow under
       stone   -> fine grain, lit brick tops / shaded brick bottoms along the mortar lines, moss specks under ledges
   - bevel shading: lit top edges, shaded bottom edges wherever the colour or the silhouette changes (sprites get a rim light)
   Trees and house walls / roofs (which Seth likes as they are) and the animated water frames are left alone.
   ===================================================================== */
const HDX={cache:new WeakMap(),miss:0,frame:-1,on:true};
function hdHash(x,y,s){let h=(x*374761393+y*668265263+s*1442695041)|0;h=Math.imul(h^(h>>>13),1274126177);return ((h^(h>>>16))>>>0)/4294967296;}
function hdBuild(src,mode){
  const w=src.width,h=src.height;let id;try{id=src.getContext('2d').getImageData(0,0,w,h).data;}catch(e){return null;}
  const W=w*2,H=h*2,out=new Uint8ClampedArray(W*H*4),px=(x,y)=>x<0||y<0||x>=w||y>=h?-1:(y*w+x);
  const same=(a,b)=>{if(a<0||b<0)return a===b;const i=a*4,j=b*4;return id[i]===id[j]&&id[i+1]===id[j+1]&&id[i+2]===id[j+2]&&id[i+3]===id[j+3];};
  const lum=p=>p<0?-1:(id[p*4+3]<128?-1:id[p*4]*.3+id[p*4+1]*.59+id[p*4+2]*.11);
  const seed=(w*7+h*13+id[0]+id[5]*3+id[17]*7+id[(w*h>>1)*4+1]*11)|0;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const P=px(x,y),A=px(x,y-1),B=px(x+1,y),C=px(x-1,y),D=px(x,y+1);
    // Scale2x
    let e=[P,P,P,P];
    if(!same(A,D)&&!same(C,B)){if(same(C,A))e[0]=C;if(same(A,B))e[1]=B;if(same(C,D))e[2]=C;if(same(D,B))e[3]=B;}
    if(e.some(q=>q<0))e=e.map(q=>q<0?P:q);
    const L=lum(P),la=lum(A),ld=lum(D);
    for(let k=0;k<4;k++){
      const sx=x*2+(k&1),sy=y*2+(k>>1),o=(sy*W+sx)*4,s=e[k]*4;
      let r=id[s],g=id[s+1],b=id[s+2],a=id[s+3];
      if(a>0){
        let f=1;const hv=hdHash(sx,sy,seed),mx=Math.max(r,g,b),mn=Math.min(r,g,b),sat=mx?(mx-mn)/mx:0,lu=r*.3+g*.59+b*.11;
        const grass=g>r+8&&g>=b&&sat>.18,dirt=r>=g&&g>=b&&r-b>28&&sat<.6&&lu>70,stone=sat<.16&&lu>50&&lu<215;
        if(mode==='tile'){
          if(grass){f*=.955+hv*.09;
            const hb=hdHash(sx,sy-1,seed+3);
            if(hdHash(sx,sy,seed+1)<.07)f*=1.2;else if(hb<.07)f*=.82;              // blade tip / root
          }else if(dirt){f*=.95+hv*.1;
            if(hdHash(x,y,seed+7)<.05&&(k===0)){f*=1.28;}else if(hdHash(x,y-1,seed+7)<.05&&k<2){f*=.74;}   // pebble + its shadow
          }else if(stone){f*=.96+hv*.08;
            if(hdHash(x,y+1,seed+9)<.04&&k>=2&&ld>=0&&ld<L-25){r=r*.6+58*.4;g=g*.6+110*.4;b=b*.6+52*.4;}   // moss under a ledge
          }
        }
        // bevel: lit top / shaded bottom across colour or silhouette edges
        if(k<2&&(la<0?mode==='spr':la<L-18))f*=mode==='spr'?1.16:1.1;
        if(k>=2&&(ld<0?mode==='spr':ld<L-18))f*=mode==='spr'?.84:.9;
        if(f!==1){r=Math.min(255,r*f);g=Math.min(255,g*f);b=Math.min(255,b*f);}
      }
      out[o]=r;out[o+1]=g;out[o+2]=b;out[o+3]=a;
    }
  }
  const c=document.createElement('canvas');c.width=W;c.height=H;c.getContext('2d').putImageData(new ImageData(out,W,H),0,0);return c;
}
function hdGet(src,mode){
  if(!HDX.on||!src||!src.getContext)return null;let c=HDX.cache.get(src);if(c!==undefined)return c;
  const fr=Math.floor(gtime*60);if(fr!==HDX.frame){HDX.frame=fr;HDX.miss=0;}if(++HDX.miss>60)return null;   // never stall a frame
  c=hdBuild(src,mode);HDX.cache.set(src,c);return c;
}
const HD_SKIP_TILE=id=>(typeof TREE_IDS!=='undefined'&&TREE_IDS.has(id))||id===T.H||id===T.D||id===T.R||id===T.RL||id===T.W||id===T.U||id===T.PW||id===T.PR||id===T.FR;
{const _ts=tileSprite;tileSprite=function(id,x,y,time){const s=_ts.apply(this,arguments);if(!s||s.width!==16||s.height!==16||HD_SKIP_TILE(id))return s;return hdGet(s,'tile')||s;};}
/* sprites drawn at 2x or more (hero, NPCs, enemies, pets, props, lamps, signs, UI icons): the main canvas's drawImage swaps a small
   source canvas for its HD twin when it is scaled up by 2x or more. Trees / houses / water returned by tileSprite are marked to skip. */
const HD_NO=new WeakSet();
{const _ts2=tileSprite;tileSprite=function(id,x,y,time){const s=_ts2.apply(this,arguments);if(s&&HD_SKIP_TILE(id))HD_NO.add(s);return s;};}
if(typeof treeLayers==='function'){const _tl=treeLayers;treeLayers=function(){const L=_tl.apply(this,arguments);if(L){HD_NO.add(L.bg);HD_NO.add(L.fg);}return L;};}
{const _di=ctx.drawImage.bind(ctx);ctx.drawImage=function(img,a,b,c,d){
  if(arguments.length===5&&img&&img.getContext&&img.width<=48&&img.height<=64&&c>=img.width*1.9&&d>=img.height*1.9&&!HD_NO.has(img)){const h=hdGet(img,'spr');if(h)return _di(h,a,b,c,d);}
  return _di.apply(null,arguments);};}
