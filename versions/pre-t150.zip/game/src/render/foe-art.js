/* =====================================================================
   NEW FOES ART (Glowcap Grove mushrooms + Shardstone Caverns rock creatures). Code-drawn pixel art after Seth's reference sheets:
   16x16 regular foes (light from the top-left, #14182c outline), 32x32 bosses. Disguise sprites for the ambushers (pebble scamp = a rock,
   geode mimic = a geode, chestcap = a treasure chest).
   ===================================================================== */
(function buildFoeArt(){
  const O='#14182c',S=(w,h,fn)=>autoOutline(makeSprite(w,h,fn),O),px=(g,x,y,c)=>rect(g,x,y,1,1,c);
  // ---- mushroom template: cap (dome / pointy / wizard), spots, pale stem face ----
  const cap=(g,o)=>{const {c,l,d,cx=8,cy=6,rx=7,ry=4}=o;ell(g,cx,cy,rx,ry,d);ell(g,cx,cy-1,rx,ry-1,c);ell(g,cx-2,cy-2,rx-3,ry-2,l);rect(g,cx-rx,cy+1,rx*2+1,1,d);};
  const face=(g,o)=>{const {skin='#f6e3c4',skD='#d9bf98',y=8,eyes='#14182c',w=6}=o,x=8-(w>>1);rect(g,x,y,w,5,skin);rect(g,x+w-1,y,1,5,skD);rect(g,x,y+4,w,1,skD);px(g,x+1,y+2,eyes);px(g,x+w-2,y+2,eyes);rect(g,x,y+5,2,1,'#e8d6b4');rect(g,x+w-2,y+5,2,1,'#e8d6b4');};
  const spots=(g,list,c)=>{for(const [x,y,s] of list)rect(g,x,y,s||2,s||2,c);};
  const shroomCol={red:['#c8323a','#e86a5a','#8a1c26','#fff4e0'],purple:['#7a3a94','#b06ad0','#4a1e60','#e8a8f0'],green:['#3e8e4a','#7ad07a','#245a2e','#e8ffd0'],orange:['#d8802a','#f6b24a','#9a5214','#fff0c0']};
  const mkShroom=(k,eyes)=>S(16,16,g=>{const [c,l,d,sp]=shroomCol[k];cap(g,{c,l,d,cy:6});spots(g,[[4,4],[10,3],[7,6,1],[12,6,1]],sp);face(g,{y:9,eyes});});
  SP.redcap=mkShroom('red');SP.shroom=mkShroom('purple');SP.greencap=mkShroom('green');SP.ambercap=mkShroom('orange');
  SP.babyshroom=S(16,16,g=>{ell(g,8,10,4,3,'#8a1c26');ell(g,8,9,4,2,'#c8323a');rect(g,6,8,2,1,'#e86a5a');px(g,10,9,'#fff4e0');px(g,6,10,'#fff4e0');rect(g,6,12,4,3,'#f6e3c4');px(g,7,13,O);px(g,9,13,O);rect(g,9,12,1,3,'#d9bf98');});
  SP.ironcap=S(16,16,g=>{cap(g,{c:'#4a6ab0',l:'#7a9ae0',d:'#2a3e74',cy:6});rect(g,5,3,6,4,'#9aa4b4');rect(g,5,3,6,1,'#d6dce6');rect(g,10,4,1,3,'#6a7484');px(g,6,5,'#d6dce6');px(g,9,5,'#d6dce6');
    rect(g,1,6,3,3,'#9aa4b4');rect(g,12,6,3,3,'#9aa4b4');rect(g,1,6,3,1,'#d6dce6');face(g,{y:9});rect(g,6,10,2,1,O);rect(g,9,10,2,1,O);});   // angry brows
  SP.spitter=S(16,16,g=>{cap(g,{c:'#3a9a7a',l:'#7ad8b0',d:'#1e5e4a',cy:6});for(const [x,y] of [[4,4],[8,3],[11,5]]){rect(g,x,y,2,2,'#f0d040');px(g,x,y,'#fff6a0');}face(g,{y:9});rect(g,7,12,2,1,O);});
  SP.frostcap=S(16,16,g=>{tri(g,8,0,2,9,14,9,'#4a8ad0');tri(g,8,1,4,8,12,8,'#7ab8f0');tri(g,7,1,5,5,8,5,'#cfe8ff');rect(g,2,8,13,1,'#2a5a94');spots(g,[[5,6,1],[10,4,1],[11,7,1]],'#ffffff');face(g,{y:9,skin:'#d6f4ff',skD:'#9ad0e8'});});
  SP.shadowcap=S(16,16,g=>{ell(g,7,6,6,4,'#3a1430');ell(g,7,5,6,3,'#6a2458');ell(g,5,4,3,2,'#8e3a7a');rect(g,12,6,3,2,'#6a2458');rect(g,14,7,1,2,'#3a1430');spots(g,[[4,4],[9,3]],'#e858a8');face(g,{y:9,skin:'#b8a8c0',skD:'#8a7a98',eyes:'#ffe14d'});});
  SP.spore=S(16,16,g=>{cap(g,{c:'#c8323a',l:'#e86a5a',d:'#8a1c26',cy:5});spots(g,[[4,3],[10,2]],'#fff4e0');rect(g,5,5,6,3,'#9aa4b4');rect(g,5,5,6,1,'#d6dce6');rect(g,6,6,1,1,O);rect(g,9,6,1,1,O);   // helmet visor
    face(g,{y:8,w:6});rect(g,0,7,1,5,'#d6dce6');rect(g,1,8,1,4,'#b8c0cc');rect(g,0,12,3,1,'#7a5530');   // little sword
    ell(g,13,11,2,3,'#8a5a2c');rect(g,12,8,3,2,'#5a3a1c');px(g,12,10,'#c08a52');});                    // acorn shield
  SP.lantern=S(16,16,g=>{tri(g,7,0,1,8,14,8,'#d8902a');tri(g,7,1,3,7,12,7,'#f6b24a');rect(g,11,0,3,2,'#d8902a');rect(g,13,1,2,2,'#9a5214');rect(g,1,8,14,1,'#9a5214');spots(g,[[5,5,1],[9,4,1]],'#ffe9a0');
    face(g,{y:9,skin:'#f6e3c4'});rect(g,4,10,4,4,'#2a6a6a');rect(g,12,10,3,4,'#ffd23f');rect(g,12,10,3,1,'#7a5530');px(g,13,12,'#fff6c0');});
  SP.chestcap=S(16,16,g=>{rect(g,1,3,14,7,'#8a5a2c');rect(g,1,3,14,2,'#a8743c');rect(g,1,6,14,1,'#d8a838');rect(g,7,6,2,3,'#f0c838');px(g,7,7,O);rect(g,1,3,1,7,'#d8a838');rect(g,14,3,1,7,'#d8a838');
    ell(g,4,2,2,1,'#9a5ab8');ell(g,11,2,2,1,'#e870a8');rect(g,4,10,8,3,'#f6e3c4');px(g,6,11,O);px(g,9,11,O);rect(g,3,13,3,2,'#9a5ab8');rect(g,10,13,3,2,'#9a5ab8');});
  SP.chestcapD=S(16,16,g=>{rect(g,1,5,14,10,'#8a5a2c');rect(g,1,5,14,3,'#a8743c');rect(g,1,9,14,1,'#d8a838');rect(g,7,9,2,3,'#f0c838');px(g,7,10,O);rect(g,1,5,1,10,'#d8a838');rect(g,14,5,1,10,'#d8a838');rect(g,1,14,14,1,'#5a3a1c');});
  // ---- rock creatures ----
  const rock=(g,cx,cy,rx,ry)=>{ell(g,cx,cy,rx,ry,'#5e5a6e');ell(g,cx-1,cy-1,rx-1,ry-1,'#8a8698');ell(g,cx-2,cy-2,Math.max(1,rx-3),Math.max(1,ry-3),'#aaa6b6');};
  const eyes=(g,x,y,c='#ffc23a',gap=3)=>{px(g,x,y,c);px(g,x+gap,y,c);};
  SP.scamp=S(16,16,g=>{rock(g,8,10,6,4);eyes(g,6,10);rect(g,4,14,2,1,'#5e5a6e');rect(g,10,14,2,1,'#5e5a6e');});
  SP.scampD=S(16,16,g=>{rock(g,8,11,6,4);rect(g,4,13,8,1,'#5e5a6e');});
  SP.shscorp=S(16,16,g=>{ell(g,7,11,4,3,'#4e5268');ell(g,7,10,3,2,'#7a7e98');rect(g,9,4,2,2,'#4e5268');rect(g,10,6,2,3,'#4e5268');rect(g,8,8,2,2,'#4e5268');tri(g,10,0,13,3,9,4,'#c890f0');px(g,11,1,'#f0d8ff');
    rect(g,1,9,3,2,'#7a7e98');rect(g,0,8,2,1,'#aaa6b6');rect(g,12,10,3,2,'#7a7e98');eyes(g,5,10,'#ffc23a',2);for(const x of [4,6,8,10])px(g,x,14,'#4e5268');});
  SP.sentinel=S(16,16,g=>{rect(g,5,0,6,4,'#d8c098');rect(g,5,0,6,1,'#f0dcb4');rect(g,7,1,2,2,O);px(g,7,1,'#7df9ff');rect(g,5,5,6,5,'#d8c098');rect(g,5,5,6,1,'#f0dcb4');rect(g,6,6,3,3,'#7df9ff');px(g,7,7,'#d8c098');
    rect(g,1,6,3,3,'#c8b088');rect(g,12,6,3,3,'#c8b088');rect(g,6,11,4,3,'#c8b088');rect(g,6,11,4,1,'#e8d4ac');});
  SP.maw=S(16,16,g=>{rock(g,8,8,7,6);ell(g,8,4,5,2,'#7aa83a');rect(g,3,3,2,2,'#7aa83a');rect(g,4,8,9,5,O);for(let x=4;x<13;x+=2){px(g,x,8,'#f6e3c4');px(g,x+1,12,'#f6e3c4');}eyes(g,6,6,'#ffc23a',4);rect(g,4,14,3,2,'#5e5a6e');rect(g,10,14,3,2,'#5e5a6e');});
  SP.tortoise=S(16,16,g=>{ell(g,7,10,6,3,'#6e6a80');ell(g,7,9,5,2,'#9a96aa');rect(g,4,9,3,1,'#7df9ff');rect(g,9,10,2,1,'#7df9ff');tri(g,7,2,5,7,9,7,'#b070e0');tri(g,7,3,6,6,8,6,'#e0b0ff');tri(g,4,5,3,8,6,8,'#b070e0');tri(g,11,5,10,8,12,8,'#b070e0');
    rect(g,12,9,4,3,'#8a8698');px(g,14,10,'#ffc23a');rect(g,2,13,2,2,'#5e5a6e');rect(g,10,13,2,2,'#5e5a6e');});
  SP.fbat=S(16,16,g=>{tri(g,0,7,7,5,6,10,'#4e5268');tri(g,16,7,9,5,10,10,'#4e5268');tri(g,1,7,6,6,6,9,'#7a7e98');tri(g,15,7,10,6,10,9,'#7a7e98');rect(g,6,6,4,5,'#7a7e98');rect(g,6,5,1,1,'#7a7e98');rect(g,9,5,1,1,'#7a7e98');eyes(g,6,8,'#ffc23a',3);});
  SP.bboar=S(16,16,g=>{rock(g,7,9,6,4);ell(g,6,5,4,2,'#7aa83a');rect(g,11,8,4,4,'#7a7690');rect(g,13,10,2,1,'#5e5a6e');px(g,12,8,'#ffc23a');rect(g,11,11,1,2,'#f6e3c4');rect(g,15,9,1,2,'#f6e3c4');for(const x of [3,6,9])rect(g,x,13,2,2,'#5e5a6e');});
  SP.geode=S(16,16,g=>{rock(g,8,6,6,4);rect(g,3,8,10,1,O);ell(g,8,11,6,3,'#5e5a6e');ell(g,8,11,5,2,'#7a3a94');for(const x of [4,6,9,11])tri(g,x,9,x-1,12,x+1,12,'#c890f0');ell(g,8,11,1,1,'#40d8d8');eyes(g,6,5,'#ffc23a',4);});
  SP.geodeD=S(16,16,g=>{rock(g,8,9,6,5);rect(g,6,6,2,2,'#c890f0');px(g,6,6,'#f0d8ff');rect(g,10,9,1,2,'#40d8d8');});
  SP.crawler=S(16,16,g=>{ell(g,8,11,6,3,'#4a4e6e');ell(g,8,10,5,2,'#6e72a0');tri(g,8,3,6,9,10,9,'#b070e0');tri(g,8,4,7,8,9,8,'#e0b0ff');tri(g,4,6,3,9,6,9,'#b070e0');tri(g,12,6,10,9,13,9,'#b070e0');eyes(g,6,11,'#fff3c0',3);for(const x of [2,5,10,13])rect(g,x,13,1,3,'#4a4e6e');});
  SP.cgolem=S(16,16,g=>{rock(g,8,4,4,3);rect(g,3,7,10,6,'#3e3a48');rect(g,4,7,8,4,'#5a5666');rect(g,1,7,3,5,'#4e4a5a');rect(g,12,7,3,5,'#4e4a5a');rect(g,4,13,3,3,'#3e3a48');rect(g,9,13,3,3,'#3e3a48');
    line(g,6,8,8,11,'#ff9a2a');line(g,10,8,9,12,'#ff9a2a');px(g,2,9,'#ff9a2a');px(g,13,10,'#ff9a2a');eyes(g,6,4,'#ffc23a',3);});
  SP.mgolem=S(16,16,g=>{rock(g,8,4,4,3);rect(g,3,7,10,6,'#6e6a7c');rect(g,4,7,8,3,'#8a8698');rect(g,0,8,4,5,'#7a7690');rect(g,12,8,4,5,'#7a7690');rect(g,4,13,3,3,'#5e5a6e');rect(g,9,13,3,3,'#5e5a6e');
    ell(g,4,7,3,1,'#7aa83a');ell(g,12,7,3,1,'#7aa83a');rect(g,2,8,1,3,'#7aa83a');rect(g,13,8,1,2,'#7aa83a');rect(g,7,9,2,2,'#40d8d8');eyes(g,6,4,'#fff3c0',3);});
  // ---- bosses (32x32) ----
  SP.warden=S(32,32,g=>{const s='#d8c098',l='#f0dcb4',d='#a8906c';rect(g,6,1,20,3,s);rect(g,6,1,20,1,l);rect(g,6,4,3,8,s);rect(g,23,4,3,8,s);   // ruined arch crown
    rect(g,9,8,14,14,s);rect(g,9,8,14,2,l);rect(g,22,8,1,14,d);rect(g,13,10,6,4,O);rect(g,15,11,2,2,'#ffc23a');ell(g,16,17,3,3,'#40d8d8');ell(g,16,17,1,1,'#e0ffff');
    rect(g,2,10,7,9,s);rect(g,23,10,7,9,s);rect(g,2,10,7,1,l);rect(g,1,19,8,6,s);rect(g,23,19,8,6,s);rect(g,10,22,5,8,s);rect(g,17,22,5,8,s);rect(g,10,22,5,1,d);
    for(const [x,y] of [[8,9],[22,9],[4,12],[26,13]])rect(g,x,y,2,4,'#6aa83a');});
  SP.colony=S(32,32,g=>{rect(g,8,10,16,16,'#7a4a2a');rect(g,8,10,16,2,'#9a6a3a');rect(g,23,10,1,16,'#5a321a');ell(g,16,11,9,3,'#6aa83a');rect(g,9,12,3,5,'#6aa83a');rect(g,20,12,3,4,'#6aa83a');
    ell(g,16,19,5,4,'#f6e3c4');rect(g,13,18,2,2,O);rect(g,17,18,2,2,O);rect(g,14,22,4,2,'#d9bf98');rect(g,4,22,5,3,'#5a321a');rect(g,23,22,5,3,'#5a321a');rect(g,8,26,5,4,'#5a321a');rect(g,19,26,5,4,'#5a321a');
    for(const [x,y,c] of [[16,4,'#c8323a'],[6,7,'#9a5ab8'],[26,8,'#9a5ab8'],[4,14,'#e870a8'],[27,15,'#e870a8']]){ell(g,x,y,3,2,c);rect(g,x-1,y+2,2,2,'#f6e3c4');}px(g,15,3,'#fff4e0');px(g,17,4,'#fff4e0');});
  SP.mking=S(32,32,g=>{ell(g,16,13,14,8,'#2e6a2e');ell(g,16,12,13,7,'#4a8e3a');ell(g,12,9,7,3,'#7ac05a');for(const x of [6,10,20,25])rect(g,x,17,2,5,'#7ac05a');
    rect(g,11,1,10,4,'#a8743c');for(const x of [11,15,19])rect(g,x,0,2,2,'#a8743c');rect(g,15,2,2,2,'#ffd23f');
    for(const [x,y] of [[5,10],[27,10],[20,14]]){ell(g,x,y,2,1,'#9a5ab8');px(g,x,y+2,'#f6e3c4');}
    rect(g,9,20,14,9,'#f6e3c4');rect(g,22,20,1,9,'#d9bf98');rect(g,12,22,2,2,O);rect(g,18,22,2,2,O);rect(g,11,25,10,5,'#e8e0d0');rect(g,13,29,6,2,'#e8e0d0');rect(g,8,29,5,3,'#7a4a2a');rect(g,19,29,5,3,'#7a4a2a');});
  SP.brute=S(16,16,g=>{cap(g,{c:'#2a3e74',l:'#4a6ab0',d:'#1a2850',cy:5,rx:7,ry:4});rect(g,5,2,6,4,'#9aa4b4');rect(g,5,2,6,1,'#d6dce6');rect(g,0,5,4,4,'#9aa4b4');rect(g,12,5,4,4,'#9aa4b4');
    face(g,{y:8,w:8});rect(g,5,9,2,1,O);rect(g,9,9,2,1,O);rect(g,0,10,3,4,'#9aa4b4');rect(g,13,10,3,4,'#9aa4b4');});
  // ---- card icon: teleport (blue-violet rune ring with a star) ----
  SP.ic.teleport=makeSprite(16,16,g=>{ell(g,8,8,7,7,'#3a2a7a');ell(g,8,8,5,5,'#7a5ae0');ell(g,8,8,3,3,'#1a1440');rect(g,7,3,2,10,'#d8ccff');rect(g,3,7,10,2,'#d8ccff');px(g,8,8,'#fff');rect(g,2,2,2,2,'#7df9ff');rect(g,12,12,2,2,'#7df9ff');});
})();
