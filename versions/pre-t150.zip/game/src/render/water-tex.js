/* =====================================================================
   t143u / t144u WATER TEXTURES: water was one flat blue with 3 stripes. Now:
   - 4 variants x 4 animation frames: depth shading, soft caustic light bands, little wave crests that drift, the odd sparkle
   - DEEP water (no land within 2 tiles) is a shade darker and calmer
   - SHORE FOAM: animated white lapping dashes along every edge that touches land (on top of the existing shallow-edge blend)
   - MIREWOOD BOG water is its own murky green-brown with drifting scum, rising bubbles and lily pads
   ===================================================================== */
const WTEX=(()=>{
  const r=(g,x,y,w,h,c)=>rect(g,x,y,w,h,c);
  const PAL={
    ow:  {base:'#3876cc',deep:'#2c62b4',lo:'#2a5aa8',hi:'#7ab8f2',hi2:'#a8d6ff',spark:'#ffffff'},
    deep:{base:'#2c62b4',deep:'#24549e',lo:'#204a90',hi:'#5a98dc',hi2:'#86bcf0',spark:'#e8f4ff'},
    bog: {base:'#22382e',deep:'#1a2e26',lo:'#14241e',hi:'#4a6a44',hi2:'#7a9a5a',spark:'#c8e0a0'},
  };
  const C=new Map();
  function frame(kind,v,f){const k=kind+v+f;let s=C.get(k);if(s)return s;const p=PAL[kind],rnd=mulberry32(97+v*13+(kind==='bog'?500:kind==='deep'?250:0));
    s=makeSprite(16,16,g=>{r(g,0,0,16,16,p.base);
      for(let i=0;i<6;i++){const x=Math.floor(rnd()*16),y=Math.floor(rnd()*16);r(g,x,y,2+Math.floor(rnd()*3),1,p.deep);}          // mottled depth
      if(kind==='bog'){
        for(let i=0;i<3;i++){const x=Math.floor((rnd()*16+f*.8+i*5))%16,y=Math.floor(rnd()*14);r(g,x,y,3,2,p.hi);r(g,x+1,y,1,1,p.hi2);}   // drifting scum
        const by=14-((f*4+v*3)%14);r(g,(v*5+3)%14,by,1,1,p.spark);if(f%2)r(g,(v*7+9)%14,(by+6)%14,1,1,p.hi2);                         // bubbles
        if(v===2){ell(g,10,5,3,2,'#4a7a2a');r(g,10,4,2,1,'#6aa03a');r(g,12,5,1,1,p.base);}                                            // lily pad
      }else{
        for(let i=0;i<2;i++){const y=(i*8+f*2+v*3)%16;for(let x=0;x<16;x++){if(((x+y+i*3)&7)<3)r(g,x,(y+Math.round(Math.sin((x+f)/2.5)))&15,1,1,p.hi);}}   // caustic bands
        for(let i=0;i<2;i++){const x=(i*7+f*2+v*4)%13,y=(i*7+v*5+f)%14;r(g,x,y,3,1,p.hi2);r(g,x+1,y-1<0?0:y-1,1,1,p.hi2);r(g,x+3,y+1,2,1,p.lo);}   // wave crests
        if((f+v)%4===0)r(g,(v*5+f*3)%15,(v*3+f*5)%15,1,1,p.spark);                                                                    // sparkle
      }});
    C.set(k,s);return s;}
  const isWat=t=>t===T.W||t===T.U||t===T.PW||t===T.PR||t===T.BWK;
  const DEEP=new Map();
  function deep(x,y){const k=y*4096+x;let d=DEEP.get(k);if(d!=null)return d;d=true;
    for(let j=-2;j<=2&&d;j++)for(let i=-2;i<=2;i++){const t=map[y+j]&&map[y+j][x+i];if(t!=null&&!isWat(t)){d=false;break;}}DEEP.set(k,d);if(DEEP.size>60000)DEEP.clear();return d;}
  function foam(base,x,y,f){let m=0;const n=(i,j)=>{const t=map[y+j]&&map[y+j][x+i];return t!=null&&!isWat(t);};
    if(n(0,-1))m|=1;if(n(1,0))m|=2;if(n(0,1))m|=4;if(n(-1,0))m|=8;if(!m)return base;
    const k='fo'+weBaseId(base)+'|'+m+'|'+f;let s=C.get(k);if(s)return s;
    s=makeSprite(16,16,g=>{g.drawImage(base,0,0);g.fillStyle='rgba(240,250,255,.85)';const ph=f*2;
      for(let i=0;i<16;i+=4){const a=(i+ph)%16;if(m&1)g.fillRect(a,0,2,1);if(m&4)g.fillRect(15-a,15,2,1);if(m&8)g.fillRect(0,a,1,2);if(m&2)g.fillRect(15,15-a,1,2);}
      g.fillStyle='rgba(240,250,255,.35)';for(let i=1;i<16;i+=5){const a=(i+ph+2)%16;if(m&1)g.fillRect(a,1,1,1);if(m&4)g.fillRect(a,14,1,1);if(m&8)g.fillRect(1,a,1,1);if(m&2)g.fillRect(14,a,1,1);}});
    C.set(k,s);return s;}
  function tile(id,x,y,time){
    if(id!==T.W)return null;const f=(Math.floor(time*2.2)+(x>>1)+(y>>1))&3,v=(hash2(x,y)>>>5)&3;
    const kind=zoneOfTy(y)==='swamp'?'bog':deep(x,y)?'deep':'ow';
    let s=weCompose(frame(kind,v,f),x,y,id);if(kind!=='bog')s=foam(s,x,y,f);return s;}
  return {tile,frame,PAL};
})();
{const _ts=tileSprite;tileSprite=function(id,x,y,time){if(id===T.W){const s=WTEX.tile(id,x,y,time);if(s)return s;}return _ts.apply(this,arguments);};}
TSPR.mini[T.W]=TSPR.mini[T.W]||'#3876cc';
