/* =====================================================================
   NEW REGIONS (Frosthowl Pass, Mirewood Bog, Sundered Ruins): tiles, monster + boss sprites, waystone. All code-drawn, original.
   ===================================================================== */
(function buildZoneArt(){
  const sp=(g,seed,cols,n)=>sprinkle(g,seed,cols,n);
  // ---- tiles ----
  TSPR[T.SN]=[1,2,3,4].map(s=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#e8f0fa');sp(g,s*5,['#d3e2f4','#fff','#c4d6ee'],16);}));
  TSPR[T.IC]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#a9d8f2');sp(g,v+60,['#d6f0ff','#8cc4e8','#fff'],14);rect(g,2+v*5,4,5,1,'#e8f8ff');rect(g,8,10,4,1,'#7ab4dc');}));
  TSPR[T.PN]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#e8f0fa');sp(g,v+70,['#d3e2f4'],8);rect(g,7,12,2,4,'#4a2c14');
    tri(g,8,1,2,13,14,13,'#1d5a3a');tri(g,8,4,3,11,13,11,'#2a7a4e');tri(g,8,1,5,6,11,6,'#e8f0fa');rect(g,4,9,3,1,'#e8f0fa');rect(g,9,11,3,1,'#e8f0fa');}));
  TSPR[T.RK]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#6a7284');for(let y=0;y<16;y+=5){rect(g,0,y+4,16,1,'#454c5e');rect(g,(y*3+v*5)%12,y,1,4,'#454c5e');}
    rect(g,0,0,16,2,'#e8f0fa');rect(g,2,2,5,1,'#e8f0fa');sp(g,v+80,['#8a92a4','#575e70'],10);}));
  TSPR[T.MD]=[1,2,3,4].map(s=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#5a6a3a');sp(g,s*9,['#4a5a2e','#6e7e46','#3e4c26','#7a8a50'],16);if(s===2){ell(g,8,9,4,2,'#3a4a5a');rect(g,6,8,2,1,'#6a8aa0');}}));
  TSPR[T.MR]=[0,1,2,3].map(f=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#2c4a3e');for(let i=0;i<3;i++){const y=(i*6+f*2)%16,x=(i*5+f*3)%12;rect(g,x,y,4,1,'#4a7a62');rect(g,x+5,(y+3)%16,3,1,'#1f362e');}rect(g,(f*5)%14,(f*7)%14,2,2,'#7a9a52');}));
  TSPR[T.RE]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#5a6a3a');sp(g,v+90,['#4a5a2e'],8);for(let i=0;i<5;i++){rect(g,2+i*3,4+(i+v)%3*2,1,11,'#8a9a4a');rect(g,2+i*3,3+(i+v)%3*2,2,3,'#6a4a2a');}}));
  TSPR[T.SD]=[1,2,3,4].map(s=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#e2c27a');sp(g,s*7,['#d4b062','#efd496','#c9a458'],18);if(s===3){rect(g,3,10,5,1,'#c9a458');rect(g,4,9,3,1,'#c9a458');}}));
  TSPR[T.SR]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#c4a066');for(let y=0;y<16;y+=4){rect(g,0,y+3,16,1,'#8e6e3c');const off=(y/4+v)%2?0:5;for(let x=off;x<16;x+=10)rect(g,x,y,1,3,'#8e6e3c');}rect(g,0,0,16,1,'#e6c88a');sp(g,v+100,['#b08a52','#d8b878'],9);
    if(v){rect(g,5,5,6,1,'#7a5a2c');rect(g,7,4,2,4,'#7a5a2c');}}));
  TSPR[T.SC]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#e2c27a');rect(g,2,12,12,3,'#8e6e3c');rect(g,3,11,10,2,'#d4b078');rect(g,4,1,8,11,'#b08a52');rect(g,5,1,6,11,'#dcc08a');rect(g,6,1,2,11,'#f2e0b0');rect(g,3,0,10,2,'#ecd29a');rect(g,3,0,10,1,'#fff6d8');rect(g,6,5,4,1,'#8e6e3c');rect(g,6,8,4,1,'#8e6e3c');}));
  TSPR[T.RU]=[0,1,2,3].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#cdb07a');rect(g,0,0,8,8,'#d6ba86');rect(g,8,8,8,8,'#d6ba86');rect(g,0,0,16,1,'#e6d0a0');rect(g,8,0,1,16,'#a88a56');rect(g,0,8,16,1,'#a88a56');sp(g,v+110,['#b89a62','#e2c890'],8);
    if(v===2){rect(g,4,5,2,2,'#e2c27a');rect(g,10,10,3,1,'#a88a56');}}));
  TSPR[T.CV]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3a3446');rect(g,0,0,8,8,'#413b50');rect(g,8,8,8,8,'#413b50');sp(g,v+120,['#2e2a3a','#4e4860'],10);if(v)rect(g,5,9,2,2,'#7dffa0');}));
  TSPR[T.GT]=[0,1,2,3].map(f=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#2a2640');for(let i=0;i<6;i++){rect(g,0,i*3,16,3,i%2?'#4a465e':'#35314a');}
    rect(g,3,0,10,16,'#120e24');rect(g,5,2,6,12,'#2a1a5a');ell(g,8,8,2+(f%2),4,'#7dd0ff');rect(g,7,6,2,4,'#fff');rect(g,3,0,10,1,'#8a86a8');}));
  TSPR[T.GX]=[0,1,2,3].map(f=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#35314a');rect(g,2,2,12,12,'#120e24');ell(g,8,8,3+(f%2),5,'#ffe9a0');rect(g,7,6,2,4,'#fff');rect(g,2,2,12,1,'#8a86a8');}));
  TSPR[T.GB]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#6a7284');for(let y=0;y<16;y+=5){rect(g,0,y+4,16,1,'#454c5e');}
    rect(g,0,0,16,16,'rgba(40,30,20,.18)');g.fillStyle='#1a1420';for(const [x,y] of [[7,0],[7,2],[8,3],[8,5],[7,6],[6,8],[7,10],[8,11],[8,13],[7,15]])g.fillRect(x,y,1,2);rect(g,3,4,2,1,'#1a1420');rect(g,11,9,2,1,'#1a1420');}));
  TSPR[T.CH]=[0,1].map(o=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3a3446');rect(g,2,7,12,8,'#6b4423');rect(g,2,7,12,2,'#8a5a2c');rect(g,2,5,12,3,o?'#a87a42':'#8a5a2c');rect(g,2,9,12,1,'#e0b841');rect(g,7,9,2,3,'#ffd23f');
    if(o){rect(g,3,3,10,2,'#ffe9a0');rect(g,5,1,6,2,'#fff6c0');}}));
  Object.assign(TSPR.mini,{[T.SN]:'#e8f0fa',[T.IC]:'#a9d8f2',[T.PN]:'#2a7a4e',[T.RK]:'#6a7284',[T.MD]:'#5a6a3a',[T.MR]:'#2c4a3e',[T.RE]:'#8a9a4a',[T.SD]:'#e2c27a',[T.SR]:'#c4a066',[T.SC]:'#e6c88a',[T.RU]:'#cdb07a',[T.CV]:'#3a3446',[T.GT]:'#7dd0ff',[T.GX]:'#ffe9a0',[T.GB]:'#6a7284',[T.CH]:'#ffd23f'});
  // ---- monsters (16x16, drawn 2x) ----
  const mk=(rows,pal,ol)=>{const s=fromMap(rows,pal);autoOutline(s,ol||'#141018');return s;};
  SP.wolf=mk(['................','................','...g..........g.','..ggg........ggg','..gwgggggggggwg.','..gwwgggggggwwg.','.gggwgwgggwgwggg','.gggggggggggggg.','..ggwwwwwwwwggg.','..gwwwwwwwwwwgg.','..gww.gg..gg.wg.','..gg..gg..gg.gg.','..bb..bb..bb.bb.','................','................','................'],
    {g:'#8aa0b8',w:'#dfe8f4',b:'#4a5a6e'});
  SP.yeti=mk(['....wwwwwwww....','...wwwwwwwwww...','..wwwwwwwwwwww..','..wwbbwwwwbbww..','..wwbebwwbebww..','..wwbbbmmbbbww..','..wwwwmmmmwwww..','.wwwwwwwwwwwwww.','wwwwwwwwwwwwwwww','wwwiwwwwwwwwiwww','wwwiwwwwwwwwiwww','wwwwwwwwwwwwwwww','.wwwwwwwwwwwwww.','..wwwwwiiwwwwww.','..bbbb....bbbb..','..bbbb....bbbb..'],
    {w:'#e6eef8',i:'#b4c8e0',b:'#6fa8d8',e:'#fff',m:'#3a4a68'});
  SP.toad=mk(['................','................','...ee....ee.....','..eyye..eyye....','..eyye..eyye....','.gggggggggggggg.','ggggggwgggwggggg','gggggggggggggggg','gddgggggggggggdg','gddgggwwwwgggddg','.gggggwwwwgggggg','.gg.dgggggg.dggg','.gg..gg..gg..gg.','.bb..bb..bb..bb.','................','................'],
    {g:'#5a9a3a',d:'#3a6a26',e:'#7ab84a',y:'#ffd23f',w:'#d8e8a0',b:'#2a4a1a'});
  SP.witch=mk(['.......hh.......','......hhhh......','.....hhhhhh.....','....hhhhhhhh....','..hhhhhhhhhhhh..','..ppppppppppp...','...pgggggggp....','...pgeggegp.....','...pgggmggp.....','...ppgggggpp.s..','..pppppppppps...','..ppppvvpppps...','.ppppppvvppps...','.pppppppppppps..','.pppppppppppps..','..pppppppppp.s..'],
    {h:'#3a2a5a',p:'#5a3a8a',g:'#7ac060',e:'#ffe14d',m:'#3a1a2a',v:'#8a62c0',s:'#6b4423'});
  SP.scorpion=mk(['..........tttt....','.........tttttt..','.........ttkktt..','..........tkkt...','.........ttk.....','...cc....ttt.....','..cccc.bbbbbb....','.cc..cbbbbbbbb...','cc...bbxbbbbxbb..','c....bbbbbbbbbb..','.....bbbbbbbbb...','.....bbbbbbbbb...','....l.l.l.l.l.l..','...l..l.l.l..l...','................','................'],
    {t:'#c0782a',k:'#8a4a14',c:'#d49040',b:'#b8742c',x:'#ff4a2a',l:'#7a4a1a'});
  SP.mummy=mk(['.....wwwwww.....','....wwwwwwww....','....wbwwwwbw....','....wweewweew...','....wwwwwwww....','...wwbwwwwbww...','..wwwwwbbwwwww..','.wwwbwwwwwwbwww.','.wwwwwwwwwwwwww.','.wbwwwbbbwwwwbw.','.wwwwwwwwwwwwww.','..wwbwwwwwbwww..','..wwwwwwwwwwww..','..wwbwwwwwwbww..','..wwww....wwww..','..bbbb....bbbb..'],
    {w:'#d8c89a',b:'#a8946a',e:'#ffd23f'});
  SP.boar=mk(['................','................','.........dd.dd..','.......ddddddd..','...bbbdddddddd..','..bbbbbdddddbbb.','.pbbbbbbbbbbbbb.','ppbebbbbbbbbbbbb','pppbbbbbbbbbbbbb','wwpbbbbbbbbbbbb.','.wbbbbbbbbbbbbb.','..bbbbbbbbbbbb..','..bb.bb..bb.bb..','..hh.hh..hh.hh..','................','................'],
    {b:'#8a5a34',d:'#5e3a20',p:'#d8a07a',w:'#fff2d0',e:'#14101a',h:'#3a2412'});
  SP.scarecrow=mk(['.....hhhhhh.....','....hhhhhhhh....','..hhhhhhhhhhhh..','.....ssssss.....','....sseessee....','....ssssmmss....','.....ssssss.....','sswwwwccccwwwwss','.sscccpccccss...','..wwccccccccww..','....ccccpccc....','.....cccccc.....','.....tt..tt.....','.....tt..tt.....','.....ww..ww.....','................'],
    {h:'#6b4a2a',s:'#e8c860',e:'#2a1a10',m:'#7a3a20',c:'#b8503a',p:'#4a7ab8',t:'#4a5a8a',w:'#9a7a3a'});
  // ---- bosses (32x32 drawn 2x) ----
  SP.rimegar=autoOutline(makeSprite(32,32,g=>{
    const ice='#8cd0f0',iceD='#4a8cc0',iceL='#dff4ff',fur='#e6eef8';
    rect(g,6,12,20,18,iceD);rect(g,8,12,16,17,ice);rect(g,10,13,12,5,iceL);rect(g,4,16,5,12,ice);rect(g,23,16,5,12,ice);rect(g,3,26,6,4,iceL);rect(g,23,26,6,4,iceL);
    ell(g,16,9,7,7,ice);rect(g,9,8,14,5,iceL);tri(g,9,6,6,0,12,5,iceL);tri(g,23,6,26,0,20,5,iceL);tri(g,13,4,16,-3,19,4,iceL);
    rect(g,11,8,3,3,'#102a4a');rect(g,18,8,3,3,'#102a4a');rect(g,12,9,1,1,'#7df9ff');rect(g,19,9,1,1,'#7df9ff');rect(g,13,13,6,2,'#102a4a');rect(g,14,13,1,2,'#fff');rect(g,17,13,1,2,'#fff');
    rect(g,8,22,16,2,fur);rect(g,10,24,12,6,fur);rect(g,12,28,3,3,iceD);rect(g,18,28,3,3,iceD);
  }),'#0a1830');
  SP.mossback=autoOutline(makeSprite(32,32,g=>{
    const m='#4a7a3a',mD='#2a4a22',mL='#7aae52',bel='#c8c070';
    ell(g,16,22,13,9,mD);ell(g,16,21,12,8,m);ell(g,16,25,8,5,bel);for(const [x,y] of [[8,18],[14,15],[21,17],[25,21],[11,23]])ell(g,x,y,2,2,mL);
    for(const [nx,hx,hy] of [[8,6,6],[16,16,3],[24,26,6]]){rect(g,nx-1,hy+4,3,13,m);ell(g,hx,hy+1,4,3,m);rect(g,hx-2,hy,2,2,'#ffd23f');rect(g,hx+1,hy,2,2,'#ffd23f');rect(g,hx-1,hy+3,3,1,'#a02020');}
    rect(g,4,28,6,3,mD);rect(g,22,28,6,3,mD);
  }),'#0e1808');
  SP.colossus=autoOutline(makeSprite(32,32,g=>{
    const s='#c4a066',sD='#8e6e3c',sL='#ecd29a';
    rect(g,8,10,16,18,sD);rect(g,9,10,14,17,s);rect(g,11,11,10,5,sL);rect(g,2,12,7,15,s);rect(g,23,12,7,15,s);rect(g,1,24,8,6,sD);rect(g,23,24,8,6,sD);rect(g,2,24,6,5,sL);rect(g,24,24,6,5,sL);
    rect(g,10,3,12,9,s);rect(g,10,2,12,2,sL);rect(g,12,5,3,3,'#1a0e00');rect(g,17,5,3,3,'#1a0e00');rect(g,13,6,1,1,'#ffb02e');rect(g,18,6,1,1,'#ffb02e');rect(g,13,9,6,1,sD);
    rect(g,13,16,6,6,'#1a0e00');rect(g,14,17,4,4,'#ffb02e');rect(g,15,18,2,2,'#fff6c0');rect(g,11,27,4,4,sD);rect(g,17,27,4,4,sD);
    for(let i=0;i<4;i++)rect(g,8+i*5,22+(i%2),3,1,sD);
  }),'#1a0e00');
  SP.waystone=autoOutline(makeSprite(16,16,g=>{rect(g,3,13,10,3,'#4a465e');tri(g,8,0,3,14,13,14,'#6a7284');tri(g,8,2,5,13,11,13,'#8a92a4');rect(g,7,6,2,5,'#7df9ff');rect(g,6,8,4,1,'#7df9ff');rect(g,7,4,2,1,'#fff');}),'#14121e');
  SP.waystoneOff=autoOutline(makeSprite(16,16,g=>{rect(g,3,13,10,3,'#3c3a46');tri(g,8,0,3,14,13,14,'#58566a');tri(g,8,2,5,13,11,13,'#6c6a7e');rect(g,7,6,2,5,'#34324a');rect(g,6,8,4,1,'#34324a');rect(g,7,4,2,1,'#74728a');}),'#14121e');   // dormant stone: grey, dark rune
})();
