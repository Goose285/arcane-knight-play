/* ---------- water / land edge blending (rivers, ponds, pools, swamp, oasis) ----------
   Like the gravel path edges: the land next to water gets a soft, irregular dirt + pebble bank with a few small rocks,
   and the water next to land gets a shallow band (light turquoise at the shore, then a darker band for the depth change).
   Pure sprite compositing on the 16px tile, cached per (base tile, neighbour mask, variant); no per-frame cost beyond a lookup.
   The village pond has its own round stone rim and is left alone. */
const WE_LAND=new Set([T.G,T.K,T.SN,T.MD,T.SD]),WE_WATER=new Set([T.W,T.U]);
const WE_DIRS=[[0,-1],[1,0],[0,1],[-1,0],[1,-1],[1,1],[-1,1],[-1,-1]];   // N E S W NE SE SW NW  -> bits 1,2,4,...
let WE_MASK=null;const WE_CACHE=new Map();let WE_BASEID=1;
function weBuild(){
  WE_MASK=new Uint8Array(MW*MH);
  for(let y=0;y<MH;y++)for(let x=0;x<MW;x++){
    const id=map[y][x],wt=WE_WATER.has(id),lt=!wt&&WE_LAND.has(id);if(!wt&&!lt)continue;
    let m=0;
    for(let i=0;i<8;i++){const nx=x+WE_DIRS[i][0],ny=y+WE_DIRS[i][1];if(nx<0||ny<0||nx>=MW||ny>=MH)continue;
      const n=map[ny][nx];if(wt?WE_LAND.has(n):WE_WATER.has(n))m|=1<<i;}
    WE_MASK[y*MW+x]=m;
  }
}
function weMask(x,y){if(!WE_MASK)weBuild();return WE_MASK[y*MW+x];}
const WE_PAL={   // [wet, dirt, light, fringe, pebbles[]]
  g:['#5b4430','#7c5f3b','#98784a','#6f6a3c',['#b9b5a6','#8d8a7d','#d2cdbd']],
  k:['#4a3a2a','#66503a','#80653f','#4f5a34',['#a7a396','#7a776c','#c4bfb0']],
  s:['#7c6a48','#a08658','#bda070','#a89a62',['#d4cdb8','#a89f88','#e6dfca']],
  m:['#3d2f22','#55412e','#6d543a','#4a4a2c',['#8e8a7a','#66635a','#a8a496']],
  n:['#6c6558','#8c8576','#a8a192','#9aa09a',['#cfd0cc','#a3a29a','#e8e8e4']],
};
function wePalOf(id){return id===T.K?WE_PAL.k:id===T.SD?WE_PAL.s:id===T.MD?WE_PAL.m:id===T.SN?WE_PAL.n:WE_PAL.g;}
function weH(a,b,c){let h=Math.imul(a+1,374761393)^Math.imul(b+7,668265263)^Math.imul(c+13,2246822519);h=Math.imul(h^h>>>13,1274126177);return((h^h>>>16)>>>0)/4294967296;}
// edge width at position t (0..15) along a tile side: fixed at both ends so neighbouring tiles join up, wobbly between
function weWidth(v,dir,t,base,amp){
  const k=t/4,i=Math.floor(k),f=k-i,a=weH(v,dir,i)*2-1,b=weH(v,dir,i+1)*2-1,s=a+(b-a)*(f*f*(3-2*f));
  return base+amp*s*Math.sin(Math.PI*t/15);
}
// signed "inside" depth of pixel (x,y) for the given neighbour mask; >0 means inside the strip. returns [q, d] (q: depth from strip outer edge, d: distance to water side)
function weDepth(mask,v,x,y,base,amp){
  let best=-99,dmin=99;const px=x+.5,py=y+.5;
  const side=[py,16-px,16-py,px];   // N E S W distances to the tile sides
  for(let i=0;i<4;i++){if(!(mask>>i&1))continue;const d=side[i],t=(i&1)?y:x,w=weWidth(v,i,t,base,amp),q=w-d;if(q>best){best=q;dmin=Math.min(dmin,d);}}
  for(let i=4;i<8;i++){if(!(mask>>i&1))continue;
    if(mask>>(i-4)&1||mask>>((i-3)&3)&1)continue;   // a straight side already covers this corner
    const cx=(i===4||i===5)?16:0,cy=(i===4||i===7)?0:16,d=Math.hypot(px-cx,py-cy),w=base*.9+amp*.5*(weH(v,i,0)*2-1),q=w-d;if(q>best){best=q;dmin=Math.min(dmin,d);}}
  return [best,dmin];
}
function weBank(base,mask,id,v){
  const P=wePalOf(id),sp=document.createElement('canvas');sp.width=sp.height=16;const g=sp.getContext('2d');
  const put=(x,y,c)=>{if(x<0||y<0||x>15||y>15)return;g.fillStyle=c;g.fillRect(x,y,1,1);};
  g.drawImage(base,0,0);
  if(id===T.SD){   // BEACH: sand darkens smoothly into wet sand with a line of foam - no dirt, pebbles or rocks
    for(let y=0;y<16;y++)for(let x=0;x<16;x++){
      const [q]=weDepth(mask,v,x,y,5.2,2.3);if(q<=.6)continue;const r=weH(x,y,v+31);
      if(q<1.6){if(r<(q-.6))put(x,y,'#e2c98f');continue;}
      if(q<3.0){put(x,y,r<.85?'#d2b57a':'#e2c98f');continue;}
      if(q<4.3){put(x,y,r<.88?'#b8995e':'#c9aa70');continue;}
      put(x,y,r<.55?'#eef6ff':r<.8?'#c8e4f0':'#b8995e');                       // foam at the waterline
    }
    return sp;
  }
  const ov=document.createElement('canvas');ov.width=ov.height=16;const o=ov.getContext('2d');
  const op=(x,y,c)=>{if(x<0||y<0||x>15||y>15)return;o.fillStyle=c;o.fillRect(x,y,1,1);};
  for(let y=0;y<16;y++)for(let x=0;x<16;x++){
    const [q]=weDepth(mask,v,x,y,5.2,2.3);if(q<=0)continue;
    const r=weH(x,y,v+31);
    if(q<.9){if(r<.45+q*.4)op(x,y,r<.2?P[3]:P[2]);continue;}                 // ragged fringe: dithered into the grass
    if(q<1.9){op(x,y,r<.78?P[2]:P[1]);continue;}                              // light dirt
    if(q<3.6){op(x,y,r<.82?P[1]:P[2]);continue;}                              // dirt
    op(x,y,r<.85?P[0]:P[1]);                                                  // wet dark soil at the waterline
  }
  // pebbles
  for(let y=0;y<16;y++)for(let x=0;x<16;x++){
    const [q]=weDepth(mask,v,x,y,5.2,2.3);if(q<1.1||q>4.4)continue;
    const r=weH(x,y,v+77);if(r<.085){const c=P[4][Math.floor(r*P[4].length*11.7)%3];op(x,y,c);if(r<.03)op(x+1,y,P[4][1]);}
  }
  // a few small rocks that sit on the bank edge (0..2 per tile)
  const nr=(weH(v,mask,5)<.3?0:weH(v,mask,6)<.5?1:2);
  for(let k=0,tries=0;k<nr&&tries<14;tries++){
    const rx=1+Math.floor(weH(v,k+tries,21)*12),ry=1+Math.floor(weH(v,k+tries,22)*13),[q]=weDepth(mask,v,rx,ry,5.2,2.3);
    if(q<1.2||q>4.2)continue;k++;
    const big=weH(rx,ry,v)<.35;
    o.fillStyle='rgba(30,22,16,.55)';o.fillRect(rx,ry+(big?2:1),(big?4:3),1);                 // contact shadow
    o.fillStyle='#8f8c80';o.fillRect(rx,ry,big?3:2,big?2:1);o.fillStyle='#a9a598';o.fillRect(rx,ry,big?2:1,1);
    o.fillStyle='#6a675d';o.fillRect(rx+(big?2:1),ry+(big?1:0),1,1);
  }
  g.drawImage(ov,0,0);return sp;
}
function weShallow(base,mask){
  const sp=document.createElement('canvas');sp.width=sp.height=16;const g=sp.getContext('2d');g.drawImage(base,0,0);
  for(let y=0;y<16;y++)for(let x=0;x<16;x++){
    const [q,d]=weDepth(mask,0,x,y,6.2,0);if(q<=0)continue;
    // d: distance from the bank. 0-1.6 light turquoise shallows, then a darker band marking the drop-off
    if(d<1.6)g.fillStyle=((x+y)&1&&d>.9)?'rgba(150,235,220,.22)':'rgba(150,235,225,.38)';
    else if(d<3.4)g.fillStyle='rgba(6,52,70,.38)';
    else if(d<5)g.fillStyle=((x+y)&1)?'rgba(6,36,76,.20)':'rgba(6,36,76,.12)';
    else g.fillStyle='rgba(6,36,76,.07)';
    g.fillRect(x,y,1,1);
  }
  return sp;
}
function weBaseId(b){if(!b._we)b._we=WE_BASEID++;return b._we;}
// compose: returns the base sprite untouched when there is no water/land boundary on any side
function weCompose(base,x,y,id){
  const m=weMask(x,y);if(!m)return base;
  const wt=WE_WATER.has(id),v=hash2(x,y)&3,key=weBaseId(base)+'|'+m+'|'+(wt?0:v);
  let r=WE_CACHE.get(key);if(r)return r;
  r=wt?weShallow(base,m):weBank(base,m,id,v);WE_CACHE.set(key,r);return r;
}
