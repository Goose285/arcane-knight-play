/* =====================================================================
   THE NEW OAKVALE CHURCH (after Seth's reference): cream stone, blue slate roof, a bell tower with a gold-tipped cross over the
   nave, three arched stained-glass windows behind the altar, altar candles, a red carpet, two rows of three pews, an arched oak
   door with iron straps, lanterns either side of it and ivy climbing the walls. Replaces the little roof cross.
   ===================================================================== */
Object.assign(T,{CWL:86});SOLID.add(T.CWL);
/* THIN church walls (t135u): one tile id; the look depends on where it sits in the chapel - a 4px cream wall strip with pilasters on the
   outer side(s), the nave floor (with its diamond border) filling the rest, so the hall reads wide with slim walls */
const CW_CACHE={};
function chapelWallTile(x,y){
  const C=CHAPEL,L=x===C.x0,R=x===C.x1,Bm=y===C.y1,k=(L?1:0)|(R?2:0)|(Bm?4:0)|((y+x)%2?8:0);if(CW_CACHE[k])return CW_CACHE[k];
  return CW_CACHE[k]=makeSprite(16,16,g=>{
    const fl=TSPR[T.CHF][0];g.drawImage(fl,0,0);
    for(let i=1;i<16;i+=4){if(!L&&!R){}else{rect(g,L?5:9,i,2,2,'#d9c79a');}}           // diamond border inside the wall
    const ST='#e6dcc0',STL='#f6eedb',STD='#b8ab8a',O='#14182c';
    if(L){rect(g,0,0,4,16,ST);rect(g,0,0,1,16,O);rect(g,3,0,1,16,STD);rect(g,1,0,1,16,STL);if((y%2)===0){rect(g,0,4,6,6,ST);rect(g,5,4,1,6,STD);rect(g,0,4,6,1,STL);}rect(g,4,0,1,16,'rgba(40,30,10,.25)');}
    if(R){rect(g,12,0,4,16,ST);rect(g,15,0,1,16,O);rect(g,12,0,1,16,STD);rect(g,14,0,1,16,STL);if((y%2)===0){rect(g,10,4,6,6,ST);rect(g,10,4,1,6,STD);rect(g,10,4,6,1,STL);}rect(g,11,0,1,16,'rgba(40,30,10,.25)');}
    if(Bm){rect(g,0,10,16,6,ST);rect(g,0,10,16,1,STL);rect(g,0,15,16,1,O);for(let xx=(x%2)*4;xx<16;xx+=8)rect(g,xx,12,1,3,STD);rect(g,0,13,16,1,STD);rect(g,0,9,16,1,'rgba(40,30,10,.25)');
      if(L)rect(g,0,8,6,8,ST),rect(g,0,8,6,1,STL),rect(g,0,8,1,8,O);if(R)rect(g,10,8,6,8,ST),rect(g,10,8,6,1,STL),rect(g,15,8,1,8,O);}
  });
}
(function buildChurch2(){
  const ST='#e6dcc0',STL='#f6eedb',STD='#b8ab8a',SL='#3c5a8a',SLL='#6a8cc0',SLD='#22385e';
  SP.bellTower=autoOutline(makeSprite(24,44,g=>{
    // cross
    rect(g,11,0,2,9,'#f0d870');rect(g,8,3,8,2,'#f0d870');rect(g,11,0,1,9,'#fff3b0');
    // pyramid slate spire
    for(let i=0;i<10;i++){const w=4+i*2;rect(g,12-w/2,9+i,w,1,i%3===2?SLD:SL);rect(g,12-w/2,9+i,1,1,SLL);}
    rect(g,1,19,22,2,SLD);rect(g,1,19,22,1,SLL);
    // belfry: cream stone with an arched opening and the bell
    rect(g,3,21,18,23,ST);rect(g,3,21,1,23,STL);rect(g,20,21,1,23,STD);
    for(let y=24;y<44;y+=4){rect(g,3,y,18,1,STD);const o=(y/4)%2?4:9;for(let x=o;x<20;x+=9)rect(g,x,y-3,1,3,STD);}
    rect(g,8,24,8,10,'#2a2438');rect(g,9,23,6,1,'#2a2438');rect(g,10,22,4,1,STD);
    ell(g,12,29,3,3,'#d9a83a');rect(g,9,30,6,2,'#d9a83a');rect(g,10,27,2,2,'#ffe48a');rect(g,11,32,2,1,'#7a5a1a');
    rect(g,7,34,10,1,STD);rect(g,7,35,10,1,STL);
    // round window below
    ell(g,12,39,2,2,'#4a7ae2');rect(g,12,37,1,5,'#2a2438');rect(g,10,39,5,1,'#2a2438');
  }),'#14182c');
  SP.chDoor=autoOutline(makeSprite(16,16,g=>{
    rect(g,2,4,12,12,'#6a3f1e');rect(g,3,2,10,2,'#6a3f1e');rect(g,5,1,6,1,'#6a3f1e');
    rect(g,2,4,12,1,'#8a5a2c');rect(g,7,2,2,14,'#4a2a12');
    rect(g,2,7,12,1,'#3a3a44');rect(g,2,12,12,1,'#3a3a44');rect(g,9,9,1,2,'#d9b84a');
    rect(g,1,1,1,15,STD);rect(g,14,1,1,15,STD);rect(g,4,0,8,1,STD);
  }),'#14182c');
  SP.chLantern=autoOutline(makeSprite(8,14,g=>{rect(g,3,0,2,2,'#2a2a34');rect(g,1,2,6,1,'#2a2a34');rect(g,1,3,6,7,'#2a2a34');rect(g,2,4,4,5,'#ffd86a');rect(g,3,5,2,3,'#fff6c8');rect(g,1,10,6,1,'#2a2a34');rect(g,3,11,2,3,'#2a2a34');}),'#14182c');
  SP.chIvy=[0,1,2].map(v=>makeSprite(16,16,g=>{const r=mulberry32(77+v);for(let i=0;i<26;i++){const x=Math.floor(r()*14),y=Math.floor(r()*16*(0.4+v*.2));rect(g,x,y,2,2,r()<.5?'#3a7a3a':'#5aa04a');if(r()<.3)rect(g,x,y,1,1,'#8ad070');}
    for(let y=0;y<12+v*2;y++)rect(g,7+Math.round(Math.sin(y*.7+v)*2),y,1,1,'#2a5a2a');}));
  TSPR[T.CWL]=[makeSprite(16,16,g=>{g.drawImage(TSPR[T.CHF][0],0,0);rect(g,0,0,4,16,ST);rect(g,1,0,1,16,STL);rect(g,3,0,1,16,STD);})];TSPR.mini[T.CWL]=ST;
  SP.chWinBig=autoOutline(makeSprite(16,22,g=>{rect(g,2,4,12,18,'#2a2438');ell(g,8,5,6,5,'#2a2438');rect(g,3,5,10,16,'#e24a4a');ell(g,8,6,5,4,'#4a7ae2');rect(g,3,10,5,5,'#4a7ae2');rect(g,8,10,5,5,'#f0c53a');rect(g,3,15,5,6,'#4ae28a');rect(g,8,15,5,6,'#a24ae2');
    rect(g,7,6,2,14,'#f0d870');rect(g,4,9,8,2,'#f0d870');rect(g,7,6,1,14,'#fff3b0');rect(g,1,21,14,1,STD);}),'#14182c');
  SP.chSteps=makeSprite(16,10,g=>{rect(g,1,0,14,3,'#cfc4a4');rect(g,1,0,14,1,'#efe6cc');rect(g,0,3,16,3,'#c2b696');rect(g,0,3,16,1,'#e2d8bc');rect(g,0,6,16,3,'#b3a688');rect(g,0,6,16,1,'#d6cbae');rect(g,0,9,16,1,'#14182c');});
  SP.chFlowers=makeSprite(16,8,g=>{for(let i=0;i<6;i++){const x=1+i*2.5|0;rect(g,x,3+(i%2),2,2,'#3a7a3a');rect(g,x,2+(i%2),1,1,i%2?'#ffffff':'#ffe14d');}});
  SP.chCandle=makeSprite(4,8,g=>{rect(g,1,3,2,5,'#fffdf0');rect(g,1,7,2,1,'#c9c4b2');rect(g,1,0,2,2,'#ffb84a');rect(g,1,1,1,1,'#fff3b0');});
})();
/* tower stands on the ridge (replaces the old cross) */
let drawChapelCross=function(){
  const x=(CHAPEL.door+.5)*TS-cam.x,y=CHAPEL.y0*TS-cam.y+TS*1.2;
  draw(SP.bellTower,Math.round(x-24),Math.round(y-88),2);
  if(DAY&&typeof DAY.t==='number'){const r=Math.abs(((gtime*.05)%1)-.5)<.01;if(r){}}
}
let drawChurch2=function(){
  const cx=Math.round(cam.x),cy=Math.round(cam.y),C=CHAPEL;
  const x0=C.x0*TS-cx,y0=C.y0*TS-cy,w=(C.x1-C.x0+1)*TS,h=(C.y1-C.y0+1)*TS;
  if(x0>VW+40||y0>VH+40||x0+w<-40||y0+h<-40)return;
  // ivy on the corners of the walls
  draw(SP.chIvy[0],x0,y0+TS*2,2);draw(SP.chIvy[0],x0+w-TS,y0+TS*2,2);
  // altar candles (flicker)
  const ax=C.door*TS-cx,ay=(C.y0+3)*TS-cy;
  if(0)for(const dx of [2,24]){draw(SP.chCandle,ax+dx,ay-6,2);ctx.fillStyle=`rgba(255,200,90,${.18+.08*Math.sin(gtime*9+dx)})`;ctx.beginPath();ctx.arc(ax+dx+4,ay-4,9,0,6.283);ctx.fill();}
  // the big centre window over the altar
  {const wx=C.door*TS-cx,wy=(C.y0+2)*TS-cy;draw(SP.chWinBig,wx,wy-12,2);}
  // vines climbing the front corners + flowers at their feet, steps down from the door
  draw(SP.chIvy[2],x0-4,y0+h-TS*1.6,2);draw(SP.chIvy[1],x0+w-TS+4,y0+h-TS*1.6,2);draw(SP.chFlowers,x0,y0+h-6,2);draw(SP.chFlowers,x0+w-TS,y0+h-6,2);
  draw(SP.chSteps,C.door*TS-cx,(C.y1+1)*TS-cy,2);
  // arched door in the front wall + lanterns
  const dx=C.door*TS-cx,dy=C.y1*TS-cy;draw(SP.chDoor,dx,dy,2);
  for(const lx of [-1,1]){const px=dx+TS/2+lx*TS*1.1-8,py=dy-6;draw(SP.chLantern,px,py,2);
    const night=typeof DAY!=='undefined'&&(DAY.t<.27||DAY.t>.76);ctx.fillStyle=`rgba(255,214,110,${(night?.32:.12)+.05*Math.sin(gtime*4+lx)})`;ctx.beginPath();ctx.arc(px+8,py+12,night?22:12,0,6.283);ctx.fill();}
};
