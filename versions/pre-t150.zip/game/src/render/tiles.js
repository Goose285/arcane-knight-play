
/* =====================================================================
   TILES (16x16 art, drawn 2x)
   ===================================================================== */
const T={G:0,T:1,W:2,P:3,B:4,F:5,R:6,H:7,D:8,L:9,N:10,K:11,J:12,C:13,S:14,U:15,Z:16,RL:17,BT:18,CW:19,CF:20,CP:21,CK:22,CT:23,CS:24,CX:25,SN:26,IC:27,PN:28,RK:29,MD:30,MR:31,RE:32,SD:33,SR:34,SC:35,RU:36,CV:37,GT:38,GX:39,GB:40,CH:41,CO:42};
const SOLID=new Set([T.T,T.W,T.B,T.R,T.H,T.D,T.N,T.S,T.U,T.Z,T.RL,T.BT,T.CW,T.CP,T.CK,T.CT,T.PN,T.RK,T.MR,T.RE,T.SR,T.SC,T.GB,T.CH,T.CO]);
const TSPR={};
function sprinkle(g,seed,cols,n){const r=mulberry32(seed);for(let i=0;i<n;i++){g.fillStyle=cols[Math.floor(r()*cols.length)];g.fillRect(Math.floor(r()*16),Math.floor(r()*16),1,1);}}
/* M18 grass: layered - base, soft blotches of lighter / darker turf, dithered texture, little blade tufts, and (light grass only)
   the odd tiny wildflower. dark=true is the Whisperwood floor (cooler, no flowers). */
const GRASS_FLOWERS=['#ffffff','#ff8ab8','#ffd84a','#8ab4ff','#c890ff','#ff9a5a'];
function grassBase(seed,dark,flowers){return g=>{
  const r=mulberry32(seed*3+1);
  const base=dark?'#2c7344':'#5aaa45',lo=dark?'#256339':'#4f9a3c',hi=dark?'#35844f':'#68b94e',tf=dark?'#40965c':'#7ccc62',td=dark?'#1d5430':'#3d8530';
  rect(g,0,0,16,16,base);
  for(let k=0;k<3;k++){const bx=Math.floor(r()*12),by=Math.floor(r()*12),w=3+Math.floor(r()*4),h=2+Math.floor(r()*3);rect(g,bx,by,w,h,r()<.5?lo:hi);rect(g,bx+1,by-1<0?0:by-1,Math.max(1,w-2),1,r()<.5?lo:hi);}
  sprinkle(g,seed,dark?['#245f39','#368a52','#1f5430']:[lo,hi,'#4e9c3e','#7ccc62'],12);
  for(let k=0;k<2+(r()<.5?1:0);k++){const x=1+Math.floor(r()*13),y=3+Math.floor(r()*11);rect(g,x,y,1,2,k%2?td:tf);rect(g,x-1,y-1,1,1,k%2?td:tf);rect(g,x+1,y-2,1,2,k%2?td:tf);}
  if(!dark&&flowers){const n=1+(r()<.45?1:0)+(r()<.2?1:0);for(let k=0;k<n;k++){const x=1+Math.floor(r()*13),y=2+Math.floor(r()*11),c=GRASS_FLOWERS[Math.floor(r()*GRASS_FLOWERS.length)];
    rect(g,x,y+1,1,2,'#3f8a36');rect(g,x,y,1,1,c);if(r()<.5){rect(g,x-1,y,1,1,c);rect(g,x+1,y,1,1,c);rect(g,x,y-1,1,1,c);rect(g,x,y,1,1,'#ffe98a');}}}
};}
function buildTiles(){
  TSPR[T.G]=[1,2,3,4,5,6,7,8].map(s=>makeSprite(16,16,grassBase(s*7,false,s>2&&s%2===1)));
  TSPR[T.K]=[1,2,3,4,5,6].map(s=>makeSprite(16,16,grassBase(s*11,true)));
  TSPR[T.P]=[1,2,3,4,5,6].map(s=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#dcc18f');sprinkle(g,s*13,['#cfb07a','#e8d1a2','#c7a770','#eed8aa'],18);
    const r=mulberry32(s*5+2);rect(g,2+Math.floor(r()*10),3+Math.floor(r()*9),5,1,'#d0b27c');
    if(s>2){for(let k=0;k<(s>4?3:2);k++){const x=1+Math.floor(r()*13),y=2+Math.floor(r()*12);rect(g,x,y+1,2,1,'#a8906a');rect(g,x,y,2,1,'#b9a98c');rect(g,x,y,1,1,'#d8cdb4');}}}));
  TSPR[T.W]=[0,1,2,3].map(f=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3a7fd5');rect(g,0,0,16,16,'#3a7fd5');
    for(let i=0;i<3;i++){const y=(i*6+f*2)%16,x=(i*5+f*3)%12;rect(g,x,y,4,1,'#7db8f5');rect(g,x+5,(y+3)%16,3,1,'#2d68b8');}}));
  TSPR[T.U]=[0,1,2,3].map(f=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#4a98ea');
    for(let i=0;i<3;i++){const y=(i*5+f*3)%16;rect(g,(i*6+f*2)%12,y,5,1,'#b4e0ff');}
    rect(g,7,(f*3)%16,2,2,'#fff');rect(g,3+f,5,1,1,'#fff');rect(g,11-f,10,1,1,'#fff');}));
  TSPR[T.T]=[0,1,2,3].map(i=>{const dark=i>=2;return makeSprite(16,16,g=>{grassBase(i*5+1,dark)(g);
    rect(g,6,11,4,5,'#4a2c14');rect(g,7,11,2,5,'#6b4423');
    const c1=dark?'#143f26':'#1d6430',c2=dark?'#1d5a34':'#2f8d3d',c3=dark?'#2d7a46':'#5ab85a';
    ell(g,8,7,7,6,c1);ell(g,5,6,4,4,c2);ell(g,11,6,4,4,c2);ell(g,8,4,5,3,c2);
    rect(g,5,3,2,2,c3);rect(g,9,2,2,1,c3);rect(g,11,5,1,2,c3);
    sprinkle(g,i+77,[c1],5);});});
  TSPR[T.B]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#8a8d9c');for(let y=0;y<16;y+=4){rect(g,0,y+3,16,1,'#565a6b');const off=(y/4+v)%2?0:4;for(let x=off;x<16;x+=8)rect(g,x,y,1,3,'#565a6b');}
    rect(g,0,0,16,1,'#a9acba');sprinkle(g,v+5,['#7a7d8c','#9a9dac'],10);}));
  TSPR[T.BT]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#8a8d9c');rect(g,0,0,16,5,'#2a2a3a');rect(g,0,0,5,5,'#8a8d9c');rect(g,8,0,5,5,'#8a8d9c');rect(g,0,0,5,1,'#b4b7c4');rect(g,8,0,5,1,'#b4b7c4');
    for(let y=6;y<16;y+=4){rect(g,0,y+3,16,1,'#565a6b');rect(g,(y/4)%2?0:6,y,1,3,'#565a6b');}rect(g,0,5,16,1,'#565a6b');}));
  TSPR[T.F]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,v?'#a8a294':'#b9b4a6');rect(g,0,0,8,8,'#b9b4a6');rect(g,8,8,8,8,'#b9b4a6');rect(g,8,0,8,8,'#a8a294');rect(g,0,8,8,8,'#a8a294');
    rect(g,0,0,16,1,'#cdc8ba');rect(g,0,0,1,16,'#cdc8ba');rect(g,8,0,1,16,'#8e887a');rect(g,0,8,16,1,'#8e887a');sprinkle(g,v+3,['#9c968a','#c4bfb0'],6);}));
  TSPR[T.C]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#a8232f');rect(g,0,0,2,16,'#e0b43a');rect(g,14,0,2,16,'#e0b43a');rect(g,3,0,1,16,'#7c1822');rect(g,12,0,1,16,'#7c1822');for(let y=2;y<16;y+=8){rect(g,6,y,4,4,'#d04a58');rect(g,7,y+1,2,2,'#e0b43a');}}));
  TSPR[T.Z]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#b9b4a6');rect(g,2,12,12,3,'#6e6a60');rect(g,3,11,10,2,'#d8d4c6');rect(g,4,1,8,11,'#7c7a72');rect(g,5,1,6,11,'#d0cdc0');rect(g,6,1,2,11,'#f0eee4');rect(g,3,0,10,2,'#e4e0d2');rect(g,3,0,10,1,'#fff');}));
  TSPR[T.R]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#b8452f');for(let y=0;y<16;y+=4){rect(g,0,y+3,16,1,'#7a2a1b');const off=((y/4)+v)%2?0:4;for(let x=off;x<16;x+=8){rect(g,x,y,1,3,'#8c3220');}rect(g,0,y,16,1,'#d2644a');}}));
  TSPR[T.RL]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#b8452f');for(let y=0;y<12;y+=4){rect(g,0,y+3,16,1,'#7a2a1b');const off=((y/4)+v)%2?0:4;for(let x=off;x<16;x+=8)rect(g,x,y,1,3,'#8c3220');rect(g,0,y,16,1,'#d2644a');}rect(g,0,12,16,4,'#5a1f14');rect(g,0,12,16,1,'#8c3220');}));
  TSPR[T.H]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#ecdfc2');rect(g,0,0,2,16,'#6b4423');rect(g,14,0,2,16,'#6b4423');rect(g,0,0,16,2,'#6b4423');rect(g,0,14,16,2,'#7a7060');
    sprinkle(g,v+21,['#d9cba8','#f4e9d0'],8);
    if(v){rect(g,4,4,8,7,'#4a2c14');rect(g,5,5,6,5,'#8ccfff');rect(g,5,5,2,2,'#cdeaff');rect(g,8,5,1,5,'#4a2c14');rect(g,5,7,6,1,'#4a2c14');}}));
  TSPR[T.D]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#ecdfc2');rect(g,0,0,2,16,'#6b4423');rect(g,14,0,2,16,'#6b4423');rect(g,0,0,16,2,'#6b4423');
    rect(g,3,2,10,14,'#3a2410');rect(g,4,3,8,13,'#8a5a2c');rect(g,4,3,3,13,'#9a6a36');rect(g,7,3,1,13,'#5a3a1c');rect(g,9,3,3,13,'#7a4c22');rect(g,10,9,2,2,'#f0d060');rect(g,5,3,6,1,'#a87a42');}));
  TSPR[T.L]=[0,1,2,3].map(i=>makeSprite(16,16,g=>{grassBase(i*3+5,false)(g);const cs=[['#ff6a8a','#ffd'],['#ffe14d','#fff'],['#a78bff','#fff'],['#ff9a3d','#ffe']][i];
    const r=mulberry32(i+31);for(let k=0;k<4;k++){const x=2+Math.floor(r()*11),y=3+Math.floor(r()*10);rect(g,x,y,1,2,'#2f7a2a');rect(g,x-1,y-1,3,1,cs[0]);rect(g,x,y-2,1,3,cs[0]);rect(g,x,y-1,1,1,cs[1]);}}));
  TSPR[T.N]=[0].map(()=>makeSprite(16,16,g=>{grassBase(9,false)(g);rect(g,1,5,3,10,'#4a2c14');rect(g,12,5,3,10,'#4a2c14');rect(g,2,5,1,10,'#8a5a2c');rect(g,13,5,1,10,'#8a5a2c');rect(g,0,6,16,2,'#4a2c14');rect(g,0,6,16,1,'#a87a42');rect(g,0,10,16,2,'#4a2c14');rect(g,0,10,16,1,'#a87a42');}));
  TSPR[T.J]=[0].map(()=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#3a7fd5');rect(g,0,1,16,14,'#6b4423');for(let y=1;y<16;y+=3){rect(g,0,y,16,1,'#8a5a2c');rect(g,0,y+2,16,1,'#3a2410');}rect(g,0,0,16,1,'#2a1808');rect(g,0,15,16,1,'#2a1808');for(let x=2;x<16;x+=6){rect(g,x,3,1,1,'#c9a15e');rect(g,x+2,10,1,1,'#c9a15e');}}));
  TSPR[T.S]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#7c7e8c');rect(g,0,0,16,3,'#c8cad6');rect(g,0,3,16,1,'#a0a2b0');rect(g,0,13,16,3,'#5a5c6a');rect(g,0,8,16,1,'#6a6c7a');rect(g,v?4:9,3,1,5,'#6a6c7a');rect(g,v?10:3,9,1,4,'#6a6c7a');}));
  // minimap colours
  // building fronts: top-left light - shingle tops catch the light, plaster gets texture, beams get a lit edge, a soft shade under the eaves
  for(const id of [T.R,T.RL])for(const c of TSPR[id]){const g=c.getContext('2d');for(let y=0;y<(id===T.RL?12:16);y+=4){for(let x=0;x<16;x+=2)if(((x>>1)+y)%3)rect(g,x,y,1,1,'#d8664a');rect(g,0,y+2,16,1,'rgba(90,24,14,.35)');}rect(g,0,0,16,1,'rgba(255,200,170,.25)');}
  for(const id of [T.H,T.D])for(const c of TSPR[id]){const g=c.getContext('2d');rect(g,2,2,12,1,'rgba(60,40,20,.28)');rect(g,0,0,1,16,'#8a5a32');rect(g,14,0,1,16,'#8a5a32');rect(g,0,0,16,1,'#8a5a32');
    if(id===T.H)for(let i=0;i<6;i++){const h=hash2(i*13+7,i*5+3);rect(g,3+(h%10),4+((h>>>4)%8),1,1,i%2?'#f8f0dc':'#ddcfae');}}
  TSPR.mini={[T.G]:'#58a845',[T.K]:'#2c7344',[T.T]:'#1d6430',[T.W]:'#3a7fd5',[T.P]:'#d6b985',[T.B]:'#8a8d9c',[T.BT]:'#8a8d9c',[T.F]:'#b9b4a6',[T.R]:'#b8452f',[T.RL]:'#b8452f',[T.H]:'#ecdfc2',[T.D]:'#8a5a2c',[T.L]:'#7ccc62',[T.N]:'#8a5a2c',[T.J]:'#8a5a2c',[T.C]:'#a8232f',[T.S]:'#7c7e8c',[T.U]:'#4a98ea',[T.Z]:'#d0cdc0'};
}
buildTiles();
