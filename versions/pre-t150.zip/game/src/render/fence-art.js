/* =====================================================================
   FENCES + GATES (t138u): wooden fences auto-join (horizontal runs, vertical runs, corners, T-joints); every run has
   square posts with caps, two cross rails and an X brace on alternate bays; a run that ends next to a road / path gets a
   tall GATE POST (stone footing, iron cap, small lantern). The stone gate arch and the wooden double gate are redrawn to match.
   ===================================================================== */
{
  const O='#2a1608',W0='#6b4022',W1='#8a5a32',W2='#a8743e',WH='#c89058',ST='#8a8898',STL='#b8b6c4',STD='#5a5868';
  const r=(g,x,y,w,h,c)=>rect(g,x,y,w,h,c);
  const isF=(x,y)=>x>=0&&y>=0&&x<MW&&y<MH&&map[y]&&map[y][x]===T.N;
  const isRoad=(x,y)=>x>=0&&y>=0&&x<MW&&y<MH&&map[y]&&(map[y][x]===T.P||map[y][x]===T.F||map[y][x]===T.J);
  function post(g,x,y0,y1,big){const w=big?4:3;r(g,x,y0,w,y1-y0,O);r(g,x+1,y0+1,w-2,y1-y0-2,big?W2:W1);r(g,x+1,y0+1,1,y1-y0-2,WH);
    r(g,x,y0-1,w,2,O);r(g,x+1,y0-1,w-2,1,big?WH:W2);r(g,x,y1-1,w,1,'rgba(20,10,0,.5)');}
  function gatePost(g,x){r(g,x-1,12,7,4,STD);r(g,x,12,5,3,ST);r(g,x,12,5,1,STL);           // stone footing
    r(g,x,1,5,12,O);r(g,x+1,2,3,10,W1);r(g,x+1,2,1,10,WH);r(g,x+3,2,1,10,W0);               // tall post
    r(g,x-1,0,7,2,'#3a3a46');r(g,x,0,5,1,'#8a8aa0');                                          // iron cap
    r(g,x+1,4,3,3,'#2a2a30');r(g,x+2,5,1,1,'#ffd23f');}                                      // little lantern
  function hRails(g,x0,x1,brace){r(g,x0,5,x1-x0,2,O);r(g,x0,5,x1-x0,1,W2);r(g,x0,10,x1-x0,2,O);r(g,x0,10,x1-x0,1,W1);
    if(brace){for(let i=0;i<x1-x0;i++){const t=i/(x1-x0);const ya=Math.round(6+t*4),yb=Math.round(10-t*4);px2(g,x0+i,ya,W1);px2(g,x0+i,yb,W0);}}}
  const px2=(g,x,y,c)=>r(g,x,y,1,1,c);
  function vRails(g,y0,y1){r(g,6,y0,1,y1-y0,O);r(g,7,y0,2,y1-y0,W1);r(g,7,y0,1,y1-y0,WH);r(g,9,y0,1,y1-y0,O);}
  const FC=new Map();
  function fenceTile(x,y){
    const L=isF(x-1,y),R=isF(x+1,y),U=isF(x,y-1),D=isF(x,y+1),gl=!L&&isRoad(x-1,y),gr=!R&&isRoad(x+1,y),brace=(hash2(x,y)&1)===1;
    const key=(L|R<<1|U<<2|D<<3|gl<<4|gr<<5|brace<<6)+':'+(hash2(x,y)%3);let c=FC.get(key);if(c)return c;
    c=makeSprite(16,16,g=>{grassBase(9+hash2(x,y)%3,false)(g);
      r(g,0,14,16,2,'rgba(20,30,10,.25)');
      const horiz=L||R||!(U||D);
      if(U||D){vRails(g,U?0:7,D?16:9);}
      if(horiz){const x0=L?0:gl?5:6,x1=R?16:gr?11:10;if(x1>x0)hRails(g,x0,x1,brace&&L&&R);}
      if(gl)gatePost(g,0);else if(gr)gatePost(g,11);
      if(!gl&&!gr){const big=!L||!R||U||D;post(g,6,3,15,big);}
      for(let i=0;i<3;i++){const gx=hash2(x+i,y*3)%15;r(g,gx,15,1,1,'#4f9a3a');r(g,gx+1,14,1,1,'#6ab84a');}
    });FC.set(key,c);return c;
  }
  XTILE_FN[T.N]=(x,y)=>fenceTile(x,y);
  // gate arch + wooden gate, redrawn
  const GC={};
  const archSpr=()=>GC.a||(GC.a=makeSprite(16,16,g=>{
    r(g,0,0,16,16,'#7a7888');for(let y=0;y<16;y+=3){r(g,0,y+2,16,1,'#5a5868');for(let x=((y/3)%2?0:4);x<16;x+=8)r(g,x,y,1,2,'#5a5868');}
    r(g,0,0,16,1,'#c8c6d4');r(g,3,5,10,11,'#16121e');for(let i=0;i<5;i++)r(g,3+i,5-Math.round(Math.sqrt(25-(i-5)*(i-5))*.6),10-2*i,1,'#16121e');
    r(g,2,4,1,12,'#a8a6b4');r(g,13,4,1,12,'#4a4858');r(g,5,1,6,2,'#a8a6b4');r(g,7,1,2,3,'#d8d6e2');                 // keystone + jambs
    for(let i=4;i<13;i+=2)r(g,i,4,1,3,'#3a3a46');r(g,3,6,10,1,'#3a3a46');                                          // raised portcullis teeth
    r(g,0,7,2,4,O);r(g,0,8,1,2,'#ffd23f');r(g,14,7,2,4,O);r(g,15,8,1,2,'#ffd23f');r(g,4,14,8,2,'#8d7a5c');
    r(g,0,0,3,3,'#5ea83a');r(g,13,0,3,2,'#4f9a3a');}));
  const gateSpr=()=>GC.g||(GC.g=makeSprite(16,16,g=>{grassBase(10,false)(g);
    r(g,0,1,3,15,O);r(g,1,2,1,13,STL);r(g,0,0,3,2,'#d8d4c8');r(g,13,1,3,15,O);r(g,14,2,1,13,ST);r(g,13,0,3,2,'#d8d4c8');   // stone posts
    r(g,3,4,10,12,O);r(g,4,5,8,11,W1);for(let i=4;i<12;i+=2)r(g,i,5,1,11,W2);r(g,7,4,2,12,O);                            // planks + centre seam
    r(g,4,4,3,1,W2);r(g,9,4,3,1,W2);r(g,4,3,2,1,W1);r(g,10,3,2,1,W1);                                                      // gently arched top
    r(g,3,7,10,1,'#3e3e4a');r(g,3,12,10,1,'#3e3e4a');px(g,6,10,'#d8d8e0');px(g,9,10,'#d8d8e0');                            // iron bands + rings
    for(let i=0;i<10;i++){r(g,4+i,Math.round(8+i*.4),1,1,W0);}}));                                                        // diagonal brace
  XTILE_FN[T.WGH]=()=>archSpr();XTILE_FN[T.WGT]=()=>gateSpr();
  function px(g,x,y,c){rect(g,x,y,1,1,c);}
}
