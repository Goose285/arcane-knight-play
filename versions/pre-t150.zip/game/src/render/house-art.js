/* =====================================================================
   HOUSE INTERIOR WALLS - mockup options  ?housewall=1..4  (default 1; 0 = the original grey brick)
   1 warm timber + plaster with beams   2 log cabin   3 cottage stone with wallpaper trim   4 wooden planks with windows / shelves / rug
   Only the room edge is built (a 2-row back wall, 1-tile side + front walls); everything outside the room is dark.
   Pure rendering: the map, collision and tile ids are untouched.
   ===================================================================== */
const HOUSEWALL=(()=>{const q=new URLSearchParams(location.search).get('housewall');if(q===null||q==='')return 1;const v=+q;return v>=1&&v<=4?v|0:0;})();   // default = 1 (warm timber + plaster); ?housewall=0 = the old grey brick
const HW_DARK='#07050f';
const HW_CACHE=new Map();
const hwRectNow=()=>{const R=HOUSE_ROOM;return {x0:(HOUSEVOID===4?HOUSE_KIT.x0:R.x0)-1,x1:R.x1+1,ub:R.y0-2,y1:R.y1+1};};
function hwKind(x,y,id){   // what a house-zone tile is, for wall painting: 'ub' upper back wall, 'lb' lower back wall, 'l','r','m' side / inner walls, 'bt' front wall, 'out' beyond the walls, null = floor / prop
  const R=HOUSE_ROOM,W=hwRectNow(),lb=R.y0-1;
  if(x<W.x0||x>W.x1||y<W.ub||y>W.y1)return 'out';
  if(y===W.ub)return 'ub';if(y===lb)return 'lb';
  if(id===T.F||id===T.P||id===T.GX)return null;
  if(x===W.x0)return 'l';if(x===W.x1)return 'r';
  if(y===W.y1)return 'bt';
  if(HOUSEVOID===4&&x===R.x0-1)return 'm';
  return null;
}
const hwN=(x,y,k)=>hash2(x*7+k,y*13+k*3)&255;
function hwSpeck(g,col,n,seed){for(let i=0;i<n;i++){const h=hash2(seed+i*31,i*17+seed);rect(g,h&15,(h>>4)&15,1,1,col);}}
/* ---- 1. warm timber + plaster ---- */
function hwTimber(g,kind,x,y){
  const PL='#ecdcb8',PL2='#e0cca4',PD='#cdb68c',T1='#6b4426',T2='#8d5e37',T3='#46281a';
  const beamV=()=>{rect(g,6,0,4,16,T1);rect(g,6,0,1,16,T2);rect(g,9,0,1,16,T3);};
  if(kind==='ub'||kind==='lb'){
    rect(g,0,0,16,16,PL);hwSpeck(g,PL2,7,x*5+y);hwSpeck(g,PD,3,x*3+y*9);
    if(x%4===0)beamV();
    if(kind==='ub'){rect(g,0,0,16,4,T1);rect(g,0,0,16,1,T2);rect(g,0,3,16,1,T3);
      if(HOUSEVOID===4&&x>=HOUSE_KIT.x0&&x<=HOUSE_KIT.x1&&x%4!==0){   // kitchen wall: hanging copper pots and a spice shelf
        if(x%4===1){rect(g,7,4,1,3,'#3a2412');ell(g,8,10,4,3,'#b8683a');ell(g,8,9,3,2,'#d08850');rect(g,4,7,8,1,'#8a4a28');rect(g,12,9,2,1,'#8a4a28');}
        else{rect(g,0,11,16,2,T1);rect(g,0,11,16,1,T2);rect(g,2,6,3,5,'#d8c070');rect(g,6,7,3,4,'#a85a3a');rect(g,10,6,3,5,'#7a9a4a');rect(g,2,6,3,1,'#fff0a0');}}}
    else{rect(g,0,0,16,1,'#00000014');rect(g,0,9,16,2,T1);rect(g,0,9,16,1,T2);rect(g,0,12,16,4,'#8a5a34');for(let i=0;i<16;i+=5)rect(g,i,12,1,4,'#6b4426');rect(g,0,12,16,1,'#a8703a');rect(g,0,15,16,1,T3);
      if(x%4===0){rect(g,6,9,4,7,T1);rect(g,6,9,1,7,T2);rect(g,9,9,1,7,T3);}}
    return;}
  // side / front strips: a timber post + plaster infill
  rect(g,0,0,16,16,PL);hwSpeck(g,PL2,6,x*5+y);
  if(kind==='bt'){rect(g,0,0,16,5,T1);rect(g,0,0,16,1,T2);rect(g,0,4,16,1,T3);if(x%4===0)rect(g,6,0,4,16,T1);return;}
  if(kind==='m'){rect(g,0,0,3,16,T1);rect(g,2,0,1,16,T2);rect(g,13,0,3,16,T1);rect(g,13,0,1,16,T2);rect(g,3,0,2,16,'#0000001c');rect(g,11,0,2,16,'#0000001c');if(y%3===0){rect(g,3,6,10,3,T1);rect(g,3,6,10,1,T2);}return;}
  const edge=kind==='l'?[13,3]:[0,3];rect(g,edge[0],0,3,16,T1);rect(g,edge[0]+(kind==='l'?0:2),0,1,16,T2);
  if(y%3===0){rect(g,0,6,16,3,T1);rect(g,0,6,16,1,T2);}
  rect(g,kind==='l'?10:3,0,3,16,'#0000001c');
}
/* ---- 2. log cabin ---- */
function hwLog(g,kind,x,y){
  const B='#9a6334',H='#b57a44',S='#6e4421',C='#2e1c0e';
  const logs=(w0,w1)=>{for(let k=0;k<4;k++){const yy=k*4,seed=hwN(x,y*4+k,2);rect(g,w0,yy,w1-w0,4,B);rect(g,w0,yy,w1-w0,1,H);rect(g,w0,yy+2,w1-w0,1,S);rect(g,w0,yy+3,w1-w0,1,C);
      rect(g,(seed&7)+w0,yy+1,1,1,S);rect(g,((seed>>3)&7)+w0+3,yy+1,2,1,'#8a5528');if(seed%5===0){rect(g,8+(seed&3),yy+1,3,2,S);rect(g,9+(seed&3),yy+1,1,1,C);}}};
  if(kind==='ub'||kind==='lb'){logs(0,16);if(kind==='ub')rect(g,0,0,16,1,'#c88f55');else{rect(g,0,0,16,1,'#00000018');}
    if(kind==='lb'){rect(g,0,15,16,1,C);}
    return;}
  if(kind==='bt'){logs(0,16);rect(g,0,0,16,2,'#00000030');return;}
  // side walls: stacked log ends
  rect(g,0,0,16,16,'#3a2412');
  for(let k=0;k<2;k++){const cy=4+k*8,cx=8;ell(g,cx,cy,4,4,C);ell(g,cx,cy,3,3,'#c58c52');ell(g,cx,cy,2,2,'#a8713a');ell(g,cx,cy,1,1,'#8a5528');rect(g,cx-3,cy-3,2,1,'#e0aa70');}
  rect(g,kind==='l'?12:0,0,4,16,'#00000026');
}
/* ---- 3. cottage stone + wallpaper trim ---- */
function hwStone(g,x,y,top){   // fieldstone, warm grey-beige
  rect(g,0,0,16,16,'#8e7c64');
  for(let r=0;r<16;r+=5){const off=((y*3+(r/5|0))&1)?0:3;
    for(let c=-off;c<16;c+=8){const w=6+(hwN(c+x*16,r+y*16,4)&1),x0=Math.max(0,c),x1=Math.min(16,c+w);if(x1<=x0)continue;
      rect(g,x0,r,x1-x0,4,'#b8a68b');rect(g,x0,r,x1-x0,1,'#d2c3a8');rect(g,x0,r+3,x1-x0,1,'#9d8b72');if(hwN(c+x*16,r,5)%3===0)rect(g,x0+1,r+1,2,1,'#a89577');}}
}
function hwCottage(g,kind,x,y){
  const PA='#e9eee0',PB='#c6d8c0',PC='#a9c3a4',RAIL='#8a6a48',RAILH='#b08a60',RAILS='#5c4630';
  if(kind==='ub'){   // wallpaper: cream + sage stripes with tiny flowers, crown trim on top
    for(let c=0;c<16;c++)rect(g,c,0,1,16,((c+((x&1)*8))%16<8)?PA:PB);
    for(let c=0;c<16;c+=8)rect(g,(c+((x&1)*8))%16,0,1,16,PC);
    const f=hwN(x,y,6);rect(g,3+(f&3),6,1,1,'#d68a9a');rect(g,2+(f&3),7,3,1,'#e8a8b4');rect(g,3+(f&3),8,1,1,'#d68a9a');rect(g,11-(f&3),10,1,1,'#d68a9a');rect(g,10-(f&3),11,3,1,'#e8a8b4');rect(g,11-(f&3),12,1,1,'#d68a9a');
    rect(g,0,0,16,3,RAIL);rect(g,0,0,16,1,RAILH);rect(g,0,2,16,1,RAILS);rect(g,0,3,16,1,'#00000028');
    rect(g,0,14,16,2,RAIL);rect(g,0,14,16,1,RAILH);rect(g,0,15,16,1,RAILS);return;}
  if(kind==='lb'){hwStone(g,x,y,false);rect(g,0,0,16,2,RAIL);rect(g,0,0,16,1,RAILH);rect(g,0,2,16,1,'#00000030');rect(g,0,13,16,3,'#00000014');return;}
  hwStone(g,x,y,false);
  if(kind==='bt'){rect(g,0,0,16,2,'#00000034');rect(g,0,0,16,1,RAIL);return;}
  rect(g,kind==='l'?12:0,0,4,16,'#0000002a');
}
/* ---- 4. wooden planks + windows / shelves ---- */
function hwPlank(g,x,y,sx){   // vertical planks 4px wide
  for(let c=0;c<4;c++){const v=hwN(x*4+c,y,8)&3,base=['#b07a45','#a5703c','#b98350','#aa753f'][v];rect(g,c*4,0,4,16,base);rect(g,c*4,0,1,16,'#c9965c');rect(g,c*4+3,0,1,16,'#6e4421');
    const k=hwN(x*4+c,y,9);rect(g,c*4+1+(k&1),(k>>1)&15,1,3,'#8d5c2e');if(k%7===0){rect(g,c*4+1,(k>>2)&15,2,2,'#7a4a24');}}
}
function hwWindow(g,lower){
  const FR='#f1e4c8',FRS='#b59e78';
  if(!lower){rect(g,1,2,14,14,FR);rect(g,3,4,10,12,'#7fc4ee');rect(g,3,4,10,5,'#a8dcf6');rect(g,3,4,10,1,'#d8f2ff');rect(g,4,5,3,1,'#ffffff');rect(g,7,4,2,12,FR);rect(g,3,9,10,1,FR);rect(g,1,2,14,1,'#fff8e6');rect(g,1,2,1,14,FRS);rect(g,14,2,1,14,FRS);
    rect(g,3,4,3,5,'#e8847a');rect(g,3,4,1,5,'#c85a55');rect(g,10,4,3,5,'#e8847a');rect(g,12,4,1,5,'#c85a55');}   // curtains
  else{rect(g,1,0,14,5,FR);rect(g,3,0,10,2,'#7fc4ee');rect(g,7,0,2,2,FR);rect(g,3,0,3,2,'#e8847a');rect(g,10,0,3,2,'#e8847a');rect(g,0,5,16,3,FR);rect(g,0,5,16,1,'#fff8e6');rect(g,0,7,16,1,FRS);rect(g,0,8,16,2,'#00000030');   // sill
    rect(g,5,3,3,0,'#fff');}
}
function hwShelf(g,x,seed){   // a plank shelf on the upper-wall tile, with books and jars
  rect(g,0,12,16,3,'#6a4423');rect(g,0,12,16,1,'#8d5e37');rect(g,0,14,16,1,'#3a2412');rect(g,1,15,2,1,'#3a2412');rect(g,13,15,2,1,'#3a2412');
  const cols=['#b0453a','#3f6fb0','#4a8a4a','#d6a52a','#7a4a9a','#c8c0a8'];let cx=1;const h=hwN(x,seed,3);
  if(h%3===0){ell(g,5,9,3,3,'#c8e0e8');rect(g,3,6,5,1,'#8a6a4a');rect(g,4,9,3,2,'#e8b040');ell(g,12,9,2,2,'#b86a3a');rect(g,11,6,3,1,'#8a6a4a');return;}
  for(let b=0;b<5;b++){const bh=6+((h>>b)&3),w=2+((h>>(b+2))&1);rect(g,cx,12-bh,w,bh,cols[(h+b)%6]);rect(g,cx,12-bh,1,bh,'#ffffff30');cx+=w;if(cx>14)break;}
}
function hwPlanks(g,kind,x,y){
  if(kind==='ub'||kind==='lb'){hwPlank(g,x,y);
    if(kind==='ub'){rect(g,0,0,16,2,'#7a4a24');rect(g,0,0,16,1,'#a8703a');}
    else{rect(g,0,0,16,1,'#00000018');rect(g,0,13,16,3,'#6a4423');rect(g,0,13,16,1,'#8d5e37');rect(g,0,15,16,1,'#3a2412');}
    const R=HOUSE_ROOM,dx=x-R.x0;
    if(dx===2||dx===11){hwWindow(g,kind==='lb');}
    else if(kind==='ub'&&(dx===5||dx===6||dx===9||dx===10))hwShelf(g,x,dx);
    return;}
  hwPlank(g,x,y);
  if(kind==='bt'){rect(g,0,0,16,2,'#00000040');return;}
  rect(g,kind==='l'?12:0,0,4,16,'#0000002e');rect(g,kind==='l'?15:0,0,1,16,'#3a2412');
}
function hwRug(g,rx,ry,w,h){   // woven rug: dark red border, cream field with diamond band, fringe left / right
  const RD='#9a2f35',RD2='#7a2228',CR='#ecdcb4',GD='#d6a52a';rect(g,0,0,16,16,CR);
  if(ry===0){rect(g,0,0,16,3,RD);rect(g,0,0,16,1,RD2);rect(g,0,3,16,1,GD);}
  if(ry===h-1){rect(g,0,13,16,3,RD);rect(g,0,15,16,1,RD2);rect(g,0,12,16,1,GD);}
  if(rx===0){rect(g,0,0,3,16,RD);rect(g,0,0,1,16,RD2);rect(g,3,0,1,16,GD);rect(g,0,0,16,0,RD);for(let i=0;i<16;i+=2)rect(g,0,i,1,1,'#f4ead0');}
  if(rx===w-1){rect(g,13,0,3,16,RD);rect(g,15,0,1,16,RD2);rect(g,12,0,1,16,GD);for(let i=0;i<16;i+=2)rect(g,15,i,1,1,'#f4ead0');}
  if(ry>0&&ry<h-1&&rx>0&&rx<w-1&&(rx+ry)%2===0){rect(g,7,4,2,2,RD);rect(g,6,6,4,2,RD);rect(g,7,8,2,2,RD);rect(g,7,6,2,2,GD);}
  else if(ry>0&&ry<h-1)rect(g,0,7,16,2,'#e4d09c');
}
function hwKitFloor(x,y){return makeSprite(16,16,g=>{rect(g,0,0,16,16,'#a97a48');
  for(let r=0;r<4;r++){const yy=r*4,off=((y*4+r)&1)?0:8;rect(g,0,yy+3,16,1,'#6e4a28');rect(g,0,yy,16,1,'#bb8b56');rect(g,(off+x*5)&15,yy,1,3,'#6e4a28');
    const v=hwN(x,y*4+r,31);if(v%3===0)rect(g,v&7,yy+1,5,1,'#98693a');}});}
function hwFloor(base,x,y,prop){   // the room floor: soft shadow under the back wall / beside the walls, a rug (wall option 4), the kitchen's plank floor + furniture (void option 4)
  const R=HOUSE_ROOM,K=HOUSE_KIT,v4=HOUSEVOID===4,kit=v4&&x>=K.x0&&x<=K.x1,thr=v4&&x===R.x0-1,P=v4?HOUSE_PROPS[x+','+y]:null;
  let rug=null;
  if(HOUSEWALL===4&&x>=29&&x<=34&&y>=R.y0+4&&y<=R.y0+6)rug=[x-29,y-(R.y0+4),6,3];
  const doorRow=v4&&(y===R.y0+1||y===R.y0+2);
  const sh=y===R.y0?1:0,ed=thr?0:x===(v4?K.x0:R.x0)?1:x===R.x1?2:(kit&&x===K.x1&&!doorRow)?2:(v4&&x===R.x0&&!doorRow)?1:0;
  if(!sh&&!ed&&!rug&&!kit&&!thr&&!P)return base;
  const key='f'+HOUSEWALL+'|'+HOUSEVOID+'|'+(base===TSPR[T.F][0]?0:1)+'|'+sh+ed+(kit||thr?'k'+x+'_'+(y&3):'')+'|'+(rug?rug.join():'')+(P?'p'+P.join():'');
  let r=HW_CACHE.get(key);if(r)return r;
  r=makeSprite(16,16,g=>{g.drawImage((kit||thr)?hwKitFloor(x,y):base,0,0);
    if(rug)hwRug(g,rug[0],rug[1],rug[2],rug[3]);
    if(P)hwProp(g,P[0],P[1],P[2],x,y);
    if(sh){for(let i=0;i<5;i++){g.fillStyle='rgba(30,16,8,'+(.34-i*.07)+')';g.fillRect(0,i,16,1);}}
    if(ed===1){for(let i=0;i<3;i++){g.fillStyle='rgba(30,16,8,'+(.26-i*.08)+')';g.fillRect(i,0,1,16);}}
    if(ed===2){for(let i=0;i<3;i++){g.fillStyle='rgba(30,16,8,'+(.26-i*.08)+')';g.fillRect(15-i,0,1,16);}}});
  HW_CACHE.set(key,r);return r;
}
/* kitchen furniture (solid tiles, drawn over the plank floor) */
function hwProp(g,t,rx,ry,x,y){
  const WD='#8a5a34',WL='#b98a55',WS='#4e2f18',OUT='#2a170b';
  if(t==='counter'){rect(g,0,2,16,14,OUT);rect(g,0,3,16,4,'#cdb48a');rect(g,0,3,16,1,'#e6d2a8');rect(g,0,6,16,1,'#8e7a58');   // worktop
    rect(g,1,7,14,8,WD);rect(g,1,7,14,1,WL);rect(g,7,8,2,7,WS);rect(g,3,10,2,1,'#e8c860');rect(g,11,10,2,1,'#e8c860');rect(g,1,14,14,1,WS);
    if(rx===2){ell(g,8,5,5,2,'#7a8a98');ell(g,8,5,4,1,'#a8bccb');rect(g,7,1,2,2,'#c8c8d0');rect(g,7,1,4,1,'#c8c8d0');}   // sink + tap
    if(rx===0){rect(g,3,2,4,2,'#c85a3a');rect(g,4,1,2,1,'#6a8a3a');}   // a bowl of fruit / tomatoes
    if(rx===3){ell(g,8,4,4,2,'#d8b070');rect(g,5,3,6,1,'#e8c890');}   // a loaf
    return;}
  if(t==='stove'){rect(g,0,2,16,14,OUT);rect(g,1,3,14,12,'#3d3d48');rect(g,1,3,14,1,'#5a5a68');ell(g,5,5,2,1,'#222');ell(g,11,5,2,1,'#222');ell(g,5,5,1,0,'#c85a3a');
    rect(g,3,8,10,6,'#25252e');rect(g,4,9,8,4,'#ff9a3a');rect(g,5,10,6,2,'#ffd070');rect(g,4,9,8,1,'#c8581e');rect(g,2,15,12,1,OUT);rect(g,6,0,4,3,'#2a2a30');return;}
  if(t==='barrel'){ell(g,8,9,6,7,OUT);ell(g,8,9,5,6,'#8a5a30');rect(g,3,6,10,1,'#4a4a52');rect(g,3,11,10,1,'#4a4a52');rect(g,5,3,1,12,'#a8703a');rect(g,9,3,1,12,'#6e4421');ell(g,8,4,4,1,'#a8703a');ell(g,8,4,3,1,'#5a3a1c');return;}
  if(t==='crate'){rect(g,1,3,14,13,OUT);rect(g,2,4,12,11,'#b07a45');rect(g,2,4,12,1,'#d09860');for(let i=0;i<4;i++)rect(g,2,5+i*3,12,1,'#8a5a2c');rect(g,2,4,2,11,'#8a5a2c');rect(g,12,4,2,11,'#8a5a2c');for(let i=0;i<10;i++)rect(g,3+(i>>1)+i%2*0,5+i,1,1,'#6e4421');
    const v=hwN(x,y,41);if(v%2===0){rect(g,5,1,6,3,'#d8c070');rect(g,5,1,6,1,'#f0e090');}return;}   // sometimes a sack on top
  if(t==='table'){const cl=(rx+ry)%2?'#d8e0e8':'#b83a3a';rect(g,rx===0?1:0,ry===0?2:0,rx===0?15:16,ry===0?14:15,OUT);   // a table with a checked cloth
    rect(g,rx===0?2:0,ry===0?3:0,rx===0?14:16,ry===0?12:14,'#c8483f');
    for(let yy=(ry===0?3:0);yy<15;yy+=4)for(let xx=(rx===0?2:0);xx<16;xx+=4)if(((xx+yy)/4|0)%2===0)rect(g,xx,yy,4,4,'#f0e8d8');
    if(rx===0&&ry===1){ell(g,12,6,3,2,'#f0f0f0');ell(g,12,6,2,1,'#cfd8e0');}if(rx===1&&ry===0){ell(g,4,8,3,2,'#f0f0f0');ell(g,4,8,2,1,'#cfd8e0');rect(g,10,6,3,4,'#a8703a');rect(g,10,5,3,1,'#d8b070');}
    if(ry===1)rect(g,rx===0?2:0,13,rx===0?14:16,2,'#00000040');return;}
}
function houseTile(id,x,y,base){   // called from tileSprite for the house zone; returns a 16x16 sprite
  const k=hwKind(x,y,id);
  if(k==='out')return hwOut(x,y);
  if(k===null){
    if(id===T.F||id===T.B)return hwFloor(id===T.B?TSPR[T.F][0]:base,x,y,id===T.B);
    return base;}
  const kk=(k==='m'&&HOUSEWALL!==1)?'l':k;
  const key=HOUSEWALL+'|'+kk+'|'+x+'|'+(y%12);
  let r=HW_CACHE.get(key);if(r)return r;
  r=makeSprite(16,16,g=>{
    if(HOUSEWALL===1)hwTimber(g,kk,x,y);else if(HOUSEWALL===2)hwLog(g,kk,x,y);else if(HOUSEWALL===3)hwCottage(g,kk,x,y);else hwPlanks(g,kk,x,y);});
  HW_CACHE.set(key,r);return r;
}
/* =====================================================================
   ?housevoid=1..4 : what lies beyond the walls, + one pixel-scale step of zoom (options 1, 2, 4) so the room fills the screen
   ===================================================================== */
const houseInView=()=>typeof P!=='undefined'&&typeof state!=='undefined'&&state!=='title'&&P.y>=HOUSE_Y0*TS&&P.y<(HOUSE_Y0+HOUSE_H)*TS;
const houseZoomWant=()=>HOUSEWALL>0&&(HOUSEVOID===1||HOUSEVOID===2||HOUSEVOID===4)&&houseInView();
function hwOutSide(x,y){   // distance (tiles) outside the wall ring + which side is the outer edge
  const W=hwRectNow(),dx=Math.max(W.x0-x,0,x-W.x1),dy=Math.max(W.ub-y,0,y-W.y1);
  return {d:Math.max(dx,dy,1),side:dy>=dx?(y<W.ub?'u':'b'):(x<W.x0?'l':'r')};
}
function hwPaintSide(g,side,fn){   // fn paints with the outer edge at the TOP; transform it onto the real side
  g.save();
  if(side==='b')g.setTransform(1,0,0,-1,0,16);else if(side==='l')g.setTransform(0,1,1,0,0,0);else if(side==='r')g.setTransform(0,1,-1,0,16,0);
  fn(g);g.restore();
}
function hwBrown(g,x,y){rect(g,0,0,16,16,'#2c1b10');hwSpeck(g,'#34210f',8,x*5+y*3);hwSpeck(g,'#251710',5,x*11+y);}
/* eave: shingle courses with the outer edge at the TOP (hwPaintSide turns it onto the real side) */
function hwEaveC(g,x,y){
  rect(g,0,0,16,16,'#6b3123');
  for(let r=0;r<4;r++){const yy=r*4,off=(r+((x+y)&1))&1?4:0;
    for(let c=-off;c<16;c+=8){const x0=Math.max(0,c),x1=Math.min(16,c+8);if(x1<=x0)continue;const v=hwN(x+c,y*4+r,12)&3;
      rect(g,x0,yy,x1-x0,4,['#8a4632','#7e3f2c','#93503a','#7a3a2a'][v]);rect(g,x0,yy,x1-x0,1,'#a85d44');rect(g,x0,yy+3,x1-x0,1,'#4e2217');rect(g,x1-1,yy,1,4,'#4e2217');}}
  rect(g,0,0,16,2,'#3a1a12');rect(g,0,2,16,1,'#a85d44');   // fascia board on the outer edge
  rect(g,0,12,16,4,'#00000040');rect(g,0,14,16,2,'#00000040');   // shade toward the wall
}
function hwOuterWallC(g,x,y){   // the outside face of the house wall: dark timber frame + weathered plaster
  rect(g,0,0,16,16,'#b49f78');hwSpeck(g,'#a28d66',9,x*7+y);hwSpeck(g,'#c4b08a',4,x+y*5);
  rect(g,0,0,16,3,'#3e2616');rect(g,0,0,16,1,'#5a3a22');
  if(x%4===0||y%4===0){rect(g,6,3,4,13,'#4d2f1a');rect(g,6,3,1,13,'#6b4426');rect(g,9,3,1,13,'#2e1b0e');}
  rect(g,0,13,16,3,'#00000030');
}
function hwWoodGrain(g,x,y){
  rect(g,0,0,16,16,(y&1)?'#3a2515':'#3e2817');
  for(let i=0;i<7;i++){const h=hash2(x*9+i*17,y*5+i*7),yy=h&15,xx=(h>>4)&7,len=5+((h>>8)&7);rect(g,xx,yy,len,1,(h&1)?'#4a321e':'#2f1c0f');}
  const k=hwN(x,y,15);if(k%6===0){ell(g,3+(k&7),4+((k>>3)&7),2,1,'#2a190c');ell(g,3+(k&7),4+((k>>3)&7),1,0,'#4a321e');}
  rect(g,0,15,16,1,'#22140a');rect(g,0,0,16,1,'#46301c');
}
function hwBlur(c){   // soften a 16x16 tile (down to 6x6 and back up, smoothed)
  const t=document.createElement('canvas');t.width=t.height=6;const g=t.getContext('2d');g.imageSmoothingEnabled=true;g.drawImage(c,0,0,6,6);
  const o=makeSprite(16,16,h=>{h.imageSmoothingEnabled=true;h.drawImage(t,0,0,16,16);});return o;
}
function hwGrassC(g,x,y){
  rect(g,0,0,16,16,'#4a7c3a');
  for(let i=0;i<14;i++){const h=hash2(x*13+i*19,y*7+i*3),xx=h&15,yy=(h>>4)&15;rect(g,xx,yy,2+((h>>8)&3),2,(h&1)?'#3e6e33':'#58903f');}
  const f=hwN(x,y,21);if(f%5===0){rect(g,f&7,(f>>3)&7,1,1,'#e8d070');rect(g,8+(f&3),9,1,1,'#f0e8f0');}
  if(f%9===1)ell(g,8,8,5,4,'#2f5a2a');   // a bush
}
function hwOut(x,y){
  if(!HOUSEVOID)return HW_VOID();
  const o=hwOutSide(x,y),near=o.d<=(HOUSEVOID===3?2:1),key='o'+HOUSEVOID+'|'+(HOUSEVOID===1||HOUSEVOID===4||(HOUSEVOID===3&&o.d>=3)?0:(HOUSEVOID===2&&!near?'g':o.d+o.side))+'|'+(x&3)+'|'+(y&3)+(HOUSEVOID===3&&o.d<3?'|'+x%4+'|'+y%4:'');
  let r=HW_CACHE.get(key);if(r)return r;
  if(HOUSEVOID===2){   // dim, blurred cutaway: the eave right outside the wall, then grass beyond
    const raw=makeSprite(16,16,g=>{if(near)hwPaintSide(g,o.side,gg=>hwEaveC(gg,x,y));else hwGrassC(g,x,y);});
    r=hwBlur(raw);const g=r.getContext('2d');g.fillStyle='rgba(8,10,26,.4)';g.fillRect(0,0,16,16);
    if(near){g.fillStyle='rgba(0,0,0,.14)';g.fillRect(0,0,16,16);}}
  else if(HOUSEVOID===3){
    r=makeSprite(16,16,g=>{
      if(o.d===1)hwPaintSide(g,o.side,gg=>hwOuterWallC(gg,x,y));
      else if(o.d===2)hwPaintSide(g,o.side,gg=>hwEaveC(gg,x,y));
      else hwWoodGrain(g,x,y);});}
  else r=makeSprite(16,16,g=>{hwBrown(g,x,y);});
  HW_CACHE.set(key,r);return r;
}
let HW_VIG=null;
function drawHouseVignette(){   // soft warm-dark vignette over the room (options 1 and 4)
  if(!(HOUSEVOID===1||HOUSEVOID===4)||!houseInView()||HOUSEWALL<1)return;
  if(!HW_VIG||HW_VIG.width!==VW||HW_VIG.height!==VH)HW_VIG=makeSprite(VW,VH,g=>{const gr=g.createRadialGradient(VW/2,VH/2,Math.min(VW,VH)*.30,VW/2,VH/2,Math.max(VW,VH)*.62);
    gr.addColorStop(0,'rgba(34,16,6,0)');gr.addColorStop(.6,'rgba(30,14,5,.28)');gr.addColorStop(1,'rgba(22,10,3,.72)');g.fillStyle=gr;g.fillRect(0,0,VW,VH);});
  ctx.drawImage(HW_VIG,0,0);
}
const HW_VOID=()=>{let r=HW_CACHE.get('void');if(!r){r=makeSprite(16,16,g=>rect(g,0,0,16,16,HW_DARK));HW_CACHE.set('void',r);}return r;};
