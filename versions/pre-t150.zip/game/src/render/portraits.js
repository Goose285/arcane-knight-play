/* =====================================================================
   CUTSCENE PORTRAITS: 24x24 code-drawn busts, shown at 4x. All original.
   ===================================================================== */
SP.port={};
const portBase=(g,o)=>{
  rect(g,3,19,18,5,o.cloth);rect(g,4,18,16,2,o.clothL);rect(g,9,17,6,3,o.skinD);            // shoulders + neck
  rect(g,6,5,12,13,o.skin);rect(g,7,4,10,1,o.skin);rect(g,7,18,10,1,o.skinD);rect(g,6,9,1,5,o.skinD);rect(g,17,9,1,5,o.skinD);
  rect(g,8,10,3,2,'#fff');rect(g,13,10,3,2,'#fff');rect(g,9,10,2,2,o.eye);rect(g,14,10,2,2,o.eye);rect(g,9,10,1,1,'#000');rect(g,14,10,1,1,'#000');  // eyes
  rect(g,11,13,2,2,o.skinD);rect(g,10,16,4,1,o.mouth||'#8a3a30');};                         // nose + mouth
SP.port.hero=autoOutline(makeSprite(24,24,g=>{       // the Sun Paladin
  portBase(g,{skin:'#f2c9a0',skinD:'#d4a880',cloth:'#f6ecd2',clothL:'#fffaf0',eye:'#3a5a8a'});
  rect(g,2,19,5,3,'#e8b83a');rect(g,17,19,5,3,'#e8b83a');rect(g,2,19,5,1,'#ffe27a');rect(g,17,19,5,1,'#ffe27a');          // gold pauldrons
  rect(g,11,20,2,4,'#e8b83a');rect(g,10,21,4,2,'#e8b83a');rect(g,11,21,2,1,'#ffe27a');                                    // sun mark on the breastplate
  rect(g,4,2,16,6,'#e8b83a');rect(g,5,1,14,2,'#e8b83a');rect(g,5,1,14,1,'#ffe27a');rect(g,6,3,12,1,'#ffe27a');rect(g,5,8,14,1,'#a8741a');   // gold helm + brow
  rect(g,4,8,3,9,'#e8b83a');rect(g,17,8,3,9,'#e8b83a');rect(g,4,8,1,9,'#ffe27a');rect(g,6,9,1,7,'#a8741a');rect(g,17,9,1,7,'#a8741a');  // cheek guards
  rect(g,10,0,4,2,'#fff6d8');rect(g,9,1,6,1,'#fff6d8');rect(g,11,0,2,1,'#fff');                                           // plume
  rect(g,8,9,3,1,'#a8741a');rect(g,13,9,3,1,'#a8741a');}),'#14182c');
SP.port.orin=autoOutline(makeSprite(24,24,g=>{
  portBase(g,{skin:'#e8c4a0',skinD:'#c8a080',cloth:'#4a5a9a',clothL:'#7a8ac8',eye:'#3a5a8a'});
  rect(g,5,3,14,3,'#f2f2f2');rect(g,4,5,3,8,'#f2f2f2');rect(g,17,5,3,8,'#f2f2f2');           // white hair
  rect(g,8,8,3,1,'#f2f2f2');rect(g,13,8,3,1,'#f2f2f2');                                      // brows
  rect(g,6,15,12,6,'#f2f2f2');rect(g,8,17,8,5,'#dcdcdc');rect(g,10,16,4,1,'#8a3a30');        // long beard
  rect(g,3,19,3,2,'#ffd23f');rect(g,18,19,3,2,'#ffd23f');}),'#10101c');
SP.port.hale=autoOutline(makeSprite(24,24,g=>{
  portBase(g,{skin:'#d8a880',skinD:'#b88860',cloth:'#6a727e',clothL:'#a6aeba',eye:'#5a4a2a'});
  rect(g,4,2,16,7,'#8a929e');rect(g,5,1,14,2,'#b8c0cc');rect(g,5,8,14,1,'#5a626e');rect(g,11,3,2,9,'#6a727e');  // helm + nasal
  rect(g,10,0,4,2,'#d84a3a');rect(g,9,-1,6,1,'#d84a3a');                                     // plume
  rect(g,6,12,3,2,'#6a4a2a');rect(g,15,12,3,2,'#6a4a2a');rect(g,7,16,10,1,'#5a3a2a');        // stubble
  rect(g,6,13,1,1,'#7a1a1a');rect(g,17,13,1,1,'#7a1a1a');}),'#0e1016');
SP.port.brum=autoOutline(makeSprite(24,24,g=>{
  portBase(g,{skin:'#c88a62',skinD:'#a86a48',cloth:'#5a3a22',clothL:'#8a5a32',eye:'#2a1a0a'});
  rect(g,6,3,12,3,'#3a2a1a');rect(g,6,5,2,4,'#3a2a1a');rect(g,16,5,2,4,'#3a2a1a');           // thick hair
  rect(g,7,8,4,2,'#2a1a0a');rect(g,13,8,4,2,'#2a1a0a');                                      // heavy brows
  rect(g,5,14,14,7,'#7a3a1a');rect(g,7,19,10,3,'#9a4a22');rect(g,9,15,6,1,'#7a3a1a');rect(g,10,16,4,1,'#8a3a30');  // red beard
  rect(g,8,6,3,1,'#2a2a2a');rect(g,12,12,1,1,'#2a2a2a');rect(g,15,7,2,2,'#2a2a2a');          // soot
  rect(g,3,20,4,3,'#a0a0a8');rect(g,17,20,4,3,'#a0a0a8');}),'#140a04');
SP.port.pip=autoOutline(makeSprite(24,24,g=>{
  portBase(g,{skin:'#f0c8a0',skinD:'#d0a880',cloth:'#4a8a4a',clothL:'#7ac27a',eye:'#2a5a2a',mouth:'#c05a4a'});
  rect(g,5,2,14,4,'#d8902a');rect(g,4,4,3,6,'#d8902a');rect(g,17,4,3,5,'#d8902a');rect(g,8,5,6,2,'#e8b050');rect(g,15,5,2,3,'#e8b050');  // tousled hair
  rect(g,8,13,2,1,'#e8a090');rect(g,14,13,2,1,'#e8a090');rect(g,9,15,6,2,'#fff');rect(g,10,16,4,1,'#c05a4a');   // freckles + grin
  rect(g,6,3,12,1,'#5a8a3a');}),'#0c180c');
SP.port.aldric=autoOutline(makeSprite(24,24,g=>{
  const sk='#b8e8d0';
  rect(g,3,19,18,5,'#1c4a3a');rect(g,4,18,16,2,'#2a7a5a');rect(g,9,17,6,3,'#7ab8a0');
  rect(g,6,5,12,13,sk);rect(g,7,4,10,1,sk);rect(g,6,9,1,6,'#8ac0a8');rect(g,17,9,1,6,'#8ac0a8');
  rect(g,7,9,4,4,'#0a1a14');rect(g,13,9,4,4,'#0a1a14');rect(g,8,10,2,2,'#7dffa0');rect(g,14,10,2,2,'#7dffa0');rect(g,8,10,1,1,'#fff');rect(g,14,10,1,1,'#fff');  // glowing eyes
  rect(g,11,13,2,2,'#4a7a68');rect(g,8,16,8,2,'#0a1a14');rect(g,9,16,1,2,sk);rect(g,11,16,1,2,sk);rect(g,13,16,1,2,sk);rect(g,15,16,1,2,sk);   // teeth
  rect(g,5,16,2,4,'#e8f2ee');rect(g,17,16,2,4,'#e8f2ee');rect(g,7,19,10,2,'#e8f2ee');         // wispy beard
  rect(g,5,1,14,4,'#2a6a4a');rect(g,5,0,2,3,'#7dffa0');rect(g,9,-1,2,4,'#7dffa0');rect(g,13,-1,2,4,'#7dffa0');rect(g,17,0,2,3,'#7dffa0');  // hollow crown
  rect(g,7,3,10,1,'#b0ffd0');rect(g,11,2,2,1,'#fff');}),'#04100a');
SP.port.narr=makeSprite(24,24,g=>{rect(g,4,3,16,18,'#2a2a48');rect(g,5,4,14,16,'#3a3a68');rect(g,8,7,8,1,'#cfd0ff');rect(g,8,10,8,1,'#cfd0ff');rect(g,8,13,6,1,'#cfd0ff');rect(g,8,16,7,1,'#cfd0ff');rect(g,11,2,2,2,'#ffd23f');});
