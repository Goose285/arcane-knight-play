/* =====================================================================
   GREY STONE CASTLE WALL (t139u, after Seth's reference kit): crenellated grey brick wall with moss at the base, twin gate towers with
   blue + gold banners, an arched gatehouse with a raised portcullis and lanterns. Used for Oakvale's SOUTH town wall (the plain B / BT
   tiles there are re-drawn, ids + collision unchanged) and as new editor Walls pieces:
     WSB straight wall (joins) | WPI pillar | WOC outer corner | WIC inner corner | WTB tower with banner | WPT gatehouse + portcullis (walkable)
     WGP stone gate pillar with lantern  (+ the existing low / ruined / ivy (mossy) / wooden double gate pieces)
   ===================================================================== */
Object.assign(T,{WSB:87,WPI:88,WOC:89,WIC:90,WTB:91,WPT:92,WGP:93});
[T.WSB,T.WPI,T.WOC,T.WIC,T.WTB,T.WGP].forEach(t=>{SOLID.add(t);XWALLS.add(t);});WALL_IDS.add(T.WSB);
const SW=(()=>{
  const O='#3a3236',S='#a49c92',L='#c8c0b2',D='#7a7268',M='#6a625a',r=(g,x,y,w,h,c)=>rect(g,x,y,w,h,c),px=(g,x,y,c)=>rect(g,x,y,1,1,c);
  const bricks=(g,x0,y0,x1,y1,seed)=>{r(g,x0,y0,x1-x0,y1-y0,S);for(let y=y0;y<y1;y+=4){r(g,x0,Math.min(y+3,y1-1),x1-x0,1,M);const off=((y>>2)+seed)%2?0:4;
      for(let x=x0+off;x<x1;x+=8){r(g,x,y,1,3,M);r(g,x+1,y,Math.min(5,x1-x-1),1,L);}}};
  const moss=(g,y,seed)=>{for(let x=0;x<16;x++){const h=hash2(x+seed,y)%4;if(h<2){r(g,x,y-h,1,h+1,'#6fa24a');if(h===1)px(g,x,y-h,'#9ccc6a');}}};
  const crown=(g,y,seed,L0,R0)=>{   // merlons (4 wide, gaps 4) + a coping band below them
    for(let x=0;x<16;x+=8){r(g,x+1,y,3,1,O);r(g,x,y+1,5,4,O);r(g,x+1,y+1,3,4,S);r(g,x+1,y+1,3,1,L);px(g,x+1,y+1,'#d8d0c2');}
    r(g,0,y+5,16,3,O);r(g,0,y+6,16,1,L);r(g,0,y+7,16,1,D);if(L0)r(g,0,y,1,y+8,O);if(R0)r(g,15,y,1,8,O);};
  const grass=g=>g.drawImage(TSPR[T.G][0],0,0);
  const banner=(g,x)=>{r(g,x-1,1,8,2,O);r(g,x,1,6,1,'#e0b43a');r(g,x,3,6,9,O);r(g,x+1,3,4,8,'#2f5ab8');r(g,x+1,3,1,8,'#4a7ae0');r(g,x+1,11,2,2,'#2f5ab8');r(g,x+3,11,2,2,'#2f5ab8');
    px(g,x+2,13,'#e0b43a');r(g,x+2,6,2,2,'#e0b43a');r(g,x,3,1,10,'#e0b43a');r(g,x+5,3,1,10,'#e0b43a');};
  const lantern=(g,x,y)=>{r(g,x,y,4,6,O);r(g,x+1,y+1,2,4,'#ffd060');px(g,x+1,y+1,'#fff4c0');r(g,x+1,y-1,2,1,O);};
  const C=new Map(),mk=(k,f)=>{let s=C.get(k);if(!s){s=makeSprite(16,16,f);C.set(k,s);}return s;};
  // ---- Oakvale's south wall ----
  const TY1=()=>Math.floor(TOWN.y1/TS),inX=x=>x>=Math.floor(TOWN.x0/TS)-3&&x<=Math.ceil(TOWN.x1/TS)+3;
  const isW=id=>id===T.B||id===T.BT;
  function zone(x,y){const ty=TY1();if(y<ty-2||y>ty+1||!inX(x))return null;const R1=map[ty-1],R0=map[ty-2];if(!R1)return null;
    const tower=R0&&R0[x]===T.BT&&isW(R1[x]);const gateL=R1[x]===T.P&&isW(R1[x-1]),gateR=R1[x]===T.P&&isW(R1[x+1]);
    return {row:y-(ty-2),tower,tl:tower&&R0[x-1]!==T.BT,gateL,gateR,wall:isW(R1[x])};}
  function southTile(x,y){
    const z=zone(x,y);if(!z)return null;const id=map[y][x];
    if(z.tower&&isW(id)){const k='t'+z.row+(z.tl?'l':'r')+(x&1);return mk(k,g=>{
      if(z.row===0){grass(g);r(g,0,12,16,4,O);crown(g,2,x,z.tl,!z.tl);bricks(g,z.tl?1:0,10,z.tl?16:15,16,1);r(g,z.tl?0:15,10,1,6,O);}
      else if(z.row===1){bricks(g,z.tl?1:0,0,z.tl?16:15,16,x);r(g,z.tl?0:15,0,1,16,O);if(z.tl)banner(g,10);else r(g,4,4,2,6,O);}
      else{bricks(g,z.tl?1:0,0,z.tl?16:15,16,x+1);r(g,z.tl?0:15,0,1,16,O);r(g,z.tl?10:4,2,2,6,O);moss(g,15,x);r(g,0,15,16,1,'rgba(20,24,44,.4)');}});}
    // (t143u: the t142u walk-over gate span was removed - the gate is a plain open gap between the two banner towers)
    if(z.wall&&isW(id)){const k='w'+z.row+(x&1)+(map[y][x-1]===T.P?'L':'')+(map[y][x+1]===T.P?'R':'');return mk(k,g=>{
      if(z.row===1){grass(g);crown(g,3,x,false,false);bricks(g,0,11,16,16,x);}
      else if(z.row===2){bricks(g,0,0,16,15,x+1);moss(g,15,x);r(g,0,15,16,1,'rgba(20,24,44,.45)');}
      else return;});}
    return null;
  }
  const L0c='#c8c0b2';
  // ---- editor pieces ----
  const isSW=id=>id===T.WSB||id===T.WPI||id===T.WOC||id===T.WIC||id===T.WTB;
  function piece(id,x,y,thumb){const l=!thumb&&x>0&&isSW(map[y][x-1]),rr=!thumb&&x<map[y].length-1&&isSW(map[y][x+1]);const k='p'+id+(l?1:0)+(rr?1:0)+(x&1);return mk(k,g=>{
    grass(g);
    if(id===T.WSB){crown(g,1,x,!l,!rr);bricks(g,!l?1:0,9,!rr?15:16,15,x);if(!l)r(g,0,9,1,6,O);if(!rr)r(g,15,9,1,6,O);moss(g,15,x);r(g,0,15,16,1,O);}
    else if(id===T.WPI){r(g,3,0,10,16,O);bricks(g,4,5,12,15,x);for(let i=4;i<12;i+=4){r(g,i,0,3,4,S);r(g,i,0,3,1,L);}r(g,3,4,10,1,L);moss(g,15,1);}
    else if(id===T.WOC){r(g,2,0,12,16,O);bricks(g,3,5,8,15,0);bricks(g,8,5,13,15,1);r(g,8,5,1,10,D);for(let i=3;i<13;i+=4){r(g,i,1,3,3,S);r(g,i,1,3,1,L);}r(g,3,4,10,1,L);moss(g,15,2);}
    else if(id===T.WIC){crown(g,1,x,false,false);bricks(g,0,9,7,15,0);bricks(g,8,9,16,15,1);r(g,7,1,2,14,D);r(g,7,1,1,14,O);moss(g,15,3);}
    else if(id===T.WTB){r(g,1,0,14,16,O);bricks(g,2,4,14,15,x);for(let i=2;i<14;i+=4){r(g,i,0,3,3,S);r(g,i,0,3,1,L);}r(g,2,3,12,1,L);banner(g,5);moss(g,15,4);}
    else if(id===T.WGP){r(g,4,1,8,15,O);bricks(g,5,3,11,15,x);r(g,3,0,10,3,O);r(g,4,0,8,2,L);lantern(g,6,6);moss(g,15,5);}
    else if(id===T.WPT){g.drawImage(TSPR[T.P][0],0,0);r(g,0,0,3,16,S);r(g,13,0,3,16,S);r(g,2,0,1,16,O);r(g,13,0,1,16,O);r(g,3,0,10,5,'#1a1622');
      for(let i=4;i<13;i+=3)r(g,i,0,1,5,'#6a4a2a');r(g,3,4,10,1,'#6a4a2a');lantern(g,0,4);moss(g,15,6);}
  });}
  for(const id of [T.WSB,T.WPI,T.WOC,T.WIC,T.WTB,T.WPT,T.WGP]){XTILE_FN[id]=(x,y)=>piece(id,x,y);TSPR[id]=[piece(id,0,0,true)];TSPR.mini[id]=id===T.WPT?'#2a2436':'#8e8e9c';}
  return {southTile,zone};
})();
