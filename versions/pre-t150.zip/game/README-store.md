# Arcane Knight: Realm of Embers - app store guide

Everything lives in `/workspace/arcane-knight/` (symlink `/workspace/megaman-medieval` is a leftover alias - delete it, it is not used by the app).

```
index.html                 the whole game (single file, no assets) - source of truth
manifest.webmanifest, sw.js, icons/    PWA (installable + offline)
app/                       Capacitor project (android/ and ios/ native projects, www/ = copy of the web build)
dist/ArcaneKnight-debug.apk   debug APK built on this box (sideload/test only)
store/                     app-icon-1024.png, Google Play feature graphic, screenshots for iPhone / iPad / Android
PRIVACY.md                 privacy-policy template (host it at a public URL)
```

App id: **com.sethmoynahan.arcaneknight** (change in `app/capacitor.config.json` *before* the first upload - it can never be changed after publishing).
Version: 1.0 (build 1) - edit `versionCode`/`versionName` in `app/android/app/build.gradle` and Version/Build in Xcode; both must increase on every upload.

## 0. Day-to-day workflow
1. Edit the game (`index.html`). Bump `VERSION` in `sw.js` so installed PWAs refresh.
2. `cd app && npm run sync` (copies index.html/icons/manifest/sw into `www/` and runs `cap sync`).
3. Android: `npm run android:debug` (APK) or `npm run android:release` (AAB for Play). iOS: `npx cap open ios`, build in Xcode.
4. Regenerate icons/splash only if you change the art: put `icon-only.png`, `icon-foreground.png`, `icon-background.png`, `splash.png`, `splash-dark.png` in `app/assets/` and run `npm run icons`.

Android toolchain used on this box (already installed, not needed on your machine if you use Android Studio):
JDK 21 `/workspace/jdk`, SDK `/workspace/android-sdk` (platform-35/36, build-tools 35). Env: `export JAVA_HOME=/workspace/jdk ANDROID_HOME=/workspace/android-sdk PATH=$JAVA_HOME/bin:$PATH`.
On your own machine: install Android Studio (or JDK 21 + cmdline-tools), run `npx cap open android`.

## 1. Google Play ($25 one-time)
1. Create a developer account at https://play.google.com/console ($25, ID verification; new *personal* accounts must run a **closed test with 12+ testers for 14 days** before production access - plan for it).
2. **Create app** -> name "Arcane Knight: Realm of Embers", Game, Free, accept policies.
3. **Sign the build** (Play requires an AAB signed with an upload key):
   ```
   keytool -genkeypair -v -keystore arcane-knight-upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000
   ```
   Keep the keystore + passwords backed up (never commit). Add a `signingConfigs.release` block to `app/android/app/build.gradle`
   (storeFile/storePassword/keyAlias/keyPassword) and `signingConfig signingConfigs.release` in `buildTypes.release`, then `cd app && npm run android:release`.
   Output: `app/android/app/build/outputs/bundle/release/app-release.aab`. Enroll in **Play App Signing** when prompted (default).
4. Upload the AAB to **Testing -> Closed testing** (then Production). Fill in the store listing:
   * Short description (80 chars), full description (4000), category Games > Role Playing (or Action).
   * **App icon 512x512** - `icons/icon-512.png` (or `store/app-icon-1024.png` downscaled). 
   * **Feature graphic 1024x500** - `store/google-play-feature-graphic-1024x500.png`.
   * **Phone screenshots** (2-8, 16:9 to 9:16, 320-3840 px) - `store/screenshots/google-play-phone-1080x1920/*.png`. Tablet screenshots (7"/10") recommended - the iPad set can be reused.
5. **App content** forms: Privacy policy URL (host `PRIVACY.md`), Ads: No, App access: no login, Content rating questionnaire (expect Teen/PEGI 7-12: fantasy violence), Target audience 13+ (avoids Families-policy requirements), **Data safety**: "No data collected / shared", News app: No.
6. Review typically takes a few days. 

## 2. Apple App Store ($99 / year)
Requires a Mac with Xcode (not possible on this Linux box). The iOS project is ready in `app/ios/App`.
1. Enroll in the **Apple Developer Program** at https://developer.apple.com/programs/ ($99/yr, individual or organization).
2. On a Mac: install Xcode, Node 22+, then `cd app && npm install && npm run sync && npx cap open ios`.
   (Capacitor 8 iOS uses Swift Package Manager - no CocoaPods needed.)
3. In Xcode: select the *App* target -> **Signing & Capabilities** -> pick your Team, keep bundle id `com.sethmoynahan.arcaneknight`. Set Version 1.0, Build 1. Deployment target iOS 15+. Icons/launch screen are already generated (`Assets.xcassets`).
4. In **App Store Connect** (https://appstoreconnect.apple.com) -> My Apps -> **+** New App: platform iOS, name, language, bundle id, SKU (any unique string).
5. Xcode: *Product -> Destination: Any iOS Device -> Product -> Archive -> Distribute App -> App Store Connect -> Upload*.
6. Test with **TestFlight** (internal testers need no review), then fill the listing and **Submit for Review**:
   * Screenshots: **6.9"/6.5" iPhone** (1284x2778 provided, 1320x2868 for 6.9") and **13" iPad** (2064x2752 provided; needed because the app runs on iPad) - `store/screenshots/ios-*`.
   * App icon 1024x1024 (no alpha) - `store/app-icon-1024.png` (already in the Xcode asset catalog).
   * Description, keywords (100 chars), support URL, marketing URL (optional), **privacy policy URL** (host `PRIVACY.md`).
   * **App Privacy** questionnaire: "Data Not Collected". Export compliance: no encryption beyond OS (answer No/exempt). Age rating questionnaire (expect 9+/12+: cartoon/fantasy violence).
   * Apple guideline 4.2 ("minimum functionality") - wrapped web apps get rejected if they feel like a website. This one is a complete offline game with save/load, which is fine; mention "fully native-wrapped game, works offline" in the review notes.
7. Review usually takes 1-2 days.

## 3. Trademark / IP checklist before you submit
* Game, spell and file names are original (Frost Bolt / Frost Burst / Crimson Bolt / Crimson Burst, Arcane Knight, Emberfang). All art and sound are generated by code - no third-party assets.
* Search the title on https://tmsearch.uspto.gov and both stores to make sure "Arcane Knight" isn't a conflicting registered game name; there are other games with similar names, so consider a more unique subtitle or a trademark search before launch.
* Publisher/developer name shown in stores = the name on your developer account.

## 4. Web / PWA (free, no store)
Host the folder (`index.html`, `manifest.webmanifest`, `sw.js`, `icons/`) on any HTTPS static host (GitHub Pages, Netlify, Cloudflare Pages). Users can "Add to Home Screen"; it works offline after the first load (verified: service worker caches 14 files, game boots offline).

## 5. Known limits
* The debug APK is unsigned for release and only for testing (`adb install dist/ArcaneKnight-debug.apk`). It was built but **not launched** on an emulator/device on this box (no emulator/KVM).
* The iOS project was generated but not built (needs macOS/Xcode).
