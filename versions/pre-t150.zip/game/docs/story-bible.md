# Arcane Knight: Realm of Embers — Story Bible

Status: working canon, written against `src/data/story.js`, `src/data/quests.js`, `src/data/npcs.js`, `src/player/church.js`, `src/data/enemies.js`, `src/data/secrets.js`, `src/data/world-extras.js` as of v19.
Anything marked **[canon]** is already in the game's text or data. Anything marked **[extension]** is new connective lore proposed here so writers have one consistent answer; it contradicts nothing in the game and can be introduced gradually.

---

## 1. The pitch

A young hero (the player, "HERO" — a knight in a cream-and-gold sun-plate) is the newest guardian of **Oakvale**, a cozy riverside village. North of the village, up the Castle Road, sits **Castle Dracoryn**, ruled for seven winters by a dragon and ringed by the walking dead. Under the castle lies the **Crypt of Hollow Kings**, and under the crypt, held down by an old seal, lies the **Ashen Tide**.

The game is a hopeful story about a small light holding the line against a very large dark, told by people who are scared and keep showing up anyway.

## 2. Tone and themes

**Cozy town, dangerous wild.** Oakvale is warm: lanterns, a fountain that heals, a chapel that is always open, a kid who wants slime gel. Past the gate the world is genuinely dangerous: cones of sight, ambushes, bosses that outscale you if you rush. The contrast is the point. Safe places should feel *earned* and *protected* (hence the Town Guard: "no monster sets foot in Oakvale while the Guard stands").

**Hopeful, not grim.** Death and decay are present (undead, a lich, a bog, a ruin), but the story's answer to them is care, memory, courage and kindness. No cruelty-for-shock. Even the villain-shaped figure (Aldric) turns out to have been a protector.

**Faith and light versus darkness.** [canon] Father Anselm quotes scripture (Joshua 1:9, Isaiah 40:31, Psalm 23:4) and offers a free blessing that heals fully and saves the game. The visual language: sun, gold, lanterns, campfire, chapel windows against ash, green witch-fire, hollow green crown-fire. Light is not a weapon in itself; it is **company, shelter, and refusing to leave someone alone in the dark**. Keep faith sincere and gentle: never preachy, never mocked, never required (the player can ignore Anselm and still win).

**Reconciliation over conquest.** The best outcomes come from listening (Orin, Hale, Aldric all reward the player who listens). Combat is how the hero earns the right to be heard.

**Voice.** Short sentences, concrete nouns, a little dry humor from the adults, none from the dead. Pip is the exclamation marks. Hale speaks in half-sentences. Orin tells you what he is *not* saying. Aldric is formal and tired. Text lines in dialogue should be one to three sentences; cutscene beats are 3–6 lines.

**Never:** modern slang, sarcasm toward faith, gore, cruelty to animals, real-world denominations or politics. Scripture quotes are public-domain KJV wording only.

## 3. World

### The valley and its places

| Place | In game | Role |
|---|---|---|
| **Oakvale** | Village, SW | Home base: houses, fountain, Brum's forge, Orin, the notice board, Marlo's menagerie, Arena Master, the **Oakvale Chapel** (Father Anselm), the riverside (Fisher Tobin), the player's house. Monsters cannot enter; two **Town Guards** (level 30, blue-and-steel plate) stand at the north-fence gap and the east bridge. [canon] |
| **Greenmeadow** | Meadow N of village | Starter wilds. Slimes, the training ground; the thicket with Orin's lost signet; the **crypt stairs** in the northwest. [canon] |
| **Whisperwood** | Forest E | Goblin warrens, bone cages, the pond. The Whisperwood Waystone. First spawner braziers. [canon] |
| **Castle Road / Castle Dracoryn** | North | The Gate Guard's post; the courtyard; Emberfang on the throne; the castle interior is Emberfang's territory. [canon] |
| **Crypt of Hollow Kings** | Under the meadow stairs | Bats, wraiths, the grave-flame braziers, the throne hall of the **Lich King**. [canon] |
| **Frosthowl Pass** | Snow region | Frost wolves, Rime Brutes; boss **Rimegar the Frost Titan**; Frosthowl Waystone. [canon] |
| **Mirewood Bog** | Swamp region | Bog toads, Mire Witches; boss **Old Mossback the Bog Hydra**; Mirewood Pool; Mirewood Waystone. [canon] |
| **Sundered Ruins** | Desert region | Dune scorpions, Dust Mummies; boss **The Sundered Colossus**; Sundered Oasis; Sundered Waystone. [canon] |
| **Ember Arena** | Beyond the village | Boss Rush / weekly vault run, run by the Arena Master. [canon] |

### Waystones [canon] / lore [extension]
Six waystones fast-travel between places. **[extension]** They are the **Vael road-lights**: King Aldric had them raised across the valley so no traveler would ever be more than a day from light. The three regional waystones (snow, bog, desert) stand in the shadow of the three Titans because the road-lights were the first things the Tide's leak corrupted. Re-lighting a stone is "restoring a candle Aldric left burning".

### The Seal and the Hollow Crown
**[canon]** King Aldric Vael forged the **Hollow Crown** to bind "something beneath the castle". The crown is bound to a seal; the seal holds the **Ashen Tide**. The crown held *him* to the seal ("I could not stop"). The Hollow Crown can be **renewed, carried, or broken**.

### The Ashen Tide
**[canon]** Named by Aldric as patient ("The Tide is patient, but I am not"); it is what the seal holds, and in the *Free* ending it "must now be faced".
**[extension]** The Tide is not a monster or a god, it is a *rising* — a flood of ash-cold nothing that does not think, it only wears things down: warmth, names, memory, light. It cannot be killed, only held, turned back, or outlasted. Its signs: ember-grey drifting ash, lanterns guttering, the dead standing up *against their will*, the three Titans losing their reason. It never speaks; when something "speaks for it" (a corrupted Titan, a wraith) that is the Tide's echo in a mouth that is not its own. It is afraid of nothing, and it is stopped by *being remembered by someone who stays*. (This is why Orin, Hale and Anselm matter mechanically: trust, perks, blessings.)

## 4. Characters

### The hero [canon]
Silent protagonist ("HERO"), a new knight of Oakvale. The Sun Paladin look: cream/gold plate, gold plumed helm, cream cape with a gold sun, round gold sun shield. Defined by choices at three beats (the Lich King's questions, Hale's secret, the Hollow Crown). Never given a name or backstory in text; the sequel should keep this open.

### Elder Orin [canon]
Oakvale's old, soft-voiced storyteller and the village's moral center. Gives the Slime Trouble, The Lost Signet and Bane of the Hollow King quests, and the chapter 1 and 5 scenes. Perk at full trust: **Orin's Blessing, +10% XP**. He half-believes the legend that Aldric turned lich ("Folk say the king turned lich... Folk say many things") and wants to be proven wrong. Speaks in winters (years), not years. Warm, careful, a little wry. **[extension]** He was a boy in Castle Dracoryn's kitchens under King Aldric; his mixed fear and love for the old king explains why he asks the hero, not an army.

### Captain Hale (the Gate Guard) [canon]
Posted at the castle gate for seven winters; the only witness. Gives Goblin Menace and Into the Crypt. He saw Aldric on the battlements crowned in green fire, *screaming at the dead to go back down* — not raising them. He has told no one. Half-sentences, soldier's economy. Perk at full trust: **Hale's Drills, +12 max health**. Arc: guilt about silence → relief at being believed (or bitterness if the hero spreads it). **[extension]** He once served in Aldric's household guard and swore to Sera that he would "keep the gate until someone comes who can bear it".

### Brum the Smith [canon]
Blacksmith at the village forge; sells cards and arcane-shot reforges; gives Goblin Iron. Gruff, generous, loyal to people not causes. Perk at full trust: **Brum's Friend Price, workbench gold costs -20%**. He measures everyone by what they bring back from the wild. **[extension]** His forge-fire was lit from a coal carried out of Castle Dracoryn the night Aldric vanished: a small, literal "ember of the old kingdom" in the village.

### Pip [canon]
The kid who loves slime gel and loud skeletons. Gives Goo for Pip and Rattling Bones. Perk at full trust: **Pip's Lucky Charm, +25% card drop chance**. Pip is hope in the form of a nine-year-old: tells everyone the hero is amazing, fears nothing because no one has told him to. Never put Pip in real danger on screen. **[extension]** Pip's lost father was one of the knights who went up the Castle Road in the first winter. Pip does not mention it.

### King Aldric Vael [canon]
Last king of Dracoryn. Vanished from the castle seven winters ago; the dead rose; a dragon took the courtyard. Forged the Hollow Crown. In the crypt he appears as the **Lich King** (boss, three phases), formal, tired, trying to warn the hero ("Turn back, little knight") while the crown forces him to fight. When freed: "I could not stop." He wants three things: his people safe, his daughter remembered, the crown *ended well*. Every dialogue branch lets him be gentle.

### Sera Vael [canon: named, off-screen]
Aldric's daughter. She **bonded a dragon (Emberfang) to guard the courtyard** — not to terrorise the valley but "to keep the villagers away from the stairs - to keep them from [the king]". She is the unseen heart of the story. **[extension]** Sera did not die: she stayed. The ember in Emberfang's chest is her bond-flame; the dragon fights because Sera asked it to hold the courtyard "until someone comes who can end it". Emberfang's trophy ("Emberfang Tooth") and the weapon "Emberfang Edge" are relics of that bond. She is the strongest sequel hook (see §10).

### Emberfang the Dragon [canon]
Castle Dracoryn's first boss (territory: the castle interior; two phases; freeze-resistant). Treated by the village as a monster; in truth a loyal guardian. Tone for any future scene: **sorrowful, not evil**. First defeat guarantees the **Reflect** card (see §8).

### Father Anselm [canon]
Priest of Oakvale Chapel: "Oakvale Chapel has stood here since before the dragon woke." Offers a free blessing (full heal + the game is saved) and a verse (Joshua 1:9, Isaiah 40:31, Psalm 23:4, plus two plain-spoken encouragements). Sincere, unhurried, never pushy; says "friend" and "traveler". He is the player's safe room. **[extension]** He kept the chapel bell silent for seven winters ("no bell the dead can answer"); the first time it tolls again should be a payoff in the sequel.

### Fisher Tobin [canon]
Old riverside fisher with tired knees; teaches fishing (rod lent if you have none) and runs A Line in the Water / The Quiet Waters. Patient, gentle humor ("the fish have gotten shy of me"). Reward at the end of his chain: a ring and the **Poison Cloud** card ("a card from the bog pools"). **[extension]** He fished the river that runs past the old castle wall; he knows which pools "taste like ash" when the Tide is near.

### The rest of the cast [canon]
- **Marlo the Keeper**: pet adoption (Cinderpup, Rime Wisp, Gloam Moth, Pebblin). Warm, animal-first.
- **Arena Master**: runs the Ember Arena boss rush. Brisk, a bit theatrical.
- **Town Guards** (two, level 30): "Monsters are not allowed past these gates." Armoured, kind to the hero. They defend their posts on their own: any hostile within five tiles of a guard is struck down (bosses are driven off), whether or not the hero is fighting; they step out a little, then return to their post.
- **Notice Board**: daily and weekly challenges.

## 5. The Hollow Crown (main plot) [canon]

Five chapters (the chronicle shows them as **"The Hollow Crown"** questline):

1. **Whispers in Oakvale** (Orin; unlocked at level 3 or after Slime Trouble). Orin tells the legend: Aldric vanished seven winters ago; the dead walked; a dragon took the courtyard. Choice: hear the whole legend (+Orin trust) or keep it short. Seeds the Hollow Crown.
2. **The Sleepless Guard** (Hale; after Goblin Menace or level 5). Hale confesses he saw the king screaming at the dead to go back down. Choice: keep the secret (+2 Hale), tell the village (−1 Hale, +1 Orin), or ask why he tells a stranger (+1 Hale).
3. **The Voice in the Dark** (descend to the Crypt). Aldric speaks from the dark and warns the hero off. Choice: come to end the curse / to listen (+Orin trust, flag) / for the crown (flag: greed).
4. **The Hollow Crown** (kill the Lich King). The fire gutters; Aldric thanks the hero, names Sera and Emberfang, and gives the three choices. (Dialogue changes if the hero listened or showed greed.)
5. **What Oakvale Remembers** (back to Orin). Epilogue scenes vary by ending and by who trusts you (Hale, Brum, Pip each speak if trust >= 2).

The Lich King quest ("Bane of the Hollow King") pays gold, XP, legendary gear and the **Time Stop** and **Curse** cards.

## 6. The three endings [canon]

All three are valid and "complete". The choice is a values statement, not a right/wrong test.

| Ending | Choice | What it means | Reward | Village reaction |
|---|---|---|---|---|
| **The Ember Crown** (`ember`) | Take the crown for yourself | Power over safety; the hero becomes the new seal-bearer, alone | Legendary **Ember Crown Band** ring, +15 max HP | Villagers keep their distance; trust drops with everyone |
| **The Warden's Oath** (`warden`) | Return the crown to Orin to renew the seal | Duty and community; the old order is restored | +500 G and an epic card | Orin and Hale trust you more; "Oakvale sleeps soundly" |
| **The Shattered Seal** (`free`) | Break the crown | Freedom over safety; no more bound souls, but the Tide is loose to face | +250 G, +400 XP, an epic card | Brum and Pip trust you more; "we shall face the Tide together" |

Narrative notes:
- *Ember* is **not** a villain ending. The hero keeps the crown's weight so no one else has to; the cost is loneliness.
- *Warden* is the traditional ending and the one that most respects Aldric's own work.
- *Free* turns the Tide from a buried threat into a *horizon*: the sequel's natural engine.
- Writers must keep the ending flag consistent. After the game: Orin's epilogue always says "the Realm of Embers is yours to roam... there is more beyond the pass" — leave that door open.

## 7. Zone lore and bosses

### Castle Dracoryn and the Dragon
The royal seat. The castle is where Aldric disappeared and where Emberfang stands guard. The Gate Guard's post marks the edge of the safe valley.

### Crypt of Hollow Kings
**[canon]** Torch-lit halls of bats and wraiths; spawners called *Grave-Flame Braziers* and the *Hollow King's Cage*; the Lich King holds the throne hall. **[extension]** The crypt is not a tomb of villains, it is where Dracoryn's kings *chose* to be buried near the seal so that their sleeping minds would add strength to it. The dead rising against their will is the Tide pulling on them.

### Frosthowl Pass — Rimegar the Frost Titan
Snowbound mountain road; frost wolves and Rime Brutes. **[extension]** Rimegar is a mountain guardian raised in the old kingdom's day to keep the northern pass closed; the Tide's cold got inside it. Its treasure map (Frost-Stained Map) leads to a rare card. Defeat guarantees **Summon Wolf** (a spirit of the pass answering a hero who proved worthy).

### Mirewood Bog — Old Mossback the Bog Hydra
Wet, green and hungry; toads, Mire Witches, hex braziers. **[extension]** The witches are not evil: they stayed to tend a spreading sickness in the water, and the Hydra is what the sickness woke. Mossback's map (Mildewed Map) gives a rare card; Fisher Tobin warns about "pools that taste of ash".

### Sundered Ruins — The Sundered Colossus
A sun-baked ruin of cracked statuary; scorpions, Dust Mummies, sun-rune braziers. **[extension]** Once a monument to the first Vael king, split by an old quake and now animated by the Tide as an echo of "a kingdom that kept things in order". Its map (Sun-Bleached Map) gives a rare card.

### Whisperwood
The forest is the village's larder and its worry. Goblins nest in warrens; a pond at the heart (fishing). **[extension]** The wood *whispers* because the Tide's silence presses on it from underneath — hence the name.

### Ember Arena
**[extension]** A sparring ring where the Titans' *echoes* are held in the old training-stones, so that heroes can practice without risking the real thing. Boss-rush clones never count for story rewards (they are echoes).

### Oakvale
The only true safe place: Guards at the gates, a chapel that never locks, a fountain that heals. When it is threatened, the guards intervene and the fight ends safely: the world's way of saying *home is home*.

## 8. Cards, rewards, and what they mean in-world

The Hollow Crown story pays out the **Time Stop** and **Curse** cards (Lich King). A set of normally hard-to-get cards are now **guaranteed rewards** from named milestones (drops still possible on top). The in-fiction logic:

| Card | Source | Why it fits |
|---|---|---|
| Haste | Quest: Slime Trouble (Orin) | Orin teaches speed: "you will need to outrun trouble". |
| Chain Lightning | Quest: Goblin Menace (Hale) | Hale's drills: strike one, hit the line. |
| Holy Ward | Quest: The Lost Signet (Orin) | The signet is a ward-mark of Oakvale's founders. |
| Shadow Step | Quest: Into the Crypt (Hale) | Learned from surviving the dark. |
| Curse | Quest: Bane of the Hollow King (Orin) | Aldric's own curse, made harmless in your hand. |
| Poison Cloud | Quest: The Quiet Waters (Tobin; fishing milestone) | Learned from the bog pools. |
| Reflect | Boss: Emberfang (first defeat) | Sera's bond-flame turns back what strikes it. |
| Summon Wolf | Boss: Rimegar (first defeat) | A spirit of the pass answers you. |
| Decoy | First monster spawner destroyed | The trick every scout learns: leave something behind. |

## 9. Village perks and trust (systems tie-in) [canon]
Trust with Orin, Hale, Brum and Pip changes with dialogue choices (needs 2 for the perk): **XP**, **max health**, **forge discount**, **card drop chance**. Writers: each choice should feel like *being a decent person*, not a stat optimisation.

## 10. Sequel hooks

Pick one or combine; each respects the endings.

1. **Sera.** Emberfang is her bond. Either the hero finds her beyond the pass or she comes to Oakvale. Warden: she returns to reclaim a renewed seal; Free: she arrives to help face the Tide; Ember: she judges the hero for taking the crown.
2. **The Tide rises.** After *Free*, the Tide leaks along the Vael road-lights, dimming waystones one by one. A re-lighting campaign: restore each stone, each with a tiny story and a boss echo.
3. **The Pass.** Orin's last line ("there is more beyond the pass") points to a region past Frosthowl, where Aldric's *other* seal anchors sit; the bell of Oakvale Chapel is the new quest-giver.
4. **The next Warden.** After *Warden*, Orin is too old to keep the crown; the village needs a new keeper. Who? Pip, grown up, as a possible NPC successor.
5. **The Ember Crown's weight.** After *Ember*, the crown whispers; a rival claimant from the Sundered Ruins arrives wanting to take it.
6. **The Arena's echoes.** The boss-rush echoes begin to act on their own; the Arena Master asks for help.
7. **Trust payoffs.** Hale, Brum, Pip and Anselm each hold a small side-arc waiting: Hale's oath to Sera, the forge-coal from the castle, Pip's father, the silent bell.

## 11. Style cheat-sheet

- **Names:** Oakvale, Dracoryn, Vael, Hollow Crown, Hollow Kings, Ashen Tide, Emberfang, Frosthowl, Mirewood, Sundered, Whisperwood, Greenmeadow. Titles use "the X" for guardians (Frost Titan, Bog Hydra).
- **Colours:** cream and gold (hero, chapel), ember orange (Emberfang, forge), ash-grey (Tide), green fire (Aldric, witches), steel-blue (guards).
- **Light motif:** lanterns mark safety; guttering lanterns mark the Tide; the sun is the hero's sigil.
- **Dialogue rules:** each speaker has a consistent verbal tic (Pip: caps and exclamation, Hale: breaks, Orin: winters and "hero", Anselm: "friend", Aldric: "little knight", Brum: "friend" with a grunt).
- **Writing for the player:** always at least one gracious option in every choice; no punishments for kindness; trust changes are small and shown by a toast, not by a lecture.

## 12. Consistency checklist (before adding any new text)

- Does it fit *seven winters* since Aldric vanished?
- Does it keep Emberfang sympathetic and Sera unseen?
- Does it leave all three endings viable (no hard canon that one of them happened)?
- Is the faith tone sincere and gentle?
- Does Oakvale stay safe?
- If it adds a card, quest or boss reward, update §8 and `src/data/quests.js` / `src/cards/cards.js`.
