# Combat Lab + experimental card system

Reach it from **Pause > Character > COMBAT LAB** (the same entry turns into LEAVE COMBAT LAB). It warps you to the Ember Arena with three
immortal Training Dummies and three real foes (slime, knight, goblin) that respawn after a few seconds. Nothing there is saved or rewarded
(no XP, gold, loot, quest progress) and the hero cannot fall.

The lab runs the EXPERIMENTAL card rules (`src/player/lab.js`, flag `EXPCARD`):

1. Hand of at most 4 cards (`EXPCARD.hand`).
2. No full-hand refresh when the spell gauge fills. One new card is dealt every 2.5 s (`EXPCARD.deal`) into the first empty slot; while the hand is full the timer waits. The gauge bar shows "NEXT CARD".
3. Tapping an attack card only selects it (AIM frame on the card, range ring, reticle / aim preview). The next tap or click in the world casts it at that spot (snaps to a foe within `EXPCARD.snap` px). Tap the card again, or SHOT / CAST / pause / any HUD control, to cancel. Cards that need a creature (Frost Bolt, Crimson Bolt, Chain, Curse, Drain) say NO TARGET on bare ground; area cards (Meteor, Poison Cloud, the bursts) can land anywhere. Buffs (Heal, Barrier, Haste, Ward, Reflect, Decoy, Time Stop, Quake, Wolf) still cast on tap. Swipe-up and hold-SHOT swipe keep their quick-cast-at-nearest behaviour.
4. Works with the two-thumb layout: taps inside the floating-stick zone count as aim taps when they are short and do not drag.

## Promoting it to the main game
Set `EXPCARD.enabled=true` (or expose it as a Settings toggle). `expCards()` is the only switch the combat code consults:
`dealHand()` (hand shape), the gauge block in `updatePlayerCombat()` (dealing), `cardUse()` (tap behaviour) and the `B.xt` aim override
in `nearestEnemy()/aimEnemy()/fireAngle()`.

Tests: `tests/ms32.js` (desktop + iPhone). Screenshots: `store/combat-lab.png`, `store/combat-lab-aiming.png`.
