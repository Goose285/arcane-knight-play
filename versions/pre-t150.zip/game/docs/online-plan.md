# Online features plan (co-op, PvP card duels, cloud saves) - DEFERRED

Status: **not built.** Arcane Knight is a single-file offline game (saves live in `localStorage`, plus the Capacitor wrapper).
Everything below needs a backend or a relay, so it is a design note only - no server code exists in this repo.

## What would be needed

| Feature | Needs | Hard parts |
|---|---|---|
| Cloud saves / cross-device | Accounts + a small key-value store | Sign-in UX, conflict resolution (two devices edited offline), save versioning (`v:1` already in the save blob) |
| PvP card duels (turn based) | Matchmaking + a message relay | Cheating (deck/hand must be validated server-side), disconnects, ranking |
| Co-op in the overworld/boss fights | Real-time relay, authoritative or lock-step simulation | The game is a free-running real-time simulation with `Math.random()`; it is not deterministic yet, so lock-step is out and a host-authoritative model is needed |

## Options

### A. Firebase (Auth + Firestore/Realtime DB) - fastest to ship
- Cloud saves: Firebase Auth (Apple/Google/anonymous) + one Firestore doc per user holding the save JSON (about 5-15 KB).
- Duels: Realtime DB / Firestore room doc with moves as an append-only log; Cloud Functions validate each move.
- Real-time co-op: not a good fit (latency, cost per write).
- Cost: free "Spark" tier covers early testing; Blaze pay-as-you-go is typically a few dollars per month for thousands of casual users (reads/writes are what you pay for). Cloud Functions add roughly a cent per few thousand calls.

### B. Supabase (Postgres + Auth + Realtime)
- Same shape as Firebase, SQL instead of document store, row-level security for per-user saves, Realtime channels for duel rooms.
- Cost: free tier (500 MB DB, 50k monthly active users); Pro is about 25 USD/month flat, which is easier to predict than per-operation billing.

### C. Own WebSocket server (Node + `ws`, or Colyseus) - best for real-time
- One small VM or container holds rooms; the host client (or the server) simulates the fight and streams state at 10-20 Hz.
- Needed for co-op boss fights. Colyseus gives rooms, matchmaking and state sync out of the box.
- Cost: a 5-10 USD/month VPS handles hundreds of concurrent players; scales by adding instances + a Redis presence layer (another 10-15 USD/month).

### D. WebRTC peer-to-peer (with a tiny signalling server)
- Cheapest at runtime (only signalling, effectively free on a free-tier worker). Good for 2-player duels and co-op between friends.
- NAT traversal needs a TURN relay for roughly 10-20% of connections (about 0.40 USD per GB if self-hosted/managed), and there is no server-side anti-cheat.

### E. Cloud saves with no accounts: platform storage
- iOS: iCloud key-value / CloudKit through a Capacitor plugin; Android: Google Play Games saved games. No server and no cost, but per-platform only (no iOS to Android sync) and extra native code.

## Suggested path
1. **Cloud saves first** (Option A or B, or E for the lowest effort): the save is already one versioned JSON blob, so this is a thin upload/download layer with "newest wins, ask on conflict".
2. **Card duels second**: turn-based, tiny messages, fits Option A/B (room doc + validated moves). Needs a deterministic duel ruleset extracted from the real-time combat (the cards currently resolve in real time).
3. **Co-op last**: needs Option C (or D for friends only) and a host-authoritative refactor of the combat loop. This is the largest piece of work.

## Prerequisites inside the game (cheap to do now)
- Keep `save.js` as the single serialization point (already true) and keep adding `v` migrations.
- Seeded randomness for anything that must be reproducible (the weekly crypt in M12 uses a seeded RNG already).
- Never trust the client for ranked play: leaderboards (the boss-rush board is local only) would need server-side score validation.

## Rough cost summary (monthly, small audience)
| Setup | Approx cost |
|---|---|
| Cloud saves on Firebase/Supabase free tier | 0 USD |
| Cloud saves + duels, Firebase pay-as-you-go | 1-10 USD |
| Supabase Pro | 25 USD |
| Colyseus/ws server on a small VPS | 5-10 USD (+ about 10-15 USD for Redis at scale) |
| WebRTC P2P with free signalling + TURN | 0-5 USD |
