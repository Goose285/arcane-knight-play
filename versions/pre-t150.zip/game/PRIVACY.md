# Privacy Policy - Arcane Knight: Realm of Embers

_Last updated: [DATE]_   _Publisher: Seth Moynahan_   _Contact: [YOUR EMAIL]_

Arcane Knight: Realm of Embers ("the game") does **not collect, transmit, sell or share any personal data**.

* **No account, no analytics, no ads, no third-party SDKs, no network calls.** The game is fully offline.
* **Local save data only.** Your progress (level, gold, position) is stored on your device in the app's local
  storage so you can pick up where you left off. It never leaves the device. Deleting the app or clearing its data
  removes it, and "New Game" erases it.
* **No children's data is knowingly collected** (nothing is collected from anyone).
* Changes to this policy will be posted at this page. Questions: [YOUR EMAIL].

Host this page at a public URL (GitHub Pages, your website, Notion public page, etc.) - both stores require a URL.
