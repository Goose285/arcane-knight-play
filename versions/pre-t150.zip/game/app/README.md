# Arcane Knight - Capacitor wrapper
See `../README-store.md` for the complete guide. Quick start:
```
npm install
npm run sync            # copy ../index.html etc. into www/ and cap sync
npm run android:debug   # -> android/app/build/outputs/apk/debug/app-debug.apk  (needs JDK 21 + Android SDK)
npx cap open ios        # on a Mac, then Archive in Xcode
```
