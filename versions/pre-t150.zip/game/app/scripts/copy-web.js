// Copies the single-file web game (+ PWA files and icons) from the parent folder into ./www for Capacitor.
const fs = require('fs'), path = require('path');
const src = path.resolve(__dirname, '..', '..'), dst = path.resolve(__dirname, '..', 'www');
fs.rmSync(dst, { recursive: true, force: true }); fs.mkdirSync(dst, { recursive: true });
for (const f of ['index.html', 'manifest.webmanifest', 'sw.js']) fs.copyFileSync(path.join(src, f), path.join(dst, f));
fs.cpSync(path.join(src, 'icons'), path.join(dst, 'icons'), { recursive: true });
console.log('web build copied to', dst);
