# Spell cards, combos, decks & shops

All card data lives in one table (`CARDS` in `tools/parts/p3b.html`, built into `index.html`).
To add a card: (1) add a row to `CARDS`, (2) add `CAST.<id> = function(card, dmgMult, aimAngle, playerCentre)`, (3) add a 16x16 icon `SP.ic.<id>` in `p1.html`.
`tgt:1` on a row means the card needs a target in line of sight (card is kept if blocked).

## Rarity & deck limits
| Rarity | Max copies in deck | Max owned | Shop price | Notes |
|---|---|---|---|---|
| Common | 4 | 5 | 40 G | starter cards |
| Uncommon | 3 | 4 | 90 G | |
| Rare | 2 | 3 | 200 G | |
| Epic | 1 | 2 | 450 G | |
| Legendary | 1 | 1 | not sold | Dragonfire - only from defeating the dragon |

Deck: 10-20 cards. Starter collection/deck = 4 Sword, 4 Fireball, 3 Barrier, 3 Heal, 3 Lance (17 cards).
The spell gauge deals 5 cards at a time from a shuffled draw pile of your deck (reshuffles when empty).
New cards that you find/buy are auto-added to the deck if there is room.

## Cards
| Card | Rarity | Effect |
|---|---|---|
| Sword / Fireball / Barrier / Heal / Lance | Common | unchanged basics |
| Frost Bolt, Crimson Bolt | Uncommon | single-target freeze / lifesteal |
| Chain Lightning | Uncommon | hits target then jumps (<=150px, LOS) to up to 4 foes total, -25% damage per jump |
| Poison Cloud | Uncommon | 68px cloud for 5s on target, damage tick every 0.5s (ignores guards) |
| Haste | Uncommon | 5s: +45% move speed, +80% shot rate, +40% charge speed |
| Decoy | Uncommon | fake knight (80 HP) for 5s - enemies aim at it; absorbs shots & blasts |
| Frost Burst, Crimson Burst | Rare | area freeze / area lifesteal |
| Earthquake | Rare | shockwave r118 around you, damage + 1.2s stun, clears hostile shots; bosses only get slowed |
| Shadow Step | Rare | dash up to 130px in aim direction (wall-safe, stops before walls/NPCs), 0.9s invulnerable |
| Holy Ward | Rare | dome r70 for 3s deletes hostile projectiles |
| Reflect | Rare | 1.5s window: hostile projectiles reaching you are sent back (x2.2 damage) |
| Curse | Rare | target takes 2x damage for 6s |
| Summon Wolf | Rare | spirit wolf for 10s hunts the nearest foe (30 dmg bite / 0.55s) |
| Meteor Call | Epic | 1.1s telegraph on target's spot, then 160 dmg r62 blast |
| Drain Soul | Epic | 2s beam (range 250, LOS) 22 dmg/0.25s, heals you for 50% of damage dealt, you move at 60% speed |
| Time Stop | Epic | all non-boss foes frozen 2s (windups cancelled), hostile projectiles hang in the air; bosses are only slowed |
| Dragonfire | Legendary | huge flame cone (r280), 210 dmg + burn; granted when you first fell the dragon |

## Combos (cast the pair within 1.5s, either order -> the 2nd card is replaced by the fused effect + "COMBO!" banner)
| Pair | Result |
|---|---|
| Frost Bolt + Fireball | **Steam Blast** - r88 blast at the target, 140 dmg + 1s stun |
| Chain Lightning + Poison Cloud | **Storm Cloud** - r88 electrified cloud, 16 dmg ticks plus a 38 dmg lightning zap on a foe each tick |
| Shadow Step + Sword | **Phantom Slash** - 110px dash, then triple slash: 160 dmg to everything along the path |
| Holy Ward + Heal | **Sanctuary** - 5s dome that also heals 5% HP/s (+20% instantly) |
| Fireball + Earthquake | **Magma Surge** - r135 fire ring: 130 dmg, burn, 0.8s stun |
| Time Stop + Meteor Call | **Judgment** - a meteor (150 dmg) falls on EVERY foe |

## Getting cards
* **Enemy drops** (non-blocking toast + "NEW CARD!" text): chance = 11% + 0.8%/enemy level (max 34%). Rarity odds shift to rare/epic with enemy level (measured over 20k rolls - lv1: 58% common / 32% uncommon / 8% rare / 1.5% epic; lv12: 23% common / 36% uncommon / 31% rare / 10% epic). The dragon always rolls at level 16 and grants Dragonfire the first time.
* **Blacksmith Brum** (talk to him): 4 cards for sale, stock re-rolls every 5 kills; plus "Reforge Arcane Shot".
* Duplicates beyond the owned cap convert to gold (40% of shop price).

## Deck screen
Pause (P / pause button) -> DECK. Touch: drag to scroll, tap `+` / `-`. Keyboard: Up/Down, Left/Right (or A/D), Esc/P to close. Needs >=10 cards. Saved with the game (`localStorage`: collection, deck, shop stock).
