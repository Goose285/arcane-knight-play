// Copy the web build (dist/web) into the play repo WITHOUT deleting anything and WITHOUT touching world-edits.json
// (the editor's SAVE button commits that file straight to the play repo; the build must never clobber it).
//   node scripts/build.js && node scripts/sync-play.js [../ak-play]
const fs=require('fs'),path=require('path');
const src=path.join(__dirname,'..','dist','web'),dst=path.resolve(process.argv[2]||path.join(__dirname,'..','..','ak-play'));
const KEEP=new Set(['world-edits.json','.git','.nojekyll']);
if(!fs.existsSync(dst)){console.error('no play repo at '+dst);process.exit(1);}
let n=0;
(function cp(a,b,top){fs.mkdirSync(b,{recursive:true});for(const f of fs.readdirSync(a)){if(top&&KEEP.has(f))continue;const s=path.join(a,f),d=path.join(b,f);if(fs.statSync(s).isDirectory())cp(s,d,false);else{fs.copyFileSync(s,d);n++;}}})(src,dst,true);
if(!fs.existsSync(path.join(dst,'.nojekyll')))fs.writeFileSync(path.join(dst,'.nojekyll'),'');
console.log('synced '+n+' files into '+dst+' (world-edits.json preserved'+(fs.existsSync(path.join(dst,'world-edits.json'))?', present':', not present')+')');
