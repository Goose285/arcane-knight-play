const puppeteer=require('puppeteer-core');const fs=require('fs');
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const pg=await b.newPage();await pg.setViewport({width:800,height:600});
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await new Promise(r=>setTimeout(r,600));
 const res=await pg.evaluate(()=>{
  const mk=(w,h)=>{const c=document.createElement('canvas');c.width=w;c.height=h;const g=c.getContext('2d');g.imageSmoothingEnabled=false;return [c,g];};
  const sp=(g,spr,x,y,s,flip)=>{g.save();g.translate(x,y);if(flip){g.translate(spr.width*s,0);g.scale(-1,1);}g.drawImage(spr,0,0,spr.width*s,spr.height*s);g.restore();};
  const info={hero:[SP.hero.r[1].width,SP.hero.r[1].height],dragon:[SP.dragon.width,SP.dragon.height]};
  // background layer
  const bg=(g,W,H,stars=true)=>{
    const gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,'#0c0a24');gr.addColorStop(.58,'#41204f');gr.addColorStop(1,'#d2602f');g.fillStyle=gr;g.fillRect(0,0,W,H);
    if(stars)for(let i=0;i<70;i++){const x=(i*397)%W,y=(i*211)%(H*.5);const s=i%9===0?W/170:W/340;g.fillStyle=`rgba(255,255,255,${.35+.45*((i*7)%10)/10})`;g.fillRect(x,y,s,s);}
    g.fillStyle='#f4e8c0';g.beginPath();g.arc(W*.74,H*.25,W*.11,0,6.283);g.fill();g.fillStyle='#e0d0a0';g.beginPath();g.arc(W*.71,H*.22,W*.018,0,6.283);g.fill();g.beginPath();g.arc(W*.77,H*.28,W*.012,0,6.283);g.fill();
    // castle silhouette
    g.fillStyle='#150b26';const cx=W*.2,cw=W*.6,cy=H*.5;g.fillRect(cx,cy,cw,H*.3);
    for(let i=0;i<9;i++)g.fillRect(cx+i*cw/9+cw/60,cy-H*.03,cw/18,H*.04);
    [[cx-W*.02,cy-H*.1,W*.1],[cx+cw-W*.08,cy-H*.1,W*.1],[cx+cw*.4,cy-H*.17,W*.12]].forEach(([x,y,w])=>{g.fillRect(x,y,w,H*.4);g.beginPath();g.moveTo(x-w*.1,y);g.lineTo(x+w/2,y-H*.12);g.lineTo(x+w*1.1,y);g.fill();});
    g.fillStyle='#ffcf5a';[[.47,.42],[.25,.5],[.7,.5],[.37,.6],[.58,.6]].forEach(([a,c])=>g.fillRect(W*a,H*c,W*.014,W*.022));
    g.fillStyle='#10281a';g.fillRect(0,H*.8,W,H*.2);g.fillStyle='#17391f';g.fillRect(0,H*.8,W,H*.015);
  };
  const fg=(g,W,H)=>{
    const s=W/1024;
    sp(g,SP.dragon,W*.08,H*.14,Math.round(7*s*10)/10*1,true);  // dragon top-left, flying
    sp(g,SP.hero.r[1],W*.5-8*29*s,H*.47,29*s,false);
    for(let i=0;i<26;i++){g.fillStyle=`rgba(255,${150+(i*13)%90},60,.85)`;const x=(i*271)%W,y=H*.35+((i*173)%(H*.55));g.fillRect(x,y,W/200,W/200);}
  };
  const out={};
  const full=(W)=>{const [c,g]=mk(W,W);bg(g,W,W);fg(g,W,W);return c;};
  const icon=full(1024);out.icon=icon.toDataURL('image/png');
  {const [c,g]=mk(1024,1024);bg(g,1024,1024);out.bg=c.toDataURL('image/png');}
  {const [c,g]=mk(1024,1024);fg(g,1024,1024);out.fg=c.toDataURL('image/png');}
  const scaled=(src,W)=>{const [c,g]=mk(W,W);g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(src,0,0,W,W);return c.toDataURL('image/png');};
  out.sizes={};[16,32,48,72,96,120,128,144,152,167,180,192,256,384,512].forEach(w=>out.sizes[w]=scaled(icon,w));
  // splash: dark bg + hero + title
  const splash=(W,H,dark)=>{const [c,g]=mk(W,H);const gr=g.createLinearGradient(0,0,0,H);gr.addColorStop(0,'#07060d');gr.addColorStop(.6,dark?'#150b26':'#2a1540');gr.addColorStop(1,dark?'#3a1a1a':'#8a3a24');g.fillStyle=gr;g.fillRect(0,0,W,H);
    const m=Math.min(W,H);for(let i=0;i<120;i++){const x=(i*397)%W,y=(i*211)%(H*.6);g.fillStyle=`rgba(255,255,255,${.25+.4*((i*7)%10)/10})`;g.fillRect(x,y,m/400,m/400);}
    sp(g,SP.hero.r[1],W/2-8*m/70,H*.5-m*.2,m/70,false);
    g.textAlign='center';g.font=`bold ${m*.095}px "Courier New",monospace`;g.lineWidth=m*.02;g.lineJoin='round';g.strokeStyle='#3a0a0a';g.strokeText('ARCANE KNIGHT',W/2,H*.5+m*.18);g.fillStyle='#ff9a3a';g.fillText('ARCANE KNIGHT',W/2,H*.5+m*.18);
    g.font=`bold ${m*.04}px "Courier New",monospace`;g.lineWidth=m*.01;g.strokeStyle='#000';g.strokeText('~ Realm of Embers ~',W/2,H*.5+m*.25);g.fillStyle='#cfe0ff';g.fillText('~ Realm of Embers ~',W/2,H*.5+m*.25);
    return c.toDataURL('image/png');};
  out.splash=splash(2732,2732,false);out.splashDark=splash(2732,2732,true);out.splashPortrait=splash(1242,2688,false);
  out.info=info;return out;});
 const save=(p,d)=>{fs.mkdirSync(require('path').dirname(p),{recursive:true});fs.writeFileSync(p,Buffer.from(d.split(',')[1],'base64'));};
 const A='/workspace/arcane-knight/';
 save(A+'app/assets/icon-only.png',res.icon);save(A+'app/assets/icon-foreground.png',res.fg);save(A+'app/assets/icon-background.png',res.bg);
 save(A+'app/assets/splash.png',res.splash);save(A+'app/assets/splash-dark.png',res.splashDark);
 save(A+'store/app-icon-1024.png',res.icon);
 for(const w in res.sizes)save(A+`icons/icon-${w}.png`,res.sizes[w]);
 save(A+'icons/apple-touch-icon.png',res.sizes[180]);save(A+'icons/maskable-512.png',res.sizes[512]);save(A+'icons/splash.png',res.splashPortrait);
 console.log(res.info);await b.close();
})();
