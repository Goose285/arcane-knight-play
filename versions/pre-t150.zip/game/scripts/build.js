// Build: concatenates src modules (order in src/manifest.json) into ONE self-contained index.html,
// writes dist/web/ (deployable) and syncs app/www for Capacitor.
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'..'),src=path.join(root,'src');
const order=JSON.parse(fs.readFileSync(path.join(src,'manifest.json'),'utf8'));
const js=order.map(f=>`/* ---------- src/${f} ---------- */\n`+fs.readFileSync(path.join(src,f),'utf8')).join('\n');
const html=fs.readFileSync(path.join(src,'template.html'),'utf8').replace('%%JS%%',()=>js);
fs.writeFileSync(path.join(root,'index.html'),html);
// duplicate top-level names: a later module silently overrides an earlier one in a concatenated bundle
{const seen={},dup=[];for(const f of order){const t=fs.readFileSync(path.join(src,f),'utf8');
  for(const m of t.matchAll(/^(?:async\s+)?function\s+(\w+)|^(?:const|let|var)\s+(\w+)/gm)){const n=m[1]||m[2];if(seen[n]&&seen[n]!==f)dup.push(`${n} (${seen[n]} + ${f})`);seen[n]=f;}}
  if(dup.length){console.error('DUPLICATE top-level names:\n  '+dup.join('\n  '));process.exit(1);}}
// syntax check
try{new Function(js.replace(/^'use strict';?/m,''));}catch(e){console.error('SYNTAX ERROR in bundle:',e.message);process.exit(1);}
const web=path.join(root,'dist','web');fs.mkdirSync(web,{recursive:true});
fs.writeFileSync(path.join(web,'index.html'),html);
for(const f of ['manifest.webmanifest','sw.js'])fs.copyFileSync(path.join(root,f),path.join(web,f));
fs.cpSync(path.join(root,'icons'),path.join(web,'icons'),{recursive:true});
const www=path.join(root,'app','www');
if(fs.existsSync(path.join(root,'app'))){fs.mkdirSync(www,{recursive:true});fs.writeFileSync(path.join(www,'index.html'),html);
  for(const f of ['manifest.webmanifest','sw.js'])fs.copyFileSync(path.join(root,f),path.join(www,f));
  fs.cpSync(path.join(root,'icons'),path.join(www,'icons'),{recursive:true});}
console.log('built index.html',(html.length/1024).toFixed(0)+'KB from',order.length,'modules');
