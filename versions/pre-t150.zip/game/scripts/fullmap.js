const puppeteer=require('puppeteer-core');const fs=require('fs');
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const pg=await b.newPage();await pg.setViewport({width:800,height:600});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file://'+require('path').join(__dirname,'..','index.html')+'?nosave=1');await new Promise(r=>setTimeout(r,600));
 const data=await pg.evaluate(()=>{
  const K=24,W=MW*K,H=MH*K,LEG=300,TOP=64,Y=ty=>ty;const skip=y=>(y>=OW_H&&y<CRY0)||(y>CRY_END&&y<ZONE_Y0.snow)||[ZONE_Y0.snow,ZONE_Y0.swamp,ZONE_Y0.desert].some(z=>y>=z+ZONE_H&&y<z+ZONE_H+2)||(y>=ZONE_Y0.desert+ZONE_H&&y<ARENA_Y0);
  const c=document.createElement('canvas');c.width=W;c.height=H+LEG+TOP;const g=c.getContext('2d');g.imageSmoothingEnabled=false;
  g.fillStyle='#0b0916';g.fillRect(0,0,c.width,c.height);
  g.translate(0,TOP);
  for(let y=0;y<MH;y++){if(skip(y))continue;for(let x=0;x<MW;x++)g.drawImage(tileSprite(map[y][x],x,y,0),x*K,Y(y)*K,K,K);}
  // faint 8-tile grid + coordinates
  g.strokeStyle='rgba(255,255,255,.12)';g.lineWidth=1;g.fillStyle='rgba(255,255,255,.55)';g.font='11px "Courier New",monospace';g.textAlign='left';
  for(let x=0;x<=MW;x+=8){g.beginPath();g.moveTo(x*K+.5,0);g.lineTo(x*K+.5,H);g.stroke();if(x<MW)g.fillText(String(x),x*K+3,12);}
  for(let y=0;y<=OW_H;y+=8){g.beginPath();g.moveTo(0,y*K+.5);g.lineTo(W,y*K+.5);g.stroke();if(y<OW_H&&y)g.fillText(String(y),3,y*K+13);}
  for(let y=56;y<MH;y+=8){if(skip(y))continue;g.beginPath();g.moveTo(0,Y(y)*K+.5);g.lineTo(W,Y(y)*K+.5);g.stroke();g.fillText(String(y),3,Y(y)*K+13);}
  const txt=(s,x,y,size,col,align='center',lw=5)=>{g.font=`bold ${size}px "Courier New",monospace`;g.textAlign=align;g.lineJoin='round';g.lineWidth=lw;g.strokeStyle='rgba(0,0,0,.9)';g.strokeText(s,x,y);g.fillStyle=col;g.fillText(s,x,y);};
  // zone outlines
  const zone=(x0,y0,x1,y1,col,dash)=>{g.save();g.setLineDash(dash||[10,7]);g.lineWidth=3;g.strokeStyle=col;g.strokeRect(x0*K,y0*K,(x1-x0+1)*K,(y1-y0+1)*K);g.restore();};
  zone(18,1,46,11,'#ffd23f');zone(3,29,24,44,'#7dffa0');zone(3,14,24,27,'#9ad0ff');zone(27,14,61,45,'#ff9a6a');
  // dragon territory (castle interior)
  g.save();g.setLineDash([4,5]);g.lineWidth=2;g.strokeStyle='rgba(255,70,70,.9)';g.strokeRect(19*K,2*K,27*K,9*K);g.restore();
  zone(17,51,46,61,'#7dffa0',[4,5]);   // Lich King territory (throne hall)
  const ZC={snow:'#9fe8ff',swamp:'#9bd84a',desert:'#f0c060'};
  for(const id in ZONES)zone(0,ZONES[id].y0,63,ZONES[id].y0+ZONE_H-1,ZC[id]);
  // gate arches on the overworld
  for(const id in ZONES){const q=ZONES[id].gate;g.lineWidth=3;g.strokeStyle=ZC[id];g.strokeRect((q.x-.5)*K,(q.y-.5)*K,2*K,1.6*K);txt('GATE: '+ZONE_NAME[id],(q.x+.5)*K,(q.y-1)*K,11,ZC[id],undefined,4);}
  zone(14,ARENA_Y0+2,49,ARENA_Y0+13,'#ff9a6a');txt('EMBER ARENA  -  BOSS RUSH',32*K,(ARENA_Y0+1.1)*K,24,'#ff9a6a');txt('entered from the Arena Master in Oakvale  -  five champions, endless laps',32*K,(ARENA_Y0+1.1)*K+16,12,'#ffe3d5',undefined,4);
  zone(HOUSE_ROOM.x0,HOUSE_ROOM.y0,HOUSE_ROOM.x1,HOUSE_ROOM.y1,'#ffd23f');txt('YOUR HOUSE  -  trophy shelves',32*K,(HOUSE_Y0+1.4)*K,22,'#ffd23f');txt('door sign at the south-east village house',32*K,(HOUSE_Y0+1.4)*K+16,12,'#fff6cf',undefined,4);
  {const q=HOUSE_DOOR;txt('YOUR HOUSE (door)',(q.tx+.5)*K,(q.ty-.2)*K,11,'#ffd23f',undefined,4);}
  {const k2=NPCS.find(n=>n.pets);if(k2)txt('PET KEEPER',k2.x/TS*K,k2.y/TS*K-30,11,'#c58bff',undefined,4);const a2=NPCS.find(n=>n.rush);if(a2)txt('ARENA MASTER',a2.x/TS*K,a2.y/TS*K-30,11,'#ff9a6a',undefined,4);}
  const zl=(id,sub)=>{const y0=ZONES[id].y0;txt(ZONE_NAME[id],32*K,(y0+.2)*K-14,26,ZC[id]);txt(sub,32*K,(y0+.2)*K+4,13,'#fff',undefined,4);};
  zl('snow','frost wolves Lv 7-9  -  Rime Brutes  -  boss Rimegar Lv 14');zl('swamp','bog toads  -  mire witches  -  boss Old Mossback Lv 17');zl('desert','dune scorpions  -  dust mummies  -  boss The Sundered Colossus Lv 20');
  // area labels
  txt('OAKVALE VILLAGE',13.5*K,43.2*K,26,'#7dffa0');txt('safe zone - heal at fountain',13.5*K,44.1*K,12,'#d8ffe4',undefined,4);
  txt('GREENMEADOW',13.5*K,15.2*K,26,'#9ad0ff');txt('Lv 1-3',13.5*K,16.2*K,15,'#e5f2ff',undefined,4);
  txt('WHISPERWOOD',44*K,16.2*K,28,'#ff9a6a');txt('Lv 3-6',44*K,17.4*K,15,'#ffe3d5',undefined,4);
  txt('CASTLE DRACORYN',26*K,3.4*K,24,'#ffd23f');txt('Lv 6-10  -  Boss Lv 12',26*K,4.5*K,14,'#fff1b8',undefined,4);
  txt('Castle Road',17*K,12.8*K,12,'#fff',undefined,4);
  txt('CRYPT STAIRS',5.5*K,16.4*K,14,'#c58bff');txt('(down to the Crypt)',5.5*K,17.2*K,10,'#e5d5ff',undefined,4);
  txt('CRYPT OF HOLLOW KINGS',31.5*K,Y(49)*K-16,26,'#c58bff');txt('bats Lv 8-11  -  wraiths Lv 10-14  -  entered by the meadow stairs',31.5*K,Y(49)*K+2,13,'#e5d5ff',undefined,4);
  txt('THRONE HALL - LICH KING Lv 16',31.5*K,Y(52)*K,14,'#7dffa0');txt('Entry hall / up-stairs',31.5*K,Y(84)*K,12,'#ffe14d',undefined,4);
  txt('West crypt',9.5*K,Y(63)*K,12,'#fff',undefined,4);txt('East crypt',53.5*K,Y(63)*K,12,'#fff',undefined,4);txt('Hub',31.5*K,Y(65)*K,12,'#fff',undefined,4);
  // sprites
  const spr=(s,x,y,sz)=>{if(!s)return;if(!s.getContext){s=(s.d&&s.d[0])||(s.r&&s.r[0])||s;}try{g.drawImage(s,x-sz/2,y-sz,sz,sz);}catch(e){}};
  // enemy spawns
  const col={slime:'#58d66b',knight:'#c8cde0',goblin:'#e0a050',dragon:'#ff5a4a',bat:'#b08cff',wraith:'#7bd0f0',lich:'#7dffa0',wolf:'#bfeaff',yeti:'#dfe8ff',rimegar:'#6fd0ff',toad:'#8fd04a',witch:'#c06ae0',mossback:'#4fb04a',scorpion:'#e8a040',mummy:'#d8c890',colossus:'#ffcf5a'};
  enemies.forEach(e=>{const x=e.hx/TS*K,y=Y(e.hy/TS)*K,s=e.def.big?72:34;
    g.fillStyle='rgba(0,0,0,.45)';g.beginPath();g.ellipse(x,y,s*.32,s*.12,0,0,6.283);g.fill();
    g.lineWidth=2;g.strokeStyle=col[e.type];g.beginPath();g.arc(x,y-s*.3,s*.55,0,6.283);g.stroke();
    spr(SP[e.def.spr],x,y,s);
    txt('Lv'+e.lv,x,y+13,12,'#ffe14d',undefined,4);});
  // waystones + treasure-map dig spots
  WAYSTONES.forEach(w=>{const p=w.zone?zoneArrive(w.zone):null,x=(p?p.x+44:(w.tx+.5)*TS)/TS*K,y=(p?(p.y-20)/TS*K:(w.ty+.9)*K);g.fillStyle='rgba(125,249,255,.95)';g.beginPath();g.arc(x,y-12,13,0,6.283);g.fill();g.lineWidth=2;g.strokeStyle='#fff';g.stroke();txt('W',x,y-7,15,'#10243a',undefined,0);txt(w.name,x,y+12,10,'#7df9ff',undefined,4);});
  TMAPS.forEach(t=>{const x=(t.x+.5)*K,y=(t.y+.5)*K;txt('X',x,y+8,22,'#ffd23f',undefined,5);txt('dig: '+t.name,x,y+22,10,'#ffe9a0',undefined,4);});
  // NPCs
  NPCS.forEach(n=>{if(n.way||n.house==='shelf'||n.house==='bed'||zoneOfPx(n.y)==='house')return;const x=n.x/TS*K,y=n.y/TS*K;g.fillStyle='rgba(60,140,255,.9)';g.beginPath();g.arc(x,y-14,17,0,6.283);g.fill();g.lineWidth=2;g.strokeStyle='#fff';g.stroke();spr(SP[n.spr],x,y,30);txt(n.name,x,y+13,12,'#9fd0ff',undefined,4);});
  // player start
  txt('START',SPAWN.x/TS*K,SPAWN.y/TS*K-30,13,'#ffffff');g.fillStyle='#ffe14d';g.beginPath();g.moveTo(SPAWN.x/TS*K,SPAWN.y/TS*K-4);g.lineTo(SPAWN.x/TS*K-8,SPAWN.y/TS*K-20);g.lineTo(SPAWN.x/TS*K+8,SPAWN.y/TS*K-20);g.fill();
  // fountain / gate / bridge labels
  txt('Fountain (heal)',15.5*K,32.6*K,11,'#bfe9ff',undefined,4);txt('River',25.9*K,20*K,12,'#cfe8ff',undefined,4);txt('Bridge',26*K,36.6*K,11,'#ffe0a8',undefined,4);txt('Castle gate',32*K,11.9*K+10,11,'#fff',undefined,4);
  // title
  g.setTransform(1,0,0,1,0,0);
  txt('ARCANE KNIGHT: REALM OF EMBERS  -  WORLD MAP',W/2,40,34,'#ffcf3a','center',8);
  txt('64 x 48 world + 64 x 38 crypt + 3 regions of 64 x 32 + boss arena  -  grid every 8 tiles',W-14,TOP-8,12,'#cfd0ff','right',3);
  // legend
  const ly=TOP+H+14;g.fillStyle='rgba(18,14,36,.95)';g.fillRect(10,ly,W-20,LEG-24);g.strokeStyle='#e8e0c8';g.lineWidth=2;g.strokeRect(10,ly,W-20,LEG-24);
  txt('LEGEND',24,ly+24,16,'#ffe14d','left',4);
  const items=[['Slime','slime','Lv 1-3 meadow / 3-6 forest'],['Skeleton Knight','knight','Lv 3-6 forest / 6-10 castle'],['Goblin Archer','goblin','Lv 3-6 forest / 6-10 castle'],['Emberfang (boss)','dragon','Lv 12, stays in castle'],['Crypt Bat','bat','Lv 8-11 crypt'],['Hollow Wraith','wraith','Lv 10-14 crypt'],['Lich King (boss)','lich','Lv 16, throne hall'],['Frost Wolf','wolf','Lv 7-9 Frosthowl'],['Rime Brute','yeti','Lv 8-9 Frosthowl'],['Rimegar (boss)','rimegar','Lv 14, frost titan'],['Bog Toad','toad','Lv 10-12 Mirewood'],['Mire Witch','witch','Lv 11-12 Mirewood'],['Old Mossback (boss)','mossback','Lv 17, bog hydra'],['Dune Scorpion','scorpion','Lv 13-15 Sundered'],['Dust Mummy','mummy','Lv 14-16 Sundered'],['Sundered Colossus (boss)','colossus','Lv 20, desert ruins']];
  items.forEach(([n,t,d],i)=>{const x=24+(i%4)*370,y=ly+66+Math.floor(i/4)*54;g.lineWidth=2;g.strokeStyle=col[t];g.beginPath();g.arc(x+18,y-14,18,0,6.283);g.stroke();spr(SP[ENEMY[t].spr],x+18,y+2,ENEMY[t].big?44:34);txt(n,x+46,y-12,13,'#fff','left',3);txt(d,x+46,y+6,11,'#cfd0ff','left',3);});
  const y2=ly+252;g.fillStyle='rgba(60,140,255,.9)';g.beginPath();g.arc(36,y2-4,9,0,6.283);g.fill();txt('NPC',54,y2,13,'#9fd0ff','left',3);
  g.setLineDash([10,7]);g.lineWidth=3;g.strokeStyle='#ffd23f';g.beginPath();g.moveTo(130,y2-4);g.lineTo(170,y2-4);g.stroke();g.setLineDash([]);txt('Area border',178,y2,13,'#fff','left',3);
  g.setLineDash([4,5]);g.lineWidth=2;g.strokeStyle='rgba(255,70,70,.9)';g.beginPath();g.moveTo(330,y2-4);g.lineTo(370,y2-4);g.stroke();g.setLineDash([]);txt('Dragon territory (never leaves)',378,y2,13,'#fff','left',3);
  txt('Lv badges = this save\'s spawn levels (zone range + small variation, respawn in place)',W-24,y2,12,'#cfd0ff','right',3);
  return c.toDataURL('image/png');
 });
 fs.writeFileSync(require('path').join(__dirname,'..','store','full-map.png'),Buffer.from(data.split(',')[1],'base64'));console.log(errs);await b.close();})();
