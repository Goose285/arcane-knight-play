#!/usr/bin/env bash
# Recoverable backup before a major update:
#  1. tags HEAD in the game repo and the play repo (local tags: backup-<label>)
#  2. copies the CURRENT playable build from the play repo into ak-play/versions/<label>/ so that older version stays playable on the
#     site at  <site>/versions/<label>/  (sw.js is left out on purpose so the old copy never fights the live service worker)
#  3. ARCHIVE (t141u): builds versions/<label>.zip = game/ (the game repo source at tag backup-<label>; store/ and top-level *.png
#     screenshots left out) + play/ (that playable build). With AK_RELEASE=1 and an authenticated gh it is ALSO uploaded as a GitHub
#     Release asset on Goose285/arcane-knight (tag backup-<label>); otherwise the zip stays in the play repo, linked from /versions/.
#  4. commits that copy + zip in the play repo (no push)
# backfill an archive for an existing label:  scripts/snapshot.sh --archive-only <label>
# usage: scripts/snapshot.sh [label] [play-repo]      label defaults to YYYY-MM-DD-<short game hash>
set -euo pipefail
GAME="$(cd "$(dirname "$0")/.." && pwd)"
ARCHIVE_ONLY=0; if [ "${1:-}" = "--archive-only" ]; then ARCHIVE_ONLY=1; shift; fi
PLAY="${2:-$GAME/../ak-play}"; PLAY="$(cd "$PLAY" && pwd)"
LABEL="${1:-$(date +%Y-%m-%d)-$(git -C "$GAME" rev-parse --short HEAD)}"
ID=(-c user.name="Seth Moynahan" -c user.email="seth@users.noreply.local")
archive(){   # $1 = label -> $PLAY/versions/$1.zip
  local L="$1" Z="$PLAY/versions/$1.zip" T; T="$(mktemp -d)"
  git -C "$GAME" archive --format=zip -o "$T/game.zip" "backup-$L" -- . ':!store' ':(exclude,glob)*.png'
  python3 - "$T/game.zip" "$PLAY/versions/$L" "$Z" <<'PY'
import sys,zipfile,os
src,play,out=sys.argv[1:4]
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
    with zipfile.ZipFile(src) as g:
        for i in g.infolist():
            if not i.is_dir(): z.writestr('game/'+i.filename,g.read(i.filename))
    for root,_,files in os.walk(play):
        for f in files:
            fp=os.path.join(root,f); z.write(fp,'play/'+os.path.relpath(fp,play))
PY
  rm -rf "$T"; echo "archived $Z ($(du -h "$Z" | cut -f1))"
  if [ "${AK_RELEASE:-0}" = "1" ] && command -v gh >/dev/null && gh auth status >/dev/null 2>&1; then
    gh release view "backup-$L" -R Goose285/arcane-knight >/dev/null 2>&1 || gh release create "backup-$L" -R Goose285/arcane-knight --title "Backup $L" --notes "Source + playable build before update ($L)" --target "$(git -C "$GAME" rev-parse "backup-$L^{commit}")"
    gh release upload "backup-$L" "$Z" -R Goose285/arcane-knight --clobber && echo "uploaded as a GitHub Release asset: backup-$L"
  fi
}
index_page(){ ( echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Arcane Knight - older versions</title><h1>Older versions</h1><ul>'
  for d in $(ls -1 "$PLAY/versions" | grep -v '\.html$' | grep -v '\.zip$' | sort -r); do z=""; [ -e "$PLAY/versions/$d.zip" ] && z=" - <a href=\"$d.zip\">download zip (source + build)</a>"; echo "<li><a href=\"$d/\">$d</a>$z</li>"; done; echo '</ul><p><a href="../">current version</a></p>' ) > "$PLAY/versions/index.html"; }
if [ "$ARCHIVE_ONLY" = "1" ]; then archive "$LABEL"; index_page; git -C "$PLAY" add versions && git -C "$PLAY" "${ID[@]}" commit -qm "Archive versions/$LABEL.zip" && echo "committed versions/$LABEL.zip"; exit 0; fi
for R in "$GAME" "$PLAY"; do
  if git -C "$R" rev-parse -q --verify "refs/tags/backup-$LABEL" >/dev/null; then echo "tag backup-$LABEL already in $R"; else git -C "$R" "${ID[@]}" tag -a "backup-$LABEL" -m "backup before update ($LABEL)"; echo "tagged $R -> backup-$LABEL"; fi
done
DEST="$PLAY/versions/$LABEL"; mkdir -p "$DEST"
for f in index.html manifest.webmanifest icons world-edits.json; do [ -e "$PLAY/$f" ] && cp -R "$PLAY/$f" "$DEST/"; done
archive "$LABEL"
index_page
git -C "$PLAY" add versions && git -C "$PLAY" "${ID[@]}" commit -qm "Snapshot playable build: versions/$LABEL" && echo "committed versions/$LABEL in play repo"
echo "versions path: /versions/$LABEL/"
