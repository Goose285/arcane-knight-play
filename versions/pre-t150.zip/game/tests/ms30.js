// M30: no stuck pale-white "ghost" enemies: a foe that is mid death-fade when its fight ends (fled / guards drove them off / defeat)
// must be finished off, not left engaged+dying (never updated again, frozen white flash).  Plus: every combat effect has a lifetime.
// node tests/ms30.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,finish,shot}=await boot('ms30',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();});
 const setup=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.flash=0;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=e.lk=1e9;e.calm=0;});
   g.tp(12,26);g.P.x=12*32+16;g.P.y=26*32+28;g.P.grace=0;g.P.hp=1e6;
   const sl=g.enemies.filter(e=>e.type==='slime'&&!e.def.boss).slice(0,3);sl.forEach((e,i)=>{e.x=e.hx=12*32+16+(i-1)*44;e.y=e.hy=24*32+(i%2)*20;e.fa=e.ta=Math.PI/2;e.hp=e.maxhp;});
   window.__sl=sl;d.startEncounter(sl[0],true);g.P.grace=0;});
 const bad=()=>E(()=>{const g=__game,B=g.B;return g.enemies.filter(e=>e.alive&&((e.engaged&&(!B||!B.ens.includes(e)))||(e.dying&&!B)||(!B&&e.flash>0)||(e.dying&&e.dyT>1.8))).map(e=>[e.type,e.engaged,e.dying,e.flash,e.dyT]);});
 // ---- 1. kill one slime and end the fight right away through each exit path while it is dying
 for(const path of ['disengage','guard','lose']){
  await setup();await sleep(1200);
  await E(path=>{const g=__game,d=g.dbg,sl=window.__sl;sl[0].hp=1;d.killEnemy(sl[0]);sl[0].flash=.12;sl[1].flash=.12;
    if(path==='disengage')d.disengage();else if(path==='guard')d.townEnd();else d.endBattle(false);
    window.__path=path;},path);
  await sleep(300);
  const st=await E(()=>({B:!!__game.B,s0:(s=>[s.alive,s.engaged,s.dying,s.flash])(window.__sl[0]),s1:(s=>[s.engaged,s.flash])(window.__sl[1])}));
  ok(!st.B&&st.s0[0]===false&&st.s0[1]===false&&st.s0[3]===0,path+': the dying slime is finished off when the fight ends ('+JSON.stringify(st.s0)+')');
  ok(st.s1[0]===false&&st.s1[1]===0,path+': survivors are released (not engaged, no flash)');
  await sleep(600);ok((await bad()).length===0,path+': no engaged/dying/flashing enemy left outside a fight '+JSON.stringify(await bad()));
 }
 // ---- 2. safety net: an enemy left engaged+dying+flash by any other path is reaped by the world update and by the next fight
 await setup();await E(()=>{__game.dbg.endFight();});
 await E(()=>{const e=window.__sl[2];e.alive=true;e.engaged=true;e.dying=true;e.dyT=0;e.flash=.12;});
 await sleep(500);
 const st2=await E(()=>{const e=window.__sl[2];return [e.alive,e.engaged,e.flash];});
 ok(st2[0]===false&&st2[1]===false&&st2[2]===0,'a stale engaged+dying foe is reaped by the world update '+JSON.stringify(st2));
 await setup();await E(()=>{const e=window.__sl[2];e.engaged=true;e.flash=.12;e.x=e.hx=12*32+60;e.y=e.hy=24*32+30;});   // engaged but not in the fight
 await sleep(900);
 ok(await E(()=>{const e=window.__sl[2];return !e.engaged&&e.flash===0||__game.B.ens.includes(e);}),'an enemy marked engaged but not in the fight is released (or joined)');
 // ---- 3. a long natural slime fight with joiners: flash always decays, effect lists stay bounded and empty after the fight
 await setup();
 const samples=await E(()=>new Promise(res=>{const out={maxFlash:0,stuck:0,max:{},n:0};const t0=performance.now();const iv=setInterval(()=>{const B=__game.B;if(B){B.inv=Math.max(B.inv||0,3);for(const k of ['fx','texts','parts','zones','shots','timers']){out.max[k]=Math.max(out.max[k]||0,B[k].length);}
   for(const e of B.ens){if(e.flash>.2)out.maxFlash=Math.max(out.maxFlash,e.flash);if(e.dying&&e.dyT>1.8)out.stuck++;if(e.engaged===false)out.stuck++;}out.n++;}
   if(performance.now()-t0>7000){clearInterval(iv);res(out);}},40);}));
 ok(samples.maxFlash<=.2&&samples.stuck===0,'in a long fight no enemy flash exceeds its lifetime and none is stuck dying/unengaged ('+JSON.stringify(samples)+')');
 ok((samples.max.parts||0)<300&&(samples.max.fx||0)<30&&(samples.max.texts||0)<40,'effect lists stay bounded');
 await E(()=>{__game.dbg.endFight();});await sleep(400);
 ok((await bad()).length===0,'no leftovers after the fight '+JSON.stringify(await bad()));
 await setup();await sleep(900);await shot('no-ghost-blobs');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
