// M26: Oakvale is monster-free; Town Guards at the entrances end fights you run into town.  node tests/ms26.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms26',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();});
 const reset=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.calm=0;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;e.fa=0;e.ta=0;});g.P.hp=1e6;g.P.lv=Math.max(g.P.lv,3);d.toasts.length=0;});
 const at=(tx,ty)=>E((tx,ty)=>{const g=__game;g.tp(tx,ty);g.P.x=tx*32+16;g.P.y=ty*32+28;g.P.grace=0;},tx,ty);
 const put=(type,x,y,fa)=>E((type,x,y,fa)=>{const g=__game,e=g.enemies.find(q=>q.type===type&&!q.def.boss);e.x=e.hx=x;e.y=e.hy=y;e.fa=e.ta=fa;e.mode='look';e.mt=e.lk=1e9;e.hp=e.maxhp;window.__e=e;},type,x,y,fa);
 // ---- spawn rules
 const sp=await E(()=>{const g=__game,t=g.townDbg(),T=t.TOWN;const inside=g.enemies.filter(e=>t.inTownPx(e.hx,e.hy-8)||t.inTownPx(e.x,e.y-8)).length;
   const near=g.enemies.filter(e=>e.hy<100*32&&t.townNear(e.hx,e.hy,2.5*32)).length;return {inside,near,slimes:g.enemies.filter(e=>e.type==='slime'&&e.hy<100*32).map(e=>[e.hx/32|0,e.hy/32|0].join(':')).join(' ')};});
 ok(sp.inside===0,'no monster spawns or stands inside the village ('+sp.inside+')');
 ok(sp.near===0,'no monster home within 2.5 tiles of the village walls ('+sp.slimes+')');
 // ---- guards
 const gd=await E(()=>{const g=__game,t=g.townDbg(),gs=t.guardsOf();return {n:gs.length,lv:Math.min(...gs.map(q=>q.lv)),pos:gs.map(q=>[(q.x/32).toFixed(1),(q.y/32).toFixed(1)].join(',')),inT:gs.every(q=>t.inTownPx(q.x,q.y-8)),spr:!!g.dbg.SP.tguard,lines:gs.every(q=>q.lines.length>=2)};});
 ok(gd.n===2&&gd.lv>=25&&gd.spr&&gd.lines,'Town Guards (level '+gd.lv+') have their own armoured sprite and dialogue: '+gd.pos.join(' | '));
 ok(gd.inT,'guards stand at the north gate and the east bridge, inside the walls');
 const sp2=await E(()=>{const g=__game,d=g.dbg,gs=g.townDbg().guardsOf();return gs.map(q=>{const tx=Math.floor(q.x/32),ty=Math.floor(q.y/32);
   const t=g.dbg.map?g.dbg.map[ty][tx]:null;let lan=99;for(let y=ty-3;y<=ty+3;y++)for(let x=tx-3;x<=tx+3;x++)if(d.map[y][x]===d.T.LN)lan=Math.min(lan,Math.hypot(x-tx,y-ty));
   let npc=99;for(const n of g.npcs)if(n!==q)npc=Math.min(npc,Math.hypot(n.x-q.x,n.y-q.y)/32);
   return {tx,ty,road:t===d.T.P,solid:d.SOLID.has(t),lan,npc};});});
 ok(sp2[0].tx===14&&sp2[0].ty===30,'guard 1 stands beside the gap in the north fence ('+sp2[0].tx+','+sp2[0].ty+')');
 ok(sp2[1].tx>=21&&sp2[1].tx<=23&&sp2[1].ty>=38&&sp2[1].ty<=40,'guard 2 stands at the east bridge approach ('+sp2[1].tx+','+sp2[1].ty+')');
 ok(sp2.every(q=>!q.road&&!q.solid),'neither guard stands on the road or in a wall');
 ok(sp2.every(q=>q.lan>=1.8&&q.npc>=1.6),'neither overlaps a lantern or another NPC ('+sp2.map(q=>q.lan.toFixed(1)+'/'+q.npc.toFixed(1))+')');
 // ---- never wanders in: slime just north of the fence, walking south
 await reset();await at(12,32);
 await E(()=>{const g=__game,e=g.enemies.find(q=>q.type==='slime'&&!q.def.boss);e.x=e.hx=12.5*32;e.y=e.hy=28.3*32;e.fa=e.ta=Math.PI/2;e.mode='walk';e.mt=60;e.lk=1e9;e.vr=0;e.ar=0;window.__e=e;g.P.grace=99;});
 let inside=false;for(let i=0;i<24;i++){await sleep(150);if(await E(()=>__game.townDbg().inTownPx(window.__e.x,window.__e.y-8)))inside=true;}
 ok(!inside,'a monster walking at the gate is turned back at the village boundary');
 // ---- no aggro while the hero is in town
 await reset();await at(12,31);await put('knight',12.5*32,26*32+28,Math.PI/2);await E(()=>{__game.P.grace=0;});await sleep(1500);
 ok(await E(()=>!__game.B),'a knight watching the gate does not start a fight while the hero stands in town');
 // ---- running into town mid-fight: guards strike the pursuers, fight ends safely
 await reset();await at(12,31);await put('knight',12.5*32,26*32+28,Math.PI/2);
 const began=await E(()=>{const g=__game;g.dbg.startEncounter(window.__e,true);g.P.grace=0;window.__e.hp=window.__e.maxhp=window.__e.mhp=9999;return !!g.B;});   // (guards now react within a frame)
 ok(began,'combat started with the hero standing at the gate');
 let ended=false,bolts=0;for(let i=0;i<30&&!ended;i++){await sleep(150);bolts=Math.max(bolts,await E(()=>__game.townDbg().TGB.length));ended=await E(()=>!__game.B);}
 ok(bolts>0,'a guard bolt strikes the pursuer');
 ok(ended,'the fight ends safely');
 const af=await E(()=>({alive:window.__e.alive,grace:__game.P.grace,hp:__game.P.hp,state:__game.state,xp:__game.P.xp}));
 ok(!af.alive&&af.grace>0&&af.state==='play','the knight was struck down, the hero gets breathing room ('+JSON.stringify(af)+')');
 // ---- the HERO lands the kill in town: normal victory, no "Town Guard drove them off"
 await reset();await at(12,31);await put('slime',12.5*32,29*32,Math.PI/2);
 const kill=await E(()=>{const g=__game,d=g.dbg;g.townDbg().guardsOf().forEach(q=>{q.gcd=1e9;});d.toasts.length=0;g.P.hp=d.maxHp();
   g.dbg.startEncounter(window.__e,true);g.P.grace=0;const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(x=>{x.joinT=0;x.atkCd=1e9;});const e=window.__e;e.hp=1;window.__g0=g.P.gold;window.__x0=g.P.xp;
   B.shots.push({x:e.x,y:e.y-13,vx:0,vy:0,r:10,dmg:500,own:'p',kind:'arcane',life:1,a:0});return {inTown:g.townDbg().inTownPx(g.P.x,g.P.y-8)};});
 let drove=false;for(let i=0;i<30;i++){await sleep(120);if(await E(()=>__game.dbg.toasts.some(t=>/drove them off/i.test(t.s))))drove=true;}
 const kr=await E(()=>({dead:!window.__e.alive,gold:__game.P.gold>window.__g0,xp:__game.P.xp>window.__x0||__game.P.lv>1,B:!!__game.B}));
 ok(!drove,'killing a foe yourself in town never says the Town Guard drove it off');
 ok(kr.dead&&(kr.gold||kr.xp),'... and the normal victory runs (reward granted) '+JSON.stringify(kr));
 // ---- bosses are driven off instead (3 strikes) and heal / go home calm
 await reset();await at(12,31);await put('knight',12.5*32,26*32+28,Math.PI/2);
 await E(()=>{const g=__game,e=window.__e;e.def=Object.assign({},e.def,{boss:true});e.hp=e.maxhp=e.mhp=9999;g.dbg.startEncounter(e,true);g.P.grace=0;});
 ended=false;for(let i=0;i<40&&!ended;i++){await sleep(150);ended=await E(()=>!__game.B);}
 const bo=await E(()=>{const e=window.__e;return {alive:e.alive,home:Math.hypot(e.x-e.hx,e.y-e.hy)<4,hp:e.hp===e.maxhp,calm:e.calm>0};});
 ok(ended&&bo.alive&&bo.home&&bo.hp&&bo.calm,'a boss is driven off: back home at full health, calm ('+JSON.stringify(bo)+')');
 // ---- anything that ends up inside the walls is repelled
 await reset();await at(10,22);await E(()=>{const g=__game,e=g.enemies.find(q=>q.type==='goblin'&&!q.def.boss);e.x=10*32;e.y=33*32;window.__e=e;});await sleep(400);
 ok(await E(()=>{const e=window.__e;return !__game.townDbg().inTownPx(e.x,e.y-8)&&Math.abs(e.x-e.hx)<2;}),'a monster that appears inside town is sent home');
 // ---- chase: an enemy hunting the hero cannot follow him through the gate
 await reset();await at(12,27);await put('knight',12.5*32,23*32,Math.PI/2);await E(()=>{window.__e.hp=window.__e.maxhp=window.__e.mhp=99999;__game.dbg.startEncounter(window.__e,true);__game.B.ens[0].atkCd=99;});
 await sleep(400);await E(()=>{const g=__game;g.P.x=12.5*32;g.P.y=34*32;});   // hero walks into town; knight (stepEnemy) must not follow
 let crossed=false;for(let i=0;i<20;i++){await sleep(120);if(await E(()=>window.__e.alive&&__game.townDbg().inTownPx(window.__e.x,window.__e.y-8)))crossed=true;}
 ok(!crossed,'pursuers never cross the boundary');
 // ---- screenshots: each guard spot
 await reset();await at(12,32);await E(()=>{const g=__game;g.P.grace=99;g.P.hp=g.dbg.maxHp();g.dbg.TRK.open=false;g.P.dir='u';});await sleep(3500);await E(()=>{__game.dbg.toasts.length=0;__game.dbg.TRK.open=false;});
 await shot(MOBILE?'town-guards.png':'town-guards-desktop.png');
 await at(21,36);await E(()=>{const g=__game;g.P.grace=99;g.P.dir='r';g.dbg.toasts.length=0;});await sleep(1500);
 await shot(MOBILE?'town-guards-2.png':'town-guards-2-desktop.png');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
