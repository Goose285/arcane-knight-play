// Feature assertions (gear, quests, dungeon, music, day/night): node tests/features.js [desktop|mobile]
const puppeteer=require('puppeteer-core');const path=require('path');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const MOBILE=process.argv[2]==='mobile';const URL='file://'+path.join(__dirname,'..','index.html');
const fails=[];let n=0;const ok=(c,m)=>{n++;if(!c){fails.push(m);console.log('  FAIL: '+m);}};
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});if(MOBILE)await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);else await pg.setViewport({width:960,height:640});
 const E=(f,...a)=>pg.evaluate(f,...a);
 const tap=async(tag)=>{await E(t=>{const U=__game.dbg.UI;U.scroll=t.startsWith('equip')||t.startsWith('sell')?1e6:0;},tag);await sleep(120);const p=await E(t=>{const r=__game.dbg.UI.rects.find(q=>q.tag===t);if(!r)return null;const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},tag);if(!p)return false;
   if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(150);return true;};
 await pg.goto(URL);await pg.evaluate(()=>localStorage.clear());await pg.goto(URL);await sleep(500);
 if(MOBILE)await pg.touchscreen.tap(200,400);else await pg.keyboard.press('Space');await sleep(500);
 ok(await E(()=>__game.state)==='play','game starts');
 const dg=await E(()=>{const g=__game,d=g.dbg,out={};
   const en=g.enemies;const bats=en.filter(e=>e.type==='bat'),wr=en.filter(e=>e.type==='wraith'&&!e.night),li=en.filter(e=>e.type==='lich');
   out.spawned=bats.length>=6&&wr.length>=5&&li.length===1;
   out.lv=[...bats,...wr.filter(e=>!e.night)].every(e=>e.lv>=8&&e.lv<=14);
   out.lich=li[0].def.boss&&li[0].def.freezeImmune&&!!li[0].terr&&li[0].lv>=14&&li[0].def.big;
   out.inCrypt=[...bats,...wr,...li].every(e=>e.hy/32>=d.CRY0);
   out.areaName=d.areaName(31,60)==='CRYPT OF HOLLOW KINGS'&&d.areaName(10,20)!=='CRYPT OF HOLLOW KINGS';
   // crypt is only reachable by the stairs
   out.disconnected=!d.reach[60][31];
   out.stairs=d.map[19][5]===d.T.CS&&d.reach[19][5];
   return out;});
 for(const [k,v] of Object.entries(dg))ok(v,'dungeon: '+k);
 // ================= GEAR =================
 const g1=await E(()=>{const d=__game.dbg;d.resetGear();const out={};
   out.empty=d.gearStats().hp===0&&d.GEAR.inv.length===0;
   out.slots=['weapon','armor','ring'].every(s=>{const it=d.genGear(s,5,'rare');return it.slot===s&&Object.keys(it.st).length>=1;});
   const w=d.genGear('weapon',8,'epic'),a=d.genGear('armor',8,'epic');
   out.wShot=w.st.shot>0;out.aHp=a.st.hp>0;
   const dmg0=__game.P.lv;d.addGear(w);d.addGear(a);
   const hp0=__game.maxHpFn?0:0;
   out.inv=d.GEAR.inv.length===2;
   d.equipGear(w);d.equipGear(a);
   out.eq=d.GEAR.eq.weapon===w&&d.GEAR.eq.armor===a&&d.GEAR.inv.length===0;
   const s=d.gearStats();out.stats=s.shot>=w.st.shot&&s.hp>=a.st.hp+(w.st.hp||0);
   // rarity ordering: higher rarity -> bigger primary on average
   const avg=r=>{let t=0;for(let i=0;i<60;i++)t+=d.genGear('weapon',10,r).st.shot;return t/60;};
   out.rar=avg('legendary')>avg('common');
   // boss guaranteed drop of epic/legendary
   out.boss=Array.from({length:30},()=>d.rollGearDrop({type:'dragon',lv:10,def:{boss:true}})).every(x=>x&&(x.rar==='epic'||x.rar==='legendary'));
   // normal drops are not guaranteed and rarer at low level
   let got=0;for(let i=0;i<400;i++)if(d.rollGearDrop({type:'slime',lv:1,def:{}}))got++;out.dropRate=got>5&&got<150;
   // sell
   const ring=d.genGear('ring',6,'uncommon');d.addGear(ring);const g0=__game.P.gold;d.sellGear(ring);out.sell=__game.P.gold>g0&&!d.GEAR.inv.includes(ring);
   // save round trip
   __game.saveGame('t');const sv=__game.readSave();out.saved=!!(sv&&sv.gear&&sv.gear.eq.weapon&&sv.gear.eq.weapon.id===w.id);
   d.resetGear();out.reset=!d.GEAR.eq.weapon;d.unpackGear(sv.gear);out.restored=d.GEAR.eq.weapon&&d.GEAR.eq.weapon.name===w.name&&d.GEAR.eq.armor.name===a.name;
   return out;});
 for(const [k,v] of Object.entries(g1))ok(v,'gear: '+k);
 // equipment screen via the pause menu
 await E(()=>{const g=__game;g.state='paused';});await sleep(150);
 
 await E(()=>{__game.dbg.openGear();});await sleep(200);
 ok(await E(()=>__game.dbg.UI.mode)==='gear','equipment screen opens');
 await E(()=>{const d=__game.dbg;d.addGear(d.genGear('weapon',12,'legendary'));});await sleep(200);
 ok(await E(()=>__game.dbg.uiRows().length)>=7,'equipment screen lists rows');
 const eqTag=await E(()=>{const it=__game.dbg.GEAR.inv[0];return 'equip:'+it.id;});
 const hadW=await E(()=>__game.dbg.GEAR.eq.weapon.id);
 ok(await tap(eqTag),'EQUIP button present');
 ok(await E(id=>__game.dbg.GEAR.eq.weapon.id!==id,hadW),'tapping EQUIP swaps weapon');
 ok(await E(()=>__game.dbg.GEAR.inv.length)===1,'old weapon returned to backpack');
 ok(await tap('unequip:weapon'),'REMOVE button present');
 ok(await E(()=>!__game.dbg.GEAR.eq.weapon),'tapping REMOVE unequips');
 await E(()=>{__game.dbg.closeUI();});await sleep(200);ok(await E(()=>__game.state)==='paused','Done returns to pause menu');await E(()=>{__game.state='play';});
 // gear drop -> full loot screen (B.drops hook)
 const loot=await E(async()=>{const g=__game,d=g.dbg;d.resetGear();
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;e.engaged=false;});
   const e=g.enemies.find(o=>o.type==='knight');g.tp(10,38);g.P.grace=99;g.P.hp=1e6;e.x=g.P.x+40;e.y=g.P.y;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;
   const orig=Math.random;Math.random=()=>0.001; // force a drop
   d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=1;
   B.shots.push({x:e.x,y:e.y-13,vx:0,vy:0,r:10,dmg:50,own:'p',kind:'arcane',life:1,a:0});
   await new Promise(r=>setTimeout(r,900));Math.random=orig;
   return {phase:g.B&&g.B.phase,drops:g.B?g.B.drops.map(x=>!!x.item):[],eq:!!d.GEAR.eq.weapon||!!d.GEAR.eq.armor||!!d.GEAR.eq.ring||d.GEAR.inv.length>0};});
 ok(loot.eq,'gear dropped from a kill and entered inventory');
 ok(loot.phase==='reward'||loot.phase==='win','gear drop triggers the victory/loot screen (phase='+loot.phase+')');
 ok(loot.drops.includes(true),'loot screen lists the gear item');

 // ================= QUESTS =================
 const q1=await E(async()=>{const g=__game,d=g.dbg;d.resetQuests();const out={};
   const npc=n=>d.NPCS.find(x=>x.name===n);
   out.count=d.QUESTS.length>=6&&d.QUESTS.length<=10;
   d.STORY.ch=5;   // story scenes also put a marker on Orin; this block tests plain quest markers
   out.givers=['Elder Orin','Pip','Gate Guard','Blacksmith Brum'].every(n=>d.QUESTS.some(q=>q.giver===n));
   out.kinds=['kill','collect','find','reach'].every(k=>d.QUESTS.some(q=>q.obj.k===k))&&d.QUESTS.some(q=>q.obj.type==='lich');
   out.avail=d.questStatus('slimes')==='avail'&&d.questStatus('ring')==='locked'&&d.questStatus('lich')==='locked';
   out.mark=d.npcMarker(npc('Elder Orin'))==='avail'&&d.npcMarker(npc('Pip'))==='avail';
   // talk -> offer (with choice) -> accept
   d.questTalk(npc('Elder Orin'));out.offer=!!(g.DLG&&g.DLG.choice);g.DLG.choice();
   out.started=d.questStatus('slimes')==='active';out.markActive=d.npcMarker(npc('Elder Orin'))==='active';
   // progress by kills
   d.questEvent('kill','slime');d.questEvent('kill','slime');out.prog=d.questProgress(d.QUEST_BY_ID.slimes)===2&&d.questStatus('slimes')==='active';
   d.questEvent('kill','knight');out.ignoreOther=d.questProgress(d.QUEST_BY_ID.slimes)===2;
   d.questEvent('kill','slime');out.ready=d.questStatus('slimes')==='ready'&&d.npcMarker(npc('Elder Orin'))==='ready';
   const g0=g.P.gold;d.questTalk(npc('Elder Orin'));out.reward=g.P.gold>=g0+60&&d.questStatus('slimes')==='done';
   out.unlock=d.questStatus('ring')==='avail';
   // collect quest from drops
   d.questStart('gel');const r0=Math.random;Math.random=()=>0.001;for(let i=0;i<5;i++)d.questLoot({type:'slime'});Math.random=r0;
   out.collect=d.QS.items.gel===3&&d.questStatus('gel')==='ready';
   const own0=d.COL().frostbolt|0;d.questTalk(npc('Pip'));out.card=(d.COL().frostbolt|0)>own0&&d.QS.items.gel===0&&d.questStatus('gel')==='done';
   // find quest: item on the map
   d.questStart('ring');out.hidden=d.questWorldItems().length===1;const w=d.questWorldItems()[0];
   out.ringReach=d.reach[w.ty][w.tx];
   g.P.x=w.tx*32+16;g.P.y=w.ty*32+22;d.updateQuestWorld();out.found=d.questStatus('ring')==='ready'&&d.questWorldItems().length===0;
   const inv0=d.GEAR.inv.length+Object.values(d.GEAR.eq).filter(Boolean).length;d.questTalk(npc('Elder Orin'));
   out.gear=d.GEAR.inv.length+Object.values(d.GEAR.eq).filter(Boolean).length===inv0+1;
   // reach: area visited BEFORE accepting still counts
   d.questEvent('area',d.QUEST_BY_ID.crypt.obj.area);
   for(const id of ['goblins']){d.questStart(id);for(let i=0;i<4;i++)d.questEvent('kill','goblin');d.questTalk(npc('Gate Guard'));}
   d.questStart('crypt');out.reach=d.questStatus('crypt')==='ready';d.questTalk(npc('Gate Guard'));
   out.lichOffered=d.questStatus('lich')==='avail';d.questStart('lich');d.questEvent('kill','lich');out.lichKill=d.questStatus('lich')==='ready';
   d.questTalk(npc('Elder Orin'));out.allDone=d.QUESTS.filter(q=>d.questStatus(q.id)==='done').length===6;
   // smith: quest offered first, shop still reachable when no quest pending
   out.smithOffer=d.npcMarker(npc('Blacksmith Brum'))==='avail';
   // save round trip
   g.saveGame('t');const sv=g.readSave();out.saved=!!(sv&&sv.quests&&sv.quests.st.lich==='done');
   const snap=JSON.stringify(d.packQuests());d.resetQuests();out.reset=d.questStatus('slimes')==='avail';d.unpackQuests(sv.quests);out.restored=JSON.stringify(d.packQuests())===JSON.stringify(sv.quests)&&d.questStatus('slimes')==='done';
   return out;});
 for(const [k,v] of Object.entries(q1))ok(v,'quest: '+k);
 const sm=await E(()=>{const d=__game.dbg;d.resetQuests();d.questTalk(d.NPCS.find(n=>n.smith));const r=!!(__game.DLG&&__game.DLG.noAct&&__game.DLG.no==='SHOP');d.endFight();return r;});
 ok(sm,'quest: Brum offers the quest but still lets you go to the shop (SHOP choice)');
 // real kill in a fight advances quest + drops item
 const q2=await E(async()=>{const g=__game,d=g.dbg;d.resetQuests();d.questStart('gel');
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;e.engaged=false;});
   const e=g.enemies.find(o=>o.type==='slime');g.tp(10,38);g.P.grace=99;g.P.hp=1e6;e.x=g.P.x+40;e.y=g.P.y;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;
   const orig=Math.random;Math.random=()=>0.001;d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=1;
   B.shots.push({x:e.x,y:e.y-13,vx:0,vy:0,r:10,dmg:50,own:'p',kind:'arcane',life:1,a:0});
   await new Promise(r=>setTimeout(r,900));Math.random=orig;
   return {gel:d.QS.items.gel};});
 ok(q2.gel===1,'quest: killing a slime in battle drops Slime Gel');
 // quest log screen
 await E(()=>{__game.state='paused';__game.dbg.openQuests();});await sleep(250);
 ok(await E(()=>__game.dbg.UI.mode)==='quests'&&await E(()=>__game.dbg.uiRows().length)>=4,'quest log opens and lists quests');
 await E(()=>{__game.dbg.closeUI();__game.state='play';});

 // ================= DUNGEON + LICH KING =================
 await E(()=>{__game.dbg.endFight();__game.state='play';});await sleep(200);
 // walk onto the stairs -> fade -> crypt, then back out
 await E(()=>{__game.dbg.endFight();});
 await E(()=>{const g=__game;g.P.grace=99;g.P.hp=1e6;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.tp(5,19);});await sleep(1300);
 const inn=await E(()=>({y:__game.P.y/32,area:__game.dbg.areaName(Math.floor(__game.P.x/32),Math.floor(__game.P.y/32)),st:__game.state}));
 ok(inn.y>=50&&inn.area==='CRYPT OF HOLLOW KINGS'&&inn.st==='play','stairs lead down into the crypt');
 await sleep(500);ok(await E(()=>__game.areaCur==='CRYPT OF HOLLOW KINGS'),'area banner/area state is the crypt');
 await E(()=>{__game.tp(31,85);});await sleep(1300);
 ok(await E(()=>__game.P.y/32<30),'crypt exit stairs lead back to the meadow');
 // every Lich King attack, every phase: telegraph builds, strike runs without error, ring zone hits only the ring
 const lk=await E(async()=>{const g=__game,d=g.dbg,out={};
   g.enemies.forEach(e=>{e.x=2*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;e.engaged=false;});
   const e=g.enemies.find(o=>o.type==='lich');e.x=31.5*32;e.y=57*32;e.alive=true;e.dying=false;g.P.x=31.5*32;g.P.y=60*32;g.P.hp=1e9;g.P.grace=0;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp;
   const c={x:e.x,y:e.y-26},ex0=e.x,ey0=e.y;   // (the Lich's new phase-step teleport moves him during the loop, so measure the ring first)
   const rz=d.Z.ring(c.x,c.y,64,235,19);
   out.ringShape=!d.inZone(rz,{x:c.x+10,y:c.y})&&d.inZone(rz,{x:c.x+130,y:c.y})&&!d.inZone(rz,{x:c.x+300,y:c.y});
   let made=0,kinds=new Set();
   for(const ph of [[false,false],[true,false],[true,true]]){e.p2=ph[0];e.p3=ph[1];
     for(let i=0;i<40;i++){B.owner=e;const a=d.ATK.lich(e);if(!a||!a.strike)return {err:'bad attack'};made++;kinds.add(a.zones.length+':'+(a.zones[0]&&a.zones[0].k));a.strike(e);}}
   out.made=made;out.kinds=kinds.size>=4;
   // ring zone geometry: hit in the ring, safe at the centre and outside it
   await new Promise(r=>setTimeout(r,1200));
   out.alive=g.state==='play';
   // phases trigger on hp thresholds
   return out;});
 ok(!lk.err,'lich: '+(lk.err||'attacks ok'));ok(lk.made===120,'lich: 120 attack rolls built+struck without errors');ok(lk.kinds,'lich: multiple distinct attack shapes');ok(lk.ringShape,'lich: nova ring zone is a donut (safe in the middle and outside)');
 const ph=await E(async()=>{const g=__game,d=g.dbg;const B=g.B,e=B.ens.find(o=>o.type==='lich');B.owner=e;
   B.zones.length=0;B.timers.length=0;e.st='idle';e.p2=false;e.p3=false;e.hp=e.maxhp*.6;d.damageEnemy(e,1);const p2=e.p2&&!e.p3;
   e.bshield=0;e.hp=e.maxhp*.3;d.damageEnemy(e,1);const p3=e.p3;e.bshield=0;return {p2,p3};});
 ok(ph.p2,'lich: phase 2 at <66% hp');ok(ph.p3,'lich: phase 3 at <33% hp');
 // kill the lich: loot screen, guaranteed epic/legendary gear, boss flags, quest completion path
 const kl=await E(async()=>{const g=__game,d=g.dbg;d.resetQuests();d.QS.st.lich='active';const B=g.B,e=B.ens.find(o=>o.type==='lich');
   B.zones.length=0;B.timers.length=0;g.P.hp=1e9;e.bshield=0;e.hp=1;d.damageEnemy(e,50);
   for(let i=0;i<40&&!(g.B&&g.B.phase==='reward');i++)await new Promise(r=>setTimeout(r,100));
   return {phase:g.B&&g.B.phase,boss:g.B&&g.B.boss,name:g.B&&g.B.bossName,gear:g.B?g.B.drops.filter(x=>x.item).map(x=>x.rar):[],down:d.lichState().lichDown,q:d.questStatus('lich')};});
 ok(kl.phase==='reward'&&kl.boss&&kl.name==='LICH KING','lich: victory screen with boss name '+JSON.stringify(kl));
 ok(kl.gear.length===1&&(kl.gear[0]==='epic'||kl.gear[0]==='legendary'),'lich: guaranteed epic/legendary gear drop');
 ok(kl.down,'lich: lichDown flag set');ok(kl.q==='ready','lich: slaying him readies the quest');
 await E(()=>{__game.press('Space');});await sleep(600);
 // lichDown persists in the save
 ok(await E(()=>{__game.saveGame('t');return __game.readSave().lichDown===true;}),'lich: defeat is saved');

 // ================= MUSIC =================
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.P.grace=99;g.P.hp=1e9;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});if(d.DAY.night)d.setTimeOfDay(.5);});
 const tracks=await E(()=>Object.keys(__game.dbg.TRACKS));
 for(const n of ['village','meadow','forest','castle','dungeon','boss','battle'])ok(tracks.includes(n),'music: track '+n);
 const acState=await E(()=>({ac:typeof AC!=='undefined'&&!!AC,st:AC&&AC.state}));
 const spots=[['village',13,38],['meadow',8,22],['forest',40,22],['castle',31,6],['dungeon',31,70]];
 for(const [name,x,y] of spots){
   await E((x,y)=>{__game.tp(x,y);__game.P.grace=99;},x,y);await sleep(450);
   ok(await E(()=>__game.dbg.MUS.name)===name,'music: '+name+' track plays at its location');
 }
 ok(await E(()=>__game.dbg.MUS.notes)>20,'music: notes are being synthesized');
 // crossfade: switching keeps the old track alive (fading) alongside the new one
 await E(()=>{__game.tp(13,38);});await sleep(450);
 const cf=await E(()=>{const M=__game.dbg.MUS;return {n:M.live.length,fading:M.live.filter(o=>o.dead).length};});
 ok(cf.n>=2&&cf.fading>=1,'music: crossfade keeps outgoing track fading ('+JSON.stringify(cf)+')');
 if(acState.st==='running'){await sleep(2400);ok(await E(()=>__game.dbg.MUS.live.length)===1,'music: faded-out track is released');}
 // battle + boss tracks
 const bt=await E(async()=>{const g=__game,d=g.dbg,out={};g.tp(10,20);g.P.grace=99;
   const e=g.enemies.find(o=>o.type==='slime'&&o.alive&&!o.night);e.x=g.P.x+40;e.y=g.P.y;e.hx=e.x;e.hy=e.y;d.startEncounter(e,true);
   await new Promise(r=>setTimeout(r,500));out.battle=d.MUS.name;
   d.endFight();g.tp(31.5,60);g.P.grace=0;g.enemies.forEach(o=>{if(o.type!=='lich'){o.mt=1e9;o.lk=1e9;}});
   const l=g.enemies.find(o=>o.type==='lich');l.alive=true;l.dying=false;l.x=31.5*32;l.y=56*32;d.startEncounter(l,true);g.B.phase='fight';
   await new Promise(r=>setTimeout(r,500));out.boss=d.MUS.name;d.endFight();return out;});
 ok(bt.battle==='battle','music: battle track during a fight');ok(bt.boss==='boss','music: boss track during the Lich King fight');
 // mute toggle respects music
 await E(()=>{__game.dbg.endFight();__game.tp(13,38);});await sleep(400);
 const m1=await E(()=>({t:__game.dbg.MUS.target,n:__game.dbg.MUS.notes}));
 await E(()=>{__game.dbg.PAUSE_ITEMS.find(i=>i.k==='KeyM').act();});await sleep(500);
 const m2=await E(()=>({t:__game.dbg.MUS.target,n:__game.dbg.MUS.notes}));await sleep(500);const m3=await E(()=>__game.dbg.MUS.notes);
 ok(m1.t>0&&m2.t===0,'music: mute drops the music gain to 0');ok(m3===m2.n,'music: no notes scheduled while muted');
 await E(()=>{__game.dbg.PAUSE_ITEMS.find(i=>i.k==='KeyM').act();});await sleep(500);
 const m4=await E(()=>({t:__game.dbg.MUS.target,n:__game.dbg.MUS.notes}));
 ok(m4.t>0&&m4.n>m3,'music: unmute resumes the music');
 // ================= DAY / NIGHT =================
 const dn=await E(async()=>{const g=__game,d=g.dbg,out={};
   out.len=d.DAY.len===480;
   d.setTimeOfDay(.5);out.day=!d.DAY.night&&d.DAY.nightAmt<.05;
   d.setTimeOfDay(.75);out.dusk=d.DAY.nightAmt<.9;
   const slime=g.enemies.filter(e=>e.type==='slime'&&!e.night&&e.alive&&!e.engaged).pop();const base=slime.baseLv;
   d.setTimeOfDay(.5);out.dayLv=slime.lv===base;
   const nightAlive0=g.enemies.filter(e=>e.night&&e.alive).length;out.noNightMobsByDay=nightAlive0===0;
   d.setTimeOfDay(1.0);out.night=d.DAY.night&&d.DAY.nightAmt>.95;
   out.nightLv=slime.lv===base+2;
   const nm=g.enemies.filter(e=>e.night&&e.alive);out.nightMobs=nm.length>=6;
   const w=nm.filter(e=>e.type==='wraith');out.meadowWraith=w.length>=3&&w.every(e=>e.lv>=5&&e.lv<=7); /* positions are parked by earlier tests */
   d.setTimeOfDay(.5);out.dawn=!d.DAY.night&&g.enemies.filter(e=>e.night&&e.alive).length===0&&slime.lv===base;
   // time actually advances (8 min cycle)
   const t0=d.DAY.t;await new Promise(r=>setTimeout(r,1200));out.advances=d.DAY.t>t0+.0015&&d.DAY.t<t0+.01;
   // save/load keeps time of day
   d.setTimeOfDay(.9);g.saveGame('t');out.saved=Math.abs(g.readSave().tod-.9)<.01;d.setTimeOfDay(.5);g.loadSave&&0;
   return out;});
 for(const [k,v] of Object.entries(dn))ok(v,'daynight: '+k);
 // lighting overlay really darkens the screen at night, and torches glow in the crypt
 const lum=async()=>E(()=>{const c=document.getElementById('c'),g=c.getContext('2d'),d=g.getImageData(8,c.height-12,4,4).data;let s=0;for(let i=0;i<d.length;i+=4)s+=d[i]+d[i+1]+d[i+2];return s/(d.length/4*3);});
 await E(()=>{__game.dbg.endFight();__game.state='play';__game.tp(13,38);__game.dbg.setTimeOfDay(.5);});await sleep(500);const lDay=await lum();
 await E(()=>{__game.dbg.setTimeOfDay(1.0);});await sleep(500);const lNight=await lum();
 ok(lNight<lDay*.7,'daynight: night overlay darkens the world ('+Math.round(lDay)+' -> '+Math.round(lNight)+')');
 await E(()=>{__game.dbg.setTimeOfDay(.5);});
 await b.close();
 console.log(`features ${MOBILE?'mobile':'desktop'}: ${n-fails.length}/${n} assertions passed`);process.exit(fails.length?1:0);
})().catch(e=>{console.error('FEATURES CRASH',e);process.exit(1);});
