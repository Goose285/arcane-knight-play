// M49: town guards only act on real threats and fight visibly (damage numbers -> death animation, no rewards); no monster is removed silently (dawn dissolve, sent-home puffs).  node tests/ms49.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms49',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();
   for(const e of g.enemies)if(e.alive&&!e.night){e.mt=1e9;e.lk=1e9;}});
 const reset=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.WARP=null;d.toasts.length=0;g.P.hp=d.maxHp();g.P.grace=0;});
 const put=(type,x,y)=>E((type,x,y)=>{const g=__game,e=g.enemies.find(q=>q.type===type&&!q.def.boss&&!q.night);e.alive=true;e.dying=false;e.gdie=false;e.x=e.hx=x;e.y=e.hy=y;e.fa=e.ta=Math.PI/2;e.mode='look';e.mt=e.lk=1e9;e.hp=e.maxhp;e.calm=0;window.__e=e;},type,x,y);
 // ---- 1. an idle monster right outside the gate is left alone (hero near, not fighting)
 await reset();await E(()=>{const g=__game;g.tp(14,26);g.P.x=14.5*32;g.P.y=26*32;g.P.grace=99;});await put('slime',14.5*32,28.2*32);
 let bolts=0;for(let i=0;i<20;i++){await sleep(150);bolts=Math.max(bolts,await E(()=>__game.townDbg().TGB.length));}
 const idle=await E(()=>({alive:window.__e.alive,hp:window.__e.hp===window.__e.maxhp,dying:window.__e.dying}));
 ok(bolts===0&&idle.alive&&idle.hp&&!idle.dying,'guards do not strike an idle monster standing 2 tiles from the post ('+JSON.stringify(idle)+', bolts '+bolts+')');
 // ---- 2. a fight at the gate: guards hit for damage, the foe plays its death animation, hero gets nothing
 await reset();await E(()=>{const g=__game;g.tp(12,31);g.P.x=12.5*32;g.P.y=31*32+28;g.P.grace=0;});await put('slime',12.5*32,27*32+28);
 await E(()=>{const g=__game,e=window.__e;e.hp=e.maxhp=e.mhp=100;g.dbg.startEncounter(e,true);g.P.grace=0;window.__g0=g.P.gold;window.__x0=g.P.xp;window.__k0=g.dbg.kills;});
 const seen={part:false,dying:false,gone:false,drove:false};let maxHpSeen=0;
 for(let i=0;i<60&&!seen.gone;i++){await sleep(80);
  const s=await E(()=>{const e=window.__e;return {hp:e.hp,alive:e.alive,dying:e.dying,gdie:!!e.gdie,drove:__game.dbg.toasts.some(t=>/drove them off/i.test(t.s))};});
  if(s.alive&&!s.dying&&s.hp<100&&s.hp>0)seen.part=true;if(s.alive&&s.dying)seen.dying=true;if(!s.alive)seen.gone=true;if(s.drove)seen.drove=true;}
 ok(seen.part,'a guard bolt wounds the foe first (visible damage, not an instant delete)');
 ok(seen.dying,'then the foe plays its death animation before it is gone');
 ok(seen.gone,'and the guard-killed foe is gone afterwards');
 ok(!seen.drove,'killing it is not reported as "drove them off"');
 for(let i=0;i<30&&await E(()=>!!__game.B);i++)await sleep(150);
 const pay=await E(()=>({gold:__game.P.gold===window.__g0,xp:__game.P.xp===window.__x0,B:!!__game.B,state:__game.state}));
 ok(pay.gold&&pay.xp&&!pay.B&&pay.state==='play','the hero gets no gold / XP for a guard kill and the fight ends cleanly '+JSON.stringify(pay));
 // ---- 3. night monsters dissolve visibly at dawn (burst + text), never blink out
 await reset();await E(()=>{const g=__game,d=g.dbg;g.tp(30,20);d.setTimeOfDay(0);const w=g.enemies.find(e=>e.night);w.alive=true;w.engaged=false;w.dying=false;window.__w=w;d.WFX.length=0;});
 const n0=await E(()=>__game.dbg.WFX.length);
 await E(()=>{__game.dbg.setTimeOfDay(.5);});
 const dn=await E(()=>({alive:window.__w.alive,fx:__game.dbg.WFX.length,txt:__game.dbg.WFX.some(q=>q.k==='t'&&/dawn/.test(q.s))}));
 ok(!dn.alive&&dn.fx>n0&&dn.txt,'a night monster at dawn fades with a visible burst and text ('+JSON.stringify(dn)+')');
 // ---- 4. the hero's own kill near the gate still rewards normally (guards do not steal it when the hero is away from the post)
 await reset();await E(()=>{const g=__game;g.tp(14,22);g.P.x=14.5*32;g.P.y=22*32;g.P.grace=0;});await put('slime',14.5*32,20*32);
 const rw=await E(async()=>{const g=__game,d=g.dbg,e=window.__e;e.hp=1;d.startEncounter(e,true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(x=>{x.joinT=0;x.atkCd=1e9;});const g0=g.P.gold;
   B.shots.push({x:e.x,y:e.y-13,vx:0,vy:0,r:10,dmg:500,own:'p',kind:'arcane',life:1,a:0});await new Promise(r=>setTimeout(r,1200));return {dead:!e.alive||e.dying,gold:g.P.gold>g0};});
 ok(rw.dead&&rw.gold,'a normal kill away from the gate pays gold as usual '+JSON.stringify(rw));
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
