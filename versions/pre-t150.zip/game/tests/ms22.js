// M22: pause menu redesign (main screen of big buttons + sub-pages with BACK).  node tests/ms22.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms22');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';g.P.hp=d.maxHp();g.P.grace=9999;g.P.lv=6;g.P.gold=240;});
 await sleep(300);
 const st=()=>E(()=>__game.state),pageOf=()=>E(()=>__game.dbg.PAUSE.page);
 // tap a pause button by id with a real touch / mouse click
 const tapId=async id=>{const p=await E(id=>{const r=__game.dbg.getPauseRects().find(q=>q.e.id===id);if(!r)return null;const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},id);
   if(!p)return false;if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(250);return true;};
 const rectsOk=()=>E(()=>{const g=__game,rs=g.dbg.getPauseRects(),z=g.size;let ov=false;for(let i=0;i<rs.length;i++)for(let j=i+1;j<rs.length;j++){const a=rs[i],b=rs[j];if(a.x<b.x+b.w&&b.x<a.x+a.w&&a.y<b.y+b.h&&b.y<a.y+a.h)ov=true;}
   return {n:rs.length,fit:rs.every(q=>q.y>=0&&q.y+q.h<=z.VH&&q.x>=0&&q.x+q.w<=z.VW),noOverlap:!ov,minH:Math.min(...rs.map(q=>q.h)),minW:Math.min(...rs.map(q=>q.w)),ids:rs.map(q=>q.e.id).join(',')};});
 // ---- opening: pause button / key
 if(MOBILE){const b=await E(()=>__game.btn.pause);await pg.touchscreen.tap(b.x,b.y);}else await pg.keyboard.press('KeyP');
 await sleep(300);ok(await st()==='paused'&&await pageOf()==='main','pause opens on the main page');
 let r=await rectsOk();
 ok(r.ids.startsWith('resume,character,cards,inventory,journal,world,skills,settings,home,quit'),'main page: Resume, Character, Cards, Inventory, Journal, World Map, Skills, Settings, Teleport Home, Save & Quit ('+r.ids+')');
 ok(r.fit&&r.noOverlap,'main page fits the screen without overlap '+JSON.stringify(r));
 ok(r.minH>=28||r.ids.includes('sound'),'big touch targets (min height '+r.minH+')');
 const big=await E(()=>__game.dbg.getPauseRects().filter(q=>q.e.id!=='sound').every(q=>q.kind==='tab'?(q.h>=32&&q.w>=36):q.h>=28&&q.w>=70));ok(big,'satchel tabs are >=36x32 and straps >=70x28');
 await shot(MOBILE?'pause-main.png':'pause-main-desktop.png');
 // ---- sub-pages: CHARACTER / JOURNAL / SKILLS, each with BACK
 for(const [pid,ids] of [['character','pets,ach,daily,lab,back'],['journal','quests,story,back'],['skills','tree,fish,craft,back']]){
   await tapId(pid);ok(await pageOf()===pid&&await st()==='paused','tapping '+pid+' opens its page');
   r=await rectsOk();ok(r.ids===ids,pid+' page lists '+ids+' (got '+r.ids+')');ok(r.fit&&r.noOverlap&&r.minH>=40,pid+' page fits, no overlap, big targets '+JSON.stringify(r));
   if(pid==='skills')await shot(MOBILE?'pause-skills.png':'pause-skills-desktop.png');
   if(pid==='character')await shot(MOBILE?'pause-character.png':'pause-character-desktop.png');
   await tapId('back');ok(await pageOf()==='main','BACK returns to the main page from '+pid);
 }
 // ---- leaf features open and return to the page they came from
 const cases=[['cards','deck','main'],['inventory','gear','main'],['world','travel','main'],['settings','settings','main']];
 for(const [id,mode,home] of cases){await tapId(id);ok(await st()===mode,id+' opens '+mode+' (got '+await st()+')');
   await E(()=>{__game.dbg.closeUI();});await sleep(150);ok(await st()==='paused'&&await pageOf()===home,id+': closing returns to the pause menu');}
 for(const [pid,id,mode] of [['character','pets','pets'],['character','ach','ach'],['character','daily','daily'],['journal','quests','quests'],['journal','story','story'],['skills','tree','skills'],['skills','fish','fish'],['skills','craft','craft']]){
   await tapId(pid);await tapId(id);ok(await st()===mode,pid+' > '+id+' opens '+mode+' (got '+await st()+')');
   await E(()=>{__game.dbg.closeUI();});await sleep(150);ok(await st()==='paused'&&await pageOf()===pid,pid+' > '+id+': closing returns to the '+pid+' page');
   await tapId('back');}
 // ---- keyboard: hotkeys still work, Esc = back, arrows + Enter
 await E(()=>{__game.press('KeyT');});await sleep(250);ok(await st()==='skills','hotkey T opens the skill tree from the pause menu');
 await E(()=>{__game.dbg.closeUI();});await sleep(150);ok(await pageOf()==='skills','... and returns to the Skills page');
 await E(()=>{__game.press('Escape');});await sleep(200);ok(await pageOf()==='main'&&await st()==='paused','Esc on a sub-page goes back to main (not resume)');
 await E(()=>{__game.press('ArrowDown');});await sleep(150);await E(()=>{__game.press('Enter');});await sleep(250);
 ok(await E(()=>__game.dbg.PAUSE.kbd),'arrow keys move a highlight');await E(()=>{__game.dbg.pauseReset();});await sleep(250);
 // ---- Resume
 await tapId('resume');ok(await st()==='play','RESUME returns to the game');
 await E(()=>{__game.state='paused';__game.dbg.pauseReset();});await sleep(200);
 // ---- Save & Quit: needs a second tap, saves, lands on the title with Continue available
 await E(()=>{__game.P.gold=777;});
 await tapId('quit');ok(await st()==='paused','Save & Quit: first tap only asks to confirm');
 await tapId('quit');await sleep(300);ok(await st()==='title','Save & Quit: second tap goes to the title screen');
 ok(await E(()=>{const s=JSON.parse(localStorage.getItem(Object.keys(localStorage).find(k=>/save/i.test(k))));return s&&s.P&&s.P.gold===777;}),'... and the game was saved first');
 await sleep(300);const items=await E(()=>__game.titleMenu.items.join(','));ok(/Continue/.test(items),'title offers Continue ('+items+')');
 await E(()=>{const t=__game.titleMenu;t.sel=0;});await E(()=>{__game.press('Space');});await sleep(500);
 ok(await st()==='play'&&await E(()=>__game.P.gold)===777,'Continue resumes the saved game');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
