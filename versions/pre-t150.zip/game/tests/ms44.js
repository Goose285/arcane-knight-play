// M44: tracker shows progress + arrow (expanded by default; collapsed chip keeps count/bar/arrow), fishing hero animation + subtle catch feedback.  node tests/ms44.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms44',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.resetPets();
   for(const e of g.enemies)if(e.alive){e.alive=false;e.hidden=true;e.x=64;e.y=64;e.respawn=1e9;}});
 // ---- tracker: Goblin Iron
 await E(()=>{const d=__game.dbg;d.QS.st={};d.QS.n={};d.QS.items={};d.QS.ord=[];d.TRK.id=null;d.TRK.open=false;d.TRK.sig=null;d.TRK.done=null;d.startQuest&&d.startQuest('iron');});
 const has=await E(()=>!!__game.dbg.startQuest);
 if(!has){await E(()=>{const d=__game.dbg;d.QS.st.iron='active';d.QS.ord=['iron'];d.QS.n.iron=0;d.QS.items.iron=0;d.TRK.id='q:iron';});}
 await sleep(500);
 let e=await E(()=>{const d=__game.dbg,x=d.trkEntries().find(q=>q.id==='q:iron');return x&&{prog:x.prog,need:x.need,name:x.name};});
 ok(e&&e.need===3&&e.prog===0,'Goblin Iron tracks 0/3 ('+JSON.stringify(e)+')');
 // collapsed chip must carry the count, bar and arrow: pixels at the right edge of the chip are drawn (not the plain fill)
 await E(()=>{__game.dbg.TRK.open=false;});await sleep(300);
 const r1=await E(()=>__game.dbg.TRK.rect&&{...__game.dbg.TRK.rect});ok(r1&&r1.h>20,'collapsed chip still renders');
 await shot('tracker-collapsed-landscape.png');
 // a progress change pops it open and the count goes 1/3
 await E(()=>{const d=__game.dbg;d.QS.items.iron=1;});await sleep(500);
 const o=await E(()=>{const d=__game.dbg,x=d.trkEntries().find(q=>q.id==='q:iron');return {open:d.TRK.open,prog:x.prog,flash:d.TRK.flash>0};});
 ok(o.open&&o.prog===1&&o.flash,'picking up an item updates progress 1/3 and opens the tracker ('+JSON.stringify(o)+')');
 await sleep(400);await shot('tracker-goblin-iron-landscape.png');
 await E(()=>{const d=__game.dbg;d.QS.items.iron=2;});await sleep(300);
 ok(await E(()=>__game.dbg.trkEntries().find(q=>q.id==='q:iron').prog===2),'progress 2/3');
 // saved collapsed flag never hides it on load
 const sv=await E(()=>{const d=__game.dbg;d.TRK.open=false;const p=d.packQuests();d.unpackQuests(p);return d.TRK.open;});
 ok(sv===true,'tracker always starts expanded after load');
 await E(()=>{__game.dbg.QS.st.iron=undefined;delete __game.dbg.QS.st.iron;});
 // ---- fishing animation + feedback
 await E(()=>{const g=__game,d=g.dbg;d.QS.st={};d.TRK.open=false;d.resetFish();d.FSH.rod=0;g.P.grace=99;g.tp(24,41);});
 await sleep(400);
 await E(()=>{const g=__game;g.press('KeyE');});await sleep(180);
 const c0=await E(()=>{const d=__game.dbg;return {ph:d.FISH.ph,pose:d.fishPose()};});
 await shot('fishing-anim-cast.png');
 ok(c0.ph==='cast'&&Math.abs(c0.pose.bend)>0,'cast: swing pose active ('+JSON.stringify(c0)+')');
 await sleep(1400);
 const i0=await E(()=>{const d=__game.dbg;return {ph:d.FISH.ph,b:d.fishPose().bend,g:d.fishRodGeom().tip};});
 ok(i0.ph==='on'&&i0.b>.05&&i0.b<.3,'idle: rod held out with a gentle bend ('+JSON.stringify(i0)+')');
 await E(()=>{const d=__game.dbg;d.FISH.fid={t:0,dur:1,nx:50};});await sleep(450);
 ok(await E(()=>__game.dbg.fishPose().lift>2),'idle fidget lifts the rod');
 await shot('fishing-anim-idle.png');
 await E(()=>{const d=__game.dbg;d.FISH.next=.03;});await sleep(200);
 const y=await E(()=>{const d=__game.dbg;return {yank:d.FISH.yank,lift:d.fishPose().lift,pop:d.FISH.fx.some(q=>q.fish),flash:!!d.FISH.flash};});
 ok(y.yank>0&&y.lift>3&&y.pop&&!y.flash,'catch: quick yank + fish pop, no flash ('+JSON.stringify(y)+')');
 await sleep(250);await shot('fishing-anim-catch.png');
 await E(()=>{const d=__game.dbg;d.FISH.rare=.03;d.FISH.next=99;});await sleep(500);
 const rb=await E(()=>{const d=__game.dbg;return {ph:d.FISH.ph,b:d.fishPose().bend};});
 ok(rb.ph==='rare'&&rb.b>.4,'rare bite: excited rod bend ('+JSON.stringify(rb)+')');
 await shot('fishing-anim-rare-bite.png');
 await pg.keyboard.press('Space');await sleep(300);
 const rs=await E(()=>{const d=__game.dbg;return d.FISH.fx.filter(q=>q.fish).map(q=>q.big);});
 ok(rs.length&&rs[0]===true,'rare catch: golden-sparkle fish pop');await shot('fishing-anim-rare-catch.png');
 // all four facings animate without throwing
 for(const dir of ['l','r','u','d']){await E((dir)=>{const g=__game;g.P.dir=dir;},dir);await sleep(250);}
 ok(true,'all four facings render');
 await finish();
})();
