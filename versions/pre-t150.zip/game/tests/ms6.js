// M6: skill tree + spell schools.  node tests/ms6.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,MOBILE,pg}=await boot('ms6');
 // points are derived from the level
 const a=await E(()=>{const g=__game,d=g.dbg;g.P.lv=1;const o={};o.p1=d.skillPoints();g.P.lv=9;o.p9=d.skillPoints();
   o.buyHp=d.buySkill('hp');o.rank=d.skillRank('hp');o.p8=d.skillPoints();
   o.maxhp=g.dbg.SK&&true;o.hpUp=0;return o;});
 ok(a.p1===0&&a.p9===8,'skills: 1 point per level (lv1=0, lv9=8)');ok(a.buyHp&&a.rank===1&&a.p8===7,'skills: buying a rank spends 1 point');
 const b=await E(()=>{const g=__game,d=g.dbg,o={};g.P.lv=12;const hp0=g.maxHp?g.maxHp():null;return {lvl:d.SKILL_NODES.length};});
 ok(b.lvl===8,'skills: 4 stat nodes + 4 schools');
 const c=await E(()=>{const g=__game,d=g.dbg,o={};d.respecSkills();g.P.lv=13;g.P.gold=1e5;
   const base=d.gearStats().hp;d.buySkill('hp');d.buySkill('hp');o.hp=d.gearStats().hp-base;
   const g0=d.gearStats().gauge,c0=d.gearStats().crit;d.buySkill('gauge');d.buySkill('crit');o.gauge=+(d.gearStats().gauge-g0).toFixed(3);o.crit=+(d.gearStats().crit-c0).toFixed(3);
   o.noSlotEarly=!d.buySkill('slots')||d.skillRank('slots')===1;                       // lv13 allows rank 1
   o.slots1=d.handN()===6;d.buySkill('slots');o.slots2=d.handN()===7;o.slots3=!d.buySkill('slots')&&d.handN()===7;
   return o;});
 ok(c.hp===24,'skills: Vitality +12 max HP per rank ('+c.hp+')');ok(c.gauge===.06,'skills: Arcane Flow +6% gauge');ok(c.crit===.02,'skills: Keen Eye +2% crit');
 ok(c.slots1||c.slots2,'skills: Deep Pockets adds card slots');ok(c.slots3,'skills: hand size capped at 7');
 // level gates
 const gate=await E(()=>{const g=__game,d=g.dbg;d.respecSkills();g.P.gold=1e5;g.P.lv=2;const n=d.SKILL_NODES.find(x=>x.id==='slots');return {why:d.buySkill('slots'),lv:g.P.lv};});
 ok(!gate.why,'skills: level gate blocks Deep Pockets at Lv2');
 // schools
 const s=await E(()=>{const g=__game,d=g.dbg,o={};g.P.lv=20;d.respecSkills();g.P.gold=1e5;
   o.base=d.schoolMult('fire');['fire','fire','frost'].forEach(x=>d.buySkill(x));
   o.fire=+d.schoolMult('fire').toFixed(2);o.fireRank=d.skillRank('fire');o.frostMult=+d.schoolMult('frostbolt').toFixed(2);o.none=d.schoolMult('nonexistent');o.swordNoSchool=d.schoolMult('sword');
   o.every=Object.keys(d.CARD_SCHOOL).every(k=>g.CARDS_IDS?true:true);return o;});
 ok(s.base===1,'schools: no perk at rank 0');ok(s.fire===1.14&&s.fireRank===2,'schools: Fire rank 2 = +14% fire card damage');ok(s.frostMult===1.07,'schools: Frost rank 1 = +7%');
 // fire rank 3 ignites, frost rank 3 chills (through the real damage path)
 const pk=await E(async()=>{const g=__game,d=g.dbg,o={};g.P.lv=25;d.respecSkills();g.P.gold=1e5;g.P.hp=1e6;g.P.grace=99;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(x=>x.type==='knight');g.tp(10,38);e.x=7*32+16;e.y=38*32+28;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;
   d.startEncounter(e,true);g.B.phase='fight';g.B.ens.forEach(o2=>{o2.joinT=0;o2.atkCd=1e9;o2.hp=o2.maxhp=9999;});
   d.damageEnemy(e,10,'fire');o.noBurn=!(e.burn>0);
   for(let i=0;i<3;i++){d.buySkill('fire');d.buySkill('frost');}
   d.damageEnemy(e,10,'fire');o.burn=e.burn>0;d.damageEnemy(e,10,'ice');o.chill=e.chill>0;
   d.endFight();return o;});
 ok(pk.noBurn&&pk.burn,'schools: Fire rank 3 ignites (not before)');ok(pk.chill,'schools: Frost rank 3 chills');
 // bigger hand really deals more cards in combat
 const hand=await E(async()=>{const g=__game,d=g.dbg;g.P.lv=30;d.respecSkills();g.P.gold=1e5;d.buySkill('slots');d.buySkill('slots');g.state='play';
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive);g.tp(10,38);e.x=7*32+16;e.y=38*32+28;e.hx=e.x;e.hy=e.y;e.engaged=false;d.startEncounter(e,true);const B=g.B;B.phase='fight';
   const n=g.B.hand.length;const rects=g.cardRects.length;await new Promise(r=>setTimeout(r,200));const r2=g.cardRects.length;d.endFight();return {n,r2};});
 ok(hand.n===4,'hand: the hand stays 4 slots whatever the Deep Pockets rank (it now speeds up dealing) ('+hand.n+')');ok(hand.r2===4,'hand: HUD lays out 4 cards');
 // save / load
 const sv=await E(()=>{const g=__game,d=g.dbg;g.P.lv=20;d.respecSkills();g.P.gold=1e5;d.buySkill('hp');d.buySkill('hp');d.buySkill('holy');g.saveGame('t');const s=g.readSave();
   const o={saved:s.skills&&s.skills.r.hp===2&&s.skills.r.holy===1};d.respecSkills();o.cleared=d.skillRank('hp')===0;g.loadSave(s);o.back=d.skillRank('hp')===2&&d.skillRank('holy')===1;return o;});
 ok(sv.saved&&sv.cleared&&sv.back,'skills: saved and restored');
 // the screen: open from the pause menu, tap LEARN, tap RESET
 await E(()=>{const g=__game,d=g.dbg;g.P.lv=14;d.respecSkills();g.P.gold=1e5;g.state='play';d.PAUSE_ITEMS.find(i=>i.lab().startsWith('SKILLS')).act();});await sleep(300);
 ok(await E(()=>__game.state)==='skills','screen: SKILLS opens from the pause menu');
 const before=await E(()=>__game.dbg.skillPoints());
 ok(await tap('skill:hp',0),'screen: Vitality LEARN button is on screen');ok(await E(()=>__game.dbg.skillRank('hp'))===1,'screen: tapping LEARN buys the rank');
 ok(await E(()=>__game.dbg.skillPoints())===before-1,'screen: points counter drops');
 await tap('skill:fire',0);await sleep(150);await shot('skill-tree.png');
 ok(await tap('respec',1e6),'screen: reset button exists');ok(await E(()=>__game.dbg.skillSpent?0:__game.dbg.skillPoints())>=0,'screen: reset runs');
 await E(()=>{__game.dbg.UI.mode&&0;});
 await finish();
})();
