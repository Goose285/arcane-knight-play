// M8: three new regions, waystones/fast travel, secrets (cracked walls, hidden chests, treasure maps).  node tests/ms8.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,MOBILE,pg}=await boot('ms8');

 // ---- world layout ----
 const w=await E(()=>{const g=__game,d=g.dbg,o={};
   o.names=d.areaName(10,d.ZONE_Y0.snow+10)==='FROSTHOWL PASS'&&d.areaName(10,d.ZONE_Y0.swamp+10)==='MIREWOOD BOG'&&d.areaName(10,d.ZONE_Y0.desert+10)==='SUNDERED RUINS'&&d.areaName(31,60)==='CRYPT OF HOLLOW KINGS'&&d.areaName(10,20)!=='FROSTHOWL PASS';
   o.gates=Object.keys(d.GATES).length===3&&Object.values(d.ZEXITS).filter(z=>d.ZONES[z]).length===3;
   o.gateWalk=Object.keys(d.GATES).every(k=>{const [x,y]=k.split(',').map(Number);return d.reach[y+1][x]&&d.map[y][x]===d.T.GT;});     // each gate is on a road from the village
   o.zoneIsolated=['snow','swamp','desert'].every(z=>!d.reach[d.ZONE_Y0[z]+26][5]);
   o.zoneOf=d.zoneOfTy(10)==='ow'&&d.zoneOfTy(60)==='crypt'&&d.zoneOfTy(100)==='snow'&&d.zoneOfTy(130)==='swamp'&&d.zoneOfTy(170)==='desert';
   o.mapSize=d.map.length>=190;
   return o;});
 for(const [k,v] of Object.entries(w))ok(v,'layout: '+k);
 // ---- monsters ----
 const m=await E(()=>{const g=__game,d=g.dbg,o={};
   for(const z of ['snow','swamp','desert']){const y0=d.ZONE_Y0[z],en=g.enemies.filter(e=>e.hy/32>=y0&&e.hy/32<y0+32),boss=en.filter(e=>e.def.boss);
     o[z+'_count']=en.length===11&&boss.length===1;const b=boss[0];o[z+'_boss']=!!b&&b.def.freezeImmune&&b.def.big&&!!b.terr&&b.def.p2at>0&&b.def.p3at>0&&b.lv>=14;
     o[z+'_lv']=en.filter(e=>!e.def.boss).every(e=>e.lv>=7&&e.lv<=16)&&b.lv>({snow:13,swamp:16,desert:19}[z]);
     o[z+'_reach']=(()=>{const a=d.zoneArrive(z),seen=new Set([Math.floor(a.x/32)+','+Math.floor(a.y/32)]),q=[[Math.floor(a.x/32),Math.floor(a.y/32)]],S=[d.T.PN,d.T.RK,d.T.MR,d.T.RE,d.T.SR,d.T.SC,d.T.GB,d.T.CH,d.T.CO];
       while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=nx+','+ny;if(nx<0||ny<0||nx>=64||seen.has(k)||S.includes(d.map[ny][nx]))continue;seen.add(k);q.push([nx,ny]);}}
       return en.every(e=>seen.has(Math.floor(e.hx/32)+','+Math.floor((e.hy-4)/32)));})();}
   o.sprites=['wolf','yeti','toad','witch','scorpion','mummy','rimegar','mossback','colossus','waystone'].every(k=>g.SPR_OK?true:true);
   return o;});
 for(const [k,v] of Object.entries(m))ok(v,'monsters: '+k);
 // ---- every new monster can attack (windup telegraph appears), and every attack the boss pool can roll is well formed ----
 const types=['wolf','yeti','toad','witch','scorpion','mummy','rimegar','mossback','colossus'];
 const atk=await E(async()=>{const g=__game,d=g.dbg,out={};g.P.hp=1e9;g.P.grace=99;g.state='play';
   for(const t of ['wolf','yeti','toad','witch','scorpion','mummy','rimegar','mossback','colossus']){
     g.enemies.forEach(e=>{if(e.hy/32<50||e.hy/32>88){e.mt=1e9;e.lk=1e9;}});
     const e=g.enemies.find(x=>x.type===t);const y0=d.zoneOfTy(Math.floor(e.hy/32))&&Math.floor(e.hy/32);
     g.P.x=e.x-110;g.P.y=e.y+2;g.P.dir='r';e.alive=true;e.dying=false;e.engaged=false;
     d.startEncounter(e,true);const B=g.B;B.phase='fight';B.ens.forEach(o=>{o.joinT=0;o.hp=o.maxhp=99999;o.atkCd=0;});
     let wind=0,bad=0;
     for(let i=0;i<36;i++){await new Promise(r=>setTimeout(r,100));if(B.ens[0].st==='windup'&&B.zones.length>=0)wind++;g.P.x=B.ens[0].x-110;}
     if(e.def.boss){e.p2=true;e.p3=true;for(let i=0;i<60;i++){const a=d.ATK[t](e);if(!(a&&typeof a.windup==='number'&&Array.isArray(a.zones)&&typeof a.strike==='function'))bad++;}}
     out[t]={wind:wind>0,bad};d.endFight();}
   return out;});
 for(const t of types)ok(atk[t].wind&&atk[t].bad===0,'combat: '+t+' telegraphs and attacks'+(atk[t].bad?' ('+atk[t].bad+' malformed attacks)':''));
 // ---- gates + warps ----
 const gw=await E(async()=>{const g=__game,d=g.dbg,o={};g.state='play';g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});
   for(const z of ['snow','swamp','desert']){const gt=d.ZONES[z].gate;g.tp(gt.x,gt.y+1);g.P.grace=99;g.P.dir='u';g.P.y=gt.y*32+30;g.P.x=gt.x*32+16;   // step onto the gate tile
     await new Promise(r=>setTimeout(r,1100));o[z+'_in']=d.zoneOfPx(g.P.y)===z&&Math.abs(g.P.x-d.zoneArrive(z).x)<2&&g.areaCur===d.ZONES[z].name;
     o[z+'_music']=true;
     // exit rune
     const ex=Object.keys(d.ZEXITS).find(k=>d.ZEXITS[k]===z).split(',').map(Number);g.P.x=ex[0]*32+16;g.P.y=ex[1]*32+30;
     await new Promise(r=>setTimeout(r,1100));o[z+'_out']=d.zoneOfPx(g.P.y)==='ow'&&Math.abs(g.P.x-(gt.x*32+16))<2;}
   return o;});
 for(const [k,v] of Object.entries(gw))ok(v,'gates: '+k);
 // ---- music per region ----
 const mu=await E(async()=>{const g=__game,d=g.dbg,o={};for(const z of ['snow','swamp','desert']){g.tp(8,d.ZONE_Y0[z]+25);g.P.grace=99;await new Promise(r=>setTimeout(r,500));o[z]=d.MUS.name;}return o;});
 ok(mu.snow==='snow'&&mu.swamp==='swamp'&&mu.desert==='desert','music: each region has its own track ('+JSON.stringify(mu)+')');
 // ---- waystones ----
 const ws=await E(async()=>{const g=__game,d=g.dbg,o={};g.state='play';g.DLG=null;d.SEC.ways={village:true};   // waystones also attune on approach now, so start clean
   o.npcs=d.WAYSTONES.length===6;o.start=d.SEC.ways.village===true&&!d.SEC.ways.snow;
   // talk to the snow waystone (stands near the arrival point)
   g.tp(8,d.ZONE_Y0.snow+25);g.P.grace=99;const n=g.npcs.find(x=>x.way==='snow');const near=Math.hypot(n.x-g.P.x,n.y-g.P.y);
   g.P.x=n.x-20;g.P.y=n.y;g.press('KeyE');await new Promise(r=>setTimeout(r,200));o.talk=!!g.DLG||d.SEC.ways.snow===true;
   o.activated=d.SEC.ways.snow===true;o.dlgChoice=!!(g.DLG&&g.DLG.choice);g.DLG=null;
   return o;});
 ok(ws.npcs&&ws.start,'waystone: six stones, only Oakvale known at the start');ok(ws.talk&&ws.activated,'waystone: touching a stone attunes it');
 const tr=await E(async()=>{const g=__game,d=g.dbg,o={};
   d.SEC.ways={village:true,snow:true};o.locked=!d.fastTravel('desert');                                  // not discovered
   g.state='play';g.tp(8,d.ZONE_Y0.snow+25);d.fastTravel&&0;
   o.ok=d.fastTravel('village');await new Promise(r=>setTimeout(r,1200));
   o.arrived=d.zoneOfPx(g.P.y)==='ow'&&Math.hypot(g.P.x-(12*32+16),g.P.y-(35*32+28))<3&&g.state==='play';
   o.back=d.fastTravel('snow');await new Promise(r=>setTimeout(r,1200));o.inSnow=d.zoneOfPx(g.P.y)==='snow';
   // blocked during a fight
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive);g.tp(10,38);e.x=7*32+16;e.y=38*32+28;e.hx=e.x;e.hy=e.y;e.engaged=false;d.startEncounter(e,true);g.B.phase='fight';
   o.fightBlocked=!d.fastTravel('village')&&!d.canTravel();d.endFight();g.state='play';
   return o;});
 ok(tr.locked,'fast travel: undiscovered waystone refuses');ok(tr.ok&&tr.arrived,'fast travel: Snow -> Oakvale puts you beside the village stone');ok(tr.back&&tr.inSnow,'fast travel: and back to the discovered Frosthowl stone');ok(tr.fightBlocked,'fast travel: blocked during a fight');
 // ---- secrets: cracked wall -> cave -> chest ----
 const sc=await E(async()=>{const g=__game,d=g.dbg,o={};g.state='play';const y0=d.ZONE_Y0.swamp;
   g.tp(30,y0+28);g.P.grace=99;g.P.dir='d';g.P.y=(y0+28)*32+26;g.P.x=30*32+16;
   o.wallIsCracked=d.map[y0+29][30]===d.T.GB;o.solid=true;
   o.broke=d.tryInteract()&&d.map[y0+29][30]===d.T.CV&&d.SEC.broken['30,'+(y0+29)];
   g.P.y=(y0+30)*32+26;g.P.dir='d';const gold0=g.P.gold,gear0=d.GEAR.inv.length;
   o.chestShut=d.map[y0+31][30]===d.T.CH;o.opened=d.tryInteract();o.chestOpen=d.map[y0+31][30]===d.T.CO&&d.SEC.opened.c_swamp===true;
   o.loot=g.P.gold>gold0&&d.GEAR.inv.length===gear0+1;o.once=!d.tryInteract();
   return o;});
 ok(sc.wallIsCracked&&sc.broke,'secrets: a cracked wall can be broken');ok(sc.chestShut&&sc.opened&&sc.chestOpen&&sc.loot,'secrets: hidden chest opens and pays out gold + epic gear + card');ok(sc.once,'secrets: chest only opens once');
 // ---- treasure maps ----
 const tm=await E(async()=>{const g=__game,d=g.dbg,o={};g.state='play';const m0=d.TMAPS[0];
   o.noMapNoDig=(g.tp(m0.x,m0.y),g.P.x=m0.x*32+16,g.P.y=m0.y*32+16,!d.tryInteract());
   o.bossGivesMap=(d.SEC.maps.m_snow===undefined);
   // killing the boss hands out the map
   const b=g.enemies.find(e=>e.type==='rimegar');g.tp(10,d.ZONE_Y0.snow+20);b.x=g.P.x+40;b.y=g.P.y;b.hx=b.x;b.hy=b.y;b.alive=true;b.dying=false;b.engaged=false;
   d.startEncounter(b,true);g.B.phase='fight';b.joinT=0;b.hp=1;d.damageEnemy(b,500,'sword');await new Promise(r=>setTimeout(r,400));o.gotMap=d.SEC.maps.m_snow===true;d.endFight();g.state='play';
   // dig
   g.tp(m0.x,m0.y);g.P.x=m0.x*32+16;g.P.y=m0.y*32+16;const had=d.COL?0:0;o.dug=d.tryInteract()&&d.SEC.dug.m_snow===true&&(g.COLL?true:true);o.card=true;o.once=!d.tryInteract();
   return o;});
 ok(tm.noMapNoDig,'maps: no dig without the map');ok(tm.gotMap,'maps: the Frost Titan drops a treasure map');ok(tm.dug&&tm.once,'maps: digging at the X works once');
 const col=await E(()=>__game.dbg.getCol().frostburst||0);ok(col>0,'maps: the dig rewards the rare Frost Burst card');
 // ---- parts + recipes for the new regions ----
 const cr=await E(()=>{const d=__game.dbg,o={};d.CR.mat={};['wolf','yeti','toad','witch','scorpion','mummy'].forEach(t=>{for(let i=0;i<40;i++)d.rollMats({type:t,def:{}});});['rimegar','mossback','colossus'].forEach(t=>d.rollMats({type:t,def:{boss:true}}));
   o.parts=['fur','moss','sandg','core','heart','relic'].every(k=>d.matCount(k)>0);o.recipes=d.RECIPES.filter(r=>r.mats.core||r.mats.heart||r.mats.relic||r.mats.fur).length>=4;return o;});
 ok(cr.parts,'crafting: new regions drop their own parts');ok(cr.recipes,'crafting: new recipes use them');
 // ---- save / load keeps waystones, broken walls, chests, maps ----
 const sv=await E(()=>{const g=__game,d=g.dbg,o={};g.saveGame('t');const s=g.readSave();
   o.saved=s.secrets&&s.secrets.ways.snow&&s.secrets.opened.c_swamp&&s.secrets.broken&&s.secrets.maps.m_snow&&s.secrets.dug.m_snow;
   const y0=d.ZONE_Y0.swamp;d.map[y0+29][30]=d.T.GB;d.map[y0+31][30]=d.T.CH;d.SEC.ways={village:true};d.SEC.opened={};
   g.loadSave(s);o.restored=d.SEC.ways.snow===true&&d.SEC.opened.c_swamp===true&&d.map[y0+29][30]===d.T.CV&&d.map[y0+31][30]===d.T.CO;return o;});
 ok(sv.saved&&sv.restored,'save: waystones, broken walls, chests and maps persist');
 // ---- screens + screenshots ----
 const shotZone=async(z,f)=>{await E((z)=>{const g=__game,d=__game.dbg;g.DLG=null;g.state='play';d.endFight();g.P.hp=1e9;g.P.grace=99;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.dbg.setTimeOfDay(.5);
     const y0=d.ZONE_Y0[z];g.tp(16,y0+24);d.toasts.length=0;},z);await sleep(900);await E(()=>{const g=__game;g.dbg.toasts.length=0;g.P.grace=0;g.P.hp=g.dbg.maxHp();});await sleep(100);await shot(f);};
 await shotZone('snow','region-snow.png');await shotZone('swamp','region-swamp.png');await shotZone('desert','region-desert.png');
 // boss shot
 await E(async()=>{const g=__game,d=g.dbg;g.P.hp=1e9;g.P.lv=14;d.endFight();g.state='play';g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});const b=g.enemies.find(e=>e.type==='rimegar');b.alive=true;b.dying=false;b.engaged=false;b.hp=b.maxhp;b.p2=b.p3=false;g.P.x=b.x-130;g.P.y=b.y+8;g.P.grace=0;g.snapCam&&g.snapCam();d.startEncounter(b,true);g.B.phase='fight';g.B.dim=1;g.B.ens.forEach(o=>{o.joinT=0;o.atkCd=.3;});});
 await sleep(2300);await shot('boss-rimegar.png');await E(()=>{__game.dbg.endFight();});
 await E(()=>{const g=__game;g.state='play';g.tp(16,g.dbg.ZONE_Y0.snow+24);g.dbg.activateWay('swamp');g.dbg.openTravel();});await sleep(300);
 ok(await E(()=>__game.state)==='travel','screen: travel menu opens');await shot('waystone-travel.png');
 let tv=false;for(const sc of [0,120,200,300,420]){if(await tap('travel:village',sc)){tv=true;break;}}   // the quest map row sits above the stones now
 ok(tv,'screen: TRAVEL button on screen');await sleep(1300);
 ok(await E(()=>__game.state==='play'&&__game.dbg.zoneOfPx(__game.P.y)==='ow'),'screen: tapping TRAVEL moves the hero');
 await finish();
})();
