// M14: aim preview while a ranged/area card is held.  node tests/ms14.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms14');
 const cardXY=i=>E(i=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,r=__game.cardRects[i];
   return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height,k:c.width/z.VW};},i);
 // hold = finger/mouse pressed on card slot i;  returns a release fn(move?)
 let th=null;
 const press=async i=>{const c=await cardXY(i);if(MOBILE)th=await pg.touchscreen.touchStart(c.x,c.y);else{await pg.mouse.move(c.x,c.y);await pg.mouse.down();}await sleep(120);return c;};
 const release=async()=>{if(MOBILE){await th.end();th=null;}else await pg.mouse.up();await sleep(80);};
 const drag=async(c,dy)=>{if(MOBILE)await th.move(c.x,c.y-dy*c.k);else await pg.mouse.move(c.x,c.y-dy*c.k,{steps:4});await sleep(100);};
 const HAND=['frostbolt','fire','lance','frostburst','meteor','poison','chain','quake','dragonfire','shadow','crimsonbolt','curse','drain','crimsonburst','heal','haste','ward','shield','sword','wolf','decoy','reflect','timestop'];
 const setup=async(o={})=>{await E(o=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   const kn=g.enemies.filter(x=>x.type==='knight'),sl=g.enemies.filter(x=>x.type==='slime');
   const near=kn[0],far=sl[0];near.dying=false;far.dying=false;near.x=5*32+16;near.y=38*32+28;far.x=(o.sx||4)*32+16;far.y=(o.sy||37.8)*32+28;[near,far].forEach(e=>{e.hx=e.x;e.hy=e.y;});
   g.P.x=10*32+16;g.P.y=38*32+28;g.P.grace=99;g.P.hp=d.maxHp();g.tp(10,38);g.P.x=10*32+16;g.P.y=38*32+28;g.P.aim=0;g.P.dir='r';
   if(o.nx)near.x=o.nx*32+16;d.startEncounter(near,true);const B=g.B;if(!B.ens.includes(far)){far.engaged=false;d.initCombatEnemy(far,0);B.ens.push(far);}B.phase='fight';B.dim=1;B.noiseT=1e9;B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;e.mt=1e9;});
   B.banner=null;B.t=5;d.toasts.length=0;B.hand=o.hand||['frostbolt','fire','lance','frostburst','meteor'];B.sel=0;window.__near=near;window.__far=far;},o);await sleep(200);};
 const held=()=>E(()=>__game.dbg.heldCardId());
 const plan=id=>E(id=>{const p=__game.dbg.aimPlan(id);if(!p)return null;const e=__game.B.ens;return {kind:p.kind,bad:p.blocked||false,noTarget:p.noTarget,r:p.r,hits:p.hits.map(h=>h===window.__near?'near':h===window.__far?'far':'x'),tgt:p.target===window.__near?'near':p.target===window.__far?'far':p.target?'x':null,
   end:{x:p.end.x,y:p.end.y},from:{x:p.from.x,y:p.from.y},len:p.len,pts:p.pts.length};},id);

 // ===== 1. kinds: ranged/area/projectile have a plan, support cards do not =====
 await setup({hand:HAND.slice(0,5)});
 const exp={frostbolt:'bolt',fire:'proj',lance:'line',frostburst:'area',meteor:'area',poison:'area',chain:'chain',quake:'self',dragonfire:'cone',shadow:'dash',crimsonbolt:'bolt',curse:'bolt',drain:'bolt',crimsonburst:'area'};
 for(const [id,k] of Object.entries(exp)){const p=await plan(id);ok(p&&p.kind===k,'plan kind '+id+' = '+k+' (got '+(p&&p.kind)+')');}
 for(const id of ['heal','haste','ward','shield','sword','wolf','decoy','reflect','timestop']){ok((await plan(id))===null,'no preview for '+id);}

 // ===== 2. target = auto-aim (nearest in LOS); area radii; hits =====
 await setup();
 let p=await plan('frostbolt');
 ok(p.tgt==='near'&&p.hits.join()==='near'&&!p.bad,'frostbolt targets the nearest enemy, highlights it');
 ok(await E(()=>{const n=window.__near,q=__game.dbg.aimPlan('frostbolt');return Math.hypot(q.end.x-n.x,q.end.y-(n.y-13))<4;}),'impact marker is on the target');
 ok(Math.hypot(p.end.x-p.from.x,p.end.y-p.from.y)>100,'line spans hero to target');
 p=await plan('frostburst');ok(p.kind==='area'&&p.r===70&&p.tgt==='near','frostburst footprint radius 70 around target');
 ok((await plan('crimsonburst')).r===70,'crimson burst footprint radius 70');
 ok((await plan('meteor')).r===62,'meteor footprint radius 62');ok((await plan('poison')).r===68,'poison cloud footprint radius 68');
 ok((await plan('quake')).r===118,'quake ring radius 118 around hero');
 ok((await plan('dragonfire')).len===280,'dragonfire cone length 280');
 ok((await plan('lance')).hits.includes('near'),'lance band highlights the enemy in line');
 ok((await plan('fire')).hits.join()==='near','fireball preview stops at the first enemy');
 await E(()=>{const f=window.__far,n=window.__near;n.x=8*32+16;f.x=n.x-40;f.y=n.y-10;});await sleep(120);
 p=await plan('frostburst');ok(p.hits.includes('near')&&p.hits.includes('far'),'burst highlights every enemy inside the footprint');
 p=await plan('frostbolt');ok(p.hits.join()==='near','single-target bolt highlights only its target');
 p=await plan('chain');ok(p.hits.length===2&&p.pts===3,'chain path jumps to the second enemy ('+p.hits+')');

 // ===== 3. live: the preview follows moving hero / enemy =====
 await setup();
 const a1=await plan('frostbolt');await E(()=>{window.__near.x+=24;window.__near.y-=20;});await sleep(80);const a2=await plan('frostbolt');
 ok(Math.hypot(a2.end.x-a1.end.x,a2.end.y-a1.end.y)>20,'impact marker follows a moving enemy');
 await E(()=>{__game.P.y-=24;});await sleep(80);const a3=await plan('frostbolt');ok(Math.abs(a3.from.y-a2.from.y+24)<2,'origin follows the hero');
 // nearest-enemy switch: far enemy walks closer than the near one
 await setup();ok((await plan('frostbolt')).tgt==='near','initially targets the nearest');await E(()=>{window.__far.x=9*32+16;window.__far.y=38*32+28;});await sleep(80);ok((await plan('frostbolt')).tgt==='far','target switches to the new nearest enemy');
 // no enemies: facing direction, stops at walls
 await setup();await E(()=>{window.__near.dying=true;window.__far.dying=true;__game.P.aim=Math.PI;});await sleep(80);
 p=await plan('frostbolt');ok(p.noTarget&&p.hits.length===0&&p.end.x<p.from.x,'no enemy: line follows the facing direction (noTarget flagged)');
 p=await plan('fire');ok(p.end.x<p.from.x-20&&p.hits.length===0,'fireball with no enemy flies along facing');
 // wall: find a free tile with a solid tile a few tiles to its right, hero there facing it
 await setup();
 const w=await E(()=>{const d=__game.dbg;for(let ty=30;ty<45;ty++)for(let tx=2;tx<70;tx++){const x=tx*32+16,y=ty*32+28;
   if(!d.wallT(x,y-12)&&!d.wallT(x+32,y-12)&&!d.wallT(x+64,y-12)&&d.wallT(x+96,y-12)&&!d.wallT(x-32,y-12)){const g=__game;window.__near.dying=true;window.__far.dying=true;g.P.x=x;g.P.y=y;g.P.aim=0;g.P.dir='r';return {x,y,wx:Math.floor((x+96)/32)*32};}}return null;});
 ok(!!w,'found a wall spot for the wall test');
 if(w){await sleep(100);
  for(const id of ['fire','lance','frostbolt']){p=await plan(id);ok(p.end.x<=w.wx&&p.end.x>w.x+10,id+' preview stops at the wall ('+Math.round(p.end.x)+' <= '+w.wx+')');}
  p=await plan('dragonfire');ok(p.end.x<=w.wx,'dragonfire cone is cut at the wall');
  // enemy behind the wall: line of sight lost -> red/blocked marker at the wall, no highlight
  await E((w)=>{const n=window.__near;n.dying=false;n.x=w.x+7*32;n.y=w.y;},w);await sleep(100);
  p=await plan('frostbolt');ok(p.bad&&p.hits.length===0&&p.end.x<=w.wx,'target behind a wall: blocked marker at the wall, nothing highlighted');
  p=await plan('frostburst');ok(p.bad,'area card with blocked target is flagged');
  p=await plan('fire');ok(p.end.x<=w.wx,'fireball toward a foe behind a wall stops at the wall');}

 // ===== 4. real hold on a card: appears while held, gone on release / swipe =====
 await setup({hand:['frostbolt','heal','frostburst','sword','meteor']});
 ok((await held())===null,'nothing held at rest');
 const n0=await E(()=>__game.dbg.AIMV.drawn);await sleep(150);ok((await E(()=>__game.dbg.AIMV.drawn))===n0,'nothing drawn at rest');
 let c=await press(0);
 ok((await held())==='frostbolt','hold on frostbolt card is detected');
 const n1=await E(()=>__game.dbg.AIMV.drawn);await sleep(200);const n2=await E(()=>__game.dbg.AIMV.drawn);
 ok(n2===n1,'NO dashed preview is drawn while a ranged card is pressed and held (no glimpse on touch-down)');
 const imgHeld=await pg.screenshot({encoding:'base64'});
 await shot('aim-preview.png');
 ok(await E(()=>__game.B.hand[0]==='frostbolt'),'holding does not cast');
 // live move while held
 const e1=await E(()=>__game.dbg.AIMV.last);await E(()=>{window.__near.y-=30;});await sleep(150);
 await release();await E(()=>__game.dbg.expCancel());   // (a released ranged card now stays selected for tap-to-cast; cancel it)
 ok((await held())===null,'preview removed on release');
 const n3=await E(()=>__game.dbg.AIMV.drawn);await sleep(200);ok((await E(()=>__game.dbg.AIMV.drawn))===n3,'nothing drawn after release');
 // support card held: nothing drawn
 await setup({hand:['frostbolt','heal','frostburst','sword','meteor']});
 c=await press(1);ok((await held())==='heal','hold on heal detected');const m1=await E(()=>__game.dbg.AIMV.drawn);await sleep(200);
 ok((await E(()=>__game.dbg.AIMV.drawn))===m1,'heal shows no preview');await release();
 c=await press(3);const m2=await E(()=>__game.dbg.AIMV.drawn);await sleep(200);ok((await E(()=>__game.dbg.AIMV.drawn))===m2,'melee sword shows no preview');await release();
 // area hold + screenshot
 await setup({hand:['frostbolt','heal','frostburst','sword','meteor'],sx:7,sy:38.4,nx:8.3});
 c=await press(2);ok((await held())==='frostburst','hold on frostburst detected');await sleep(250);
 {const a0=await E(()=>__game.dbg.AIMV.drawn);await sleep(200);ok((await E(()=>__game.dbg.AIMV.drawn))===a0,'area card held: no footprint drawn');}
 await shot('aim-preview-area.png');
 // swipe up -> casts and the preview ends
 await drag(c,70);await sleep(100);ok((await held())===null,'preview removed once the swipe casts');
 ok(await E(()=>__game.B.hand[2]===null),'swipe still casts the held card');
 await release();await sleep(300);
 // drag back down (cancel) : press, move down, release outside -> no stuck preview
 await setup({hand:['frostbolt','heal','frostburst','sword','meteor']});
 c=await press(4);ok((await held())==='meteor','hold on meteor detected');await sleep(120);
 {const a0=await E(()=>__game.dbg.AIMV.drawn);await sleep(200);ok((await E(()=>__game.dbg.AIMV.drawn))===a0,'meteor held: no footprint drawn');}
 await release();await E(()=>__game.dbg.expCancel());ok((await held())===null,'meteor preview gone on release');
 // outside of a fight / when state not play nothing is held
 await E(()=>{__game.dbg.endFight();});ok((await held())===null,'no preview outside a fight');
 await finish();
})().catch(e=>{console.error(e);process.exit(1);});
