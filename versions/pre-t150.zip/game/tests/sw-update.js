// Service worker update flow: new sw.js -> activates, old cache deleted, open page reloads itself into the new build.  node tests/sw-update.js
require('child_process').execSync('rm -rf /tmp/swt && cp -r '+__dirname+'/../dist/web /tmp/swt');
const puppeteer=require('puppeteer-core');const http=require('http'),fs=require('fs'),path=require('path');
const srv=http.createServer((q,r)=>{let f=path.join('/tmp/swt',q.url.split('?')[0]);if(f.endsWith('/'))f+='index.html';try{const b=fs.readFileSync(f);r.setHeader('Content-Type',f.endsWith('.js')?'text/javascript':f.endsWith('.html')?'text/html':f.endsWith('.png')?'image/png':'application/json');r.setHeader('Cache-Control','max-age=600');r.end(b);}catch(e){r.statusCode=404;r.end();}}).listen(8765);
(async()=>{const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});const p=await b.newPage();let navs=0;p.on('framenavigated',f=>{if(f===p.mainFrame())navs++;});
await p.goto('http://localhost:8765/',{waitUntil:'load'});await new Promise(r=>setTimeout(r,2500));
const k1=await p.evaluate(async()=>({ctl:!!navigator.serviceWorker.controller,keys:await caches.keys()}));console.log('first',JSON.stringify(k1));
await p.reload({waitUntil:'load'});await new Promise(r=>setTimeout(r,1500));const n0=navs;
let sw=fs.readFileSync('/tmp/swt/sw.js','utf8').replace(/arcane-knight-v\d+/,'arcane-knight-v99');fs.writeFileSync('/tmp/swt/sw.js',sw);
let ix=fs.readFileSync('/tmp/swt/index.html','utf8');fs.writeFileSync('/tmp/swt/index.html',ix.replace('<head>','<head><!--NEWBUILD-->'));
await p.evaluate(()=>navigator.serviceWorker.getRegistration().then(r=>r.update()));
await new Promise(r=>setTimeout(r,4000));
const k2=await p.evaluate(async()=>({keys:await caches.keys(),html:document.documentElement.outerHTML.includes('NEWBUILD')}));
console.log(navs-n0>=1&&k2.html&&k2.keys.join()==='arcane-knight-v99'?'sw-update: PASS (auto-reload into new build, old cache dropped)':'sw-update: FAIL',JSON.stringify(k2));await b.close();srv.close();})();
