// M21: Sun Paladin hero redesign.  node tests/ms21.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms21');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.hp=d.maxHp();g.P.grace=9999;});
 await sleep(300);
 // ---- sprite colour census: ivory + gold, no old blue armour / red plume
 const a=await E(()=>{const sp=__game.dbg.SP,out={};const census=c=>{const q=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let cream=0,gold=0,blue=0,red=0,solid=0;
     for(let i=0;i<q.length;i+=4){if(q[i+3]<200)continue;solid++;const r=q[i],g=q[i+1],b=q[i+2];if(r>200&&g>180&&b>140&&b<245)cream++;else if(r>190&&g>130&&b<110)gold++;if(b>180&&r<120)blue++;if(r>200&&g<90&&b<90)red++;}return {cream,gold,blue,red,solid};};
   out.d=census(sp.hero.d[0]);out.u=census(sp.hero.u[0]);out.r=census(sp.hero.r[0]);out.b=census(sp.heroB[0]);
   const frames=[...sp.hero.d,...sp.hero.u,...sp.hero.r,...sp.hero.l];out.n=frames.length;out.sz=frames.every(c=>c.width===16&&c.height===16);
   out.uniq=new Set(frames.map(c=>c.toDataURL())).size;out.icon=!!sp.heroIcon&&sp.heroIcon.width===8;out.port=!!sp.port.hero&&sp.port.hero.width===24;
   out.mirror=(()=>{const A=sp.hero.r[1],B2=sp.hero.l[1];const ca=document.createElement('canvas');ca.width=16;ca.height=16;const q=ca.getContext('2d');q.translate(16,0);q.scale(-1,1);q.drawImage(A,0,0);return ca.toDataURL()===B2.toDataURL();})();
   return out;});
 ok(a.n===12&&a.sz,'12 hero frames (3 per direction x4), all 16x16 as before');
 ok(a.uniq>=9,'frames are distinct ('+a.uniq+')');
 for(const k of ['d','u','r','b'])ok(a[k].cream>=18&&a[k].gold>=14,'facing '+k+': ivory ('+a[k].cream+') + gold ('+a[k].gold+') plate');
 for(const k of ['d','u','r','b'])ok(a[k].blue<=3&&a[k].red===0,'facing '+k+': no leftover blue armour / red plume ('+a[k].blue+','+a[k].red+')');
 ok(a.mirror,'left-facing frames mirror the right ones');ok(a.icon&&a.port,'HUD head icon + cutscene portrait exist');
 // ---- in the game: walking animation frames come from the new sprites, and the HUD draws the icon
 await E(()=>{const g=__game;g.tp(11,40);});await sleep(400);
 const w=await E(()=>{const g=__game;return {has:!!g.dbg.SP.hero[g.P.dir]};});ok(w.has,'player draws with the new hero sprite');
 await E(()=>{const g=__game;g.P.dir='d';g.dbg.toasts.length=0;});await sleep(800);
 // ---- screenshots: the whole screen + a 3x close-up around the hero
 await E(()=>{const g=__game;g.tp(11,41);g.dbg.toasts.length=0;g.dbg.setTimeOfDay(.42);});await sleep(4200);await E(()=>{__game.dbg.toasts.length=0;});
 await shot('hero-paladin-full.png');
 const pos=await E(()=>{const g=__game,c=document.getElementById('c').getBoundingClientRect(),z=g.size;return {x:c.left+(g.P.x-g.cam.x)/z.VW*c.width,y:c.top+(g.P.y-g.cam.y-16)/z.VH*c.height,k:c.width/z.VW};});
 const half=Math.round(46*pos.k);
 await pg.screenshot({path:require('path').join(__dirname,'..','store','hero-paladin.png'),clip:{x:Math.max(0,pos.x-half),y:Math.max(0,pos.y-half),width:half*2,height:half*2,scale:4}});
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
