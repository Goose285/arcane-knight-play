// M56: decluttered opening - story panel -> village name -> ONE objective (Talk to Elder Orin); dailies / tips / tutorial wait until the
// first quest is handed in, then arrive one at a time; one toast at a time inside the free HUD band (no overlap on iPhone landscape);
// old saves skip the intro.  node tests/ms56.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms56',{town:true,grow:true,intro:true,stayTitle:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{const t=__game.titleMenu;t.sel=t.items.indexOf('New Game');__game.dbg.startFromTitle();});await sleep(600);
 let s=await E(()=>{const g=__game,d=g.dbg;return {ph:d.INTRO.ph,dlg:g.DLG&&g.DLG.name,tut:d.TUT.on,toasts:d.toasts.length,area:g.areaCur};});
 ok(s.ph==='story'&&s.dlg==='OAKVALE','new game opens with the story panel first '+JSON.stringify(s));
 ok(!s.tut,'the tutorial panel does not compete with it');
 ok(s.toasts===0,'no toast (combat tip / daily) at the start');
 const tr0=await E(()=>__game.dbg.TRK.rect);ok(!tr0,'tracker hidden while the story panel is up');
 await E(()=>{__game.DLG=null;});await sleep(500);
 s=await E(()=>({ph:__game.dbg.INTRO.ph}));ok(s.ph==='banner','closing the story shows the village name next');
 await sleep(2600);
 s=await E(()=>{const d=__game.dbg,l=d.trkEntries(),c=d.trkCurrent(l);return {ph:d.INTRO.ph,cur:c&&c.obj,kinds:l.map(e=>e.kind),tg:!!d.trkTarget(c),rect:d.TRK.rect,
   marks:__game.npcs.filter(n=>d.npcMarker(n)).map(n=>n.name)};});
 ok(s.ph==='obj','then ONE objective');
 ok(s.cur==='Talk to Elder Orin by the fountain','tracker: "Talk to Elder Orin by the fountain"');
 ok(s.kinds.join()==='intro','no story chapter / daily entries compete ('+s.kinds+')');
 ok(s.tg,'the tracker arrow points at Orin');
 ok(s.marks.join()==='Elder Orin','only Orin wears a quest marker ('+s.marks+')');
 const fd=await E(()=>{const d=__game.dbg,o=__game.npcs.find(n=>n.name==='Elder Orin'),w=d.world();let best=1e9;for(let y=0;y<w.MH;y++)for(let x=0;x<d.MWv;x++)if(d.map[y][x]===d.T.PW||d.map[y][x]===d.T.PR||d.map[y][x]===d.T.U)best=Math.min(best,Math.hypot((x+.5)*32-o.x,(y+.5)*32-o.y));return best/32;});
 ok(fd<4.5,'Orin stands by the fountain ('+fd.toFixed(1)+' tiles)');
 // daily notices stay quiet
 await E(()=>{__game.dbg.toasts.length=0;});await sleep(5000);
 s=await E(()=>__game.dbg.toasts.map(t=>t.s));ok(!s.some(x=>/daily/i.test(x)),'daily announcements suppressed during the first quest '+JSON.stringify(s));
 // talk to Orin -> quest
 s=await E(()=>{const g=__game,d=g.dbg,o=g.npcs.find(n=>n.name==='Elder Orin');d.questTalk?0:0;g.P.x=o.x;g.P.y=o.y+30;d.questTalk(o);const L=g.DLG&&g.DLG.lines;if(g.DLG&&g.DLG.choice)g.DLG.choice();g.DLG=null;return {L:L&&L.length,st:d.questStatus('slimes'),cur:d.trkCurrent().name};});
 ok(s.st==='active'&&s.cur==='Slime Trouble','talking to Orin starts Slime Trouble and the tracker follows it '+JSON.stringify(s));
 ok(s.L<=4,'Orin gets to the point (short offer, '+s.L+' lines)');
 // toast queue: one at a time, inside the free band
 s=await E(async()=>{const d=__game.dbg;d.toasts.length=0;d.toast('first message that is fairly long so that it would have run into the tracker panel before',1);d.toast('second');d.toast('second');
   await new Promise(r=>setTimeout(r,300));const n=d.toasts.length,R=d.getToastR(),T=d.TRK.rect,mm=__game.size.VW-8-132;return {n,R,T,mm,VW:__game.size.VW};});
 ok(s.n===2,'duplicate toasts collapse; queue holds 2');
 const ov=(a,b)=>a&&b&&a.x<b.x+b.w&&b.x<a.x+a.w&&a.y<b.y+b.h&&b.y<a.y+a.h;
 ok(s.R&&!ov(s.R,s.T),'the toast never overlaps the tracker '+JSON.stringify([s.R,s.T]));
 ok(s.R&&(s.R.x+s.R.w<=s.mm||s.R.y>100),'the toast never overlaps the minimap');
 const one=await E(()=>{let c=0;const o=__game.dbg;return o.getToastR()?1:0;});ok(one===1,'only one toast is drawn at a time');
 // finish the quest -> the rest is introduced one by one
 s=await E(async()=>{const g=__game,d=g.dbg;d.toasts.length=0;for(let i=0;i<3;i++)d.questEvent('kill','slime');d.questEvent&&0;
   const st=d.questStatus('slimes');const o=g.npcs.find(n=>n.name==='Elder Orin');g.P.x=o.x;g.P.y=o.y+30;d.questTalk(o);const L=g.DLG&&g.DLG.lines.join(' ');g.DLG=null;
   await new Promise(r=>setTimeout(r,400));return {st,done:d.questStatus('slimes'),L,q:d.toasts.map(t=>t.s),intro:d.introActive(),gold:g.P.gold};});
 ok(s.st==='ready'&&s.done==='done','three slimes -> hand in to Orin');
 ok(/shortsword/.test(s.L)&&/signet/.test(s.L)&&/south/.test(s.L),'reward + a reason to explore (signet thicket, the south road)');
 ok(s.gold>=80,'coins paid ('+s.gold+')');
 ok(!s.intro&&s.q.some(x=>/Daily challenges unlocked/.test(x))&&s.q.some(x=>/TIP/.test(x)),'after the first quest: tip + dailies arrive, queued '+JSON.stringify(s.q));
 // an existing save never gets the intro
 s=await E(()=>{const g=__game,d=g.dbg;d.saveNow();const sv=g.readSave();g.loadSave(sv);return {ph:d.INTRO.ph,a:d.introActive()};});
 ok(!s.a,'loading a save does not restart the intro');
 ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
