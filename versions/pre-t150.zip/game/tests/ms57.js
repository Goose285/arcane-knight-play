// M57 (t133u): eastern regions + new foes, auto-connecting walls, chests, teleport card, dash, NPC day/night routines, editor palette + COPY,
// church, organic borders.  node tests/ms57.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms57',{town:true,grow:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>__game.dbg.startFromTitle());await sleep(700);
 // regions
 let s=await E(()=>{const k=__game.t133();const cnt={grove:0,caves:0,rift:0};for(let y=k.OY;y<k.OY+k.OW_H;y++)for(let x=0;x<k.MW;x++){const r=k.eastRegion(x,y);if(r)cnt[r]++;}
   const types=new Set(k.enemies.map(e=>e.type));return {on:k.EAST.on,MW:k.MW,cnt,types:[...types],an:k.areaName(k.OX+90,k.OY+20)};});
 ok(s.on&&s.MW>=112,'the world grew east ('+s.MW+' cols)');
 ok(s.cnt.grove>500&&s.cnt.caves>500&&s.cnt.rift>100,'Glowcap Grove, Shardstone Caverns and Ember Rift exist '+JSON.stringify(s.cnt));
 ok(s.an==='GLOWCAP GROVE','area name in the grove');
 const want=['redcap','ironcap','spitter','frostcap','shadowcap','lantern','chestcap','shscorp','sentinel','maw','tortoise','fbat','bboar','geode','crawler','scamp','mgolem','cgolem','colony','mking','warden'];
 ok(want.every(t=>s.types.includes(t)),'all new monsters + bosses placed (missing: '+want.filter(t=>!s.types.includes(t))+')');
 // organic edges: the grove/caves border is not a straight row
 s=await E(()=>{const k=__game.t133();const ys=[];for(let x=70;x<108;x+=3){for(let y=20;y<80;y++){if(k.eastRegion(k.OX+x,k.OY+y)==='caves'){ys.push(y);break;}}}return ys;});
 ok(new Set(s).size>=3,'region border is irregular ('+s.join(',')+')');
 // walls auto-connect
 s=await E(()=>{const k=__game.t133(),y=k.OY+90,x=k.OX+70;for(let i=0;i<3;i++)k.edSetTile(x+i,y,k.T.WLM);const mid=k.XTILE_FN[k.T.WLM](x+1,y),end=k.XTILE_FN[k.T.WLM](x,y);
   k.edSetTile(x+5,y,k.T.WLM);const lone=k.XTILE_FN[k.T.WLM](x+5,y);k.edSetTile(x+5,y+1,k.T.WLM);const vert=k.XTILE_FN[k.T.WLM](x+5,y);
   const r={m:[mid!==end,mid!==lone,vert!==lone],diff:mid!==end&&mid!==lone&&vert!==lone,solid:k.solidTile(x,y),shotBlock:k.XWALLS.has(k.T.WLM)};for(const xx of [0,1,2,5])k.edSetTile(x+xx,y,k.T.G);k.edSetTile(x+5,y+1,k.T.G);return r;});
 ok(s.diff,'straight walls auto-connect (end / middle / lone / vertical pieces differ)');ok(s.solid&&s.shotBlock,'walls block walking and shots');
 // chests
 s=await E(()=>{const k=__game.t133(),g0=k.P.gold;let c=null;for(let y=k.OY;y<k.OY+k.OW_H&&!c;y++)for(let x=0;x<k.MW;x++)if(k.map[y][x]===k.T.CHST){c=[x,y];break;}
   const t=k.chestTier(...c),o=k.openChestAt(...c),again=k.openChestAt(...c),pk=k.packSecrets();return {c,t,o,again,gold:k.P.gold-g0,opened:k.chestOpened(...c),saved:Object.keys(pk.chest2||{}).length};});
 ok(s.c&&s.o&&!s.again&&s.opened,'a scattered chest opens once and stays open');ok(s.gold>0,'chest gives loot (+'+s.gold+' G)');ok(s.saved>=1,'opened chests are saved');
 // teleport card
 s=await E(()=>{const k=__game.t133();return {c:!!k.CARD.teleport,cast:typeof k.CAST.teleport,g:k.EXP_GROUND.has('teleport')};});
 ok(s.c&&s.cast==='function'&&s.g,'TELEPORT card exists and aims at a ground spot');
 s=await E(()=>{const g=__game,d=g.dbg,k=g.t133();d.endFight();g.state='play';const e=g.enemies.find(x=>x.type==='slime'&&x.alive)||g.enemies.find(x=>x.alive&&!x.def.boss);
   g.P.x=e.x-120;g.P.y=e.y;e.engaged=false;d.startEncounter(e,true);const B=k.B;B.phase='fight';const x0=g.P.x,y0=g.P.y;B.xt={x:x0+150,y:y0-12};B.inv=0;k.CAST.teleport();
   const r={moved:Math.hypot(g.P.x-x0,g.P.y-y0),inv:B.inv,free:!k.solidTile(Math.floor(g.P.x/32),Math.floor((g.P.y-6)/32))};B.xt=null;return r;});
 ok(s.moved>40&&s.free,'teleport blinks to the chosen spot ('+Math.round(s.moved)+'px)');ok(s.inv>0,'teleport gives i-frames');
 // dash
 s=await E(()=>{const g=__game,k=g.t133();k.DASH.cd=0;const x0=g.P.x;const a=k.tryDash(1,0);for(let i=0;i<20;i++)k.dashTick(1/60);const b=k.tryDash(1,0);const cd=k.DASH.cd;g.dbg.endFight();g.state='play';return {a,b,cd,dx:g.P.x-x0};});
 ok(s.a&&s.dx>30,'dash bursts forward ('+Math.round(s.dx)+'px)');ok(!s.b&&s.cd>2&&s.cd<=2.5,'2.5s cooldown blocks a second dash (cd '+s.cd.toFixed(2)+')');
 // routines
 s=await E(()=>{const g=__game,k=g.t133();k.DAY.t=.5;k.updateRoutines(.016);const brum=k.NPCS.find(n=>n.name==='Blacksmith Brum');const day={st:brum.rt&&brum.rt.st,closed:k.rtShopClosed(brum)};
   k.DAY.t=.9;k.updateRoutines(.016);const night={st:brum.rt.st,closed:k.rtShopClosed(brum),x:brum.x};k.openDlg(brum);const dlg=k.DLG&&k.DLG.lines[0];k.DLG=null;
   k.DAY.t=.5;k.updateRoutines(.016);for(const t of [.53,.56,.59,.62,.65,.68,.71,.74,.77,.775,.782])k.DAY.t=t,k.updateRoutines(.016);for(let i=0;i<5;i++)k.updateRoutines(.1);const walking=brum.rt.st;
   return {day,night,dlg,walking,n:k.ROUT.list.length};});
 ok(s.n>=4,'shopkeepers / villagers have routines ('+s.n+')');
 ok(s.day.st==='work'&&!s.day.closed,'by day the smith is at work and trades');
 ok(s.night.st==='home'&&s.night.closed&&s.night.x<0,'at night he is home and the shop is closed');
 ok(/closed/i.test(s.dlg||''),'talking to a closed shop says so');
 ok(s.walking==='toHome','at dusk he walks home');
 // editor palette + copy
 s=await E(()=>{const k=__game.t133();const names=k.ED_ITEMS.map(i=>i.name);return {cats:k.ED_CATS,walls:k.ED_ITEMS.filter(i=>i.cat==='Walls'||i.cat==='Plants').length,all:k.ED_ITEMS.length,chest:!!k.ED_ITEM_BY['p:'+k.T.CHST],en:!!k.ED_ITEM_BY['e:cgolem']};});
 ok(s.cats.includes('Walls')&&s.cats.includes('All'),'editor has Walls and All tabs');ok(s.walls>=15,'all wall pieces + planters ('+s.walls+')');ok(s.all>=30,'All tab lists every tile / NPC look ('+s.all+')');ok(s.chest&&s.en,'chest + new monsters are placeable');
 await E(()=>__game.dbg.edOpen());await sleep(300);
 s=await E(()=>{const k=__game.t133(),x=k.OX+30,y=k.OY+96;k.edSetTile(x,y,k.T.PL1);k.edSetTile(x+1,y,k.T.WLM);k.edCopyGrab(x,y,x+1,y);const n=k.edCopyStamp(x,y+3);
   return {n,a:k.map[y+3][x]===k.T.PL1,b:k.map[y+3][x+1]===k.T.WLM};});
 ok(s.n>=2&&s.a&&s.b,'COPY: a selected area stamps copies');
 await E(()=>__game.dbg.edExit());await sleep(300);
 ok(!errs.length,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
