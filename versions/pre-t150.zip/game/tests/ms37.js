// M37: the Lab card system is now the main game: hand of 4, one card / 2.5s, compact deal timer, 4-card fan for thumbs + lefty.  node tests/ms37.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms37',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.lv=Math.max(g.P.lv,12);});
 const fight=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.calm=0;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;});
   g.tp(11,20);g.P.x=11*32+16;g.P.y=20*32+28;g.P.hp=d.maxHp();g.P.grace=0;
   const e=g.enemies.find(q=>q.type==='slime'&&!q.def.boss);e.x=e.hx=(11+3.2)*32;e.y=e.hy=20*32+28;e.hp=e.maxhp=e.mhp=1e7;window.__e=e;
   d.startEncounter(e,true);const B=g.B;B.inv=99;e.atkCd=1e9;e.joinT=0;return !!B;});
 const waitClk=async sec=>{const t0=await E(()=>__game.B.clk);for(let i=0;i<400;i++){await sleep(50);if(await E((t,sc)=>__game.B.clk-t>=sc,t0,sec))return;}};
 const hand=()=>E(()=>__game.B.hand.slice());
 ok(await fight(),'a fight starts');
 await sleep(1300);   // through the alert phase
 ok(await E(()=>__game.B.phase==='fight'||__game.B.phase==='alert'),'in combat');
 await E(()=>{window.__game.B.inv=99;});
 // ---- 1. opening hand and slots
 let h=await hand();
 ok(h.length===4,'the hand has exactly 4 slots ('+h.length+')');
 ok(h.filter(Boolean).length===2,'opening hand = 2 cards ('+h.filter(Boolean).length+')');
 ok(await E(()=>!__game.dbg.EXPCARD||__game.dbg.EXPCARD.enabled),'the new card system is on by default');
 // ---- 2. one card per 2.5s, max 4, timer waits, no refresh
 await E(()=>{const B=__game.B;B.hand=[null,null,null,null];B.xdeal=0;B.xsel=-1;B.gauge=0;});
 await waitClk(1.6);h=await hand();ok(h.filter(Boolean).length===0,'nothing is dealt before 2.5s');
 await waitClk(1.3);h=await hand();ok(h.filter(Boolean).length===1,'one card at ~2.5s ('+h.filter(Boolean).length+')');
 await waitClk(2.6);h=await hand();ok(h.filter(Boolean).length===2,'then one more 2.5s later ('+h.filter(Boolean).length+')');
 await waitClk(5.4);h=await hand();ok(h.filter(Boolean).length===4,'the hand tops out at 4 ('+h.filter(Boolean).length+')');
 const keep=h.slice();await waitClk(9.5);
 ok(JSON.stringify(await hand())===JSON.stringify(keep),'no full-hand refresh after the old 8.5s gauge time (hand unchanged)');
 ok(await E(()=>__game.B.xdeal<=2.5&&__game.B.gauge===1),'the deal timer waits while the hand is full');
 await E(()=>{__game.B.hand[1]=null;});await waitClk(2.9);h=await hand();ok(!!h[1]&&h.filter(Boolean).length===4,'casting/freeing a slot: one new card refills it');
 // deal speed bonuses
 const sp=await E(()=>{const g=__game,d=g.dbg,B=g.B;B.hand=[null,null,null,null];B.xdeal=0;const o={};o.base=1+d.gearStats().gauge+.1*d.skillRank('slots');return o;});
 ok(sp.base>=1,'gear/skill deal-speed bonus applies ('+sp.base+')');
 // ---- 3. HUD: a small timer instead of the big spell gauge
 const hb=await E(()=>__game.dbg.COMBAT_HUD_BOT());
 ok(hb>0&&hb<=100,'combat HUD cluster stays compact ('+hb+')');
 // ---- 4. the fan (touch): 4 cards, clear of SHOT/CAST, on-screen, mirrored for left-handed
 const geo=()=>E(()=>{const g=__game,d=g.dbg,z=g.size,R=g.cardRects.slice(),a=g.btn.atk,c=g.btn.atk;
   const hit=(r,b)=>{const rr=Math.max(r.w,r.h)/2*.72;return Math.hypot((r.cx!=null?r.cx:r.x+r.w/2)-b.x,(r.cy!=null?r.cy:r.y+r.h/2)-b.y)<b.r+rr*.6;};
   return {n:R.length,onscreen:R.every(r=>{const cx=r.cx!=null?r.cx:r.x+r.w/2,cy=r.cy!=null?r.cy:r.y+r.h/2;return cx>r.w/2&&cx<z.VW-r.w/2&&cy>r.h/2&&cy<z.VH-r.h/2;}),
     clear:R.every(r=>!hit(r,a)&&!hit(r,c)),side:R.map(r=>(r.cx!=null?r.cx:r.x+r.w/2)).reduce((s,x)=>s+x,0)/R.length,atkx:a.x,mid:z.VW/2,w:R[0]&&R[0].w,h:R[0]&&R[0].h};});
 await E(()=>{const B=__game.B;B.hand=['fire','heal','lance','chain'];B.sel=0;B.xsel=-1;B.gauge=.4;B.xdeal=1;});await sleep(300);
 const g1=await geo();
 ok(g1.n===4,'4 card slots are laid out ('+g1.n+')');
 if(MOBILE){
   ok(g1.onscreen&&g1.clear,'right-handed fan: every card on screen and clear of SHOT and CAST ('+JSON.stringify(g1)+')');
   ok(g1.side<g1.atkx+8,'right-handed fan arcs to the left of the thumb buttons');
   await E(()=>{const B=__game.B;(B.texts||[]).length=0;});await sleep(200);await shot('four-card-hand.png');
   await E(()=>{__game.dbg.setToggle('lefty');});await sleep(300);
   const g2=await geo();
   ok(g2.n===4&&g2.onscreen&&g2.clear,'left-handed fan: on screen and clear of the thumb buttons ('+JSON.stringify(g2)+')');
   ok(g2.side>g2.atkx-8&&g2.atkx<g2.mid,'left-handed fan mirrors to the right of SHOT/CAST (buttons on the left)');
   await shot('four-card-hand-lefty.png');
   await E(()=>{__game.dbg.setToggle('lefty');});await sleep(200);
 }else{
   ok(g1.onscreen,'desktop: all 4 cards on screen ('+JSON.stringify(g1)+')');
   await shot('four-card-hand-desktop.png');
 }
 // ---- 5. tap a ranged card still selects, a heal casts on one tap, the freed slot refills
 await E(()=>{const B=__game.B;B.hand=['fire','heal',null,null];B.sel=0;B.gauge=0;B.xdeal=0;B.xsel=-1;B.inv=99;});await sleep(250);
 const clickAt=async(x,y)=>{const p=await E((x,y)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+x/z.VW*c.width,y:c.top+y/z.VH*c.height};},x,y);if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);};
 const cardPt=i=>E(i=>{const r=__game.cardRects[i];return r?{x:r.cx!=null?r.cx:r.x+r.w/2,y:r.cy!=null?r.cy:r.y+r.h/2}:null;},i);
 let cp=await cardPt(1);await clickAt(cp.x,cp.y);await sleep(100);
 ok(await E(()=>__game.B.hand[1]===null),'HEAL casts on one tap in the main game');
 cp=await cardPt(0);await clickAt(cp.x,cp.y);await sleep(100);
 ok(await E(()=>__game.B.xsel===0&&__game.B.hand[0]==='fire'),'FIREBALL only selects (then tap the world)');
 await E(()=>{__game.dbg.expCancel();});
 await waitClk(3);
 ok((await hand()).filter(Boolean).length>=2,'freed slots refill with single new cards');
 await E(()=>{__game.dbg.endFight();});
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
