// M38: save safety net - New Game / a fresh hero keep the old save as a backup, the title offers Restore Backup, Lab never writes saves.  node tests/ms38.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,finish}=await boot('ms38',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.endFight();localStorage.removeItem(d.SAVE_KEY);localStorage.removeItem(d.BAK_KEY);});
 // a veteran save
 const vet=await E(()=>{const g=__game,d=g.dbg;g.P.lv=38;g.P.gold=1234;g.P.xp=5;g.state='play';const ok=g.saveGame('t');const s=g.readSave();return {ok,lv:s&&s.P.lv,gold:s&&s.P.gold};});
 ok(vet.ok&&vet.lv===38&&vet.gold===1234,'a Lv38 / 1234G save is written ('+JSON.stringify(vet)+')');
 // ---- the Lab / Boss Rush never write (RUSH.on blocks saving)
 const lab=await E(()=>{const g=__game,d=g.dbg,raw=localStorage.getItem(d.SAVE_KEY);d.RUSH.on=true;g.P.lv=1;g.P.gold=0;const w=g.saveGame('lab');d.RUSH.on=false;const same=localStorage.getItem(d.SAVE_KEY)===raw;g.P.lv=38;g.P.gold=1234;return {w,same};});
 ok(lab.w===false&&lab.same,'saving is blocked while the Combat Lab / Boss Rush is active (save untouched)');
 // ---- a fresh Lv1 hero overwriting a veteran keeps a backup
 const reg=await E(()=>{const g=__game,d=g.dbg;g.P.lv=1;g.P.gold=0;g.state='play';g.saveGame('oops');const s=g.readSave(),b=d.readBackup();g.P.lv=38;g.P.gold=1234;return {now:s.P.lv,bak:b&&b.P.lv,bgold:b&&b.P.gold};});
 ok(reg.now===1&&reg.bak===38&&reg.bgold===1234,'a regression to Lv1 keeps the Lv38 save as a backup ('+JSON.stringify(reg)+')');
 // ---- title: Restore Backup appears and works
 const tt=await E(()=>{const g=__game,d=g.dbg;g.state='title';g.titleMenu.items.length=0;d.initTitleMenu();return {items:g.titleMenu.items.slice(),line:g.titleMenu.save.P.lv};});
 ok(tt.items.join()==='Continue,New Game,Restore Backup,Fishing Lab'&&tt.line===1,'title screen offers Restore Backup next to the Lv1 Continue ('+tt.items.join('|')+')');
 const rs=await E(()=>{const g=__game,d=g.dbg;g.titleMenu.sel=2;g.P.lv=1;g.P.gold=0;d.startFromTitle();const s=g.readSave();return {state:g.state,lv:g.P.lv,gold:g.P.gold,saved:s.P.lv};});
 ok(rs.state==='play'&&rs.lv===38&&rs.gold===1234&&rs.saved===38,'Restore Backup brings back Lv38 / 1234G and rewrites the save ('+JSON.stringify(rs)+')');
 // ---- New Game: really a new hero, and the old save is kept as a backup
 const ng=await E(()=>{const g=__game,d=g.dbg;g.state='title';localStorage.removeItem(d.BAK_KEY);g.titleMenu.items.length=0;d.initTitleMenu();g.titleMenu.sel=1;g.P.lv=38;g.P.gold=1234;
   d.startFromTitle();const first=g.titleMenu.confirm;d.startFromTitle();return {first,state:g.state,lv:g.P.lv,gold:g.P.gold,save:g.readSave(),bak:d.readBackup()&&d.readBackup().P.lv};});
 ok(ng.first&&ng.state==='play'&&ng.lv===1&&ng.gold===0&&!ng.save&&ng.bak===38,'New Game needs two presses, resets the hero (even after quit-to-title) and backs the old save up ('+JSON.stringify({lv:ng.lv,gold:ng.gold,bak:ng.bak})+')');
 // the new hero autosaves, the backup stays
 const as=await E(()=>{const g=__game,d=g.dbg;g.state='play';g.saveGame('t');return {lv:g.readSave().P.lv,bak:d.readBackup().P.lv};});
 ok(as.lv===1&&as.bak===38,'the new hero autosaves without touching the backup');
 // a worse save never replaces a better backup
 const nb=await E(()=>{const g=__game,d=g.dbg;g.P.lv=3;g.saveGame('t');g.P.lv=1;g.saveGame('t');d.clearSave();return d.readBackup().P.lv;});
 ok(nb===38,'the most advanced backup is kept ('+nb+')');
 await E(()=>{const d=__game.dbg;localStorage.removeItem(d.SAVE_KEY);localStorage.removeItem(d.BAK_KEY);});
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
