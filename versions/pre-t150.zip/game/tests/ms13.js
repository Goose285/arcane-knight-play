// M13: tutorial/onboarding, settings (volume, gamepad, left-handed), colour-blind modes, text size.  node tests/ms13.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,MOBILE,pg}=await boot('ms13');
 const calm=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.UI.mode=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.P.grace=99;g.P.hp=d.maxHp();});
 const clickCanvas=async(r)=>{const p=await E(r=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},r);
   if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(250);};
 await calm();
 const reset=()=>E(()=>{const d=__game.dbg;Object.assign(d.SET,d.SET_DEFAULT);d.setSave();d.setApply();});

 // ================= DATA / DEFAULTS =================
 const dat=await E(()=>{const d=__game.dbg,o={};
   o.def=d.SET.master===.8&&d.SET.music===.8&&d.SET.sfx===.8&&d.SET.text===0&&d.SET.cb===0&&d.SET.lefty===false&&d.SET.pad===true;
   o.txt=d.TEXT_SIZES.length===3&&d.TEXT_SIZES[0].k===1&&d.TEXT_SIZES[2].k>d.TEXT_SIZES[1].k;o.cb=d.CB_MODES.length===4&&d.CB_MODES[0].id==='off';
   o.tut=d.TUT_STEPS.length===5&&d.TUT_STEPS.every(s=>s.id&&s.k&&s.t);o.pause=d.PAUSE_ITEMS.some(i=>i.k==='KeyN'&&i.lab()==='SETTINGS');
   o.newGameTut=d.TUT.on===true&&d.TUT.i===0;d.tutFinish(true);return o;});
 for(const [k,v] of Object.entries(dat))ok(v,'data: '+k);
 await reset();
 // pause menu still fits every entry
 const pm=await E(()=>{const g=__game,d=g.dbg;g.state='paused';return new Promise(r=>setTimeout(()=>{const z=g.size,rs=d.getPauseRects();const o={n:rs.length===11&&d.PAUSE_ITEMS.length===16,fit:rs.every(q=>q.y>=0&&q.y+q.h<=z.VH&&q.x>=0&&q.x+q.w<=z.VW)};
   let ov=false;for(let i=0;i<rs.length;i++)for(let j=i+1;j<rs.length;j++){const a=rs[i],b=rs[j];if(a.x<b.x+b.w&&b.x<a.x+a.w&&a.y<b.y+b.h&&b.y<a.y+a.h)ov=true;}o.noOverlap=!ov;g.state='play';r(o);},150));});
 ok(pm.n&&pm.fit&&pm.noOverlap,'pause menu: main page (9 buttons + sound) and all 14 features reachable, fit on screen without overlapping '+JSON.stringify(pm));

 // ================= PERSISTENCE =================
 const ps=await E(()=>{const g=__game,d=g.dbg,o={};Object.assign(d.SET,{master:.3,music:.5,sfx:.1,text:2,cb:3,lefty:true,pad:false,tutDone:true});d.setSave();
   const raw=JSON.parse(localStorage.getItem(d.SET_KEY));o.raw=raw.master===.3&&raw.text===2&&raw.cb===3&&raw.lefty===true&&raw.pad===false&&raw.tutDone===true;
   Object.assign(d.SET,d.SET_DEFAULT);d.setLoad();o.back=d.SET.master===.3&&d.SET.music===.5&&d.SET.sfx===.1&&d.SET.text===2&&d.SET.cb===3&&d.SET.lefty&&!d.SET.pad&&d.SET.tutDone;
   localStorage.setItem(d.SET_KEY,JSON.stringify({master:9,music:-4,sfx:'x',text:99,cb:-4,lefty:'yes',pad:false,tutDone:'no'}));d.setLoad();
   o.junk=d.SET.master===1&&d.SET.music===0&&d.SET.sfx===.8&&d.SET.text===2&&d.SET.cb===0&&d.SET.lefty===false&&d.SET.pad===false&&d.SET.tutDone===false;
   localStorage.setItem(d.SET_KEY,'{not json');d.setLoad();o.corrupt=d.SET.master===.8&&d.SET.text===0&&d.SET.pad===true;
   // separate from the game save, survives a new game
   d.SET.master=.6;d.setSave();d.resetDaily();o.sep=JSON.parse(localStorage.getItem(d.SET_KEY)).master===.6;
   return o;});
 for(const [k,v] of Object.entries(ps))ok(v,'settings storage: '+k);
 await reset();

 // ================= VOLUME =================
 const vo=await E(()=>{const g=__game,d=g.dbg,o={};
   d.SET.master=.5;d.SET.sfx=.5;d.SET.music=.4;o.mul=Math.abs(d.sfxVol()-.25)<1e-9&&Math.abs(d.musVol()-.2)<1e-9;
   d.SET.master=1;d.SET.sfx=.9;d.setVol('sfx',.5);o.cap=d.SET.sfx===1;d.setVol('sfx',-2);o.floor=d.SET.sfx===0;d.setVol('music',-.1);o.step=d.SET.music===.3;d.setVol('music',.1);o.round=d.SET.music===.4;return o;});
 for(const [k,v] of Object.entries(vo))ok(v,'volume: '+k);
 const tg=await E(async()=>{const g=__game,d=g.dbg,o={};if(!d.AC){o.ac=false;return o;}o.ac=true;const AC=d.AC,rec=[];
   const orig=AC.createGain.bind(AC);AC.createGain=function(){const gn=orig();const s=gn.gain.setValueAtTime.bind(gn.gain);gn.gain.setValueAtTime=(v,t)=>{rec.push(v);return s(v,t);};return gn;};
   const play=(m,s)=>{d.SET.master=m;d.SET.sfx=s;rec.length=0;d.tone(300,200,.05,'square',.1);return rec[0];};
   const full=play(1,1),half=play(.5,1),quarter=play(.5,.5),zero=play(1,0);AC.createGain=orig;
   o.full=Math.abs(full-.1)<1e-6;o.half=Math.abs(half-.05)<1e-6;o.q=Math.abs(quarter-.025)<1e-6;o.zero=zero===0||zero<1e-9;
   // music master follows music*master
   d.SET.master=.5;d.SET.music=.5;g.state='play';d.musUpdate(0);const t1=d.MUS.target;d.SET.music=1;d.musUpdate(0);const t2=d.MUS.target;o.mus=!d.MUS.master||(t2>t1&&Math.abs(t1/t2-.5)<.02);
   return o;});
 ok(tg.ac,'volume: audio engine is running');ok(tg.full&&tg.half&&tg.q&&tg.zero,'volume: master x sfx scales every sound effect ('+JSON.stringify(tg)+')');ok(tg.mus,'volume: music level follows master x music');
 await reset();

 // ================= TEXT SIZE =================
 const tx=await E(()=>{const g=__game,d=g.dbg,o={};o.a=d.scaleText(8)===8&&d.scaleText(11)===11&&d.scaleText(20)===20;
   d.setCycle('text',3,1);o.b=d.TXS===1.15&&d.scaleText(8)===9&&d.scaleText(20)===20&&d.scaleText(11)>11;
   d.setCycle('text',3,1);o.c=d.TXS===1.3&&d.scaleText(8)===10.5&&d.scaleText(12)===12;
   d.setCycle('text',3,1);o.wrap=d.SET.text===0&&d.TXS===1;d.setCycle('text',3,-1);o.back=d.SET.text===2;d.setCycle('text',3,1);return o;});
 for(const [k,v] of Object.entries(tx))ok(v,'text size: '+k);
 const dh=async lvl=>E(async lvl=>{const g=__game,d=g.dbg;d.SET.text=lvl;d.setApply();g.state='play';g.DLG={name:'ELDER ORIN',lines:['Hero, sit a moment. The slimes were nothing. What troubles me sits at the far end of the Castle Road, past the gate and into the old crypt.'],i:0,c:999,yes:'YES',no:'NO'};
   await new Promise(r=>setTimeout(r,250));const b=g.dlgRects.box;return {h:b.h,w:b.w};},lvl);
 const h0=await dh(0),h1=await dh(1),h2=await dh(2);
 ok(h0.h>=100&&h1.h>=h0.h&&h2.h>h0.h,'text size: dialogue box grows with the setting ('+h0.h+' -> '+h1.h+' -> '+h2.h+')');
 await sleep(100);await shot('text-size-xl.png');
 await E(()=>{const g=__game;g.DLG=null;});
 // cutscene text wraps with the size too
 const cs=async lvl=>E(async lvl=>{const g=__game,d=g.dbg;d.SET.text=lvl;d.setApply();g.DLG=null;d.startCut('c1');await new Promise(r=>setTimeout(r,400));const st=g.DLG.steps[0];g.DLG.c=st.t.length;await new Promise(r=>setTimeout(r,250));const h=g.dlgRects.box.h;g.DLG=null;d.STORY.cutting=null;return h;},lvl);
 const c0=await cs(0),c2=await cs(2);ok(c2>c0,'text size: cutscene box grows too ('+c0+' -> '+c2+')');
 await reset();await E(()=>{__game.DLG=null;});

 // ================= COLOUR-BLIND =================
 const cb=await E(()=>{const g=__game,d=g.dbg,o={};o.off=d.cbMatrix('off')===null;
   const ms=['deutan','protan','tritan'].map(i=>d.cbMatrix(i));o.len=ms.every(m=>m.length===20&&m.every(Number.isFinite));o.last=ms.every(m=>[0,0,0,1,0].every((v,i)=>m[15+i]===v)&&[0,0,0,0].every((v,i)=>[3,4,8,9,13,14].map(k=>m[k]).every(x=>x===0)));
   o.notId=ms.every(m=>{const id=[1,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,1,0];return m.some((v,i)=>Math.abs(v-id[i])>.05);});
   // a deutan filter moves pure red/green apart in the channels the player can distinguish
   const app=(m,[r,gg,b])=>[0,1,2].map(k=>m[k*5]*r+m[k*5+1]*gg+m[k*5+2]*b);
   const dm=d.cbMatrix('deutan'),red=app(dm,[1,0,0]),grn=app(dm,[0,1,0]);o.sep=Math.abs(red[2]-grn[2])>.2||Math.abs(red[1]-grn[1])>.15;
   o.none=document.getElementById('c').style.filter==='';return o;});
 for(const [k,v] of Object.entries(cb))ok(v,'colour-blind: '+k);
 await sleep(200);const shotOff=await pg.screenshot({encoding:'base64'});
 const ap=await E(()=>{const d=__game.dbg,o={};d.setCycle('cb',4,1);o.deutan=document.getElementById('c').style.filter.includes('cbf-deutan');
   const f=document.getElementById('cbf-deutan');o.svg=!!f&&!!f.querySelector('feColorMatrix')&&f.querySelector('feColorMatrix').getAttribute('values').trim().split(/\s+/).length===20;o.three=['deutan','protan','tritan'].every(i=>!!document.getElementById('cbf-'+i));
   d.setCycle('cb',4,1);o.protan=document.getElementById('c').style.filter.includes('cbf-protan');d.setCycle('cb',4,1);o.tritan=document.getElementById('c').style.filter.includes('cbf-tritan');
   d.setCycle('cb',4,1);o.wrap=document.getElementById('c').style.filter===''&&d.SET.cb===0;d.setCycle('cb',4,1);return o;});
 for(const [k,v] of Object.entries(ap))ok(v,'colour-blind: filter '+k);
 await sleep(250);const shotCb=await pg.screenshot({encoding:'base64'});ok(shotCb!==shotOff,'colour-blind: the picture really changes');
 await shot('colourblind-deutan.png');await reset();

 // ================= LEFT-HANDED =================
 const lh=await E(()=>{const g=__game,d=g.dbg,o={};const z=g.size,mid=z.VW/2;d.setApply();
   o.rAtk=g.btn.atk.x>mid&&g.btn.pause.x>mid&&g.joy.dx<mid;
   d.setToggle('lefty');o.on=d.LEFTY&&g.btn.atk.x<mid&&g.btn.pause.x<mid&&g.joy.dx>mid;
   o.dist=g.btn.atk.x-z.SL<140&&g.btn.atk.y===(z.VH-z.SB-16-g.btn.atk.r);
   d.setToggle('lefty');o.off=!d.LEFTY&&g.btn.atk.x>mid&&g.joy.dx<mid;return o;});
 for(const [k,v] of Object.entries(lh))ok(v,'left-handed: '+k);
 if(MOBILE){
   const touch=async(fx,fy)=>{const p=await E((fx,fy)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+fx*z.VW/z.VW*c.width,y:c.top+fy*c.height};},fx,fy);await pg.touchscreen.touchStart(p.x,p.y);await sleep(150);const on=await E(()=>__game.joy.on);await pg.touchscreen.touchEnd();await sleep(150);return on;};
   await calm();
   const rr=await touch(.8,.42),rl=await touch(.2,.5);ok(!rr&&rl,'left-handed: right-handed layout - stick starts on the left only');
   await E(()=>{__game.dbg.setToggle('lefty');});
   const lr=await touch(.8,.42),ll=await touch(.2,.5);ok(lr&&!ll,'left-handed: mirrored layout - stick starts on the right only');
   await E(()=>{__game.dbg.setToggle('lefty');__game.dbg.setToggle('lefty');});await sleep(200);await shot('left-handed-layout.png');
   await E(()=>{__game.dbg.setToggle('lefty');});
 }else{
   await E(()=>{__game.dbg.setToggle('lefty');});await reset();
 }
 await reset();

 // ================= GAMEPAD =================
 await calm();
 await E(()=>{window.__pad={connected:true,id:'Test Pad (STANDARD GAMEPAD)',axes:[0,0,0,0],buttons:Array.from({length:17},()=>({pressed:false,value:0}))};navigator.getGamepads=()=>[window.__pad];});
 await sleep(300);
 const g1=await E(()=>{const d=__game.dbg;return {on:d.PAD.on,toast:d.toasts.some(t=>/Gamepad connected/.test(t.s))};});ok(g1.on&&g1.toast,'gamepad: connection is detected and announced');
 const mv=await E(async()=>{const g=__game,d=g.dbg,o={};g.tp(12,37);g.P.grace=99;const x0=g.P.x;window.__pad.axes[0]=1;await new Promise(r=>setTimeout(r,500));o.held=g.keys.KeyD===true;o.moved=g.P.x>x0+10;
   window.__pad.axes[0]=0;await new Promise(r=>setTimeout(r,200));o.released=!g.keys.KeyD;const y0=g.P.y;window.__pad.axes[1]=-1;await new Promise(r=>setTimeout(r,400));o.up=g.P.y<y0-5||g.keys.KeyW===true;window.__pad.axes[1]=0;
   window.__pad.axes[0]=.2;await new Promise(r=>setTimeout(r,200));o.dead=!g.keys.KeyD;window.__pad.axes[0]=0;return o;});
 ok(mv.held&&mv.moved,'gamepad: left stick walks the hero');ok(mv.released,'gamepad: releasing the stick stops');ok(mv.up&&mv.dead,'gamepad: up works and the dead-zone ignores drift');
 const bt=await E(async()=>{const g=__game,d=g.dbg,o={};const hold=async(i)=>{window.__pad.buttons[i]={pressed:true,value:1};await new Promise(r=>setTimeout(r,120));const k={j:g.keys.KeyJ,e:g.keys.KeyE,k:g.keys.KeyK,l:g.keys.KeyL,p:d.state==='paused'||g.state==='paused'};window.__pad.buttons[i]={pressed:false,value:0};await new Promise(r=>setTimeout(r,120));return k;};
   g.state='play';o.a=(await hold(0)).j===true;o.b=(await hold(1)).e===true;o.x=(await hold(2)).k===true;o.y=(await hold(3)).l===true;o.rb=(await hold(5)).l===true;
   g.state='play';const st=await hold(9);o.start=st.p;g.state='play';await new Promise(r=>setTimeout(r,100));
   o.rel=!g.keys.KeyJ&&!g.keys.KeyE&&!g.keys.KeyK&&!g.keys.KeyL;return o;});
 for(const [k,v] of Object.entries(bt))ok(v,'gamepad buttons: '+k);
 // menus: A confirms, B backs out, d-pad moves the cursor
 const mn=await E(async()=>{const g=__game,d=g.dbg,o={};g.state='play';d.openGear();await new Promise(r=>setTimeout(r,200));o.in=g.state==='gear';
   window.__pad.buttons[13]={pressed:true,value:1};await new Promise(r=>setTimeout(r,100));o.down=g.keys.ArrowDown===true;window.__pad.buttons[13]={pressed:false,value:0};await new Promise(r=>setTimeout(r,100));
   window.__pad.buttons[0]={pressed:true,value:1};await new Promise(r=>setTimeout(r,100));o.enter=g.keys.Enter===true&&!g.keys.KeyE;window.__pad.buttons[0]={pressed:false,value:0};await new Promise(r=>setTimeout(r,100));
   window.__pad.buttons[1]={pressed:true,value:1};await new Promise(r=>setTimeout(r,200));o.back=g.state!=='gear';window.__pad.buttons[1]={pressed:false,value:0};await new Promise(r=>setTimeout(r,100));g.state='play';return o;});
 for(const [k,v] of Object.entries(mn))ok(v,'gamepad menus: '+k);
 const dlg=await E(async()=>{const g=__game,d=g.dbg;g.state='play';g.DLG={name:'T',lines:['one','two'],i:0,c:99};window.__pad.buttons[0]={pressed:true,value:1};await new Promise(r=>setTimeout(r,150));window.__pad.buttons[0]={pressed:false,value:0};await new Promise(r=>setTimeout(r,100));const r=g.DLG&&g.DLG.i===1;g.DLG=null;return r;});
 ok(dlg,'gamepad: A advances dialogue');
 // turning it off in settings
 const off=await E(async()=>{const g=__game,d=g.dbg,o={};d.setToggle('pad');await new Promise(r=>setTimeout(r,200));o.off=!d.PAD.on;g.P.grace=99;const x0=g.P.x;window.__pad.axes[0]=1;await new Promise(r=>setTimeout(r,400));o.still=g.P.x<x0+4&&!g.keys.KeyD;window.__pad.axes[0]=0;
   d.setToggle('pad');await new Promise(r=>setTimeout(r,200));o.on=d.PAD.on;return o;});
 ok(off.off&&off.still,'gamepad: the settings switch turns it off');ok(off.on,'gamepad: and back on');
 await E(()=>{window.__pad.connected=false;});await sleep(200);ok(await E(()=>!__game.dbg.PAD.on&&!__game.keys.KeyD),'gamepad: unplugging releases everything');
 await E(()=>{delete navigator.getGamepads;});

 // ================= TUTORIAL =================
 await calm();await reset();
 const t0=await E(()=>{const g=__game,d=g.dbg,o={};window.__NOTUT=true;o.off=d.tutStart()===false&&!d.TUT.on;window.__NOTUT=false;
   d.SET.tutDone=true;o.noRepeat=d.tutMaybeStart()===false&&!d.TUT.on;d.SET.tutDone=false;o.first=d.tutMaybeStart()===true&&d.TUT.on&&d.TUT.i===0;return o;});
 ok(t0.off,'tutorial: can be disabled (test pages)');ok(t0.noRepeat&&t0.first,'tutorial: starts once on a fresh device only');
 await sleep(1100);await E(()=>{__game.dbg.toasts.length=0;});await sleep(150);await shot('tutorial-step.png');
 const st=await E(async()=>{const g=__game,d=g.dbg,o={};const wait=ms=>new Promise(r=>setTimeout(r,ms));const gold0=g.P.gold;g.P.grace=99;g.tp(12,37);d.TUT.px=g.P.x;d.TUT.py=g.P.y;d.TUT.gap=0;
   await wait(150);o.s0=d.TUT.i===0;                                    // nothing yet
   g.P.x+=40;await wait(150);o.near=d.TUT.i===0;g.P.x+=80;await wait(250);o.move=d.TUT.i===1;d.TUT.gap=0;
   g.press('KeyJ');await wait(250);o.shoot=d.TUT.i===2;d.TUT.gap=0;
   g.DLG={name:'ELDER ORIN',lines:['hi'],i:0,c:0};await wait(250);o.talk=d.TUT.i===3;g.DLG=null;d.TUT.gap=0;
   g.state='paused';await wait(250);o.pause=d.TUT.i===4;g.state='play';d.TUT.gap=0;await wait(150);
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;g.P.x=e.x-60;g.P.y=e.y+2;e.engaged=false;d.startEncounter(e,true);await wait(300);
   o.fight=!d.TUT.on&&d.SET.tutDone===true;o.gold=g.P.gold>=gold0+50;o.toast=d.toasts.some(t=>/TUTORIAL COMPLETE/.test(t.s));
   o.saved=JSON.parse(localStorage.getItem(d.SET_KEY)).tutDone===true;d.endFight();return o;});
 for(const [k,v] of Object.entries(st))ok(v,'tutorial steps: '+k);
 // skip with Tab / tapping SKIP; no gift
 const sk=await E(async()=>{const g=__game,d=g.dbg,o={};const wait=ms=>new Promise(r=>setTimeout(r,ms));g.state='play';g.DLG=null;d.SET.tutDone=false;d.tutStart();d.TUT.gap=0;const gold0=g.P.gold;
   g.press('Tab');await wait(200);o.tab=!d.TUT.on&&d.SET.tutDone&&g.P.gold===gold0&&d.toasts.some(t=>/skipped/.test(t.s));return o;});
 ok(sk.tab,'tutorial: Tab skips it with no reward');
 await E(()=>{const g=__game,d=g.dbg;g.state='play';g.DLG=null;d.SET.tutDone=false;d.tutStart();d.TUT.gap=0;});await sleep(400);
 const skr=await E(()=>__game.dbg.TUT.skipR);ok(!!skr,'tutorial: SKIP button is on screen');
 if(skr){await clickCanvas(skr);}
 ok(await E(()=>!__game.dbg.TUT.on&&__game.dbg.SET.tutDone),'tutorial: tapping SKIP ends it');
 // hidden while talking/fighting
 const hid=await E(async()=>{const g=__game,d=g.dbg;const wait=ms=>new Promise(r=>setTimeout(r,ms));d.SET.tutDone=false;d.tutStart();d.TUT.gap=0;g.DLG={name:'x',lines:['y'],i:0,c:0};await wait(200);const a=d.TUT.skipR===null;g.DLG=null;await wait(200);const b=d.TUT.skipR!==null;d.tutFinish(true);return a&&b;});
 ok(hid,'tutorial: banner hides during dialogue and returns after');
 // replay from the settings screen
 await calm();await E(()=>{const g=__game,d=g.dbg;d.SET.tutDone=true;g.state='paused';d.PAUSE_ITEMS.find(i=>i.k==='KeyN').act();});await sleep(300);
 ok(await tap('set:tut',null),'settings: REPLAY TUTORIAL button on screen');await sleep(300);
 const rp=await E(()=>{const g=__game,d=g.dbg;return {on:d.TUT.on,i:d.TUT.i,st:g.state,done:d.SET.tutDone};});ok(rp.on&&rp.i===0&&rp.st==='play'&&!rp.done,'settings: replay restarts the tutorial in the world');
 await E(()=>{__game.dbg.tutFinish(true);});

 // ================= SETTINGS SCREEN =================
 await calm();await reset();
 await E(()=>{const g=__game,d=g.dbg;g.state='paused';d.PAUSE_ITEMS.find(i=>i.k==='KeyN').act();});await sleep(300);
 ok(await E(()=>__game.state==='settings'&&__game.dbg.UI.from==='paused'),'settings: opens from the pause menu');
 ok(await E(()=>__game.dbg.uiRows().length)>=13,'settings: audio, display, controls and help rows');
 await sleep(150);await shot('settings-screen.png');
 const m0=await E(()=>__game.dbg.SET.master);
 ok(await tap('set:master:minus',0),'settings: volume - button on screen');ok(await E(m=>Math.abs(__game.dbg.SET.master-(m-.1))<1e-9,m0),'settings: tapping - lowers the volume by 10%');
 await tap('set:master:plus',0);await tap('set:master:plus',0);ok(await E(m=>Math.abs(__game.dbg.SET.master-(m+.1))<1e-9,m0),'settings: tapping + raises it');
 await tap('set:music:minus',0);await tap('set:sfx:minus',0);ok(await E(()=>__game.dbg.SET.music===.7&&__game.dbg.SET.sfx===.7),'settings: music and effects sliders are independent');
 ok(await tap('set:text',null),'settings: text size button on screen');ok(await E(()=>__game.dbg.SET.text===1&&__game.dbg.TXS===1.15),'settings: tapping it cycles to LARGE and applies at once');
 await tap('set:text',null);await tap('set:text',null);ok(await E(()=>__game.dbg.SET.text===0),'settings: cycles back to NORMAL');
 await tap('set:cb',null);ok(await E(()=>__game.dbg.SET.cb===1&&document.getElementById('c').style.filter.includes('deutan')),'settings: colour-blind button applies a filter');
 await sleep(200);await shot('settings-colourblind.png');await tap('set:cb',null);await tap('set:cb',null);await tap('set:cb',null);ok(await E(()=>__game.dbg.SET.cb===0),'settings: colour-blind cycles back to OFF');
 await tap('set:lefty',null);ok(await E(()=>__game.dbg.SET.lefty&&__game.dbg.LEFTY),'settings: left-handed toggle');await tap('set:lefty',null);
 await tap('set:pad',null);ok(await E(()=>!__game.dbg.SET.pad),'settings: gamepad toggle');await tap('set:pad',null);ok(await E(()=>__game.dbg.SET.pad),'settings: gamepad toggled back on');
 // keyboard: Right raises, Left lowers on the selected row
 const kb=await E(async()=>{const g=__game,d=g.dbg;d.UI.sel=0;d.SET.master=.5;g.press('ArrowRight');await new Promise(r=>setTimeout(r,120));const a=d.SET.master===.6;g.press('ArrowLeft');await new Promise(r=>setTimeout(r,120));g.press('ArrowLeft');await new Promise(r=>setTimeout(r,120));return a&&d.SET.master===.4;});
 ok(kb,'settings: Left/Right change the highlighted slider');
 const saved=await E(()=>{const d=__game.dbg,j=JSON.parse(localStorage.getItem(d.SET_KEY));return j.master===d.SET.master&&j.sfx===.7&&j.pad===true;});ok(saved,'settings: every change is saved immediately');
 await E(()=>{__game.dbg.closeUI();});await sleep(150);ok(await E(()=>__game.state==='paused'),'settings: closing returns to the pause menu');
 await E(()=>{__game.state='play';});await reset();

 // title gear + O key: no accidental save
 const ti=await E(async()=>{const g=__game,d=g.dbg,o={};localStorage.removeItem('arcaneKnight.save.v1');g.state='title';d.initTitleMenu();await new Promise(r=>setTimeout(r,300));o.gear=!!g.titleMenu.gear;o.r=g.titleMenu.gear;return o;});
 ok(ti.gear,'title: settings gear is drawn');
 await clickCanvas(ti.r);
 const tg2=await E(()=>({st:__game.state,from:__game.dbg.UI.from}));ok(tg2.st==='settings'&&tg2.from==='title','title: tapping the gear opens settings');
 await E(()=>{__game.dbg.closeUI();});await sleep(200);
 const back=await E(()=>({st:__game.state,save:localStorage.getItem('arcaneKnight.save.v1')}));ok(back.st==='title'&&back.save===null,'title: closing returns to the title and writes no save');
 await E(()=>{__game.press('KeyO');});await sleep(250);ok(await E(()=>__game.state==='settings'),'title: O opens settings from the keyboard');
 await E(()=>{__game.dbg.closeUI();__game.state='play';});
 await reset();await finish();
})().catch(e=>{console.error(e);process.exit(1);});
