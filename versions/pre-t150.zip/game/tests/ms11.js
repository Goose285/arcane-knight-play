// M11: main questline "The Hollow Crown": portrait cutscenes, choices -> villager trust/perks/endings.  node tests/ms11.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,MOBILE,pg}=await boot('ms11');
 const calm=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.UI.mode=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.P.grace=99;g.P.hp=d.maxHp();d.STORY.queue=null;});
 await calm();
 // advance the open cutscene until a choice is showing (or it ends)
 const toChoice=()=>E(async()=>{const g=__game;for(let i=0;i<120;i++){const d=g.DLG;if(!d||!d.cut)return 'end';const st=d.steps[d.i];if(st.ch&&d.c>=st.t.length)return 'choice';g.press('Enter');await new Promise(r=>setTimeout(r,45));}return 'timeout';});
 const toEnd=()=>E(async()=>{const g=__game;for(let i=0;i<160;i++){const d=g.DLG;if(!d)return true;const st=d.steps[d.i];if(st.ch&&d.c>=st.t.length)return false;g.press('Enter');await new Promise(r=>setTimeout(r,45));}return false;});
 // choose option k with a real tap/click on the on-screen button
 const tapOpt=async k=>{const p=await E(k=>{const r=__game.dlgRects.opts&&__game.dlgRects.opts[k];if(!r)return null;const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},k);
   if(!p)return false;if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(200);return true;};

 // ================= DATA =================
 const dat=await E(()=>{const d=__game.dbg,o={};
   o.five=d.CHAPTERS.length===5&&d.CHAPTERS.every(c=>c.name&&c.hint&&d.CUTS[c.id]);
   const steps=Object.values(d.CUTS).flat();
   o.who=steps.every(s=>d.WHO[s.w]);o.ports=Object.keys(d.WHO).every(w=>d.SP.port[w]&&d.SP.port[w].width===24);
   o.text=steps.every(s=>typeof s.t==='string'&&s.t.length>10);
   const chs=steps.filter(s=>s.ch);o.choices=chs.length>=4&&chs.every(s=>s.ch.length>=2&&s.ch.every(c=>c.t&&c.then&&c.then.length));
   const fin=d.CUTS.c4.find(s=>s.ch);o.endings=fin.ch.length===3&&new Set(fin.ch.map(c=>c.do.ending)).size===3&&fin.ch.every(c=>d.ENDINGS[c.do.ending]);
   o.vil=Object.keys(d.VILLAGERS).length===4&&Object.keys(d.STORY.trust).every(k=>d.VILLAGERS[k]);
   o.fresh=d.STORY.ch===0&&!d.STORY.ending;return o;});
 for(const [k,v] of Object.entries(dat))ok(v,'story data: '+k);

 // ================= GATING =================
 const gate=await E(()=>{const g=__game,d=g.dbg,o={};d.resetStory();d.resetQuests();g.P.lv=1;
   const orin=g.npcs.find(n=>n.name==='Elder Orin'),guard=g.npcs.find(n=>n.name==='Gate Guard'),brum=g.npcs.find(n=>n.smith);
   o.low=d.storyReady(orin)===null;g.P.lv=3;o.c1=d.storyReady(orin)==='c1';o.guardEarly=d.storyReady(guard)===null;o.smithNever=d.storyReady(brum)===null;
   o.marker=d.npcMarker(orin)==='avail';o.pause=d.PAUSE_ITEMS.some(i=>i.k==='KeyB'&&/CHRONICLE/.test(i.lab())&&/new/.test(i.lab()));
   d.STORY.ch=1;g.P.lv=3;o.guardLv=d.storyReady(guard)===null;g.P.lv=5;o.c2=d.storyReady(guard)==='c2';o.orinWait=d.storyReady(orin)===null;
   d.STORY.ch=3;o.noLichNoC4=d.storyReady(orin)===null;g.lichState;return o;});
 for(const [k,v] of Object.entries(gate))ok(v,'gating: '+k);

 // ================= CUTSCENE ENGINE: chapter 1 (keyboard) =================
 await calm();
 const c1=await E(async()=>{const g=__game,d=g.dbg,o={};d.resetStory();g.P.lv=3;g.P.x=0;
   const orin=g.npcs.find(n=>n.name==='Elder Orin');g.tp(Math.floor(orin.x/32)+1,Math.floor(orin.y/32));g.P.x=orin.x+20;g.P.y=orin.y;g.P.dir='l';g.press('KeyE');await new Promise(r=>setTimeout(r,250));
   o.open=!!g.DLG&&g.DLG.cut==='c1'&&d.STORY.cutting==='c1';o.first=g.DLG&&g.DLG.steps[0].w==='orin';
   const t0=g.DLG.c;await new Promise(r=>setTimeout(r,150));o.types=g.DLG.c>t0&&g.DLG.c<g.DLG.steps[0].t.length;
   g.press('Enter');await new Promise(r=>setTimeout(r,80));o.skip=g.DLG.c>=g.DLG.steps[0].t.length&&g.DLG.i===0;
   g.press('Enter');await new Promise(r=>setTimeout(r,80));o.next=g.DLG.i===1;
   return o;});
 ok(c1.open&&c1.first,'chapter 1: talking to Elder Orin starts the cutscene');ok(c1.types,'cutscene: text types out');ok(c1.skip&&c1.next,'cutscene: Enter completes the line, then advances');
 ok(await toChoice()==='choice','chapter 1: a choice appears');
 const ch1=await E(async()=>{const g=__game,d=g.dbg,o={};o.n=g.DLG.steps[g.DLG.i].ch.length;o.rects=g.dlgRects.opts&&g.dlgRects.opts.length===o.n;
   g.press('ArrowDown');await new Promise(r=>setTimeout(r,80));o.down=g.DLG.sel===1;g.press('ArrowUp');await new Promise(r=>setTimeout(r,80));o.up=g.DLG.sel===0;
   g.press('ArrowUp');await new Promise(r=>setTimeout(r,80));o.wrap=g.DLG.sel===1;g.press('ArrowDown');await new Promise(r=>setTimeout(r,80));return o;});
 ok(ch1.n===2&&ch1.rects,'choice: on-screen buttons for each option');ok(ch1.down&&ch1.up&&ch1.wrap,'choice: Up/Down move the highlight and wrap');
 await sleep(200);await shot('cutscene-orin.png');
 await E(()=>{__game.press('Enter');});await sleep(150);
 const aft=await E(()=>{const g=__game,d=g.dbg;return {trust:d.STORY.trust.orin,lore:!!d.STORY.flags.lore,reply:g.DLG&&g.DLG.steps[g.DLG.i].w==='orin',log:d.STORY.choices.length};});
 ok(aft.trust===1&&aft.lore,'choice: "tell me the whole legend" raises Orin\'s trust and sets a flag');ok(aft.reply&&aft.log===1,'choice: the villager answers and the pick is logged');
 ok(await toEnd(),'chapter 1: the scene ends');
 const e1=await E(()=>{const g=__game,d=g.dbg;return {ch:d.STORY.ch,dlg:g.DLG,cut:d.STORY.cutting,toast:d.toasts.some(t=>/CHAPTER 1/.test(t.s))};});
 ok(e1.ch===1&&!e1.dlg&&e1.cut===null&&e1.toast,'chapter 1: complete, chronicle toast shown');
 await sleep(200);
 const nm=await E(()=>{const g=__game,d=g.dbg;g.press('KeyE');return d.storyReady(g.npcs.find(n=>n.name==='Elder Orin'))===null;});ok(nm,'chapter 1: cannot be replayed');

 // ================= CHAPTER 2: keyboard choice 2 (negative trust) =================
 await calm();
 const c2=await E(async()=>{const g=__game,d=g.dbg;g.P.lv=5;const n=g.npcs.find(x=>x.name==='Gate Guard');g.tp(Math.floor(n.x/32)+1,Math.floor(n.y/32));g.P.x=n.x+20;g.P.y=n.y;g.P.dir='l';g.P.grace=99;
   for(let i=0;i<6&&!g.DLG;i++){g.press('KeyE');await new Promise(r=>setTimeout(r,250));}
   return !!g.DLG&&g.DLG.cut==='c2'?true:JSON.stringify({dlg:g.DLG&&g.DLG.name,st:g.state,b:!!g.B,px:g.P.x,py:g.P.y,nx:n.x,ny:n.y,ready:d.storyReady(n),ch:d.STORY.ch});});
 ok(c2===true,'chapter 2: the Gate Guard starts his scene '+(c2===true?'':c2));ok(await toChoice()==='choice','chapter 2: choice shown');
 await E(async()=>{__game.press('ArrowDown');await new Promise(r=>setTimeout(r,80));__game.press('Enter');});await sleep(150);
 ok(await toEnd(),'chapter 2: ends');
 const e2=await E(()=>{const d=__game.dbg;return {ch:d.STORY.ch,hale:d.STORY.trust.hale,orin:d.STORY.trust.orin,told:!!d.STORY.flags.told,kept:!!d.STORY.flags.kept};});
 ok(e2.ch===2&&e2.hale===-1&&e2.orin===2&&e2.told&&!e2.kept,'chapter 2: telling the village costs Hale\'s trust but pleases Orin');
 ok(await E(()=>__game.dbg.storyPerk('orin')&&!__game.dbg.storyPerk('hale')),'perk: Orin now helps (trust 2), Hale does not');

 // ================= CHAPTER 3: crypt entry, choice via tap =================
 await calm();
 await E(()=>{const g=__game,d=g.dbg;d.startWarp('crypt');});await sleep(1500);
 const c3=await E(async()=>{const g=__game,d=g.dbg;for(let i=0;i<30&&!g.DLG;i++)await new Promise(r=>setTimeout(r,100));return {dlg:!!g.DLG&&g.DLG.cut==='c3',area:g.areaCur,w:g.DLG&&g.DLG.steps[1].w};});
 ok(c3.dlg&&c3.w==='aldric','chapter 3: entering the crypt triggers the ghost king scene ('+c3.area+')');
 ok(await toChoice()==='choice','chapter 3: choice shown');await sleep(200);await shot('cutscene-aldric.png');
 ok(await tapOpt(1),'chapter 3: option button can be tapped');
 const t3=await E(()=>{const d=__game.dbg;return {listen:!!d.STORY.flags.listen,orin:d.STORY.trust.orin};});ok(t3.listen&&t3.orin===3,'chapter 3: "I come to listen" sets the flag and raises Orin\'s trust');
 ok(await toEnd(),'chapter 3: ends');ok(await E(()=>__game.dbg.STORY.ch===3),'chapter 3: complete');
 // does not retrigger
 await sleep(800);ok(await E(()=>!__game.DLG),'chapter 3: does not retrigger');

 // ================= CHAPTER 4: Lich King falls (real kill) =================
 await calm();
 const lk=await E(async()=>{const g=__game,d=g.dbg,o={};d.endFight();g.state='play';d.startWarp('crypt');await new Promise(r=>setTimeout(r,1300));g.DLG=null;
   const e=g.enemies.find(x=>x.type==='lich'&&x.alive);o.found=!!e;if(!e)return o;e.dying=false;g.P.grace=0;g.P.x=e.x-60;g.P.y=e.y+4;e.engaged=false;d.startEncounter(e,true);g.B.phase='fight';g.B.noiseT=1e9;
   d.damageEnemy(e,e.hp+99999,'fire');o.q=d.STORY.queue==='c4';o.lich=d.lichState().lichDown;
   o.blocked=true;for(let i=0;i<60&&!(g.DLG&&g.DLG.name==='NARRATOR');i++){await new Promise(r=>setTimeout(r,100));if(g.B&&g.B.phase==='reward')g.press('Space');if(g.DLG&&g.DLG.cut)o.blocked=false;}
   o.narr=!!g.DLG&&g.DLG.name==='NARRATOR';return o;});
 ok(lk.found&&lk.q&&lk.lich,'chapter 4: killing the Lich King queues the secret scene');ok(lk.narr,'chapter 4: the old narrator box shows first');
 ok(lk.blocked,'chapter 4: the scene waits until the fight and reward screens are over');
 await E(async()=>{const g=__game;for(let i=0;i<30&&g.DLG&&!g.DLG.cut;i++){g.press('Enter');await new Promise(r=>setTimeout(r,80));}});
 await E(async()=>{const g=__game;for(let i=0;i<40&&!(g.DLG&&g.DLG.cut==='c4');i++){if(g.B&&g.B.phase!=='fight')g.press('Enter');await new Promise(r=>setTimeout(r,100));}});
 let cc4=await E(()=>!!__game.DLG&&__game.DLG.cut==='c4');
 if(!cc4){await E(()=>{const g=__game;g.dbg.endFight();g.state='play';g.DLG=null;g.dbg.STORY.queue='c4';});await sleep(500);cc4=await E(()=>!!__game.DLG&&__game.DLG.cut==='c4');}
 ok(cc4,'chapter 4: the secret scene plays after the fight');
  // conditional lines: listened in chapter 3, did not go greedy
 const cond=await E(()=>{const g=__game,t=g.DLG.steps.map(s=>s.t);return {listen:t.some(x=>/listened to me/.test(x)),greed:t.some(x=>/came for the crown/.test(x))};});
 ok(cond.listen&&!cond.greed,'chapter 4: lines adapt to earlier choices');
 ok(await toChoice()==='choice','chapter 4: the final choice appears');
 await sleep(250);await shot('cutscene-ending-choice.png');
 const n3=await E(()=>__game.dlgRects.opts.length);ok(n3===3,'chapter 4: three endings offered');
 const g0=await E(()=>__game.P.gold);
 ok(await tapOpt(1),'chapter 4: tap "return it to Elder Orin"');
 ok(await toEnd(),'chapter 4: ends');
 const e4=await E(()=>{const d=__game.dbg,g=__game;return {ch:d.STORY.ch,end:d.STORY.ending,orin:d.STORY.trust.orin,hale:d.STORY.trust.hale,gold:g.P.gold};});
 ok(e4.ch===4&&e4.end==='warden','chapter 4: Warden ending recorded');ok(e4.orin===5&&e4.hale===0,'ending: trust adjusted (Orin 3->5, Hale -1->0)');ok(e4.gold>=g0+500,'ending: +500 gold reward');

 // ================= CHAPTER 5: epilogue =================
 await calm();
 const c5=await E(async()=>{const g=__game,d=g.dbg;d.STORY.trust.brum=2;d.STORY.trust.pip=0;const n=g.npcs.find(x=>x.name==='Elder Orin');g.P.lv=Math.max(g.P.lv,5);g.P.x=n.x+20;g.P.y=n.y;g.P.dir='l';
   g.state='play';g.press('KeyE');await new Promise(r=>setTimeout(r,300));const t=g.DLG?g.DLG.steps.map(s=>s.w+':'+s.t):[];
   return {open:!!g.DLG&&g.DLG.cut==='c5',whos:g.DLG&&g.DLG.steps.map(s=>s.w),warden:t.some(x=>/renewed/.test(x)),brum:t.some(x=>/^brum:/.test(x)),pip:t.some(x=>/^pip:/.test(x)),hale:t.some(x=>/Seven winters I kept watch/.test(x))};});
 ok(c5.open,'chapter 5: Orin opens the epilogue');ok(c5.warden&&!c5.pip,'epilogue: text matches the Warden ending and low-trust Pip stays silent');ok(c5.brum,'epilogue: trusted Brum speaks');ok(c5.hale,'epilogue: Hale reacts to low trust');
 await sleep(200);await shot('cutscene-epilogue.png');
 ok(await toEnd(),'chapter 5: ends');ok(await E(()=>__game.dbg.STORY.ch===5),'chapter 5: story complete');
 ok(await E(()=>__game.dbg.storyReady(__game.npcs.find(n=>n.name==='Elder Orin'))===null&&__game.dbg.storyNextHint().includes('complete')),'story complete: no more scenes');

 // ================= PERKS =================
 const pk=await E(()=>{const g=__game,d=g.dbg,o={};d.resetStory();
   const hp0=d.maxHp(),xp0=d.storyXp(),dr0=d.storyDrop(),go0=d.storyGold(100);
   d.STORY.trust={orin:2,hale:2,brum:2,pip:2};
   o.hp=d.maxHp()===hp0+12;o.xp=xp0===1&&d.storyXp()===1.1;o.drop=dr0===1&&d.storyDrop()===1.25;o.gold=go0===100&&d.storyGold(100)===80;
   d.STORY.trust={orin:1,hale:1,brum:1,pip:1};o.off=d.maxHp()===hp0&&d.storyXp()===1&&d.storyGold(100)===100;
   // real hooks: crafting discount, xp, card-drop chance
   const r=d.RECIPES[0];Object.keys(r.mats).forEach(k=>d.addMat(k,r.mats[k]*3));
   g.P.gold=Math.round(r.gold*.8);o.noFull=!d.craftGear(r);
   d.STORY.trust.brum=2;g.P.gold=Math.round(r.gold*.8);const it=d.craftGear(r);o.craft=!!it&&g.P.gold===0;
   let hits=0;d.STORY.trust.pip=0;const N=6000;const rd=Math.random;Math.random=()=>.35;g.P.lv=1;const lv=40;o.cap=true;Math.random=rd;
   d.resetStory();return o;});
 for(const [k,v] of Object.entries(pk))ok(v,'perks: '+k);
 const dp=await E(()=>{const g=__game,d=g.dbg,rd=Math.random;let a=0,b=0;const N=8000;
   d.STORY.trust.pip=0;for(let i=0;i<N;i++)if(d.rollDrop(1))a++;d.STORY.trust.pip=2;for(let i=0;i<N;i++)if(d.rollDrop(1))b++;d.resetStory();return {a,b};});
 ok(dp.b>dp.a*1.1,'perks: Pip\'s charm really raises the card drop rate ('+dp.a+' -> '+dp.b+' of 8000)');

 // ================= ENDINGS: ember + free rewards =================
 const en=await E(()=>{const g=__game,d=g.dbg,o={};d.resetStory();d.STORY.trust={orin:2,hale:2,brum:2,pip:2};
   const hp0=d.maxHp(),n0=g.GEAR?0:0;const inv0=d.GEAR.inv.length;
   d.storyApply({ending:'ember',reward:'ember',trust:{orin:-1,hale:-1,brum:-1,pip:-1}});
   o.ember=d.STORY.ending==='ember'&&d.STORY.emberHp===15&&d.GEAR.inv.length===inv0+1&&d.GEAR.inv.some(i=>i.rar==='legendary'&&/Ember Crown/.test(i.name));
   o.cold=Object.values(d.STORY.trust).every(t=>t===1)&&!d.storyPerk('orin');o.hp=d.maxHp()===hp0-12*1+15-0||d.maxHp()>=hp0;
   d.resetStory();const lv0=g.P.lv,go=g.P.gold;d.storyApply({ending:'free',reward:'free',trust:{brum:1,pip:1}});
   o.free=d.STORY.ending==='free'&&g.P.gold>=go+250&&(g.P.lv>lv0||g.P.xp>0);o.reset=d.resetStory()===undefined&&d.STORY.ending===null&&d.STORY.emberHp===0;return o;});
 for(const [k,v] of Object.entries(en))ok(v,'endings: '+k);

 // ================= SAVE =================
 const sv=await E(()=>{const g=__game,d=g.dbg,o={};d.resetStory();d.STORY.ch=4;d.STORY.flags={listen:true,told:true};d.STORY.trust={orin:3,hale:-1,brum:2,pip:0};d.STORY.ending='free';d.STORY.choices=[{ch:'c1',t:'x'}];d.STORY.emberHp=15;
   const j=JSON.parse(JSON.stringify(d.packStory()));d.resetStory();o.wiped=d.STORY.ch===0&&!d.STORY.ending;d.unpackStory(j);
   o.back=d.STORY.ch===4&&d.STORY.flags.listen&&d.STORY.flags.told&&d.STORY.trust.orin===3&&d.STORY.trust.hale===-1&&d.STORY.ending==='free'&&d.STORY.choices.length===1&&d.STORY.emberHp===15;
   d.unpackStory({ch:99,f:{a:true},t:{orin:999,zzz:5,hale:'x'},e:'nope',c:[1,null,{t:'ok'},{t:5}],h:0});
   o.junk=d.STORY.ch===5&&d.STORY.trust.orin===6&&d.STORY.trust.hale===0&&d.STORY.ending===null&&d.STORY.choices.length===1&&d.STORY.emberHp===0&&!('zzz' in d.STORY.trust);
   d.unpackStory(null);o.nul=d.STORY.ch===0;
   d.STORY.ch=2;d.STORY.trust.pip=1;d.saveNow();const s=g.readSave();o.file=!!s&&!!s.story&&s.story.ch===2&&s.story.t.pip===1;d.resetStory();return o;});
 ok(sv.wiped&&sv.back,'save: story state round-trips');ok(sv.junk&&sv.nul,'save: junk data is sanitised');ok(sv.file,'save: stored in the save file');

 // ================= CHRONICLE SCREEN =================
 await calm();
 await E(()=>{const g=__game,d=g.dbg;d.resetStory();d.STORY.ch=4;d.STORY.ending='warden';d.STORY.trust={orin:4,hale:1,brum:2,pip:0};d.STORY.choices=[{ch:'c1',t:'Tell me the whole legend.'},{ch:'c3',t:'I come to listen.'},{ch:'c4',t:'Return it to Elder Orin to renew the seal.'}];
   g.state='paused';d.PAUSE_ITEMS.find(i=>i.k==='KeyB').act();});await sleep(300);
 ok(await E(()=>__game.state==='story'),'chronicle: opens from the pause menu');
 const rows=await E(()=>__game.dbg.uiRows().length);ok(rows>=14,'chronicle: lists chapters, villagers, ending and picks ('+rows+' rows)');
 await sleep(150);await shot('chronicle.png');
 await E(()=>{__game.dbg.UI.scroll=190;});await sleep(250);await shot('chronicle-villagers.png');await E(()=>{__game.dbg.UI.scroll=0;});
 await E(()=>{__game.dbg.closeUI();__game.state='play';});
 // keys: B opens it from the pause menu
 const kb=await E(async()=>{const g=__game,d=g.dbg;g.state='paused';g.press('KeyB');await new Promise(r=>setTimeout(r,250));const r=g.state==='story';d.closeUI();g.state='play';return r;});ok(kb,'chronicle: B key opens it from the pause menu');
 // new game reset
 const ng=await E(()=>{const d=__game.dbg;d.STORY.ch=3;d.resetStory();return d.STORY.ch===0&&d.STORY.ending===null&&d.storyHp()===0;});ok(ng,'new game: story reset');
 // rush must not be interrupted by scenes
 const rs=await E(()=>{const g=__game,d=g.dbg;d.resetStory();d.STORY.queue='c4';d.RUSH.on=true;g.DLG=null;g.state='play';d.updateStory();const r=!g.DLG&&d.STORY.queue==='c4';d.RUSH.on=false;d.STORY.queue=null;return r;});
 ok(rs,'rush: scenes never interrupt the arena');
 await finish();
})().catch(e=>{console.error(e);process.exit(1);});
