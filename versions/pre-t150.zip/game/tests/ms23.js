// M23: end-to-end charge carry-over, the way it really happens: you charge the shot in the overworld while sneaking up behind an enemy,
// the enemy turns and SEES you (natural vision trigger, not a debug startEncounter), combat begins, you release -> the CHARGED shot fires.
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,finish,MOBILE}=await boot('ms23');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.hp=d.maxHp();});
 let th=null;
 const atkXY=()=>E(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,b=__game.btn.atk;return {x:c.left+b.x/z.VW*c.width,y:c.top+b.y/z.VH*c.height};});
 const down=async()=>{if(MOBILE){const c=await atkXY();th=await pg.touchscreen.touchStart(c.x,c.y);}else await pg.keyboard.down('KeyJ');};
 const up=async()=>{if(MOBILE){if(th)await th.end();th=null;}else await pg.keyboard.up('KeyJ');};
 const setup=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.WCH.on=false;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.alive=true;e.x=60*32;e.y=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(o=>o.type==='knight');e.x=e.hx=8*32+16;e.y=e.hy=38*32+28;e.dying=false;e.engaged=false;e.fa=Math.PI;e.ta=Math.PI;e.mode='look';e.mt=1e9;e.lk=1e9;e.hp=e.maxhp=e.mhp=99999;
   g.tp(12,38);g.P.x=12*32+16;g.P.y=38*32+28;g.P.aim=Math.PI;g.P.dir='l';g.P.grace=0;window.__kn=e;d.toasts.length=0;});
 const info=()=>E(()=>{const B=__game.B;return {B:!!B,ph:B&&B.phase,ch:B&&B.charge,on:B&&B.charging,shots:B?B.shots.map(s=>s.kind):[],wch:__game.dbg.WCH.t};});
 // A) sneak behind (not seen), charge fully, enemy turns and spots you, keep holding, release in the fight
 await setup();await sleep(300);ok(!(await info()).B,'sneaking behind the knight: not spotted yet');
 await down();await sleep(1300);let i=await info();ok(!i.B&&i.wch>=1,'charged fully in the overworld without being seen (charge '+i.wch.toFixed(2)+')');
 await E(()=>{window.__kn.fa=0;window.__kn.ta=0;});          // he turns around and sees you
 let seen=false;for(let k=0;k<40&&!seen;k++){await sleep(50);i=await info();seen=i.B;}
 ok(seen,'the knight spots you and combat starts naturally');
 ok(i.on&&i.ch>=.99,'the full charge survived the spotting ('+(i.ch&&i.ch.toFixed(2))+')');
 await sleep(1400);i=await info();ok(i.ph==='fight'&&i.on&&i.ch>=1&&!i.shots.includes('charged'),'after the alert intro: still fully charged, nothing wasted ('+i.ph+')');
 await up();await sleep(80);i=await info();ok(i.shots.includes('charged'),'RELEASE -> the CHARGED shot fires in combat ('+i.shots+')');
 // B) same, but release while the "!" alert is still showing -> fires as soon as the fight begins
 await setup();await sleep(200);await down();await sleep(1300);
 await E(()=>{window.__kn.fa=0;window.__kn.ta=0;});
 seen=false;for(let k=0;k<40&&!seen;k++){await sleep(50);i=await info();seen=i.B;}
 ok(seen&&i.ph==='alert','spotted: alert phase');await up();
 let fired=false;for(let k=0;k<40&&!fired;k++){await sleep(100);i=await info();fired=i.ph==='fight'&&i.shots.includes('charged');}
 ok(fired,'released during the alert: charged shot fires the moment the fight starts');
 // C) half charge when spotted, keep holding: the charge keeps building and the release is charged
 await setup();await sleep(200);await down();await sleep(550);
 await E(()=>{window.__kn.fa=0;window.__kn.ta=0;});
 seen=false;for(let k=0;k<40&&!seen;k++){await sleep(50);i=await info();seen=i.B;}
 ok(seen&&i.on&&i.ch>.3&&i.ch<1,'half charge carried into combat ('+(i.ch&&i.ch.toFixed(2))+')');
 await sleep(2000);i=await info();ok(i.ph==='fight'&&i.ch>=1,'keeps charging to full in combat');
 const hp0=await E(()=>window.__kn.hp);await up();let ch=false;for(let k=0;k<12&&!ch;k++){await sleep(30);i=await info();ch=i.shots.includes('charged')||await E(h=>window.__kn.hp<h,hp0);}ok(ch,'and releases as a charged shot (it fired or already landed)');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
