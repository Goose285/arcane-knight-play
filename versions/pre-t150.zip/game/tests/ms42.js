// M42: idle fishing in landscape + catch feedback (vibrate on web, Capacitor Haptics natively, flash/splash/sound everywhere), rods, rarity.  node tests/ms42.js [desktop|mobile]
const boot=require('./lib/ms');const path=require('path');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish,b}=await boot('ms42',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.endFight();d.setTimeOfDay(.5);d.TRK.open=false;d.resetFish();d.FSH.rod=0;g.P.grace=99;g.tp(24,41);
   window.__vib=[];navigator.vibrate=p=>{window.__vib.push(p);return true;};for(const e of g.enemies)if(e.alive){e.alive=false;e.hidden=true;e.x=64;e.y=64;e.respawn=1e9;}});
 await sleep(600);
 // ---- web feedback: vibrate patterns (rare is stronger)
 const v=await E(()=>{const d=__game.dbg;window.__vib.length=0;d.hapticCatch(0);d.hapticCatch(1);d.hapticCatch(2);d.hapticCatch(4);return window.__vib.slice();});
 ok(v.length===4&&v[0][0]<v[2][0]+100&&Array.isArray(v[2])&&v[2].length>=3&&v[3].length>v[2].length,'web: navigator.vibrate on every catch, stronger pattern for rare ('+JSON.stringify(v)+')');
 // ---- idle fishing screens
 await E(()=>{const g=__game,d=g.dbg;g.press('KeyE');});await sleep(1000);
 await E(()=>{const d=__game.dbg;d.FISH.next=.05;});await sleep(250);
 const f1=await E(()=>{const d=__game.dbg;return {ph:d.FISH.ph,fx:d.FISH.fx.length,flash:!!d.FISH.flash,pop:d.FISH.fx.some(q=>q.fish),txt:d.FISH.fx.some(q=>q.txt&&/^\+/.test(q.txt)),ring:d.FISH.fx.some(q=>q.ring),vib:window.__vib.length,n:Object.values(d.FSH.fish).length};});
 ok(f1.ph==='on'&&f1.pop&&f1.txt&&f1.ring&&!f1.flash&&f1.vib>=5&&f1.n>=1,'a catch fires haptics + fish pop + splash ring + +Name text, and NO full-screen flash ('+JSON.stringify(f1)+')');
 await shot('fishing-landscape-catch.png');
 await sleep(1500);await E(()=>{__game.dbg.FISH.fx.length=0;__game.dbg.FISH.flash=null;});await shot('fishing-landscape-idle.png');
 await E(()=>{const d=__game.dbg;d.FISH.rare=.05;d.FISH.next=99;});await sleep(500);
 await shot('fishing-landscape-rare.png');
 ok(await E(()=>__game.dbg.FISH.ph==='rare'),'rare bite prompt shown in landscape');
 await E(()=>{window.__vib.length=0;});await pg.keyboard.press('Space');await sleep(150);
 const rv=await E(()=>({vib:window.__vib.slice(-1)[0],flash:__game.dbg.FISH.flash&&__game.dbg.FISH.flash.a}));
 ok(Array.isArray(rv.vib)&&rv.vib.length>=3,'landing a rare fish uses the stronger vibration ('+JSON.stringify(rv)+')');
 await sleep(300);await shot('fishing-landscape-rare-catch.png');
 // ---- rarity rules
 const r=await E(()=>{const d=__game.dbg,g=__game;d.FSH.xp=99999;const sp=d.FISH_SPOTS.find(s=>s.id==='oasis');const auto=new Set(),rare=new Set();for(let i=0;i<500;i++){auto.add(d.fishPickAuto(sp).id);rare.add(d.fishPickRare(sp).id);}
   return {auto:[...auto],rare:[...rare],rars:d.FISHES.map(f=>f.rar).every(x=>x>=0&&x<=4)};});
 ok(r.rare.every(i=>['gill','perch','koi','bass','eel'].includes(i))&&r.rare.includes('koi'),'rare bites land the good fish ('+r.rare+')');
 ok(!r.auto.includes('koi')&&!r.auto.includes('gill'),'ordinary catches are the everyday fish ('+r.auto+')');
 // rods: better rod = faster bites + longer rare window
 const rd=await E(()=>{const d=__game.dbg;return d.RODS.map(x=>[x.waitMul,x.bite,x.luck]);});
 ok(rd[0][0]>rd[1][0]&&rd[1][0]>rd[2][0]&&rd[2][1]>rd[0][1]&&rd[2][2]>rd[0][2],'better rods: shorter gaps, longer rare window, better luck ('+JSON.stringify(rd)+')');
 // ---- native Capacitor path in a fresh page with a fake Capacitor.Haptics
 const pg2=await b.newPage();if(MOB){const puppeteer=require('puppeteer-core');await pg2.emulate(puppeteer.KnownDevices['iPhone 12 landscape']);}
 await pg2.evaluateOnNewDocument(()=>{window.__NOTOWN=true;window.__calls=[];window.Capacitor={isNativePlatform:()=>true,registerPlugin:(n)=>({impact:o=>window.__calls.push(['impact',o.style]),notification:o=>window.__calls.push(['notify',o.type])})};});
 await pg2.goto('file://'+path.join(__dirname,'..','index.html'));await sleep(700);
 const nat=await pg2.evaluate(async()=>{const d=__game.dbg;d.hapticCatch(0);d.hapticCatch(2);await new Promise(r=>setTimeout(r,400));return window.__calls;});
 ok(nat.some(c=>c[0]==='impact'&&c[1]==='LIGHT')&&nat.some(c=>c[0]==='notify'&&c[1]==='SUCCESS')&&nat.some(c=>c[1]==='HEAVY'),'native: Capacitor Haptics light tap for common, success + heavy for rare ('+JSON.stringify(nat)+')');
 await pg2.close();
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
