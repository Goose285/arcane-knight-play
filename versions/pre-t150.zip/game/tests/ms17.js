// M17: monster spawners, tap-to-talk (no TALK button), fishing, Oakvale Chapel.  node tests/ms17.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,tap,shot,finish,MOBILE}=await boot('ms17');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 const setup=async()=>E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';g.endFightSafe&&g.endFightSafe();d.endFight();d.endFishing();g.P.hp=d.maxHp();g.P.grace=9999;g.P.gold=0;});
 await setup();await sleep(300);
 // click / tap a world point (screen coords from the camera)
 const clickW=async(wx,wy)=>{const p=await E((x,y)=>{const g=__game,c=document.getElementById('c').getBoundingClientRect(),z=g.size;return {x:c.left+(x-g.cam.x)/z.VW*c.width,y:c.top+(y-g.cam.y)/z.VH*c.height};},wx,wy);
   if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);return p;};
 const waitFor=async(f,ms=8000,step=100)=>{const t0=Date.now();while(Date.now()-t0<ms){if(await E(f))return true;await sleep(step);}return false;};
 const npcPos=async n=>E(nm=>{const o=__game.npcs.find(x=>x.name===nm);return {x:o.x,y:o.y-18};},n);

 // ---------------- 1. the TALK button is gone; tapping an NPC talks / walks over ----------------
 let a=await E(()=>{const g=__game;return {talkBtn:!!g.btn.talk,names:Object.keys(g.btn)};});
 ok(!a.talkBtn,'no on-screen TALK button exists ('+a.names.join(',')+')');
 await E(()=>{__game.tp(20,37);__game.DLG=null;});await sleep(400);
 a=await E(()=>__game.npcs.some(n=>Math.hypot(n.x-__game.P.x,n.y-__game.P.y)<46));
 ok(a===true,'(test set-up) standing next to an NPC');
 // in range: tap Pip -> talks at once
 let pp=await npcPos('Pip');await clickW(pp.x,pp.y);await sleep(350);
 a=await E(()=>({dlg:__game.DLG&&__game.DLG.name}));ok(a.dlg==='Pip','tapping an NPC in range opens the talk ('+a.dlg+')');
 await E(()=>{__game.DLG=null;});
 // out of range: Elder Orin is ~9 tiles away; tap walks there, then talks
 await E(()=>{__game.tp(16,31);__game.DLG=null;__game.dbg.GOTO.k=null;});await sleep(400);
 pp=await npcPos('Elder Orin');await clickW(pp.x,pp.y);await sleep(250);
 a=await E(()=>({k:__game.dbg.GOTO.k,n:__game.dbg.GOTO.path.length,dlg:!!__game.DLG}));
 ok(a.k==='npc'&&a.n>0&&!a.dlg,'tapping a far NPC starts walking ('+a.k+', '+a.n+' waypoints)');
 const arrived=await waitFor(()=>__game.DLG&&__game.DLG.name==='Elder Orin',12000);
 ok(arrived,'...and talks when it arrives (path goes around the fountain)');
 await E(()=>{__game.DLG=null;});
 // walking is cancelled by steering; tapping empty ground does nothing
 await E(()=>{__game.tp(16,31);__game.DLG=null;});await sleep(300);
 pp=await npcPos('Elder Orin');await clickW(pp.x,pp.y);await sleep(200);
 await pg.keyboard.down('KeyD');await sleep(180);await pg.keyboard.up('KeyD');await sleep(150);
 a=await E(()=>({k:__game.dbg.GOTO.k}));ok(a.k===null,'pressing a move key cancels the walk');
 await sleep(300);
 await E(()=>{__game.tp(16,31);__game.dbg.GOTO.k=null;});await sleep(300);
 a=await E(()=>{const g=__game;const wx=g.P.x+60,wy=g.P.y-30;return {t:g.dbg.worldTargetAt({x:wx-g.cam.x,y:wy-g.cam.y})};});
 ok(a.t===null,'empty ground is not a tap target');
 // keyboard E still works
 await E(()=>{const g=__game;const n=g.npcs.find(x=>x.name==='Pip');g.P.x=n.x-24;g.P.y=n.y;g.DLG=null;g.press('KeyE');});await sleep(300);
 a=await E(()=>({dlg:__game.DLG&&__game.DLG.name}));ok(a.dlg==='Pip','the E key still talks on desktop');
 await E(()=>{__game.DLG=null;});

 // ---------------- 2. Oakvale Chapel ----------------
 a=await E(()=>{const d=__game.dbg,T=d.T,C=d.CHAPEL;let cnt={};for(let y=C.y0;y<=C.y1;y++)for(let x=C.x0;x<=C.x1;x++){const t=d.map[y][x];cnt[t]=(cnt[t]|0)+1;}
   const pr=__game.npcs.find(n=>n.priest);return {pews:cnt[T.CHP],glass:cnt[T.CHW],altar:cnt[T.CHA],carpet:cnt[T.CHC],roof:(cnt[T.CHS]|0)+(cnt[T.CHR]|0),
     door:!d.map[C.y1][C.door]||d.reach[C.y1][C.door],priestReach:d.reach[Math.floor(pr.y/32)][Math.floor(pr.x/32)],name:d.areaName(21,34),cross:!!d.SP.chapelCross,villageAtDoor:d.areaName(21,38)};});
 ok(a.pews>=8&&a.glass>=5&&a.altar===1&&a.carpet>=4&&a.roof>=14,'chapel has pews ('+a.pews+'), stained glass ('+a.glass+'), an altar, an aisle carpet and a roof');
 ok(a.priestReach===true,'the priest can be reached on foot');ok(a.door,'the chapel door tile is walkable');ok(a.name==='OAKVALE CHAPEL'&&a.villageAtDoor==='OAKVALE VILLAGE','area name shows OAKVALE CHAPEL inside, village outside ('+a.name+')');
 ok(a.cross,'there is a cross sprite for the roof');
 await E(()=>{const g=__game;g.P.hp=7;g.DLG=null;g.dbg.ACH.s.bless=0;});
 pp=await E(()=>{const g=__game,n=g.npcs.find(x=>x.priest);g.tp(21,36);return {x:n.x,y:n.y-18};});await sleep(500);
 await clickW(pp.x,pp.y);
 ok(await waitFor(()=>__game.DLG&&__game.DLG.name==='FATHER ANSELM',9000),'tapping the priest walks into the chapel and talks');
 a=await E(()=>({txt:__game.DLG.lines.join(' '),yes:__game.DLG.yes,hp:__game.P.hp}));
 ok(/Peace be with you/.test(a.txt)&&/costs nothing/.test(a.txt)&&a.yes==='BLESS'&&a.hp<10,'priest greets kindly and offers a free blessing ('+a.yes+')');
 // walk the dialog to the choice then accept
 for(let i=0;i<4;i++){await E(()=>{const d=__game.DLG;if(d){d.c=9999;if(d.i<d.lines.length-1)d.i++,d.c=0;}});await sleep(60);}
 await E(()=>{__game.DLG.c=9999;});await sleep(80);await E(()=>__game.press('Enter'));await sleep(250);
 a=await E(()=>{const g=__game;return {hp:g.P.hp,max:g.dbg.maxHp(),bless:g.dbg.ACH.s.bless,after:g.DLG&&g.DLG.name,verse:g.DLG&&g.DLG.lines[0],save:!!g.readSave()&&g.readSave().why};});
 ok(a.hp===a.max,'the blessing fully heals ('+a.hp+'/'+a.max+')');ok(a.bless===1,'blessing counts for the achievement');
 ok(a.after==='FATHER ANSELM'&&a.verse&&a.verse.length>20,'priest follows up with an encouraging line');ok(a.save==='chapel','the chapel saves the game ('+a.save+')');
 await E(()=>{__game.DLG=null;});
 await E(()=>{__game.tp(21,34);});await sleep(1200);await E(()=>{__game.dbg.toasts.length=0;});
 await shot('church-interior.png');
 if(MOBILE){await E(()=>{__game.tp(21,38);__game.dbg.toasts.length=0;});await sleep(1300);await E(()=>{__game.dbg.toasts.length=0;});await shot('church.png');}

 // ---------------- 3. fishing ----------------
 await E(()=>{const g=__game,d=g.dbg;d.resetFish();d.resetQuests();g.DLG=null;g.state='play';g.P.gold=0;g.P.hp=d.maxHp();g.tp(24,41);d.toasts.length=0;});await sleep(500);
 a=await E(()=>({spots:__game.dbg.FISH_SPOTS.length,kinds:new Set(__game.dbg.FISH_SPOTS.map(s=>__game.dbg.zoneOfPx(__game.dbg.spotCenter(s).y))).size,water:__game.dbg.FISH_SPOTS.every(s=>__game.dbg.map[s.ty][s.tx]===__game.dbg.T.W),near:!!__game.dbg.fishSpotNear()}));
 ok(a.spots>=5&&a.kinds>=3&&a.water,'fishing spots sit on water in '+a.kinds+' areas ('+a.spots+' spots)');ok(a.near,'standing on the bank puts a spot in reach');
 a=await E(()=>{const g=__game,d=g.dbg;const r=d.startFishing(d.fishSpotNear());return {r,on:d.FISH.on,t:d.toasts.length&&d.toasts[d.toasts.length-1].s};});
 ok(!a.r&&!a.on&&/rod/i.test(a.t||''),'without a rod you are told to buy one ('+a.t+')');
 // buy the rod at Brum's shop through the real UI
 await E(()=>{const g=__game;g.P.gold=500;g.dbg.openShop();});await sleep(300);
 ok(await tap('rod:wood',1100),'Brum sells a Wooden Rod (shop button)');
 a=await E(()=>({rod:__game.dbg.FSH.rod,gold:__game.P.gold}));ok(a.rod===0&&a.gold===475,'buying the starter rod costs 25 G ('+a.gold+' left)');
 ok(await tap('rod:star',1100),'Starlight rod button exists');await E(()=>{__game.dbg.FSH.rod=0;__game.P.gold=500;});
 await E(()=>{__game.dbg.closeUI();__game.state='play';__game.dbg.toasts.length=0;});await sleep(300);
 // start with the E key: you cast ONCE and then fish arrive on their own (idle fishing)
 await E(()=>{const g=__game,d=g.dbg;g.tp(24,41);g.press('KeyE');});await sleep(250);
 a=await E(()=>({on:__game.dbg.FISH.on,ph:__game.dbg.FISH.ph}));ok(a.on&&a.ph==='cast','E next to the rippling water starts fishing ('+a.ph+')');
 await sleep(900);
 a=await E(()=>{const d=__game.dbg;return {ph:d.FISH.ph,next:d.FISH.next,lo:d.FISH_CFG.catch[0],hi:d.FISH_CFG.catch[1]};});
 ok(a.ph==='on'&&a.next>=a.lo*.7&&a.next<=a.hi+.1,'after the cast it just waits - next catch in ~8-15s ('+a.next.toFixed(1)+'s)');
 // the player does nothing: shorten the timer and the fish is caught by itself, with feedback
 await E(()=>{const d=__game.dbg;d.FSH.fish={};d.FSH.caught=0;d.FSH.xp=0;d.FISH.next=.2;});await sleep(500);
 a=await E(()=>{const d=__game.dbg;return {n:Object.values(d.FSH.fish).reduce((x,y)=>x+y,0),caught:d.FSH.caught,xp:d.FSH.xp,fx:d.FISH.fx.length,flash:!!d.FISH.flash,pop:d.FISH.fx.some(q=>q.fish),ph:d.FISH.ph,sess:d.FISH.session};});
 ok(a.n>=1&&a.ph==='on'&&a.sess===1,'a fish is caught with no input at all and fishing continues ('+JSON.stringify(a)+')');
 ok(a.fx>0&&a.pop&&!a.flash,'a catch shows the fish pop + splash particles and no screen flash');
 await shot('fishing.png');
 // rare bite: the prompt, a ~4s window, tap lands a better fish
 await E(()=>{const d=__game.dbg;d.FSH.fish={};d.FSH.caught=0;d.FISH.rare=.1;d.FISH.next=99;});await sleep(300);
 a=await E(()=>{const d=__game.dbg;return {ph:d.FISH.ph,win:d.FISH.win,pick:d.FISH.pick&&d.FISH.pick.id};});
 ok(a.ph==='rare'&&a.win>=4,'a Rare bite prompt appears with a ~4s window ('+a.win+'s)');
 await sleep(2500);ok(await E(()=>__game.dbg.FISH.ph==='rare'),'the rare bite is still catchable 2.5s later');
 await shot('fishing-rare.png');
 await pg.keyboard.press('Space');await sleep(250);
 a=await E(()=>{const d=__game.dbg;return {ph:d.FISH.ph,caught:d.FSH.caught,n:Object.values(d.FSH.fish).reduce((x,y)=>x+y,0)};});
 ok(a.ph==='on'&&a.n===1&&a.caught===1,'tapping the Rare bite lands the fish ('+JSON.stringify(a)+')');
 // ignoring a rare bite lets it go (and fishing carries on)
 await E(()=>{const d=__game.dbg;d.FISH.rare=.1;d.FISH.next=99;});await sleep(300);await E(()=>{__game.dbg.FISH.t=__game.dbg.FISH.win-.1;});await sleep(400);
 a=await E(()=>({ph:__game.dbg.FISH.ph,on:__game.dbg.FISH.on,n:Object.values(__game.dbg.FSH.fish).reduce((x,y)=>x+y,0)}));ok(a.ph==='on'&&a.on&&a.n===1,'ignoring a Rare bite lets it go - and fishing continues');
 // REEL IN stops
 await E(()=>{const d=__game.dbg;const r=d.FISH.stopR;__game.dbg.fishTap({x:r.x+5,y:r.y+5});});
 a=await E(()=>__game.dbg.FISH.on);ok(a===false,'REEL IN button stops fishing');
 await E(()=>{__game.dbg.endFishing();});
 // moving away stops fishing
 await E(()=>{const d=__game.dbg;d.startFishing(d.fishSpotNear());});await sleep(100);await pg.keyboard.down('KeyS');await sleep(200);await pg.keyboard.up('KeyS');await sleep(120);
 a=await E(()=>__game.dbg.FISH.on);ok(a===false,'walking away ends fishing');
 // levels + gated spots + species
 a=await E(()=>{const d=__game.dbg;d.FSH.xp=0;const l1=d.fishLv();d.fishAward(d.FISHES[0]);const w=d.FISH_SPOTS.find(s=>s.id==='wood');d.tp=null;return {l1,gated:d.fishLv()<w.lv,ids:d.fishPick(d.FISH_SPOTS[0]).id};});
 ok(a.l1===1&&a.gated,'fishing starts at level 1 and the Whisperwood pond is locked');
 a=await E(()=>{const g=__game,d=g.dbg;g.tp(45,36);d.toasts.length=0;const w=d.FISH_SPOTS.find(s=>s.id==='wood');const r1=d.startFishing(w);const t=d.toasts.length&&d.toasts[d.toasts.length-1].s;d.FSH.xp=300;const lv=d.fishLv();d.endFishing();const r2=d.startFishing(w);const on=d.FISH.on;d.endFishing();
   const seen=new Set();for(let i=0;i<400;i++)seen.add(d.fishPick(w).id);const lo=new Set();d.FSH.xp=0;for(let i=0;i<200;i++)lo.add(d.fishPick(d.FISH_SPOTS[0]).id);return {r1,t,lv,r2,on,rare:[...seen].some(x=>d.FISHES.find(f=>f.id===x&&f.tier===1),),lo:[...lo].every(x=>['minnow','carp','boot','pearl'].includes(x))};});
 ok(!a.r1&&/Lv 3/.test(a.t||''),'a locked spot refuses and says the level needed ('+a.t+')');ok(a.r2&&a.on,'once leveled up the better spot opens (Lv '+a.lv+')');
 ok(a.rare,'better spots give better fish');ok(a.lo,'the village river only gives the easy fish at level 1');
 // sell and cook through the UI
 await E(()=>{const g=__game,d=g.dbg;d.resetFish();d.FSH.rod=0;d.FSH.fish={minnow:3,carp:2,boot:1};d.FSH.xp=0;g.P.gold=0;g.P.hp=10;g.tp(21,37);g.state='play';d.openFishing('play');});await sleep(300);
 ok(await tap('eat:minnow'),'COOK button for fish');
 a=await E(()=>({hp:__game.P.hp,n:__game.dbg.FSH.fish.minnow}));ok(a.hp>10&&a.n===2,'cooking a fish heals and uses it up ('+a.hp+' hp, '+a.n+' left)');
 ok(await tap('sell:carp'),'SELL button for fish');
 a=await E(()=>({gold:__game.P.gold,n:__game.dbg.FSH.fish.carp}));ok(a.gold>=11&&a.n===1,'selling pays gold ('+a.gold+' G)');
 ok(await tap('sellall'),'SELL ALL button');
 a=await E(()=>({gold:__game.P.gold,left:Object.keys(__game.dbg.FSH.fish).length}));ok(a.left===0&&a.gold>20,'sell all empties the catch ('+a.gold+' G)');
 await E(()=>{__game.dbg.closeUI();__game.state='play';});
 // crafting use + achievements
 a=await E(()=>{const d=__game.dbg;return {mat:!!d.MATS.fscale,rec:d.RECIPES.some(r=>r.id==='r_angler'&&r.mats.fscale)};});ok(a.mat&&a.rec,'Silver Scales are a crafting part with a recipe');
 a=await E(()=>{const d=__game.dbg;d.ACH.s.fish=1;d.ACH.s.spw=1;d.ACH.s.bless=1;delete d.ACH.done.fish1;window.__NOACH=false;const before=d.achCount();d.achTick();return {ids:['fish1','fish25','fishlv','spw1','spw5','bless'].map(i=>!!d.ACHS.find(x=>x.id===i)),done:d.achCount()-before};});
 ok(a.ids.every(x=>x),'fishing / spawner / chapel achievements exist');ok(a.done>=3,'...and unlock from play ('+a.done+' unlocked)');await E(()=>{window.__NOACH=true;});
 // the fisherman + his quests
 await E(()=>{const g=__game,d=g.dbg;d.resetFish();d.resetQuests();d.resetPets&&0;g.DLG=null;g.state='play';g.tp(23,40);});await sleep(300);
 pp=await npcPos('Fisher Tobin');await clickW(pp.x,pp.y);await sleep(500);
 a=await E(()=>{const g=__game;return {n:g.DLG&&g.DLG.name,txt:g.DLG&&g.DLG.lines.join(' '),yes:g.DLG&&g.DLG.yes};});
 ok(a.n==='Fisher Tobin'&&/Catch three fish/.test(a.txt||'')&&a.yes==='ACCEPT','Fisher Tobin offers a small quest ('+a.n+')');
 await E(()=>{const d=__game.DLG;d.i=d.lines.length-1;d.c=9999;});await sleep(100);await E(()=>__game.press('Enter'));await sleep(200);
 a=await E(()=>({st:__game.dbg.QS.st.fish1,rod:__game.dbg.FSH.rod,trk:__game.dbg.TRK.id,tg:(()=>{const e=__game.dbg.trkEntries().find(x=>x.id==='q:fish1');return e&&e.obj;})()}));
 ok(a.st==='active'&&a.rod===0,'accepting lends you a rod when you have none ('+a.st+', rod '+a.rod+')');ok(a.trk==='q:fish1'&&/Catch 3 fish/.test(a.tg||''),'the quest tracker follows it ('+a.tg+')');
 a=await E(()=>{const d=__game.dbg;d.fishAward(d.FISHES[0]);d.fishAward(d.FISHES[1]);const m=d.questProgress(d.QUEST_BY_ID.fish1);d.fishAward(d.FISHES[0]);return {m,st:d.QS.st.fish1,tg:d.trkTarget(d.trkEntries().find(x=>x.id==='q:fish1'))};});
 ok(a.m===2&&a.st==='ready','catching fish counts toward it ('+a.m+'/3, then '+a.st+')');
 await E(()=>{const g=__game;g.DLG=null;g.tp(23,40);const n=g.npcs.find(x=>x.name==='Fisher Tobin');g.P.x=n.x-22;g.P.y=n.y;g.P.gold=0;g.press('KeyE');});await sleep(300);
 a=await E(()=>({st:__game.dbg.QS.st.fish1,gold:__game.P.gold}));ok(a.st==='done'&&a.gold>=70,'handing in pays the reward ('+a.gold+' G)');
 await E(()=>{__game.DLG=null;});
 // tap a fishing spot from a distance: walks to the bank and casts
 await E(()=>{const g=__game,d=g.dbg;d.endFishing();g.tp(21,40);g.state='play';g.DLG=null;d.FSH.rod=0;d.toasts.length=0;});await sleep(500);
 a=await E(()=>{const d=__game.dbg,s=d.FISH_SPOTS.find(x=>x.id==='oak2'),c=d.spotCenter(s);return c;});await clickW(a.x,a.y);
 ok(await waitFor(()=>__game.dbg.FISH.on,9000),'tapping a rippling spot walks to the bank and starts fishing');
 await E(()=>{__game.dbg.endFishing();});
 // persistence
 a=await E(()=>{const g=__game,d=g.dbg;d.FSH.rod=1;d.FSH.xp=77;d.FSH.fish={trout:2};d.saveNow();const s=g.readSave();d.resetFish();const z=d.FSH.rod;g.loadSave(s);return {z,rod:d.FSH.rod,xp:d.FSH.xp,fish:d.FSH.fish.trout};});
 ok(a.z===-1&&a.rod===1&&a.xp===77&&a.fish===2,'rod, fishing xp and catch are saved and restored');

 // ---------------- 4. monster spawners ----------------
 a=await E(()=>{const d=__game.dbg;const zones=d.SPW.map(s=>d.zoneOfPx(s.y));const solid=d.SPW.some(s=>{for(let dy=-1;dy<=1;dy++)for(let dx=-1;dx<=1;dx++){const t=d.map[Math.floor(s.y/32)+dy][Math.floor(s.x/32)+dx];if([d.T.T,d.T.W,d.T.CW,d.T.MR,d.T.RE,d.T.SR,d.T.RK,d.T.SC,d.T.CP,d.T.CK].includes(t))return true;}return false;});
   const cnt={};zones.forEach(z=>cnt[z]=(cnt[z]|0)+1);return {n:d.SPW.length,cnt,solid,art:Object.keys(d.SPW_THEME).length,forestOk:d.SPW.filter(s=>d.zoneOfPx(s.y)==='ow').every(s=>d.reach[Math.floor(s.y/32)][Math.floor(s.x/32)])};});
 ok(a.n>=6&&a.cnt.ow>=2&&a.cnt.swamp>=1&&a.cnt.desert>=1&&a.cnt.crypt>=1,'spawners placed in Whisperwood, bog, ruins and crypt '+JSON.stringify(a.cnt));
 ok(!a.solid&&a.forestOk,'every spawner stands on cleared, reachable ground');
 // spawn behaviour (forest brazier)
 await E(()=>{const g=__game,d=g.dbg;d.resetSpawners();d.endFight();g.P.grace=9999;g.state='play';g.DLG=null;const s=d.SPW[0];g.tp(Math.floor(s.x/32),Math.floor(s.y/32)+3);for(const e of g.enemies)if(!e.spw&&e.alive)e.alive=false;});
 await sleep(600);
 await E(()=>{const d=__game.dbg;d.SPW[0].t=.05;});await sleep(900);
 a=await E(()=>{const d=__game.dbg,s=d.SPW[0];return {n:d.spwMinions(s).length,types:d.spwMinions(s).map(e=>e.type),near:s.near};});
 ok(a.near&&a.n>=1,'standing near a spawner makes it summon monsters ('+a.n+': '+a.types.join(',')+')');
 let maxN=0;for(let i=0;i<40;i++){await E(()=>{const d=__game.dbg,s=d.SPW[0];s.t=0;});await sleep(60);maxN=Math.max(maxN,await E(()=>__game.dbg.spwMinions(__game.dbg.SPW[0]).length));}
 ok(maxN>=2&&maxN<=3,'it keeps summoning but never above its cap (max '+maxN+')');
 a=await E(()=>{const d=__game.dbg,s=d.SPW[0];return d.spwMinions(s).every(e=>s.def.mobs.includes(e.type)&&e.spw===s);});ok(a,'summoned monsters match the brazier theme');
 // far away: no summoning
 await E(()=>{const g=__game,d=g.dbg;const s=d.SPW[1];for(const e of g.enemies)if(e.spw===s)e.alive=false;g.tp(Math.floor(s.x/32),Math.floor(s.y/32)-14<2?Math.floor(s.y/32)+14:Math.floor(s.y/32)-14);s.t=0;});await sleep(500);
 a=await E(()=>{const d=__game.dbg;return {n:d.spwMinions(d.SPW[1]).length,near:d.SPW[1].near};});ok(!a.near&&a.n===0,'a spawner you are not near stays quiet');
 // damage: real arcane shot in the overworld
 await E(()=>{const g=__game,d=g.dbg;for(const e of g.enemies)if(e.spw)e.alive=false;const s=d.SPW[0];s.hp=s.maxhp;g.P.x=s.x;g.P.y=s.y+70;g.P.dir='u';g.P.aim=-Math.PI/2;d.WS.length=0;g.snapCam&&g.snapCam();g.keys.KeyJ=false;});await sleep(200);
 const hp0=await E(()=>__game.dbg.SPW[0].hp);
 await E(()=>{__game.press('KeyJ');});await sleep(60);await E(()=>{__game.keys.KeyJ=false;});let hp1=hp0;for(let i=0;i<30&&hp1>=hp0;i++){await sleep(100);hp1=await E(()=>__game.dbg.SPW[0].hp);}
 ok(hp1<hp0,'an arcane shot damages the spawner ('+hp0+' -> '+hp1+')');
 // cards (sword arc, lance line, quake, meteor) and battle shots hit it too
 a=await E(()=>{const d=__game.dbg,s=d.SPW[0],P=__game.P;s.hp=s.maxhp;const o={x:s.x,y:s.y+30-16};const h0=s.hp;d.spwHitArc(o,-Math.PI/2,64,1.15,50,'sword');const h1=s.hp;
   d.spwHitRadius(s.x,s.y,100,50,'quake');const h2=s.hp;const z=d.Z.line(s.x,s.y+80,-Math.PI/2,200,22);d.spwHitZone(z,50,'lance');const h3=s.hp;return {h0,h1,h2,h3};});
 ok(a.h1<a.h0&&a.h2<a.h1&&a.h3<a.h2,'sword arc, quake and lance line all damage it ('+[a.h0,a.h1,a.h2,a.h3].join('>')+')');
 await E(()=>{const g=__game,d=g.dbg,s=d.SPW[0];s.hp=s.maxhp;const e=g.enemies.find(o=>o.alive&&!o.spw&&!o.def.boss);e.x=s.x+60;e.y=s.y+40;g.P.x=s.x+10;g.P.y=s.y+60;g.P.grace=0;d.startEncounter(e,true);});await sleep(400);
 await E(()=>{const g=__game,d=g.dbg,s=d.SPW[0];g.B.shots.push({x:s.x-30,y:s.y-16,vx:300,vy:0,r:5,dmg:30,own:'p',kind:'arcane',life:1,a:0});});await sleep(250);
 a=await E(()=>{const d=__game.dbg,s=d.SPW[0];return {hp:s.hp,max:s.maxhp,B:!!__game.B};});ok(a.B&&a.hp<a.max,'player shots in a battle hit the spawner too ('+a.hp+'/'+a.max+')');
 await E(()=>{__game.dbg.endFight();__game.P.grace=9999;});
 // destroy it: reward, rubble, achievement counter, remembered in the save
 a=await E(()=>{const g=__game,d=g.dbg,s=d.SPW[0];s.hp=s.maxhp;const gold0=g.P.gold,xp0=g.P.xp,lv0=g.P.lv,spw0=d.ACH.s.spw|0,sh0=d.matCount('shard');d.hurtSpawner(s,99999,'sword');
   return {dying:s.dying,gold:g.P.gold-gold0,xp:(g.P.xp+g.P.lv*1000)-(xp0+lv0*1000),spw:(d.ACH.s.spw|0)-spw0,shard:d.matCount('shard')-sh0,live:d.spwLive(s)};});
 ok(a.dying&&!a.live&&a.gold>=60&&a.xp>0&&a.spw===1&&a.shard>=1,'destroying it pays gold ('+a.gold+'), XP, crafting parts and counts ('+JSON.stringify(a)+')');
 await sleep(1400);await E(()=>{__game.dbg.toasts.length=0;});
 a=await E(()=>{const d=__game.dbg,s=d.SPW[0];return {alive:s.alive,left:s.left>0,walk:!(()=>{const P=__game.P;P.x=s.x;P.y=s.y;return false;})()};});
 ok(a.alive===false&&a.left,'a destroyed spawner leaves rubble and a re-kindle timer');
 a=await E(()=>{const g=__game,d=g.dbg;d.saveNow();const s=g.readSave();const keys=Object.keys(s.spw||{});d.resetSpawners();const back=d.SPW[0].alive;g.loadSave(s);return {keys,back,after:d.SPW[0].alive,other:d.SPW[1].alive};});
 ok(a.keys.includes('sp_forest1')&&a.back===true&&a.after===false&&a.other===true,'destroyed spawners are saved and stay destroyed after loading');
 await E(()=>{const d=__game.dbg,s=d.SPW[0];s.left=.1;});await sleep(500);
 a=await E(()=>({alive:__game.dbg.SPW[0].alive,hp:__game.dbg.SPW[0].hp===__game.dbg.SPW[0].maxhp}));ok(a.alive&&a.hp,'after the timer it re-kindles at full health');
 // screenshot of a spawner with a few summoned monsters (NPC-free forest clearing)
 await E(()=>{const g=__game,d=g.dbg;d.resetSpawners();d.toasts.length=0;g.state='play';g.DLG=null;const s=d.SPW[0];g.tp(Math.floor(s.x/32),Math.floor(s.y/32)+3);for(const e of g.enemies)if(!e.spw&&e.alive)e.alive=false;g.P.grace=9999;d.SPW.forEach(q=>q.t=.05);});
 await sleep(500);for(let i=0;i<12;i++){await E(()=>{__game.dbg.SPW[0].t=0;});await sleep(120);}
 await E(()=>{const d=__game.dbg,s=d.SPW[0];s.hp=Math.round(s.maxhp*.6);d.toasts.length=0;d.hurtSpawner(s,10,'arcane');});await sleep(700);await E(()=>{const d=__game.dbg;d.TRK&&(d.TRK.open=false);});await shot('monster-spawner.png');
 // other zones' spawners summon their own kinds (swamp, ruins, crypt) - check by calling the summoner next to the player
 a=await E(()=>{const g=__game,d=g.dbg,res={};for(const i of [2,4,6]){const s=d.SPW[i];g.tp(Math.floor(s.x/32),Math.floor(s.y/32)+3);g.P.grace=9999;s.t=0;for(let k=0;k<30;k++){d.updateSpawners(.25);}res[s.id]=d.spwMinions(s).map(e=>e.type);}return res;});
 ok(Object.values(a).every(l=>l.length>=1),'swamp, ruins and crypt spawners summon their own monsters '+JSON.stringify(a));
 // new game resets all of it
 a=await E(()=>{const d=__game.dbg;d.SPW[3].alive=false;d.SPW[3].left=100;d.resetSpawners();d.FSH.rod=2;d.resetFish();return {sp:d.SPW[3].alive,rod:d.FSH.rod};});ok(a.sp&&a.rod===-1,'a new game resets spawners and fishing');
 ok(errs.length===0,'no page errors ('+errs.join(' | ')+')');
 await finish();
})();
