// M40: Fishing Lab (title menu): 5 prototype fishing mechanics, isolated from the main game's fishing + save, slow relaxed pacing.  node tests/ms40.js [desktop|mobile]
if(process.argv[2]==='mobile')process.argv[2]='mobile';
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms40',{stayTitle:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;});
 // seed a real save so we can prove the lab never touches it
 await E(()=>{const g=__game;g.titleMenu.items.length=0;});
 const items=await E(()=>{__game.dbg.initTitleMenu();return __game.titleMenu.items.slice();});
 ok(items.includes('Fishing Lab')&&items[items.length-1]==='Fishing Lab','title menu has a Fishing Lab option ('+items+')');
 await E(()=>{localStorage.setItem('arcaneKnight.save.v1',JSON.stringify({v:1,t:1,P:{x:100,y:100,dir:'d',hp:50,lv:7,xp:0,gold:321,up:0}}));__game.dbg.initTitleMenu();});
 const before=await E(()=>localStorage.getItem('arcaneKnight.save.v1'));
 await E(()=>{const t=__game.titleMenu;t.sel=t.items.indexOf('Fishing Lab');});
 await sleep(1500);await shot('fishlab-title.png');
 // enter by tapping the item
 const pos=await E(()=>{const t=__game.titleMenu,r=t.rects[t.items.indexOf('Fishing Lab')],c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};});
 if(MOB)await pg.touchscreen.tap(pos.x,pos.y);else await pg.mouse.click(pos.x,pos.y);
 await sleep(400);
 ok(await E(()=>__game.state==='fishlab'),'tapping Fishing Lab opens it');

 // drive the lab through its own exports
 const api=(f,...a)=>E(f,...a);
 // ---- pacing config is relaxed
 const cfg=await E(()=>{const c=__game.dbg.FL.cfg;return JSON.parse(JSON.stringify(c));});
 ok(cfg.iCatch[0]>=8&&cfg.iCatch[1]<=15,'idle catch interval is ~8-15s ('+cfg.iCatch+')');
 ok(cfg.iBiteWin>=4,'rare bite window is ~4s');
 ok(cfg.tSpeed<=.5&&cfg.hBanner>=1,'needle sweep is slow');
 ok(cfg.sSpeed[1]<=22,'shadows drift slowly');
 for(let i=0;i<5;i++){await E(i=>{__game.dbg.flSetMode(i);},i);await sleep(120);await shot('fishlab-mode'+(i+1)+'-start.png');}
 // ---- 1 timing
 await E(()=>{const d=__game.dbg;d.FL.rng=()=>.5;d.flSetMode(0);d.flAct({x:0,y:0});});
 await E(()=>{const d=__game.dbg;for(let i=0;i<400&&d.FL.m.ph!=='game';i++)d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.m.ph==='game'&&__game.dbg.FL.m.g.k==='timing'),'timing: a bite starts the timing bar');
 const z=await E(()=>{const g=__game.dbg.FL.m.g;return {zw:g.zw,rar:g.rar};});
 await shot('fishlab-timing.png');
 await E(()=>{const g=__game.dbg.FL.m.g;g.pos=g.zc;__game.dbg.flAct(null);__game.dbg.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.stats[0].n===1),'timing: tapping inside the green zone catches the fish');
 ok(await E(()=>{const d=__game.dbg;const a=d.flTimingNew(0).zw,b=d.flTimingNew(4).zw;return a>b&&b>.08;}),'timing: rarer fish = smaller zone');
 await E(()=>{const d=__game.dbg;for(let i=0;i<100;i++)d.flUpdate(.05);d.flAct(null);for(let i=0;i<400&&d.FL.m.ph!=='game';i++)d.flUpdate(.05);const g=d.FL.m.g;g.pos=Math.min(1,g.zc+g.zw);if(Math.abs(g.pos-g.zc)<=g.zw/2)g.pos=0;d.flAct(null);d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.stats[0].esc===1),'timing: a miss lets it escape');
 // ---- 2 tug
 await E(()=>{const d=__game.dbg;d.flSetMode(1);d.flAct({x:0,y:0});for(let i=0;i<400&&d.FL.m.ph!=='game';i++)d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.m.g&&__game.dbg.FL.m.g.k==='tug'),'tug: a bite starts the tug of war');
 await E(()=>{__game.dbg.FL.down=true;for(let i=0;i<20;i++)__game.dbg.flUpdate(.05);});await shot('fishlab-tug.png');
 const tg=await E(()=>{const g=__game.dbg.FL.m.g;return {ten:g.ten,prog:g.prog};});
 ok(tg.ten>.3&&tg.ten<.9&&tg.prog>.2,'tug: holding raises tension gently and reels in ('+JSON.stringify(tg)+')');
 await E(()=>{for(let i=0;i<300&&!__game.dbg.FL.m.g.done;i++)__game.dbg.flUpdate(.05);});    // keep holding: the line snaps
 ok(await E(()=>__game.dbg.FL.m.g.done==='lose'&&/SNAP/.test(__game.dbg.FL.m.g.why)),'tug: line snaps at max tension');
 await E(()=>{const d=__game.dbg;d.FL.down=false;d.flSetMode(1);d.flAct({x:0,y:0});for(let i=0;i<400&&d.FL.m.ph!=='game';i++)d.flUpdate(.05);d.FL.m.g.surgeT=999;for(let i=0;i<140;i++)d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.m.g.done==='lose'&&/slack/i.test(__game.dbg.FL.m.g.why)),'tug: staying slack too long lets the fish escape');
 await E(()=>{const d=__game.dbg;d.flSetMode(1);d.flAct({x:0,y:0});for(let i=0;i<400&&d.FL.m.ph!=='game';i++)d.flUpdate(.05);const g=d.FL.m.g;g.surgeT=999;let h=true;for(let i=0;i<1200&&!g.done;i++){h=g.ten<.55?true:g.ten>.7?false:h;d.FL.down=h;d.flUpdate(.05);}d.FL.down=false;});
 ok(await E(()=>__game.dbg.FL.stats[1].n===1),'tug: pulsing hold/release lands the fish');
 // ---- 3 idle: nothing pressed, catches arrive on their own
 await E(()=>{const d=__game.dbg;d.FL.rng=Math.random;d.flSetMode(2);d.flAct({x:0,y:0});for(let i=0;i<20;i++)d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.m.ph==='on'),'idle: cast once and it keeps fishing');
 await E(()=>{const d=__game.dbg;d.FL.m.rare=1e9;for(let i=0;i<2400;i++)d.flUpdate(.05);});     // 120s of doing nothing
 const idle=await E(()=>__game.dbg.FL.stats[2].n);
 ok(idle>=7&&idle<=16,'idle: ~1 catch per 8-15s while the player does nothing ('+idle+' in 120s)');
 await E(()=>{const d=__game.dbg;d.FL.m.rare=.1;for(let i=0;i<5;i++)d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.m.ph==='rare'),'idle: a Rare bite prompt appears');
 await shot('fishlab-idle-rare.png');
 const n0=await E(()=>__game.dbg.FL.stats[2].n);
 await E(()=>{const d=__game.dbg;for(let i=0;i<60;i++)d.flUpdate(.05);d.flAct({x:0,y:0});});    // 3s later still catchable
 ok(await E(n0=>__game.dbg.FL.stats[2].n===n0+1&&__game.dbg.FL.stats[2].by.slice(2).some(x=>x>0),n0),'idle: tapping within the generous window lands a rare fish');
 await E(()=>{const d=__game.dbg;d.FL.m.rare=.1;for(let i=0;i<5;i++)d.flUpdate(.05);for(let i=0;i<100;i++)d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.m.ph==='on'&&__game.dbg.FL.stats[2].esc>=1),'idle: ignoring the rare bite lets it go (and fishing continues)');
 await shot('fishlab-idle.png');
 // ---- 4 shadows
 await E(()=>{const d=__game.dbg;d.flSetMode(3);for(let i=0;i<40;i++)d.flUpdate(.05);});
 const sh=await E(()=>{const d=__game.dbg,m=d.FL.m;return {n:m.sh.length,big:m.sh.reduce((a,s)=>Math.max(a,s.r),0),small:m.sh.reduce((a,s)=>Math.min(a,s.r),99),rars:m.sh.map(s=>s.rar)};});
 ok(sh.n>=5&&sh.big>=sh.small,'shadows: several swim in the pond; size follows rarity ('+JSON.stringify(sh)+')');
 await shot('fishlab-shadow.png');
 await E(()=>{const d=__game.dbg,g=d.flGeom(),s=d.FL.m.sh[0];d.flAct({x:g.pond.x+s.x,y:g.pond.y+s.y});});
 ok(await E(()=>__game.dbg.FL.m.ph==='cast'&&!!__game.dbg.FL.m.tgt),'shadows: tapping a shadow casts at it');
 await E(()=>{const d=__game.dbg;d.FL.rng=()=>.99;for(let i=0;i<140;i++)d.flUpdate(.05);});
 ok(await E(()=>__game.dbg.FL.stats[3].n===1),'shadows: short wait then the fish is caught');
 // ---- 5 hybrid
 await E(()=>{const d=__game.dbg;d.FL.rng=Math.random;d.flSetMode(4);d.flAct({x:0,y:0});for(let i=0;i<20;i++)d.flUpdate(.05);});
 await E(()=>{const d=__game.dbg;d.FL.m.rare=1e9;for(let i=0;i<1200;i++)d.flUpdate(.05);});
 const hy=await E(()=>__game.dbg.FL.stats[4]);
 ok(hy.n>=3&&hy.by[2]+hy.by[3]+hy.by[4]===0,'hybrid: common fish arrive on their own ('+hy.n+' in 60s)');
 for(const kind of ['timing','tug']){
   await E(k=>{const d=__game.dbg;d.FL.rng=()=>k==='timing'?.1:.9;d.FL.m.rare=.1;for(let i=0;i<4;i++)d.flUpdate(.05);},kind);
   ok(await E(()=>__game.dbg.FL.m.ph==='banner'),'hybrid: a rare bite shows the banner first ('+kind+')');
   await E(()=>{const d=__game.dbg;for(let i=0;i<30&&d.FL.m.ph!=='game';i++)d.flUpdate(.05);});
   ok(await E(k=>__game.dbg.FL.m.g.k===k,kind),'hybrid: the rare bite launches a quick '+kind+' game');
   await shot('fishlab-hybrid-'+kind+'.png');
   if(kind==='timing')await E(()=>{const g=__game.dbg.FL.m.g;g.pos=g.zc;__game.dbg.flAct(null);});
   else await E(()=>{const d=__game.dbg,g=d.FL.m.g;g.surgeT=999;g.prog=.995;d.FL.down=true;d.flUpdate(.1);d.FL.down=false;});
   await E(()=>{const d=__game.dbg;for(let i=0;i<40;i++)d.flUpdate(.05);});
 }
 ok(await E(()=>__game.dbg.FL.stats[4].by[2]+__game.dbg.FL.stats[4].by[3]+__game.dbg.FL.stats[4].by[4]===2),'hybrid: winning both minigames landed 2 rare+ fish');
 // ---- real pointer input: tabs + back
 const tabPos=await E(i=>{const g=__game.dbg.flGeom(),r=g.tabs[i],c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},2);
 if(MOB)await pg.touchscreen.tap(tabPos.x,tabPos.y);else await pg.mouse.click(tabPos.x,tabPos.y);await sleep(200);
 ok(await E(()=>__game.dbg.FL.mode===2),'tapping a tab switches mode');
 // ---- isolation
 await E(()=>{window.dispatchEvent(new Event('pagehide'));});
 ok(await E(b=>localStorage.getItem('arcaneKnight.save.v1')===b,before),'the lab never touches the save (pagehide inside the lab does not save)');
 ok(await E(()=>JSON.stringify(__game.dbg.FISH).length>0&&!__game.dbg.FISH.on),'main-game fishing state untouched');
 const bp=await E(()=>{const g=__game.dbg.flGeom(),r=g.back,c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};});
 if(MOB)await pg.touchscreen.tap(bp.x,bp.y);else await pg.mouse.click(bp.x,bp.y);await sleep(300);
 ok(await E(()=>__game.state==='title'&&__game.titleMenu.items[__game.titleMenu.sel]==='Fishing Lab'),'Back returns to the title menu');
 // Continue still works afterwards
 await E(()=>{const t=__game.titleMenu;t.sel=0;});await E(()=>{__game.press('Space');});await sleep(400);
 ok(await E(()=>__game.state==='play'&&__game.P.lv===7),'Continue still loads the untouched save afterwards');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
