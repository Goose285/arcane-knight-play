// M16: quest tracker HUD (TRACK button, auto-track, collapsible panel, flash, arrow, text size).  node tests/ms16.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE,tap}=await boot('ms16');
 await E(()=>{window.__NOACH=true;window.__NOMETA=true;window.__NOTUT=true;__game.dbg.tutFinish(true);__game.dbg.toasts.length=0;});   // (explicit: do not rely on the preload hook)
 const calm=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.UI.mode=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.P.grace=99;g.P.hp=d.maxHp();});
 const fresh=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.UI.mode=null;d.QS.st={};d.QS.n={};d.QS.items={};d.QS.ord=[];d.TRK.id=null;d.TRK.open=true;d.TRK.sig=null;d.TRK.flash=0;d.TRK.done=null;d.STORY.ch=0;d.DAILY.ch=[];d.SET.text=1;d.setApply&&d.setApply();g.tp(13,38);g.P.grace=99;});
 const rect=()=>E(()=>{const r=__game.dbg.TRK.rect;return r&&{x:r.x,y:r.y,w:r.w,h:r.h};});
 const ent=()=>E(()=>__game.dbg.trkEntries().map(e=>({id:e.id,kind:e.kind,name:e.name,obj:e.obj,prog:e.prog,need:e.need,short:e.short,ready:e.ready,step:e.step,steps:e.steps})));

 // ===== data: story / villager quest / daily entries =====
 await fresh();await sleep(250);
 let es=await ent();
 ok(es.length===1&&es[0].kind==='story'&&es[0].step===1&&es[0].steps===5,'only the story chapter at the start: step 1/5');
 ok(await E(()=>__game.dbg.TRK.id==='s'),'story chapter is tracked when nothing else is');
 await E(()=>{__game.dbg.STORY.ch=1;});await sleep(200);es=await ent();ok(es[0].step===2&&/Sleepless/.test(es[0].name),'story chapter 2: step 2/5 and its name');
 await E(()=>{__game.dbg.STORY.ch=0;});

 // ===== auto-track the newest quest, do not steal tracking afterwards =====
 await E(()=>{const d=__game.dbg;d.questStart('slimes');});await sleep(200);
 ok(await E(()=>__game.dbg.TRK.id==='q:slimes'),'starting a quest with nothing tracked auto-tracks it (story does not count as "tracked" once a quest exists)');
 await E(()=>{const d=__game.dbg;d.questStart('gel');});await sleep(200);
 ok(await E(()=>__game.dbg.TRK.id==='q:slimes'),'a second quest does not steal the tracker');
 es=await ent();
 const sl=es.find(e=>e.id==='q:slimes'),gl=es.find(e=>e.id==='q:gel');
 ok(sl&&sl.prog===0&&sl.need===3&&/Gooey Slime/.test(sl.short)&&/Defeat 3/.test(sl.obj),'kill quest: "Defeat 3 Gooey Slimes", progress 0/3');
 ok(gl&&gl.short==='Slime Gel'&&gl.need===3,'collect quest: Slime Gel 0/3');

 // ===== live progress + flash =====
 await E(()=>{const d=__game.dbg;d.TRK.flash=0;});await sleep(150);
 await E(()=>{__game.dbg.questEvent('kill','slime');});await sleep(250);
 ok(await E(()=>__game.dbg.TRK.flash>0&&__game.dbg.TRK.fk==='prog'),'panel flashes when progress changes');
 es=await ent();ok(es.find(e=>e.id==='q:slimes').prog===1,'progress updated live (1/3)');
 let r=await rect();ok(!!r,'tracker panel is on screen in the world');
 // ===== layout: not over the minimap or the touch controls =====
 const lay=await E(()=>{const g=__game,d=g.dbg,z=g.size,r=d.TRK.rect;return {r,VW:z.VW,VH:z.VH,SL:z.SL||0,SR:z.SR||0};});
 ok(lay.r.x>=0&&lay.r.x+lay.r.w<=lay.VW-(lay.SR||0)-8-128-2,'panel stays left of the minimap');
 console.log('  layout',JSON.stringify(lay));ok(lay.r.y+lay.r.h<lay.VH*(MOBILE?.45:.75),'panel sits in the top area, well above the joystick / SHOT button');
 // ===== collapse by tapping =====
 const hOpen=r.h;
 const click=async()=>{const p=await E(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,r=__game.dbg.TRK.rect;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};});
   if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(250);};
 await click();r=await rect();ok(r&&r.h<hOpen*.6&&await E(()=>!__game.dbg.TRK.open),'tapping the panel collapses it ('+hOpen+' -> '+(r&&r.h)+')');
 await click();r=await rect();ok(r&&r.h===hOpen&&await E(()=>__game.dbg.TRK.open),'tapping again expands it');
 ok(await E(()=>!__game.B&&!__game.state.startsWith('x')),'tapping the tracker does not shoot or move');
 // ===== arrow target =====
 const tg=await E(()=>{const g=__game,d=g.dbg,en=d.trkEntries().find(e=>e.id==='q:slimes'),t=d.trkTarget(en);return t&&{x:t.x,y:t.y};});
 ok(!!tg,'kill quest has a target position (nearest slime)');
 // ===== quest log: TRACK button =====
 await E(()=>{__game.dbg.openQuests();});await sleep(300);
 ok(await tap('track:q:gel',null),'quest log: TRACK button for the second quest');await sleep(200);
 ok(await E(()=>__game.dbg.TRK.id==='q:gel'),'TRACK switches the tracked quest');
 ok(await E(()=>{const t=__game.dbg.UI.rects.find(r=>r.tag==='track:q:gel');return !!t;}),'button stays listed (shows TRACKING)');
 await shot('quest-log-track.png');
 ok(await tap('track:s',null),'quest log: the story chapter has a TRACK button too');await sleep(150);ok(await E(()=>__game.dbg.TRK.id==='s'),'story chapter can be tracked');
 await E(()=>{const d=__game.dbg;d.UI.mode=null;__game.state='play';d.trackQuest('q:slimes');});await sleep(250);
 // ===== hidden when it should be =====
 await E(()=>{__game.DLG={name:'X',lines:['hi'],i:0,c:0};});await sleep(150);ok((await rect())!==null,'stays up during an ordinary dialogue (it only hides for full-screen cutscenes)');await E(()=>{__game.DLG=null;});
 await E(()=>{__game.state='paused';});await sleep(150);ok((await rect())===null,'hidden while paused');await E(()=>{__game.state='play';});
 await sleep(150);ok(!!(await rect()),'returns after');

 // ===== ready / complete flash, then next quest =====
 await E(()=>{const d=__game.dbg;d.TRK.flash=0;d.questEvent('kill','slime');d.questEvent('kill','slime');});await sleep(300);
 es=await ent();const rd=es.find(e=>e.id==='q:slimes');
 ok(rd&&rd.ready&&/Return to Elder Orin/.test(rd.obj),'finished objective: tracker says "Return to Elder Orin"');
 ok(await E(()=>__game.dbg.TRK.fk==='ready'),'ready state flashes green');
 const ar=await E(()=>{const d=__game.dbg,en=d.trkEntries().find(e=>e.id==='q:slimes'),t=d.trkTarget(en),n=__game.npcs.find(x=>x.name==='Elder Orin');return t&&Math.abs(t.x-n.x)<1&&Math.abs(t.y-n.y)<1;});
 ok(ar,'arrow points at the quest giver when ready');
 await E(()=>{__game.dbg.questComplete('slimes');});await sleep(300);
 ok(await E(()=>!!__game.dbg.TRK.done),'completing the tracked quest shows a QUEST COMPLETE flash');
 await shot('quest-tracker-complete.png');
 await sleep(3000);
 ok(await E(()=>!__game.dbg.TRK.done&&__game.dbg.TRK.id==='q:gel'),'afterwards the next quest is tracked automatically');

 // ===== dailies =====
 await E(()=>{window.__NOMETA=false;const d=__game.dbg;d.DAILY.ch=d.dailyRoll(d.dayNum());d.DAILY.day=d.dayNum();});await sleep(150);
 es=await ent();const dl=es.filter(e=>e.kind==='daily');
 ok(dl.length===3&&dl.every(e=>e.need>0&&e.obj.length>3),'three daily challenges are listed with objectives');
 await E(()=>{__game.dbg.trackQuest('d:0');});await sleep(200);
 ok(await E(()=>__game.dbg.TRK.id==='d:0'),'a daily can be tracked');
 await E(()=>{const c=__game.dbg.DAILY.ch[0];c.p=c.n;c.done=true;});await sleep(250);
 ok(await E(()=>__game.dbg.TRK.flash>0&&__game.dbg.TRK.fk==='ready'),'daily completion flashes');
 await E(()=>{window.__NOMETA=true;__game.dbg.DAILY.ch=[];});await sleep(250);
 ok(await E(()=>__game.dbg.TRK.id!=='d:0'),'a vanished daily falls back to another tracked entry');

 // ===== text size =====
 await E(()=>{const d=__game.dbg;d.trackQuest('q:gel');d.SET.text=1;d.setApply();});await sleep(250);const t1=await rect();
 await E(()=>{const d=__game.dbg;d.SET.text=2;d.setApply();});await sleep(250);const t2=await rect();
 ok(t1&&t2&&t2.h>t1.h&&t2.w===t1.w,'bigger text setting makes the panel taller, same width ('+t1.h+' -> '+t2.h+')');
 const fit=await E(()=>{const z=__game.size,r=__game.dbg.TRK.rect;return r.x+r.w<=z.VW-8-128-2&&r.y+r.h<z.VH*.5;});ok(fit,'still clear of the minimap / controls at the largest text size');
 await E(()=>{const d=__game.dbg;d.SET.text=1;d.setApply();});

 // ===== save / load =====
 const sv=await E(()=>{const g=__game,d=g.dbg,o={};d.trackQuest('q:gel');d.TRK.open=false;g.saveGame('t');const s=g.readSave();o.saved=!!s.quests&&s.quests.trk&&s.quests.trk.id==='q:gel'&&s.quests.trk.open===false&&s.quests.ord.includes('gel');
   d.TRK.id=null;d.TRK.open=true;d.QS.ord=[];g.loadSave(s);o.loaded=d.TRK.id==='q:gel'&&d.TRK.open===true&&d.QS.ord.includes('gel');d.TRK.open=true;return o;});
 ok(sv.saved&&sv.loaded,'tracked quest is saved and restored (always loads expanded)');
 // ===== not shown in battle =====
 await calm();await E(()=>{const g=__game,d=g.dbg,e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.engaged=false;g.P.x=e.x-60;g.P.y=e.y+2;d.startEncounter(e,true);g.B.phase='fight';});await sleep(300);
 {const r=await rect();ok(r!==null&&r.h<40,'tracker stays up during battle as a compact one-line chip');const gb=await E(()=>__game.dbg.COMBAT_HUD_BOT());ok(r&&r.y>=gb,'...below the spell gauge / combat HUD, not on top of it');}
 await E(()=>{__game.dbg.endFight();});await sleep(300);

 // ===== screenshot =====
 await fresh();
 await E(()=>{const g=__game,d=g.dbg;d.enemies&&0;d.questStart('slimes');d.questEvent('kill','slime');d.TRK.flash=0;d.toasts.length=0;g.state='play';
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.x=e.hx=g.P.x+150;e.y=e.hy=g.P.y-40;e.mt=1e9;e.lk=1e9;});await sleep(500);
 await shot('quest-tracker.png');
 await finish();
})().catch(e=>{console.error(e);process.exit(1);});
