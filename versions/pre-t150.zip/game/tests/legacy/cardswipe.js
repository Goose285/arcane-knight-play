// Card swipe gesture: press a card + swipe up casts THAT card auto-aimed at the nearest enemy (iPhone touch + desktop mouse drag); tap still casts as before
const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let fails=0;const ok=(c,m)=>{if(!c){fails++;console.log('  FAIL:',m);}else console.log('  ok  ',m);};
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);
 pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(400);await pg.touchscreen.tap(200,400);await sleep(300);
 const cardXY=i=>pg.evaluate(i=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,r=__game.cardRects[i];
   return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height,k:c.width/z.VW};},i);
 const setup=async(o={})=>{await pg.evaluate((o)=>{const g=__game,d=g.dbg;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   const kn=g.enemies.filter(x=>x.type==='knight'),sl=g.enemies.filter(x=>x.type==='slime');
   const near=kn[0],far=sl[0];near.x=5*32+16;near.y=38*32+28;far.x=7*32+16;far.y=33.5*32+28;[near,far].forEach(e=>{e.hx=e.x;e.hy=e.y;});
   g.P.x=10*32+16;g.P.y=38*32+28;g.P.grace=99;g.P.hp=1e6;g.tp(10,38);g.P.x=10*32+16;g.P.y=38*32+28;g.P.aim=0;g.P.dir='r';   // facing AWAY from the enemies
   d.startEncounter(near,true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;});B.hand=o.hand||['frostbolt','sword','lance','fire','crimsonbolt'];B.sel=0;
   window.__shots=new Set();window.__iv&&clearInterval(window.__iv);window.__iv=setInterval(()=>{if(g.B)g.B.shots.forEach(s=>{if(s.own==='p')window.__shots.add(s.kind);});},8);
   window.__near=near;if(o.noEnemy)B.ens.forEach(e=>{e.dying=true;});},o);await sleep(150);};
 const st=()=>pg.evaluate(()=>({hand:__game.B?__game.B.hand.slice():null,sel:__game.B&&__game.B.sel,aim:__game.P.aim,shots:[...__shots],dmg:5000-__near.hp}));
 // 1. swipe up on card #2 (lance): casts the lance (not the selected card #0) toward the nearest enemy, even though the hero faces away
 await setup();let c=await cardXY(2);
 let th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(60);await th.move(c.x,c.y-20*c.k);await sleep(80);ok(await pg.evaluate(()=>__game.B.hand[2])==='lance','swipe: card is NOT cast on press / short drag (still in hand mid-swipe)');
 await pg.screenshot({path:'/workspace/arcane-knight/store/card-swipe.png'});      // aim line + arrows while swiping
 await th.move(c.x,c.y-70*c.k);await sleep(60);
 let s=await st();ok(s.hand[2]===null,'swipe: pressed card (lance) was cast');ok(s.hand[0]==='frostbolt','swipe: other cards untouched');
 ok(Math.abs(Math.abs(s.aim)-Math.PI)<.5,'swipe: aimed at the nearest enemy behind the hero (aim '+Math.round(s.aim*57.3)+'deg)');
 await th.end();await sleep(600);s=await st();ok(s.shots.includes('lance')||s.dmg>0,'swipe: the cast hit/fired (shots '+s.shots+', dmg '+s.dmg+')');
 // 2. plain tap on a card still selects + casts it
 await setup();c=await cardXY(1);await pg.touchscreen.tap(c.x,c.y);await sleep(300);s=await st();
 ok(s.hand[1]===null&&s.hand[0]==='frostbolt','tap: still casts the tapped card');
 // 3. no enemy -> cast in the facing direction
 await setup({noEnemy:true,hand:['lance','fire','haste','sword','frostbolt']});await pg.evaluate(()=>{__game.P.aim=0;__game.P.dir='r';});c=await cardXY(2);
 th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(50);await th.move(c.x,c.y-30*c.k);await th.move(c.x,c.y-70*c.k);await sleep(50);s=await st();
 ok(s.hand[2]===null,'no enemy: card cast anyway');ok(Math.abs(s.aim)<.5,'no enemy: cast along facing direction (aim '+Math.round(s.aim*57.3)+'deg)');await th.end();await sleep(200);
 // 4. existing hold-SHOT + swipe up still casts the highlighted card at the nearest enemy
 await setup();const bt=await pg.evaluate(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,b=__game.btn.atk;return {x:c.left+b.x/z.VW*c.width,y:c.top+b.y/z.VH*c.height,k:c.width/z.VW};});
 th=await pg.touchscreen.touchStart(bt.x,bt.y);await sleep(60);await th.move(bt.x,bt.y-30*bt.k);await th.move(bt.x,bt.y-70*bt.k);await sleep(100);s=await st();
 ok(s.hand[0]===null,'SHOT+swipe: still casts the highlighted card');await th.end();await sleep(300);
 // 5. desktop mouse drag on a card
 const pg2=await b.newPage();await pg2.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg2.setViewport({width:960,height:640});pg2.on('pageerror',e=>errs.push(e.message));
 await pg2.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(400);await pg2.evaluate(()=>{__game.state='play';});
 await pg2.evaluate(()=>{const g=__game,d=g.dbg;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(x=>x.type==='knight');e.x=5*32+16;e.y=38*32+28;e.hx=e.x;e.hy=e.y;g.tp(10,38);g.P.grace=99;g.P.hp=1e6;g.P.aim=0;g.P.dir='r';
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;o.hp=o.maxhp=5000;});B.hand=['frostbolt','sword','lance','fire','crimsonbolt'];B.sel=0;});await sleep(150);
 const m=await pg2.evaluate(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,r=__game.cardRects[3];return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height,k:c.width/z.VW};});
 await pg2.mouse.move(m.x,m.y);await pg2.mouse.down();await pg2.mouse.move(m.x,m.y-25*m.k,{steps:4});await pg2.mouse.move(m.x,m.y-70*m.k,{steps:6});await sleep(100);
 const h=await pg2.evaluate(()=>({hand:__game.B.hand.slice(),aim:__game.P.aim}));await pg2.mouse.up();
 ok(h.hand[3]===null&&h.hand[0]==='frostbolt','mouse drag up on a card casts that card');ok(Math.abs(Math.abs(h.aim)-Math.PI)<.5,'mouse drag: auto-aimed at the enemy');
 console.log('ERRORS',errs);await b.close();process.exit(fails||errs.length?1:0);
})();
