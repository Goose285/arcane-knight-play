const puppeteer=require('puppeteer-core');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg.setViewport({width:1280,height:720});
 const errs=[];pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(500);
 await pg.keyboard.press('Space');await sleep(300);
 // helper: park all enemies far away, freeze one enemy as the subject
 const setup=(type,ex,ey,fa,px,py,pdirAim)=>pg.evaluate((type,ex,ey,fa,px,py,aim)=>{
   const g=__game;g.enemies.forEach(e=>{e.alive=true;e.x=e.hx=e.hx;});
   g.enemies.forEach(e=>{e.fa=0;e.mode='look';e.mt=1e9;e.lk=1e9;e.ta=e.fa;});
   const e=g.enemies.find(o=>o.type===type);
   // move everything else out of the way (teleport far off-screen but keep alive)
   g.enemies.forEach(o=>{if(o!==e){o.x=60*32;o.y=2*32;}});
   e.x=ex*32+16;e.y=ey*32+28;e.fa=fa;e.ta=fa;e.mode='look';e.mt=1e9;e.lk=1e9;
   g.P.x=px*32+16;g.P.y=py*32+28;g.P.grace=0;g.P.aim=aim;g.tp(px,py);g.P.x=px*32+16;g.P.y=py*32+28;
   return {ex:e.x,ey:e.y};
 },type,ex,ey,fa,px,py,pdirAim);
 const inB=()=>pg.evaluate(()=>!!__game.B);
 const res={};
 // 1. in cone: knight at (20,20) facing east(0), player at (24,20) -> 128px, within 170 -> should trigger
 await setup('knight',8,38,0,12,38,Math.PI);
 await sleep(500);res.inCone=await inB();
 await pg.evaluate(()=>{__game.B=null;});
 // cleanup: end battle by disengage via direct: reload not possible; re-navigate
 await pg.reload();await sleep(500);await pg.keyboard.press('Space');await sleep(300);
 // 2. behind: knight facing west (PI), player east of it (behind) at same distance -> must NOT trigger
 await setup('knight',8,38,Math.PI,12,38,Math.PI);
 await sleep(2500);res.behindSneak=await inB();
 // 2b. out of range in front: player 220px in front of knight (range 170)
 await setup('knight',8,38,0,15,38,Math.PI);await sleep(1200);res.outOfRangeFront=await inB();
 // 2c. wall blocks: goblin north of village house facing south, player south of the house wall
 await setup('goblin',6,28,Math.PI/2,6,34,-Math.PI/2);await sleep(1500);res.wallBlocked=await inB();
 // 2d. same geometry w/out wall (player beside, in cone) -> triggers
 await setup('goblin',10,26,Math.PI/2,10,29,-Math.PI/2);await sleep(1000);res.noWallTriggers=await inB();
 await pg.reload();await sleep(500);await pg.keyboard.press('Space');await sleep(300);
 // 3. shoot an enemy from behind: knight facing west, player behind facing it, press J
 await setup('knight',8,38,Math.PI,12,38,Math.PI);
 await sleep(300);
 await pg.keyboard.down('KeyJ');await sleep(120);await pg.keyboard.up('KeyJ');
 let tries=0;while(!(await inB())&&tries++<20)await sleep(60);
 res.shotStartsFight=await inB();
 res.shotHp=await pg.evaluate(()=>__game.B&&[__game.B.ens[0].hp,__game.B.ens[0].maxhp,__game.B.phase]);
 console.log(JSON.stringify(res));
 console.log(errs);
 await b.close();
})();
