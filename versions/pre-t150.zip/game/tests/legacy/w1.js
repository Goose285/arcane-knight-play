const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const mode=process.argv[2]||'desk';
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];
 const fresh=async()=>{const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});
  if(mode==='mob')await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);else await pg.setViewport({width:1280,height:720});
  pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
  await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(400);
  if(mode==='mob')await pg.touchscreen.tap(200,400);else await pg.keyboard.press('Space');await sleep(300);
  await pg.evaluate(()=>{window.park=()=>__game.enemies.forEach(e=>{e.alive=true;e.engaged=false;e.fa=0;e.mode='look';e.mt=1e9;e.lk=1e9;e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;});});
  return pg;};
 const res={};
 // ---------- 1. attacks through walls
 const scen=[
  ['topWall',[30,2],[30,0],['goblin','knight','dragon','slime']],
  ['castleSouth',[22,10],[22,12],['goblin','knight','dragon','slime']],
  ['house',[5,28],[5,34],['goblin','dragon','slime']],
  ['fountain',[13,34],[18,34],['goblin','dragon','slime']],
  ['CONTROL_open',[8,38],[11,38],['goblin','knight','dragon','slime']],
 ];
 for(const [name,et,pt,types] of scen){
  res[name]={};
  for(const type of types){
   const pg=await fresh();
   const r=await pg.evaluate(async(et,pt,type)=>{
    const g=__game,d=g.dbg;park();
    const e=g.enemies.find(o=>o.type===type);e.terr=null;   // wall test: disable the dragon's territory clamp/disengage
    e.x=et[0]*32+16;e.y=et[1]*32+28;
    g.P.x=pt[0]*32+16;g.P.y=pt[1]*32+28;g.P.grace=99;g.P.hp=1e6;
    d.startEncounter(e,true);let B=g.B;B.phase='fight';B.dim=1;e.joinT=0;e.hp=e.maxhp=1e9;
    const px=e.x,py=e.y;let shotsOut=0,kinds={};
    const start=g.P.hp;
    for(let i=0;i<70;i++){
      e.x=px;e.y=py;e.atkCd=1e9;e.st='idle';B.inv=0;B.owner=e;d.ZOFF=d.eOff(e);
      const a=d.ATK[type](e);a.zones.forEach(z=>B.zones.push({...z,t:0,dur:.2,o:e}));
      a.strike(e);
      B.shots.forEach(s=>kinds[s.kind]=1);
      await new Promise(r=>setTimeout(r,35));
    }
    await new Promise(r=>setTimeout(r,1000));
    return {loss:start-g.P.hp,kinds:Object.keys(kinds).join(','),los:d.losW(d.ecen(e),d.eOff(e),d.pcen(),7)};
   },et,pt,type);
   res[name][type]=r;await pg.close();
  }
 }
 console.log(JSON.stringify(res,null,1));
 {const bad=[];for(const [n,o] of Object.entries(res))for(const [t,r] of Object.entries(o)){if(n==='CONTROL_open'){if(!(r.loss>0))bad.push(n+'/'+t+' control did no damage');}else if(r.loss>0)bad.push(n+'/'+t+' damaged through wall: '+r.loss);}
  if(bad.length){console.error('WALL TEST FAILED',bad);process.exitCode=1;}}
 // ---------- 2. natural AI: no attack started without LOS, repositions
 {
  const pg=await fresh();
  const r=await pg.evaluate(async()=>{
   const g=__game,d=g.dbg;park();
   const e=g.enemies.find(o=>o.type==='goblin');e.x=22*32+16;e.y=10*32+28;
   g.P.x=22*32+16;g.P.y=12*32+28;g.P.grace=99;g.P.hp=1e6;d.startEncounter(e,true);
   const B=g.B;B.phase='fight';B.dim=1;e.joinT=0;e.hp=e.maxhp=1e9;
   let bad=0,wind=0,moved=0,last='idle';const x0=e.x,y0=e.y;
   for(let i=0;i<80;i++){await new Promise(r=>setTimeout(r,50));g.P.x=22*32+16;g.P.y=12*32+28;
    if(e.st==='windup'&&last!=='windup'){wind++;if(!d.losW(d.ecen(e),d.eOff(e),d.pcen(),7))bad++;}last=e.st;}
   return {wind,windupWithoutLOS:bad,moved:Math.round(Math.hypot(e.x-x0,e.y-y0)),hpLoss:1e6-g.P.hp};
  });
  console.log('naturalAI',JSON.stringify(r));await pg.close();
 }
 // ---------- 3. auto radius vs cone
 const trig=async(label,type,ex,ey,fa,px,py)=>{
  const pg=await fresh();
  const r=await pg.evaluate(async(type,ex,ey,fa,px,py)=>{
   const g=__game;park();
   const e=g.enemies.find(o=>o.type===type);
   e.x=ex*32+16;e.y=ey*32+28;e.fa=fa;e.ta=fa;e.mode='look';e.mt=1e9;e.lk=1e9;e.hx=e.x;e.hy=e.y;
   g.P.x=px*32+16+(px%1)*0;g.P.y=py*32+28;g.P.grace=0;
   await new Promise(r=>setTimeout(r,900));
   return !!g.B;
  },type,ex,ey,fa,px,py);await pg.close();res['range:'+label]=r;};
 // knight vr170 ar85 vh .7 ; east-facing at (8,38); distances via tile coords (x32)
 await trig('behind 2.0 tiles (64px, in auto) -> TRIGGER','knight',8,38,Math.PI,10,38);
 await trig('behind 3.5 tiles (112px, outside auto) -> no','knight',8,38,Math.PI,11.5,38);
 await trig('front 4 tiles (128px, in cone) -> TRIGGER','knight',8,38,0,12,38);
 await trig('side 4 tiles (128px, out of cone) -> no','knight',8,38,Math.PI/2,12,38);
 await trig('front 6 tiles (192px, > vr) -> no','knight',8,38,0,14,38);
 await trig('behind, wall between (castle S wall, 64px) -> no','knight',22,10,Math.PI/2*-1,22,12);
 await trig('front, wall between (castle S wall) -> no','knight',22,10,Math.PI/2,22,12);
 console.log(JSON.stringify(Object.fromEntries(Object.entries(res).filter(([k])=>k.startsWith('range')))));
 console.log('ERRORS',errs);
 await b.close();
})();
