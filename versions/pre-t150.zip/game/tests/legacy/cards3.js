const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const MOBILE=process.argv[2]==='mobile';const OUT='/workspace/arcane-knight/store/';const PRE=MOBILE?'mobile':'desktop';
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});
 if(MOBILE)await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);else await pg.setViewport({width:960,height:640});
 pg.on('pageerror',e=>{errs.push('PAGEERR '+e.message);console.log('PAGEERR',e.message)});pg.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text());});
 const R={};const URL='file:///workspace/arcane-knight/index.html';
 await pg.goto(URL);await pg.evaluate(()=>localStorage.clear());await pg.goto(URL);await sleep(400);
 const start=async()=>{if(MOBILE)await pg.touchscreen.tap(200,400);else await pg.keyboard.press('Space');await sleep(500);};
 await start();
 const tap=async(lx,ly)=>{const p=await pg.evaluate((lx,ly)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+lx/z.VW*c.width,y:c.top+ly/z.VH*c.height};},lx,ly);
   if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(150);};
 const rectOf=async tag=>{await pg.evaluate((tag)=>{const U=__game.dbg.UI,id=tag.split(':')[1];const o=U.offs.find(q=>q.r.id===id);if(o)U.scroll=Math.max(0,o.y-20);},tag);await sleep(120);
  return pg.evaluate((tag)=>{const r=__game.dbg.UI.rects.find(q=>q.tag===tag);return r&&{x:r.x+r.w/2,y:r.y+r.h/2};},tag);};
 // ---- pause menu screenshot
 await pg.evaluate(()=>{__game.state='paused';});await sleep(200);await pg.screenshot({path:OUT+PRE+'-pause-menu.png'});await pg.evaluate(()=>{__game.state='play';});
 // ---- blacksmith: walk up and press E (talk)
 const sm=await pg.evaluate(()=>{const n=__game.dbg.NPCS.find(n=>n.smith);__game.P.x=n.x;__game.P.y=n.y+26;__game.P.grace=99;__game.P.gold=600;__game.dbg.QS.st.iron='done';__game.P.dir='u';return {name:n.name};});
 R.smith=sm;await sleep(200);
 if(MOBILE){const b2=await pg.evaluate(()=>{__game.press('KeyE');return 1;});}else await pg.keyboard.press('KeyE');
 await sleep(400);R.shopState=await pg.evaluate(()=>({state:__game.state,stock:__game.dbg.SHOP().stock}));
 await pg.screenshot({path:OUT+PRE+'-shop-screen.png'});
 const sid=R.shopState.stock[0];
 const g0=await pg.evaluate((id)=>({gold:__game.P.gold,own:__game.dbg.COL()[id]||0,price:__game.dbg.RAR[__game.dbg.CARD[id].rar].price}),sid);
 let r=await rectOf('buy:'+sid);await tap(r.x,r.y);
 R.buy=await pg.evaluate(([id,g0])=>({goldSpent:g0.gold-__game.P.gold,price:g0.price,own:__game.dbg.COL()[id],sold:__game.dbg.SHOP().sold[id],inDeck:__game.dbg.DECK().filter(x=>x===id).length}),[sid,g0]);
 r=await rectOf('buy:'+sid);await tap(r.x,r.y);R.rebuyBlocked=await pg.evaluate(([id,g0])=>({goldSpent:g0.gold-__game.P.gold,msg:__game.dbg.UI.msg}),[sid,g0]);
 // reforge
 r=await rectOf('shot');const up0=await pg.evaluate(()=>__game.P.up);await tap(r.x,r.y);R.reforge=await pg.evaluate((u)=>({up:__game.P.up-u}),up0);
 // rotation after 5 kills
 const old=await pg.evaluate(()=>[...__game.dbg.SHOP().stock]);
 r=await rectOf('done');await tap(r.x,r.y);R.afterShopClose=await pg.evaluate(()=>__game.state);
 await pg.evaluate(()=>{__game.dbg.addKills(5);__game.dbg.openShop();});await sleep(100);
 R.rotated=await pg.evaluate((o)=>({old:o,now:[...__game.dbg.SHOP().stock],soldReset:Object.keys(__game.dbg.SHOP().sold).length===0}),old);
 await pg.evaluate(()=>__game.dbg.closeUI());
 // ---- save persistence
 await pg.evaluate(()=>{const d=__game.dbg;['chain','wolf','meteor'].forEach(id=>d.grantCard(id));d.deckAdd('lance');d.saveNow();});
 const before=await pg.evaluate(()=>({col:__game.dbg.COL(),deck:[...__game.dbg.DECK()],shop:__game.dbg.SHOP(),gold:__game.P.gold}));
 await pg.goto(URL);await sleep(500);
 R.titleItems=await pg.evaluate(()=>__game.titleMenu.items.slice());
 await pg.evaluate(()=>__game.press('Space'));await sleep(500);
 const after=await pg.evaluate(()=>({col:__game.dbg.COL(),deck:[...__game.dbg.DECK()],shop:__game.dbg.SHOP(),gold:__game.P.gold}));
 R.savePersist=JSON.stringify(before)===JSON.stringify(after);
 R.savedCards={deck:after.deck.length,col:Object.keys(after.col).length};
 // ---- combat visuals
 const setup=async(hand)=>pg.evaluate((hand)=>{const g=__game,d=g.dbg;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   const pool=g.enemies.filter(x=>x.type==='knight'||x.type==='slime');
   const pos=[[6,38],[7,37.4],[7.4,39],[6,36.6]];
   pool.slice(0,3).forEach((e,i)=>{e.x=pos[i][0]*32+16;e.y=pos[i][1]*32+28;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;});
   g.tp(10,38);g.P.grace=99;g.P.hp=60;g.P.aim=Math.PI;g.P.dir='l';
   d.startEncounter(pool[0],true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;});
   B.hand=hand;B.sel=0;window.__es=B.ens.slice();},hand);
 const cast=async(name,hand,idxs,wait,shotsAt)=>{await setup(hand);await pg.evaluate((idxs)=>{idxs.forEach(i=>__game.dbg.useCard(i));},idxs);await sleep(wait);await pg.screenshot({path:OUT+PRE+'-spell-'+name+'.png'});};
 if(MOBILE||true){
  await cast('chain',['chain','poison','sword','heal','lance'],[0],140);
  await cast('meteor',['meteor','quake','sword','heal','lance'],[0],700);
  await cast('meteor-impact',['meteor','quake','sword','heal','lance'],[0],1230);
  await cast('poison-quake',['quake','poison','ward','haste','lance'],[0,1],500);
  await cast('combo-steam',['frostbolt','fire','sword','heal','lance'],[0,1],350);
  await cast('combo-judgment',['timestop','meteor','sword','heal','lance'],[0,1],1050);
  await cast('dragonfire-wolf',['wolf','dragonfire','ward','haste','lance'],[0,1],350);
 }
 await b.close().catch(()=>{});
 console.log(JSON.stringify(R,null,1));console.log('ERRORS',errs);
})();
