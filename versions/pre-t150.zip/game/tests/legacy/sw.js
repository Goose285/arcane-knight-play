const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);
 pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(400);await pg.touchscreen.tap(200,400);await sleep(300);
 const css=async()=>pg.evaluate(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,b=__game.btn.atk;return {x:c.left+b.x/z.VW*c.width,y:c.top+b.y/z.VH*c.height,k:c.width/z.VW};});
 const setup=async(opts={})=>{await pg.evaluate((o)=>{const g=__game,d=g.dbg;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   if(window.__B&&g.B){} 
   const kn=g.enemies.filter(x=>x.type==='knight'),sl=g.enemies.filter(x=>x.type==='slime');
   const near=kn[0],far=sl[0];near.x=(o.nx||5)*32+16;near.y=38*32+28;far.x=7*32+16;far.y=33.5*32+28;[near,far].forEach(e=>{e.hx=e.x;e.hy=e.y;});
   g.P.x=10*32+16;g.P.y=38*32+28;g.P.grace=99;g.P.hp=1e6;g.tp(10,38);g.P.x=10*32+16;g.P.y=38*32+28;g.P.aim=0;g.P.dir='r';
   d.startEncounter(near,true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;});B.hand=o.hand||['frostbolt','sword','fire','lance','crimsonbolt'];B.sel=0;
   window.__shots=new Set();window.__iv&&clearInterval(window.__iv);window.__iv=setInterval(()=>{if(g.B)g.B.shots.forEach(s=>{if(s.own==='p')window.__shots.add(s.kind);});},8);
   window.__near=near;},opts);};
 const out={};
 // A: quick swipe (before hold threshold) -> casts frost bolt at nearest, no shot, faces enemy
 await setup();let c=await css();
 let th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(60);await th.move(c.x,c.y-30*c.k);await th.move(c.x,c.y-70*c.k);await sleep(120);
 out.A_beforeEnd=await pg.evaluate(()=>({frozen:__near.frozen>0,hp:__near.hp,card:__game.B.hand[0],dir:__game.P.dir,aimDeg:Math.round(__game.P.aim*57.3)}));
 await th.end();await sleep(500);
 out.A=await pg.evaluate(()=>({shots:[...__shots],cardUsed:__game.B.hand[0]===null||__game.B.hand[0]!=='frostbolt',nearFrozen:__near.frozen>0,dmg:5000-__near.hp,facing:__game.P.dir}));
 // B: swipe after long hold (charging) -> charge cancelled, no charged shot
 await setup();c=await css();th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(1300);
 out.B_chargeBefore=await pg.evaluate(()=>+__game.B.charge.toFixed(2));
 await th.move(c.x,c.y-30*c.k);await th.move(c.x,c.y-70*c.k);await sleep(100);await th.end();await sleep(500);
 out.B=await pg.evaluate(()=>({shots:[...__shots],charge:__game.B.charge,spent:__game.B.hand[0]!=='frostbolt'}));
 // C: tap = one normal shot
 await setup();c=await css();await pg.touchscreen.tap(c.x,c.y);await sleep(400);
 out.C_tapShots=await pg.evaluate(()=>[...__shots]);
 // D: long hold no swipe -> charged shot
 await setup();c=await css();th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(1400);await th.end();await sleep(300);
 out.D_holdShots=await pg.evaluate(()=>[...__shots]);
 // E: short drag (<40px) then release: no cast
 await setup();c=await css();th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(100);await th.move(c.x,c.y-20*c.k);await sleep(50);await th.end();await sleep(300);
 out.E_noSwipe=await pg.evaluate(()=>({card:__game.B.hand[0],shots:[...__shots]}));
 // F: sword swipe with enemy close (behind player's facing): damages nearest
 await setup({nx:8,hand:['sword','lance','fire','frostbolt','crimsonbolt']});c=await css();th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(50);await th.move(c.x,c.y-60*c.k);await sleep(50);await th.end();await sleep(500);
 out.F_sword=await pg.evaluate(()=>({dmg:5000-__near.hp}));
 // G: lance & fire aimed at nearest enemy though moving away + screenshot of hint
 await setup({hand:['lance','fire','sword','frostbolt','crimsonbolt']});c=await css();th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(300);
 await pg.screenshot({path:'/workspace/arcane-knight/mobile-swipe-hint.png'});
 await th.move(c.x,c.y-22*c.k);await sleep(120);await pg.screenshot({path:'/workspace/arcane-knight/mobile-swipe-aim.png'});
 await th.move(c.x,c.y-60*c.k);await sleep(150);await pg.screenshot({path:'/workspace/arcane-knight/mobile-swipe-cast.png'});await th.end();await sleep(400);
 out.G_lance=await pg.evaluate(()=>({dmg:5000-__near.hp,card:__game.B.hand[0]}));
 // K key auto-face (desktop path): face away, press K
 await setup({hand:['lance','fire','sword','frostbolt','crimsonbolt']});await pg.evaluate(()=>{__game.P.aim=0;__game.P.dir='r';__game.B.target=null;});
 await pg.evaluate(()=>__game.press('KeyK'));await sleep(300);
 out.K=await pg.evaluate(()=>({dmg:5000-__near.hp,dir:__game.P.dir}));
 console.log(JSON.stringify(out,null,1),errs);await b.close();})();
