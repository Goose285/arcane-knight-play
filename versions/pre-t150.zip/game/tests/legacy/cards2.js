const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const MOBILE=process.argv[2]==='mobile';const OUT='/workspace/arcane-knight/store/';
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});
 if(MOBILE)await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);else await pg.setViewport({width:960,height:640});
 pg.on('pageerror',e=>{errs.push('PAGEERR '+e.message);console.log('PAGEERR',e.message)});pg.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text());});
 const R={};
 const URL='file:///workspace/arcane-knight/index.html';
 await pg.goto(URL);await sleep(500);
 await pg.evaluate(()=>{localStorage.clear();});
 await pg.goto(URL);await sleep(400);
 // title -> New Game
 if(MOBILE)await pg.touchscreen.tap(200,400);else await pg.keyboard.press('Space');
 await sleep(500);R.state0=await pg.evaluate(()=>__game.state);
 R.starter=await pg.evaluate(()=>({deck:__game.dbg.DECK().length,col:__game.dbg.COL()}));
 // tap helper: logical -> css
 const tap=async(lx,ly)=>{const p=await pg.evaluate((lx,ly)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+lx/z.VW*c.width,y:c.top+ly/z.VH*c.height};},lx,ly);
   if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(150);};
 const rectOf=async tag=>{await pg.evaluate((tag)=>{const U=__game.dbg.UI,id=tag.split(':')[1];const o=U.offs.find(q=>q.r.id===id);if(o)U.scroll=Math.max(0,o.y-20);},tag);await sleep(120);
  return pg.evaluate((tag)=>{const r=__game.dbg.UI.rects.find(q=>q.tag===tag);return r&&{x:r.x+r.w/2,y:r.y+r.h/2};},tag);};
 // pause -> deck (touch: pause button, then DECK button)
 if(MOBILE){const pb=await pg.evaluate(()=>{const b=__game.btn.pause;return b;});await tap(pb.x,pb.y);}else await pg.keyboard.press('KeyP');
 await sleep(200);R.paused=await pg.evaluate(()=>__game.state);
 const sz=await pg.evaluate(()=>__game.size);
 if(MOBILE){const pr=await pg.evaluate(()=>__game.dbg.getPauseRects().find(r=>r.e.id==='cards'));await tap(pr.x+pr.w/2,pr.y+pr.h/2);}else await pg.keyboard.press('KeyD');
 await sleep(250);R.deckOpen=await pg.evaluate(()=>__game.state);
 // give some cards then edit deck by tapping
 await pg.evaluate(()=>{const d=__game.dbg;['frostbolt','frostbolt','chain','chain','quake','wolf','timestop','meteor','dragonfire','curse','haste'].forEach(id=>d.grantCard(id));});
 await sleep(250);
 R.afterGrant=await pg.evaluate(()=>({deck:__game.dbg.DECK().length,col:Object.keys(__game.dbg.COL()).length}));
 // deck was 17 -> grants auto-added up to 20; remove 2 swords via tap, add quake via tap
 let r=await rectOf('minus:sword');await tap(r.x,r.y);await tap(r.x,r.y);
 R.afterMinus=await pg.evaluate(()=>({deck:__game.dbg.DECK().length,sword:__game.dbg.DECK().filter(x=>x==='sword').length}));
 if(MOBILE){r=await rectOf('plus:meteor');}else r=await rectOf('plus:meteor');
 await tap(r.x,r.y);
 R.afterPlus=await pg.evaluate(()=>({deck:__game.dbg.DECK().length,meteor:__game.dbg.DECK().filter(x=>x==='meteor').length}));
 // copy limit: epic max 1
 r=await rectOf('plus:meteor');if(r)await tap(r.x,r.y);
 R.epicLimit=await pg.evaluate(()=>({meteor:__game.dbg.DECK().filter(x=>x==='meteor').length,msg:__game.dbg.UI.msg}));
 // drag-scroll (touch) / wheel (desktop)
 if(MOBILE){const c=await pg.evaluate(()=>{const c=document.getElementById('c').getBoundingClientRect();return {x:c.left+c.width/2,y:c.top+c.height*.6,h:c.height};});
   const th=await pg.touchscreen.touchStart(c.x,c.y);await th.move(c.x,c.y-120);await th.move(c.x,c.y-260);await th.end();}
 else{await pg.mouse.move(480,320);await pg.mouse.wheel({deltaY:300});}
 await sleep(200);R.scroll=await pg.evaluate(()=>__game.dbg.UI.scroll);
 await pg.evaluate(()=>{__game.dbg.UI.scroll=0;});await sleep(200);
 await pg.screenshot({path:OUT+(MOBILE?'mobile':'desktop')+'-deck-screen.png'});
 await pg.evaluate(()=>{__game.dbg.UI.scroll=Math.max(0,__game.dbg.UI.total-(__game.dbg.UI.bot-__game.dbg.UI.top));});await sleep(200);
 await pg.screenshot({path:OUT+(MOBILE?'mobile':'desktop')+'-deck-combos.png'});
 await pg.evaluate(()=>{__game.dbg.UI.scroll=0;});
 // Done -> returns to paused -> resume
 r=await rectOf('done');await tap(r.x,r.y);await sleep(200);R.afterDone=await pg.evaluate(()=>__game.state);
 if(MOBILE){const pr=await pg.evaluate(()=>__game.dbg.getPauseRects().find(r=>r.e.id==='resume'));await tap(pr.x+pr.w/2,pr.y+pr.h/2);}else await pg.keyboard.press('KeyP');
 await sleep(200);R.resumed=await pg.evaluate(()=>__game.state);
 // deck <10 blocked
 await pg.evaluate(()=>{__game.dbg.openDeck();});await sleep(100);
 await pg.evaluate(()=>{const d=__game.dbg;while(d.DECK().length>10)d.deckRemove(d.DECK()[0]);d.deckRemove(d.DECK()[0]);});
 R.minDeck=await pg.evaluate(()=>({n:__game.dbg.DECK().length,msg:__game.dbg.UI.msg}));
 await pg.evaluate(()=>{__game.dbg.closeUI();});R.stillInDeck=await pg.evaluate(()=>__game.state);
 await pg.evaluate(()=>{const d=__game.dbg;['sword','fire','heal','lance','shield'].forEach(id=>{d.deckAdd(id);});d.closeUI();});
 R.leftDeck=await pg.evaluate(()=>__game.state);
 // gauge draws from DECK only
 R.drawFromDeck=await pg.evaluate(()=>{const g=__game,d=g.dbg;const dk=d.DECK();dk.length=0;for(let i=0;i<12;i++)dk.push('lance');
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive);g.tp(10,38);e.x=g.P.x-80;e.y=g.P.y;d.startEncounter(e,true);g.B.phase='fight';
   const h1=[...g.B.hand];g.B.gauge=1;return {hand:h1};});
 await sleep(300);R.redeal=await pg.evaluate(()=>[...__game.B.hand]);
 // restore sane deck
 await pg.evaluate(()=>{__game.dbg.resetCards();__game.B&&(__game.B.pile=null);});
 // --- drops distribution ---
 R.drops=await pg.evaluate(()=>{const d=__game.dbg,out={};for(const lv of [1,5,12]){const c={n:0,common:0,uncommon:0,rare:0,epic:0};for(let i=0;i<20000;i++){const x=d.rollDrop(lv);if(x){c.n++;c[x.rar]++;}}out['lv'+lv]={chance:+(c.n/20000).toFixed(3),common:c.common,uncommon:c.uncommon,rare:c.rare,epic:c.epic};}return out;});
 // --- shop via blacksmith NPC ---
 await pg.evaluate(()=>{const g=__game;g.B&&g.B.ens&&0;});
 R.shop=await pg.evaluate(async()=>{const g=__game,d=g.dbg;d.resetCards();g.B=null;return 1;});
 await pg.evaluate(()=>{__game.state='play';});
 await b.close().catch(()=>{});
 console.log(JSON.stringify(R,null,1));console.log('ERRORS',errs);
})();
