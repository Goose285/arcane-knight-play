const puppeteer=require('puppeteer-core');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const mode=process.argv[2]||'desk';
 const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});
 if(mode==='mob'){await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);}else await pg.setViewport({width:1280,height:720});
 const errs=[];pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(500);
 if(mode==='mob')await pg.touchscreen.tap(200,400);else await pg.keyboard.press('Space');
 await sleep(400);
 // knight(subject) at (8,38) facing east; slime at ~140px from it, goblin ~180px; dragon/other far (>400px)
 await pg.evaluate(()=>{
  const g=__game;
  g.enemies.forEach(e=>{e.alive=true;e.fa=0;e.mode='look';e.mt=1e9;e.lk=1e9;e.ta=0;e.x=60*32;e.y=2*32;});
  const pick=t=>g.enemies.filter(o=>o.type===t);
  const k=pick('knight')[0],s=pick('slime')[0],go=pick('goblin')[0],far=pick('slime')[1]||pick('knight')[1];
  k.x=8*32+16;k.y=38*32+28;
  s.x=k.x;s.y=k.y-130;go.x=k.x-150;go.y=k.y+60;
  far.x=k.x;far.y=k.y+500;
  [k,s,go,far].forEach(e=>{e.hx=e.x;e.hy=e.y;e.mode='look';e.mt=1e9;e.lk=1e9;});
  g.P.x=12*32+16;g.P.y=38*32+28;g.P.grace=0;g.P.aim=Math.PI;g.tp(12,38);g.P.x=12*32+16;g.P.y=38*32+28;
  window.__t={k,s,go,far};
 });
 let tries=0;while(!(await pg.evaluate(()=>!!__game.B))&&tries++<40)await sleep(100);
 await sleep(1500);
 const r=await pg.evaluate(()=>({n:__game.B.ens.length,types:__game.B.ens.map(e=>e.type),far:__t.far.engaged,s:__t.s.engaged,go:__t.go.engaged,phase:__game.B.phase}));
 console.log(JSON.stringify(r));
 // hold fire & screenshot mid-fight
 if(mode==='mob'){await pg.touchscreen.tap(330,700);}
 await sleep(1800);
 await pg.screenshot({path:'/workspace/arcane-knight/'+(mode==='mob'?'mobile-group-battle.png':'desktop-group-battle.png')});
 // kill all by force through game API: damage every engaged
 await pg.evaluate(()=>{window.__p=setInterval(()=>{const B=__game.B;if(B&&B.phase==='fight'){B.ens.forEach(e=>{if(!e.dying&&e.hp>20)e.hp=20;});}},50);});
 // spam J
 for(let i=0;i<120;i++){await pg.keyboard.down('KeyJ');await sleep(60);await pg.keyboard.up('KeyJ');await sleep(60);
   const ph=await pg.evaluate(()=>__game.B&&__game.B.phase);if(ph==='reward'||ph==='lose'||!ph)break;}
 await sleep(300);
 console.log('phase',await pg.evaluate(()=>{clearInterval(__p);return __game.B&&{ph:__game.B.phase,def:__game.B.defeated,xp:__game.B.gainXp,g:__game.B.gainGold,total:__game.B.total};}));
 if(mode==='mob'){await pg.screenshot({path:'/workspace/arcane-knight/mobile-group-reward.png'});}
 await pg.keyboard.press('Space');await sleep(400);
 console.log('after',await pg.evaluate(()=>({B:!!__game.B,far:__t.far.engaged,ents:__game.enemies.filter(e=>e.alive).length,hp:__game.P.hp})));
 console.log(errs);
 await b.close();
})();
