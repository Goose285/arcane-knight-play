const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];const url='file:///workspace/arcane-knight/index.html';
 const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg.setViewport({width:1280,height:720});pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto(url);await sleep(500);
 const out={};
 out.menu1=await pg.evaluate(()=>__game.titleMenu.items.slice());
 await pg.keyboard.press('Space');await sleep(300);
 out.noSaveYet=await pg.evaluate(()=>localStorage.getItem('arcaneKnight.save.v1'));
 // area change autosave: village -> meadow
 await pg.evaluate(()=>{__game.P.lv=4;__game.P.gold=123;__game.P.xp=17;__game.tp(8,20);});await sleep(400);
 out.areaSave=await pg.evaluate(()=>{const s=JSON.parse(localStorage.getItem('arcaneKnight.save.v1')||'null');return s&&{why:s.why,area:s.area,lv:s.P.lv,gold:s.P.gold};});
 // level-up save via real kill
 await pg.evaluate(()=>{const g=__game,d=g.dbg;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});const e=g.enemies.find(o=>o.type==='slime');e.x=8*32+16;e.y=20*32+28;g.P.x=11*32;g.P.y=20*32+28;g.P.xp=1e3-1+0;g.P.grace=99;d.startEncounter(e,true);g.B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=1;});
 for(let i=0;i<30;i++){await pg.keyboard.down('KeyJ');await sleep(60);await pg.keyboard.up('KeyJ');await sleep(60);if(!(await pg.evaluate(()=>!!__game.B)))break;}
 out.levelSave=await pg.evaluate(()=>{const s=JSON.parse(localStorage.getItem('arcaneKnight.save.v1'));return {why:s.why,lv:s.P.lv};});
 await pg.evaluate(()=>{__game.P.gold=555;__game.saveGame('manual');});
 await pg.reload();await sleep(500);
 out.menu2=await pg.evaluate(()=>__game.titleMenu.items.slice());
 await pg.screenshot({path:'/workspace/arcane-knight/desktop-title-continue.png'});
 await pg.keyboard.press('Space');await sleep(300);
 out.loaded=await pg.evaluate(()=>({lv:__game.P.lv,gold:__game.P.gold,state:__game.state}));
 // new game w/ confirm
 await pg.reload();await sleep(500);await pg.keyboard.press('ArrowDown');await pg.keyboard.press('Space');await sleep(200);
 out.afterFirstNewGamePress=await pg.evaluate(()=>({state:__game.state,hasSave:!!localStorage.getItem('arcaneKnight.save.v1'),confirm:__game.titleMenu.confirm}));
 await pg.keyboard.press('Space');await sleep(300);
 out.afterConfirm=await pg.evaluate(()=>({state:__game.state,lv:__game.P.lv,hasSave:!!localStorage.getItem('arcaneKnight.save.v1')}));
 console.log(JSON.stringify(out,null,1),errs);
 // mobile tap on Continue
 const m=await b.newPage();await m.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await m.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);m.on('pageerror',e=>errs.push(e.message));
 await m.goto(url);await sleep(500);await m.screenshot({path:'/workspace/arcane-knight/mobile-title-new.png'});await m.evaluate(()=>{});
 {const rc0=await m.evaluate(()=>__game.titleMenu.rects[0]);const sc0=await m.evaluate(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {l:c.left,t:c.top,w:c.width,h:c.height,VW:z.VW,VH:z.VH};});await m.touchscreen.tap(sc0.l+(rc0.x+rc0.w/2)/sc0.VW*sc0.w,sc0.t+(rc0.y+rc0.h/2)/sc0.VH*sc0.h);await sleep(300);}
 await m.evaluate(()=>{__game.P.lv=3;__game.saveGame('t');});await m.reload();await sleep(500);
 const rc=await m.evaluate(()=>__game.titleMenu.rects.map(r=>r));await m.screenshot({path:'/workspace/arcane-knight/mobile-title-continue.png'});
 const sc=await m.evaluate(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {l:c.left,t:c.top,w:c.width,h:c.height,VW:z.VW,VH:z.VH};});
 const r0=rc[0];await m.touchscreen.tap(sc.l+(r0.x+r0.w/2)/sc.VW*sc.w,sc.t+(r0.y+r0.h/2)/sc.VH*sc.h);await sleep(400);
 console.log('mobile tap continue ->',await m.evaluate(()=>({state:__game.state,lv:__game.P.lv})),errs);
 await b.close();})();
