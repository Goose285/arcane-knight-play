const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);
 pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(500);await pg.evaluate(()=>{__game.state='play';});
 // enemy offset (dx,dy) from player in px; player moving right (aim 0) so facing is away from enemy
 const run=(dx,dy,hand,idx)=>pg.evaluate(async([dx,dy,hand,idx])=>{const g=__game,d=g.dbg;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(o=>o.type==='knight');g.tp(10,38);g.P.grace=99;g.P.hp=1e6;const px=g.P.x,py=g.P.y;
   e.x=px+dx;e.y=py+dy;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.dim=1;e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;
   g.P.aim=0;g.P.dir='r';g.P.moving=true;B.hand=hand;B.sel=0;B.lastCard=null;
   const lock=!!d.swordLock(64);
   d.useCard(idx||0);await new Promise(r=>setTimeout(r,450));
   return {lock,dmg:5000-e.hp,dir:g.P.dir,moved:Math.round(Math.hypot(g.P.x-px,g.P.y-py)),aimDeg:Math.round(g.P.aim*57.3)};},[dx,dy,hand,idx]);
 const R={};
 R.behind50=await run(-50,0,['sword','heal','heal','heal','heal']);
 R.behindDiag=await run(-40,-35,['sword','heal','heal','heal','heal']);
 R.outsideReachLunge90=await run(-95,0,['sword','heal','heal','heal','heal']);
 R.far200=await run(-200,0,['sword','heal','heal','heal','heal']);
 R.frontAsBefore=await run(55,0,['sword','heal','heal','heal','heal']);
 // wall: castle south wall, enemy just beyond wall within 64px
 R.behindWall=await pg.evaluate(async()=>{const g=__game,d=g.dbg;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(o=>o.type==='knight');e.x=22*32+16;e.y=10*32+28;e.hx=e.x;e.hy=e.y;g.P.x=22*32+16;g.P.y=12*32+28;g.P.grace=99;g.P.hp=1e6;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;return {los:d.losW(d.ecen(e),7,d.pcen(),7),lock:!!d.swordLock(64)};});
 // Phantom Slash combo auto-targets: enemy behind the dash destination
 R.phantom=await pg.evaluate(async()=>{const g=__game,d=g.dbg;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(o=>o.type==='knight');g.tp(10,38);g.P.grace=99;g.P.hp=1e6;const px=g.P.x,py=g.P.y;e.x=px-60;e.y=py+4;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;g.P.aim=0;g.P.moving=true;
   B.hand=['shadow','sword','heal','heal','heal'];B.sel=0;B.lastCard=null;d.useCard(0);d.useCard(1);await new Promise(r=>setTimeout(r,500));return {combo:B.lastCombo,dmg:5000-e.hp};});
 await pg.evaluate(()=>{});
 // screenshot of a lunge swing
 await pg.evaluate(()=>{const g=__game,d=g.dbg;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.mt=1e9;e.lk=1e9;});const e=g.enemies.find(o=>o.type==='knight');g.tp(10,38);g.P.grace=99;g.P.hp=1e6;e.x=g.P.x-80;e.y=g.P.y;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;g.P.aim=0;g.P.moving=true;B.hand=['sword','heal','heal','heal','heal'];B.sel=0;d.useCard(0);});
 await sleep(130);await pg.screenshot({path:'/workspace/arcane-knight/store/mobile-sword-autotarget.png'});
 await b.close();console.log(JSON.stringify(R,null,1));console.log('ERRORS',errs);
})();
