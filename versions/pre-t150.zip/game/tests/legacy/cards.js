const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const MOBILE=process.argv[2]==='mobile';
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});
 if(MOBILE)await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);else await pg.setViewport({width:960,height:640});
 pg.on('pageerror',e=>errs.push('PAGEERR '+e.message));pg.on('console',m=>{if(m.type()==='error')errs.push('CONSOLE '+m.text());});
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(500);
 await pg.evaluate(()=>{__game.state='play';});
 const setup=async(o={})=>pg.evaluate((o)=>{const g=__game,d=g.dbg;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   const pool=g.enemies.filter(x=>x.type==='knight'||x.type==='slime');
   const pos=[[6,38],[7,37.4],[7.4,39],[6,36.6]];
   pool.slice(0,o.n||3).forEach((e,i)=>{e.x=pos[i][0]*32+16;e.y=pos[i][1]*32+28;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;});
   g.tp(10,38);g.P.grace=99;g.P.hp=60;g.P.aim=Math.PI;g.P.dir='l';
   d.startEncounter(pool[0],true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;e.frozen=0;e.stun=0;});
   B.hand=[o.id||'sword','sword','sword','sword','sword'];B.sel=0;
   window.__es=B.ens.slice();return B.ens.length;},o);
 const hp=()=>pg.evaluate(()=>__es.map(e=>5000-e.hp));
 const R={};
 // --- each new card executes ---
 const ids=['chain','quake','meteor','poison','shadow','ward','reflect','haste','wolf','decoy','curse','drain','dragonfire','timestop'];
 const snap=()=>pg.evaluate(()=>({hp:Math.round(__game.P.hp),inv:+__game.B.inv.toFixed(2),haste:+__game.B.haste.toFixed(1),wolf:!!__game.B.wolf,clouds:__game.B.clouds.length,stun:__es.map(e=>+(e.stun||0).toFixed(1)),curse:__es.map(e=>+(e.curse||0).toFixed(1)),chill:__es.map(e=>+e.chill.toFixed(1)),ch:!!__game.B.channel,ts:+__game.B.tstop.toFixed(1)}));
 for(const id of ids){
   await setup({id});let pre={};
   if(id==='drain')await pg.evaluate(()=>{__game.P.hp=30;});
   if(id==='shadow')pre=await pg.evaluate(()=>({x:__game.P.x,y:__game.P.y}));
   await pg.evaluate(()=>__game.dbg.useCard(0));
   const used=await pg.evaluate(()=>__game.B.hand[0]===null);
   let extra={};
   if(id==='ward'||id==='reflect'||id==='decoy'){
     await pg.evaluate(()=>{const g=__game,B=g.B,pc=g.dbg.pcen();B.inv=0;B.barrier=0;g.P.hp=60;
       B.shots.push({x:pc.x-90,y:pc.y,vx:200,vy:0,r:6,dmg:12,own:'e',kind:'goo',life:2,a:0});});
     await sleep(250);extra.mid=await pg.evaluate(()=>({reflected:__game.B.shots.some(s=>s.refl)}));await sleep(700);
     extra.end=await pg.evaluate(()=>({hp:Math.round(__game.P.hp),decoyHp:__game.B.decoy&&__game.B.decoy.hp,aimIsDecoy:!!__game.B.decoy&&Math.abs(__game.dbg.aimPos().x-__game.B.decoy.x)<1,enemyDmg:__es.map(e=>5000-e.hp)}));
   }
   await sleep({meteor:1700,wolf:2500,poison:1500,drain:1400,curse:100}[id]||500);
   const st=await snap(),after=await pg.evaluate(()=>({x:__game.P.x,y:__game.P.y}));
   R[id]={used,dmg:await hp(),...st,extra,moved:id==='shadow'?Math.round(Math.hypot(after.x-pre.x,after.y-pre.y)):undefined};
 }
 // curse doubles damage
 for(const cursed of [false,true]){
   await setup({id:'curse',n:1});
   if(cursed){await pg.evaluate(()=>__game.dbg.useCard(0));await sleep(100);}
   await pg.evaluate(()=>{__game.B.hand[1]='frostbolt';__game.B.lastCard=null;__game.dbg.useCard(1);});await sleep(300);
   R['frostbolt_'+(cursed?'cursed':'plain')]=(await hp())[0];
 }
 // time stop vs boss
 await setup({id:'timestop',n:2});
 await pg.evaluate(()=>{const d=__game.enemies.find(e=>e.type==='dragon');d.x=__es[0].x+60;d.y=__es[0].y;d.alive=true;d.engaged=false;__game.dbg.startEncounter;__es[0].engaged=true;});
 R.timestopBoss=await pg.evaluate(()=>{const g=__game,d=g.enemies.find(e=>e.type==='dragon'),B=g.B;if(!B.ens.includes(d)){d.engaged=true;d.joinT=0;d.atkCd=1e9;d.chill=0;d.hp=d.maxhp;B.ens.push(d);}
   B.hand[0]='timestop';B.lastCard=null;g.dbg.useCard(0);return {normalStun:B.ens.filter(e=>e!==d).map(e=>e.stun>0),dragonStun:d.stun>0,dragonChill:+d.chill.toFixed(1),shotsFrozen:B.tstop>0};});
 // --- combos ---
 const combos=[['frostbolt','fire'],['chain','poison'],['shadow','sword'],['sword','shadow'],['ward','heal'],['fire','quake'],['timestop','meteor'],['meteor','timestop'],['fire','frostbolt']];
 R.combos={};
 for(const [a,c] of combos){
   await setup({id:a});
   const r=await pg.evaluate(([a,c])=>{const B=__game.B,d=__game.dbg;B.hand=[a,c,'sword','sword','sword'];B.sel=0;d.useCard(0);const t1=B.combos||0;d.useCard(1);return {combos:B.combos||0,last:B.lastCombo,banner:B.banner&&B.banner.s};},[a,c]);
   await sleep(1500);r.dmg=await hp();R.combos[a+'+'+c]=r;
 }
 // outside 1.5s window: no combo
 await setup({id:'frostbolt'});
 await pg.evaluate(()=>{const B=__game.B,d=__game.dbg;B.hand=['frostbolt','fire','sword','sword','sword'];d.useCard(0);});await sleep(1800);
 R.noComboLate=await pg.evaluate(()=>{const B=__game.B;__game.dbg.useCard(1);return B.combos||0;});
 await b.close().catch(()=>{});
 console.log(JSON.stringify(R,null,1));console.log('ERRORS',errs);
})();
