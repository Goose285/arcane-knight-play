const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg.setViewport({width:1280,height:720});const errs=[];pg.on('pageerror',e=>errs.push(e.message));
 await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(400);await pg.keyboard.press('Space');await sleep(300);
 const r=await pg.evaluate(async()=>{const g=__game,d=g.dbg;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
  const dr=g.enemies.find(o=>o.type==='dragon');dr.x=10*32+16;dr.y=38*32+28;g.P.x=14*32+16;g.P.y=38*32+28;g.P.grace=99;g.P.hp=1e6;
  d.startEncounter(dr,true);const B=g.B;B.phase='fight';dr.joinT=0;dr.hp=1;dr.atkCd=1e9;const ph=new Set();
  for(let i=0;i<60&&g.B;i++){__game.press('KeyJ');await new Promise(r=>setTimeout(r,80));if(g.B)ph.add(g.B.phase);if(g.B&&g.B.phase==='reward'&&g.B.t>.8){__game.press('Space');}}
  return [...ph];});
 console.log(r,errs);await b.close();})();
