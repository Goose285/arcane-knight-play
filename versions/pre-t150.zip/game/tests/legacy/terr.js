const puppeteer=require('puppeteer-core');const sleep=ms=>new Promise(r=>setTimeout(r,ms));
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const errs=[];
 const fresh=async(mob)=>{const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});if(mob)await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);else await pg.setViewport({width:1280,height:720});
  pg.on('pageerror',e=>errs.push(e.message));pg.on('console',m=>{if(m.type()==='error')errs.push(m.text());});
  await pg.goto('file:///workspace/arcane-knight/index.html?nosave=1');await sleep(400);await pg.evaluate(()=>__game.press('Space'));await sleep(300);
  await pg.evaluate(()=>{window.park=()=>__game.enemies.forEach(e=>{if(e.type!=='dragon'){e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;}e.mt=1e9;e.lk=1e9;});});return pg;};
 const out={};
 let pg=await fresh();
 out.rect=await pg.evaluate(()=>{const d=__game.enemies.find(o=>o.type==='dragon');return d.terr;});
 // 1. forced outside position gets pulled back; wandering never leaves
 out.wander=await pg.evaluate(async()=>{const g=__game;park();const d=g.enemies.find(o=>o.type==='dragon');
  g.P.x=10*32;g.P.y=40*32;g.P.grace=99;let out=0;const t=d.terr;
  d.x=31*32;d.y=14*32;await new Promise(r=>setTimeout(r,100));const afterTeleport=[Math.round(d.x),Math.round(d.y)];
  for(let i=0;i<120;i++){ // force it to walk south/east/west repeatedly
    d.mode='walk';d.mt=2;d.fa=[Math.PI/2,0,Math.PI,Math.PI/2][i%4];await new Promise(r=>setTimeout(r,50));
    if(d.x<t.x0-.5||d.x>t.x1+.5||d.y<t.y0-.5||d.y>t.y1+.5)out++;}
  return {afterTeleport,violations:out,pos:[Math.round(d.x),Math.round(d.y)]};});
 await pg.close();
 // 2. player outside the gate, in line of sight, does not trigger aggro
 pg=await fresh();
 out.noAggroOutside=await pg.evaluate(async()=>{const g=__game;park();const d=g.enemies.find(o=>o.type==='dragon');
  d.x=31.5*32;d.y=10*32;d.fa=Math.PI/2;d.ta=d.fa;d.mode='look';d.mt=1e9;d.lk=1e9;g.P.x=31.5*32;g.P.y=13*32;g.P.grace=0;
  await new Promise(r=>setTimeout(r,1200));return !!g.B;});
 // inside triggers
 out.aggroInside=await pg.evaluate(async()=>{const g=__game;park();const d=g.enemies.find(o=>o.type==='dragon');
  d.x=31.5*32;d.y=4*32;d.fa=Math.PI/2;d.ta=d.fa;d.mode='look';d.mt=1e9;d.lk=1e9;g.P.x=31.5*32;g.P.y=7*32;g.P.grace=0;
  await new Promise(r=>setTimeout(r,1200));return !!g.B;});
 await pg.close();
 // 3. fight inside, then player runs out the gate: dragon never leaves, attacks reach through LOS, gives up and goes home
 pg=await fresh();
 out.flee=await pg.evaluate(async()=>{const g=__game,d0=g.dbg;park();const d=g.enemies.find(o=>o.type==='dragon');
  d.x=31.5*32;d.y=9*32;g.P.x=31.5*32;g.P.y=9.6*32;g.P.grace=99;g.P.hp=1e6;g.tp(31,9);g.P.x=31.5*32;g.P.y=9.6*32;
  d0.startEncounter(d,true);const B=g.B;B.phase='fight';d.joinT=0;d.hp=d.maxhp;d.atkCd=.3;
  const t=d.terr;let viol=0,maxY=0;const log={};
  await new Promise(r=>setTimeout(r,800));
  g.P.x=31.5*32;g.P.y=14*32;           // teleport outside, straight south of the gate (clear LOS)
  const hp0=g.P.hp;let engagedAfter=[];
  for(let i=0;i<70;i++){await new Promise(r=>setTimeout(r,100));g.P.x=31.5*32;g.P.y=14*32;g.P.hp=Math.max(g.P.hp,1e6-1e5);
    if(d.y>t.y1+.5||d.x>t.x1+.5||d.x<t.x0-.5)viol++;maxY=Math.max(maxY,d.y);engagedAfter.push(!!g.B);}
  return {violations:viol,maxDragonY:Math.round(maxY),terrY1:t.y1,battleEndedAt:engagedAfter.indexOf(false)*0.1,dragonEngaged:d.engaged,dragonHpReset:d.hp===d.maxhp,dmgTakenOutside:hp0-g.P.hp>0};});
 await pg.close();
 // 4. mobile quick run
 pg=await fresh(true);out.mobileOk=await pg.evaluate(()=>{const d=__game.enemies.find(o=>o.type==='dragon');return !!d.terr;});await pg.close();
 console.log(JSON.stringify(out,null,1),errs);await b.close();})();
