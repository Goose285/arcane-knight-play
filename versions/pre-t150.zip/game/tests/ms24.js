// M24: roads have no single-tile notches; dirt paths are drawn as soft gravel with wobbling edges.  node tests/ms24.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms24');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.setTimeOfDay(.45);g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});g.P.grace=9999;});
 const a=await E(()=>{const d=__game.dbg,m=d.map,T=d.T,P=(x,y)=>x>=0&&y>=0&&x<64&&y<224&&m[y][x]===T.P;const bad=[];
   for(let y=0;y<224;y++)for(let x=0;x<64;x++){if(m[y][x]===T.P||m[y][x]===T.GT||m[y][x]===T.GX)continue;const n=P(x,y-1)+P(x,y+1)+P(x-1,y)+P(x+1,y);if(n>=3)bad.push([x,y]);}
   return {bad,fixed:[[12,24],[6,39],[21,39],[43,38],[54,38],[47,41]].map(([x,y])=>P(x,y)),col12:[...Array(29).keys()].map(i=>i+14).filter(y=>!P(12,y)&&y<37).concat([...Array(8).keys()].map(i=>i+39).filter(y=>!P(12,y))),col13:[14,20,24,30,36,40,44].map(y=>P(13,y))};});
 ok(a.bad.length===0,'no grass/tree tile boxed in by road on 3+ sides ('+JSON.stringify(a.bad)+')');
 ok(a.fixed.every(Boolean),'the notch tile left of the village N-S road (12,24) and the other gaps are dirt now ('+a.fixed+')');
 ok(a.col12.length<=3,'the village N-S road is continuous on its left column (x=12; non-road rows: '+a.col12+')');
 // gravel sprites: soft irregular edges, aligned with world coordinates
 const g=await E(()=>{const d=__game.dbg,T=d.T,px=(c)=>{const q=c.getContext('2d').getImageData(0,0,16,16).data,o=[];for(let i=0;i<256;i++)o.push([q[i*4],q[i*4+1],q[i*4+2]]);return o;};
   const isDirt=p=>p[0]>170&&p[1]>140&&p[2]>90&&p[2]<190&&p[0]-p[2]>30,isGrass=p=>p[1]>p[0]+20&&p[1]>p[2]+30;
   const s1=__game.tileSpriteOf(T.P,12,20,0),s3=__game.tileSpriteOf(T.P,12,21,0);
   const edgeCol=[];let d1=0,g1=0,creep=0;
   for(let y=15;y<30;y++){const A=px(__game.tileSpriteOf(T.P,12,y,0));if(y===20){d1=A.filter(isDirt).length;g1=A.filter(isGrass).length;}
     for(let r=0;r<16;r++){let n=0;for(let x=0;x<16;x++)if(isGrass(A[r*16+x]))n++;else break;edgeCol.push(n);}
     const G=px(__game.tileSpriteOf(T.G,11,y,0));for(let r=0;r<16;r++)for(let x=12;x<16;x++)if(isDirt(G[r*16+x]))creep++;}
   return {edgeCol:[Math.min(...edgeCol),Math.max(...edgeCol)],d1,g1,same:__game.tileSpriteOf(T.P,12,20,0)===s1,creep,distinct:new Set([s1,s3].map(c=>c.toDataURL())).size};});
 const spread=g.edgeCol[1]-g.edgeCol[0];
 ok(g.d1>120&&g.g1>0,'road-edge tile is mostly gravel with grass creeping in ('+g.d1+' dirt px, '+g.g1+' grass px)');
 ok(spread>=2,'the edge is irregular, not a straight tile line (grass depth varies by '+spread+' px, '+g.edgeCol+')');
 ok(g.creep>0,'dirt spills a little onto the grass next to the road ('+g.creep+' px)');
 ok(g.same,'sprites are cached per tile');ok(g.distinct===2,'neighbouring tiles differ (no repeating pattern)');
 // a straight road interior is seamless: right edge of (13,20) meets left edge of next road tile
 const t0=await E(()=>{const d=__game.dbg,T=d.T,t=performance.now();let n=0;for(let y=14;y<44;y++)for(let x=8;x<20;x++){__game.tileSpriteOf(d.map[y][x],x,y,0);n++;}return {n,ms:performance.now()-t};});
 ok(t0.ms<400,'building the whole village road set is fast ('+t0.ms.toFixed(0)+' ms for '+t0.n+' tiles)');
 const t1=await E(()=>{const d=__game.dbg,t=performance.now();for(let k=0;k<20;k++)for(let y=14;y<44;y++)for(let x=8;x<20;x++)__game.tileSpriteOf(d.map[y][x],x,y,0);return performance.now()-t;});
 ok(t1<150,'cached lookups are cheap ('+t1.toFixed(0)+' ms for 7200 lookups)');
 await E(()=>{const g=__game;g.tp(13,26);g.P.grace=9999;g.dbg.TRK.open=false;g.dbg.toasts.length=0;});await sleep(3600);await E(()=>{__game.dbg.toasts.length=0;__game.dbg.TRK.open=false;});
 await shot(MOBILE?'path-edges.png':'path-edges-desktop.png');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
