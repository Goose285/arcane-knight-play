// M15: charge SHOT while exploring, tutorial completable in town (training slime), 'escaping' only when truly breaking away.  node tests/ms15.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE,tap}=await boot('ms15');
 await E(()=>{window.__NOACH=true;});
 const calm=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.P.grace=99;g.P.hp=d.maxHp();d.WCH.on=false;});
 // hold/release the SHOT control with real input
 let th=null;
 const atkXY=()=>E(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,b=__game.btn.atk;return {x:c.left+b.x/z.VW*c.width,y:c.top+b.y/z.VH*c.height};});
 const shotDown=async()=>{if(MOBILE){const c=await atkXY();th=await pg.touchscreen.touchStart(c.x,c.y);}else await pg.keyboard.down('KeyJ');};
 const shotUp=async()=>{if(MOBILE){await th.end();th=null;}else await pg.keyboard.up('KeyJ');};
 // a slime standing in the open town row, hero facing it
 const place=async()=>{await calm();await E(()=>{const g=__game,d=g.dbg;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;});
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.engaged=false;e.x=e.hx=5*32+16;e.y=e.hy=38*32+28;e.hp=e.maxhp=e.mhp=9000;e.mt=1e9;e.lk=1e9;
   g.tp(10,38);g.P.x=10*32+16;g.P.y=38*32+28;g.P.aim=Math.PI;g.P.dir='l';g.P.grace=99;window.__sl=e;g.toasts&&0;d.toasts.length=0;});await sleep(150);};
 const shots=()=>E(()=>__game.dbg.WS.map(s=>s.kind));

 // ===== A. overworld charge =====
 await place();
 await shotDown();await sleep(450);
 let a=await E(()=>({on:__game.dbg.WCH.on,t:__game.dbg.WCH.t,ws:__game.dbg.WS.length,b:!!__game.B}));
 ok(a.on&&a.t>.3,'holding SHOT outside combat starts charging (t='+a.t.toFixed(2)+')');
 ok(a.ws===0&&!a.b,'holding does not auto-fire normal shots');
 await sleep(800);
 a=await E(()=>({t:__game.dbg.WCH.t,ws:__game.dbg.WS.length}));ok(a.t>=1&&a.ws===0,'charge reaches full (t='+a.t.toFixed(2)+') and keeps holding');
 await shot('overworld-charge.png');
 await shotUp();await sleep(40);
 ok((await shots()).includes('charged'),'releasing at full charge fires a CHARGED shot');
 await sleep(900);
 let r=await E(()=>({b:!!__game.B,hp:window.__sl.hp,max:window.__sl.maxhp,eng:window.__sl.engaged,ws:__game.dbg.WS.length,on:__game.dbg.WCH.on}));
 ok(r.b&&r.eng,'charged shot that hits an enemy starts the fight');
 const dC=r.max-r.hp;ok(dC>0,'charged damage applied on the opening hit ('+dC+')');
 ok(!r.on,'charge state cleared after release');
 // quick tap = normal shot, damage much smaller
 await place();await shotDown();await sleep(60);await shotUp();await sleep(40);
 ok((await shots()).includes('arcane')&&!(await shots()).includes('charged'),'a quick tap fires a normal shot');
 await sleep(900);
 r=await E(()=>({b:!!__game.B,d:window.__sl.maxhp-window.__sl.hp}));ok(r.b&&r.d>0&&dC>2.5*r.d,'tap opening hit is much weaker than the charged one ('+r.d+' vs '+dC+')');
 // half charge released early = normal shot
 await place();await shotDown();await sleep(500);await shotUp();await sleep(40);
 ok((await shots()).includes('arcane')&&!(await shots()).includes('charged'),'releasing before full charge fires a normal shot');
 // does not charge next to a villager (still talks) and nothing breaks in a fight
 await calm();await E(()=>{const g=__game,n=g.npcs[0];g.P.x=n.x;g.P.y=n.y+8;});await sleep(100);
 await shotDown();await sleep(200);await shotUp();await sleep(200);
 ok(await E(()=>!!__game.DLG),'SHOT next to a villager still opens dialogue');await calm();
 // charge ring on the touch button / keyboard path: fight begins mid-hold -> no stray charge
 await place();await shotDown();await sleep(1250);await E(()=>{const g=__game;g.dbg.startEncounter(window.__sl,true);g.B.phase='fight';});await sleep(250);
 ok(await E(()=>!__game.dbg.WCH.on),'fight starting mid-hold clears the overworld charge');
 await shotUp();await sleep(100);ok(await E(()=>!!__game.B),'releasing after the fight started is harmless');

 // ===== B. tutorial end to end, entirely in town =====
 await calm();
 await E(()=>{window.__NOTUT=false;const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});d.SET.tutDone=false;
   g.tp(14,40);g.P.grace=99;g.P.hp=d.maxHp();window.__gold0=g.P.gold;window.__start={x:g.P.x,y:g.P.y};d.tutStart();d.TUT.gap=0;});
 await sleep(200);
 const idx=()=>E(()=>__game.dbg.TUT.i);
 await E(()=>{const g=__game;g.P.x+=60;});await sleep(150);await E(()=>{__game.P.x+=60;});await sleep(250);ok((await idx())===1,'tutorial: move step done');
 await E(()=>{__game.dbg.TUT.gap=0;__game.press('KeyJ');});await sleep(300);ok((await idx())===2,'tutorial: shoot step done');
 await E(()=>{__game.dbg.TUT.gap=0;__game.DLG={name:'ELDER ORIN',lines:['hi'],i:0,c:0};});await sleep(300);ok((await idx())===3,'tutorial: talk step done');await E(()=>{__game.DLG=null;__game.dbg.TUT.gap=0;});
 await E(()=>{__game.state='paused';});await sleep(300);ok((await idx())===4,'tutorial: pause step done');await E(()=>{__game.state='play';__game.dbg.TUT.gap=0;});
 await sleep(500);
 const dm=await E(()=>{const g=__game,d=g.dbg,m=d.tutDummyOf();return m?{near:Math.hypot(m.x-g.P.x,m.y-g.P.y),alive:m.alive,x:m.x,y:m.y,B:!!g.B,real:g.enemies.filter(e=>!e.tut&&e.alive&&Math.hypot(e.x-g.P.x,e.y-g.P.y)<250).length}:null;});
 ok(!!dm&&dm.alive&&dm.near<140,'tutorial: a training slime appears right next to the hero in town');
 ok(dm&&dm.real===0,'tutorial: no real monster nearby (training slime is the only target)');
 await shot('tutorial-dummy.png');
 // shoot it: face it and press shot; it must not hurt us
 await E(()=>{const g=__game,m=g.dbg.tutDummyOf();g.P.aim=Math.atan2(m.y-12-(g.P.y-12),m.x-g.P.x);g.dbg.TUT.gap=0;});
 await E(()=>{__game.keys.KeyJ=true;__game.press('KeyJ');});await sleep(120);await E(()=>{__game.keys.KeyJ=false;});
 await sleep(1500);
 const fin=await E(()=>{const g=__game,d=g.dbg;return {B:!!g.B,on:d.TUT.on,done:d.SET.tutDone,gold:g.P.gold-window.__gold0,hp:g.P.hp,max:d.maxHp(),toast:d.toasts.some(t=>/TUTORIAL COMPLETE/.test(t.s)),moved:Math.hypot(g.P.x-window.__start.x,g.P.y-window.__start.y)};});
 ok(fin.B,'tutorial: shooting the training slime starts a battle');
 ok(!fin.on&&fin.done&&fin.toast&&fin.gold>=50,'tutorial: completes with the reward (gold +'+fin.gold+')');
 ok(fin.moved<260,'tutorial: whole thing finished without leaving town ('+Math.round(fin.moved)+'px)');
 await sleep(2500);
 ok(await E(()=>__game.P.hp===__game.dbg.maxHp()),'tutorial: training slime is harmless');
 await E(()=>{const g=__game,m=g.dbg.tutDummyOf();g.dbg.damageEnemy(m,m.hp+9999,'fire');});await sleep(2500);
 ok(await E(()=>!__game.dbg.tutDummyOf()||!__game.B),'tutorial: training slime can be defeated');
 await E(()=>{__game.dbg.endFight();});await sleep(400);
 ok(await E(()=>!__game.dbg.tutDummyOf()),'tutorial: training slime is removed afterwards');
 // skipping while the slime is out removes it too
 await E(()=>{const g=__game,d=g.dbg;d.SET.tutDone=false;d.tutStart();d.TUT.gap=0;d.TUT.i=4;});await sleep(500);
 ok(await E(()=>!!__game.dbg.tutDummyOf()),'tutorial replay: slime spawns again on the fight step');
 await E(()=>{__game.dbg.tutFinish(true);});await sleep(300);ok(await E(()=>!__game.dbg.tutDummyOf()),'tutorial skip: slime removed');
 await E(()=>{window.__NOTUT=true;});

 // ===== C. 'escaping' only when truly breaking away =====
 const geo=await E(()=>{const d=__game.dbg,free=(x,y)=>!d.wallT(x,y)&&!d.wallT(x,y-12);
   let open=null,blocked=null;
   for(let ty=3;ty<MH_();ty++){let run=0;for(let tx=2;tx<100;tx++){if(free(tx*32+16,ty*32+28)){run++;if(run>=17&&!open)open={y:ty*32+28,x0:(tx-16)*32+16,x1:tx*32+16};}else run=0;}}
   function MH_(){return 60;}
   // a wall between two open stretches (distance 340..460 apart, LOS blocked)
   for(let ty=3;ty<60&&!blocked;ty++)for(let tx=2;tx<90&&!blocked;tx++){
     let ok=true;for(let k=0;k<4;k++)if(!free((tx+k)*32+16,ty*32+28))ok=false;
     if(!ok||free((tx+4)*32+16,ty*32+28)===true)continue;
     // wall tile at tx+4; open again from tx+5..tx+9
     let ok2=true;for(let k=5;k<=9;k++)if(!free((tx+k)*32+16,ty*32+28))ok2=false;
     if(ok2)blocked={y:ty*32+28,x0:tx*32+16,x1:(tx+9)*32+16+130};}
   return {open,blocked};});
 ok(!!geo.open,'found a long open corridor for the escape test');
 ok(!!geo.blocked,'found a wall-separated spot for the escape test');
 const esc=(setupFn,arg)=>E((f,arg)=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.P.grace=99;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.engaged=false;e.hp=e.maxhp=e.mhp=9999;
   const fn=new Function('g','e','a','return ('+f+')(g,e,a)');fn(g,e,arg);
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.escD=null;B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;o.stun=99;});window.__e=e;return true;},setupFn.toString(),arg);
 const probe=()=>E(()=>{const d=__game.dbg,B=__game.B;B.escD=null;d.breakingAway(.016);return d.breakingAway(.016);});
 if(geo.open){
  // enemy 11.5 tiles away (368px, beyond the leash) but in clear sight: not escaping
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+368;e.y=e.hy=a.y;},geo.open);
  ok(await E(()=>Math.hypot(__e.x-__game.P.x,__e.y-__game.P.y)>__game.dbg.FLEE_DIST),'escape test: foe is beyond the leash distance');
  ok((await probe())===false,'not escaping while a foe beyond the leash still has a clear line of sight');
  // 520px away in the open: truly out of range -> escaping
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+520;e.y=e.hy=a.y;},geo.open);
  ok((await probe())===true,'escaping when far away with the foe not closing in');
  // foe winding up an attack: never escaping
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+520;e.y=e.hy=a.y;},geo.open);
  await E(()=>{__e.st='windup';});ok((await probe())===false,'not escaping while a foe is winding up an attack');
  // close foe: never escaping
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+150;e.y=e.hy=a.y;},geo.open);
  ok((await probe())===false,'not escaping with a foe close by');
  // closing in fast: not escaping even if far
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+520;e.y=e.hy=a.y;},geo.open);
  ok(await E(()=>{const d=__game.dbg,B=__game.B;B.escD=1200;return d.breakingAway(.016)===false;}),'not escaping when the foe is closing in on you');
 }
 if(geo.blocked){
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+9*32+4*0+130-130+0;e.y=e.hy=a.y;},geo.blocked);
  const dd=await E(()=>Math.hypot(__e.x-__game.P.x,__e.y-__game.P.y));
  ok(dd<340,'wall test: foe behind a wall is within the leash ('+Math.round(dd)+')');ok((await probe())===false,'not escaping while a foe is just behind a wall');
 }
 // full run: really run far away -> "You got away!" after the leash timer; staying near -> never
 if(geo.open){
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+368;e.y=e.hy=a.y;e.stun=99;},geo.open);
  await sleep(3200);ok(await E(()=>!!__game.B&&__game.B.fleeT<.1),'foe in sight beyond the leash: the escape bar never fills');
  await esc((g,e,a)=>{g.tp(Math.floor(a.x0/32),Math.floor(a.y/32));g.P.x=a.x0;g.P.y=a.y;e.x=e.hx=a.x0+520;e.y=e.hy=a.y;},geo.open);
  await sleep(600);ok(await E(()=>!!__game.B&&__game.B.fleeT>.1),'really breaking away fills the escape bar');
  await sleep(2400);ok(await E(()=>!__game.B),'...and the monster gives up (You got away!)');
 }
 // castle: a real fight next to the castle foes does not show ESCAPING
 const cas=await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.P.grace=99;
   const e=g.enemies.find(x=>x.type==='knight'&&!x.def.boss);let spot=null;const fr=(tx,ty)=>!d.wallT(tx*32+16,ty*32+28)&&!d.wallT(tx*32+16,ty*32+16);
   for(let ty=2;ty<14&&!spot;ty++)for(let tx=8;tx<30&&!spot;tx++)if(d.regions.castle(tx,ty)&&fr(tx,ty)&&fr(tx,ty+2)&&d.losW({x:tx*32+16,y:ty*32+28},0,{x:tx*32+16,y:(ty+2)*32+28},0))spot={tx,ty};
   if(!e||!spot)return null;
   e.alive=true;e.dying=false;e.engaged=false;e.x=e.hx=spot.tx*32+16;e.y=e.hy=spot.ty*32+28;g.tp(spot.tx,spot.ty+2);g.P.x=spot.tx*32+16;g.P.y=(spot.ty+2)*32+28;
   d.startEncounter(e,true);g.B.phase='fight';g.B.ens.forEach(o=>{o.joinT=0;});window.__ce=e;return true;});
 ok(!!cas,'castle: a castle knight fight starts');
 if(cas){let maxF=0;for(let i=0;i<20;i++){await sleep(150);maxF=Math.max(maxF,await E(()=>__game.B?__game.B.fleeT:0));}
  ok(maxF<.1&&await E(()=>!!__game.B),'castle: no escaping while standing next to the foes (max fleeT '+maxF.toFixed(2)+')');}
 await E(()=>{__game.dbg.endFight();});

 // ===== D. shorter night =====
 const cyc=await E(()=>{const d=__game.dbg,o={},N=2000;let a55=0,a0=0,full=0,tw=0;
   const save=d.DAY.t;
   for(let i=0;i<N;i++){d.setTimeOfDay(i/N);const n=d.DAY.nightAmt;if(n>.55)a55++;if(n>.001)a0++;if(n>.999)full++;}
   o.len=d.DAY.len;o.nightSec=a55/N*d.DAY.len;o.darkSpan=a0/N*d.DAY.len;o.fullSec=full/N*d.DAY.len;
   // night flag with hysteresis, walking forward through a whole cycle
   d.setTimeOfDay(.5);let on=0,flips=0,was=d.DAY.night;for(let i=0;i<=N;i++){d.setTimeOfDay(.5+i/N);if(d.DAY.night)on++;if(d.DAY.night!==was){flips++;was=d.DAY.night;}}
   o.flagSec=on/N*d.DAY.len;o.flips=flips;
   d.setTimeOfDay(.5);o.noon=d.DAY.nightAmt;d.setTimeOfDay(1);o.mid=d.DAY.nightAmt;d.setTimeOfDay(.75);o.six=d.DAY.nightAmt;d.setTimeOfDay(.25);o.dawn=d.DAY.nightAmt;
   // dusk/dawn are short: from 'dark' to 'day' takes at most ~5% of the cycle
   let lo=1,hi=0;for(let i=0;i<=N/2;i++){d.setTimeOfDay(1-i/N);const n=d.DAY.nightAmt;if(n>.999)lo=Math.min(lo,i);if(n<.001&&hi===0)hi=i;}
   o.fadeSec=(hi-0)/N*d.DAY.len-(.10*d.DAY.len);d.setTimeOfDay(.5);return o;});
 ok(cyc.len===480,'cycle is still 8 minutes');
 ok(cyc.nightSec>=100&&cyc.nightSec<=135,'night (monster night) lasts about 2 minutes ('+cyc.nightSec.toFixed(0)+'s of 480)');
 ok(cyc.fullSec>=90&&cyc.fullSec<=100,'full dark about 96s ('+cyc.fullSec.toFixed(0)+'s)');
 ok(cyc.darkSpan<=150&&cyc.darkSpan>=140,'dusk + dark + dawn together about 30% of the cycle ('+cyc.darkSpan.toFixed(0)+'s)');
 ok(cyc.fadeSec>=20&&cyc.fadeSec<=28,'dusk/dawn transition is short (~24s, got '+cyc.fadeSec.toFixed(0)+'s)');
 ok(cyc.flagSec>=100&&cyc.flagSec<=135&&cyc.flips===2,'night flag turns on once and off once per cycle ('+cyc.flips+' flips, '+cyc.flagSec.toFixed(0)+'s)');
 ok(cyc.noon<.01&&cyc.mid>.99&&cyc.six<.01&&cyc.dawn<.01,'noon bright, midnight dark, sunset/sunrise already light');

 // ===== E. light sources at Brum's =====
 const li=await E(()=>{const g=__game,d=g.dbg,o={};d.endFight();g.state='play';d.setTimeOfDay(1);g.P.x=10*32;g.P.y=38*32;g.P.lv=5;
   o.list=d.LIGHTS.map(l=>l.id+':'+l.price+':'+l.r).join(' ');o.asc=d.LIGHTS.every((l,i)=>!i||(l.r>d.LIGHTS[i-1].r&&l.price>d.LIGHTS[i-1].price))&&d.LIGHTS.length>=4;
   d.LGT.own={};d.LGT.eq=null;d.LGT.on=true;
   o.base=d.collectLights(false)[0].r;
   g.P.gold=50;o.poor=d.buyLight('torch')===false&&g.P.gold===50&&!d.LGT.own.torch;
   g.P.gold=100;o.buy=d.buyLight('torch')===true&&g.P.gold===100-d.LIGHT_BY.torch.price&&d.LGT.own.torch&&d.LGT.eq==='torch';
   o.dup=d.buyLight('torch')===false;
   o.torchR=d.collectLights(false)[0].r;
   g.P.gold=5000;d.buyLight('lantern');d.buyLight('enchant');d.buyLight('sunstone');
   o.sun=d.LGT.eq==='sunstone'&&d.collectLights(false)[0].r===d.LIGHT_BY.sunstone.r;
   o.crypt=d.collectLights(true)[0].r>d.LIGHT_BY.sunstone.r;
   d.equipLight('lantern');o.lan=d.collectLights(false)[0].r===d.LIGHT_BY.lantern.r;
   d.toggleLight();o.off=d.collectLights(false)[0].r===o.base;d.toggleLight();o.on=d.collectLights(false)[0].r===d.LIGHT_BY.lantern.r;
   o.lockedEquip=(()=>{d.LGT.own={torch:true};return d.equipLight('sunstone')===false;})();
   d.LGT.own={torch:true,lantern:true,sunstone:true};d.LGT.eq='sunstone';d.LGT.on=false;g.saveGame('t');
   const s=g.readSave();o.saved=!!s.craft&&!!s.craft.light&&s.craft.light.eq==='sunstone'&&s.craft.light.on===false&&s.craft.light.own.lantern===true&&!s.craft.light.own.enchant;
   d.LGT.own={};d.LGT.eq=null;d.LGT.on=true;g.loadSave(s);
   o.loaded=d.LGT.eq==='sunstone'&&d.LGT.on===false&&d.LGT.own.torch&&d.LGT.own.sunstone&&!d.LGT.own.enchant;
   return o;});
 console.log('  lights:',li.list);
 ok(li.asc,'4 light tiers, radius and price both increase');
 ok(li.base===104,'no light: base glow radius 104');ok(li.poor,'cannot buy a light without gold');ok(li.buy&&li.dup,'buying spends gold, auto-equips, cannot buy twice');
 ok(li.torchR>li.base,'torch widens the glow');ok(li.sun&&li.lan,'higher tiers glow wider; equip switches');ok(li.crypt,'lights also widen the glow in the crypt');
 ok(li.off&&li.on,'toggling the light off/on changes the radius');ok(li.lockedEquip,'cannot equip a light you do not own');
 ok(li.saved,'owned/equipped/on state is written to the save');ok(li.loaded,'...and restored on load');
 // workbench UI: buy + equip buttons and Brum opens it
 await calm();await E(()=>{const g=__game,d=g.dbg;g.P.gold=3000;d.LGT.own={};d.LGT.eq=null;d.LGT.on=true;d.openShop?d.openShop():0;});await sleep(300);
 
 
 ok(await tap('light:torch',null),'Brum shop: BUY button for the torch is on screen');await sleep(200);
 ok(await E(()=>__game.dbg.LGT.own.torch&&__game.dbg.LGT.eq==='torch'&&__game.P.gold===3000-__game.dbg.LIGHT_BY.torch.price),'Brum shop: tapping BUY buys and equips the torch');
 ok(await tap('light:lantern',null),'Brum shop: lantern row');await sleep(200);ok(await E(()=>__game.dbg.LGT.eq==='lantern'),'lantern bought and equipped');
 ok(await tap('light:torch',null),'torch EQUIP button');await sleep(200);ok(await E(()=>__game.dbg.LGT.eq==='torch'),'owned light can be equipped from the shop');
 ok(await tap('light:torch',null),'torch UNEQUIP button');await sleep(200);ok(await E(()=>__game.dbg.LGT.eq===null),'equipped light can be put away from the shop');
 await E(()=>{__game.dbg.equipLight('lantern');});await sleep(150);
 await shot('light-shop.png');
 await E(()=>{__game.dbg.UI.mode=null;__game.state='play';});
 // night with a light vs without: screenshot pixels around the hero are brighter with the sunstone
 await calm();await E(()=>{const g=__game,d=g.dbg;g.tp(13,38);d.setTimeOfDay(1);d.LGT.own={sunstone:true};d.LGT.eq=null;});await sleep(500);
 const lum=()=>E(()=>{const c=document.getElementById('c'),x=c.getContext('2d'),w=c.width,h=c.height,s=Math.floor(Math.min(w,h)*.35);let t=0;const im=x.getImageData(Math.floor(w/2-s),Math.floor(h/2-s),s*2,s*2).data;for(let i=0;i<im.length;i+=16)t+=im[i]+im[i+1]+im[i+2];return t/(im.length/16);});
 const l0=await lum();await shot('night-nolight.png');
 await E(()=>{__game.dbg.LGT.eq='sunstone';});await sleep(400);const l1=await lum();await shot('night-sunstone.png');
 ok(l1>l0*1.25,'screen around the hero is clearly brighter at night with a Sunstone ('+Math.round(l0)+' -> '+Math.round(l1)+')');
 await E(()=>{const d=__game.dbg;d.LGT.own={};d.LGT.eq=null;d.setTimeOfDay(.5);});
 await finish();
})().catch(e=>{console.error(e);process.exit(1);});
