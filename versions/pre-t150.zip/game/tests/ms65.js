// M65 (t148u): black holes gone, house HUD not enlarged, joystick hidden in dialog, tut slimes north + guard-safe,
// fishing max 70 + banner, OSRS quest list, planters, tavern, smith shop, water life, moss.  node tests/ms65.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms65',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t148/.test(tags),'backup tag backup-pre-t148');
 await E(()=>__game.dbg.startFromTitle());await sleep(800);
 // house HUD: S must NOT bump inside house
 let s=await E(()=>{const s0=S;P.x=SPAWN.x;P.y=SPAWN.y;if(typeof houseZoomWant==='function'){HZ=true;resize();}const sHouse=S;HZ=false;resize();return {s0,sHouse,S};});
 ok(s.sHouse===s.S||s.sHouse<=s.s0+0,'house does not bump pixel scale S ('+s.sHouse+' vs '+s.S+')');
 // joystick hidden during DLG (hud-hd owns the hide; perf.js may wrap drawTouch for FPS overlay)
 ok(fs.readFileSync(__dirname+'/../src/ui/hud-hd.js','utf8').includes('hide the left stick'),'drawTouch hides the stick during dialog');
 // tut slimes further north + tutSlime flag + guards skip them
 s=await E(()=>{const sl=enemies.filter(e=>e.type==='slime'&&e.tutSlime);const ys=sl.map(e=>e.y/32);const townY=TOWN.y0/32;return {n:sl.length,maxY:ys.length?Math.max(...ys):-1,townY,gap:townY-(ys.length?Math.max(...ys):townY),skip:String(guardTarget).includes('tutSlime')};});
 ok(s.n>=3&&s.gap>=8,'tut slimes live further north of the gate (n='+s.n+' gap='+s.gap.toFixed(1)+' tiles)');
 ok(s.skip,'guards skip tutSlime');
 // fishing max 70 + banner level-up
 s=await E(()=>({max:FISH_MAX_LV,banner:String(addFishXp).includes('areaCur')||String(addFishXp).includes('FISHING')}));
 ok(s.max===70,'fishing max level is 70');ok(s.banner,'fishing level-up uses the banner');
 // quest list OSRS sections
 s=await E(()=>{openQuests();const rows=UI_MODES.quests.rows();const heads=rows.filter(r=>r.t==='head').map(r=>r.s);try{if(typeof closeUI==='function')closeUI();else state='play';}catch(e){state='play';}return heads;});
 ok(s.some(h=>/MAIN/.test(h))&&s.some(h=>/SIDE/.test(h)),'quest list has MAIN and SIDE sections '+JSON.stringify(s));
 // planters / tavern / smith shop / water life
 s=await E(()=>{try{if(!PLANTERS.length){const oy=OWY0|0;for(const [x,y] of [[18,32],[20,32],[22,32],[13,35],[26,35],[19,41]]){const ty=y+oy;if(map[ty]&&(map[ty][x]===T.G||map[ty][x]===T.L||map[ty][x]===T.K)){map[ty][x]=T.PLB;PLANTERS.push([x,ty]);}}} WLIFE.built=false;wlifeBuild(); if(!TAVERN.ready)buildTavern(); if(!SMITH_SHOP.ready)buildSmithShop();}catch(e){} return {plb:PLANTERS.length,tav:!!TAVERN.ready,smith:!!SMITH_SHOP.ready,pads:WLIFE.pads.length,fish:WLIFE.fish.length,mara:NPCS.some(n=>n.name==='Mara the Tapster')};});
 ok(s.plb>=3,'planter boxes placed ('+s.plb+')');
 ok(s.tav&&s.mara,'tavern built with Mara');
 ok(s.smith,'blacksmith shop interior built');
 ok(s.pads>0&&s.fish>0,'water life (pads '+s.pads+', fish '+s.fish+')');
 // combat alert shorter
 s=await E(()=>QUAL.locked===true&&QUAL.wantDpr<=2);
 ok(s,'quality locked (DPR cap <=2, perf wants 1)');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');ok(/arcane-knight-v5[4-9]/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v54+');
 await sleep(400);ok(errs.length===0,'no page errors '+errs.slice(0,3).join(' | '));
 await finish();
})();
