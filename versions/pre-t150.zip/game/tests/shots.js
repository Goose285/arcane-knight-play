// Store screenshots: node tests/shots.js [gear|loot|pause|...]   -> store/*.png  (phone-landscape-ish 844x390 and desktop)
const puppeteer=require('puppeteer-core');const path=require('path');const fs=require('fs');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const URL='file://'+path.join(__dirname,'..','index.html');const OUT=path.join(__dirname,'..','store');
const want=process.argv.slice(2);
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});await pg.setViewport({width:960,height:640});
 const E=(f,...a)=>pg.evaluate(f,...a);
 await pg.goto(URL);await pg.evaluate(()=>localStorage.clear());await pg.goto(URL);await sleep(500);await pg.keyboard.press('Space');await sleep(500);
 const shot=async n=>{await sleep(250);await pg.screenshot({path:path.join(OUT,n+'.png')});console.log('shot',n);};
 const on=n=>!want.length||want.includes(n);
 await E(()=>{const g=__game;g.P.hp=1e6;g.P.grace=99;g.P.lv=6;g.P.gold=840;});
 if(on('gear')||on('loot')){
  await E(()=>{const d=__game.dbg;d.resetGear();
    const mk=(s,l,r)=>d.genGear(s,l,r);
    d.addGear(d.genGear('weapon',9,'epic'));d.equipGear(d.GEAR.inv[0]);
    const a=d.genGear('armor',7,'rare');d.addGear(a);d.equipGear(a);
    d.addGear(d.genGear('weapon',12,'legendary'));d.addGear(d.genGear('armor',10,'uncommon'));d.addGear(d.genGear('ring',8,'epic'));d.addGear(d.genGear('ring',3,'common'));});
  await E(()=>{__game.state='paused';});await sleep(300);await shot('pause-menu');
  await E(()=>{__game.dbg.openGear();});await sleep(300);await shot('equipment-screen');
  await E(()=>{__game.dbg.UI.scroll=1e6;});await shot('equipment-backpack');
  await E(()=>{__game.dbg.closeUI();__game.state='play';});await sleep(200);
  // hero with gear on the overworld
  await E(()=>{__game.tp(10,38);});await sleep(500);await shot('hero-with-gear');
 }
 if(on('loot')){
  await E(()=>{const g=__game,d=g.dbg;
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;e.engaged=false;});
   const e=g.enemies.find(o=>o.type==='knight');g.tp(10,38);e.x=g.P.x+40;e.y=g.P.y;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;
   window.__r=Math.random;Math.random=()=>0.001;d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=1;
   B.shots.push({x:e.x,y:e.y-13,vx:0,vy:0,r:10,dmg:50,own:'p',kind:'arcane',life:1,a:0});});
  await pg.waitForFunction(()=>__game.B&&__game.B.phase==='reward',{timeout:15000});await E(()=>{Math.random=window.__r;const g=__game,d=g.dbg;const dr=g.B.drops.find(x=>x&&x.item);if(dr){const it=d.genGear('armor',11,'epic');d.addGear(it);dr.item=it;dr.name=it.name;dr.rar=it.rar;it.upgrade=true;const o=g.B.drops.slice();g.B.drops.push({name:'Ring of Ember',item:Object.assign(d.genGear('ring',9,'rare'),{auto:false}),rar:'rare',slot:'ring'});}});await sleep(2800);await shot('loot-screen');
 }
 if(on('quest')){
  await E(()=>{const g=__game,d=g.dbg;d.resetQuests();g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;e.engaged=false;});
   d.questStart('slimes');d.questEvent('kill','slime');d.questEvent('kill','slime');d.questEvent('kill','slime');
   d.questStart('gel');d.QS.items.gel=2;d.questStart('goblins');d.questEvent('kill','goblin');d.questEvent('kill','goblin');
   g.tp(14,37);});
  await E(()=>{__game.dbg.QS.st.slimes='ready';});
  await sleep(1200);await shot('quest-markers');
  await E(()=>{__game.state='paused';__game.dbg.openQuests();});await sleep(300);await shot('quest-log');
  await E(()=>{__game.dbg.closeUI();__game.state='play';});
  await E(()=>{const g=__game,d=g.dbg;d.QS.st.slimes='ready';d.questTalk(d.NPCS[0]);});await sleep(1500);await E(()=>{__game.DLG.c=999;});await sleep(300);await shot('quest-dialog');
 }
 if(on('dungeon')){
  await E(()=>{const g=__game,d=g.dbg;g.P.lv=12;g.P.grace=99;g.P.hp=1e6;g.tp(5,19);});await sleep(1500);
  await shot('dungeon-entrance-warp');
  await E(()=>{const g=__game;g.P.grace=99;g.tp(31,76);});await sleep(700);await shot('dungeon');
  await E(()=>{const g=__game;g.tp(30,69);});await sleep(700);await shot('dungeon-hub');
 }
 if(on('lich')){
  await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.P.lv=14;g.P.grace=0;g.P.hp=400;
   g.enemies.forEach(e=>{if(e.type!=='lich'){e.x=2*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;e.engaged=false;}});
   const e=g.enemies.find(o=>o.type==='lich');e.alive=true;e.dying=false;e.x=31.5*32;e.y=56.4*32;g.tp(31.5,58);g.P.x=31.5*32;g.P.y=58.6*32;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.p2=true;e.p3=true;e.hp=e.maxhp*.55;
   B.owner=e;let a;for(let i=0;i<200;i++){a=d.ATK.lich(e);if(a.zones.length&&a.zones[0].k==='ring')break;}d.startAttack(e,a);});
  await sleep(850);await shot('lich-king-fight');
  await E(()=>{const g=__game,d=g.dbg,B=g.B,e=B.ens[0];B.zones.length=0;e.st='idle';e.cur=null;B.owner=e;let a;for(let i=0;i<200;i++){a=d.ATK.lich(e);if(a.zones.length>=5&&a.zones[0].k==='line')break;}d.startAttack(e,a);});
  await sleep(600);await shot('lich-king-bolts');
 }
 if(on('night')){
  await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.P.lv=5;g.P.grace=99;g.P.hp=1e6;g.enemies.forEach(e=>{e.mt=1e9;});d.setTimeOfDay(1.0);g.tp(13,38);});
  await sleep(1500);await shot('night-village');
  await E(()=>{const g=__game,d=g.dbg;const w=g.enemies.find(e=>e.night&&e.type==='wraith'&&e.alive);if(w)g.tp(Math.floor(w.x/32)+3,Math.floor(w.y/32));g.P.grace=99;});
  await sleep(900);await shot('night-meadow-wraith');
  await E(()=>{const g=__game,d=g.dbg;g.tp(31,10);d.setTimeOfDay(.95);});
  await sleep(900);await shot('night-castle-torches');
 }
 await b.close();
})();
