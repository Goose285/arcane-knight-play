// M28: two-thumb touch layout. Card hand = fan around the SHOT button (right thumb), floating stick anywhere in the left half,
// bigger SHOT/CAST, safe margins, left-handed mirror, nothing over the stick zone.  node tests/ms28.js mobile [land|se]
const boot=require('./lib/ms');
(async()=>{
 const V=process.argv[3]||'port',dev=V==='land'?'iPhone 14 Pro landscape':V==='se'?'iPhone SE':'iPhone 14 Pro',suf=V==='port'?'':'-'+V;
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms28'+suf,{device:dev});
 if(!MOBILE){console.log('ms28 is touch-only');process.exit(0);}
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();});
 const css=(x,y)=>E((x,y)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+x/z.VW*c.width,y:c.top+y/z.VH*c.height,k:c.width/z.VW};},x,y);
 const setup=(hand)=>E(hand=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);d.toasts.length=0;d.TRK.open=false;
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;});
   g.tp(12,26);g.P.x=12*32+16;g.P.y=26*32+28;g.P.grace=99;g.P.aim=0;g.P.dir='r';const e=g.enemies.find(o=>o.type==='knight');e.x=e.hx=8*32;e.y=e.hy=26*32+28;e.hp=e.maxhp=e.mhp=99999;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(x=>{x.joinT=0;x.atkCd=1e9;});B.hand=hand;B.sel=0;B.inv=999;g.P.hp=d.maxHp();d.toasts.length=0;},hand);
 const H5=['frostbolt','sword','lance','fire','crimsonbolt'],H6=['frostbolt','sword','lance','fire','crimsonbolt','heal'];
 // geometry check, returns problems
 const geo=()=>E(()=>{const g=__game,z=g.size,R=g.cardRects,b=g.btn,jz=g.dbg.joyZone(),L=g.dbg.LEFTY,out={bad:[]};
   const corners=r=>{const c=Math.cos(r.rot),s=Math.sin(r.rot),hw=r.w/2,hh=r.h/2;return [[-hw,-hh],[hw,-hh],[hw,hh],[-hw,hh]].map(([x,y])=>({x:r.cx+x*c-y*s,y:r.cy+x*s+y*c}));};
   const dist=(r,p)=>{const dx=p.x-r.cx,dy=p.y-r.cy,c=Math.cos(-r.rot),s=Math.sin(-r.rot),lx=dx*c-dy*s,ly=dx*s+dy*c;const ex=Math.max(Math.abs(lx)-r.w/2,0),ey=Math.max(Math.abs(ly)-r.h/2,0);return Math.hypot(ex,ey);};
   let minx=1e9,maxx=-1e9,miny=1e9,maxy=-1e9;
   R.forEach((r,i)=>{const cs=corners(r);for(const q of cs){minx=Math.min(minx,q.x);maxx=Math.max(maxx,q.x);miny=Math.min(miny,q.y);maxy=Math.max(maxy,q.y);}
     for(const [n,c] of [['atk',b.atk],['pause',b.pause]])if(dist(r,c)<c.r+2)out.bad.push('card'+i+' touches '+n);});
   out.box={minx,maxx,miny,maxy};out.z=z;out.jz=jz;out.L=L;out.atk=b.atk;out.n=R.length;
   out.inSafe=minx>=z.SL&&maxx<=z.VW-z.SR&&miny>=z.ST&&maxy<=z.VH-z.SB;
   out.clearOfStick=L?maxx<=jz.x0:minx>=jz.x1;
   out.btnsClear=L?(b.atk.x+b.atk.r<=jz.x0):(b.atk.x+b.atk.r<=z.VW-z.SR&&b.atk.x-b.atk.r>=jz.x1);
   out.margin=L?Math.min(b.atk.x-b.atk.r-z.SL,z.VH-z.SB-b.atk.y-b.atk.r):Math.min(z.VW-z.SR-b.atk.x-b.atk.r,z.VH-z.SB-b.atk.y-b.atk.r);
   out.castSafe=!b.cast;   // the CAST button is gone
   return out;});
 const checkGeo=async(tag)=>{const o=await geo();
   ok(o.n>=5,tag+': fan of '+o.n+' cards');const nar=o.z.VW<340;ok(o.atk.r>=(nar?40:46)&&o.castSafe,tag+': big SHOT button (r '+o.atk.r+') and no CAST button');
   ok(o.bad.length===0,tag+': no card touches SHOT/CAST/pause ('+o.bad.join(',')+')');
   ok(o.inSafe,tag+': whole fan inside the safe area ('+JSON.stringify(o.box)+' in '+o.z.VW+'x'+o.z.VH+')');
   ok(o.clearOfStick,tag+': fan stays clear of the stick zone ('+(o.L?'x<='+o.jz.x0.toFixed(0):'x>='+o.jz.x1.toFixed(0))+', fan '+o.box.minx.toFixed(0)+'..'+o.box.maxx.toFixed(0)+')');
   ok(o.btnsClear&&o.castSafe,tag+': SHOT and CAST sit outside the stick zone and inside the margins');
   ok(o.margin>=12,tag+': SHOT keeps a >=12px margin from the edges ('+o.margin.toFixed(0)+')');return o;};
 // ---- right-handed
 await setup(H5);await sleep(500);await checkGeo('right-handed');
 await shot('layout-two-thumb'+suf+'.png');
 // floating stick: appears wherever the left thumb lands in the left half; stays away from the fan side
 const jz=await E(()=>__game.dbg.joyZone());
 for(const [fx,fy] of [[.1,.5],[.3,.7],[.4,.35]]){
   const px=jz.x1*fx/.44,py=await E(f=>__game.size.VH*f,fy),c=await css(px,py);
   const th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(80);
   const j=await E(()=>({on:__game.joy.on,bx:__game.joy.bx,by:__game.joy.by}));
   ok(j.on&&Math.abs(j.bx-px)<=60&&Math.abs(j.by-py)<=60,'stick appears under the left thumb at ('+Math.round(px)+','+Math.round(py)+') -> ('+Math.round(j.bx)+','+Math.round(j.by)+')');
   await th.move(c.x+40*c.k,c.y);await sleep(80);ok(await E(()=>__game.joy.x>.3),'dragging the floating stick steers');await th.end();await sleep(60);ok(await E(()=>!__game.joy.on),'stick vanishes on release');}
 {const c=await css(jz.x1+(await E(()=>__game.size.VW))*.04,await E(()=>__game.size.VH*.25));await pg.touchscreen.tap(c.x,c.y);await sleep(100);ok(await E(()=>!__game.joy.on),'a touch outside the left zone does not spawn a stick');}
 // cycle by swiping the fan (no cast), both directions
 await setup(H5);await sleep(400);
 let r2=await E(()=>{const r=__game.cardRects[2];return {x:r.cx,y:r.cy};});let c=await css(r2.x,r2.y);
 let th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(50);await th.move(c.x+35*c.k,c.y);await th.move(c.x+70*c.k,c.y);await sleep(80);
 let s=await E(()=>({sel:__game.B.sel,hand:__game.B.hand.slice()}));
 ok(s.sel>=1&&s.hand.every(x=>x),'swiping along the fan turns the wheel to the next cards (sel '+s.sel+') without casting');
 await th.end();await sleep(150);ok(await E(()=>__game.B.hand.every(x=>x)),'releasing after a fan swipe does not cast');
 const sel1=await E(()=>__game.B.sel);r2=await E(()=>{const r=__game.cardRects[__game.B.sel];return {x:r.cx,y:r.cy};});c=await css(r2.x,r2.y);
 th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(50);await th.move(c.x-35*c.k,c.y);await th.move(c.x-70*c.k,c.y);await sleep(80);
 ok(await E(s=>__game.B.sel<s,sel1),'swiping the other way goes back');await th.end();await sleep(100);
 // tap casts, swipe up casts, rotated hit test works for tilted cards
 await setup(H5);await sleep(400);r2=await E(()=>{const r=__game.cardRects[1];return {x:r.cx,y:r.cy};});c=await css(r2.x,r2.y);await pg.touchscreen.tap(c.x,c.y);await sleep(250);
 ok(await E(()=>__game.B.hand[1]===null),'tapping a tilted card casts it');
 await setup(H5);await sleep(400);r2=await E(()=>{const r=__game.cardRects[0];return {x:r.cx,y:r.cy};});c=await css(r2.x,r2.y);
 th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(50);await th.move(c.x,c.y-25*c.k);await th.move(c.x,c.y-70*c.k);await sleep(100);
 ok(await E(()=>__game.B.hand[0]===null&&__game.B.hand[1]==='sword'),'swipe up on the end card of the fan casts that card');await th.end();
 // hold SHOT = charge/aim, swipe up from SHOT casts the highlighted card
 await setup(H5);await sleep(400);let a=await E(()=>({x:__game.btn.atk.x,y:__game.btn.atk.y}));c=await css(a.x,a.y);
 th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(450);
 ok(await E(()=>__game.B.charge>0||__game.B.charging),'holding SHOT still charges / aims');await shot('layout-two-thumb-aim'+suf+'.png');
 await th.move(c.x,c.y-30*c.k);await th.move(c.x,c.y-80*c.k);await sleep(120);
 ok(await E(()=>__game.B.hand[__game.B.sel]===null||__game.B.hand.some(x=>x===null)),'swiping up from SHOT still casts the highlighted card');await th.end();await sleep(200);
 // 6-card hand
 await setup(H6);await sleep(400);await checkGeo('six cards');
 // ---- left-handed mirror
 await E(()=>{__game.dbg.setToggle('lefty');});await setup(H5);await sleep(500);
 ok(await E(()=>__game.dbg.LEFTY&&__game.btn.atk.x<__game.size.VW/2),'left-handed: SHOT moves to the left thumb');
 await checkGeo('left-handed');await shot('layout-two-thumb-lefty'+suf+'.png');
 {const z=await E(()=>({jz:__game.dbg.joyZone(),VH:__game.size.VH})),c=await css(z.jz.x0+60,z.VH*.5);const t=await pg.touchscreen.touchStart(c.x,c.y);await sleep(80);
  ok(await E(()=>__game.joy.on&&__game.joy.bx>=__game.size.VW*.5),'left-handed: the floating stick lives in the right half');await t.end();await sleep(60);}
 r2=await E(()=>{const r=__game.cardRects[2];return {x:r.cx,y:r.cy};});c=await css(r2.x,r2.y);
 th=await pg.touchscreen.touchStart(c.x,c.y);await sleep(50);await th.move(c.x+35*c.k,c.y);await th.move(c.x+70*c.k,c.y);await sleep(80);
 ok(await E(()=>__game.B.sel>=1&&__game.B.hand.every(x=>x)),'left-handed: the fan still cycles by swiping');await th.end();await sleep(100);
 await E(()=>{__game.dbg.setToggle('lefty');});await sleep(200);ok(await E(()=>!__game.dbg.LEFTY&&__game.btn.atk.x>__game.size.VW/2),'toggle back to right-handed');
 ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
