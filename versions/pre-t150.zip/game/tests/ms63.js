// M63 (t145u/t146u): HUD redo in the pause-menu style, HD tile/sprite pass, pet walks after the hero instead of teleporting.
//   node tests/ms63.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms63',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t145/.test(tags),'backup tag backup-pre-t145');
 await E(()=>__game.dbg.startFromTitle());await sleep(700);
 let s=await E(()=>({p:typeof panelSkin==='function'||String(panel).includes('panelSkin')||String(panel).includes('satLeather')||!!(typeof PANEL_SKIN!=='undefined'&&PANEL_SKIN),b:String(bar).includes('rimHi')||String(bar).includes('HD'),t:String(drawTouch).includes('hdButton'),r:String(drawRunBtn).includes('hdButton'),h:String(drawOverHud).includes('hdPortrait')}));
 ok(s.p&&s.b,'panels + bars use the leather/brass HUD kit');ok(s.t&&s.r,'touch buttons (SHOT/RUN/pause/stick) restyled');ok(s.h,'hero card rebuilt (portrait, plate, badge, icons)');
 // HUD visibly differs: sample the hero card interior colour (warm brown, not the old navy #1a1630)
 s=await E(()=>{const c=document.querySelector('canvas'),g=c.getContext('2d'),k=c.width/VW,d=g.getImageData(Math.round((SL+8+90)*k),Math.round((ST+8+52)*k),1,1).data;return [d[0],d[1],d[2]];});
 ok(s[0]>s[2],'hero card interior is warm leather, not navy ('+s.join(',')+')');
 s=await E(()=>{const a=tileSprite(T.G,5,5,0),p=tileSprite(T.P,6,6,0);return {g:a.width,p:p.width};});ok(s.g===32&&s.p===32,'grass/path tiles render at 32px internal detail');
 s=await E(()=>{const t=[...TREE_IDS][0];return tileSprite(t,3,3,0).width;});ok(s===16,'trees keep their original art');
 s=await E(()=>{HDX.on=true;HDX.spr=true;HDX.miss=0;HDX.frame=-1;const src=SP.hero.d[0];delete src._hd;delete src._hdMiss;const h=hdGet(src,'spr');return h&&h.width===src.width*2;});ok(s,'hero sprite gets an HD twin');
 // pet: walks after the hero (no snap) when the hero moves 200px away
 s=await E(async()=>{PET.active=PET.active||Object.keys(PETS)[0];if(!PET.owned)PET.owned={};petSnap();const p0={x:PET.x,y:PET.y};P.x+=200;let maxStep=0,lx=PET.x,ly=PET.y;
   for(let i=0;i<60;i++){updatePet(1/60);const st=Math.hypot(PET.x-lx,PET.y-ly);maxStep=Math.max(maxStep,st);lx=PET.x;ly=PET.y;}
   const d=Math.hypot(P.x-PET.x,P.y-PET.y);P.x-=200;return {maxStep,d,fin:isFinite(PET.x)};});
 ok(s.fin&&s.maxStep<12&&s.d<90,'pet walks/runs to the hero smoothly (max step '+s.maxStep.toFixed(1)+'px, ends '+Math.round(s.d)+'px away)');
 s=await E(()=>{P.x+=1200;updatePet(1/60);const d=Math.hypot(P.x-PET.x,P.y-PET.y);P.x-=1200;petSnap();return d;});ok(s<60,'pet still teleports when very far ('+Math.round(s)+'px)');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');ok(/arcane-knight-v(5[2-9]|[6-9][0-9])/.test(sw),'service worker v52+');
 await sleep(500);ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
