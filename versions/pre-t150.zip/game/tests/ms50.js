// M50: house interior wall options ?housewall=1..4 (walls only at the room edge, dark outside).  Screens store/house-wall-N.png (landscape).  node tests/ms50.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';let bad=0,tot=0;
 for(const n of (process.argv[3]!=null?[+process.argv[3]]:[0])){
  const {pg,E,ok,sleep,shot,finish}=await boot('ms50',{town:true,device:MOB?'iPhone 12 landscape':undefined,q:'?housevoid=0&housewall='+n});
  const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
  await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.TRK.open=false;d.resetPets&&d.resetPets();
   g.tp(31,d.HOUSE_Y0+7);g.P.x=31*32+16;g.P.y=(d.HOUSE_Y0+5)*32+28;g.P.dir='u';g.P.grace=99;g.snapCam&&g.snapCam();});
  await sleep(4200);
  const w=await E(()=>{const g=__game,d=g.dbg;return {wall:d.HOUSEWALL,zone:d.zoneOfPx(g.P.y)};});
  ok(w.zone==='house'&&w.wall===n,'house zone with housewall='+n+' ('+JSON.stringify(w)+')');
  // walls only at the room edge: tiles far outside the room are the dark void; the room edge ring is a wall (not void)
  const t=await E(()=>{const d=__game.dbg,g=__game;if(!d.houseTile)return null;const R=d.HOUSE_ROOM,s=(x,y,id)=>d.tileSpriteOf?0:0;const px=(c)=>{const x=c.getContext('2d').getImageData(8,8,1,1).data;return [x[0],x[1],x[2]];};
    const T=d.T,far=g.tileSpriteOf(T.B,5,d.HOUSE_Y0+2,0),side=g.tileSpriteOf(T.B,R.x0-1,R.y0+3,0),back=g.tileSpriteOf(T.B,R.x0+3,R.y0-2,0);return {far:px(far),side:px(side),back:px(back)};});
  if(n&&t){ok(t.far[0]<12&&t.far[1]<12&&t.far[2]<24,'outside the room is dark ('+t.far+')');ok(t.side.join()!==t.far.join()&&t.back.join()!==t.far.join(),'room-edge walls are drawn ('+t.side+' / '+t.back+')');}
  if(n)await shot('house-wall-'+n+'.png');else await shot('house-wall-0-original.png');
  ok(errs.length===0,'no page errors '+errs.join('|'));
  await finish();
 }
})();
