// M51: ?housevoid=1..4 (all with the timber wall): what lies beyond the house walls.  Screens store/house-void-N.png (landscape).  node tests/ms51.js [desktop|mobile] N
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';const DEF=process.argv[3]==='default',n=DEF?4:+(process.argv[3]||1);
 const {pg,E,ok,sleep,shot,finish}=await boot('ms51',{town:true,device:MOB?'iPhone 12 landscape':undefined,q:DEF?'':'?housevoid='+n});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 const sz0=await E(()=>({VW:__game.size.VW,VH:__game.size.VH,S:__game.size.S}));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.TRK.open=false;d.resetPets&&d.resetPets();
   g.tp(31,d.HOUSE_Y0+7);g.P.x=(window.__hx||31)*32+16;g.P.y=(d.HOUSE_Y0+(window.__hy||5))*32+28;g.P.dir='u';g.P.grace=99;g.snapCam&&g.snapCam();});
 await E((n)=>{const g=__game;if(n===2){window.__hx=26.2;g.P.x=26.2*32;g.snapCam&&g.snapCam();}if(n===4){g.P.x=23.5*32;g.P.y=(d0=g.dbg.HOUSE_Y0)*32+(4)*32+16;g.snapCam&&g.snapCam();}},n);await sleep(4500);
 const w=await E(()=>{const g=__game,d=g.dbg;return {void:d.HOUSEVOID,wall:d.HOUSEWALL,zone:d.zoneOfPx(g.P.y),VW:g.size.VW,S:g.size.S};});
 ok(w.zone==='house'&&w.void===n&&w.wall===1,'house with timber walls and housevoid='+n+' ('+JSON.stringify(w)+')');
 if(MOB&&n!==3)ok(w.S>sz0.S,'zoomed in one pixel-scale step (S '+sz0.S+' -> '+w.S+')');
 if(n===3)ok(w.S===sz0.S,'option 3 keeps the normal view');
 const px=await E(()=>{const g=__game,d=g.dbg,R=d.HOUSE_ROOM,T=d.T,c=(s)=>{const q=s.getContext('2d').getImageData(8,8,1,1).data;return [q[0],q[1],q[2]];};
   return {far:c(d.hwOut(R.x0-6,R.y0+3)),near:c(d.hwOut(R.x0-2,R.y0+3))};});
 ok(!(px.far[0]<10&&px.far[1]<10&&px.far[2]<20),'beyond the walls is not black ('+px.far+')');
 await E(()=>{window.__hy=5;});
 if(!DEF)await shot('house-void-'+n+'.png');
 if(n===4){const k=await E(()=>{const d=__game.dbg,R=d.HOUSE_ROOM,K=d.HOUSE_KIT,s=d.solidTile;return {door:!s(R.x0-1,R.y0+1)&&!s(R.x0-1,R.y0+2),wall:s(R.x0-1,R.y0+4),floor:!s(K.x0+3,R.y0+3),counter:s(K.x0,R.y0),table:s(K.x0+2,R.y0+5),bed:!s(R.x0+2,R.y0+2)};});
   ok(k.door&&k.wall&&k.floor&&k.counter&&k.table,'kitchen: doorway walkable, shared wall solid, floor walkable, counters / table solid '+JSON.stringify(k));}
 // leaving restores the normal scale
 await E(()=>{const g=__game,d=g.dbg;g.tp(21,45);g.P.x=21*32+16;g.P.y=45*32+28;});await sleep(600);
 const o=await E(()=>({S:__game.size.S,VW:__game.size.VW}));ok(o.S===sz0.S,'outside the house the normal scale is back ('+o.S+')');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
