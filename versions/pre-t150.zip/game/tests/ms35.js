// M35: waystones unlock by walking up, no post-fight blink, distinct boss mechanics.  node tests/ms35.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms35',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.lv=20;g.P.hp=d.maxHp();});
 // ---- 1. waystones attune when you walk within ~2 tiles
 await E(()=>{const g=__game,d=g.dbg,n=d.NPCS.find(q=>q.way==='road');d.SEC.ways.road=false;g.P.grace=99;d.setTimeOfDay(.5);g.tp(Math.floor(n.x/32)-4,Math.floor(n.y/32)+3);window.__wn=n;});await sleep(600);
 ok(await E(()=>!__game.dbg.SEC.ways.road),'a waystone 4+ tiles away stays dormant');
 await E(()=>{const g=__game,n=window.__wn;g.P.x=n.x-24;g.P.y=n.y+8;});await sleep(450);
 const un=await E(()=>{const d=__game.dbg;return {on:!!d.SEC.ways.road,fx:window.__wn.fxT!=null,toast:d.toasts.some(t=>/Waystone Unlocked/.test(t.s||t.text||t.msg||''))};});
 ok(un.on&&un.fx,'walking up to it unlocks it with no interaction ('+JSON.stringify(un)+')');
 ok(await E(()=>__game.dbg.toasts.some(t=>JSON.stringify(t).includes('Waystone Unlocked'))),'"Waystone Unlocked" toast shown');
 await shot('waystone-unlock.png');
 await sleep(2600);
 ok(await E(()=>{const d=__game.dbg,n=window.__wn;return d.SEC.ways.road&&gtimeOk();function gtimeOk(){return true;}}),'it stays unlocked');
 // ---- 2. no blinking after a fight ends
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.tp(12,22);g.P.grace=4;d.toasts.length=0;});await sleep(500);
 const lum=()=>E(()=>{const c=document.getElementById('c'),x=c.getContext('2d'),k=c.width/__game.size.VW,g=__game,sx=(g.P.x-g.cam.x)*k,sy=(g.P.y-g.cam.y-14)*k,r=Math.round(16*k),im=x.getImageData(Math.max(0,Math.round(sx-r)),Math.max(0,Math.round(sy-r)),r*2,r*2).data;let s=0;for(let i=0;i<im.length;i+=4)s+=im[i]+im[i+1]+im[i+2];return s;});
 const v=[];for(let i=0;i<14;i++){v.push(await lum());await sleep(37);}
 const mn=Math.min(...v),mx=Math.max(...v);
 ok(await E(()=>__game.P.grace>0)&&mx/mn<1.12,'the hero does not flash on and off while the post-fight grace runs (luma range '+(mx/mn).toFixed(3)+')');
 // ---- 3. bosses
 const setup=(type)=>E(type=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.WARP=null;g.P.grace=0;g.P.hp=g.P.hp=d.maxHp();g.P.lv=40;
   g.enemies.forEach(o=>{if(o.type!==type){o.calm=99;}});
   const e=g.enemies.find(o=>o.type===type);const ay=d.ARENA.y0+4;g.tp(31,ay+5);g.P.x=31*32+16;g.P.y=(ay+5)*32+28;
   e.alive=true;e.dying=false;e.engaged=false;e.x=e.hx=31*32+16;e.y=e.hy=ay*32+40;e.hp=e.maxhp=e.mhp=e.mhp;e.p2=e.p3=false;e.bshield=0;e.mc={};e.calm=0;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.t=1;B.inv=0;B.dim=1;e.joinT=0;e.atkCd=1e9;window.__b=e;return {ok:!!B};},type);
 const st=()=>E(()=>{const g=__game,e=window.__b,c=__game.dbg;return {hp:g.P.hp,x:g.P.x,y:g.P.y,pools:g.B?(g.B.pools||[]).length:-1,tmp:g.B?g.B.ens.filter(o=>o.tmp&&!o.dying).length:-1,ex:e.x,ey:e.y,shield:e.bshield||0,stun:e.stun||0,bhp:e.hp,p2:!!e.p2};});
 const heroFull=()=>E(()=>{const g=__game;g.P.hp=g.dbg.maxHp();g.B.inv=0;});
 // dragon
 await setup('dragon');
 let r=await E(()=>{const g=__game,d=g.dbg,e=window.__b,m=d.bossMove(e,'gust');g.P.x=e.x;g.P.y=e.y+110;g.B.inv=0;const x0=g.P.y,hp0=g.P.hp;m.strike(e);return {x0,hp0,zones:m.zones.length,wind:m.windup};});
 await sleep(500);let s2=await st();
 ok(r.zones===1&&s2.hp<r.hp0&&s2.y>r.x0+50,'DRAGON wing gust: telegraphed cone, damages and knocks the hero back ('+Math.round(s2.y-r.x0)+'px, hp '+r.hp0+'->'+s2.hp+')');
 await heroFull();
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b;e.p2=true;const m=d.bossMove(e,'flamewall');g.B.pools=[];m.strike(e);return {n:g.B.pools.length};});
 ok(r.n===3,'DRAGON phase 2 flame breath leaves flame pools ('+r.n+')');
 await E(()=>{const g=__game,q=g.B.pools[0];g.P.x=q.x;g.P.y=q.y-12+12;g.B.inv=0;g.P.hp=g.dbg.maxHp();window.__hp0=g.P.hp;});await sleep(900);
 ok(await E(()=>__game.P.hp<window.__hp0),'standing in a flame pool burns the hero');
 await E(()=>{const g=__game,e=window.__b,d=g.dbg;e.p2=false;e.hp=e.maxhp*.45;g.B.pools=[];d.damageEnemy(e,1,'sword');});
 ok(await E(()=>window.__b.p2&&__game.B.pools.length>=4),'DRAGON phase 2 at 50% HP: flames erupt around it ('+await E(()=>__game.B.pools.length)+' pools)');
 // lich
 await setup('lich');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b,m=d.bossMove(e,'raise');m.strike(e);return {zones:m.zones.length,tmp:g.B.ens.filter(o=>o.tmp).length,types:g.B.ens.filter(o=>o.tmp).map(o=>o.type).join()};});
 ok(r.zones===2&&r.tmp===2,'LICH raise the dead: 2 telegraphed spawn circles, 2 minions ('+r.types+')');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b,m=d.bossMove(e,'step'),z=m.zones[0];m.strike(e);const c={x:e.x,y:e.y-26};return {dist:Math.hypot(c.x-z.x,c.y-z.y)};});
 ok(r.dist<3,'LICH phase step: teleports onto its telegraphed circle ('+r.dist.toFixed(1)+')');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b;e.hp=e.maxhp*.6;d.damageEnemy(e,1,'sword');const sh=e.bshield,hp=e.hp;d.damageEnemy(e,Math.round(sh/2),'sword');const mid={sh:e.bshield,hp:e.hp===hp};d.damageEnemy(e,sh,'sword');return {sh,mid,after:e.bshield,stun:e.stun,hpSame:e.hp===hp};});
 ok(r.sh>0&&r.mid.hp&&r.after===0&&r.stun>2&&r.hpSame,'LICH soul ward (phase 2): shield soaks damage, breaking it staggers the boss ('+JSON.stringify(r)+')');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b;e.bshield=0;e.hp=1;const n0=g.B.ens.filter(o=>o.tmp&&!o.dying).length;d.damageEnemy(e,50,'sword');return {n0,left:g.B.ens.filter(o=>o.tmp&&!o.dying).length};});
 ok(r.n0>=1&&r.left===0,'summoned minions fall with the Lich King ('+JSON.stringify(r)+')');
 await sleep(1700);await E(()=>{const g=__game;if(g.B)g.dbg.endFight();});await sleep(500);
 ok(await E(()=>!__game.enemies.some(o=>o.tmp)),'minions are removed from the world after the fight');
 // rimegar
 await setup('rimegar');
 r=await E(()=>{const d=__game.dbg,e=window.__b,m=d.bossMove(e,'slam');return {zones:m.zones.length,r:m.zones[0].r,wind:m.windup};});
 ok(r.zones===1&&r.r>=90&&r.wind>=1.2,'RIMEGAR glacial slam: big telegraphed circle with a long windup, then a shockwave ring ('+JSON.stringify(r)+')');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b,m=d.bossMove(e,'gale');g.P.x=e.x;g.P.y=e.y+100;g.B.inv=0;const y0=g.P.y;m.strike(e);return {y0};});await sleep(500);
 s2=await st();ok(s2.y>r.y0+40,'RIMEGAR bitter gale knocks the hero back ('+Math.round(s2.y-r.y0)+'px)');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b;e.hp=e.maxhp*.6;d.damageEnemy(e,1,'sword');return {sh:e.bshield};});
 ok(r.sh>0,'RIMEGAR ice armor at phase 2 ('+r.sh+')');
 // mossback
 await setup('mossback');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b,m=d.bossMove(e,'spit');g.B.pools=[];m.strike(e);return {n:g.B.pools.length,z:m.zones.length};});
 ok(r.n>=3&&r.z>=3,'MOSSBACK poison spit: telegraphed blobs leave toxic pools ('+JSON.stringify(r)+')');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b,m=d.bossMove(e,'hatch');m.strike(e);return {t:g.B.ens.filter(o=>o.tmp).map(o=>o.type).join()};});
 ok(r.t==='toad,toad','MOSSBACK hatches bog toads ('+r.t+')');
 // colossus
 await setup('colossus');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b,m=d.bossMove(e,'storm');g.P.x=e.x;g.P.y=e.y+90;g.B.inv=0;const y0=g.P.y;m.strike(e);return {y0};});await sleep(500);
 s2=await st();ok(s2.y>r.y0+50,'COLOSSUS sandstorm blasts the hero outward ('+Math.round(s2.y-r.y0)+'px)');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b;g.P.x=31*32+16;g.P.y=(d.ARENA.y0+8)*32+28;const m=d.bossMove(e,'burrow'),z=m.zones[0];m.strike(e);return {dist:Math.hypot(e.x-z.x,(e.y-26)-z.y)};});
 ok(r.dist<3,'COLOSSUS burrow: erupts on the circle marked where you stood ('+r.dist.toFixed(1)+')');
 r=await E(()=>{const g=__game,d=g.dbg,e=window.__b;e.hp=e.maxhp*.6;d.damageEnemy(e,1,'sword');return {sh:e.bshield};});
 ok(r.sh>0,'COLOSSUS stone skin at phase 2 ('+r.sh+')');
 // each boss has its own book
 const bk=await E(()=>{const d=__game.dbg;return Object.fromEntries(Object.entries(d.BOSS_BOOK).map(([k,v])=>[k,v.map(x=>x[0]).join('+')]));});
 ok(new Set(Object.values(bk)).size===5,'five bosses, five different signature books '+JSON.stringify(bk));
 await E(()=>{__game.dbg.endFight();});
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
