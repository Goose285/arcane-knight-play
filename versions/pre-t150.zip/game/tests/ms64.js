// M64 (t147u/t148u): performance - DPR capped at 2 (no auto thrash), fog half-res, cached HUD skins.
//   Chunk cache was removed in t148u (caused black holes).   node tests/ms64.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms64',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t147/.test(tags)||/backup-pre-t148/.test(tags),'backup tag present');
 await E(()=>__game.dbg.startFromTitle());await sleep(700);
 let s=await E(()=>({dpr:DPR,cap:QUAL.wantDpr,locked:!!QUAL.locked,fog:String(drawFog).includes('FOG_BUF')||String(drawFog).includes('fogDrawFast'),panel:typeof panelSkin==='function'||(typeof PANEL_SKIN!=='undefined'),noChunkLive:typeof CH==='undefined'||CH.live===false}));
 ok(s.dpr<=2&&s.cap<=2,'DPR capped at 2 (got '+s.dpr+')');
 ok(s.locked!==false,'auto quality locked (no resize thrash)');
 ok(s.fog,'fog uses the half-res buffer path');
 ok(s.panel,'HUD panel skins are cached');
 s=await E(()=>{const was=SET.perf;SET.perf=false;if(typeof qualApply==='function')qualApply();P.x=21*32;P.y=262*32;FOG.a=.8;drawFog();FOG.a=0;const out={fogW:FOG_BUF&&FOG_BUF.width,VW};SET.perf=was;if(typeof qualApply==='function')qualApply();return out;});
 ok(s.fogW>0&&s.fogW<=s.VW,'fog buffer is half-res or smaller ('+s.fogW+' <= '+s.VW+')');
 // no black holes: sample a few grass/path tiles are non-empty
 s=await E(()=>{const samples=[];for(const [x,y] of [[18,32],[21,36],[15,34],[22,40]]){const id=map[y][x],sp=tileSprite(id,x,y,0);const d=sp.getContext('2d').getImageData(0,0,Math.min(16,sp.width),Math.min(16,sp.height)).data;let lit=0;for(let i=0;i<d.length;i+=4)if(d[i]+d[i+1]+d[i+2]>30)lit++;samples.push(lit);}return samples;});
 ok(s.every(n=>n>8),'town tiles are painted (no black holes) '+s.join(','));
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');ok(/arcane-knight-v5[3-9]/.test(sw),'service worker v53+');
 await sleep(300);ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
