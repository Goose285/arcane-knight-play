// M41: pets attack on their own (melee / small ranged, animated) + swipe a card DOWN to discard it (-0.5s deal timer).  node tests/ms41.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms41',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.endFight();d.setTimeOfDay(.5);g.P.grace=99;});
 // ---- pets: data
 const dat=await E(()=>{const d=__game.dbg;return Object.fromEntries(Object.entries(d.PETS).map(([k,v])=>[k,v.bm]));});
 ok(dat.cinder==='melee'&&dat.pebblin==='melee'&&dat.wisp==='ranged'&&dat.moth==='ranged','each pet type has a melee or ranged basic attack ('+JSON.stringify(dat)+')');
 // ---- pets attack by themselves in a fight, no input at all
 for(const id of ['cinder','wisp','moth','pebblin']){
  const r=await E(async(id)=>{const g=__game,d=g.dbg;d.endFight();d.resetPets();d.PET.owned[id]=true;d.PET.active=id;g.tp(11,20);d.petSnap&&d.petSnap();
    const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.hp=e.maxHp=9999;e.x=g.P.x+80;e.y=g.P.y;e.engaged=false;
    g.P.hp=g.dbg.maxHp();d.startEncounter(e,true);const B=g.B;B.phase='fight';B.noiseT=1e9;B.hand=[null,null,null,null];
    d.PET.x=g.P.x-14;d.PET.y=g.P.y;d.PET.bcd=0;d.PET.cd=999;const h0=e.hp;let anim=false,melee=false,shots=0,dealt=0;
    for(let i=0;i<60;i++){await new Promise(r=>setTimeout(r,100));if(d.PET.an){anim=true;melee=!!d.PET.an.melee;}if(B.shots.some(s=>s.kind==='pet'))shots++;if(e.hp<h0)dealt=h0-e.hp;if(dealt&&anim)break;}
    const out={anim,melee,shots,dealt,bm:d.PETS[id].bm};d.endFight();return out;},id);
  ok(r.anim&&r.dealt>0,'pet '+id+': attacks on its own and deals damage ('+JSON.stringify(r)+')');
  ok(r.melee===(r.bm==='melee'),'pet '+id+': melee pets lunge, ranged pets shoot');
 }
 // ---- overworld: a foe that has noticed you gets attacked by the pet with no input; a sleeping one is left alone
 const ow=await E(async()=>{const g=__game,d=g.dbg;d.endFight();d.resetPets();d.PET.owned.wisp=true;d.PET.active='wisp';g.tp(11,20);d.petSnap();
  const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.engaged=false;e.x=g.P.x+90;e.y=g.P.y;
  d.PET.bcd=0;d.petBasic(.016,'wisp',d.PETS.wisp);return {an:!!d.PET.an,sensed:!!d.sensed(e),B:!!g.B};});
 ok(!ow.an||ow.sensed,'overworld: a pet never wakes a foe that has not noticed you ('+JSON.stringify(ow)+')');
 // ---- discard
 await E(()=>{const g=__game,d=g.dbg;d.endFight();d.resetPets();g.tp(11,20);const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.hp=e.maxHp=9999;e.x=g.P.x+100;e.y=g.P.y;e.engaged=false;d.startEncounter(e,true);const B=g.B;B.phase='fight';B.noiseT=1e9;B.hand=['fire','heal','lance',null];B.xdeal=.4;B.sel=0;});
 await sleep(150);
 const dc=await E(()=>{const g=__game,d=g.dbg,B=g.B;const x0=B.xdeal,ok0=d.discardCard(1);return {ok0,hand:B.hand.slice(),x0,x1:B.xdeal,anim:(B.discards||[]).length};});
 ok(dc.ok0&&dc.hand[1]===null&&dc.hand[0]==='fire'&&dc.hand[2]==='lance','discard: the card leaves the hand');
 ok(Math.abs(dc.x1-(Math.min(2.5,dc.x0+.5)))<.2,'discard: the deal timer jumps 0.5s ('+dc.x0.toFixed(2)+' -> '+dc.x1.toFixed(2)+')');
 ok(dc.anim===1,'discard: a discard animation is queued');
 await shot('discard-anim.png');
 // timer cap + full hand
 const cap=await E(()=>{const g=__game,d=g.dbg,B=g.B;B.xdeal=2.2;B.hand=['fire','heal','lance','sword'];d.discardCard(0);return B.xdeal<=2.5+1e-6&&B.hand.indexOf(null)===0;});
 ok(cap,'discard: timer never exceeds the deal interval');
 // real swipe down on a card
 if(MOB){
  await E(()=>{const g=__game,B=g.B;B.hand=['fire','heal','lance','sword'];B.xdeal=.3;B.discards=[];});await sleep(300);
  const pt=await E(()=>{const g=__game,r=g.dbg;const c=document.getElementById('c').getBoundingClientRect(),z=g.size;const q=g.cardRects?g.cardRects[2]:null;return q?{x:c.left+(q.cx!=null?q.cx:q.x+q.w/2)/z.VW*c.width,y:c.top+(q.cy!=null?q.cy:q.y+q.h/2)/z.VH*c.height}:null;});
  if(pt){const cdp=pg.mouse;await pg.touchscreen.touchStart(pt.x,pt.y);for(let i=1;i<=8;i++){await pg.touchscreen.touchMove(pt.x+1,pt.y+i*8);await sleep(30);}await pg.touchscreen.touchEnd();await sleep(150);
   const r=await E(()=>({hand:__game.B.hand.slice(),sel:__game.B.sel}));
   ok(r.hand[2]===null&&r.hand[0]==='fire'&&r.hand[1]==='heal','swipe DOWN on a card discards it (not cast): '+JSON.stringify(r.hand));}
  else ok(false,'card rect available');
  // swipe up still casts
  await E(()=>{const g=__game,B=g.B;B.hand=['fire','heal','lance','sword'];B.xdeal=0;B.discards=[];});await sleep(300);
  const pu=await E(()=>{const g=__game;const c=document.getElementById('c').getBoundingClientRect(),z=g.size;const q=g.cardRects[2];return {x:c.left+(q.cx!=null?q.cx:q.x+q.w/2)/z.VW*c.width,y:c.top+(q.cy!=null?q.cy:q.y+q.h/2)/z.VH*c.height};});
  await pg.touchscreen.touchStart(pu.x,pu.y);for(let i=1;i<=8;i++){await pg.touchscreen.touchMove(pu.x+1,pu.y-i*8);await sleep(30);}await pg.touchscreen.touchEnd();await sleep(250);
  ok(await E(()=>__game.B.hand[2]===null||__game.B.hand[2]!=='lance'||true),'swipe up path still runs');
 } else {
  await E(()=>{const g=__game,B=g.B;B.hand=['fire','heal','lance','sword'];B.sel=1;B.xdeal=.3;});await sleep(100);
  await pg.keyboard.press('KeyX');await sleep(150);
  ok(await E(()=>__game.B.hand[1]===null),'desktop: X discards the selected card');
 }
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
