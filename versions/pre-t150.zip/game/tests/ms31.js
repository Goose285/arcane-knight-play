// M31: Town Guards defend real threats only (a foe fighting the hero near the post, or a monster inside the walls), step out a little and return; idle monsters are left alone.
// node tests/ms31.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,finish}=await boot('ms31',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();});
 const reset=(hx,hy)=>E((hx,hy)=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.flash=0;e.calm=0;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=e.lk=1e9;e.vr=0;});
   g.tp(hx,hy);g.P.x=hx*32+16;g.P.y=hy*32+28;g.P.grace=99;g.P.hp=1e6;
   g.townDbg().guardsOf().forEach(q=>{q.x=q.hx;q.y=q.hy;q.gcd=0;q.struck=0;});},hx,hy);
 const put=(type,tx,ty,idx=0)=>E((type,tx,ty,idx)=>{const e=__game.enemies.filter(o=>o.type===type&&!o.def.boss)[idx];e.x=e.hx=tx*32;e.y=e.hy=ty*32;e.alive=true;e.dying=false;e.engaged=false;e.hp=e.maxhp;e.mode='look';e.mt=e.lk=1e9;e.ar=0;e.vr=0;window['__e'+idx]=e;return [e.x,e.y];},type,tx,ty,idx);
 const G=i=>E(i=>{const q=__game.townDbg().guardsOf()[i];return {x:q.x/32,y:q.y/32,hx:q.hx/32,hy:q.hy/32,struck:q.struck};},i);
 const gd=await E(()=>__game.townDbg().guardsOf().length);ok(gd===2,'two guards');
 // ---- 1. north guard, hero far away and NOT in combat: an idle slime 4 tiles from the post is NOT touched
 await reset(40,10);let g0=await G(0);
 await put('slime',g0.hx-1.2,g0.hy-3.8);await sleep(100);
 ok(await E(()=>!__game.B),'no combat is running (hero is far away)');
 let bolts=0,maxOut=0;for(let i=0;i<20;i++){await sleep(120);bolts=Math.max(bolts,await E(()=>__game.townDbg().TGB.length));const g=await G(0);maxOut=Math.max(maxOut,Math.hypot(g.x-g.hx,g.y-g.hy));}
 ok(await E(()=>window.__e0.alive&&window.__e0.hp===window.__e0.maxhp&&!window.__e0.dying),'an idle slime ~4 tiles from the post is left alone');
 ok(bolts===0&&(await G(0)).struck===0,'no guard bolt is fired at it');
 ok(maxOut<.05,'the guard stays on his post ('+maxOut.toFixed(2)+')');
 // ---- 2. outside 5 tiles: left alone
 await reset(40,10);g0=await G(0);await put('slime',g0.hx-1,g0.hy-6.5);await sleep(2500);
 ok(await E(()=>window.__e0.alive&&window.__e0.hp===window.__e0.maxhp),'a slime 6.5 tiles away is not attacked');
 let gb=await G(0);ok(gb.struck===0&&Math.hypot(gb.x-gb.hx,gb.y-gb.hy)<.05,'the guard stays at his post (no chasing)');
 // ---- 3. east bridge guard: a goblin in the hero's own fight, hero standing near the post
 await reset(22,39);let g1=await G(1);await put('goblin',g1.hx+2.5,g1.hy-2,0);
 await E(()=>{const g=__game;g.P.grace=0;g.dbg.startEncounter(window.__e0,true);g.P.grace=0;});await sleep(6500);
 ok(await E(()=>!window.__e0.alive&&!__game.B),'east guard finishes a goblin fighting the hero beside the post, and the fight ends');
 // ---- 4. the hero fights elsewhere: an idle slime near the post is not poached, and the fight carries on
 await reset(12,22);g0=await G(0);
 await put('slime',g0.hx-1.5,g0.hy-4,0);
 await E(()=>{const g=__game,e=g.enemies.filter(o=>o.type==='knight'&&!o.def.boss)[0];e.x=e.hx=12*32+60;e.y=e.hy=22*32+28;e.hp=e.maxhp=e.mhp=99999;e.mode='look';e.mt=e.lk=1e9;window.__k=e;g.P.grace=0;g.dbg.startEncounter(e,true);g.P.grace=0;});
 await sleep(2500);
 ok(await E(()=>window.__e0.alive&&window.__e0.hp===window.__e0.maxhp),'a guard does not poach an idle slime during the hero\'s fight elsewhere');
 ok(await E(()=>!!__game.B&&__game.B.ens.includes(window.__k)),'the hero\'s fight elsewhere continues');
 // ---- 5. an enemy IN the hero's fight within reach of the guard (hero by the gate) is hit, dies visibly and the fight ends cleanly
 await reset(12,26);g0=await G(0);await put('slime',g0.hx-1.5,g0.hy-3.5,0);
 await E(()=>{const g=__game;g.P.grace=0;g.dbg.startEncounter(window.__e0,true);});await sleep(6500);
 ok(await E(()=>!__game.B&&!window.__e0.alive&&!window.__e0.engaged),'guard kills an engaged enemy and the fight ends without leftovers');
 // ---- 6. a boss in a fight by the post is driven off (not killed)
 await reset(12,26);g0=await G(0);await put('knight',g0.hx-1,g0.hy-3.5,0);
 await E(()=>{const e=window.__e0;e.def=Object.assign({},e.def,{boss:true});e.hp=e.maxhp=9999;e.mhp=9999;const g=__game;g.P.grace=0;g.dbg.startEncounter(e,true);});await sleep(5000);
 const bs=await E(()=>{const e=window.__e0;return {alive:e.alive,gh:e.gHits,calm:e.calm,hp:e.hp,hpm:e.maxhp,home:Math.hypot(e.x-e.hx,e.y-e.hy)};});
 ok(bs.alive&&bs.gh>=1,'a boss is struck and driven off rather than slain '+JSON.stringify(bs));
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
