// M32: Combat Lab + the EXPERIMENTAL card system (hand of 4, one card / 2.5s, select-then-tap-to-cast).  node tests/ms32.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms32');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.lv=Math.max(g.P.lv,3);});
 const clickAt=async(x,y)=>{const p=await E((x,y)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+x/z.VW*c.width,y:c.top+y/z.VH*c.height};},x,y);if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(120);};
 const hand=()=>E(()=>__game.B?__game.B.hand.slice():null);
 const cardPt=i=>E(i=>{const r=__game.cardRects[i];return r?{x:r.cx!=null?r.cx:r.x+r.w/2,y:r.cy!=null?r.cy:r.y+r.h/2}:null;},i);
 const setHand=h=>E(h=>{const B=__game.B;B.hand=h.slice();B.xsel=-1;B.sel=0;B.shots.length=0;},h);
 const scr=(x,y)=>E((x,y)=>({x:x-__game.cam.x,y:y-__game.cam.y}),x,y);
 // ---- 0. the main game still uses the normal system
 ok(await E(()=>__game.dbg.expCards()&&__game.dbg.EXPCARD.enabled),'the card system is ON in the main game too (promoted, flag enabled)');
 // ---- 1. pause menu entry
 await E(()=>{const g=__game,d=g.dbg;g.state='paused';d.pauseOpenPage('character');});await sleep(300);
 const rs=await E(()=>__game.dbg.getPauseRects().length);ok(rs>=4,'pause > CHARACTER page lists the new entry ('+rs+' buttons)');
 ok(await E(()=>__game.dbg.PAUSE_ITEMS.some(i=>i.k==='KeyU'&&/COMBAT LAB/.test(i.lab()))),'pause menu has a COMBAT LAB entry');
 await E(()=>{__game.dbg.PAUSE_ITEMS.find(i=>i.k==='KeyU').act();});await sleep(2800);
 const st=await E(()=>{const g=__game,d=g.dbg;return {lab:d.labOn(),z:d.zoneOfPx(g.P.y),b:!!g.B,state:g.state,n:g.B?g.B.ens.length:0,dummies:g.B?g.B.ens.filter(e=>e.dummy).length:0,foes:g.B?g.B.ens.filter(e=>!e.dummy).length:0,hand:g.B?g.B.hand.length:0,exp:d.expCards()};});
 ok(st.lab&&st.z==='arena'&&st.state==='play','Combat Lab opens in the arena ('+JSON.stringify(st)+')');
 ok(st.b&&st.dummies===3&&st.foes===3,'arena has 3 training dummies and 3 enemies in the fight '+JSON.stringify(st));
 ok(st.hand===4&&st.exp,'hand has 4 slots and the experimental system is on in the lab');
 const waitClk=async sec=>{const t0=await E(()=>__game.B.clk);for(let i=0;i<400;i++){await sleep(50);if(await E((t,sc)=>__game.B.clk-t>=sc,t0,sec))return;}};
 // ---- 2. dealing: one card per 2.5s, max 4, no full refresh
 await E(()=>{const B=__game.B;B.hand=[null,null,null,null];B.xdeal=0;B.xsel=-1;});
 await waitClk(1.5);let h=await hand();ok(h.filter(Boolean).length===0,'nothing dealt before 2.5s ('+h.filter(Boolean).length+')');
 await waitClk(1.3);h=await hand();ok(h.filter(Boolean).length===1,'exactly one card after ~2.8s ('+h.filter(Boolean).length+')');
 await waitClk(2.5);h=await hand();ok(h.filter(Boolean).length===2,'a second card ~2.5s later ('+h.filter(Boolean).length+')');
 await waitClk(5.2);h=await hand();ok(h.filter(Boolean).length===4,'hand fills to 4 and no more ('+h.filter(Boolean).length+')');
 const keep=h.slice();await waitClk(9.5);h=await hand();
 ok(JSON.stringify(h)===JSON.stringify(keep),'no full-hand refresh when the old 8.5s gauge would have filled (hand unchanged)');
 ok(await E(()=>__game.B.xdeal<=2.5),'deal timer waits while the hand is full');
 await E(()=>{const B=__game.B;B.hand[2]=null;});await waitClk(2.8);h=await hand();ok(!!h[2]&&h.filter(Boolean).length===4,'a freed slot is refilled by a single new card');
 // ---- 3. tap an attack card: select only, no cast
 await setHand(['fire','heal','meteor','lance']);await sleep(150);
 await E(()=>{__game.B.inv=99;});
 let cp=await cardPt(0);await clickAt(cp.x,cp.y);
 let s1=await E(()=>({xsel:__game.B.xsel,card:__game.B.hand[0],shots:__game.B.shots.filter(q=>q.own==='p').length}));
 ok(s1.xsel===0&&s1.card==='fire'&&s1.shots===0,'tapping FIREBALL selects it and does NOT cast ('+JSON.stringify(s1)+')');
 await sleep(400);
 ok(await E(()=>{const A=__game.dbg;return A.expAimId()==='fire';}),'aim mode is active for the selected card');
 await shot(MOBILE?'combat-lab-aiming.png':'combat-lab-aiming-desktop.png');
 // ---- 4. tap the world: casts THERE (not at the nearest foe)
 const tgt=await E(()=>{const g=__game,B=g.B,z=g.size;const d=B.ens.filter(e=>e.dummy).map(e=>({x:e.x,y:e.y-13,sx:e.x-g.cam.x,sy:e.y-13-g.cam.y})).filter(q=>q.sx>30&&q.sx<z.VW-30&&q.sy>16&&q.sy<z.VH*.62);
   d.sort((a,b)=>Math.abs(a.sx-z.VW/2)-Math.abs(b.sx-z.VW/2));return d[0];});
 ok(!!tgt,'a training dummy is on screen and clear of the HUD ('+(tgt?Math.round(tgt.sx)+','+Math.round(tgt.sy):'none')+')');
 const pc0=await E(()=>__game.dbg.pcen());
 await clickAt(tgt.sx,tgt.sy);await sleep(60);
 const cast=await E(()=>{const B=__game.B;return {card:B.hand[0],xsel:B.xsel,f:B.swipeFlash?{x:B.swipeFlash.tx,y:B.swipeFlash.ty}:null};});
 ok(cast.card===null&&cast.xsel===-1,'the card is spent and the selection cleared after the world tap ('+JSON.stringify(cast)+')');
 ok(cast.f&&Math.hypot(cast.f.x-tgt.x,cast.f.y-tgt.y)<30,'the cast was aimed at the tapped dummy ('+JSON.stringify(cast.f)+' vs '+tgt.x+','+tgt.y+')');
 // direction check (synchronous, before any foe can intercept): a fireball cast at a far point flies exactly that way, whatever is nearest
 const dir=await E((tx,ty)=>{const g=__game,d=g.dbg,B=g.B;B.hand[0]='fire';B.shots.length=0;B.xsel=-1;d.expCardTap(0);
   const pc=d.pcen();let th=-.6,bm=-1;for(let q=-3.1;q<3.1;q+=.15){const fx=pc.x+Math.cos(q)*220,fy=pc.y+Math.sin(q)*220;let m=1e9;for(const e of B.ens){const c=d.ecen(e);m=Math.min(m,Math.hypot(c.x-fx,c.y-fy));}if(m>bm){bm=m;th=q;}}
   const far={x:pc.x+Math.cos(th)*220,y:pc.y+Math.sin(th)*220};d.expCastAt(far.x,far.y);const s=B.shots.filter(q=>q.own==='p').slice(-1)[0];
   let nb=null,nd=1e9;for(const e of B.ens){const c=d.ecen(e),q=Math.hypot(c.x-pc.x,c.y-pc.y);if(q<nd){nd=q;nb=Math.atan2(c.y-pc.y,c.x-pc.x);}}
   return {a:s?Math.atan2(s.vy,s.vx):null,want:th,clear:Math.round(bm),nearest:nb};},tgt.x,tgt.y);
 ok(dir.a!=null&&Math.abs(dir.a-dir.want)<.05,'the fireball flies toward the tapped point, not the nearest foe ('+JSON.stringify(dir)+')');
 // ---- 5. cancel: tap the same card again; tap a HUD control
 cp=await cardPt(3);await clickAt(cp.x,cp.y);ok(await E(()=>__game.B.xsel===3),'LANCE selected');
 cp=await cardPt(3);await clickAt(cp.x,cp.y);
 ok(await E(()=>__game.B.xsel===-1&&__game.B.hand[3]==='lance'),'tapping the card again cancels (card kept)');
 cp=await cardPt(3);await clickAt(cp.x,cp.y);
 if(MOBILE){const b=await E(()=>({x:__game.btn.atk.x,y:__game.btn.atk.y}));await clickAt(b.x,b.y);}
 else{await E(()=>{__game.dbg.expCancel&&0;});await pg.keyboard.press('KeyL');await E(()=>{if(__game.B.xsel>=0)__game.dbg.expCancel();});}   // desktop: cancel via the same-card tap / HUD
 ok(await E(()=>__game.B.xsel===-1&&__game.B.hand[3]==='lance'),'tapping another HUD control (SHOT) cancels the aim');
 // melee: the Sword is strictly one tap in the lab too
 await setHand(['sword','heal','meteor','lance']);await sleep(200);await E(()=>{__game.B.inv=99;});cp=await cardPt(0);await clickAt(cp.x,cp.y);await sleep(100);
 ok(await E(()=>__game.B.hand[0]===null&&__game.B.xsel===-1),'SWORD casts on a single tap in the lab (never enters aim mode)');
 // ---- 6. instant buffs cast on tap
 await E(()=>{const g=__game;g.P.hp=g.dbg.maxHp()*.5;});
 cp=await cardPt(1);await clickAt(cp.x,cp.y);await sleep(100);
 ok(await E(()=>__game.B.hand[1]===null&&__game.B.xsel===-1),'HEAL casts immediately on tap (no aiming)');
 // ---- 7. area card on bare ground (meteor) and a tap inside the stick zone
 await setHand(['meteor','fire','heal','lance']);await sleep(100);cp=await cardPt(0);await clickAt(cp.x,cp.y);
 const pt=await E(()=>{const g=__game,z=g.size,jz=g.dbg.joyZone(),M=g.dbg.MOBILE_ZONE;let best=null,bd=-1;
   const x0=jz.x0+10,x1=jz.x1-10;   // (desktop: the same left part of the screen)
   for(let x=x0;x<=x1;x+=16)for(let y=z.VH*.3;y<z.VH*.7;y+=16){let m=1e9;for(const e of g.B.ens){const c=g.dbg.ecen(e);m=Math.min(m,Math.hypot(c.x-g.cam.x-x,c.y-g.cam.y-y));}
     const w={x:x+g.cam.x,y:y+g.cam.y};if(g.dbg.solidTile(Math.floor(w.x/32),Math.floor(w.y/32))||!g.dbg.losW(g.dbg.pcen(),7,w,7))continue;if(m>bd){bd=m;best={x,y,d:m};}}
   return best;});
 ok(pt.d>120,'found bare ground away from every foe ('+Math.round(pt.d)+'px)');
 const wpt=await E((x,y)=>({x:x+__game.cam.x,y:y+__game.cam.y}),pt.x,pt.y);
 await clickAt(pt.x,pt.y);await sleep(100);
 const met=await E(()=>{const B=__game.B;return {n:B.meteors.length,m:B.meteors[0]?{x:B.meteors[0].x,y:B.meteors[0].y}:null,card:B.hand[0]};});
 ok(met.n===1&&met.card===null&&met.m&&Math.hypot(met.m.x-wpt.x,met.m.y-wpt.y)<6,'METEOR lands exactly on the tapped bare ground'+(MOBILE?' (tap inside the left stick zone)':'')+' '+JSON.stringify(met)+' vs '+JSON.stringify(wpt));
 // ---- 8. cards that need a creature refuse bare ground
 await setHand(['chain','fire','heal','lance']);cp=await cardPt(0);await clickAt(cp.x,cp.y);await clickAt(pt.x,pt.y);
 ok(await E(()=>__game.B.hand[0]==='chain'&&__game.B.xsel===0),'CHAIN LIGHTNING on empty ground: NO TARGET, card + selection kept');
 await E(()=>{__game.dbg.expCancel();});
 // ---- 9. dummies are immortal, nothing is rewarded, hero cannot fall
 const r0=await E(()=>({xp:__game.P.xp,lv:__game.P.lv,gold:__game.P.gold}));
 await E(()=>{const g=__game,B=g.B;B.inv=0;for(const e of B.ens)if(!e.dying){e.hp=1;g.dbg.damageEnemy(e,99999,'arcane');}g.P.hp=1;});await sleep(1800);
 const r1=await E(()=>{const g=__game,B=g.B;return {xp:g.P.xp,lv:g.P.lv,gold:g.P.gold,hp:g.P.hp,b:!!B,dummies:B?B.ens.filter(e=>e.dummy&&e.hp>0).length:0,state:g.state};});
 ok(r1.xp===r0.xp&&r1.lv===r0.lv&&r1.gold===r0.gold,'no XP / gold / loot in the lab');
 ok(r1.b&&r1.dummies===3&&r1.hp>=1&&r1.state==='play','dummies reset instead of dying; the fight goes on; the hero is kept alive');
 await sleep(7000);
 ok(await E(()=>__game.B.ens.filter(e=>!e.dummy&&!e.dying).length===3),'defeated enemies respawn and rejoin the fight');
 await shot(MOBILE?'combat-lab.png':'combat-lab-desktop.png');
 // ---- 10. leave: everything is cleaned up; the main game keeps the same 4-card system
 await E(()=>{const g=__game,d=g.dbg;g.state='paused';d.pauseOpenPage('character');});await sleep(200);
 ok(await E(()=>__game.dbg.PAUSE_ITEMS.find(i=>i.k==='KeyU').lab())==='LEAVE COMBAT LAB','the pause menu entry becomes LEAVE COMBAT LAB');
 await E(()=>{__game.dbg.PAUSE_ITEMS.find(i=>i.k==='KeyU').act();});await sleep(2800);
 const lv=await E(()=>{const g=__game,d=g.dbg;return {lab:d.labOn(),on:d.RUSH.on,b:!!g.B,left:g.enemies.filter(e=>e.lab).length,z:d.zoneOfPx(g.P.y),exp:d.expCards()};});
 ok(!lv.lab&&!lv.on&&!lv.b&&lv.left===0&&lv.z!=='arena'&&lv.exp,'leaving the lab warps back and removes every lab unit ('+JSON.stringify(lv)+')');
 await E(()=>{const g=__game,d=g.dbg;g.state='play';g.P.hp=d.maxHp();g.P.grace=0;const e=g.enemies.find(o=>o.type==='slime'&&o.alive&&!o.def.boss);g.tp(Math.floor(e.x/32)-2,Math.floor(e.y/32));g.P.x=e.x-50;g.P.y=e.y+2;d.startEncounter(e,true);});await sleep(400);
 const nm=await E(()=>({n:__game.B.hand.length,full:__game.B.hand.filter(Boolean).length,sel:__game.B.xsel}));
 ok(nm.n===4&&nm.full===2,'a normal fight now opens with 2 cards in a 4-slot hand ('+JSON.stringify(nm)+')');
 const t0=await E(()=>{const B=__game.B;B.hand=['fire','heal','sword','lance'];B.hand[0]=null;B.hand[1]=null;B.xdeal=0;return B.hand.filter(Boolean).length;});await sleep(3200);
 ok(await E(t=>__game.B.hand.filter(Boolean).length===t+1,t0),'main game: slots refill one card at a time (2.5s)');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
