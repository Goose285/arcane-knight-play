// M47: hero fishing = side profile when the water is to the side (mirrored for left), subtle body motion (breathing, weight shift, lean on a bite, pull-back on a catch).  node tests/ms47.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms47',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.resetPets();d.TRK.open=false;
   for(const e of g.enemies)if(e.alive){e.alive=false;e.hidden=true;e.x=64;e.y=64;e.respawn=1e9;}d.resetFish();d.FSH.rod=0;g.P.grace=99;});
 const start=(tx,ty,spot,dx=0,dy=0)=>E((tx,ty,id,dx,dy)=>{const g=__game,d=g.dbg;d.endFishing();g.tp(tx,ty);g.P.x=tx*32+16+dx;g.P.y=ty*32+28+dy;g.P.dir='d';g.snapCam&&g.snapCam();return d.startFishing(d.FISH_SPOTS.find(s=>s.id===id));},tx,ty,spot,dx,dy);
 const info=()=>E(()=>{const d=__game.dbg,g=__game;return {dir:g.P.dir,ph:d.FISH.ph,pose:d.fishPose()};});
 // ---- water to the right
 ok(await start(24,41,'oak2'),'fishing starts with water to the right');
 let i=await info();ok(i.dir==='r','water right of the hero: faces right ('+i.dir+')');
 await sleep(1500);await E(()=>{__game.dbg.FISH.next=1e9;});await sleep(300);await shot('fish-side-right.png');
 // ---- diagonal (water down-right, a bit more down than right) still gets the side view
 ok(await start(24,43,'oak1',0,4),'fishing starts diagonally');i=await info();ok(i.dir==='r','water down-and-right of the hero: side profile ('+i.dir+')');
 // ---- water to the left (hero on the east bank)
 await E(()=>{__game.dbg.FSH.xp=1e5;});const oy=await E(()=>__game.dbg.ZONE_Y0.desert+24);
 ok(await start(47,oy,'oasis'),'fishing starts with water to the left');i=await info();ok(i.dir==='l','water left of the hero: faces left, mirrored sprite ('+i.dir+')');
 await sleep(1500);await E(()=>{__game.dbg.FISH.next=1e9;});await sleep(300);await shot('fish-side-left.png');
 const spr=await E(()=>{const d=__game.dbg;return {l:d.SP&&d.SP.hero?d.SP.hero.l.length:3};});
 // ---- straight up / down still use back / front
 await start(25,43,'oak1',0,-20);i=await info();ok(i.dir==='d'||i.dir==='r'||i.dir==='l','vertical case resolves to a facing ('+i.dir+')');
 // ---- body motion: breathing bob, weight shift, lean on bite, pull-back on catch
 await start(24,41,'oak2');await sleep(1200);
 const br=await E(async()=>{const d=__game.dbg,v=[];for(let k=0;k<30;k++){v.push(d.fishPose().oy);await new Promise(r=>setTimeout(r,90));}return {min:Math.min(...v),max:Math.max(...v)};});
 ok(br.max-br.min>.6&&br.max-br.min<2.5,'idle: gentle breathing bob (oy range '+br.min.toFixed(2)+'..'+br.max.toFixed(2)+')');
 const sh=await E(()=>{const d=__game.dbg;d.FISH.sh={t:0,dur:.6,nx:99,d:1,step:true};return null;});await sleep(200);
 const sp=await E(()=>{const d=__game.dbg,p=d.fishPose();return {step:p.step,oy:p.oy,ox:p.ox};});ok(sp.step>0,'weight shift: a small step (leg frame '+sp.step+')');
 await sleep(700);
 await E(()=>{const d=__game.dbg;d.FISH.sh={t:99,dur:1,nx:99,d:1,step:false};d.FISH.ph='rare';d.FISH.t=0;d.FISH.win=4;d.FISH.rare=4;});await sleep(250);
 const bi=await E(()=>{const d=__game.dbg,p=d.fishPose();return {lean:p.lean,ox:p.ox,bend:p.bend};});ok(bi.lean>.04&&bi.ox>0,'rare bite: leans toward the water ('+JSON.stringify(bi)+')');
 await shot('fish-body-bite.png');
 await E(()=>{const d=__game.dbg;d.FISH.ph='on';d.FISH.t=0;d.FISH.next=1e9;d.FISH.yank=.55;});await sleep(150);
 const pb=await E(()=>{const d=__game.dbg,p=d.fishPose();return {lean:p.lean,ox:p.ox};});ok(pb.lean<-.03&&pb.ox<-1,'catch: small pull-back away from the water ('+JSON.stringify(pb)+')');
 await E(()=>{__game.dbg.endFishing();});
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
