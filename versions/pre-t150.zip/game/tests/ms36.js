// M36: main-game card targeting - ranged/area cards: tap card, tap the world to cast; melee/heal/buff/self cards fire on ONE tap, every time.  node tests/ms36.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms36',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.lv=Math.max(g.P.lv,12);});
 const px=(x,y)=>E((x,y)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+x/z.VW*c.width,y:c.top+y/z.VH*c.height};},x,y);
 const clickAt=async(x,y)=>{const p=await px(x,y);if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);};
 const cardPt=i=>E(i=>{const r=__game.cardRects[i];return r?{x:r.cx!=null?r.cx:r.x+r.w/2,y:r.cy!=null?r.cy:r.y+r.h/2}:null;},i);
 const hand=()=>E(()=>__game.B.hand.slice());
 // a fight in open ground north of Oakvale with one tough, passive slime on screen
 const fight=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.calm=0;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;});
   g.tp(11,20);g.P.x=11*32+16;g.P.y=20*32+28;g.P.hp=g.P.hp=d.maxHp();g.P.grace=0;
   const e=g.enemies.find(q=>q.type==='slime'&&!q.def.boss);e.x=e.hx=(11+3.2)*32;e.y=e.hy=20*32+28;e.hp=e.maxhp=e.mhp=1e7;window.__e=e;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.inv=99;e.atkCd=1e9;e.joinT=0;e.st='idle';return !!B;});
 const prep=id=>E(id=>{const g=__game,B=g.B;B.inv=99;B.xsel=-1;B.sel=0;B.gauge=0;B.xdeal=0;B.hand=[id,'sword','sword','sword'];B.shots.length=0;window.__e.hp=window.__e.maxhp=1e7;window.__e.dying=false;g.P.hp=g.dbg.maxHp();g.P.x=11*32+16;g.P.y=20*32+28;window.__e.stun=0;},id);
 const foeScr=()=>E(()=>{const g=__game,c=g.dbg.ecen(window.__e);return {x:c.x-g.cam.x,y:c.y-g.cam.y};});
 ok(await fight(),'a fight starts in the main game');
 ok(await E(()=>__game.dbg.expCards()&&__game.dbg.expAim()&&!__game.dbg.labOn()),'main game (not the lab): card targeting + 4-card hand are on');
 const ids=await E(()=>__game.dbg.CARDS.map(c=>c.id));
 const INSTANT=['sword','shield','heal','haste','decoy','ward','reflect','timestop','quake','wolf','shadow'];
 const bad=[];
 for(const id of ids){
   await prep(id);await sleep(260);
   let cp=await cardPt(0);if(!cp){bad.push(id+':no rect');continue;}
   await clickAt(cp.x,cp.y);await sleep(90);
   const s1=await E(()=>({h:__game.B.hand[0],x:__game.B.xsel,phase:__game.B.phase}));
   if(INSTANT.includes(id)){
     if(s1.h!==null)bad.push(id+': single tap did not cast ('+JSON.stringify(s1)+')');
   }else{
     if(!(s1.h===id&&s1.x===0)){bad.push(id+': ranged card should only select ('+JSON.stringify(s1)+')');continue;}
     const f=await foeScr();await clickAt(f.x,f.y);await sleep(90);
     const s2=await E(()=>({h:__game.B.hand[0],x:__game.B.xsel}));
     if(!(s2.h===null&&s2.x===-1))bad.push(id+': world tap did not cast ('+JSON.stringify(s2)+')');
   }
   if(!await E(()=>!!__game.B)){bad.push(id+': fight ended');await fight();}
 }
 ok(bad.length===0,'all '+ids.length+' cards behave: '+(bad.join(' | ')||'instant ones fire on one tap, ranged ones select then cast on the world tap'));
 // melee strictness: the Sword and every melee-type card can never enter aim mode
 const mel=await E(()=>{const d=__game.dbg;return d.CARDS.filter(c=>c.melee||/melee/i.test(c.desc)).map(c=>({id:c.id,aimed:d.expAimed(c.id)}));});
 ok(mel.length>=3&&mel.some(m=>m.id==='sword')&&mel.every(m=>!m.aimed),'sword + all melee cards are one-tap only, never aimed ('+mel.map(m=>m.id).join(',')+')');
 // ---- cancel + no beam / reticle
 await prep('fire');await E(()=>{const B=__game.B,h=['fire','heal','lance','chain','poison','shield','meteor'];B.hand=h.slice(0,B.hand.length);B.sel=0;});await sleep(260);let cp=await cardPt(0);await clickAt(cp.x,cp.y);await sleep(120);
 ok(await E(()=>__game.dbg.expAimId()==='fire'),'FIREBALL selected: aim mode on');
 const n0=await E(()=>__game.dbg.AIMV.drawn);await sleep(350);
 ok((await E(()=>__game.dbg.AIMV.drawn))===n0,'a selected card draws no dashed beam / footprint preview');
 const f0=await foeScr();
 if(!MOBILE){const p=await px(f0.x,f0.y);await pg.mouse.move(p.x,p.y);}
 await E(()=>{const B=__game.B;(B.texts||[]).length=0;});await sleep(300);await shot(MOBILE?'ranged-aim.png':'ranged-aim-desktop.png');
 cp=await cardPt(0);await clickAt(cp.x,cp.y);await sleep(80);
 ok(await E(()=>__game.B.xsel===-1&&__game.B.hand[0]==='fire'),'tapping the card again cancels, card kept');
 // swap selection: select fire, then tap lance
 await prep('fire');await E(()=>{const B=__game.B;B.hand[1]='lance';B.hand[2]='fire';});await sleep(260);
 cp=await cardPt(0);await clickAt(cp.x,cp.y);await sleep(80);cp=await cardPt(1);await clickAt(cp.x,cp.y);await sleep(80);
 ok(await E(()=>__game.B.xsel===1&&__game.B.hand[0]==='fire'&&__game.B.hand[1]==='lance'),'tapping a different ranged card switches the selection (nothing cast)');
 // the cast goes where you tap: tap empty ground away from the foe
 const far=await E(()=>{const g=__game,d=g.dbg,z=g.size,pc=d.pcen();let best=null;for(let q=0;q<6.28;q+=.2){const x=pc.x-g.cam.x+Math.cos(q)*150,y=pc.y-g.cam.y+Math.sin(q)*110;if(x<40||x>z.VW-40||y<80||y>z.VH*.6)continue;const f=d.ecen(window.__e),m=Math.hypot(f.x-g.cam.x-x,f.y-g.cam.y-y);if(!best||m>best.m)best={x,y,m,q};}return best;});
 await E(()=>{const B=__game.B;B.shots.length=0;B.hand[1]=null;B.xsel=2;B.sel=2;B.xid='fire';});await clickAt(far.x,far.y);await sleep(40);
 const sh=await E(()=>{const g=__game,s=g.B.shots.filter(q=>q.own==='p').slice(-1)[0];return {a:s?Math.atan2(s.vy,s.vx):null,spent:g.B.hand[2]===null};});
 const want=await E((fx,fy)=>{const g=__game,pc=g.dbg.pcen();return Math.atan2(fy+g.cam.y-pc.y,fx+g.cam.x-pc.x);},far.x,far.y);
 ok(sh.spent&&sh.a!=null&&Math.abs(Math.atan2(Math.sin(sh.a-want),Math.cos(sh.a-want)))<.2,'the fireball flies to the tapped spot ('+JSON.stringify(sh)+' want '+want.toFixed(2)+')');
 // ---- sloppy taps still count: finger/mouse drifts 14px while pressing a card
 await prep('heal');await sleep(260);cp=await cardPt(0);
 const p0=await px(cp.x,cp.y);
 if(MOBILE){await pg.touchscreen.touchStart(p0.x,p0.y);await pg.touchscreen.touchMove(p0.x+9,p0.y-8);await pg.touchscreen.touchEnd();}
 else{await pg.mouse.move(p0.x,p0.y);await pg.mouse.down();await pg.mouse.move(p0.x+9,p0.y-8);await pg.mouse.up();}
 await sleep(120);
 ok(await E(()=>__game.B.hand[0]===null),'a tap that drifts ~12px still fires a self card');
 // keyboard number keys follow the same rules
 await prep('fire');await sleep(200);await pg.keyboard.press('Digit1');await sleep(120);
 ok(await E(()=>__game.B.xsel===0&&__game.B.hand[0]==='fire'),'number key on a ranged card selects it');
 await pg.keyboard.press('Digit1');await sleep(120);
 ok(await E(()=>__game.B.xsel===-1&&__game.B.hand[0]==='fire'),'pressing it again cancels');
 await prep('heal');await sleep(200);await pg.keyboard.press('Digit1');await sleep(120);
 ok(await E(()=>__game.B.hand[0]===null),'number key on a heal casts at once');
 // selection is dropped when the hand changes under it
 await prep('fire');await sleep(200);await E(()=>{__game.dbg.expCardTap(0);});await E(()=>{__game.B.hand[0]='heal';});await sleep(150);
 ok(await E(()=>__game.B.xsel===-1),'selection clears if its card is replaced');
 await E(()=>{__game.dbg.endFight();});
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
