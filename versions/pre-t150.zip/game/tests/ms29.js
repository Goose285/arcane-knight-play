// M29: guaranteed card rewards for the hard-to-get cards.  node tests/ms29.js [desktop|mobile]
const fs=require('fs'),boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,finish}=await boot('ms29');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);g.state='play';d.endFight();g.DLG=null;d.resetCards();});
 // ---- quests
 const MAP=[['slimes','haste'],['ring','ward'],['goblins','chain'],['crypt','shadow'],['fish2','poison']];
 for(const [q,card] of MAP){
   const r=await E((q,card)=>{const g=__game,d=g.dbg;const before=d.getCol()[card]|0;d.QS.st[q]='ready';d.questComplete(q);return {before,after:d.getCol()[card]|0,st:d.QS.st[q],txt:d.questRewardText(d.QUEST_BY_ID[q].reward)};},q,card);
   ok(r.before===0&&r.after===1&&r.st==='done',q+' quest hands over '+card+' ('+r.before+' -> '+r.after+')');ok(new RegExp('card').test(r.txt),q+' quest log lists the card reward ('+r.txt+')');}
 const li=await E(()=>{const d=__game.dbg;d.QS.st.lich='ready';d.questComplete('lich');const c=d.getCol();return {ts:c.timestop|0,cu:c.curse|0};});
 ok(li.ts===1&&li.cu===1,'the Lich King quest pays both Time Stop and Curse ('+JSON.stringify(li)+')');
 // ---- bosses
 const bo=await E(()=>{const d=__game.dbg;const o={};d.guarOnBossKill({type:'dragon',x:100,y:100});o.reflect=d.getCol().reflect|0;d.guarOnBossKill({type:'dragon',x:100,y:100});o.reflect2=d.getCol().reflect|0;
   d.guarOnBossKill({type:'rimegar',x:100,y:100});o.wolf=d.getCol().wolf|0;d.guarOnBossKill({type:'colossus',x:1,y:1});o.keys=Object.keys(d.GUAR_GOT());return o;});
 ok(bo.reflect===1&&bo.reflect2===1,'Emberfang drops Reflect the first time only');ok(bo.wolf===1,'Rimegar drops Summon Wolf');ok(bo.keys.includes('boss:dragon')&&bo.keys.includes('boss:rimegar')&&!bo.keys.includes('boss:colossus'),'only mapped bosses are tracked ('+bo.keys+')');
 await E(()=>{const d=__game.dbg;delete d.GUAR_GOT()['boss:dragon'];});
 ok(await E(()=>{const d=__game.dbg;d.guarOnBossKill({type:'dragon',rush:true,x:1,y:1});return !d.GUAR_GOT()['boss:dragon'];}),'boss-rush clones do not count');
 // ---- spawner
 const sp=await E(()=>{const g=__game,d=g.dbg;d.resetSpawners();const s=d.SPW[0];const b=d.getCol().decoy|0;d.destroySpawner(s);return {b,a:d.getCol().decoy|0,k:!!d.GUAR_GOT().spawner};});
 ok(sp.b===0&&sp.a>=1&&sp.k,'the first monster spawner you destroy pays Decoy ('+JSON.stringify(sp)+')');
 ok(await E(()=>{const d=__game.dbg;return d.guarGrant('spawner','decoy')===false;}),'...and only once');
 // ---- saved with the cards
 ok(await E(()=>{const d=__game.dbg,pk=JSON.parse(JSON.stringify(d.packCards()));d.unpackCards(pk);return !!d.GUAR_GOT().spawner&&!!d.GUAR_GOT()['boss:rimegar']&&d.guarGrant('boss:rimegar','wolf')===false;}),'milestones survive a save/load round trip');
 // ---- wiring
 const html=fs.readFileSync(require('path').join(__dirname,'..','index.html'),'utf8');
 ok(/trophyOnKill\(e\);guarOnBossKill\(e\)/.test(html),'the boss kill path calls the guaranteed-reward hook');
 ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
