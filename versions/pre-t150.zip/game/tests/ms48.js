// M48: walking into your house door works the FIRST time (resting against the door / sliding along the wall / diagonal stick), not only after walking up from below.  node tests/ms48.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms48',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);g.DLG=null;g.state='play';d.endFight();g.P.grace=99;});
 const tryDoor=async(label,y,dx,keys)=>{
  await E((dx,y)=>{const g=__game,d=g.dbg;g.state='play';g.WARP=null;g.tp(d.HOUSE_DOOR.tx,d.HOUSE_DOOR.ty+1);g.P.x=d.HOUSE_FRONT.x+dx;g.P.y=y;g.P.dir='d';g.P.grace=99;},dx,y);
  await sleep(300);for(const k of keys)await pg.keyboard.down(k);await sleep(1100);
  const inside=await E(()=>__game.dbg.zoneOfPx(__game.P.y)==='house'||!!__game.WARP);
  for(const k of keys)await pg.keyboard.up(k);await sleep(2300);
  ok(inside,'door: '+label);return inside;};
 const g0=await E(()=>({front:__game.dbg.HOUSE_FRONT.y}));
 await tryDoor('resting against the door, pressing up (first try, no run-up)',1416,0,['ArrowUp']);
 await tryDoor('resting against the door at the edge of the doorway',1416,12,['ArrowUp']);
 await tryDoor('pushing up + slightly right against the wall (diagonal stick / sliding)',1416,-6,['ArrowUp','ArrowRight']);
 await tryDoor('walking up from below',g0.front+30,0,['ArrowUp']);
 // beside the door is still a wall: no entry
 await E(()=>{const g=__game,d=g.dbg;g.state='play';g.WARP=null;g.tp(d.HOUSE_DOOR.tx-1,d.HOUSE_DOOR.ty+1);g.P.x=d.HOUSE_FRONT.x-40;g.P.y=1416;g.P.grace=99;});await sleep(200);
 await pg.keyboard.down('ArrowUp');await sleep(700);const bw=await E(()=>__game.dbg.zoneOfPx(__game.P.y));await pg.keyboard.up('ArrowUp');
 ok(bw==='ow','pressing up against the wall next to the door does not enter');
 await finish();
})();
