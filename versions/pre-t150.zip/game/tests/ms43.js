// M43: water/land edge blending + big trees (default on): collision stays at the trunk, canopy covers + fades over hero/NPC/quest markers.  node tests/ms43.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms43',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.resetPets();d.TRK.open=false;
   for(const e of g.enemies)if(e.alive){e.alive=false;e.hidden=true;e.x=64;e.y=64;e.respawn=1e9;}});
 // ---- water edges
 const w=await E(()=>{const g=__game,d=g.dbg,m=g.map||d.map;let water=0,bank=0,shore=0;
   for(let y=0;y<m.length;y++)for(let x=0;x<m[0].length;x++){const id=m[y][x],k=d.weMask(x,y);if(d.WE_WATER.has(id)){water++;if(k)shore++;}else if(d.WE_LAND.has(id)&&k)bank++;}
   return {water,shore,bank};});
 ok(w.water>50&&w.shore>20&&w.bank>20,'edge masks built for rivers/pools: '+JSON.stringify(w));
 const bx=await E(()=>{const g=__game,d=g.dbg,m=g.map||d.map;let tot=0,swim=0,diff=0;const c=document.createElement('canvas');c.width=c.height=16;const k=c.getContext('2d');
   for(let y=0;y<m.length;y++)for(let x=0;x<m[0].length;x++){if(d.WE_LAND.has(m[y][x])&&d.weMask(x,y)){tot++;k.clearRect(0,0,16,16);k.drawImage(g.tileSpriteOf(m[y][x],x,y,0),0,0);const px=k.getImageData(0,0,16,16).data;let a=0,br=0;for(let i=0;i<px.length;i+=4){if(px[i+3]<255)a++;if(px[i]>px[i+1]+12)br++;}if(a)swim++;if(br>6)diff++;}}return {tot,swim,diff};});
 ok(bx.tot>0&&bx.swim===0&&bx.diff>bx.tot*.8,'bank tiles are opaque composites with brown dirt/pebbles ('+JSON.stringify(bx)+')');
 const wt=await E(()=>{const g=__game,d=g.dbg,m=g.map||d.map;let n=0,shore=0;const c=document.createElement('canvas');c.width=c.height=16;const k=c.getContext('2d');
   for(let y=0;y<m.length;y++)for(let x=0;x<m[0].length;x++){if(d.WE_WATER.has(m[y][x])&&d.weMask(x,y)){n++;k.clearRect(0,0,16,16);k.drawImage(g.tileSpriteOf(m[y][x],x,y,0),0,0);const px=k.getImageData(0,0,16,16).data;let dk=0;for(let i=0;i<px.length;i+=4)if(px[i+2]<170&&px[i]<70)dk++;if(dk>4)shore++;}}return {n,shore};});
 ok(wt.n>0&&wt.shore>wt.n*.6,'water tiles at the shore carry the shallow/depth band ('+JSON.stringify(wt)+')');
 // ---- big trees: default 2x
 ok(await E(()=>__game.dbg.BIGTREE===2&&__game.dbg.BIGTREE_IDS.has(1)&&!__game.dbg.BIGTREE_IDS.has(29)),'big trees on by default (2x), bushes/stumps/reeds not scaled');
 const T=await E(()=>{const g=__game,d=g.dbg,m=g.map||d.map;const W=m[0].length;
   for(let y=8;y<60;y++)for(let x=3;x<W-3;x++){if(m[y][x]!==1)continue;let free=true;for(let dy=-3;dy<=-1;dy++)for(let dx=-1;dx<=1;dx++)if(d.solidTile(x+dx,y+dy))free=false;if(free&&!d.solidTile(x,y+1)&&!d.solidTile(x,y+2))return [x,y];}return null;});
 ok(!!T,'found a lone tree tile at '+T);
 await E((tx,ty)=>{const g=__game,d=g.dbg;g.tp(tx,ty+2);d.petSnap&&d.petSnap();g.P.grace=99;},T[0],T[1]);await sleep(3800);
 const col=await E((tx,ty)=>{const d=__game.dbg;return {trunk:d.solidTile(tx,ty),above:d.solidTile(tx,ty-1),above2:d.solidTile(tx,ty-2),side:d.solidTile(tx-1,ty)};},T[0],T[1]);
 ok(col.trunk&&!col.above&&!col.above2&&!col.side,'collision is the trunk tile only; canopy area is walkable ('+JSON.stringify(col)+')');
 await E((tx,ty)=>{const g=__game;g.P.x=tx*32+16;g.P.y=ty*32+16;},T[0],T[1]-1);   // hero directly behind the trunk (north of it)
 await sleep(900);
 const key=(tx,ty)=>[tx,ty];
 const F=(tx,ty)=>E((tx,ty)=>{const g=__game,d=g.dbg;return d.TREE_FADE.get(ty*(g.map||d.map)[0].length+tx);},tx,ty);
 const f=await F(T[0],T[1]);
 ok(f!==undefined&&f<.7,'canopy fades while the hero is under it (alpha '+(f&&f.toFixed(2))+')');
 await shot('trees-under-canopy.png');
 await E((tx,ty)=>{const g=__game;g.P.x=tx*32+16;g.P.y=(ty+2)*32+16;},T[0],T[1]);await sleep(900);
 ok((await F(T[0],T[1]))===undefined,'canopy is fully opaque again with the hero in front');
 await E((tx,ty)=>{const d=__game.dbg;const n=d.NPCS[0];window.__npc={x:n.x,y:n.y};n.x=tx*32+16;n.y=(ty-1)*32+16;},T[0],T[1]);await sleep(900);
 const f3=await F(T[0],T[1]);
 ok(f3!==undefined&&f3<.7,'canopy also fades for an NPC / quest marker behind it ('+(f3&&f3.toFixed(2))+')');
 await E(()=>{const n=__game.dbg.NPCS[0];n.x=window.__npc.x;n.y=window.__npc.y;});
 // the hero can walk behind a tree (north of the trunk) from the side without being blocked by the canopy
 const walk=await E((tx,ty)=>{const g=__game,d=g.dbg;g.P.x=(tx+1)*32+16;g.P.y=(ty+1)*32+16;let ok=true;for(const [x,y] of [[tx+1,ty],[tx+1,ty-1],[tx,ty-1],[tx,ty-2]])if(d.solidTile(x,y))ok=false;return ok;},T[0],T[1]);
 ok(walk,'path around the trunk to the space behind the tree is open');
 await finish();
})();
