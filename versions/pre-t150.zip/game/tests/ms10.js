// M10: pets / companions with small attacks + the player house with trophy shelves.  node tests/ms10.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,MOBILE,pg}=await boot('ms10');
 const calm=()=>E(()=>{const g=__game;g.dbg.endFight();g.state='play';g.DLG=null;g.dbg.UI.mode=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.P.grace=99;g.P.hp=g.dbg.maxHp();});
 await calm();

 // ================= PETS =================
 const dat=await E(()=>{const g=__game,d=g.dbg,o={};
   o.four=d.PET_IDS.length===4&&d.PET_IDS.every(i=>d.PETS[i].name&&d.PETS[i].price>0&&d.PETS[i].col&&d.PETS[i].desc);
   o.names=new Set(d.PET_IDS.map(i=>d.PETS[i].name)).size===4;
   const k=g.npcs.find(n=>n.pets);o.keeper=!!k&&d.reach[Math.floor(k.y/32)][Math.floor(k.x/32)];
   o.none=d.PET.active===null&&Object.keys(d.PET.owned).length===0;return o;});
 for(const [k,v] of Object.entries(dat))ok(v,'pets data: '+k);
 const ad=await E(()=>{const g=__game,d=g.dbg,o={};g.P.gold=10;o.poor=d.adoptPet('cinder')===false&&!d.PET.owned.cinder;
   g.P.gold=1000;const g0=g.P.gold;o.buy=d.adoptPet('cinder')===true&&d.PET.owned.cinder&&g0-g.P.gold===d.PETS.cinder.price;o.first=d.PET.active==='cinder';
   o.dup=d.adoptPet('cinder')===false;d.adoptPet('wisp');o.stay=d.PET.active==='cinder';
   o.sum=d.summonPet('wisp')&&d.PET.active==='wisp';o.rest=d.summonPet(null)&&d.PET.active===null;o.unowned=d.summonPet('moth')===false;
   d.summonPet('cinder');return o;});
 for(const [k,v] of Object.entries(ad))ok(v,'adopt: '+k);
 // follows the hero
 const fol=await E(async()=>{const g=__game,d=g.dbg;g.tp(10,36);g.P.hp=d.maxHp();await new Promise(r=>setTimeout(r,700));
   const p0=Math.hypot(d.PET.x-g.P.x,d.PET.y-g.P.y);g.P.x+=0;let dist=[];
   for(let i=0;i<8;i++){g.P.x+=22;g.P.dir='r';g.P.moving=true;await new Promise(r=>setTimeout(r,90));dist.push(Math.hypot(d.PET.x-g.P.x,d.PET.y-g.P.y));}
   await new Promise(r=>setTimeout(r,700));const after=Math.hypot(d.PET.x-g.P.x,d.PET.y-g.P.y);
   g.P.x+=900;await new Promise(r=>setTimeout(r,150));const snap=Math.hypot(d.PET.x-g.P.x,d.PET.y-g.P.y);
   return {p0,max:Math.max(...dist),after,snap};});
 ok(fol.p0<40&&fol.after<50,'pet: stays right behind the hero ('+fol.after.toFixed(0)+'px)');ok(fol.max<260,'pet: lags a little but keeps up while running');ok(fol.snap<60,'pet: catches up instantly after a teleport');
 // attacks inside a real fight
 const atk=async(id,lvl)=>E(async(id,lvl)=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.P.hp=Math.round(d.maxHp()*.5);g.P.grace=0;d.PET.owned[id]=true;d.summonPet(id);d.PET.bond[id]=lvl||0;
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.dyT=0;d.applyLevel(e,3);e.hp=e.maxhp=e.mhp=9999;e.chill=0;
   g.tp(Math.floor(e.x/32)-3,Math.floor(e.y/32));g.P.x=e.x-110;g.P.y=e.y;d.PET.x=g.P.x;d.PET.y=g.P.y;d.PET.cd=.05;d.PET.bcd=1e9;e.engaged=false;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.noiseT=1e9;B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;});B.inv=0;
   const h0=e.hp,p0=g.P.hp;let shot=false,kind=null;
   for(let i=0;i<60&&e.hp===h0&&g.P.hp<=p0;i++){await new Promise(r=>setTimeout(r,100));const s=B.shots.find(q=>q.kind==='pet');if(s){shot=true;kind=s.pk;}}
   await new Promise(r=>setTimeout(r,500));
   const r={shot,kind,dealt:h0-e.hp,healed:g.P.hp-p0,chill:e.chill>0,dmg:d.petDmg(id),lv:d.petLevel(id)};d.endFight();return r;},id,lvl);
 const atkR=async(id,l)=>{let r;for(let i=0;i<3;i++){r=await atk(id,l);if(r.shot||id==='moth')break;}return r;};   // retry: a loaded machine can miss the first window
 const a1=await atkR('cinder');ok(a1.shot&&a1.kind==='ember'&&a1.dealt>0,'cinderpup: shoots an ember on its own and damages the target ('+a1.dealt+')');
 const a2=await atkR('wisp');ok(a2.shot&&a2.dealt>0&&a2.chill,'rime wisp: frost shard damages and chills');
 const a3=await atkR('moth');ok(a3.healed>0&&!a3.shot,'gloam moth: heals the hero instead of attacking ('+a3.healed+')');
 const a4=await atkR('pebblin');ok(a4.shot&&a4.kind==='pebble'&&a4.dealt>a1.dealt,'pebblin: slow but hits harder ('+a4.dealt+' vs '+a1.dealt+')');
 ok(a1.dmg<=Math.round(a1.dmg)&&a1.dmg>=5,'pet damage is small ('+a1.dmg+')');
 const lv=await E(()=>{const d=__game.dbg;d.PET.bond.cinder=0;const l1=d.petLevel('cinder'),m1=d.petDmg('cinder');d.PET.bond.cinder=8*4;const l5=d.petLevel('cinder'),m5=d.petDmg('cinder');d.PET.bond.cinder=999;return {l1,l5,up:m5>m1*1.8,cap:d.petLevel('cinder')===5};});
 ok(lv.l1===1&&lv.l5===5&&lv.up&&lv.cap,'bond: levels 1..5 and damage scales up');
 const bond=await E(async()=>{const g=__game,d=g.dbg;d.endFight();d.summonPet('cinder');d.PET.bond.cinder=0;
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive);e.dying=false;g.P.x=e.x-90;g.P.y=e.y;e.engaged=false;d.startEncounter(e,true);g.B.phase='fight';d.damageEnemy(e,e.hp+9999,'fire');
   const r=d.PET.bond.cinder;d.endFight();return r;});
 ok(bond===1,'bond: +1 per kill with the pet out');
 // elites and pets: pet hits never trigger thorns
 const th=await E(()=>{const g=__game,d=g.dbg;d.endFight();const e=g.enemies.find(x=>x.type==='knight'&&x.alive&&!x.def.boss);e.dying=false;d.makeElite(e,['thorned']);g.P.x=e.x-90;g.P.y=e.y;e.engaged=false;d.startEncounter(e,true);g.B.phase='fight';g.B.noiseT=1e9;const p0=g.P.hp;d.damageEnemy(e,40,'pet');const r=p0-g.P.hp;d.endFight();return r;});
 ok(th===0,'pets: thorns do not reflect a pet\'s hits');
 // save / load
 const sv=await E(()=>{const g=__game,d=g.dbg;d.summonPet('wisp');d.PET.bond.wisp=17;d.awardTrophy('fang');d.HOUSE.slots[2]='fang';const p=d.packPets(),j=JSON.parse(JSON.stringify(p));d.resetPets();const wiped=!d.PET.active&&!d.HOUSE.trophies.fang;d.unpackPets(j);
   const bad=(d.unpackPets({owned:{x:true,cinder:true},active:'nope',house:{t:{fang:true,zz:true},s:['crown','fang']}}),d.PET.active===null&&d.PET.owned.cinder&&!d.PET.owned.x&&d.HOUSE.slots[0]===null&&d.HOUSE.slots[1]==='fang');
   d.unpackPets(j);return {wiped,ok:d.PET.active==='wisp'&&d.PET.bond.wisp===17&&d.HOUSE.trophies.fang&&d.HOUSE.slots[2]==='fang',bad};});
 ok(sv.wiped&&sv.ok,'save: pets, bond, trophies and shelves round-trip');ok(sv.bad,'save: junk data is sanitised');
 const sv2=await E(()=>{const g=__game,d=g.dbg;d.saveNow();const s=g.readSave();return !!s&&!!s.pets&&s.pets.active==='wisp';});ok(sv2,'save: stored in the save file');

 // ---- screens ----
 await calm();
 const talk=await E(async()=>{const g=__game,d=g.dbg;d.resetPets();g.P.gold=2000;const n=g.npcs.find(x=>x.pets);g.P.x=n.x+18;g.P.y=n.y;g.P.dir='l';g.press('KeyE');await new Promise(r=>setTimeout(r,300));return {st:g.state,mode:d.UI.mode};});
 ok(talk.st==='pets'&&talk.mode==='pets','keeper: talking opens the pets screen');
 await sleep(150);ok(await tap('pet:cinder',0),'screen: ADOPT button on screen');await sleep(300);
 const adopted=await E(()=>({own:!!__game.dbg.PET.owned.cinder,act:__game.dbg.PET.active}));ok(adopted.own&&adopted.act==='cinder','screen: tapping ADOPT buys the pet');
 await tap('pet:wisp',0);await sleep(200);await tap('pet:wisp',0);await sleep(200);
 await E(()=>{const d=__game.dbg;d.adoptPet('moth');d.PET.bond.cinder=20;});await sleep(250);await shot('pets-screen.png');
 await E(()=>{__game.dbg.summonPet('cinder');});await sleep(150);ok(await tap('pet:wisp',0),'screen: SUMMON button on screen');await sleep(200);ok(await E(()=>__game.dbg.PET.active==='wisp'),'screen: tapping SUMMON swaps the pet');
 // pause menu entry
 const pm=await E(()=>{const g=__game,d=g.dbg;d.closeUI();g.state='play';return d.PAUSE_ITEMS.some(i=>i.k==='KeyO'&&/PETS/.test(i.lab()));});ok(pm,'pause menu: PETS entry');
 await E(()=>{const g=__game,d=g.dbg;g.state='paused';d.PAUSE_ITEMS.find(i=>i.k==='KeyO').act();});await sleep(200);ok(await E(()=>__game.state==='pets'),'pause menu: PETS opens the screen');
 await E(()=>{__game.dbg.closeUI();});await calm();

 // ================= HOUSE =================
 const hz=await E(()=>{const g=__game,d=g.dbg,o={};o.zone=d.zoneOfTy(d.HOUSE_Y0+5)==='house'&&d.map.length>=224&&d.areaName(30,d.HOUSE_Y0+6)==='YOUR HOUSE';
   o.door=!!d.reach[d.HOUSE_DOOR.ty][d.HOUSE_DOOR.tx]&&!g.npcs.some(x=>x.house==='door'||x.spr==='houseSign');   // the front is reachable and the sign is gone
   o.floor=d.map[d.HOUSE_ROOM.y0+2][30]===d.T.F;o.exit=Object.values(d.ZEXITS).includes('house');o.slots=d.HOUSE_SLOTS.length===8&&d.HOUSE_SLOTS.every(([x,y])=>d.map[y][x]===d.T.F);
   o.shelf=!!g.npcs.find(x=>x.house==='shelf')&&!!g.npcs.find(x=>x.house==='bed');o.mini=!!d.MINI.house;return o;});
 for(const [k,v] of Object.entries(hz))ok(v,'house: '+k);
 // enter by tapping the door: the hero walks over and goes in (no sign, no prompt)
 const tp0=await E(()=>{const g=__game,d=g.dbg;g.state='play';g.DLG=null;d.endFight();g.tp(17,45);g.P.x=17*32+16;g.P.y=45*32+28;g.P.grace=99;g.snapCam&&g.snapCam();
   const t=d.worldTargetAt({x:(d.HOUSE_DOOR.tx+.5)*32-g.cam.x,y:(d.HOUSE_DOOR.ty-.4)*32-g.cam.y});return {k:t&&t.k,set:!!t&&d.setGoto(t)};});
 ok(tp0.k==='door'&&tp0.set,'house: tapping the door starts a walk to it');
 await sleep(2500);
 const ent=await E(async()=>{const g=__game,d=g.dbg;await new Promise(r=>setTimeout(r,1000));return {in:d.zoneOfPx(g.P.y)==='house',area:g.areaCur,music:d.musWant(),pet:Math.hypot(d.PET.x-g.P.x,d.PET.y-g.P.y)<60,dlg:!!g.DLG};});
 ok(ent.in&&ent.area==='YOUR HOUSE'&&!ent.dlg,'house: tapping the door warps you inside with no prompt');ok(ent.music==='village','house: cosy music');ok(ent.pet,'house: your pet comes along');
 // leave and walk into the door
 await E(async()=>{const g=__game,d=g.dbg;g.state='play';d.startWarp({x:d.HOUSE_FRONT.x,y:d.HOUSE_FRONT.y+22,dir:'u'});await new Promise(r=>setTimeout(r,1200));g.P.grace=99;});
 await pg.keyboard.down('ArrowUp');await sleep(1500);await pg.keyboard.up('ArrowUp');
 const out={in:await E(()=>__game.dbg.zoneOfPx(__game.P.y)==='house')};
 ok(out.in,'house: walking up into the door goes in');
 await E(()=>{const g=__game;g.P.hp=10;});
 const bed=await E(async()=>{const g=__game,d=g.dbg;const n=g.npcs.find(x=>x.house==='bed');g.P.x=n.x+20;g.P.y=n.y;g.P.dir='l';g.press('KeyE');await new Promise(r=>setTimeout(r,250));const r={hp:g.P.hp===d.maxHp(),dlg:!!g.DLG};g.DLG=null;return r;});
 ok(bed.hp&&bed.dlg,'house: the bed restores health');
 // trophies
 const tr=await E(()=>{const g=__game,d=g.dbg,o={};d.resetPets();
   o.none=d.trophyCount()===0;const st=['dragon','lich','rimegar','mossback','colossus'];
   o.boss=st.every(t=>{const e={type:t,def:{boss:true},rush:false};d.trophyOnKill(e);return d.HOUSE.trophies[d.TROPHY_BOSS[t]];});
   o.rush=(()=>{const e={type:'dragon',def:{boss:true},rush:true};d.resetPets();d.trophyOnKill(e);return !d.HOUSE.trophies.fang;})();
   d.resetPets();for(let i=0;i<9;i++)d.trophyOnKill({type:'slime',def:{},elite:['swift'],rush:false});o.nine=!d.HOUSE.trophies.brand;d.trophyOnKill({type:'slime',def:{},elite:['swift'],rush:false});o.brand=!!d.HOUSE.trophies.brand;
   d.resetPets();g.P.gold=9999;['cinder','wisp','moth'].forEach(i=>d.adoptPet(i));o.three=!d.HOUSE.trophies.banner;d.adoptPet('pebblin');o.banner=!!d.HOUSE.trophies.banner;
   d.resetPets();Object.assign(d.RUSH,{on:true,round:3,score:900,t:100,ret:{x:12*32,y:36*32},cur:null});const b=g.B;d.rushFinish('quit');g.DLG=null;o.laurel=!!d.HOUSE.trophies.laurel;
   d.resetPets();Object.assign(d.RUSH,{on:true,round:2,score:500,t:50,ret:{x:12*32,y:36*32},cur:null});d.rushFinish('quit');g.DLG=null;o.noLaurel=!d.HOUSE.trophies.laurel;
   d.setRushLB([]);return o;});
 for(const [k,v] of Object.entries(tr))ok(v,'trophies: '+k);
 await sleep(1200);
 // shelf logic
 const sh=await E(()=>{const g=__game,d=g.dbg,o={};d.resetPets();const first=d.cycleSlot(0);o.empty=first===null;d.awardTrophy('fang');d.awardTrophy('crown');
   const a=d.cycleSlot(0);o.a=a==='fang'||a==='crown';const b=d.cycleSlot(1);o.unique=b!==a&&(b==='fang'||b==='crown');const c=d.cycleSlot(2);o.none=c===null;   // both taken -> only empty
   const seq=[];for(let i=0;i<4;i++)seq.push(d.cycleSlot(3));o.cycle=seq.includes(null);
   d.HOUSE.slots=d.HOUSE_SLOTS.map(()=>null);return o;});
 for(const [k,v] of Object.entries(sh))ok(v,'shelf: '+k);
 // shelf screen
 await E(()=>{const g=__game,d=g.dbg;d.resetPets();['fang','crown','horn','eye','idol','laurel'].forEach(t=>d.awardTrophy(t));d.toasts.length=0;g.state='play';g.P.hp=d.maxHp();
   const n=g.npcs.find(x=>x.house==='shelf');g.P.x=n.x;g.P.y=n.y+24;g.P.dir='u';g.press('KeyE');});await sleep(300);
 ok(await E(()=>__game.state==='house'),'shelf: talking to the shelf opens the trophy screen');
 ok(await tap('slot:0',0),'screen: CHANGE button on screen');await sleep(200);
 for(let i=1;i<6;i++){await tap('slot:'+i,0);await sleep(60);}
 const placed=await E(()=>__game.dbg.HOUSE.slots.filter(Boolean).length);ok(placed>=5,'screen: tapping CHANGE places trophies ('+placed+' on shelves)');
 await sleep(200);await shot('trophy-shelf-screen.png');
 await E(()=>{const g=__game;g.dbg.closeUI();g.state='play';g.dbg.toasts.length=0;g.P.grace=0;g.P.x=31*32+16;g.P.y=(g.dbg.HOUSE_ROOM.y1-3)*32+28;g.P.dir='u';g.dbg.PET.owned.cinder=true;g.dbg.summonPet('cinder');});
 await sleep(900);await E(()=>{__game.dbg.toasts.length=0;});await sleep(120);await shot('house-trophies.png');
 // pet shot picture inside a fight
 await E(()=>{const g=__game,d=g.dbg;g.dbg.endFight();g.dbg.startWarp({x:12*32+16,y:36*32+28,dir:'d'});});await sleep(1000);
 await E(async()=>{const g=__game,d=g.dbg;d.summonPet('wisp');d.PET.bond.wisp=16;g.P.hp=d.maxHp();g.P.grace=0;const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;d.applyLevel(e,3);e.hp=e.maxhp=e.mhp=9999;
   g.P.x=11*32;g.P.y=36*32+28;e.x=e.hx=g.P.x+130;e.y=e.hy=g.P.y;d.PET.x=g.P.x-10;d.PET.y=g.P.y;d.PET.cd=.1;e.engaged=false;d.startEncounter(e,true);g.B.phase='fight';g.B.noiseT=1e9;g.B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;});g.B.dim=1;});
 for(let i=0;i<40;i++){await sleep(60);if(await E(()=>!!__game.B.shots.find(s=>s.kind==='pet')))break;}
 await sleep(70);await shot('pet-battle.png');await E(()=>{__game.dbg.endFight();});
 // exit rune
 await E(()=>{const g=__game,d=g.dbg;g.state='play';g.tp(31,d.HOUSE_ROOM.y1-1);g.P.grace=99;});await sleep(100);
 await E(()=>{const g=__game,d=g.dbg;d.startWarp(d.HOUSE_IN);});await sleep(1100);
 const ex=await E(async()=>{const g=__game,d=g.dbg;g.P.x=31*32+16;g.P.y=d.HOUSE_ROOM.y1*32+30;await new Promise(r=>setTimeout(r,1200));return {out:d.zoneOfPx(g.P.y)==='ow',near:Math.abs(g.P.x-d.HOUSE_OUT.x)<3};});
 ok(ex.out&&ex.near,'house: the exit rune leads back to the village door');
 // new game wipes pets + trophies
 const ng=await E(()=>{const d=__game.dbg;d.summonPet('wisp');d.awardTrophy('fang');d.resetPets();return d.PET.active===null&&d.trophyCount()===0;});ok(ng,'new game: pets and trophies reset');
 await finish();
})().catch(e=>{console.error(e);process.exit(1);});
