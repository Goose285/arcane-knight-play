// M12: daily challenges, login chest, weekly seeded roguelike crypt, achievements.  node tests/ms12.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,MOBILE,pg}=await boot('ms12');
 const calm=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.UI.mode=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.P.grace=99;g.P.hp=d.maxHp();});
 const tapOpt=async k=>{const p=await E(k=>{const r=__game.dlgRects.opts&&__game.dlgRects.opts[k];if(!r)return null;const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},k);
   if(!p)return false;if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(200);return true;};
await E(()=>{window.__NOACH=true;});   // achievements only unlock when a test calls achTick() itself
 await calm();
 const day=(y,m,d)=>[y,m,d];
 const at=(y,m,d)=>E((y,m,d)=>{__game.dbg.setNow(new Date(y,m,d,12).getTime());},y,m,d);

 // ================= DATA =================
 const dat=await E(()=>{const d=__game.dbg,o={};
   o.login=d.LOGIN_REWARDS.length===7&&d.LOGIN_REWARDS.every(r=>r.n&&(r.g||r.mat||r.card||r.gear))&&!!d.LOGIN_REWARDS[6].gear&&!!d.LOGIN_REWARDS[6].card;
   o.kinds=d.DAILY_KINDS.length>=5&&d.DAILY_KINDS.every(k=>k.k&&k.min<=k.max&&k.gold>0);
   o.ach=d.ACHS.length>=20&&new Set(d.ACHS.map(a=>a.id)).size===d.ACHS.length&&d.ACHS.every(a=>a.n&&a.d&&a.gold>0&&(a.t||a.p));
   o.boons=d.BOONS.length>=6&&new Set(d.BOONS.map(b=>b.id)).size===d.BOONS.length&&d.BOONS.every(b=>b.n&&b.d);
   o.wk=d.WEEKLY_CFG.floors===7&&d.WEEKLY_CFG.boss.length===5;o.metaOn=d.metaOff()===false;return o;});
 for(const [k,v] of Object.entries(dat))ok(v,'data: '+k);

 // ================= CLOCK + SEEDS =================
 await at(2026,10,1);
 const ck=await E(()=>{const g=__game,d=g.dbg,o={};const t=(y,m,dd)=>new Date(y,m,dd,12).getTime();
   const sun=d.weekNum(d.dayNum(t(2026,10,1))),mon=d.weekNum(d.dayNum(t(2026,10,2))),sun2=d.weekNum(d.dayNum(t(2026,10,8)));
   o.week=mon===sun+1&&sun2===mon&&d.weekNum(d.dayNum(t(2026,10,9)))===mon+1;
   o.day=d.dayNum(t(2026,10,2))===d.dayNum(t(2026,10,1))+1&&d.dayNum(new Date(2026,10,2,0,5).getTime())===d.dayNum(new Date(2026,10,2,23,55).getTime());
   const a=d.seededRng(42),b=d.seededRng(42),c=d.seededRng(43);const sa=[a(),a(),a()],sb=[b(),b(),b()],sc=[c(),c(),c()];
   o.rng=JSON.stringify(sa)===JSON.stringify(sb)&&JSON.stringify(sa)!==JSON.stringify(sc)&&sa.every(v=>v>=0&&v<1);
   o.hash=d.hashStr('x')===d.hashStr('x')&&d.hashStr('x')!==d.hashStr('y');return o;});
 for(const [k,v] of Object.entries(ck))ok(v,'clock/seed: '+k);

 // ================= DAILY CHALLENGES =================
 const dr=await E(()=>{const g=__game,d=g.dbg,o={};g.P.lv=1;const base=d.dayNum();
   const a=d.dailyRoll(base),b=d.dailyRoll(base);o.same=JSON.stringify(a)===JSON.stringify(b);o.three=a.length===3&&new Set(a.map(c=>c.k)).size===3;
   o.noLv=a.every(c=>c.k!=='elite'&&c.k!=='arena');
   const sets=new Set();for(let i=0;i<10;i++)sets.add(JSON.stringify(d.dailyRoll(base+i)));o.varied=sets.size>=6;
   o.range=a.every(c=>{const k=d.DAILY_KINDS.find(x=>x.k===c.k);return c.n>=k.min&&c.n<=k.max&&c.p===0&&!c.done;});
   g.P.lv=20;const hi=new Set();for(let i=0;i<40;i++)d.dailyRoll(base+i).forEach(c=>hi.add(c.k));o.hiKinds=hi.has('elite')&&hi.has('arena');g.P.lv=3;
   o.text=a.every(c=>/\d/.test(d.dailyText(c)));return o;});
 for(const [k,v] of Object.entries(dr))ok(v,'daily roll: '+k);
 const ev=await E(()=>{const g=__game,d=g.dbg,o={};d.resetDaily();g.P.gold=0;
   d.DAILY.day=d.dayNum();d.DAILY.ch=[{k:'kills',t:'slime',n:2,p:0,done:false,gold:60},{k:'type',t:'goblin',n:1,p:0,done:false,gold:70},{k:'gold',t:'slime',n:40,p:0,done:false,gold:80}];
   d.dailyEvent('kill',{type:'slime'});o.p1=d.DAILY.ch[0].p===1&&d.DAILY.ch[1].p===0&&!d.DAILY.ch[0].done;
   d.dailyEvent('kill',{type:'goblin'});o.type=d.DAILY.ch[1].done&&d.DAILY.ch[0].done;o.gold1=g.P.gold===130;      // kills 60 + type 70
   d.dailyEvent('gold',25);o.half=d.DAILY.ch[2].p===25&&!d.DAILY.ch[2].done;d.dailyEvent('gold',25);o.cap=d.DAILY.ch[2].p===40&&d.DAILY.ch[2].done;
   o.total=d.DAILY.total===3;o.bonus=d.DAILY.bonus&&g.P.gold>=130+80+200;o.noRepeat=(()=>{const gg=g.P.gold;d.dailyEvent('kill',{type:'slime'});d.dailyEvent('gold',99);return g.P.gold===gg;})();
   o.toast=d.toasts.some(t=>/ALL DAILIES/.test(t.s));return o;});
 for(const [k,v] of Object.entries(ev))ok(v,'daily events: '+k);
 const el=await E(()=>{const g=__game,d=g.dbg,o={};d.resetDaily();d.DAILY.day=d.dayNum();d.DAILY.ch=[{k:'elite',t:'slime',n:1,p:0,done:false,gold:130},{k:'cards',t:'slime',n:2,p:0,done:false,gold:60},{k:'arena',t:'slime',n:1,p:0,done:false,gold:140}];
   d.dailyEvent('kill',{type:'slime',elite:null});o.plain=d.DAILY.ch[0].p===0;d.dailyEvent('kill',{type:'slime',elite:['swift'],rush:true});o.rush=d.DAILY.ch[0].p===0;d.dailyEvent('kill',{type:'slime',elite:['swift']});o.elite=d.DAILY.ch[0].done;
   d.dailyEvent('card');d.dailyEvent('card');o.cards=d.DAILY.ch[1].done;d.dailyEvent('arena');o.arena=d.DAILY.ch[2].done;return o;});
 for(const [k,v] of Object.entries(el))ok(v,'daily events: '+k);
 // rollover to a new day
 const ro=await E(()=>{const g=__game,d=g.dbg,o={};d.resetDaily();g.state='play';d.updateDaily(5);const d0=d.DAILY.day,ch0=JSON.stringify(d.DAILY.ch);o.made=d0===d.dayNum()&&d.DAILY.ch.length===3;
   d.DAILY.ch[0].p=1;d.updateDaily(5);o.same=JSON.stringify(d.DAILY.ch).includes('"p":1')&&d.DAILY.day===d0;
   d.setNow(d.nowMs()+864e5);d.updateDaily(5);o.next=d.DAILY.day===d0+1&&d.DAILY.ch.every(c=>c.p===0)&&d.toasts.some(t=>/New daily/.test(t.s));
   d.setNow(d.nowMs()-864e5);return o;});
 for(const [k,v] of Object.entries(ro))ok(v,'daily rollover: '+k);
 // real hooks: kill + cast inside a real fight
 await calm();
 const rl=await E(async()=>{const g=__game,d=g.dbg,o={};d.resetDaily();d.DAILY.day=d.dayNum();d.DAILY.ch=[{k:'kills',t:'slime',n:1,p:0,done:false,gold:60},{k:'cards',t:'slime',n:1,p:0,done:false,gold:60},{k:'gold',t:'slime',n:5,p:0,done:false,gold:80}];
   g.tp(10,36);const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;g.P.grace=0;g.P.x=e.x-60;g.P.y=e.y+2;e.engaged=false;d.startEncounter(e,true);g.B.phase='fight';g.B.noiseT=1e9;
   g.B.hand[0]=g.B.hand.find(Boolean)||'fireball';
   const h=g.B.hand.findIndex(Boolean);if(h>=0){g.B.sel=h;d.useCard(h);}
   o.card=d.DAILY.ch[1].p>=1||d.DAILY.ch[1].done;
   d.damageEnemy(e,e.hp+9999,'fire');await new Promise(r=>setTimeout(r,500));
   o.kill=d.DAILY.ch[0].done;o.gold=d.DAILY.ch[2].p>0;d.endFight();return o;});
 ok(rl.card,'real hook: casting a card counts');ok(rl.kill,'real hook: a real kill completes the challenge');ok(rl.gold,'real hook: gold from a kill counts');

 // ================= LOGIN CHEST =================
 await at(2026,10,2);
 const ch=await E(()=>{const g=__game,d=g.dbg,o={};d.resetDaily();o.ready=d.chestReady()&&d.chestPreview()===1;g.P.gold=0;
   const r1=d.claimChest();o.d1=r1&&r1.streak===1&&g.P.gold===80;o.closed=!d.chestReady()&&d.claimChest()===null&&g.P.gold===80;o.pause=!d.PAUSE_ITEMS.find(i=>i.k==='KeyV').lab().includes('chest');
   d.setNow(d.nowMs()+864e5);o.again=d.chestReady()&&d.chestPreview()===2;const gel=d.matCount('gel');const r2=d.claimChest();o.d2=r2.streak===2&&d.matCount('gel')===gel+3;
   d.setNow(d.nowMs()+864e5*3);o.reset=d.chestPreview()===1;const r3=d.claimChest();o.d3=r3.streak===1;       // missed days -> back to day 1
   for(let i=0;i<6;i++){d.setNow(d.nowMs()+864e5);d.claimChest();}o.seven=d.DAILY.streak===7;
   return o;});
 for(const [k,v] of Object.entries(ch))ok(v,'login chest: '+k);
 const gr=await E(()=>{const g=__game,d=g.dbg,o={};d.resetDaily();d.DAILY.streak=6;d.DAILY.last=d.dayNum()-1;d.DAILY.chestDay=d.dayNum()-1;
   const inv=d.GEAR.inv.length+Object.values(d.GEAR.eq).filter(Boolean).length,gold=g.P.gold;
   const r=d.claimChest();o.is7=r.streak===7&&/GRAND/.test(r.r.n);o.gold=g.P.gold>=gold+400;o.gear=d.GEAR.inv.length+Object.values(d.GEAR.eq).filter(Boolean).length>inv;o.got=r.got.length>=3;
   d.setNow(d.nowMs()+864e5);const r8=d.claimChest();o.wrap=r8.streak===8&&r8.r.n==='Day 1';o.best=d.ACH.s.streakBest===8;return o;});
 for(const [k,v] of Object.entries(gr))ok(v,'grand chest: '+k);
 ok(await E(()=>{const d=__game.dbg;d.resetDaily();return d.PAUSE_ITEMS.find(i=>i.k==='KeyV').lab().includes('chest');}),'pause menu: DAILY shows (chest!) when one is waiting');

 // ================= SAVE =================
 const sv=await E(()=>{const g=__game,d=g.dbg,o={};d.resetDaily();d.resetAch();d.DAILY.day=d.dayNum();d.DAILY.ch=d.dailyRoll(d.dayNum());d.DAILY.ch[0].p=1;d.DAILY.streak=4;d.DAILY.last=d.dayNum();d.DAILY.chestDay=d.dayNum();d.DAILY.total=9;d.ACH.done.blood=1;d.ACH.s.crafts=5;d.ACH.s.bestFloor=3;
   const j=JSON.parse(JSON.stringify({d:d.packDaily(),a:d.packAch()}));d.resetDaily();d.resetAch();o.wiped=d.DAILY.ch.length===0&&d.DAILY.streak===0&&!d.ACH.done.blood;
   d.unpackDaily(j.d);d.unpackAch(j.a);o.back=d.DAILY.ch.length===3&&d.DAILY.ch[0].p===1&&d.DAILY.streak===4&&d.DAILY.total===9&&d.ACH.done.blood===1&&d.ACH.s.crafts===5&&d.ACH.s.bestFloor===3;
   d.unpackDaily({day:'x',streak:-9,ch:[{k:'nope',n:5},null,{k:'kills',n:-3},{k:'kills',t:'zzz',n:9999,p:-1,done:1,gold:1e9}],total:1e12});
   o.junk=d.DAILY.streak===0&&d.DAILY.ch.length===1&&d.DAILY.ch[0].n===999&&d.DAILY.ch[0].t==='slime'&&d.DAILY.ch[0].p===0&&d.DAILY.ch[0].gold===999&&d.DAILY.total===99999&&d.DAILY.day===-1;
   d.unpackAch({d:{blood:1,zzz:1},s:{crafts:'x',rushBest:7}});o.ajunk=d.ACH.done.blood===1&&!d.ACH.done.zzz&&d.ACH.s.crafts===0&&d.ACH.s.rushBest===7;
   d.unpackDaily(null);d.unpackAch(null);o.nul=d.DAILY.ch.length===0&&Object.keys(d.ACH.done).length===0;
   d.DAILY.streak=3;d.ACH.done.blood=1;d.saveNow();const s=g.readSave();o.file=!!s&&!!s.daily&&s.daily.streak===3&&!!s.ach&&s.ach.d.blood===1;d.resetDaily();d.resetAch();return o;});
 ok(sv.wiped&&sv.back,'save: daily + achievements round-trip');ok(sv.junk&&sv.ajunk&&sv.nul,'save: junk data is sanitised');ok(sv.file,'save: stored in the save file');

 // ================= ACHIEVEMENTS =================
 const ac=await E(()=>{const g=__game,d=g.dbg,o={};d.resetAch();g.P.lv=3;d.toasts.length=0;const gold0=g.P.gold;
   const n0=d.achCount();const first=d.achTick();o.count=d.achCount()-n0===first;
   const ids=Object.keys(d.ACH.done);o.pays=g.P.gold>=gold0;
   d.resetAch();g.P.lv=1;const k0=g.dbg.kills?0:0;
   const prog=d.ACHS.filter(a=>a.p).every(a=>{const [c,m]=d.achProg(a);return c>=0&&c<=m&&m>=1;});o.prog=prog;
   // unlock one on purpose and check the one-time payout + toast
   d.resetAch();g.P.lv=5;g.P.gold=0;d.achTick();o.lv5=!!d.ACH.done.lv5&&g.P.gold>=40;o.toast=d.toasts.some(t=>/ACHIEVEMENT: Squire/.test(t.s));
   const gg=g.P.gold;d.achTick();o.once=g.P.gold===gg;
   d.resetAch();g.P.lv=3;d.ACH.s.crafts=3;d.achTick();o.smith=!!d.ACH.done.smith;
   d.ACH.s.bestFloor=3;d.ACH.s.streakBest=7;d.ACH.s.rushBest=5;d.achTick();o.f3=!!d.ACH.done.crypt3&&!d.ACH.done.crypt7&&!!d.ACH.done.streak&&!!d.ACH.done.arena5&&!!d.ACH.done.arena3;
   d.resetAch();g.P.lv=1;return o;});
 for(const [k,v] of Object.entries(ac))ok(v,'achievements: '+k);
 const ac2=await E(()=>{const g=__game,d=g.dbg,o={};d.resetAch();g.P.lv=1;
   const have=d.GEAR.inv.length;const it=d.genGear('ring',10,'legendary',true);d.addGear(it);d.achTick();o.legend=!!d.ACH.done.legend;
   d.resetDaily();d.DAILY.total=3;d.achTick();o.daily=!!d.ACH.done.daily3;
   d.PET.owned.cinder=true;d.achTick();o.pal=!!d.ACH.done.pal;d.PET.owned={};
   d.GEAR.inv.splice(d.GEAR.inv.indexOf(it),1);d.resetAch();return o;});
 for(const [k,v] of Object.entries(ac2))ok(v,'achievements: '+k);
 // crafting counter is real
 const cf=await E(()=>{const g=__game,d=g.dbg;d.resetAch();const r=d.RECIPES[0];Object.keys(r.mats).forEach(k=>d.addMat(k,r.mats[k]*2));g.P.gold=99999;const a=d.craftGear(r);return !!a&&d.ACH.s.crafts===1;});ok(cf,'achievements: crafting increments the counter');

 // ================= WEEKLY SEED / BOONS =================
 await at(2026,10,2);
 const ws=await E(()=>{const g=__game,d=g.dbg,o={};g.P.lv=10;d.RUSH.on=false;
   const plan=()=>[0,1,2,3,4,5,6].map(f=>d.weeklyPlan(f));const a=plan(),b=plan();o.same=JSON.stringify(a)===JSON.stringify(b);
   o.boss=d.WEEKLY_CFG.boss.includes(a[6].type)&&a.slice(0,6).every(p=>d.WEEKLY_CFG.pool.includes(p.type));
   o.aff=a[0].aff.length===0&&a[2].aff.length===1&&a[4].aff.length===2&&!a.some(p=>p.aff.includes('volatile'));
   o.lv=a[1].lv>a[0].lv&&a[5].lv>a[4].lv&&a[6].lv>=16&&a[6].hpMul===1&&a[3].hpMul>a[0].hpMul;
   const w0=d.weeklyName(),seed0=d.weeklySeed();d.setNow(d.nowMs()+864e5*7);const w1=d.weeklyName(),seed1=d.weeklySeed();const a2=plan();
   o.week=seed0!==seed1&&JSON.stringify(a2.map(p=>p.type))!==JSON.stringify(a.map(p=>p.type));d.setNow(d.nowMs()-864e5*7);
   o.name=/^\w+ \w+$/.test(w0);
   const names=new Set();for(let i=0;i<30;i++){d.setNow(d.nowMs()+864e5*7);names.add(d.weeklyName());}d.setNow(d.nowMs()-864e5*7*30);o.names=names.size>=8;
   d.RUSH.boons=[];const c1=d.boonChoices(0),c2=d.boonChoices(0);o.boons=c1.length===3&&new Set(c1.map(x=>x.id)).size===3&&JSON.stringify(c1)===JSON.stringify(c2);
   d.RUSH.boons=c1.map(x=>x.id);const c3=d.boonChoices(1);o.noRepeat=c3.every(x=>!c1.map(y=>y.id).includes(x.id));d.RUSH.boons=[];return o;});
 for(const [k,v] of Object.entries(ws))ok(v,'weekly: '+k);
 const bn=await E(()=>{const g=__game,d=g.dbg,o={};g.P.lv=10;const hp0=d.maxHp();
   o.off=d.boonDmg()===1&&d.boonDef()===1&&d.maxHp()===hp0;       // boons do nothing outside a weekly run
   d.RUSH.on=true;d.RUSH.mode='weekly';d.RUSH.boons=[];o.empty=d.boonDmg()===1;
   g.P.hp=10;d.boonTake('vigor');o.vigor=d.maxHp()===hp0+25&&g.P.hp===35;
   d.boonTake('fury');o.fury=Math.abs(d.boonDmg()-1.18)<1e-9;d.boonTake('ward');o.ward=Math.abs(d.boonDef()-.85)<1e-9;d.boonTake('fortune');o.score=Math.abs(d.boonScore()-1.25)<1e-9;
   o.dup=d.boonTake('fury')===false&&d.RUSH.boons.length===4;
   d.boonTake('rage');o.rage=Math.abs(d.boonDmg()-1.48)<1e-9&&d.maxHp()===hp0+25+Math.round((80+15*9)*-.1);
   d.boonTake('bulwark');o.floor=d.boonDef()>=.4;
   d.RUSH.mode='rush';o.mode=d.boonDmg()===1&&d.boonDef()===1;       // a normal boss rush ignores boons
   d.RUSH.on=false;d.RUSH.mode='rush';d.RUSH.boons=[];return o;});
 for(const [k,v] of Object.entries(bn))ok(v,'boons: '+k);
 // boons really change damage dealt/taken in combat
 const bd=await E(async()=>{const g=__game,d=g.dbg,o={};g.tp(10,36);g.P.grace=0;g.P.lv=10;
   const run=async(boons)=>{d.endFight();g.state='play';d.RUSH.on=!!boons;d.RUSH.mode='weekly';d.RUSH.boons=boons||[];const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;d.applyLevel(e,3);e.hp=e.maxhp=e.mhp=99999;e.engaged=false;
     g.P.x=e.x-60;g.P.y=e.y+2;g.P.hp=d.maxHp();d.startEncounter(e,true);g.B.phase='fight';g.B.noiseT=1e9;g.B.inv=0;g.B.ens.forEach(q=>{q.joinT=0;q.atkCd=1e9;});
     let best=1e9,worst=0;for(let i=0;i<5;i++){e.hp=99999;d.damageEnemy(e,100,'arcane');const dealt=99999-e.hp;best=Math.min(best,dealt);worst=Math.max(worst,dealt);}
     const h0=g.P.hp;g.B.inv=0;d.damagePlayer(40,e);const took=h0-g.P.hp;d.endFight();d.RUSH.on=false;return {min:best,took};};
   const base=await run(null),buff=await run(['fury','ward']);d.RUSH.boons=[];return {base,buff};});
 ok(bd.buff.min>bd.base.min*1.1,'boons: Fury raises damage dealt ('+bd.base.min+' -> '+bd.buff.min+')');
 ok(bd.buff.took<bd.base.took,'boons: Iron Ward lowers damage taken ('+bd.base.took+' -> '+bd.buff.took+')');

 // ================= WEEKLY RUN (real fights) =================
 await calm();
 await E(()=>{const g=__game,d=g.dbg;d.resetAch();d.wkEnsure();d.WK.lb=[];d.WK.claimed=false;d.WK.best=0;g.P.lv=14;g.P.hp=d.maxHp();g.tp(12,37);d.UI.mode=null;g.state='play';});
 const wr=await E(()=>{const d=__game.dbg;return {ok:d.rushStart('weekly'),mode:d.RUSH.mode,on:d.RUSH.on};});
 ok(wr.ok&&wr.mode==='weekly'&&wr.on,'weekly run: starts in weekly mode');await sleep(1300);
 ok(await E(()=>__game.dbg.zoneOfPx(__game.P.y)==='arena'),'weekly run: enters the arena');
 await E(()=>{__game.dbg.RUSH.wait=.2;});await sleep(900);
 const f1=await E(()=>{const g=__game,d=g.dbg,c=d.RUSH.cur,pl=d.weeklyPlan(0);return {type:c&&c.type,lv:c&&c.lv,pl,mhp:c&&c.mhp,fight:!!g.B,rush:c&&c.rush};});
 ok(f1.type===f1.pl.type&&f1.lv===f1.pl.lv&&f1.rush,'weekly run: floor 1 matches the seeded plan ('+f1.type+' Lv '+f1.lv+')');ok(f1.fight,'weekly run: floor 1 fight begins');
 const hpBase=await E(()=>{const d=__game.dbg,c=d.RUSH.cur,e=d.mkEnemyObj(c.type,0,0);d.applyLevel(e,c.lv);return e.mhp;});ok(f1.mhp>hpBase*1.5,'weekly run: floor monsters are beefed up ('+hpBase+' -> '+f1.mhp+')');
 await sleep(800);await E(()=>{__game.dbg.toasts.length=0;});await sleep(100);await shot('weekly-crypt-floor.png');
 // clear floor 1 -> boon choice
 await E(async()=>{const g=__game,d=g.dbg,c=d.RUSH.cur;g.B.phase='fight';g.B.ens.forEach(o=>{o.joinT=0;});d.damageEnemy(c,c.hp+99999,'fire');});
 const bo=await E(async()=>{const g=__game,d=g.dbg;for(let i=0;i<80&&!(g.DLG&&g.DLG.cut==='boon');i++)await new Promise(r=>setTimeout(r,100));
   return {dlg:!!g.DLG&&g.DLG.cut==='boon',n:g.DLG&&g.DLG.steps[0].ch.length,round:d.RUSH.round,score:d.RUSH.score,ids:d.boonChoices(0).map(b=>b.id)};});
 ok(bo.dlg&&bo.n===3,'weekly run: clearing a floor offers 3 boons');ok(bo.round===1&&bo.score>0,'weekly run: floor scored ('+bo.score+')');
 await E(async()=>{const g=__game;for(let i=0;i<20&&g.DLG&&!(g.DLG.steps[g.DLG.i].ch&&g.DLG.c>=g.DLG.steps[g.DLG.i].t.length);i++){g.press('Enter');await new Promise(r=>setTimeout(r,60));}});
 await sleep(250);await shot('weekly-boon-choice.png');
 const wantB=await E(()=>__game.dbg.boonChoices(0)[1].id);const pickIdx=1;ok(await tapOpt(pickIdx),'weekly run: boon button can be tapped');
 const bt=await E(()=>{const g=__game,d=g.dbg;return {boons:d.RUSH.boons.slice(),want:null,dlg:!!g.DLG,log:g.dbg.STORY.choices.length};});
 ok(bt.boons.length===1&&bt.boons[0]===wantB,'weekly run: the chosen boon is applied');ok(!bt.dlg&&bt.log===0,'weekly run: the scene closes and leaves the story log alone');
 // floor 2 spawns with the next seeded plan, and the wait pauses while the choice was open
 await E(()=>{__game.dbg.RUSH.wait=.2;});await sleep(900);
 const f2=await E(()=>{const d=__game.dbg,c=d.RUSH.cur,pl=d.weeklyPlan(1);return {ok:c&&c.type===pl.type&&c.lv===pl.lv};});ok(f2.ok,'weekly run: floor 2 follows the seeded plan');
 // fast-forward to the final floor and win
 await E(()=>{const g=__game,d=g.dbg;d.endFight();const c=d.RUSH.cur;if(c){const i=g.enemies.indexOf(c);if(i>=0)g.enemies.splice(i,1);}d.RUSH.cur=null;d.RUSH.round=d.WEEKLY_CFG.floors-1;d.RUSH.boons=['fury'];d.RUSH.wait=.1;g.state='play';g.P.hp=d.maxHp();g.P.grace=0;});await sleep(900);
 const f7=await E(()=>{const g=__game,d=g.dbg,c=d.RUSH.cur,pl=d.weeklyPlan(6);return {ok:c&&c.type===pl.type&&c.def.boss,fight:!!g.B,pl};});ok(f7.ok&&f7.fight,'weekly run: floor 7 is the seeded boss ('+f7.pl.type+')');
 const g0=await E(()=>({gold:__game.P.gold,cards:Object.values(__game.dbg.COL()).reduce((a,b)=>a+b,0),mat:__game.dbg.matCount('shard')}));
 await E(async()=>{const g=__game,d=g.dbg,c=d.RUSH.cur;g.B.phase='fight';g.B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;});d.damageEnemy(c,c.hp+999999,'fire');});
 const win=await E(async()=>{const g=__game,d=g.dbg;for(let i=0;i<90&&d.RUSH.on;i++)await new Promise(r=>setTimeout(r,100));
   for(let i=0;i<60&&!g.DLG;i++)await new Promise(r=>setTimeout(r,100));
   await new Promise(r=>setTimeout(r,1500));
   return {on:d.RUSH.on,ow:d.zoneOfPx(g.P.y)==='ow',res:d.RUSH.result,claimed:d.WK.claimed,lb:d.WK.lb.length,top:d.WK.lb[0],dlg:g.DLG&&g.DLG.lines.join(' '),best:d.ACH.s.bestFloor,wins:d.ACH.s.weeklyWins,rushLb:d.getRushLB().length};});
 ok(!win.on&&win.ow,'weekly run: the run ends and you return to the village '+JSON.stringify({on:win.on,ow:win.ow}));ok(win.res&&win.res.won&&win.res.floors===7&&win.res.mode==='weekly','weekly run: recorded as a full clear');
 ok(win.claimed&&win.wins===1&&win.res.reward&&win.res.reward.length>=3,'weekly run: the weekly chest is claimed ('+(win.res.reward||[]).join(', ')+')');
 ok(win.lb===1&&win.top.floors===7&&win.top.score>0,'weekly run: score posted to the weekly board');ok(win.rushLb===0,'weekly run: the boss-rush board is untouched');
 ok(/conquered/.test(win.dlg||'')&&/Weekly chest/.test(win.dlg||''),'weekly run: the Arena Master reports the chest');ok(win.best===7,'weekly run: best floor tracked');
 await E(()=>{const g=__game;g.DLG=null;g.dbg.achTick();});
 ok(await E(()=>!!__game.dbg.ACH.done.crypt7&&!!__game.dbg.ACH.done.crypt3),'achievements: Crypt Wanderer + Crypt Delver unlock from the run');
 // second clear in the same week pays no second chest
 const second=await E(()=>{const d=__game.dbg,g=__game,r={score:900,rounds:7,time:300,lv:14,date:1,why:'won',rank:0};Object.assign(d.RUSH,{on:true,mode:'weekly',round:7,boons:[]});const gold=g.P.gold;const x=d.weeklyFinish(r,'won');d.RUSH.on=false;d.RUSH.mode='rush';return {reward:x.reward,gold:g.P.gold-gold,lb:d.WK.lb.length};});
 ok(second.reward===null&&second.gold===0&&second.lb===2,'weekly run: the chest pays once per week');
 // new week = clean board, chest available again
 const nw=await E(()=>{const d=__game.dbg;d.setNow(d.nowMs()+864e5*7);d.wkEnsure();const o={clean:d.WK.lb.length===0&&!d.WK.claimed&&d.WK.best===0};d.setNow(d.nowMs()-864e5*7);d.wkEnsure();o.back=d.WK.lb.length===0||d.WK.lb.length>=0;return o;});
 ok(nw.clean,'weekly: a new week starts with an empty board and an unclaimed chest');
 // losing a weekly run
 await calm();
 await E(()=>{const g=__game,d=g.dbg;d.wkEnsure();d.WK.lb=[];d.WK.claimed=false;g.P.hp=d.maxHp();g.tp(12,37);d.rushStart('weekly');});await sleep(1300);await E(()=>{__game.dbg.RUSH.wait=.2;});await sleep(900);
 const ls=await E(async()=>{const g=__game,d=g.dbg;g.B.phase='fight';g.B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;});g.P.hp=1;g.B.inv=0;d.damagePlayer(80,d.RUSH.cur);
   for(let i=0;i<80&&d.RUSH.on;i++)await new Promise(r=>setTimeout(r,100));for(let i=0;i<40&&!g.DLG;i++)await new Promise(r=>setTimeout(r,100));
   return {on:d.RUSH.on,res:d.RUSH.result,lb:d.WK.lb.length,claimed:d.WK.claimed,dlg:g.DLG&&g.DLG.lines.join(' ')};});
 ok(!ls.on&&ls.res&&!ls.res.won&&ls.res.mode==='weekly','weekly run: dying ends the run');ok(ls.lb===0&&!ls.claimed,'weekly run: no board entry for zero floors, no chest');ok(/never cleared/.test(ls.dlg||''),'weekly run: the Arena Master comments');
 await E(()=>{const g=__game;g.DLG=null;g.state='play';});

 // ================= SCREENS =================
 await calm();
 await E(()=>{const g=__game,d=g.dbg;d.resetDaily();d.resetAch();d.WK.lb=[{score:4210,rounds:5,floors:5,time:200,lv:14,date:1,won:false},{score:5890,rounds:7,floors:7,time:320,lv:15,date:1,won:true}];d.WK.lb.sort((a,b)=>b.score-a.score);d.WK.best=7;d.WK.claimed=true;
   g.P.lv=12;d.DAILY.day=d.dayNum();d.DAILY.ch=[{k:'kills',t:'slime',n:12,p:12,done:true,gold:60},{k:'type',t:'goblin',n:5,p:2,done:false,gold:70},{k:'cards',t:'slime',n:24,p:9,done:false,gold:60}];d.DAILY.streak=3;d.DAILY.last=d.dayNum()-1;d.DAILY.chestDay=d.dayNum()-1;
   g.state='paused';d.PAUSE_ITEMS.find(i=>i.k==='KeyV').act();});await sleep(300);
 ok(await E(()=>__game.state==='daily'),'daily screen: opens from the pause menu');
 ok(await E(()=>__game.dbg.uiRows().length)>=10,'daily screen: chest, challenges, weekly crypt and board rows');
 await sleep(150);await shot('daily-hub.png');
 await E(()=>{__game.dbg.UI.scroll=210;});await sleep(250);await shot('daily-weekly.png');
 await E(()=>{__game.dbg.UI.scroll=0;});await sleep(200);
 const g1=await E(()=>__game.P.gold);ok(await tap('daily:chest',0),'daily screen: OPEN button on screen');await sleep(300);
 ok(await E(g=>__game.P.gold>g||__game.dbg.matCount('gel')>0||__game.dbg.matCount('bone')>0,g1)&&await E(()=>!__game.dbg.chestReady()&&__game.dbg.DAILY.streak===4),'daily screen: tapping OPEN claims the chest and bumps the streak to 4');
 ok(await E(()=>__game.dbg.PAUSE_ITEMS.find(i=>i.k==='KeyV').lab()==='DAILY'),'pause menu: the (chest!) tag disappears');
 await E(()=>{__game.dbg.closeUI();__game.state='play';});
 // weekly button launches a run from the hub
 await calm();await E(()=>{const g=__game,d=g.dbg;g.tp(12,37);d.openDaily();});await sleep(300);
 ok(await tap('daily:weekly',null),'daily screen: DESCEND button on screen');await sleep(1400);
 ok(await E(()=>__game.dbg.RUSH.on&&__game.dbg.RUSH.mode==='weekly'),'daily screen: DESCEND starts the weekly crypt');
 await E(()=>{const g=__game,d=g.dbg;d.rushFinish('quit');g.DLG=null;g.state='play';});await sleep(1300);
 // rush screen shows the weekly row
 await E(()=>{const g=__game,d=g.dbg;g.DLG=null;g.state='play';d.openUIMode('rush','play');});await sleep(250);
 ok(await E(()=>__game.dbg.uiRows().length)>=5,'arena screen: weekly crypt row added');
 ok(await tap('daily:weekly',null),'arena screen: DESCEND button on screen');await sleep(1300);
 ok(await E(()=>__game.dbg.RUSH.on&&__game.dbg.RUSH.mode==='weekly'),'arena screen: DESCEND starts the weekly crypt');
 await E(()=>{const g=__game,d=g.dbg;d.rushFinish('quit');g.DLG=null;g.state='play';});await sleep(1300);
 // achievements screen
 await calm();
 await E(()=>{const g=__game,d=g.dbg;d.resetAch();g.P.lv=12;d.ACH.done.blood=1;d.ACH.done.lv5=1;d.ACH.done.lv10=1;d.ACH.s.crafts=1;d.ACH.s.rushBest=2;g.state='paused';d.PAUSE_ITEMS.find(i=>i.k==='KeyH').act();});await sleep(300);
 ok(await E(()=>__game.state==='ach'),'achievements screen: opens from the pause menu');
 ok(await E(()=>__game.dbg.uiRows().length===__game.dbg.ACHS.length),'achievements screen: one row per achievement');
 await sleep(150);await shot('achievements.png');
 await E(()=>{__game.dbg.closeUI();__game.state='play';});
 // notice board
 await calm();
 const nb=await E(async()=>{const g=__game,d=g.dbg,o={};const n=g.npcs.find(x=>x.board);o.npc=!!n&&d.reach[Math.floor(n.y/32)][Math.floor(n.x/32)];g.tp(Math.floor(n.x/32),Math.floor(n.y/32)+1);g.P.x=n.x;g.P.y=n.y+22;g.P.dir='u';
   for(let i=0;i<6&&g.state==='play';i++){g.press('KeyE');await new Promise(r=>setTimeout(r,250));}o.open=g.state==='daily';d.closeUI();g.state='play';return o;});
 ok(nb.npc,'notice board: reachable in Oakvale');ok(nb.open,'notice board: talking opens the daily hub');
 // new game wipes it; a legacy page (meta off) never fires
 const ng=await E(()=>{const d=__game.dbg;d.DAILY.streak=5;d.ACH.done.blood=1;d.resetDaily();d.resetAch();return d.DAILY.streak===0&&!d.ACH.done.blood;});ok(ng,'new game: daily + achievements reset');
 const mo=await E(()=>{const g=__game,d=g.dbg;window.__NOMETA=true;d.resetDaily();d.DAILY.ch=[{k:'kills',t:'slime',n:1,p:0,done:false,gold:60}];const gold=g.P.gold;d.dailyEvent('kill',{type:'slime'});d.resetAch();g.P.lv=9;d.updateDaily(9);const r=d.DAILY.ch[0].p===0&&g.P.gold===gold;window.__NOMETA=false;d.resetDaily();return r;});
 ok(mo,'meta switch: daily rewards and achievements stay off when __NOMETA is set');
 await finish();
})().catch(e=>{console.error(e);process.exit(1);});
