// M62 (t143u/t144u): viewport poll + bigger cards, cozy HUD/panels, Lich rework, story choice effects, equipment compare screen,
// enclosed dungeons + entrances, no armor tint, 30-fish quest, smithy, drifting fog, south gate gap, chapel sign, pet distance, quest
// crumbs, water textures.   node tests/ms62.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms62',{town:true,grow:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t143/.test(tags),'backup tag backup-pre-t143');
 await E(()=>{window.__NOESC=0;__game.dbg.startFromTitle();});await sleep(700);
 // 2. viewport: a short innerHeight that recovers without a resize event is picked up by the poll
 let s=await E(async()=>{const h0=VH;const d=Object.getOwnPropertyDescriptor(window,'innerHeight');Object.defineProperty(window,'innerHeight',{configurable:true,get:()=>Math.round(d.get.call(window)*.8)});resize();const hs=VH;
   if(d)Object.defineProperty(window,'innerHeight',d);else delete window.innerHeight;await new Promise(r=>setTimeout(r,1300));return {h0,hs,h1:VH,poll:typeof viewPoll};});
 ok(s.poll==='function'&&s.h1===s.h0&&s.hs<=s.h0,'viewport re-checks itself and recovers the full height ('+s.hs+' -> '+s.h1+')');
 s=await E(()=>{const g=fanGeom(4);return {cw:g.cw,ch:g.ch};});ok(s.ch>=(MOB?62:52),'touch cards are bigger ('+Math.round(s.cw)+'x'+Math.round(s.ch)+')');
 s=await E(()=>String(panel).includes('brass')||String(panel).includes('rim')||String(panel).includes('panelSkin')||typeof panelSkin==='function'||(typeof PANEL_SKIN!=='undefined'));ok(s,'HUD panels use the leather + brass frame');
 // 3. lich
 s=await E(()=>{const e=enemies.find(e=>e.type==='lich');return {hp:e.maxhp,lv:e.lv,book:BOSS_BOOK.lich.map(b=>b[0])};});
 ok(s.hp<=3600,'Lich King HP reduced ('+s.hp+' at Lv'+s.lv+')');ok(['grasp','wraiths','chains','storm'].every(k=>s.book.includes(k)),'Lich has new phase moves '+s.book.join(','));
 s=await E(()=>{const e=enemies.find(e=>e.type==='lich');const mv=BOSS_MOVES.lich(e,ecen(e),{x:e.x+50,y:e.y},0);return ['grasp','wraiths','chains','storm'].map(k=>typeof mv[k]);});ok(s.every(t=>t==='function'),'new lich moves exist');
 // 4. story choices
 s=await E(()=>{delete STORY.flags.greed;const g0=P.gold;storyApply({flag:'greed'});return P.gold-g0;});ok(s===150,'a story choice now has a visible effect (+'+s+' G)');
 // 5. equipment
 s=await E(()=>{const it=genGear('weapon',5,'rare',false);addGear(it);GEARV.tab='bag';openGear();const rows=UI_MODES.gear.rows();const dl=gearDeltas(it,GEAR.eq.weapon);
   GEARV.tab='worn';GEARV.cmp='weapon';const rows2=UI_MODES.gear.rows();closeUI();return {n:rows.length,dl:dl.length,worn:rows2.length,slots:GEAR_SLOTS.join(',')};});
 ok(s.dl>0&&s.n>3&&s.worn>=5&&s.slots==='weapon,armor,ring','equipment: deltas, backpack + equipped pages with compare ('+s.slots+')');
 // 6. dungeons
 s=await E(()=>{P.x=31*TS;P.y=55*TS;const a=tileSprite(map[48][10],10,48,0),b=tileSprite(map[60][70]||0,70,60,0),c=tileSprite(map[60][10],10,60,0);P.x=SPAWN.x;P.y=SPAWN.y;
   const dk=sp=>{const d=sp.getContext('2d').getImageData(0,0,16,16).data;let m=0;for(let i=0;i<d.length;i+=4)m=Math.max(m,d[i]+d[i+1]+d[i+2]);return m;};return {gap:dk(a),side:dk(b),inside:dk(c)};});
 ok(s.gap<120&&s.side<120&&s.inside>120,'inside the crypt the outside is dark ('+s.gap+'/'+s.side+' vs '+s.inside+')');
 s=await E(()=>{const n=ENTR.index().size;return n;});ok(s>=5*3+3*6,'entrance facades for crypt + 3 gates ('+s+' tiles)');
 // 7. tint
 s=await E(()=>String(drawGearOnPlayer).includes('tintOf(spr'));ok(!s,'armor no longer tints the whole hero');
 // 8. fish
 s=await E(()=>QUEST_BY_ID.fish2.obj.n);ok(s===30,'second fish quest asks for 30');
 // 9. smithy
 s=await E(()=>{const b=SMITHY.find();let a=0,f=0;for(const r of map)for(const t of r){if(t===T.ANV)a++;if(t===T.FRN)f++;}return {b:!!b,a,f};});ok(s.b&&s.a>=1&&s.f>=1,'smithy with anvil + furnace');
 // 10. fog
 s=await E(()=>{FOG.a=.6;drawFog();FOG.a=0;return fogSprites().length;});ok(s===4,'drifting fog wisps');
 // 11. south gate
 s=await E(()=>{const ty=Math.floor(TOWN.y1/TS);let gx=-1;for(let x=0;x<40;x++)if(map[ty-1][x]===T.P&&(map[ty-1][x-1]===T.B||map[ty-1][x-1]===T.BT)){gx=x;break;}return SW.southTile(gx,ty-1)===null;});ok(s,'south gate walkway removed');
 // 12. chapel sign
 s=await E(async()=>{await new Promise(r=>setTimeout(r,3300));const n=NPCS.find(q=>q.name==='Chapel Sign');return Math.abs(Math.floor(n.x/TS)-CHAPEL.door);});ok(s>=2,'chapel sign moved off the door ('+s+' tiles)');
 // 13. pet
 s=await E(()=>PET_CFG.follow);ok(s>=24,'pet trails farther');
 // 14 + 15
 s=await E(()=>typeof drawQuestCrumbs==='function'&&typeof WTEX==='object'&&WTEX.frame('bog',0,0)!==WTEX.frame('ow',0,0));ok(s,'quest breadcrumbs + textured water / bog water');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');ok(/arcane-knight-v(5[1-9]|[6-9][0-9])/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v51+');
 await sleep(1500);ok(!errs.length,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
