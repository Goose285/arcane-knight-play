// M34: goblin camp (no goblins in the castle), Goblin Iron pity + arrow, quest-item pickup radius, World Map always opens, Teleport Home,
// clean respawn / dusk-dawn AI state and aggro.  node tests/ms34.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms34',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.lv=4;g.P.hp=d.maxHp();});
 // ---- 1. goblins live in their own camp, not in the castle with the dragon
 const gb=await E(()=>{const g=__game,d=g.dbg,c=d.GOBLIN_CAMPV,all=g.enemies.filter(e=>e.type==='goblin'&&!e.night);
   return {n:all.length,castle:all.filter(e=>d.regions.castle(Math.floor(e.hx/32),Math.floor(e.hy/32))).length,camp:all.filter(e=>Math.hypot(e.hx/32-c.tx,e.hy/32-c.ty)<=6.5).length,forest:d.regions.forest(c.tx,c.ty),dragon:g.enemies.filter(e=>e.def.boss&&e.type==='dragon').length,castleKn:g.enemies.filter(e=>e.type==='knight'&&d.regions.castle(Math.floor(e.hx/32),Math.floor(e.hy/32))).length};});
 ok(gb.castle===0&&gb.camp>=4&&gb.forest&&gb.dragon===1,'quest goblins camp in Whisperwood, none in the castle with the dragon '+JSON.stringify(gb));
 // ---- 2. Goblin Iron: guaranteed after two misses, arrow targets real goblins (or their camp)
 const ir=await E(()=>{const g=__game,d=g.dbg,sv=Math.random;d.QS.st.iron='active';d.QS.items.iron=0;d.QS.miss={};Math.random=()=>.99;
   const r=[];for(let i=0;i<3;i++){d.questLoot({type:'goblin'});r.push(d.QS.items.iron|0);}Math.random=sv;return r;});
 ok(JSON.stringify(ir)==='[0,0,1]','Goblin Iron is guaranteed after two misses in a row ('+ir+')');
 const ar=await E(()=>{const g=__game,d=g.dbg;d.QS.items.iron=0;d.QS.ord=['iron'];d.TRK.id='q:iron';const en=d.trkEntries().find(e=>e.id==='q:iron');g.tp(30,20);
   const gs=g.enemies.filter(e=>e.type==='goblin'&&!e.night),alive=gs.map(e=>e.alive);
   const t1=d.trkTarget(en,true),near=gs.some(e=>e.alive&&Math.hypot(e.x-t1.x,e.y-t1.y)<2);
   gs.forEach(e=>e.alive=false);const t2=d.trkTarget(en,true),c=d.GOBLIN_CAMPV;
   gs.forEach((e,i)=>e.alive=alive[i]);return {near,camp:Math.hypot(t2.x-(c.tx+.5)*32,t2.y-(c.ty+.5)*32)<2};});
 ok(ar.near&&ar.camp,'the arrow points at a living goblin, or at their camp while they respawn '+JSON.stringify(ar));
 await E(()=>{__game.dbg.QS.st.iron='none';});
 // ---- 3. quest items lying in the world: auto-pickup within a small radius
 const pk=await E(()=>{const g=__game,d=g.dbg,w=d.QWORLD[0];d.QS.st.ring='active';d.QS.items.ring=0;g.tp(w.tx,w.ty);g.P.x=w.tx*32+16+34;g.P.y=w.ty*32+16+8;return true;});
 await sleep(500);
 ok(await E(()=>__game.dbg.QS.items.ring===1),'a quest item within ~1 tile is picked up automatically (no button)');
 await E(()=>{const d=__game.dbg;d.QS.st.ring='none';d.QS.items.ring=0;});
 // ---- 4. World Map: always opens from the pause menu (in a fight too: view only), in every area
 for(const [name,tx,ty] of [['meadow',12,20],['snow',16,'snow'],['crypt',31,72],['arena',31,'arena']]){
  await E((tx,ty)=>{const g=__game,d=g.dbg;d.endFight();g.WARP=null;g.state='play';g.DLG=null;g.P.grace=99;const y=typeof ty==='string'?(ty==='snow'?d.ZONE_Y0.snow+24:d.ARENA_Y0+6):ty;g.tp(tx,y);g.state='paused';d.pauseOpenPage('main');},tx,ty);await sleep(250);
  const r=await E(()=>{const d=__game.dbg;d.pauseTapLeaf?0:0;d.PAUSE_ITEMS.find(i=>i.k==='KeyF').act();return {st:__game.state,mode:d.UI.mode};});await sleep(350);
  ok(r.mode==='travel'&&r.st==='travel','pause > WORLD MAP opens in '+name+' ('+JSON.stringify(r)+')');
  await E(()=>{__game.dbg.closeUI();});
 }
 await E(()=>{const g=__game,d=g.dbg;g.state='play';g.tp(12,22);g.P.grace=0;const e=g.enemies.find(o=>o.type==='slime'&&o.alive&&!o.night);e.x=e.hx=14*32;e.y=e.hy=22*32+28;g.P.y=22*32+28;d.startEncounter(e,true);g.state='paused';d.pauseOpenPage('main');});await sleep(250);
 const fm=await E(()=>{const d=__game.dbg;d.PAUSE_ITEMS.find(i=>i.k==='KeyF').act();return {mode:d.UI.mode,can:d.canTravel(),b:!!__game.B};});await sleep(300);
 ok(fm.mode==='travel'&&!fm.can&&fm.b,'World Map opens during a fight too (view only) '+JSON.stringify(fm));
 const tr=await E(()=>{const d=__game.dbg;return {fast:d.fastTravel('village')};});ok(!tr.fast,'...but you cannot fast travel during a fight');
 await E(()=>{const g=__game,d=g.dbg;d.closeUI();g.state='play';d.endFight();});
 // ---- 5. Teleport Home
 ok(await E(()=>__game.dbg.PAUSE_ITEMS.some(i=>/TELEPORT HOME/.test(i.lab()))&&__game.dbg.pauseEntries('main').some(e=>e.id==='home')),'pause menu has a TELEPORT HOME entry');
 await E(()=>{const g=__game,d=g.dbg;g.state='play';d.endFight();g.DLG=null;g.WARP=null;g.P.grace=99;d.setTimeOfDay(.5);g.tp(30,20);d.HOME.cd=0;d.HOME.cast=0;g.state='paused';});
 ok(await E(()=>{const d=__game.dbg;d.PAUSE_ITEMS.find(i=>i.k==='KeyH2').act();return d.HOME.cast>0;}),'choosing it starts a short cast');
 await sleep(1000);await E(()=>{const g=__game;g.P.x+=60;});await sleep(300);
 ok(await E(()=>__game.dbg.HOME.cast===0&&__game.dbg.HOME.cd===0),'walking away cancels the cast (no cooldown)');
 await E(()=>{const d=__game.dbg;d.startHome();});await sleep(500);await E(()=>{__game.P.hp-=3;});await sleep(300);
 ok(await E(()=>__game.dbg.HOME.cast===0),'taking damage interrupts it');
 await E(()=>{const g=__game,d=g.dbg;g.tp(30,20);d.startHome();});
 await sleep(3200);
 const th=await E(()=>{const g=__game,d=g.dbg;return {x:g.P.x/32,y:g.P.y/32,cd:Math.round(d.HOME.cd),warp:!!d.WARPV};});
 ok(th.x>10&&th.x<14&&th.y>34&&th.y<37&&th.cd>=20,'after the cast you arrive at the Oakvale waystone, then a cooldown starts ('+JSON.stringify(th)+')');
 await sleep(1200);
 ok(await E(()=>{const d=__game.dbg;d.startHome();return d.HOME.cast===0;}),'it cannot be cast again during the cooldown');
 await E(()=>{const g=__game,d=g.dbg;d.HOME.cd=0;g.tp(12,22);g.P.grace=0;const e=g.enemies.find(o=>o.type==='slime'&&o.alive&&!o.night);e.x=e.hx=14*32;e.y=e.hy=22*32+28;g.P.y=22*32+28;d.startEncounter(e,true);});await sleep(300);
 ok(await E(()=>{const d=__game.dbg;d.startHome();return d.HOME.cast===0;}),'disabled in combat');
 await E(()=>{__game.dbg.endFight();});
 // ---- 6. respawned and dusk/dawn monsters are clean and still engage you
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);g.P.lv=4;g.P.hp=d.maxHp();
   g.enemies.forEach(e=>{if(!e.def.boss){e.x=e.hx;e.y=e.hy;}});
   const e=g.enemies.find(o=>o.type==='slime'&&!o.night&&o.alive&&d.regions.forest(Math.floor(o.hx/32),Math.floor(o.hy/32))===false&&o.hy/32<26);window.__r=e;
   g.P.grace=99;e.alive=false;e.respawn=.3;e.mode='chase';e.mt=99;e.calm=50;e.alert=5;e.flash=.1;e.hp=0;});
 await sleep(900);
 const rs=await E(()=>{const e=window.__r;return {alive:e.alive,mode:e.mode,calm:e.calm,hp:e.hp,mhp:e.mhp,flash:e.flash,alert:e.alert,eng:e.engaged};});
 ok(rs.alive&&rs.mode==='look'&&rs.calm===0&&rs.hp===rs.mhp&&rs.flash===0&&!rs.eng,'a respawned monster is fully reset (full HP, calm AI, no stale state) '+JSON.stringify(rs));
 const eng=async(lv)=>{await E(lv=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.P.lv=lv;g.P.grace=0;g.enemies.forEach(o=>{if(o!==window.__r){o.calm=99;}});const e=window.__r;e.calm=0;e.mode='look';e.mt=9;e.fa=Math.PI;e.x=e.hx;e.y=e.hy;g.P.x=e.x-48;g.P.y=e.y;g.cam.x=g.P.x-200;},lv);
   for(let i=0;i<14;i++){await sleep(250);if(await E(()=>!!__game.B))return true;}return false;};
 ok(await eng(4),'a respawned monster of your level notices and engages you');
 await E(()=>{__game.dbg.endFight();});
 ok(!(await eng(38)),'by design, monsters 5+ levels below you ignore you (Lv38 hero vs Lv'+(await E(()=>window.__r.lv))+' monster) unless you attack');
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.P.lv=4;g.enemies.forEach(o=>{o.calm=0;});d.setTimeOfDay(.0);d.syncNight(true);});await sleep(600);
 const nw=await E(()=>{const g=__game,d=g.dbg,e=g.enemies.find(o=>o.night&&o.alive&&o.type==='wraith');return e?{mode:e.mode,calm:e.calm,hp:e.hp,mhp:e.mhp,lv:e.lv}:null;});
 ok(nw&&nw.calm===0&&nw.hp===nw.mhp,'night monsters appear clean at dusk '+JSON.stringify(nw));
 await E(()=>{const g=__game,d=g.dbg;g.enemies.forEach(o=>{if(!(o.night&&o.alive&&o.type==='wraith'))o.calm=99;});const e=g.enemies.find(o=>o.night&&o.alive&&o.type==='wraith');window.__w=e;e.mode='look';e.mt=9;e.fa=Math.PI;e.x=e.hx;e.y=e.hy;g.P.lv=Math.max(4,e.lv);g.P.grace=0;g.P.x=e.x-40;g.P.y=e.y;g.P.hp=d.maxHp();});
 let nb=false;for(let i=0;i<14&&!nb;i++){await sleep(250);nb=await E(()=>!!__game.B);}
 ok(nb,'a night-swapped wraith still engages an on-level hero');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
