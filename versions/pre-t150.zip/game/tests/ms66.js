// M66 (t149u): no yard anvil/furnace, performance mode (DPR1 default on touch), FPS overlay setting, fog/lighting cheap path.
//   node tests/ms66.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms66',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t149/.test(tags),'backup tag backup-pre-t149');
 await E(()=>__game.dbg.startFromTitle());await sleep(900);
 // yard forge props cleared; only interior ones remain (near shop door, not in open grass)
 let s=await E(()=>{
   const door=SMITH_SHOP.door;let yard=0,inside=0,pos=[];
   for(let y=0;y<MH;y++)for(let x=0;x<MW;x++)if(map[y][x]===T.ANV||map[y][x]===T.FRN){
     pos.push([x,y]);const nearDoor=door&&Math.abs(x-door.tx)<=4&&y>=door.wy-5&&y<=door.wy;
     if(nearDoor)inside++;else yard++;
   }
   return {yard,inside,pos,door};
 });
 ok(s.yard===0,'no stray yard anvil/furnace (yard='+s.yard+' inside='+s.inside+')');
 ok(s.inside>=1,'forge props remain inside the shop ('+s.inside+')');
 // performance mode defaults ON for touch; forces DPR 1
 s=await E(()=>{SET.perf=true;setApply();return {perf:SET.perf!==false,dpr:DPR,def:SET_DEFAULT.perf,hasFps:'fps' in SET_DEFAULT};});
 ok(s.def===true&&s.hasFps,'SET_DEFAULT.perf=true and fps setting exists');
 ok(s.perf&&s.dpr===1,'performance mode forces DPR 1 (got '+s.dpr+')');
 // HQ mode can raise DPR (on devices with dpr>1)
 s=await E(()=>{SET.perf=false;setApply();const d=DPR;SET.perf=true;setApply();return {hq:d,perf:DPR};});
 if(MOB)ok(s.hq>=s.perf,'HQ allows higher DPR than perf ('+s.hq+' vs '+s.perf+')');
 else ok(true,'desktop dpr typically 1 either way');
 // FPS overlay toggle draws when on
 s=await E(()=>{SET.fps=true;SET.perf=true;setApply();return String(drawFps).includes('FPS')||typeof drawFps==='function';});
 ok(s,'FPS overlay function exists');
 // fog cheap path in perf
 s=await E(()=>String(drawFog).includes('perfOn')&&String(drawFog).includes('fillRect'));
 ok(s,'perf fog uses cheap haze fillRect');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');
 ok(/arcane-knight-v55/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v55');
 await sleep(300);ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
