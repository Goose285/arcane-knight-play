// M7: crafting (monster parts -> gear) + card upgrades.  node tests/ms7.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,pg}=await boot('ms7');
 const a=await E(()=>{const g=__game,d=g.dbg,o={};
   o.mats=Object.keys(d.MATS).length>=8;o.map=d.MAT_DROP.slime&&d.MAT_DROP.lich&&d.MAT_DROP.wraith;
   g.P.lv=5;g.P.gold=0;
   // boss kill always drops parts
   const lich={type:'lich',def:{boss:true}};d.CR.mat={};const t=d.rollMats(lich);o.bossDrop=d.matCount('dust')>=3&&d.matCount('shard')>=2&&t.length===2;
   // normal enemy: over many rolls we get both its own part and sometimes shards
   d.CR.mat={};let n=0;for(let i=0;i<200;i++)d.rollMats({type:'slime',def:{}});o.slimeGel=d.matCount('gel')>60&&d.matCount('shard')>=1;
   return o;});
 ok(a.mats&&a.map,'craft: parts table + enemy->part map');ok(a.bossDrop,'craft: bosses always drop their part + shards');ok(a.slimeGel,'craft: regular foes drop their part often');
 const b=await E(()=>{const g=__game,d=g.dbg,o={};d.CR.mat={};g.P.gold=1000;g.P.lv=7;d.resetGear&&d.resetGear();
   const r=d.RECIPES.find(x=>x.id==='r_bone');o.noParts=d.craftGear(r)===null;o.goldKept=g.P.gold===1000;
   d.addMat('bone',6);d.addMat('gel',3);const it=d.craftGear(r);
   o.made=!!it&&it.name===r.name&&it.slot==='weapon'&&it.rar==='rare'&&it.lv>=7&&it.crafted;o.inInv=d.GEAR.inv.includes(it);
   o.paid=g.P.gold===1000-r.gold&&d.matCount('bone')===0&&d.matCount('gel')===0;
   o.allValid=d.RECIPES.every(x=>['weapon','armor','ring'].includes(x.slot)&&Object.keys(x.mats).every(k=>d.MATS[k]));
   return o;});
 ok(b.noParts&&b.goldKept,'craft: cannot craft without parts (nothing spent)');ok(b.made&&b.inInv,'craft: recipe yields named, rare, level-scaled gear in the backpack');ok(b.paid,'craft: parts + gold are consumed');ok(b.allValid,'craft: all 8 recipes reference real parts/slots');
 const c=await E(()=>{const g=__game,d=g.dbg,o={};g.P.gold=5000;['shard','scale','wing','ecto','bone'].forEach(k=>d.addMat(k,40));
   const id='fire';o.l0=d.upgLvl(id)===0&&d.upgMult(id)===1;
   o.up1=d.upgradeCard(id)&&d.upgLvl(id)===1&&Math.abs(d.upgMult(id)-1.15)<1e-9;
   o.up2=d.upgradeCard(id);o.up3=d.upgradeCard(id);o.capped=!d.upgradeCard(id)&&d.upgLvl(id)===3;
   o.label=d.cardLabel(g.CARDS?{id:'fire',name:'FIREBALL'}:{id:'fire',name:'FIREBALL'})==='FIREBALL+++';
   o.cost=d.upgCost('fire',0).mats.shard>=2&&d.upgCost('fire',2).gold>d.upgCost('fire',0).gold;
   o.notOwned=!d.upgradeCard('meteor');return o;});
 ok(c.l0&&c.up1,'upgrade: Fireball -> Fireball+ gives +15% power');ok(c.up2&&c.up3&&c.capped,'upgrade: max level 3');ok(c.label,'upgrade: label shows + marks');ok(c.cost,'upgrade: later levels cost more');ok(c.notOwned,'upgrade: cannot upgrade an unowned card');
 // upgraded card hits harder in a real fight
 const dmg=await E(async()=>{const g=__game,d=g.dbg;g.P.lv=3;g.P.gold=5000;g.P.hp=1e6;g.P.grace=99;g.state='play';
   const cast=async(up)=>{d.CR.upg={};if(up)d.CR.upg.lance=3;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
     const e=g.enemies.find(x=>x.type==='knight');g.tp(10,38);g.P.aim=Math.PI;e.x=6*32+16;e.y=38*32+28;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;
     d.startEncounter(e,true);const B=g.B;B.phase='fight';B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;o.hp=o.maxhp=99999;o.guard=0;});B.hand=['lance','sword','heal','fire','shield'];B.sel=0;
     d.useCard(0);await new Promise(r=>setTimeout(r,600));const h=99999-e.hp;d.endFight();return h;};
   const bs=[],us=[];for(let i=0;i<3;i++){bs.push(await cast(false));us.push(await cast(true));}const base=Math.min(...bs),up=Math.min(...us);return {base,up};});
 ok(dmg.base>0&&dmg.up>dmg.base*1.3,'upgrade: Lance+++ does clearly more damage in combat ('+dmg.base+' -> '+dmg.up+')');
 // kills drop parts in a real fight
 const kd=await E(async()=>{const g=__game,d=g.dbg;d.CR.mat={};g.P.hp=1e6;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;});
   let got=0;for(let i=0;i<14;i++){const e=g.enemies.find(x=>x.type==='slime');g.tp(10,38);e.x=7*32+16;e.y=38*32+28;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;e.engaged=false;
     d.startEncounter(e,true);g.B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=1;d.damageEnemy(e,50,'sword');d.endFight();}
   return d.matCount('gel');});
 ok(kd>=3,'craft: real kills grant parts ('+kd+' gel from 14 slimes)');
 // save / load
 const sv=await E(()=>{const g=__game,d=g.dbg;d.CR.mat={};d.CR.upg={};d.addMat('ecto',4);d.CR.upg.fire=2;g.saveGame('t');const s=g.readSave();const o={s:s.craft&&s.craft.mat.ecto===4&&s.craft.upg.fire===2};
   d.CR.mat={};d.CR.upg={};g.loadSave(s);o.b=d.matCount('ecto')===4&&d.upgLvl('fire')===2;return o;});
 ok(sv.s&&sv.b,'craft: parts and upgrades saved and restored');
 // the screen
 await E(()=>{const g=__game,d=g.dbg;g.state='play';g.P.lv=9;g.P.gold=5000;d.CR.mat={};d.CR.upg={};['shard','scale','wing','ecto','bone','hide','gel','dust'].forEach(k=>d.addMat(k,12));g.dbg.PAUSE_ITEMS.find(i=>i.lab()==='WORKBENCH').act();});await sleep(300);
 ok(await E(()=>__game.state)==='craft','screen: WORKBENCH opens from the pause menu');
 await E(()=>{__game.dbg.UI.scroll=0;});await sleep(200);await shot('crafting.png');
 const gearBefore=await E(()=>__game.dbg.GEAR.inv.length);
 ok(await tap('craft:r_hide',0),'screen: CRAFT button is on screen');ok(await E(()=>__game.dbg.GEAR.inv.length)===gearBefore+1,'screen: tapping CRAFT adds the item');
 ok(await tap('upg:sword',1e6),'screen: UPGRADE button is on screen');ok(await E(()=>__game.dbg.upgLvl('sword'))===1,'screen: tapping UPGRADE upgrades the card');
 await finish();
})();
