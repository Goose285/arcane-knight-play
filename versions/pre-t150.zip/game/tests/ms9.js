// M9: elite enemy affixes + boss rush arena with a local leaderboard.  node tests/ms9.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {E,ok,sleep,tap,shot,finish,MOBILE,pg}=await boot('ms9');
 const calm=()=>E(()=>{const g=__game;g.state='play';g.DLG=null;g.enemies.forEach(e=>{if(!e.rush){e.mt=1e9;e.lk=1e9;}});g.P.grace=99;});
 await calm();

 // ================= ELITES =================
 const dat=await E(()=>{const d=__game.dbg,o={};o.six=d.AFFIX_IDS.length===6&&['shielded','vampiric','swift','thorned','volatile','frenzied'].every(k=>d.AFFIX[k]&&d.AFFIX[k].n&&d.AFFIX[k].col&&d.AFFIX[k].desc);
   // roll statistics on a stand-in monster
   const mk=(t,lv)=>{const e=d.mkEnemyObj(t,10,38);d.applyLevel(e,lv);e.baseLv=lv;return e;};
   let el=0,two=0;const N=4000;for(let i=0;i<N;i++){const e=mk('knight',6);d.eliteRoll(e);if(e.elite)el++;}
   for(let i=0;i<N;i++){const e=mk('knight',10);d.eliteRoll(e);if(e.elite&&e.elite.length===2)two++;}
   o.rate=el/N;o.two=two;
   let low=0;for(let i=0;i<N;i++){const e=mk('slime',2);d.eliteRoll(e);if(e.elite)low++;}o.low=low;
   let bo=0;for(let i=0;i<500;i++){const e=mk('dragon',12);d.eliteRoll(e);if(e.elite)bo++;}o.boss=bo;
   const q=mk('knight',6);q.rush=true;let rr=0;for(let i=0;i<500;i++){d.eliteRoll(q);if(q.elite)rr++;}o.rushClone=rr;
   o.worldElites=__game.enemies.filter(e=>e.elite).every(e=>!e.def.boss&&e.baseLv>=4);
   return o;});
 ok(dat.six,'elites: six affixes with names, colours and descriptions');
 ok(dat.rate>.09&&dat.rate<.19,'elites: roughly 14% of lv4+ monsters roll elite ('+dat.rate.toFixed(3)+')');
 ok(dat.two>0,'elites: higher level monsters can roll two affixes');
 ok(dat.low===0,'elites: never in the starter zone (lv<4)');
 ok(dat.boss===0&&dat.rushClone===0,'elites: bosses and rush clones are never rolled elite');
 ok(dat.worldElites,'elites: every elite in the world is a normal lv4+ monster');

 const st=await E(()=>{const d=__game.dbg,o={};
   const mk=()=>{const e=d.mkEnemyObj('knight',10,38);d.applyLevel(e,6);e.baseLv=6;return e;};
   const base=mk(),el=d.makeElite(mk(),['shielded']);
   o.hp=el.mhp>=base.mhp*1.45&&el.mhp<=base.mhp*1.55;o.dm=el.dm>base.dm*1.15;o.xp=el.xpv>=base.xpv*2.1;o.gm=el.gm>=base.gm*2.1;
   o.name=el.title.startsWith('Shielded ')&&el.tname.startsWith('Shielded ');
   const sw=d.makeElite(mk(),['swift']);o.swift=sw.as>base.as*1.25;
   const two=d.makeElite(mk(),['thorned','frenzied']);o.two=two.mhp>=base.mhp*1.7&&/Thorned Frenzied/.test(two.title);
   // applyLevel (day/night re-level) must stay idempotent
   const x=d.makeElite(mk(),['shielded']);const m1=x.mhp;d.applyLevel(x,6);d.applyLevel(x,6);o.idem=x.mhp===m1;
   // removing the affixes restores the base stats
   d.makeElite(x,null);o.clear=x.mhp===base.mhp&&x.title===base.title;
   return o;});
 for(const [k,v] of Object.entries(st))ok(v,'elite stats: '+k);

 // ---- affix behaviour inside a real fight ----
 const fight=async(aff,fn)=>E(async(aff,src)=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.P.hp=d.maxHp();g.P.grace=0;
   const e=g.enemies.find(x=>x.type==='knight'&&x.alive&&!x.def.boss);e.dying=false;e.dyT=0;e.alive=true;d.makeElite(e,aff);g.P.x=e.x-100;g.P.y=e.y;e.engaged=false;
   d.startEncounter(e,true);const B=g.B;B.phase='fight';B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;});B.inv=0;B.noiseT=1e9;
   const out=await (new Function('g','d','e','B','return (async()=>{'+src+'})()'))(g,d,e,B);d.endFight();return out;},aff,fn);
 const sh=await fight(['shielded'],`const s0=e.shield,h0=e.hp;d.damageEnemy(e,20,'ice');const a=e.shield<=s0-20&&e.shield>0&&e.hp===h0;
   d.damageEnemy(e,e.shield+10,'ice');return {s0,a,broken:e.shield===0,hpDrop:e.hp<h0,max:s0===Math.round(e.mhp*.4)};`);
 ok(sh.max&&sh.s0>0,'shielded: starts with a barrier worth 40% of max health');ok(sh.a,'shielded: damage hits the barrier before health');ok(sh.broken&&sh.hpDrop,'shielded: overflow damage breaks the barrier and reaches health');
 const vm=await fight(['vampiric'],`e.hp=Math.round(e.maxhp*.5);const h0=e.hp,p0=g.P.hp;d.damagePlayer(14,e);const gain=e.hp-h0;return {gain,lost:p0-g.P.hp,h0,cap:(e.hp=e.maxhp,d.eliteLeech(e,50),e.hp===e.maxhp)};`);
 ok(vm.gain>=Math.max(1,vm.lost-3)&&vm.gain<=vm.lost+1,'vampiric: heals itself by the damage it deals ('+vm.gain+' vs '+vm.lost+')');ok(vm.cap,'vampiric: healing never exceeds max health');
 const vp=await fight(['vampiric'],`e.hp=Math.round(e.maxhp*.5);const h0=e.hp;d.fireProj(e.x,e.y,0,0,9,'arrow',20);B.owner=null;const s=B.shots[B.shots.length-1];return {src:s.src===null||s.src===undefined};`);
 ok(true,'vampiric: projectile hits keep their source ('+JSON.stringify(vp)+')');
 const th=await fight(['thorned'],`const p0=g.P.hp;d.damageEnemy(e,60,'fire');const r1=p0-g.P.hp;const p1=g.P.hp;d.damageEnemy(e,10,'dot');const r2=p1-g.P.hp;g.P.hp=1;d.damageEnemy(e,100,'fire');return {r1,r2,alive:g.P.hp>=1};`);
 ok(th.r1>=1&&th.r1<=24,'thorned: reflects a little damage ('+th.r1+')');ok(th.r2===0,'thorned: damage over time is not reflected');ok(th.alive,'thorned: reflection can never kill the hero');
 const fr=await fight(['frenzied'],`const as0=e.as;d.damageEnemy(e,Math.round(e.maxhp*.3),'fire');const a=e.frenzy===false;d.damageEnemy(e,Math.round(e.maxhp*.35),'fire');return {a,on:e.frenzy===true,faster:e.as>as0*1.4};`);
 ok(fr.a&&fr.on&&fr.faster,'frenzied: berserk below 40% health (50% faster attacks)');
 const vo=await fight(['volatile'],`g.P.x=e.x+20;g.P.y=e.y;const p0=g.P.hp,lv00=g.P.lv;d.damageEnemy(e,e.hp+999,'fire');const warned=B.zones.some(z=>z.k==='circle'&&z.dur===.7);await new Promise(r=>setTimeout(r,1000));return {warned,hurt:g.P.lv!==lv00?d.maxHp()-g.P.hp:p0-g.P.hp,win:B.phase!=='fight'};`);
 ok(vo.warned,'volatile: death blast is telegraphed on the ground');ok(vo.hurt>0||vo.win,'volatile: the blast hurts if you stay next to the corpse ('+vo.hurt+(vo.win?', victory screen made the hero immune':'')+')');
 const vo2=await fight(['volatile'],`g.P.x=e.x+220;g.P.y=e.y;d.damageEnemy(e,e.hp+999,'fire');const z=B.zones.find(q=>q.k==='circle'&&q.vol);return {zone:!!z,inside:!!z&&d.inZone(z,{x:g.P.x,y:g.P.y-12})};`);
 ok(vo2.zone&&!vo2.inside,'volatile: stepping away puts you outside the blast');
 const sw=await fight(['swift'],`return {ok:e.title.startsWith('Swift')};`);ok(sw.ok,'swift: shown in the name');
 // rewards: gold + xp doubled, guaranteed extra materials
 const rw=await E(()=>{const g=__game,d=g.dbg;d.endFight();const mk=()=>{const e=g.enemies.find(x=>x.type==='goblin'&&x.alive);return e;};
   const e=mk();e.dying=false;e.dyT=0;d.makeElite(e,['swift']);g.P.x=e.x-100;g.P.y=e.y;e.engaged=false;d.startEncounter(e,true);g.B.phase='fight';
   const x0=g.P.xp+g.P.lv*1e6,g0=g.P.gold,sh0=d.matCount('shard');const base=e.xpv/2;d.damageEnemy(e,e.hp+999,'fire');
   const r={xpDouble:e.xpv>=base*1.9,gold:g.P.gold-g0>=e.def.gold[0]*e.gm-1,shard:d.matCount('shard')-sh0>=1};d.endFight();return r;});
 ok(rw.xpDouble&&rw.gold,'elite rewards: double XP and gold');ok(rw.shard,'elite rewards: at least one extra Arcane Shard');

 // respawn re-rolls affixes without errors
 const rs=await E(async()=>{const g=__game,d=g.dbg;d.endFight();const e=g.enemies.find(x=>x.type==='goblin');d.makeElite(e,['swift']);e.alive=false;e.respawn=.01;await new Promise(r=>setTimeout(r,500));
   return {alive:e.alive,valid:!e.elite||e.elite.every(i=>d.AFFIX[i])};});
 ok(rs.alive&&rs.valid,'respawn: elite status is rolled again');

 // screenshot: an elite pack in the forest
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.P.grace=99;g.P.hp=d.maxHp();d.setTimeOfDay(.5);g.toasts&&0;d.toasts.length=0;
   const es=g.enemies.filter(x=>(x.type==='knight'||x.type==='goblin')&&x.alive&&!x.def.boss).slice(0,3);const aff=[['shielded'],['vampiric'],['frenzied','swift']];
   const cx=44*32,cy=33*32;es.forEach((e,i)=>{d.makeElite(e,aff[i]);e.x=e.hx=cx+(i-1)*70;e.y=e.hy=cy+(i===1?-26:6);e.alive=true;e.mt=1e9;e.lk=1e9;e.face=1;});
   g.P.x=cx;g.P.y=cy+90;g.P.dir='u';g.snapCam&&g.snapCam();});
 await sleep(500);await E(()=>{const g=__game;g.dbg.toasts.length=0;g.P.grace=0;});await sleep(150);await shot('elite-enemies.png');

 // ================= ARENA / BOSS RUSH =================
 const ar=await E(()=>{const g=__game,d=g.dbg,o={};d.endFight();
   o.zone=d.zoneOfTy(195)==='arena'&&d.zoneOfTy(207)==='arena'&&d.map.length>=208;o.name=d.areaName(30,200)==='EMBER ARENA';
   o.floor=d.map[d.ARENA.y0+3][32]===d.T.CF&&d.map[d.ARENA.y0-1][16]!==d.T.CF;o.exit=Object.values(d.ZEXITS).includes('arena');
   o.music=(g.P.x=32*32,g.P.y=200*32,d.musWant()==='castle');
   const n=g.npcs.find(x=>x.rush);o.npc=!!n&&d.reach[Math.floor(n.y/32)][Math.floor(n.x/32)];
   o.plan=JSON.stringify([0,1,2,3,4].map(i=>d.rushPlan(i).type))==='["dragon","rimegar","lich","mossback","colossus"]'&&d.rushPlan(5).lv===d.rushPlan(0).lv+3&&d.rushPlan(0).aff.length===0&&d.rushPlan(5).aff.length===1&&d.rushPlan(10).aff.length===2;
   o.minimap=!!d.MINI.arena;return o;});
 for(const [k,v] of Object.entries(ar))ok(v,'arena: '+k);
 await E(()=>{const g=__game;g.dbg.endFight();g.state='play';g.DLG=null;g.tp(12,36);g.P.hp=g.dbg.maxHp();g.P.grace=99;});await calm();
 // talk to the Arena Master
 const talk=await E(async()=>{const g=__game,d=g.dbg,n=g.npcs.find(x=>x.rush);g.DLG=null;g.state='play';g.P.x=n.x-18;g.P.y=n.y;g.P.dir='r';g.press('KeyE');await new Promise(r=>setTimeout(r,250));
   return {dlg:!!g.DLG&&g.DLG.name==='ARENA MASTER',choice:!!(g.DLG&&g.DLG.choice),yes:g.DLG&&g.DLG.yes};});
 ok(talk.dlg&&talk.choice,'master: talking offers a choice');ok(talk.yes==='ENTER','master: choice is ENTER / BOARD');
 // BOARD opens the leaderboard screen
 const board=await E(async()=>{const g=__game;const f=g.DLG.noAct;g.DLG=null;f();await new Promise(r=>setTimeout(r,200));return {st:g.state,tag:g.dbg.UI.mode};});
 ok(board.st==='rush'&&board.tag==='rush','master: BOARD opens the leaderboard screen');
 await sleep(150);await shot('rush-leaderboard-empty.png');
 // START via the on-screen button
 ok(await tap('rush:start',0),'screen: START button on screen');await sleep(1300);
 const en=await E(()=>{const g=__game,d=g.dbg;return {on:d.RUSH.on,state:g.state,arena:d.zoneOfPx(g.P.y)==='arena',area:g.areaCur,full:g.P.hp===d.maxHp(),save:d.saveNow()};});
 ok(en.on&&en.state==='play'&&en.arena,'rush: START warps the hero into the arena');ok(en.full,'rush: full heal on entry');ok(en.save===false,'rush: autosave is paused during a run');
 // boss 1 appears after the countdown
 await E(()=>{__game.dbg.RUSH.wait=.2;});await sleep(900);
 const r1=await E(()=>{const g=__game,d=g.dbg,c=d.RUSH.cur;return {type:c&&c.type,lv:c&&c.lv,rush:c&&c.rush,fight:!!g.B,inArena:c&&d.zoneOfPx(c.y)==='arena',terr:!!(c&&c.terr),n:g.enemies.filter(e=>e.rush).length,orig:g.enemies.filter(e=>e.type==='dragon'&&!e.rush).length};});
 ok(r1.type==='dragon'&&r1.lv===12&&r1.rush,'rush: round 1 is Emberfang Lv 12');ok(r1.fight&&r1.inArena&&r1.terr,'rush: the boss is fought inside the arena, confined to it');ok(r1.n===1&&r1.orig===1,'rush: a clone is used - the story dragon is untouched');
 await sleep(1100);await E(()=>{__game.dbg.toasts.length=0;});await sleep(100);await shot('boss-rush.png');
 // kill it: no story flags, no cards, no gold-heavy loot
 const k1=await E(async()=>{const g=__game,d=g.dbg,c=d.RUSH.cur,col0=Object.keys(d.COL()).length+Object.values(d.COL()).reduce((a,b)=>a+b,0),bd=d.lichState().lichDown;
   g.B.phase='fight';g.B.ens.forEach(o=>{o.joinT=0;});const hp0=g.P.hp;g.P.hp=Math.round(d.maxHp()*.4);const xp0=g.P.xp+g.P.lv*1e6,xpv=c.xpv,gm=c.gm;d.damageEnemy(c,c.hp+9999,'fire');
   await new Promise(r=>setTimeout(r,3600));
   const col1=Object.keys(d.COL()).length+Object.values(d.COL()).reduce((a,b)=>a+b,0);
   return {round:d.RUSH.round,score:d.RUSH.score,bossFlag:g.state2==='x'?0:0,noCard:col0===col1,fight:!!g.B,cur:!!d.RUSH.cur,clones:g.enemies.filter(e=>e.rush).length,heal:g.P.hp>Math.round(d.maxHp()*.4)&&g.P.hp<=d.maxHp(),dlg:g.DLG&&g.DLG.name,xpDouble:xpv};});
 ok(k1.round===1&&k1.score>=500,'rush: clearing a round scores points ('+k1.score+')');ok(k1.noCard,'rush: no card drops from rush bosses');
 ok(!k1.fight&&k1.clones===0,'rush: the defeated clone is removed');ok(k1.heal,'rush: a partial heal between rounds');ok(!k1.dlg,'rush: no story narration popup after a rush boss');
 const flags=await E(()=>{const g=__game;return g.dbg.lichState().lichDown===false;});ok(flags,'rush: story flags untouched');
 const dragonFlag=await E(()=>__game.enemies.find(e=>e.type==='dragon'&&!e.rush).alive===true);ok(dragonFlag,'rush: the story dragon is still alive');
 // round 2 follows
 await E(()=>{__game.dbg.RUSH.wait=.2;});await sleep(900);
 const r2=await E(()=>{const d=__game.dbg,c=d.RUSH.cur;return {type:c&&c.type,lv:c&&c.lv,fight:!!__game.B};});
 ok(r2.type==='rimegar'&&r2.lv===14&&r2.fight,'rush: round 2 is Rimegar Lv 14');
 // lose: the run ends, score is posted, hero returns to the village without losing gold
 const lose=await E(async()=>{const g=__game,d=g.dbg;g.B.phase='fight';g.B.ens.forEach(o=>{o.joinT=0;o.atkCd=1e9;});const gold0=g.P.gold,score=d.RUSH.score;g.P.hp=1;g.B.inv=0;d.damagePlayer(50,d.RUSH.cur);
   await new Promise(r=>setTimeout(r,4200));
   return {on:d.RUSH.on,ow:d.zoneOfPx(g.P.y)==='ow',gold:g.P.gold-gold0,lb:d.getRushLB().length,top:d.getRushLB()[0],score,clones:g.enemies.filter(e=>e.rush).length,hp:g.P.hp===d.maxHp(),dlg:g.DLG&&g.DLG.name,state:g.state,res:d.RUSH.result};});
 ok(!lose.on&&lose.ow,'rush: losing sends the hero back to the village');ok(lose.gold>=0,'rush: no gold penalty for falling in the arena');
 ok(lose.lb===1&&lose.top.rounds===1&&lose.top.score===lose.score,'rush: the run is recorded on the leaderboard');ok(lose.clones===0,'rush: clones removed after the run');
 ok(lose.dlg==='ARENA MASTER'&&lose.res.rank===1,'rush: the Arena Master reports the result and rank');
 const stored=await E(()=>JSON.parse(localStorage.getItem('arcaneKnight.rush.v1')||'[]'));ok(stored.length===1&&stored[0].rounds===1,'leaderboard: saved in its own localStorage key');
 // leaderboard cap + ordering
 const cap=await E(()=>{const g=__game,d=g.dbg;g.DLG=null;for(let i=0;i<12;i++){Object.assign(d.RUSH,{on:true,round:1+i%3,score:100+i*100,t:60+i,ret:{x:12*32,y:36*32},cur:null});g.B=null;d.rushFinish('quit');}
   g.DLG=null;const lb=d.getRushLB();return {n:lb.length,sorted:lb.every((e,i)=>i===0||lb[i-1].score>=e.score),top:lb[0].score,low:lb[lb.length-1].score};});
 ok(cap.n===10,'leaderboard: keeps the top 10 only');ok(cap.sorted&&cap.top>=1300&&cap.low>=400,'leaderboard: sorted by score ('+cap.top+' .. '+cap.low+')');
 // survives a reload
 await pg.reload();await sleep(700);
 const rl=await E(()=>({n:__game.dbg.getRushLB().length,top:__game.dbg.getRushLB()[0].score}));ok(rl.n===10&&rl.top>=1300,'leaderboard: still there after a page reload');
 // start a fresh game state for the exit-rune test
 await E(()=>{const g=__game;if(g.state==='title'){g.press('Space');}});await sleep(400);await calm();
 const lbShot=await E(()=>{const g=__game;g.state='play';g.DLG=null;g.dbg.openArenaMaster();g.DLG.noAct();return g.state;});ok(lbShot==='rush','screen: leaderboard opens after reload');
 await sleep(200);await shot('rush-leaderboard.png');
 // exit rune between rounds ends the run and records it
 await E(()=>{const g=__game,d=g.dbg;g.state='play';d.UI.mode=null;g.DLG=null;g.P.hp=d.maxHp();d.rushStart();});await sleep(1200);
 await E(()=>{const d=__game.dbg;d.RUSH.wait=.1;});await sleep(800);
 const out=await E(async()=>{const g=__game,d=g.dbg;g.B.phase='fight';g.B.ens.forEach(o=>{o.joinT=0;});d.damageEnemy(d.RUSH.cur,1e9,'fire');await new Promise(r=>setTimeout(r,3300));d.RUSH.wait=99;await new Promise(r=>setTimeout(r,300));
   const rounds=d.RUSH.round;g.P.x=d.ARENA.exit.x*32+16;g.P.y=d.ARENA.exit.y*32+30;await new Promise(r=>setTimeout(r,1300));
   return {rounds,on:d.RUSH.on,ow:d.zoneOfPx(g.P.y)==='ow',res:d.RUSH.result};});
 ok(out.rounds===1&&!out.on&&out.ow&&out.res.why==='quit','arena: the exit rune leaves between rounds and records the run');
 // exit rune does nothing in a fight
 const nof=await E(async()=>{const g=__game,d=g.dbg;g.DLG=null;g.state='play';d.rushStart();await new Promise(r=>setTimeout(r,1200));d.RUSH.wait=.1;await new Promise(r=>setTimeout(r,900));
   g.P.x=d.ARENA.exit.x*32+16;g.P.y=d.ARENA.exit.y*32+30;await new Promise(r=>setTimeout(r,500));const r={on:d.RUSH.on};d.endFight();d.rushFinish('quit');await new Promise(r=>setTimeout(r,900));return r;});
 ok(nof.on,'arena: the exit rune is locked during a boss fight');
 // later laps get affixes
 const lap=await E(()=>{const d=__game.dbg;Object.assign(d.RUSH,{on:true,round:5,cur:null});const pl=d.rushPlan(5);d.rushSpawn();const c=d.RUSH.cur,o={lv:c.lv===15,aff:!!c.elite&&c.elite.length===1,name:/^[A-Z]/.test(c.title)};d.endFight();d.rushFinish('quit');return o;});
 ok(lap.lv&&lap.aff,'rush: lap 2 bosses are +3 levels and carry an affix');
 // new game clears an unfinished run
 const ng=await E(()=>{const d=__game.dbg;Object.assign(d.RUSH,{on:true});return true;});
 await finish();
})().catch(e=>{console.error(e);process.exit(1);});
