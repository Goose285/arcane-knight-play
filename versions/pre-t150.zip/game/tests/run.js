// `npm test`: builds, then runs every test (legacy scripts: must exit 0 with no page errors; suite.js: assertions)
const {spawnSync}=require('child_process');const path=require('path');const fs=require('fs');
const dir=__dirname,hook=path.join(dir,'lib','hook.js');
const jobs=[
  ['suite desktop','suite.js',['desktop']],['suite mobile','suite.js',['mobile']],['features desktop','features.js',['desktop']],['features iPhone','features.js',['mobile']],
  ['vision (v1)','legacy/v1.js',[]],['walls (w1) desktop','legacy/w1.js',[]],['walls (w1) iPhone','legacy/w1.js',['mob']],
  ['group fight (g1)','legacy/g1.js',[]],['dragon territory (terr)','legacy/terr.js',[]],['boss (boss)','legacy/boss.js',[]],
  ['swipe-cast (sw)','legacy/sw.js',[]],['card swipe (iPhone+mouse)','legacy/cardswipe.js',[]],['save/continue (sv)','legacy/sv.js',[]],
  ['cards desktop','legacy/cards.js',[]],['cards iPhone','legacy/cards.js',['mobile']],
  ['deck/drops desktop','legacy/cards2.js',[]],['deck/drops iPhone','legacy/cards2.js',['mobile']],
  ['shop/save/fx desktop','legacy/cards3.js',[]],['shop/save/fx iPhone','legacy/cards3.js',['mobile']],
  ['sword auto-target','legacy/sword.js',[]],
  ['M6 skills desktop','ms6.js',['desktop']],['M6 skills iPhone','ms6.js',['mobile']],
  ['M7 craft desktop','ms7.js',['desktop']],['M7 craft iPhone','ms7.js',['mobile']],
  ['M8 regions desktop','ms8.js',['desktop']],['M8 regions iPhone','ms8.js',['mobile']],
  ['M9 elites+rush desktop','ms9.js',['desktop']],['M9 elites+rush iPhone','ms9.js',['mobile']],
  ['M10 pets+house desktop','ms10.js',['desktop']],['M10 pets+house iPhone','ms10.js',['mobile']],
  ['M11 story desktop','ms11.js',['desktop']],['M11 story iPhone','ms11.js',['mobile']],
  ['M12 daily+weekly desktop','ms12.js',['desktop']],['M12 daily+weekly iPhone','ms12.js',['mobile']],
  ['M13 settings+tutorial desktop','ms13.js',['desktop']],['M13 settings+tutorial iPhone','ms13.js',['mobile']],
  ['M14 aim preview desktop','ms14.js',['desktop']],['M14 aim preview iPhone','ms14.js',['mobile']],
  ['M15 charge+tutorial+escape+night+lights desktop','ms15.js',['desktop']],['M15 charge+tutorial+escape+night+lights iPhone','ms15.js',['mobile']],
  ['M16 quest tracker desktop','ms16.js',['desktop']],['M16 quest tracker iPhone','ms16.js',['mobile']],
  ['M17 spawners+fishing+chapel+tap-talk desktop','ms17.js',['desktop']],['M17 spawners+fishing+chapel+tap-talk iPhone','ms17.js',['mobile']],
  ['M18 tree variety desktop','ms18.js',['desktop']],['M18 tree variety iPhone','ms18.js',['mobile']],
  ['M19 day/sunset/night art desktop','ms19.js',['desktop']],['M19 day/sunset/night art iPhone','ms19.js',['mobile']],
  ['M20 fire light+charge carry+card layout desktop','ms20.js',['desktop']],['M20 fire light+charge carry+card layout iPhone','ms20.js',['mobile']],
  ['M21 sun paladin desktop','ms21.js',['desktop']],['M21 sun paladin iPhone','ms21.js',['mobile']],
  ['M22 pause menu desktop','ms22.js',['desktop']],['M22 pause menu iPhone','ms22.js',['mobile']],
  ['M23 charge carry-over desktop','ms23.js',['desktop']],['M23 charge carry-over iPhone','ms23.js',['mobile']],
  ['M24 roads+gravel desktop','ms24.js',['desktop']],['M24 roads+gravel iPhone','ms24.js',['mobile']],
  ['M25 awareness+AI desktop','ms25.js',['desktop']],['M25 awareness+AI iPhone','ms25.js',['mobile']],
  ['M26 town guards desktop','ms26.js',['desktop']],['M26 town guards iPhone','ms26.js',['mobile']],
  ['M27 pets/tracker/map desktop','ms27.js',['desktop']],['M27 pets/tracker/map iPhone','ms27.js',['mobile']],
  ['M28 two-thumb layout iPhone','ms28.js',['mobile']],['M28 two-thumb layout iPhone landscape','ms28.js',['mobile','land']],['M28 two-thumb layout iPhone SE','ms28.js',['mobile','se']],
  ['M29 guaranteed cards desktop','ms29.js',['desktop']],['M29 guaranteed cards iPhone','ms29.js',['mobile']],
  ['M30 ghost blobs desktop','ms30.js',['desktop']],['M30 ghost blobs iPhone','ms30.js',['mobile']],
  ['M32 combat lab desktop','ms32.js',['desktop']],['M32 combat lab iPhone','ms32.js',['mobile']],
  ['M33 heal+night+inn+waystone desktop','ms33.js',['desktop']],['M33 heal+night+inn+waystone iPhone','ms33.js',['mobile']],
  ['M34 camp+teleport+aggro desktop','ms34.js',['desktop']],['M34 camp+teleport+aggro iPhone','ms34.js',['mobile']],
  ['M37 4-card hand desktop','ms37.js',['desktop']],['M37 4-card hand iPhone','ms37.js',['mobile']],
  ['M39 landscape + rotate','ms39.js',['mobile']],
  ['M40 fishing lab desktop','ms40.js',['desktop']],
  ['M40 fishing lab iPhone','ms40.js',['mobile']],
  ['M41 pets+discard desktop','ms41.js',['desktop']],
  ['M41 pets+discard iPhone','ms41.js',['mobile']],
  ['M42 idle fishing desktop','ms42.js',['desktop']],
  ['M42 idle fishing iPhone','ms42.js',['mobile']],
  ['M43 water edges + big trees desktop','ms43.js',['desktop']],
  ['M43 water edges + big trees iPhone','ms43.js',['mobile']],
  ['M44 tracker + fishing anim desktop','ms44.js',['desktop']],
  ['M44 tracker + fishing anim iPhone','ms44.js',['mobile']],
  ['M45 satchel menu desktop','ms45.js',['desktop']],
  ['M45 satchel menu iPhone','ms45.js',['mobile']],
  ['M38 save safety desktop','ms38.js',['desktop']],['M38 save safety iPhone','ms38.js',['mobile']],
  ['M36 card targeting desktop','ms36.js',['desktop']],['M36 card targeting iPhone','ms36.js',['mobile']],
  ['M35 waystone+bosses desktop','ms35.js',['desktop']],['M35 waystone+bosses iPhone','ms35.js',['mobile']],
  ['M31 guards defend desktop','ms31.js',['desktop']],['M31 guards defend iPhone','ms31.js',['mobile']],
];
const only=process.argv[2];let fail=0;const t0=Date.now();
for(const [name,file,args] of jobs){
  if(only&&!name.includes(only))continue;
  const t=Date.now();
  const r=spawnSync('node',['-r',hook,path.join(dir,file),...args],{encoding:'utf8',timeout:300000,cwd:dir});
  const out=(r.stdout||'')+(r.stderr||'');
  const ok=r.status===0;if(!ok)fail++;
  console.log((ok?'PASS ':'FAIL ')+name+'  ('+((Date.now()-t)/1000).toFixed(0)+'s)');
  if(!ok)console.log(out.split('\n').slice(-14).join('\n'));
}
console.log(fail?`\n${fail} FAILED`:'\nALL TESTS PASSED',' in '+((Date.now()-t0)/1000).toFixed(0)+'s');
process.exit(fail?1:0);
