// M25: awareness circles, enemies near you join the fight, smarter combat AI (dodge, retreat, flank).  node tests/ms25.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,finish}=await boot('ms25',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();});
 // park every enemy far away; helpers
 const reset=(tx=10,ty=22)=>E((tx,ty)=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;window.__DODGEP=null;window.__RETREATP=null;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.calm=0;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;e.fa=0;e.ta=0;});
   g.P.x=tx*32+16;g.P.y=ty*32+28;g.tp(tx,ty);g.P.x=tx*32+16;g.P.y=ty*32+28;g.P.grace=0;g.P.hp=1e6;g.P.lv=Math.max(g.P.lv,3);d.toasts.length=0;},tx,ty);
 const put=(type,x,y,fa,o={})=>E((type,x,y,fa,o,idx)=>{const g=__game,l=g.enemies.filter(e=>e.type===type&&!e.def.boss);const e=l[idx||0];e.x=e.hx=x;e.y=e.hy=y;e.fa=e.ta=fa;e.mode='look';e.mt=e.lk=1e9;e.alive=true;e.dying=false;e.engaged=false;Object.assign(e,o);return l.indexOf(e);},type,x,y,fa,o,o.idx||0);
 const px=()=>E(()=>({x:__game.P.x,y:__game.P.y}));
 // ---- 1. awareness circle sizes
 const ar=await E(()=>{const g=__game,o={};g.enemies.filter(e=>!e.def.boss).forEach(e=>{const k=e.type;o[k]=Math.min(o[k]||1e9,e.def.ar);});return o;});
 const vals=Object.values(ar);ok(vals.every(v=>v>=64&&v<=84),'awareness circle is ~2-2.5 tiles for every regular type ('+JSON.stringify(ar)+')');
 ok(ar.slime<=ar.knight&&ar.slime<=ar.goblin,'scaled by type (slime smallest)');
 // ---- 2. circle triggers aggro with no cone: knight faces AWAY, 60px behind vs 120px behind
 await reset();let p=await px();await put('knight',p.x+60,p.y,0);await sleep(500);
 ok(await E(()=>!!__game.B),'inside the awareness circle (60px, facing away): aggro without a cone');
 await reset();p=await px();await put('knight',p.x+120,p.y,0);await sleep(900);
 ok(await E(()=>!__game.B),'outside the circle and cone (120px, facing away): no aggro');
 // ---- 3. an enemy standing next to you joins a fight, even when the usual 4-enemy cap is full and the fighters are far away
 await reset();p=await px();
 const gi=[];for(let i=0;i<4;i++)gi.push(await put('goblin',p.x+230+i*10,p.y+(i-1.5)*14,Math.PI,{idx:i}));
 await put('slime',p.x-42,p.y+6,Math.PI,{idx:0});
 await E(()=>{const g=__game,d=g.dbg,gl=g.enemies.filter(e=>e.type==='goblin'&&!e.def.boss);d.startEncounter(gl[0],true);});await sleep(300);
 let n1=await E(()=>({n:__game.B?__game.B.ens.length:0,slime:__game.B?__game.B.ens.some(e=>e.type==='slime'):false}));
 await sleep(1200);
 const n2=await E(()=>({n:__game.B.ens.length,slime:__game.B.ens.some(e=>e.type==='slime'),cap:__game.B.ens.length}));
 ok(n2.slime,'a slime right next to the hero joins the active combat (fighters: '+n2.n+')');
 ok(n2.n>=5,'proximity joiners may exceed the normal cap of 4 ('+n2.n+')');
 // ---- 4. a far slime (outside circle, cone and fighters' noise range) does not
 await reset();p=await px();
 for(let i=0;i<2;i++)await put('goblin',p.x+230+i*10,p.y+(i-.5)*14,Math.PI,{idx:i});
 await put('slime',p.x-330,p.y,Math.PI,{idx:0});
 await E(()=>{const g=__game,d=g.dbg,gl=g.enemies.filter(e=>e.type==='goblin'&&!e.def.boss);d.startEncounter(gl[0],true);});await sleep(1500);
 ok(await E(()=>!__game.B.ens.some(e=>e.type==='slime')),'a faraway slime stays out of it');
 // ---- 5. decoy / shadow-step shrink the circle
 await reset();p=await px();await put('goblin',p.x+200,p.y,Math.PI,{idx:0});
 await E(()=>{const g=__game,t=g.townDbg(),d=g.dbg,e=g.enemies.find(x=>x.type==='slime');d.startEncounter(g.enemies.find(x=>x.type==='goblin'&&!x.def.boss),true);g.B.decoy={hp:50,x:0,y:0};window.__dec=t.awareR(e);g.B.decoy=null;g.B.ghost=1;window.__gh=t.awareR(e);g.B.ghost=0;window.__base=t.awareR(e);});
 const sh=await E(()=>({base:window.__base,dec:window.__dec,gh:window.__gh}));
 ok(sh.dec<sh.base*.7&&sh.gh<sh.base*.7,'a decoy or shadow step shrinks the awareness circle ('+sh.base+' -> '+sh.dec+' / '+sh.gh+')');
 // ---- 6. dodge: forced chance -> the knight sidesteps a shot; chance 0 -> it is hit; scaling by tier
 const dodgeRun=async chance=>{await reset();p=await px();await put('knight',p.x-130,p.y,0);
   await E(c=>{const g=__game,d=g.dbg,k=g.enemies.find(e=>e.type==='knight'&&!e.def.boss);window.__DODGEP=c;d.startEncounter(k,true);g.B.phase='fight';g.B.joinT=0;k.joinT=0;k.hp=k.maxhp=k.mhp=99999;k.atkCd=99;k.dodgeCd=0;g.B.ens=[k];window.__k=k;k.dodged=0;window.__hp0=k.hp;window.__ky=k.y;
     g.P.x=k.x+130;g.P.y=k.y;g.P.aim=Math.PI;g.B.shots.push({x:g.P.x-10,y:g.P.y-12-0,vx:-380,vy:0,r:5,dmg:50,own:'p',kind:'arcane',life:1,a:Math.PI});window.__k.y=g.P.y;},chance);
   await sleep(900);return E(()=>({d:window.__k.dodged||0,hp:window.__k.hp,moved:Math.abs(window.__k.y-window.__ky)}));};
 let r=await dodgeRun(1);ok(r.d>=1&&r.hp>=99999,'forced dodge: the knight sidesteps the shot and takes no damage ('+JSON.stringify(r)+')');
 r=await dodgeRun(0);ok(r.d===0&&r.hp<99999,'chance 0: the shot lands ('+JSON.stringify(r)+')');
 const sc=await E(()=>{window.__DODGEP=null;const g=__game,t=g.townDbg(),k=g.enemies.find(e=>e.type==='knight'&&!e.def.boss),b=g.enemies.find(e=>e.def.boss);const o={},oe=k.elite,ot=k.tier;
   k.tier=0;k.elite=null;o.t0=t.dodgeChance(k);k.tier=2;o.t2=t.dodgeChance(k);k.elite='x';o.elite=t.dodgeChance(k);o.boss=t.dodgeChance(b);k.elite=oe;k.tier=ot;return o;});
 ok(sc.t2>sc.t0&&sc.elite>sc.t2&&sc.boss===0&&sc.elite<=.6,'dodge chance scales with tier / elite, bosses never dodge ('+JSON.stringify(sc)+')');
 // ---- 7. retreat at low HP (once), only for the types that do it
 const retreatRun=async(type,hpFrac)=>{await reset(11,20);p=await px();await put(type,p.x+110,p.y,Math.PI);
   await E((type,f)=>{const g=__game,d=g.dbg,k=g.enemies.find(e=>e.type===type&&!e.def.boss);window.__RETREATP=1;d.startEncounter(k,true);g.B.ens=[k];k.joinT=0;k.hp=k.maxhp*f;window.__k=k;window.__d0=Math.hypot(k.x-g.P.x,k.y-g.P.y);},type,hpFrac);
   await sleep(1100);return E(()=>{const g=__game,k=window.__k;return {ret:k.retreated===true,t:k.retreat,d:Math.hypot(k.x-g.P.x,k.y-g.P.y)-window.__d0,st:k.st};});};
 r=await retreatRun('goblin',.15);ok(r.ret&&r.d>8&&r.st!=='windup','a badly wounded goblin backs off ('+JSON.stringify(r)+')');
 r=await retreatRun('knight',.9);ok(!r.ret,'a healthy knight does not retreat');
 r=await retreatRun('slime',.1);ok(!r.ret,'slimes never retreat');
 // ---- 8. flanking: three knights charging from one side spread out around the hero
 await reset(11,20);p=await px();
 for(let i=0;i<3;i++)await put('knight',p.x+300,p.y+(i-1)*10,Math.PI,{idx:i});
 await E(()=>{const g=__game,d=g.dbg,kn=g.enemies.filter(e=>e.type==='knight'&&!e.def.boss).slice(0,3);d.startEncounter(kn[0],true);kn.slice(1).forEach(k=>{g.townDbg().initCombatEnemy(k,0);g.B.ens.push(k);});g.B.ens.forEach(k=>{k.joinT=0;k.atkCd=99;k.hp=k.maxhp=k.mhp=99999;});g.P.hp=1e6;});
 let spread=0;for(let t=0;t<14;t++){await sleep(250);spread=Math.max(spread,await E(()=>{const g=__game,a=g.B.ens.map(k=>Math.atan2(k.y-g.P.y,k.x-g.P.x));let m=0;for(const x of a)for(const y of a)m=Math.max(m,Math.abs(Math.atan2(Math.sin(x-y),Math.cos(x-y))));return m;}));}
 ok(spread>.7,'three melee foes fan out around the hero instead of stacking (max angular spread '+spread.toFixed(2)+' rad)');
 // ---- 9. attacks stay telegraphed + staggered (existing rule): never more than 2 windups at once
 await reset();p=await px();
 for(let i=0;i<4;i++)await put('goblin',p.x+170+i*8,p.y+(i-1.5)*20,Math.PI,{idx:i});
 await E(()=>{const g=__game,d=g.dbg,gl=g.enemies.filter(e=>e.type==='goblin'&&!e.def.boss).slice(0,4);d.startEncounter(gl[0],true);gl.slice(1).forEach(k=>{g.townDbg().initCombatEnemy(k,0);g.B.ens.push(k);});g.B.ens.forEach(k=>{k.joinT=0;k.atkCd=.1;});g.P.hp=1e6;window.__maxW=0;window.__iv=setInterval(()=>{if(__game.B){const w=__game.B.ens.filter(o=>o.st==='windup').length;if(w>window.__maxW){window.__maxW=w;window.__wi=__game.B.ens.map(o=>o.type+':'+o.st+':'+o.dying+':'+o.t.toFixed(2)).join(' ');}}},40);});
 await sleep(3500);const mw=await E(()=>{clearInterval(window.__iv);return window.__maxW;});
 ok(mw<=3,'group attacks are staggered: at most 3 simultaneous telegraphs ('+mw+' '+await E(()=>window.__wi)+')');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
