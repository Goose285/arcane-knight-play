// M39: phone landscape is the primary layout (844x390): HUD / stick / SHOT + fan / tracker / minimap fit; portrait phones get a 'rotate' overlay; lefty mirrors.  node tests/ms39.js [mobile]
process.argv[2]='mobile';
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish}=await boot('ms39',{town:true,device:'iPhone 12 landscape'});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.endFight();g.P.lv=Math.max(g.P.lv,12);});
 const sz=await E(()=>({w:innerWidth,h:innerHeight,vw:__game.size.VW,vh:__game.size.VH,rot:getComputedStyle(document.getElementById('rotate')).display}));
 await E(()=>{window.__ROTATE_TEST=true;});ok(sz.w===844&&sz.h===390,'viewport is 844x390 ('+JSON.stringify(sz)+')');
 ok(sz.rot==='none','no rotate overlay in landscape');
 // ---- overworld HUD
 await E(()=>{const g=__game,d=g.dbg;d.setTimeOfDay(.5);g.tp(11,20);g.P.x=11*32+16;g.P.y=20*32+28;g.P.grace=99;d.TRK.open=true;});await sleep(500);
 const L=()=>E(()=>{const g=__game,z=g.size,b=g.btn,jz=g.dbg.joyZone();return {atk:{x:b.atk.x,y:b.atk.y,r:b.atk.r},cast:!!b.cast,pause:{x:b.pause.x,y:b.pause.y,r:b.pause.r},jz,z:{VW:z.VW,VH:z.VH,SL:z.SL,SR:z.SR,ST:z.ST,SB:z.SB},L:g.dbg.LEFTY};});
 let l=await L();
 ok(l.atk.x>l.z.VW/2&&l.atk.x+l.atk.r<=l.z.VW-l.z.SR&&l.atk.y+l.atk.r<=l.z.VH-l.z.SB,'SHOT sits bottom-right inside the margins ('+JSON.stringify(l.atk)+')');
 ok(!l.cast,'no CAST button');
 ok(l.jz.x1<l.z.VW*.5&&l.jz.x0<=l.z.SL+1,'joystick zone is the left side of the screen');
 await shot('landscape-overworld.png');
 // ---- fight with the 4-card fan
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.calm=0;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;});
   const e=g.enemies.find(q=>q.type==='slime'&&!q.def.boss);e.x=e.hx=(11+4)*32;e.y=e.hy=20*32+28;e.hp=e.maxhp=e.mhp=1e7;d.startEncounter(e,true);const B=g.B;B.phase='fight';B.inv=99;e.atkCd=1e9;e.joinT=0;B.hand=['fire','heal','lance','chain'];B.sel=0;});await sleep(500);
 const geo=()=>E(()=>{const g=__game,z=g.size,R=g.cardRects.slice(),a=g.btn.atk,jz=g.dbg.joyZone(),L=g.dbg.LEFTY;
   const cx=r=>r.cx!=null?r.cx:r.x+r.w/2,cy=r=>r.cy!=null?r.cy:r.y+r.h/2;
   const hw=R.map(r=>Math.hypot(cx(r)-a.x,cy(r)-a.y)-a.r-Math.min(r.w,r.h)/2);
   return {n:R.length,onscreen:R.every(r=>cx(r)-r.w/2>=z.SL-4&&cx(r)+r.w/2<=z.VW-z.SR+4&&cy(r)-r.h/2>=z.ST&&cy(r)+r.h/2<=z.VH-z.SB+4),clear:Math.min(...hw)>-6,
     stick:L?R.every(r=>cx(r)<=jz.x0+4):R.every(r=>cx(r)>=jz.x1-4),hudBot:g.dbg.COMBAT_HUD_BOT(),topCard:Math.min(...R.map(r=>cy(r)-r.h/2)),minx:Math.min(...R.map(r=>cx(r)-r.w/2)),maxx:Math.max(...R.map(r=>cx(r)+r.w/2)),atkx:a.x,vw:z.VW};});
 let g1=await geo();
 ok(g1.n===4&&g1.onscreen&&g1.clear&&g1.stick,'right-handed: 4-card fan on screen, around SHOT, clear of the stick zone ('+JSON.stringify(g1)+')');
 await E(()=>{window.__game.B.texts.length=0;});await sleep(150);
 await shot('landscape-combat.png');
 // aim mode banner + selected frame in landscape
 await E(()=>{__game.dbg.expCardTap(0);});await sleep(250);await shot('landscape-aim.png');await E(()=>{__game.dbg.expCancel();});
 // ---- left-handed mirror
 await E(()=>{__game.dbg.setToggle('lefty');});await sleep(400);
 l=await L();let g2=await geo();
 ok(l.atk.x<l.z.VW/2&&l.jz.x0>l.z.VW*.5,'left-handed: SHOT bottom-left, stick on the right ('+JSON.stringify({atk:l.atk.x,jz:l.jz.x0})+')');
 ok(g2.n===4&&g2.onscreen&&g2.clear&&g2.stick,'left-handed: fan mirrored, on screen and clear ('+JSON.stringify(g2)+')');
 await shot('landscape-lefty.png');
 await E(()=>{__game.dbg.setToggle('lefty');__game.dbg.endFight();});await sleep(300);
 // ---- quest tracker + minimap don't collide with each other or the pause button (overworld)
 const hud=await E(()=>{const g=__game,d=g.dbg,z=g.size;return {trk:d.trkVisible?d.trkVisible():null,trkR:d.TRKR||null,mini:d.MINIR||null,pause:{x:g.btn.pause.x,y:g.btn.pause.y,r:g.btn.pause.r},VW:z.VW,VH:z.VH};});
 ok(hud.VW===844&&hud.VH===390,'logical size is 844x390');
 // ---- town screenshot + dialog + pause menu fit
 await E(()=>{const g=__game;g.tp(12,34);g.P.x=12*32+16;g.P.y=34*32+28;});await sleep(500);await shot('landscape-town.png');
 await E(()=>{const g=__game;g.state='paused';});await sleep(400);await shot('landscape-pause.png');await E(()=>{__game.state='play';});
 // ---- portrait: the rotate overlay
 await pg.setViewport({width:390,height:844,deviceScaleFactor:3,isMobile:true,hasTouch:true,isLandscape:false});await sleep(600);
 const po=await E(()=>{const r=document.getElementById('rotate');const cs=getComputedStyle(r);return {disp:cs.display,txt:r.innerText.trim().slice(0,60),paused:!!window.__ROTATE_BLOCK};});
 ok(po.disp!=='none'&&/rotate/i.test(po.txt),'portrait phone: rotate overlay is shown ('+JSON.stringify(po)+')');
 await shot('landscape-rotate-overlay.png');
 const t0=await E(()=>__game.P.x+','+__game.P.y);await E(()=>{__game.press&&__game.press('KeyD');});await sleep(400);
 await pg.setViewport({width:844,height:390,deviceScaleFactor:3,isMobile:true,hasTouch:true,isLandscape:true});await sleep(600);
 ok(await E(()=>getComputedStyle(document.getElementById('rotate')).display)==='none','back in landscape: overlay gone and the game is playable again');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
