// M52: group tactics - with 3+ enemies engaged they spread out (min spacing), melee take front/flank slots round the hero, ranged keep distance behind the melee line,
// attacks are staggered; bosses keep their own mechanics.  Screen store/group-formation.png (landscape).  node tests/ms52.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms52',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.TRK.open=false;
   for(const e of g.enemies)if(e.alive){e.mt=1e9;e.lk=1e9;}});
 // an open meadow: a 15x13 tile patch with nothing solid in it
 const spot=await E(()=>{const g=__game,d=g.dbg;let best=0,bp=null;for(let ty=10;ty<150;ty++)for(let tx=6;tx<58;tx++){if(d.zoneOfPx(ty*32)!=='ow'||g.townDbg().inTownPx(tx*32,ty*32))continue;
   if(d.solidTile(tx,ty)||d.wallT(tx*32+16,ty*32+16))continue;let k=0;for(let y=ty-4;y<=ty+4;y++)for(let x=tx-5;x<=tx+5;x++)if(!d.solidTile(x,y)&&!d.wallT(x*32+16,y*32+16))k++;if(k>best){best=k;bp={tx,ty,k};}}return bp;});
 ok(!!spot,'found an open meadow '+JSON.stringify(spot));
 const setup=(types,hero)=>E((types,sp,hero)=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.tp(sp.tx,sp.ty);g.P.x=sp.tx*32+16;g.P.y=sp.ty*32+28;g.P.grace=0;g.snapCam&&g.snapCam();
   const used=new Set(),list=[];for(const o of g.enemies)if(!o.dying){o.alive=false;o.engaged=false;}
   types.forEach(([t,tier],i)=>{const e=g.enemies.find(q=>q.type===t&&(t==='dragon'||!q.def.boss)&&!used.has(q));used.add(e);const a=-1.1+i*.31,r=84+(i%3)*14;
     e.alive=true;e.dying=false;e.gdie=false;e.engaged=false;e.x=e.hx=g.P.x+Math.cos(a)*r;e.y=e.hy=g.P.y+Math.sin(a)*r+0;e.hp=e.maxhp=e.mhp=9e4;e.calm=0;if(t==='dragon')e.terr=null;list.push(e);});
   d.startEncounter(list[0],true);const B=g.B;B.ens.filter(e=>!list.includes(e)).forEach(e=>{e.engaged=false;e.alive=false;});B.ens=B.ens.filter(e=>list.includes(e));for(const e of list.slice(1)){if(!B.ens.includes(e)){d.initCombatEnemy(e,0);B.ens.push(e);}}
   B.phase='fight';B.t=0;B.dim=1;B.ens.forEach(x=>{x.joinT=0;x.atkCd=1.2+Math.random()*1.5;});window.__list=list;window.__maxWind={m:0,r:0,all:0};B.noiseT=1e9;B.proxT=1e9;},types,spot,hero);
 const poll=()=>E(()=>{const g=__game,d=g.dbg,B=g.B;if(!B)return null;B.inv=999;g.P.hp=d.maxHp();const p=g.P,hc={x:p.x,y:p.y-12};
   const L=window.__list.filter(e=>!e.dying),ps=[];let minSp=1e9;
   for(let i=0;i<L.length;i++)for(let j=i+1;j<L.length;j++)minSp=Math.min(minSp,Math.hypot(L[i].x-L[j].x,L[i].y-L[j].y));
   const mel=L.filter(e=>!d.isRangedT(e.type)),rng=L.filter(e=>d.isRangedT(e.type));
   const wd=B.ens.filter(e=>e.st==='windup'),w=window.__maxWind;w.all=Math.max(w.all,wd.length);w.m=Math.max(w.m,wd.filter(e=>!d.isRangedT(e.type)).length);w.r=Math.max(w.r,wd.filter(e=>d.isRangedT(e.type)).length);
   const dist=e=>Math.hypot(e.x-hc.x,e.y-12-hc.y),ang=e=>Math.atan2(e.y-12-hc.y,e.x-hc.x);
   return {minSp,mel:mel.map(e=>Math.round(dist(e))),rng:rng.map(e=>({t:e.type,d:Math.round(dist(e)),lo:d.BAND[e.type][0]})),angs:mel.map(e=>ang(e)),form:B.form&&B.form.n,hp:g.P.hp};});
 // ---- 1. a 7-strong mixed pack, hero standing still
 await setup([['knight'],['knight'],['slime'],['slime'],['knight'],['goblin'],['goblin']]);
 let first=null,worst=1e9,worstR=1e9,last=null;
 for(let i=0;i<75;i++){await sleep(120);const s=await poll();if(!s)break;if(i===1)first=s;if(i>=45){worst=Math.min(worst,s.minSp);for(const r of s.rng)worstR=Math.min(worstR,r.d-r.lo);}last=s;}
 ok(first&&first.form>=3,'formation active with 3+ enemies (n='+(first&&first.form)+')');
 ok(worst>=30,'after settling, no two enemies closer than 30px (min '+Math.round(worst)+'px)');
 ok(worstR>=-6,'ranged units stay at/above their preferred distance (worst margin '+Math.round(worstR)+'px; '+JSON.stringify(last.rng)+')');
 const mm=Math.max(...last.mel);ok(last.rng.every(r=>r.d>mm+10),'ranged stay behind the melee line (melee max '+mm+'px, ranged '+JSON.stringify(last.rng.map(r=>r.d))+')');
 // melee spread: angular coverage round the hero - some on the sides / behind
 const as=last.angs.slice().sort((a,b)=>a-b);let gapMax=0;for(let i=0;i<as.length;i++){const nx=i+1<as.length?as[i+1]:as[0]+2*Math.PI;gapMax=Math.max(gapMax,nx-as[i]);}
 const cover=2*Math.PI-gapMax;ok(cover>2.0,'melee units spread round the hero (angular coverage '+cover.toFixed(2)+' rad of 6.28)');
 const w=await E(()=>window.__maxWind);ok(w.m<=1&&w.r<=1&&w.all<=2,'attacks staggered: max simultaneous windups melee '+w.m+', ranged '+w.r+', total '+w.all);
 await shot('group-formation.png');
 // ---- 2. hero rushes a ranged unit: it kites back instead of standing
 const kite=await E(async()=>{const g=__game,B=g.B,r=window.__list.find(e=>e.type==='goblin'&&!e.dying);r.atkCd=99;const p=g.P;B.inv=999;
   // teleport the hero close to it (inside its minimum range)
   p.x=r.x-34;p.y=r.y+8;const d0=Math.hypot(r.x-p.x,r.y-12-(p.y-12));await new Promise(rs=>setTimeout(rs,900));const d1=Math.hypot(r.x-p.x,r.y-p.y);return {d0:Math.round(d0),d1:Math.round(d1)};});
 ok(kite.d1>kite.d0+8,'a ranged unit backs away when the hero closes in ('+kite.d0+' -> '+kite.d1+'px)');
 // ---- 3. only 2 enemies: since t133u they pincer the hero from two sides (formation slots)
 await setup([['knight'],['slime']]);await sleep(1500);
 const two=await E(()=>({n:__game.B.form&&__game.B.form.n,slots:__game.B.ens.filter(e=>e.slot).length,t:__game.B.ens.map(e=>e.type+(e.alive?'':'!')+(e.dying?'d':'')),listN:window.__list.length}));
 ok(two.slots===2,'with 2 enemies both take flanking slots ('+JSON.stringify(two)+')');
 // ---- 4. a boss keeps its own mechanics: not slotted; its adds still spread
 await setup([['dragon'],['knight'],['knight'],['slime'],['goblin']]);await sleep(3500);
 const bs=await E(()=>{const g=__game,B=g.B;return B&&B.ens.filter(e=>!e.dying).map(e=>({t:e.type,slot:!!e.slot,boss:!!e.def.boss,form:B.form&&B.form.n}));});
 ok(bs&&bs.filter(e=>e.boss).every(e=>!e.slot)&&bs.filter(e=>!e.boss).every(e=>e.slot),'a boss is never slotted; its 4 adds are ('+JSON.stringify(bs&&bs.map(e=>e.t+(e.slot?'*':'')))+')');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
