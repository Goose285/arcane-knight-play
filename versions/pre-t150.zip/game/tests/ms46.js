// M46: World Map in landscape = big map column (frame hugs the picture, YOU + destination aligned) + stone list beside it.  node tests/ms46.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms46',{town:true,device:'iPhone 12 landscape'});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.lv=4;g.P.hp=d.maxHp();});
 await E(()=>{const g=__game,d=g.dbg;g.tp(12,35);g.P.x=12*32+16;g.P.y=35*32+10;g.P.grace=99;d.activateWay('road');d.activateWay('forest');d.activateWay('village');});
 // ---- opened from the pause menu
 await E(()=>{const g=__game,d=g.dbg;g.state='paused';d.pauseOpenPage('main');});await sleep(250);
 await E(()=>{const d=__game.dbg;d.PAUSE_ITEMS.find(i=>i.k==='KeyF').act();});await sleep(300);
 const idx=await E(()=>__game.dbg.WAYSTONES.findIndex(w=>w.id==='road'));
 await E(i=>{__game.dbg.UI.sel=i;},idx);await sleep(400);
 const m=await E(()=>{const g=__game,d=g.dbg,sz=g.size;const mz=d.MINI?d.MINI.ow:null;return {mode:d.UI.mode,info:d.UI.mapInfo,VW:sz.VW,VH:sz.VH,mapW:d.UI.mapW,rects:d.UI.rects.filter(r=>/^travel:/.test(r.tag||'')).map(r=>({x:r.x,w:r.w,y:r.y}))};});
 ok(m.mode==='travel','pause > World Map opens the travel screen');
 ok(m.info&&m.info.dest==='road'&&m.info.zone===m.info.here,'destination highlighted on the area map '+JSON.stringify(m.info));
 if(m.VW>=m.VH*1.4){
  ok(m.mapW>=m.VH*.7,'landscape: the map column is large ('+m.mapW+'px wide on a '+m.VW+'x'+m.VH+' screen)');
  ok(m.rects.length>=5&&m.rects.every(r=>r.x>m.mapW),'the stone list (TRAVEL buttons) sits to the right of the map');
 }
 await shot('world-map-wide.png');
 // map frame vs picture: no big dead space inside the frame
 const px=await E(()=>{const c=document.getElementById('c'),x=c.getContext('2d'),k=c.width/__game.size.VW,W=__game.dbg.UI.mapW;const y=Math.round((__game.dbg.UI.top+Math.round((__game.dbg.UI.bot-__game.dbg.UI.top)/2))*k);
   const x0=Math.round(((__game.size.VW-Math.min(__game.size.VW-14,820))/2)*k);const row=x.getImageData(x0,y,Math.round(W*k),1).data;let dark=0,n=row.length/4;for(let i=0;i<n;i++){const o=i*4;if(row[o]+row[o+1]+row[o+2]<70)dark++;}return dark/n;});
 ok(px<.3,'little dark empty space across the map frame ('+Math.round(px*100)+'% dark)');
 await E(()=>{__game.dbg.closeUI();});
 // ---- opened from a waystone (state play)
 await E(()=>{const g=__game,d=g.dbg;g.state='play';d.openTravel();});await sleep(300);
 await E(i=>{__game.dbg.UI.sel=i;},idx);await sleep(300);
 const m2=await E(()=>({mode:__game.dbg.UI.mode,mw:__game.dbg.UI.mapW,info:__game.dbg.UI.mapInfo}));
 ok(m2.mode==='travel'&&m2.info&&m2.info.dest==='road','waystone menu uses the same layout ('+JSON.stringify(m2)+')');
 await E(()=>{__game.dbg.closeUI();});
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
