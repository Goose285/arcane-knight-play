// M19: day / sunset / night art direction.  node tests/ms19.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms19');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.hp=d.maxHp();g.P.grace=9999;});
 await sleep(300);
 // ---- layout: pond, campfire, lanterns exist; walkable layout kept
 const a=await E(()=>{const g=__game,d=g.dbg,T=d.T;const P0=d.VILLAGE_POND;let water=0,rim=0;for(let y=P0.y0;y<=P0.y1;y++)for(let x=P0.x0;x<=P0.x1;x++){if(d.map[y][x]===T.PW)water++;else if(d.map[y][x]===T.PR)rim++;}
   let ln=0;for(const [x,y] of d.VILLAGE_LANTERNS)if(d.map[y][x]===T.LN)ln++;
   const fr=d.map[d.VILLAGE_FIRE.y][d.VILLAGE_FIRE.x]===T.FR;
   const sol=[T.LN,T.FR,T.PW,T.PR].every(t=>d.SOLIDS.has(t));
   const TS=32,bad=g.npcs.filter(n=>n.y<48*TS&&d.solidTile(Math.floor(n.x/TS),Math.floor(n.y/TS))).map(n=>n.name);
   const reachV=d.reach[37][5]&&d.reach[44][20]&&d.reach[41][14]&&d.reach[37][21]&&d.reach[27][15];
   let blossom=0;for(let y=0;y<46;y++)for(let x=0;x<64;x++)if(d.map[y][x]===T.T&&d.treeKindOf(x,y)==='blossom')blossom++;
   return {water,rim,ln,fr,sol,bad,reachV,blossom};});
 ok(a.water===4&&a.rim===12,'stone-rimmed pond: 4 water + 12 rim ('+a.water+'/'+a.rim+')');
 ok(a.fr,'campfire beside the pond');ok(a.ln>=7,'lanterns along the village paths ('+a.ln+')');ok(a.sol,'new props are solid');
 ok(a.bad.length===0,'no NPC inside a prop ('+a.bad+')');ok(a.reachV,'village still reachable (roads, houses, pond side)');
 ok(a.blossom>20,'purple-blossom trees mixed in ('+a.blossom+')');
 // ---- grade blends smoothly over the cycle
 const gr=await E(()=>{const d=__game.dbg,out=[];for(let i=0;i<=200;i++){const t=i/200;d.setTimeOfDay(t);const G=d.dayGrade();out.push([G.s,G.n,G.lamp,G.day]);}
   let maxJump=0;for(let i=1;i<out.length;i++)for(let k=0;k<4;k++)maxJump=Math.max(maxJump,Math.abs(out[i][k]-out[i-1][k]));
   d.setTimeOfDay(.4);return {noon:out[100],dusk:out[158],mid:out[0],maxJump,lampDay:out[100][2]};});
 ok(gr.maxJump<.25,'grade changes smoothly over 200 steps of the cycle (max step '+gr.maxJump.toFixed(2)+')');
 ok(gr.noon[3]>.95&&gr.noon[2]<.01,'noon = full day, lamps off');ok(gr.dusk[0]>.5,'sunset glow near t=.79 ('+gr.dusk[0].toFixed(2)+')');ok(gr.mid[1]>.99&&gr.mid[2]>.99,'midnight = full night, lamps on');
 // ---- drawing: lights pick up lanterns + campfire; window glow starts at sunset
 const shotAt=async(t,name)=>{await E(t0=>{const g=__game,d=g.dbg;d.setTimeOfDay(t0);g.tp(13,33);d.toasts.length=0;d.TRK.open=false;},t);await sleep(4200);await E(()=>{__game.dbg.toasts.length=0;});await shot(name);};
 await shotAt(.40,'cycle-day.png');
 await shotAt(.79,'cycle-sunset.png');
 await shotAt(.0,'cycle-night.png');
 // performance sanity: a frame stays cheap (draw 60 frames of the busy forest at night)
 const ms=await E(()=>{const g=__game,d=g.dbg;d.setTimeOfDay(.97);g.tp(46,30);const t0=performance.now();for(let i=0;i<60;i++)__game.render();return (performance.now()-t0)/60;});
 ok(ms<60,'forest night frame renders in '+ms.toFixed(1)+' ms (headless CPU)');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
