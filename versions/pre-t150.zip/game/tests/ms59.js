// M59 (t138u): animations, soft SFX, fences, church, house variety, concept pause menu, town escape, bed sleep, poison, fishmonger-only selling.
// node tests/ms59.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms59',{town:true,grow:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t138/.test(tags),'backup tag backup-pre-t138 exists');
 await E(()=>__game.dbg.startFromTitle());await sleep(700);
 // soft sfx
 let s=await E(()=>{const k=__game.t138();return {lp:k.SFX_SOFT.lp,vol:k.SFX_SOFT.vol,sq:k.softWave('square'),saw:k.softWave('sawtooth'),sin:k.softWave('sine')};});
 ok(s.lp<=2500&&s.vol<1&&s.sq==='triangle'&&s.saw==='triangle'&&s.sin==='sine','soft SFX: low-pass '+s.lp+'Hz, vol '+s.vol+', square/saw -> triangle');
 // fishmonger-only selling
 s=await E(()=>{const k=__game.t138(),id=Object.keys(k.FISH_BY).find(i=>!k.FISH_BY[i].junk);k.FSH.fish[id]=3;const g0=k.P.gold;k.FSH_SHOP.on=false;const a=k.sellFish(id,false);k.FSH_SHOP.on=true;const b=k.sellFish(id,false);k.FSH_SHOP.on=false;return {a,b,gold:k.P.gold-g0};});
 ok(s.a===0&&s.b>0&&s.gold===s.b,'fish only sell at the fishmonger (field '+s.a+'g, shop '+s.b+'g)');
 // poison
 s=await E(()=>{const k=__game.t138(),M=Math.random;Math.random=()=>0;const r={};
   r.slime=k.poisonTry({def:{name:'Slime'},type:'slime',x:0,y:0});
   r.toad=k.poisonTry({def:{name:'Bog Toad'},type:'toad',x:0,y:0});const fe={def:{name:'Witch'},type:'witch'};k.poisonCure();r.w1=k.poisonTry(fe);k.poisonCure();r.w2=k.poisonTry(fe);
   Math.random=M;k.poisonCure();k.poisonApply(5,'t');k.P.hp=k.maxHp();const h0=k.P.hp;for(let i=0;i<30;i++)k.updatePoison(.1);r.lost=h0-k.P.hp;r.on=k.PSN.t>0;
   k.P.hp=2;for(let i=0;i<40;i++)k.updatePoison(.1);r.floor=k.P.hp;k.poisonCure();r.cured=k.PSN.t===0;r.list=Object.keys(k.POISONERS);k.P.hp=k.maxHp();return r;});
 ok(!s.slime&&s.toad,'only listed monsters poison (slime no, toad yes)');
 ok(s.w1&&!s.w2,'per-monster poison cooldown');
 ok(s.on&&s.lost>0&&s.floor>=1&&s.cured,'poison ticks ('+s.lost+' HP/3s), never kills (floor '+s.floor+'), cure works');
 const src=fs.readFileSync(__dirname+'/../index.html','utf8');
 ok(/poisonCure\(\)/.test(src.slice(src.indexOf('function bedSleep'),src.indexOf('function bedSleep')+600))&&(src.match(/poisonCure\(\)/g)||[]).length>=4,'heal card, Inn and bed cure poison');
 // bed
 s=await E(async()=>{const k=__game.t138();k.DAY.t=.85;k.P.hp=5;const ls0=JSON.stringify(localStorage);k.poisonApply(9,'x');const st=k.bedSleep();await new Promise(r=>setTimeout(r,3500));return {st,hp:k.P.hp,max:k.maxHp(),t:k.DAY.t,psn:k.PSN.t,saved:JSON.stringify(localStorage)!==ls0};});
 ok(s.st&&s.hp===s.max&&Math.abs(s.t-.3)<.05&&s.psn===0&&s.saved,'bed: sleep to morning (t='+s.t.toFixed(2)+'), full HP, poison cured, saved');
 // town escape
 s=await E(()=>{const k=__game.t138();const e=k.enemies.find(e=>e.alive);if(!e)return null;e.chasing=true;const n0=k.TOWN_ESC.n;k.updateTownEscape();return {ret:!!e.ret,chasing:e.chasing,n:k.TOWN_ESC.n-n0,B:k.getB()};});
 ok(s&&s.ret&&!s.chasing&&s.n===1&&!s.B,'in town: chasers give up and walk home, no battle');
 // animations
 s=await E(()=>{const k=__game.t138(),out={};for(const ty of ['slime','wolf','bat','toad']){const e={type:ty,bob:0,mode:'walk'};const a=k.enemyAnim(e,false);e.bob=.37;const b=k.enemyAnim(e,false);out[ty]=JSON.stringify(a)!==JSON.stringify(b);}
   const p=k.playerAnim();out.p=p&&typeof p.sx==='number'&&'pose' in p;return out;});
 ok(s.slime&&s.wolf&&s.bat&&s.toad,'enemy idle/walk cycles animate');ok(s.p,'player pose anim');
 // fences / church / houses
 s=await E(()=>{const k=__game.t138(),st=new Set();for(let y=0;y<k.map.length;y++)for(let x=0;x<k.map[0].length;x++)if(k.map[y][x]===k.T.R){const h=k.houseStyle(x,y);h&&st.add(h);}
   let fv=new Set();for(let y=0;y<k.map.length&&fv.size<3;y++)for(let x=0;x<k.map[0].length;x++)if(k.map[y][x]===k.T.N){fv.add(k.XTILE_FN[k.T.N](x,y,0));}
   return {styles:[...st],fn:!!k.XTILE_FN[k.T.N],fv:fv.size,ch:!!(k.SP.bellTower&&k.SP.chAltar&&k.SP.chDais)};});
 ok(s.fn&&s.fv>=2,'auto-joining fence variants: '+s.fv);ok(s.ch,'church belfry, dais, altar sprites');
 ok(s.styles.length>=4,'house styles: '+s.styles.join(','));
 // menu
 s=await E(async()=>{const k=__game.t138();k.setState('paused');await new Promise(r=>setTimeout(r,250));const ids=k.pauseRects.map(r=>r.e.id);k.PM.tab='settings';await new Promise(r=>setTimeout(r,200));const s2=k.pauseRects.map(r=>r.e.id);k.setState('play');return {ids,s2};});
 ok(['character','cards','inventory','journal','world','skills','settings','resume','home','quit'].every(i=>s.ids.includes(i)),'concept menu: icon tabs + pill buttons');
 ok(['master-','master+'].every(i=>s.s2.includes(i)),'settings sliders');
 ok(errs.length===0,'no page errors '+errs.slice(0,2));
 await finish();
})();
