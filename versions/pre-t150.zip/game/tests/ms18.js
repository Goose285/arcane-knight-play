// M18: tree variety.  node tests/ms18.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms18');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 const setup=async()=>E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.hp=d.maxHp();g.P.grace=9999;});
 await setup();await sleep(300);
 const look=async(tx,ty,name)=>{await E((x,y)=>{__game.tp(x,y);__game.dbg.toasts.length=0;__game.dbg.TRK.open=false;},tx,ty);await sleep(1300);await E(()=>{__game.dbg.toasts.length=0;});await shot(name);};

 // ---- species spread per zone: count the distinct sprites actually drawn
 const a=await E(()=>{const g=__game,d=g.dbg,out={};const zs={ow:[0,0,64,46],snow:[2,91,62,118],swamp:[2,125,62,152],desert:[2,159,62,186]};
   for(const z in zs){const [x0,y0,x1,y1]=zs[z],set=new Set();let trees=0;for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++){const id=g.dbg.map[y][x];if([d.T.T,d.T.PN,d.T.RE,d.T.PM,d.T.AC,d.T.BU,d.T.ST].includes(id)){set.add(g.treeSpriteOf(id,x,y));trees++;}}out[z]={n:trees,uniq:set.size};}
   return out;});
 ok(a.ow.uniq>=60,'overworld uses many distinct tree sprites ('+a.ow.uniq+' from '+a.ow.n+')');
 ok(a.snow.uniq>=15,'Frosthowl has varied snowy trees ('+a.snow.uniq+')');
 ok(a.swamp.uniq>=15,'Mirewood has varied swamp trees ('+a.swamp.uniq+')');
 ok(a.desert.uniq>=15&&a.desert.n>20,'Sundered Ruins has palms/acacias ('+a.desert.uniq+', '+a.desert.n+')');
 const k=await E(()=>{const g=__game,d=g.dbg,kinds={};for(let y=0;y<46;y++)for(let x=0;x<64;x++)if(g.dbg.map[y][x]===d.T.T){const kd=d.treeKindOf(x,y);kinds[kd]=(kinds[kd]||0)+1;}return kinds;});
 for(const s of ['oak','pine','fir','birch','willow','maple','apple','dead'])ok((k[s]||0)>0,'overworld has '+s+' trees ('+(k[s]||0)+')');
 ok(Math.max(...Object.values(k))/Object.values(k).reduce((p,c)=>p+c,0)<.35,'no single species dominates ('+JSON.stringify(k)+')');
 // willows sit by the river
 const w=await E(()=>{const g=__game,d=g.dbg;let n=0,near=0;for(let y=14;y<46;y++)for(let x=0;x<64;x++)if(g.dbg.map[y][x]===d.T.T&&d.treeKindOf(x,y)==='willow'){n++;let ok=false;for(let dy=-2;dy<=2;dy++)for(let dx=-2;dx<=2;dx++)if(g.dbg.map[y+dy]&&g.dbg.map[y+dy][x+dx]===d.T.W)ok=true;if(ok)near++;}return {n,near};});
 ok(w.n>0&&w.n===w.near,'every willow stands next to water ('+w.near+'/'+w.n+')');
 // collision: solid trees block, clutter does not
 const c=await E(()=>{const g=__game,d=g.dbg;let pm=0;for(let y=159;y<187;y++)for(let x=2;x<62;x++)if(d.map[y][x]===d.T.PM||d.map[y][x]===d.T.AC)pm++;
   const s=d.SOLIDS;return {solidPM:s.has(d.T.PM)&&s.has(d.T.AC)&&s.has(d.T.T)&&s.has(d.T.PN)&&s.has(d.T.RE),clutterWalk:!s.has(d.T.BU)&&!s.has(d.T.ST),pm};});
 ok(c.solidPM,'trees (incl. palm/acacia) are solid');ok(c.clutterWalk,'bushes / stumps are walkable clutter');ok(c.pm>10,'palms + acacias placed ('+c.pm+')');
 // pathing still works: spawn can reach the castle gate, every zone arrival, the chapel door, and all four quest-era NPCs
 const p=await E(()=>{const g=__game,d=g.dbg,TS=32;const out={};
   out.castle=g.dbg.reach[12][31]||g.dbg.reach[13][31];out.chapel=d.reach[37][21];out.forestEdge=d.reach[30][50];
   let nrch=0;for(const n of g.npcs){if(n.y>48*TS)continue;const tx=Math.floor(n.x/TS),ty=Math.floor(n.y/TS);if(!d.reach[ty]||!d.reach[ty][tx])nrch++;}
   out.npcsOff=nrch;
   const zr=id=>{const z=d.ZONES[id],y0=z.y0,seen=Array.from({length:32},()=>new Array(64).fill(false)),st=[[5,26]];seen[26][5]=true;let hit=0;
     while(st.length){const [x,y]=st.pop();if(x===60&&y===8)hit=1;if(x>=46&&y<=9)hit=1;for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>63||ny>31||seen[ny][nx])continue;if(d.solidTile(nx,ny+y0))continue;seen[ny][nx]=true;st.push([nx,ny]);}}return hit;};
   out.snow=zr('snow');out.swamp=zr('swamp');out.desert=zr('desert');return out;});
 ok(p.castle&&p.chapel&&p.forestEdge,'overworld is still connected (castle/chapel/forest)');ok(p.npcsOff===0,'all NPCs still reachable ('+p.npcsOff+' not)');
 ok(p.snow&&p.swamp&&p.desert,'each zone still connects arrival -> boss arena');
 // the player is really blocked by a palm
 const bl=await E(()=>{const g=__game,d=g.dbg,TS=32;let t=null;for(let y=170;y<180&&!t;y++)for(let x=14;x<40;x++)if(d.map[y][x]===d.T.PM&&!d.solidTile(x-1,y)){t={x,y};break;}if(!t)return {none:1};
   g.tp(t.x-1,t.y);const x0=g.P.x;for(let i=0;i<60;i++)g.keys['ArrowRight']=true;return {t,x0};});
 ok(!bl.none,'found a palm to test against');
 // cheap draw: the cache stays small
 const cs=await E(()=>__game.treeCacheSize());
 ok(cs>20&&cs<900,'sprite cache stays small ('+cs+')');
 const sp=await E(()=>{const g=__game,d=g.dbg;return g.npcs.filter(n=>n.y<48*32&&d.solidTile(Math.floor(n.x/32),Math.floor(n.y/32))).map(n=>n.name);});
 ok(sp.length===0,'no NPC stands inside a tree/solid tile ('+sp+')');
 // screenshots
 await look(11,43,'trees-village.png');
 await look(48,32,'trees-whisperwood.png');
 await look(30,116,'trees-frosthowl.png');
 await look(30,150,'trees-mirewood.png');
 await look(30,184,'trees-sundered-ruins.png');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
