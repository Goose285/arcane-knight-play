// M27: list rows only act on their button; pets fight beside you (overworld + combat, every pet); quest tracker stays up through fights;
// quest arrow on the minimap / world map (cross-zone via exits); 7% card hand.  node tests/ms27.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,tap,shot,finish,MOBILE}=await boot('ms27');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=true;g.DLG=null;g.state='play';d.endFight();g.P.hp=d.maxHp();g.P.gold=9999;});
 const clickAt=async(x,y)=>{const p=await E((x,y)=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+x/z.VW*c.width,y:c.top+y/z.VH*c.height};},x,y);if(MOBILE)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(200);};
 const rowBody=(pred)=>E(()=>{const U=__game.dbg.UI;const rs=U.rects.filter(q=>q.sel!=null&&!q.tag&&q.w>200&&q.y>=U.top&&q.y+q.h<=U.bot);return rs.map(q=>({x:q.x+24,y:q.y+q.h/2,sel:q.sel}));});
 // ===== A. list rows: tapping the row body only selects; the button acts =====
 await E(()=>{const d=__game.dbg;d.openUIMode('pets','play');});await sleep(300);
 let rows=await rowBody();ok(rows.length>=2,'pet rows are listed ('+rows.length+')');
 const g0=await E(()=>__game.P.gold);
 await clickAt(rows[0].x,rows[0].y);await clickAt(rows[1].x,rows[1].y);
 let st=await E(()=>({own:Object.keys(__game.dbg.PET.owned).filter(k=>__game.dbg.PET.owned[k]),act:__game.dbg.PET.active,gold:__game.P.gold,sel:__game.dbg.UI.sel}));
 ok(st.own.length===0&&!st.act&&st.gold===g0,'tapping pet rows does NOT adopt / spend gold');ok(st.sel===1,'...but it highlights the tapped row (sel='+st.sel+')');
 ok(await tap('pet:cinder'),'ADOPT button found');st=await E(()=>({own:!!__game.dbg.PET.owned.cinder,gold:__game.P.gold}));ok(st.own&&st.gold<g0,'the ADOPT button adopts and charges');
 rows=await rowBody();const act0=await E(()=>__game.dbg.PET.active);await clickAt(rows[0].x,rows[0].y);
 ok(await E(a=>__game.dbg.PET.active===a,act0),'tapping an owned pet row does not summon / rest it');
 await tap('pet:cinder');ok(await E(()=>__game.dbg.PET.active)!==act0,'the SUMMON/REST button toggles it');
 await E(()=>{__game.dbg.closeUI();});
 await E(()=>{const d=__game.dbg;d.openUIMode('shop','play');});await sleep(300);
 rows=await rowBody();const gs=await E(()=>({g:__game.P.gold,col:JSON.stringify(__game.dbg.getCol())}));
 for(const r of rows.slice(0,4))await clickAt(r.x,r.y);
 ok(await E(s=>__game.P.gold===s.g&&JSON.stringify(__game.dbg.getCol())===s.col,gs),'tapping shop rows buys nothing ('+rows.length+' rows)');
 const buyTag=await E(()=>{const r=__game.dbg.UI.rects.find(q=>/^buy:/.test(q.tag||''));return r&&r.tag;});
 if(buyTag){await tap(buyTag);ok(await E(g=>__game.P.gold<g,gs.g),'the BUY button buys');}
 await E(()=>{__game.dbg.closeUI();});await sleep(200);
 const watch=(secs,id)=>E(id=>{const d=__game.dbg;clearInterval(window.__iv);const o=window.__w={shots:new Set(),heal:0,chill:0,far:0,alive:true};let last=__game.P.hp;
   window.__iv=setInterval(()=>{const B=__game.B;if(B){B.inv=Math.max(B.inv||0,5);for(const s of B.shots)if(s.kind==='pet')o.shots.add(s);}for(const s of d.WS)if(s.kind==='pet')o.shots.add(s);
     if(__game.P.hp>last+.5)o.heal++;last=__game.P.hp;if(window.__e&&window.__e.chill>0)o.chill++;o.far=Math.max(o.far,Math.hypot(d.PET.x-__game.P.x,d.PET.y-__game.P.y));if(d.PET.active!==id&&id)o.alive=false;},40);},id).then(()=>sleep(secs*1000)).then(()=>E(()=>{clearInterval(window.__iv);const o=window.__w;return {shots:o.shots.size,heal:o.heal,chill:o.chill,far:o.far,alive:o.alive,B:!!__game.B};}));
 // ===== B. every pet fights in combat =====
 const setupFight=(id)=>E(id=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);g.P.grace=0;
   g.enemies.forEach(e=>{e.alive=true;e.dying=false;e.engaged=false;e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=1e9;e.lk=1e9;});
   d.PET_IDS.forEach(k=>d.PET.owned[k]=true);d.PET.active=id;d.PET.bond[id]=0;
   g.tp(12,26);g.P.x=12*32+16;g.P.y=26*32+28;g.P.aim=0;g.P.dir='r';
   const e=g.enemies.find(o=>o.type==='knight');e.x=e.hx=17*32;e.y=e.hy=26*32+28;e.fa=e.ta=Math.PI;e.mode='look';e.mt=e.lk=1e9;e.hp=e.maxhp=e.mhp=99999;window.__e=e;
   d.petSnap&&d.petSnap();d.PET.cd=0;d.PET.bcd=1e9;g.P.hp=d.maxHp()*(id==='moth'?.5:1);window.__hp0=g.P.hp;window.__pet=id;},id);
 const names={cinder:'ember',wisp:'pfrost',moth:'spark',pebblin:'pebble'};
 for(const id of ['cinder','wisp','moth','pebblin']){
   await setupFight(id);
   await E(()=>{const g=__game;g.dbg.startEncounter(window.__e,true);g.P.grace=0;});
   const seen=await watch(9,id);
   if(id==='moth')ok(seen.heal>=1&&seen.alive,'Gloam Moth mends the hero during a fight (heals '+seen.heal+')');
   else ok(seen.shots>=2&&seen.alive,id+' fires at the enemy during a fight ('+seen.shots+' shots)');
   if(id==='wisp')ok(seen.chill>0,'Rime Wisp frost chills the target');
   ok(seen.far<260,id+' stays near the hero during a fight (max '+Math.round(seen.far)+' px)');
 }
 // moth with a full-health hero still contributes (sparks the enemy instead of idling)
 await setupFight('moth');await E(()=>{const g=__game;g.P.hp=g.dbg.maxHp();g.dbg.startEncounter(window.__e,true);g.P.grace=0;});
 const spk=(await watch(7,null)).shots;
 ok(spk>=1,'a moth with nothing to heal sparks the enemy ('+spk+')');
 // ===== C. overworld: the pet joins when you shoot =====
 for(const id of ['cinder','wisp','moth','pebblin']){
   await setupFight(id);await E(()=>{const g=__game,e=window.__e;e.x=e.hx=15*32;e.fa=e.ta=0;e.hp=e.maxhp=e.mhp=99999;g.P.hp=Math.min(g.P.hp,g.dbg.maxHp()*(window.__pet==='moth'?.5:1));g.dbg.WS.length=0;});
   await sleep(200);
   await E(id=>{window.__keep=1;},id);const wp=watch(1.4,null);await pg.keyboard.down('KeyJ');await sleep(110);await pg.keyboard.up('KeyJ');const w0=await wp;const w={pet:w0.shots,heal:w0.heal,B:w0.B};
   if(id==='moth')ok(w.heal>=1,'overworld: the moth mends a wounded hero ('+w.heal+')');
   else ok(w.pet>=1,'overworld: '+id+' shoots along with you ('+w.pet+', fight started='+w.B+')');
 }
 // pet never starts a fight on its own: idle hero, enemy nearby, nothing is fired
 await setupFight('cinder');await E(()=>{const e=window.__e;e.x=e.hx=17*32;e.fa=e.ta=0;__game.dbg.WS.length=0;});await sleep(1200);
 {const r=await E(()=>({B:!!__game.B,ws:__game.dbg.WS.map(s=>s.kind+s.own)}));ok(!r.B&&r.ws.every(k=>!/^pet/.test(k)),'an idle hero: the pet does not pick fights '+JSON.stringify(r));}
 // ===== D. quest tracker stays through fights =====
 await E(()=>{const g=__game,d=g.dbg;d.endFight();d.PET.active=null;d.resetQuests&&d.resetQuests();d.questStart('slimes');d.TRK.open=true;d.TRK.id='q:slimes';});await sleep(300);
 ok(await E(()=>__game.dbg.trkVisible()),'tracker visible while exploring');
 await setupFight('cinder');await E(()=>{const g=__game;g.dbg.PET.active=null;g.dbg.startEncounter(window.__e,true);g.P.grace=0;__game.B.inv=99;});await sleep(500);
 ok(await E(()=>!!__game.B&&__game.dbg.trkVisible()&&__game.dbg.TRK.id==='q:slimes'),'tracker is still shown (and still tracking the slime quest) during combat');
 ok(await E(()=>!!__game.dbg.TRK.rect&&__game.dbg.TRK.rect.y>__game.dbg.UI.top*0),'tracker panel is drawn in combat (rect present)');
 await shot('tracker-combat'+(MOBILE?'':'-desktop')+'.png');
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.DLG={lines:['Hello there, hero.'],i:0,name:'Elder Orin'};});await sleep(300);
 ok(await E(()=>__game.dbg.trkVisible()&&__game.dbg.TRK.id==='q:slimes'),'tracker stays up during dialogue');
 await E(()=>{__game.DLG=null;});
 // the tracked quest only changes when the player changes it or it is turned in
 await E(()=>{const d=__game.dbg;d.questStart('gel');d.questEvent('kill','slime');d.questEvent('kill','slime');d.questEvent('kill','slime');});await sleep(400);
 ok(await E(()=>__game.dbg.TRK.id==='q:slimes'),'quest ready to hand in: still tracked');
 await E(()=>{const d=__game.dbg;d.trackQuest('q:gel');});await sleep(200);ok(await E(()=>__game.dbg.TRK.id==='q:gel'),'the player can switch the tracked quest');
 await E(()=>{const d=__game.dbg;d.trackQuest('q:slimes');d.questComplete('slimes');});await sleep(400);
 ok(await E(()=>__game.dbg.TRK.id!=='q:slimes'),'turned-in quest leaves the tracker');
 // ===== E. quest arrow on the minimap / world map =====
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.DLG=null;d.questStart('slimes');d.trackQuest('q:slimes');g.tp(12,26);g.P.x=12*32+16;g.P.y=26*32+28;g.enemies.forEach(e=>{e.x=e.hx=60*32;e.y=e.hy=2*32;});
   const e=g.enemies.find(o=>o.type==='slime');e.alive=true;e.dying=false;e.x=e.hx=20*32;e.y=e.hy=26*32+28;e.mode='look';e.mt=e.lk=1e9;});await sleep(500);
 let rt=await E(()=>{const d=__game.dbg,r=d.trkRoute(d.trkCurrent());return r&&{x:r.x,y:r.y,via:r.via};});
 ok(rt&&!rt.via&&Math.abs(rt.x-(20*32))<40,'same area: the route points straight at the slime ('+JSON.stringify(rt)+')');
 await shot('quest-arrow-minimap'+(MOBILE?'':'-desktop')+'.png');
 // from the frozen pass the slime is back in the overworld: route = the exit rune
 await E(()=>{const g=__game,z=g.dbg.ZONES?g.dbg.ZONES.snow:null;const a=g.dbg.zoneArrive?g.dbg.zoneArrive('snow'):null;if(a){g.P.x=a.x;g.P.y=a.y;}});
 rt=await E(()=>{const d=__game.dbg,r=d.trkRoute(d.trkCurrent());return r&&{x:r.x,y:r.y,via:r.via,area:r.area};});
 ok(rt&&rt.via==='exit'&&rt.area==='snow','inside Frosthowl Pass the arrow points at the exit rune ('+JSON.stringify(rt)+')');
 // and the other way: kill-quest target inside the crypt / a zone -> arrow at the stairs / gate when outside
 await E(()=>{const g=__game,d=g.dbg;g.tp(12,26);g.P.x=12*32+16;g.P.y=26*32+28;const e=g.enemies.find(o=>o.type==='slime');e.alive=false;
   g.enemies.filter(o=>o.type==='wolf').forEach(w=>{w.alive=true;w.dying=false;w.x=w.hx=20*32;w.y=w.hy=(d.ZONES.snow.y0+20)*32;});});
 const gate=await E(()=>{const d=__game.dbg;const w=__game.enemies.find(o=>o.type==='wolf');const en={kind:'quest',q:{obj:{k:'kill',type:'wolf'},giver:'Elder Orin',id:'x'},ready:false};const r=d.trkRoute(en);return r&&{via:r.via,x:r.x,y:r.y,w:!!w};});
 ok(gate&&gate.w&&/FROSTHOWL/.test(gate.via||''),'a wolf objective while in the overworld: arrow leads to the Frosthowl gate ('+JSON.stringify(gate)+')');
 // world map screen
 await E(()=>{const g=__game,d=g.dbg;g.tp(12,26);g.P.x=12*32+16;g.P.y=26*32+28;const e=g.enemies.find(o=>o.type==='slime');e.alive=true;e.dying=false;e.x=e.hx=20*32;e.y=e.hy=26*32+28;d.openUIMode('travel','play');});await sleep(500);
 await shot('quest-arrow-worldmap'+(MOBILE?'':'-desktop')+'.png');
 ok(await E(()=>__game.dbg.UI.mode==='travel'),'world map screen opens with the quest marker');
 await E(()=>{__game.dbg.closeUI();});
 ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
