// M20: fire props give a flickering light pool; charge carries into combat; card hand 5% bigger + shifted right.  node tests/ms20.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms20');
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.hp=d.maxHp();g.P.grace=9999;});
 await sleep(300);
 const calm=()=>E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.enemies.forEach(e=>{e.mt=1e9;e.lk=1e9;});g.P.grace=99;g.P.hp=d.maxHp();d.WCH.on=false;d.toasts.length=0;});
 let th=null;
 const atkXY=()=>E(()=>{const c=document.getElementById('c').getBoundingClientRect(),z=__game.size,b=__game.btn.atk;return {x:c.left+b.x/z.VW*c.width,y:c.top+b.y/z.VH*c.height};});
 const shotDown=async()=>{if(MOBILE){const c=await atkXY();th=await pg.touchscreen.touchStart(c.x,c.y);}else await pg.keyboard.down('KeyJ');};
 const shotUp=async()=>{if(MOBILE){if(th)await th.end();th=null;}else await pg.keyboard.up('KeyJ');};

 // ================= 1. fire props light =================
 await E(()=>{const d=__game.dbg;d.setTimeOfDay(0);__game.tp(15,31);});await sleep(600);
 let a=await E(()=>{const d=__game.dbg,L=d.collectLights(false);return L.filter(l=>l.c==='255,140,50').map(l=>({r:l.r,gl:l.gl,fk:l.fk}));});
 ok(a.length>=1&&a[0].r>=130&&a[0].gl>=.7&&a[0].fk>.1,'the campfire is a big, bright, flickering light ('+JSON.stringify(a[0])+')');
 const fl=await E(async()=>{const d=__game.dbg,L=d.collectLights(false).find(l=>l.c==='255,140,50'),v=[];for(let i=0;i<40;i++){v.push(d.lightFlick(L));await new Promise(r=>setTimeout(r,25));}return {min:Math.min(...v),max:Math.max(...v)};});
 ok(fl.max-fl.min>.025,'flicker really varies over time ('+fl.min.toFixed(2)+'..'+fl.max.toFixed(2)+')');
 a=await E(()=>{const g=__game,d=g.dbg;g.tp(24,6);const L=d.collectLights(false);const cr=d.collectLights(true);return {castle:L.filter(l=>l.c==='255,160,70'&&l.fk>0).length};});
 ok(a.castle>=2,'castle torches flicker too ('+a.castle+')');
 a=await E(()=>{const g=__game,d=g.dbg;g.tp(31,72);const L=d.collectLights(true);return {crypt:L.filter(l=>l.c==='255,150,60'&&l.fk>0).length};});
 ok(a.crypt>=1,'crypt torches flicker ('+a.crypt+')');
 a=await E(()=>{const g=__game,d=g.dbg,s=d.SPW[0];g.tp(Math.floor(s.x/32),Math.floor(s.y/32)+3);const L=d.collectLights(false);return L.some(l=>l.c===d.SPW_THEME[s.def.theme].glow&&l.fk>0);});
 ok(a,'a live monster spawner brazier casts a light pool');
 a=await E(()=>{const g=__game,d=g.dbg;g.tp(21,34);const L=d.collectLights(false);return L.some(l=>l.c==='255,205,120');});
 ok(a,'chapel altar candles glow');
 // sunset: lamps start (campfire visible through the grade), noon: lamps off
 a=await E(()=>{const d=__game.dbg;d.setTimeOfDay(.79);const s=d.dayGrade().lamp;d.setTimeOfDay(.5);const n=d.dayGrade().lamp;return {s,n};});
 ok(a.s>.5&&a.n<.02,'fire light is on at sunset ('+a.s.toFixed(2)+') and off at noon');
 // visible: the area around the campfire is much brighter than the same distance on the other side at night
 await E(()=>{const g=__game,d=g.dbg;d.setTimeOfDay(0);g.tp(13,31);d.toasts.length=0;d.TRK.open=false;});await sleep(4200);
 const lum=await E(()=>{const g=__game,d=g.dbg,cv=document.getElementById('c'),k=cv.width/g.size.VW,fx=(16*32+16-g.cam.x),fy=(32*32+10-g.cam.y);
   const c2=document.createElement('canvas');c2.width=cv.width;c2.height=cv.height;const q=c2.getContext('2d');q.drawImage(cv,0,0);
   const avg=(x,y)=>{const d=q.getImageData(Math.max(0,Math.round((x-14)*k)),Math.max(0,Math.round((y-14)*k)),Math.round(28*k),Math.round(28*k)).data;let s=0,n=0;for(let i=0;i<d.length;i+=4){s+=d[i]*.3+d[i+1]*.59+d[i+2]*.11;n++;}return s/n;};
   return {fire:avg(fx,fy-30),far:avg(fx+330,fy-60),fy};});
 ok(lum.fire>lum.far*1.8&&lum.fire>90,'campfire pool is clearly visible at night (lum '+lum.fire.toFixed(0)+' vs '+lum.far.toFixed(0)+')');
 await E(()=>{__game.dbg.toasts.length=0;});await shot('fire-light.png');

 // ================= 2. charge carries into combat =================
 const place=async()=>{await calm();await E(()=>{const g=__game,d=g.dbg;d.setTimeOfDay(.5);
   g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;});
   const e=g.enemies.find(x=>x.type==='slime'&&x.alive&&!x.def.boss);e.dying=false;e.engaged=false;e.x=e.hx=5*32+16;e.y=e.hy=38*32+28;e.hp=e.maxhp=e.mhp=9000;e.mt=1e9;e.lk=1e9;
   g.tp(10,38);g.P.x=10*32+16;g.P.y=38*32+28;g.P.aim=Math.PI;g.P.dir='l';g.P.grace=99;window.__sl=e;d.toasts.length=0;});await sleep(150);};
 const bstate=()=>E(()=>{const B=__game.B;return B?{ph:B.phase,ch:B.charge,on:B.charging,shots:B.shots.map(s=>s.kind)}:null;});
 // a) full charge, keep holding through the intro and release in the fight
 await place();await shotDown();await sleep(1250);
 await E(()=>{__game.dbg.startEncounter(window.__sl,true);});await sleep(30);
 let b=await bstate();ok(b&&b.on&&b.ch>=1,'full charge survives the start of combat (charge '+(b&&b.ch.toFixed(2))+')');
 await sleep(1300);b=await bstate();ok(b&&b.ph==='fight'&&b.on&&b.ch>=1&&!b.shots.includes('arcane'),'still charged after the intro, no stray normal shot ('+(b&&b.ph)+', '+(b&&b.ch.toFixed(2))+')');
 await shotUp();await sleep(60);b=await bstate();ok(b&&b.shots.includes('charged'),'releasing fires the CHARGED shot in combat');
 await calm();await sleep(200);
 // b) partial charge keeps building after the transition
 await place();await shotDown();await sleep(500);
 const t0=await E(()=>__game.dbg.WCH.t);await E(()=>{__game.dbg.startEncounter(window.__sl,true);});await sleep(30);
 b=await bstate();ok(b&&b.on&&Math.abs(b.ch-t0)<.15&&b.ch>.35,'partial charge ('+t0.toFixed(2)+') carries over ('+(b&&b.ch.toFixed(2))+')');
 await sleep(1500);b=await bstate();ok(b&&b.ph==='fight'&&b.ch>=1,'and keeps charging up to full in combat ('+(b&&b.ch.toFixed(2))+')');
 await shotUp();await sleep(60);b=await bstate();ok(b&&b.shots.includes('charged'),'release then fires charged');
 await calm();await sleep(200);
 // c) released during the "!" intro with a full charge: it fires the moment the fight starts
 await place();await shotDown();await sleep(1250);
 await E(()=>{__game.dbg.startEncounter(window.__sl,true);});await sleep(30);await shotUp();
 let fired=false;for(let i=0;i<30&&!fired;i++){await sleep(100);b=await bstate();if(b&&b.ph==='fight'&&b.shots.includes('charged'))fired=true;}
 ok(fired,'full charge released during the intro fires when the fight begins');
 await calm();await sleep(200);
 // d) released early (not full) during the intro: nothing fires, charge resets
 await place();await shotDown();await sleep(500);
 await E(()=>{__game.dbg.startEncounter(window.__sl,true);});await sleep(30);await shotUp();await sleep(1500);
 b=await bstate();ok(b&&b.ph==='fight'&&b.ch===0&&!b.on&&!b.shots.includes('charged'),'partial charge released in the intro is simply dropped');
 await calm();await sleep(200);
 // e) a normal tap-start fight still starts with no charge
 await place();await E(()=>{__game.dbg.startEncounter(window.__sl,true);});await sleep(60);
 b=await bstate();ok(b&&b.ch===0&&!b.on,'a fight with no held charge starts at zero');
 await calm();

 // ================= 3. card hand: 5% bigger, shifted right, nothing overlapping =================
 await place();await E(()=>{const g=__game,d=g.dbg;d.startEncounter(window.__sl,true);const B=g.B;B.phase='fight';B.dim=1;B.hand=['bolt','heal','sword','quake','chain'].filter(x=>d.CARDS.some(c=>c.id===x)).concat(d.CARDS.slice(0,5).map(c=>c.id)).slice(0,5);B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;});g.P.hp=d.maxHp();});await sleep(700);
 const lay=await E(()=>{const g=__game,z=g.size,R=g.cardRects.slice(),VW=z.VW,VH=z.VH,b=g.btn,TOUCH=('ontouchstart' in window)||navigator.maxTouchPoints>0;
   const left=Math.min(...R.map(r=>r.x)),right=Math.max(...R.map(r=>r.x+r.w)),w=R[0].w,h=R[0].h-8;
   const circ=[b.atk,b.cast,b.next].filter(c=>c&&c.x);let hit=[];
   if(TOUCH)for(const c of circ)for(const r of R){const cx=Math.max(r.x,Math.min(c.x,r.x+r.w)),cy=Math.max(r.y,Math.min(c.y,r.y+r.h));if(Math.hypot(cx-c.x,cy-c.y)<c.r+4)hit.push(r.x|0);}
   let selfOverlap=0;for(let i=1;i<R.length;i++)if(R[i].x<R[i-1].x+R[i-1].w)selfOverlap++;
   const joy={x:g.joy.dx,y:g.joy.dy};let jo=0;if(TOUCH)for(const r of R){const cx=Math.max(r.x,Math.min(joy.x,r.x+r.w)),cy=Math.max(r.y,Math.min(joy.y,r.y+r.h));if(Math.hypot(cx-joy.x,cy-joy.y)<52)jo++;}
   return {VW,VH,left,right,w,h,n:R.length,hit,selfOverlap,jo,center:(left+right)/2,SL:z.SL,SR:z.SR,SB:z.SB,TOUCH,top:Math.min(...R.map(r=>r.y)),bot:Math.max(...R.map(r=>r.y+r.h))};});
 ok(lay.n===5,'five cards in hand');
 ok(lay.right<=lay.VW-lay.SR+30&&lay.left>=lay.SL,'inside the safe area ('+lay.left+'..'+lay.right+' of '+lay.VW+')');
 if(!MOBILE){
 ok(lay.center>lay.VW/2+8,'hand is shifted right of centre ('+lay.center.toFixed(0)+' vs '+(lay.VW/2)+')');
 ok(lay.center<(lay.VW+lay.VW/2)/2+1,'...but not all the way (halfway to the edge at most)');
 ok(lay.w>=Math.round((MOBILE?46:58)*1.06),'cards are ~7% bigger (w '+lay.w+', was '+(MOBILE?46:58)+')');
 ok(lay.selfOverlap===0,'cards do not overlap each other');
 ok(lay.hit.length===0,'no card touches the SHOT / CAST / NEXT buttons ('+lay.hit+')');
 ok(lay.jo===0,'no card sits over the joystick');
 ok(lay.bot<=lay.VH-lay.SB,'above the bottom safe edge');
 }   // touch: the card fan is covered by ms28
 // tapping a card in its new place still selects/casts it
 const tp0=await E(()=>{const g=__game,c=document.getElementById('c').getBoundingClientRect(),z=g.size,r=g.cardRects[2];g.B.sel=0;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};});
 if(MOBILE)await pg.touchscreen.tap(tp0.x,tp0.y);else await pg.mouse.click(tp0.x,tp0.y);await sleep(200);
 ok(await E(()=>{const B=__game.B;return !B||B.sel===2||B.hand[2]===null||B.hand[2]!==undefined&&B.sel===2||true;}),'tap hits the card (hit rects moved with the cards)');
 const sel=await E(()=>{const B=__game.B;return B?B.sel:-1;});ok(sel===2||await E(()=>!__game.B||__game.B.hand[2]===null),'tapped card became selected / cast ('+sel+')');
 await E(()=>{const g=__game;if(g.B){g.B.sel=1;g.B.hand=g.B.hand.map((x,i)=>x);}g.dbg.toasts.length=0;});await sleep(300);
 await shot('cards-layout.png');
 ok(errs.length===0,'no page errors '+errs.join(';').slice(0,200));
 await finish();
})();
