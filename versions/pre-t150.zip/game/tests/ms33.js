// M33: heal rebalance, skip the night (inn + chapel), brighter night (esp. town), monsters repopulate over dusk/dawn, wolf pathing,
// waystone glow + travel-map highlight, no NEXT button.  node tests/ms33.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,shot,finish,MOBILE}=await boot('ms33',{town:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;d.TRK.open=false;g.DLG=null;g.state='play';d.endFight();g.P.lv=Math.max(g.P.lv,4);g.P.hp=d.maxHp();});
 // ---- 1. healing rebalance
 const h0=await E(()=>{const d=__game.dbg;d.resetCards();return {heal:d.getCol().heal,deck:d.getDeck().filter(x=>x==='heal').length,tot:d.getDeck().length,pct:d.HEAL_PCT,cool:d.HEAL_COOL};});
 ok(h0.heal===1&&h0.deck===1&&h0.pct===.22,'starter deck has 1 Heal (was 3) and Heal restores 22% (was 35%) '+JSON.stringify(h0));
 ok(await E(()=>{const d=__game.dbg;d.getCol().heal=6;d.getDeck().push('heal','heal','heal');d.fixDeck();return true;}),'(setup)');
 const lim=await E(()=>{const d=__game.dbg;d.getCol().heal=6;return d.deckLimit('heal');});ok(lim===2,'a deck can never hold more than 2 Heals (limit '+lim+')');
 await E(()=>{const g=__game,d=g.dbg;d.resetCards();g.state='play';g.DLG=null;g.enemies.forEach(e=>{e.x=e.hx=60*32;e.y=e.hy=2*32;e.mode='look';e.mt=e.lk=1e9;});
   const e=g.enemies.find(o=>o.type==='slime'&&!o.def.boss);g.tp(10,22);g.P.x=10*32+16;g.P.y=22*32+28;e.x=e.hx=14*32;e.y=e.hy=22*32+28;e.alive=true;e.hp=e.maxhp=e.mhp=99999;g.P.grace=0;d.startEncounter(e,true);window.__e=e;});
 await sleep(500);
 const hp=await E(()=>{const g=__game,d=g.dbg,B=g.B;B.inv=99;const e=window.__e;e.atkCd=1e9;const mx=d.maxHp();B.hand=['heal','heal','sword','fire','lance'];B.clk=100;B.healClk=null;
   g.P.hp=1;d.useCard(0);const a=g.P.hp-1;g.P.hp=1;d.useCard(1);const b=g.P.hp-1;return {mx,a,b};});
 ok(hp.a===Math.ceil(hp.mx*.22)&&hp.b===Math.ceil(hp.mx*.22*.5),'first Heal = 22% of max HP ('+hp.a+'/'+hp.mx+'), a second within 12s = half ('+hp.b+')');
 await E(()=>{__game.dbg.endFight();});
 // ---- 2. NEXT button is gone
 ok(await E(()=>!__game.btn.next),'no NEXT button exists (cards are selected / cast directly)');
 // ---- 3. night brightness (town + wild) and screenshot
 const lum=()=>E(()=>{const c=document.getElementById('c'),x=c.getContext('2d'),w=c.width,h=c.height,im=x.getImageData(0,0,w,h).data;let s=0,n=0,dk=0;for(let i=0;i<im.length;i+=4*37){const l=.299*im[i]+.587*im[i+1]+.114*im[i+2];s+=l;n++;if(l<14)dk++;}return {mean:s/n,dark:dk/n};});
 await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;g.P.grace=99;g.tp(14,35);g.P.x=14*32+16;g.P.y=35*32+10;d.setTimeOfDay(1.0);});await sleep(1500);
 const lt=await lum();ok(lt.mean>70&&lt.dark<.18,'midnight in Oakvale: clearly night but readable (mean luma '+Math.round(lt.mean)+', very dark share '+(lt.dark*100).toFixed(0)+'%)');
 await E(()=>{__game.dbg.toasts.length=0;});await sleep(2600);await shot("night-town.png");
 const ev=await E(()=>{const c=document.getElementById('c'),x=c.getContext('2d'),w=c.width,h=c.height,cells=[];for(let gy=0;gy<5;gy++)for(let gx=0;gx<6;gx++){const im=x.getImageData(Math.floor(gx*w/6),Math.floor(gy*h/5),Math.floor(w/6),Math.floor(h/5)).data;let s=0,n=0;for(let i=0;i<im.length;i+=16){s+=.299*im[i]+.587*im[i+1]+.114*im[i+2];n++;}cells.push(s/n);}
   const m=cells.reduce((a,b)=>a+b)/cells.length;return {mean:Math.round(m),min:Math.round(Math.min(...cells)),max:Math.round(Math.max(...cells))};});
 ok(ev.min>=ev.mean*.45,'night village lighting is even: no dark patches (darkest cell '+ev.min+' vs mean '+ev.mean+', brightest '+ev.max+')');
 const fk=await E(async()=>{const d=__game.dbg,v=[];for(let i=0;i<90;i++){v.push(d.lightFlick({fk:.17,ph:4.2,x:10}));await new Promise(r=>setTimeout(r,16));}
   let step=0;for(let i=1;i<v.length;i++)step=Math.max(step,Math.abs(v[i]-v[i-1]));return {step,range:Math.max(...v)-Math.min(...v),same:d.lightFlick({fk:.1,ph:3,x:0})===d.lightFlick({fk:.1,ph:3,x:300})};});
 ok(fk.step<.02&&fk.range<.2&&fk.same,'torch flicker is subtle and smooth (max frame step '+fk.step.toFixed(3)+', range '+fk.range.toFixed(3)+') and independent of screen scroll');
 await E(()=>{const g=__game;g.tp(8,20);g.P.x=8*32+16;g.P.y=20*32+10;});await sleep(1500);
 const lw=await lum();ok(lw.mean>45&&lw.mean<lt.mean+60,'midnight in the wild is still readable (mean luma '+Math.round(lw.mean)+')');
 ok(await E(()=>__game.dbg.NIGHT_DARK<=.66&&__game.dbg.NIGHT_DARK_TOWN<__game.dbg.NIGHT_DARK),'ambient darkness lowered (was .84) and gentlest in town');
 await E(()=>{__game.dbg.setTimeOfDay(.5);});
 // ---- 4. skip the night
 const inn=await E(()=>{const d=__game.dbg,n=d.NPCS.find(q=>q.inn);return n?{x:n.x/32,y:n.y/32,clash:d.NPCS.filter(q=>q!==n&&Math.hypot(q.x-n.x,q.y-n.y)<44).length}:null;});
 ok(inn&&inn.clash===0,'Innkeeper Rosa stands in Oakvale clear of other NPCs '+JSON.stringify(inn));
 await E(()=>{const g=__game,d=g.dbg;g.tp(8,34);g.P.x=7.5*32;g.P.y=34.5*32;d.setTimeOfDay(.5);g.P.gold=500;g.P.hp=10;d.openInn(d.NPCS.find(q=>q.inn));});
 ok(await E(()=>__game.DLG&&!__game.DLG.yes),'in daylight the innkeeper offers no bed');
 await E(()=>{const g=__game,d=g.dbg;g.DLG=null;d.setTimeOfDay(.95);d.openInn(d.NPCS.find(q=>q.inn));});
 const od=await E(()=>({yes:__game.DLG&&__game.DLG.yes,cost:__game.dbg.innCost()}));ok(/SLEEP/.test(od.yes||''),'at night the innkeeper offers a bed ('+od.yes+')');
 await E(()=>{const g=__game;g.P.gold=3;const D=g.DLG,af=D.after;D.choice();g.DLG=af?af():null;});
 await sleep(300);ok(await E(()=>!__game.dbg.WARPV&&__game.dbg.DAY.t>.9),'too little gold: no sleep');
 await E(()=>{const g=__game,d=g.dbg;g.DLG=null;g.P.gold=500;g.P.hp=10;d.openInn(d.NPCS.find(q=>q.inn));window.__c=d.innCost();const D=g.DLG,af=D.after;D.choice();g.DLG=af?af():null;});
 await sleep(400);ok(await E(()=>!!__game.dbg.WARPV),'paying starts a fade');
 await sleep(2800);
 const sl=await E(()=>{const g=__game,d=g.dbg;return {t:d.DAY.t,night:d.DAY.night,hp:g.P.hp,mx:d.maxHp(),gold:g.P.gold,c:window.__c,warp:!!d.WARPV};});
 ok(!sl.warp&&sl.t>=.28&&sl.t<=.4&&!sl.night&&sl.hp===sl.mx&&sl.gold===500-sl.c,'the inn fades to morning, fully heals and charges the fee ('+JSON.stringify(sl)+')');
 await E(()=>{const g=__game,d=g.dbg;g.DLG=null;d.setTimeOfDay(.9);g.P.hp=5;g.P.gold=0;const n=g.dbg.NPCS.find(q=>q.priest);d.openPriest(n);});
 await E(()=>{const g=__game;const D=g.DLG,af=D.after;D.choice();g.DLG=af();});
 const cr=await E(()=>({yes:__game.DLG&&__game.DLG.yes}));ok(cr.yes==='REST','after Father Anselm\'s blessing, at night, he offers a rest until morning');
 await E(()=>{__game.DLG.choice();__game.DLG=null;});await sleep(3300);
 ok(await E(()=>__game.dbg.DAY.t>=.28&&__game.dbg.DAY.t<=.4&&!__game.dbg.WARPV),'resting in the chapel skips to morning (free)');
 await E(()=>{const g=__game,d=g.dbg;d.setTimeOfDay(.5);g.DLG=null;d.openPriest(g.dbg.NPCS.find(q=>q.priest));const D=g.DLG,af=D.after;D.choice();g.DLG=af();});
 ok(await E(()=>!__game.DLG.yes),'in daylight there is no rest offer');
 await E(()=>{__game.DLG=null;});
 // ---- 5. monsters repopulate across dusk / dawn
 await E(()=>{const g=__game,d=g.dbg;g.tp(8,32);g.P.grace=99;d.endFight();d.setTimeOfDay(.05);d.syncNight(true);
   window.__day=g.enemies.filter(e=>!e.night&&!e.def.boss&&!e.spw&&e.hy/32<60);window.__day.forEach(e=>{e.alive=false;e.respawn=55;e.dying=false;e.engaged=false;});
   const s=window.__day[0];s.alive=true;s.engaged=true;s.dying=true;s.dyT=0;s.flash=.12;});
 await sleep(300);ok(await E(()=>__game.dbg.DAY.night),'(setup) it is night');await E(()=>{__game.dbg.DAY.t=.1285;});
 let up=false;for(let i=0;i<40&&!up;i++){await sleep(400);up=await E(()=>!__game.dbg.DAY.night);}
 ok(up,'night turned into day on its own');
 let back=0;for(let i=0;i<40;i++){await sleep(500);back=await E(()=>window.__day.filter(e=>e.alive&&!e.engaged&&!e.dying).length);if(back===await E(()=>window.__day.length))break;}
 ok(back===await E(()=>window.__day.length),'every daytime monster is back within seconds of dawn ('+back+'/'+await E(()=>window.__day.length)+')');
 // ---- 6. wolf pathing (arena pillar) + stuck fallback
 await E(()=>{__game.dbg.labStart();});await sleep(3300);
 const mkw=`(x,y)=>({x,y,t:99,cd:9,face:1,bite:0,dmg:1,anim:0,path:null,pathT:0,stuckT:0,lx:x,ly:y,lt:0})`;
 const wf=await E(mk=>{const g=__game,d=g.dbg,B=g.B;if(!B)return {err:'no fight'};const mkw=eval(mk);
   const ty=d.ARENA.y0+3,px=22*32+16,py=ty*32+22;
   const w=mkw(px-60,py);const goal={x:px+60,y:py};let steps=0;
   const blocked=!d.losW({x:w.x,y:w.y-6},5,{x:goal.x,y:goal.y-6},5);
   for(;steps<900;steps++){const dd=Math.hypot(goal.x-w.x,goal.y-w.y);if(dd<20)break;d.wolfSteer(w,goal,dd,175/60,1/60);}
   return {steps,blocked,tele:w.tele||0,end:Math.round(Math.hypot(goal.x-w.x,goal.y-w.y))};},mkw);
 ok(wf.blocked&&wf.steps<400&&!wf.tele&&wf.end<=20,'wolf walks around a pillar to a target on the far side ('+JSON.stringify(wf)+')');
 const wt=await E(mk=>{const g=__game,d=g.dbg,mkw=eval(mk);
   const tx=40,ty=d.ARENA.y0+6,w=mkw(tx*32+16,ty*32+22),saved=[];
   for(let dx=-1;dx<=1;dx++)for(let dy=-1;dy<=1;dy++){if(!dx&&!dy)continue;saved.push([tx+dx,ty+dy,d.map[ty+dy][tx+dx]]);d.map[ty+dy][tx+dx]=d.T.CP;}
   const goal={x:30*32,y:(ty+2)*32};let t=0;for(;t<400;t++){d.wolfSteer(w,goal,Math.hypot(goal.x-w.x,goal.y-w.y),175/60,1/60);if(w.tele)break;}
   for(const [x,y,v] of saved)d.map[y][x]=v;
   return {t:+(t/60).toFixed(2),tele:w.tele||0,near:Math.round(Math.hypot(w.x-goal.x,w.y-goal.y))};},mkw);
 ok(wt.tele===1&&wt.t>1.4&&wt.t<2.6&&wt.near<90,'a pinned wolf teleports beside its target after ~1.5s ('+JSON.stringify(wt)+')');
 await E(()=>{__game.dbg.labLeave();});await sleep(3000);
 // ---- 7. waystones: dormant grey, attuned glowing
 ok(await E(()=>__game.dbg.SP.waystoneOff!==__game.dbg.SP.waystone),'a separate dormant-waystone sprite exists');
 const wy=await E(()=>{const g=__game,d=g.dbg;d.endFight();g.state='play';g.DLG=null;d.setTimeOfDay(.5);const n=d.NPCS.find(q=>q.way==='road');g.tp(Math.floor(n.x/32)-1,Math.floor(n.y/32)+4);g.P.grace=99;d.SEC.ways.road=false;window.__wn=n;return {n:n.name};});
 await sleep(700);
 const cy=()=>E(()=>{const g=__game,n=window.__wn,c=document.getElementById('c'),x=c.getContext('2d'),k=c.width/g.size.VW,sx=(n.x-g.cam.x)*k,sy=(n.y-g.cam.y-16)*k,r=Math.round(34*k),im=x.getImageData(Math.max(0,Math.round(sx-r)),Math.max(0,Math.round(sy-r)),r*2,r*2).data;let b=0,n2=0;for(let i=0;i<im.length;i+=4){b+=im[i+2]-im[i];n2++;}return b/n2;});
 const dormant=await cy();await E(()=>{__game.dbg.activateWay('road');});await sleep(500);const lit=await cy();
 ok(lit>dormant+5,'an attuned waystone glows cyan (blue-red balance '+dormant.toFixed(1)+' -> '+lit.toFixed(1)+')');
 await shot('waystone-lit.png');
 // ---- 8. travel menu: you-are-here ring + highlighted destination
 await E(()=>{const g=__game,d=g.dbg;g.tp(12,35);g.P.x=12*32+16;g.P.y=35*32+10;d.activateWay('road');d.activateWay('forest');d.openTravel();});await sleep(400);
 const idx=await E(()=>__game.dbg.WAYSTONES.findIndex(w=>w.id==='road'));
 await E(i=>{__game.dbg.UI.sel=i;},idx);await sleep(300);
 const mi=await E(()=>__game.dbg.UI.mapInfo);ok(mi&&mi.dest==='road'&&mi.zone===mi.here,'selecting a stone highlights it on the map of the area ('+JSON.stringify(mi)+')');
 await E(()=>{__game.dbg.UI.scroll=0;});await sleep(200);await shot('waystone-menu.png');
 const idx2=await E(()=>__game.dbg.WAYSTONES.findIndex(w=>w.zone));await E(i=>{__game.dbg.activateWay(__game.dbg.WAYSTONES[i].id);__game.dbg.UI.sel=i;},idx2);await sleep(300);
 const mi2=await E(()=>__game.dbg.UI.mapInfo);ok(mi2&&mi2.destZone&&mi2.zone===mi2.destZone&&mi2.here==='ow','a stone in another region switches the map to that region ('+JSON.stringify(mi2)+')');
 await E(()=>{__game.dbg.closeUI();});
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
