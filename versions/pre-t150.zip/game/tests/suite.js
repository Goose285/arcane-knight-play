// Assertion suite: node tests/suite.js [desktop|mobile]
const puppeteer=require('puppeteer-core');const path=require('path');
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const MOBILE=process.argv[2]==='mobile';const URL='file://'+path.join(__dirname,'..','index.html');
const fails=[];let n=0;const ok=(c,m)=>{n++;if(!c){fails.push(m);console.log('  FAIL: '+m);}};
(async()=>{
 const b=await puppeteer.launch({executablePath:'/usr/bin/google-chrome',headless:'new',args:['--no-sandbox']});
 const pg=await b.newPage();await pg.evaluateOnNewDocument(()=>{window.__NOTOWN=true;});if(MOBILE)await pg.emulate(puppeteer.KnownDevices['iPhone 14 Pro']);else await pg.setViewport({width:960,height:640});
 const E=(f,...a)=>pg.evaluate(f,...a);
 await pg.goto(URL);await pg.evaluate(()=>localStorage.clear());await pg.goto(URL);await sleep(500);
 ok(await E(()=>__game.state)==='title','boots to title');
 if(MOBILE)await pg.touchscreen.tap(200,400);else await pg.keyboard.press('Space');await sleep(500);
 ok(await E(()=>__game.state)==='play','New Game starts play');
 // --- world content
 const en=await E(()=>__game.enemies.map(e=>({t:e.type,lv:e.lv,fi:e.def.freezeImmune,terr:!!e.terr})));
 for(const t of ['slime','knight','goblin','dragon'])ok(en.some(e=>e.t===t),'enemy type present: '+t);
 ok(en.every(e=>e.lv>=1),'every enemy has a level');
 const dr=en.find(e=>e.t==='dragon');ok(dr&&dr.fi&&dr.terr,'dragon freezeImmune + territory');
 // --- start a fight, shoot, kill, no victory screen for normal fights
 const f=await E(async()=>{const g=__game;g.P.hp=1e6;g.P.grace=99;g.fight('slime');const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;});
   const e=B.ens[0];const hp0=e.hp,gold0=g.P.gold;g.press('KeyJ');await new Promise(r=>setTimeout(r,500));const hurt=e.hp<hp0;
   e.hp=1;g.dbg.fireProj; // finish it with a shot
   B.shots.push({x:e.x,y:e.y-13,vx:0,vy:0,r:10,dmg:50,own:'p',kind:'arcane',life:1,a:0});await new Promise(r=>setTimeout(r,500));
   return {hurt,dead:e.dying||!e.alive,gold:g.P.gold>gold0,phase:g.B?g.B.phase:'ended'};});
 ok(f.hurt,'shot damages enemy');ok(f.dead,'enemy dies');ok(f.gold,'gold awarded');ok(f.phase!=='reward'&&f.phase!=='win','no victory popup after normal fight (phase='+f.phase+')');
 await sleep(1800);
 // --- every card casts
 const cast=await E(async()=>{const g=__game,d=g.dbg,out={};
   for(const c of d.CARDS){
     g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.hx=e.x;e.hy=e.y;e.mt=1e9;e.lk=1e9;e.engaged=false;});
     const pool=g.enemies.filter(x=>x.type==='knight'||x.type==='slime');const pos=[[6,38],[7,37.4],[7.4,39]];
     pool.slice(0,3).forEach((e,i)=>{e.x=pos[i][0]*32+16;e.y=pos[i][1]*32+28;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;});
     g.tp(10,38);g.P.grace=99;g.P.hp=60;g.P.aim=Math.PI;d.startEncounter(pool[0],true);const B=g.B;B.phase='fight';B.dim=1;B.ens.forEach(e=>{e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;});
     B.hand=[c.id,'heal','heal','heal','heal'];B.sel=0;d.useCard(0);out[c.id]=B.hand[0]===null;
     await new Promise(r=>setTimeout(r,60));
     g.B&&0;
   }
   return out;});
 for(const [id,u] of Object.entries(cast))ok(u,'card casts: '+id);
 ok(Object.keys(cast).length>=23,'card table has >=23 cards ('+Object.keys(cast).length+')');
 // --- deck rules
 const dk=await E(()=>{const d=__game.dbg;d.resetCards();const n0=d.DECK().length;d.grantCard('meteor');d.deckAdd('meteor');d.deckAdd('meteor');return {n0,meteor:d.DECK().filter(x=>x==='meteor').length,max:d.DECK().length<=20};});
 ok(dk.n0===15,'starter deck 15 (1 Heal)');ok(dk.meteor===1,'epic limited to 1 copy in deck');ok(dk.max,'deck <=20');
 // --- save round trip
 const sv=await E(()=>{const g=__game,d=g.dbg;d.grantCard('chain');g.P.gold=777;g.saveGame('t');const s=g.readSave();return {gold:s&&s.P.gold,has:s&&s.cards&&s.cards.col.chain>0};});
 ok(sv.gold===777&&sv.has,'save contains gold + card collection');
 // --- sword auto target
 const sw=await E(async()=>{const g=__game,d=g.dbg;g.enemies.forEach(e=>{e.x=60*32;e.y=2*32;e.mt=1e9;e.lk=1e9;e.engaged=false;});const e=g.enemies.find(o=>o.type==='knight');g.tp(10,38);g.P.grace=99;g.P.hp=1e6;
   e.x=g.P.x-50;e.y=g.P.y;e.hx=e.x;e.hy=e.y;e.alive=true;e.dying=false;d.startEncounter(e,true);const B=g.B;B.phase='fight';e.joinT=0;e.atkCd=1e9;e.hp=e.maxhp=5000;g.P.aim=0;g.P.moving=true;B.hand=['sword','heal','heal','heal','heal'];d.useCard(0);
   await new Promise(r=>setTimeout(r,400));return {dmg:5000-e.hp,dir:g.P.dir};});
 ok(sw.dmg>0&&sw.dir==='l','sword auto-targets enemy behind player');
 await b.close();
 console.log(`suite ${MOBILE?'mobile':'desktop'}: ${n-fails.length}/${n} assertions passed`);process.exit(fails.length?1:0);
})().catch(e=>{console.error('SUITE CRASH',e);process.exit(1);});
