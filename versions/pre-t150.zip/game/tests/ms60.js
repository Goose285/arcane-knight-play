// M60 (t139u/t140u/t141u): editor-edit import, quest marker colours, sign declutter + HELP tab, level-up dedupe, cozy reveal, grey stone south
// wall + wall pieces, rock immunity, BESTIARY, typed telegraphs, backup archives.   node tests/ms60.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms60',{town:true,grow:true,device:MOB?'iPhone 12 landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t139/.test(tags),'backup tag backup-pre-t139');
 const PLAY=__dirname+'/../../ak-play';
 ok(['pre-t135','pre-t138','pre-t139'].every(l=>fs.existsSync(PLAY+'/versions/'+l+'.zip')),'backup zips for pre-t135 / pre-t138 / pre-t139');
 await E(()=>{window.__NOESC=0;__game.dbg.startFromTitle();});await sleep(700);
 // 0. Seth's editor export applies on the grown world (rows/cols, keeper NPC, scarecrow)
 const ex=fs.existsSync(PLAY+'/world-edits.json')?JSON.parse(fs.readFileSync(PLAY+'/world-edits.json','utf8')):null;
 ok(ex&&ex.g===1&&ex.ops.length>80,'world-edits.json present with g:1 ('+(ex&&ex.ops.length)+' ops)');
 let s=await E(async(ex)=>{edAdoptBaked(edMigrate(ex));await new Promise(r=>setTimeout(r,2200));return {MW,OWH:OW_H,keeper:NPCS.filter(n=>n.edAdded).map(n=>[n.name,Math.floor(n.x/32),Math.floor(n.y/32)]),
   sc:enemies.filter(e=>e.type==='scarecrow').map(e=>[Math.floor(e.hx/32),Math.floor(e.hy/32)])};},ex);
 ok(s.MW===ex.world.cols&&s.OWH===ex.world.rows,'world size matches the export ('+s.MW+'x'+s.OWH+')');
 ok(s.keeper.length===1&&s.keeper[0][2]<224+ex.world.rows+224,'keeper NPC placed inside the world '+JSON.stringify(s.keeper));
 ok(s.sc.some(([x,y])=>x===57&&y===313),'scarecrow moved to 57,313');
 s=await E(()=>{const j=JSON.parse(edJSON());return j.g===1&&typeof j.nb==='number';});ok(s,'EXPORT now carries g + nb');
 // 1. quest markers
 s=await E(()=>{const k=__game.t139();return {m:k.NPCS.map(n=>k.npcMarker(n)).filter(Boolean),col:k.QMARK_COL,main:k.QUESTS.filter(k.isMainQuest).map(q=>q.id)};});
 ok(s.m.includes('story')&&s.m.includes('avail'),'story (yellow) and side (blue) markers both used: '+s.m.join(','));
 ok(s.col.story!==s.col.avail&&/^#4a/.test(s.col.avail)&&s.col.ready,'side quests blue, ready gold');
 // 2. signs
 s=await E(()=>{const k=__game.t139();return {d:k.DECLUTTER,guide:k.NPCS.filter(n=>n.guide&&n.x>0).length,hang:k.NPCS.filter(n=>n.hang&&/^hang_/.test(n.spr)).length,ret:k.NPCS.filter(n=>n.retired&&n.x<0).length};});
 ok(s.guide===1&&s.hang>=4&&s.ret>=3,'one Controls Guide board, hanging shop signs '+s.hang+', retired posts '+s.ret+', lanterns thinned '+s.d.lanterns);
 // 3. level-up dedupe
 s=await E(()=>{const k=__game.t139();window.__NOREVEAL=0;k.REV.q.length=0;k.REV.cur=null;k.revealLevel(5,4);k.revealLevel(6,5);k.revealLevel(7,6);const lv=k.REV.q.filter(q=>q.k==='level');const r={n:lv.length,name:lv[0]&&lv[0].name};k.revealLevel(7,6);r.n2=k.REV.q.filter(q=>q.k==='level').length;k.REV.q.length=0;window.__NOREVEAL=1;return r;});
 ok(s.n===1&&s.n2===1&&/5 - 7/.test(s.name),'several level-ups = one combined screen ('+s.name+'), never repeated');
 const src=fs.readFileSync(__dirname+'/../index.html','utf8');
 ok(!/toast\(`LEVEL UP!/.test(src),'no duplicate LEVEL UP toasts');
 ok(/cozy parchment/.test(src)&&!/lineTo\(-18,-VH\)/.test(src),'reveal: parchment card, harsh ray wedges gone');
 // 5. south wall + pieces
 s=await E(()=>{const k=__game.t139(),ty=Math.floor(TOWN.y1/32);let tw=0,gt=0,wl=0;for(let x=0;x<40;x++)for(let y=ty-2;y<=ty;y++){const z=k.SW.zone(x,y);if(!z)continue;if(z.tower)tw++;if(z.gateL||z.gateR)gt++;if(z.wall)wl++;}
   return {tw,gt,wl,items:k.ED_ITEMS.filter(i=>i.cat==='Walls').map(i=>i.name)};});
 ok(s.tw>=4&&s.gt>=2&&s.wl>=10,'south wall: towers '+s.tw+', gate '+s.gt+', wall '+s.wl);
 ok(['Stone wall, crenellated (joins)','Stone pillar','Stone corner','Stone inner corner','Tower with banner','Gatehouse + portcullis','Gate pillar + lantern','Low wall, mossy','Ruined wall','Ivy wall','Wooden gate'].every(n=>s.items.includes(n)),'editor Walls tab has the full kit');
 // 6. rock immunity
 s=await E(()=>{const k=__game.t139();const n0=k.IMMUNE_LOG.n;const fake={type:'cgolem',def:{big:false},dying:false,x:0,y:0,burn:3,burnT:.5};k.rockBurnCheck(fake);const r1=fake.burn;
   const r={rock:['cgolem','warden','scamp','geode'].every(t=>k.isRock({type:t})),soft:!k.isRock({type:'slime'}),burn:r1,pois:k.damageEnemy({type:'geode',def:{},dying:false,x:0,y:0,immT:0},10,'dot')===false,fire:k.damageEnemy({type:'cgolem',def:{},dying:false,x:0,y:0,immT:0},10,'fire')===false};r.pop=k.IMMUNE_LOG.n-n0;return r;});
 ok(s.rock&&s.soft&&s.burn===0&&s.pois&&s.fire&&s.pop>=3,'rock species immune to poison + burn, Cinder Golem to fire, IMMUNE pops '+JSON.stringify(s));
 // 7. bestiary
 s=await E(async()=>{const k=__game.t139();const all=Object.keys(k.ENEMY).filter(t=>k.BEST_INFO[t]);k.BEST.seen={slime:1};k.BEST.kills={slime:3};const p=k.packBest();k.unpackBest({s:['wolf'],k:{wolf:2}});const w=k.BEST.seen.wolf&&k.BEST.kills.wolf===2;k.unpackBest(p);
   k.setState('paused');k.PM.tab='bestiary';await new Promise(r=>setTimeout(r,250));const ids=k.pauseRects.map(r=>r.e.id);k.PM.tab='help';await new Promise(r=>setTimeout(r,200));const hid=k.pauseRects.map(r=>r.e.id);k.setState('play');
   return {all:all.length,n:Object.keys(k.ENEMY).length,w,ids:ids.filter(i=>/^best:/.test(i)).length,tabs:ids.includes('bestiary')&&ids.includes('help'),help:hid.filter(i=>/^help:/.test(i)).length,saved:JSON.stringify(p)};});
 ok(s.all===s.n,'bestiary covers every monster ('+s.all+'/'+s.n+')');ok(s.w,'bestiary pack/unpack per save');ok(s.tabs&&s.ids>=8&&s.help>=6,'BESTIARY + HELP tabs ('+s.ids+' tiles, '+s.help+' help pages)');
 ok(/best:packBest\(\)/.test(src)&&/unpackBest\(s\.best\)/.test(src),'bestiary saved in the save file');
 // 8. telegraph kinds
 s=await E(()=>{const k=__game.t139();const z=(kk)=>({k:kk});return [k.teleKindOf({strike:function(e){e.dash={};}},{k:'line'}),k.teleKindOf({strike:function(){fireProj();}},{k:'line'}),k.teleKindOf({strike:function(){}},{k:'cone'}),k.teleKindOf({strike:function(){}},{k:'circle'})];});
 ok(s.join()==='dash,proj,melee,aoe','telegraph kinds: '+s.join());
 s=await E(()=>{const k=__game.t139();return Object.values(k.TELE).map(t=>t.col);});ok(new Set(s).size===4,'4 distinct telegraph colours + icons');
 ok(/ATTACK WARNINGS/.test(src),'legend in the controls guide');
 ok(errs.length===0,'no page errors '+errs.slice(0,2));
 await finish();
})();
