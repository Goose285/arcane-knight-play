/* =====================================================================
   t147u / t148u PERFORMANCE (t148u: chunk cache REMOVED — it left black holes when
   tileSprite returned null during bake, and auto-quality + resize thrashing made lag
   constant). Kept: DPR cap at 2 (no auto oscillation), fog half-res buffer, cached HUD
   panel/button skins, cheaper HD wrap + prewarm, throttled night/crypt light mask.
   ===================================================================== */
const QUAL={mode:'hi',fps:60,acc:0,n:0,t:0,wantDpr:2,locked:true};   // t148u: locked — no auto DPR/mode flips
function qualTick(dt){
  QUAL.acc+=dt;QUAL.n++;QUAL.t+=dt;
  if(QUAL.t<.75)return;QUAL.fps=QUAL.n/QUAL.t;QUAL.n=0;QUAL.t=0;
  // locked: never call resize from quality (that was the constant-lag spiral)
}
function qualApply(){QUAL.wantDpr=2;FOG_LQ=false;HDX.on=true;HDX.spr=true;}
/* ---- DPR cap at 2 (iPhone Pro = 3 was ~2.2M px) ---- */
{const _rs=resize;resize=function(){
  const raw=window.devicePixelRatio||1,cap=2;
  const desc=Object.getOwnPropertyDescriptor(window,'devicePixelRatio');
  try{Object.defineProperty(window,'devicePixelRatio',{configurable:true,get:()=>Math.min(raw,cap)});_rs();}
  finally{if(desc)Object.defineProperty(window,'devicePixelRatio',desc);else delete window.devicePixelRatio;}
  DPR=Math.min(raw,cap);QUAL.wantDpr=2;
};}
/* ---- Fog: half-res offscreen ---- */
let FOG_LQ=false,FOG_BUF=null,FOG_BG=null,FOG_KEY='';
function fogDrawFast(){
  if(FOG.a<.02)return;const a=FOG.a,S=fogSprites();
  const sc=.7,W=Math.max(1,Math.ceil(VW*sc)),H=Math.max(1,Math.ceil(VH*sc));
  if(!FOG_BUF||FOG_BUF.width!==W||FOG_BUF.height!==H){FOG_BUF=document.createElement('canvas');FOG_BUF.width=W;FOG_BUF.height=H;FOG_BG=FOG_BUF.getContext('2d');}
  const fr=Math.floor(gtime*12);
  const key=W+'x'+H+'|'+Math.round(cam.x/6)+'|'+Math.round(cam.y/6)+'|'+fr+'|'+Math.round(a*16);
  if(key!==FOG_KEY){FOG_KEY=key;const g=FOG_BG;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,W,H);
    g.fillStyle=`rgba(226,232,238,${a*.08})`;g.fillRect(0,0,W,H);
    const layers=[[.55,.9,.55,9],[.8,1.25,.75,16],[1.1,1.7,.9,26]];
    layers.forEach(([par,ss,al,spd],li)=>{const w=320*ss*sc,h=110*ss*sc,ox=(-(cam.x*par)+gtime*spd)*sc,oy=(-(cam.y*par))*sc;
      g.globalAlpha=Math.min(1,a*al*.75);
      const WW=w*.8,HH=h*.7,bx=((ox%WW)+WW)%WW-WW,by=((oy%HH)+HH)%HH-HH;
      for(let gy=0;gy<=Math.ceil(H/HH)+1;gy++)for(let gx=0;gx<=Math.ceil(W/WW)+1;gx++){
        const sx=bx+gx*WW+(gy%2)*WW*.4,sy=by+gy*HH+Math.sin(gtime*.3+gx+li)*6*sc;
        g.drawImage(S[(gx*7+gy*3+li)%4],Math.round(sx-w*.1),Math.round(sy),Math.round(w),Math.round(h));}
    });
    g.globalAlpha=1;}
  ctx.save();ctx.imageSmoothingEnabled=true;ctx.drawImage(FOG_BUF,0,0,VW,VH);ctx.imageSmoothingEnabled=false;ctx.restore();
}
drawFog=fogDrawFast;
/* ---- HUD panel + button disc caches ---- */
const PANEL_SKIN=new Map();
function panelSkin(w,h,fillKey){
  const k=w+'x'+h+'|'+fillKey;let s=PANEL_SKIN.get(k);if(s)return s;
  const c=document.createElement('canvas');c.width=w+4;c.height=h+6;const g=c.getContext('2d'),ox=0,oy=0;
  g.fillStyle='rgba(0,0,0,.45)';g.fillRect(ox+2,oy+4,w,h);
  const pat=satPattern();
  g.fillStyle='#2a160a';g.fillRect(ox+3,oy,w-6,h);g.fillRect(ox,oy+3,w,h-6);g.fillRect(ox+1,oy+1,w-2,h-2);
  g.save();g.beginPath();g.rect(ox+2,oy+2,w-4,h-4);g.clip();g.fillStyle=pat;g.fillRect(ox,oy,w,h);g.restore();
  g.fillStyle='#a8703f';g.fillRect(ox+3,oy+2,w-6,2);g.fillRect(ox+2,oy+3,2,h-6);
  g.fillStyle='#5e3a1c';g.fillRect(ox+3,oy+h-4,w-6,2);g.fillRect(ox+w-4,oy+3,2,h-6);
  g.fillStyle='#4a3208';g.fillRect(ox+4,oy+4,w-8,h-8);
  g.fillStyle='#e0b44a';g.fillRect(ox+5,oy+5,w-10,h-10);
  g.fillStyle='#fff0a0';g.fillRect(ox+5,oy+5,w-10,1);g.fillRect(ox+5,oy+5,1,h-10);
  if(fillKey==='def'){const gr=g.createLinearGradient(0,oy+7,0,oy+h-7);gr.addColorStop(0,'#3e2617');gr.addColorStop(1,'#22140b');g.fillStyle=gr;}
  else g.fillStyle=fillKey;
  g.fillRect(ox+7,oy+7,w-14,h-14);
  g.fillStyle='rgba(0,0,0,.4)';g.fillRect(ox+7,oy+7,w-14,2);g.fillRect(ox+7,oy+7,2,h-14);
  for(const [qx,qy] of [[ox+3,oy+3],[ox+w-4,oy+3],[ox+3,oy+h-4],[ox+w-4,oy+h-4]]){g.fillStyle='#4a3208';g.fillRect(qx-2,qy-2,5,5);g.fillStyle='#e0b44a';g.fillRect(qx-1,qy-1,3,3);g.fillStyle='#fff0a0';g.fillRect(qx-1,qy-1,1,1);}
  PANEL_SKIN.set(k,c);return c;
}
{const _panel=panel;panel=function(x,y,w,h,o={}){
  if(o.legacy)return _panel(x,y,w,h,o);
  x=Math.round(x);y=Math.round(y);w=Math.round(w);h=Math.round(h);
  const custom=o.fill&&o.fill!=='#1a1630',fk=custom?o.fill:'def';
  ctx.drawImage(panelSkin(w,h,fk),x,y);
  if(o.border&&o.border!=='#e8e0c8'){ctx.fillStyle=o.border;ctx.fillRect(x+9,y+h-6,w-18,2);}
};}
const BTN_CACHE=new Map();
function btnSkin(r,tintKey){
  const k=r+'|'+tintKey;let s=BTN_CACHE.get(k);if(s)return s;
  const c=document.createElement('canvas'),pad=8,sz=r*2+pad*2;c.width=sz;c.height=sz+4;const g=c.getContext('2d'),cx=pad+r,cy=pad+r;
  g.fillStyle='rgba(0,0,0,.35)';g.beginPath();g.arc(cx+2,cy+4,r+3,0,6.283);g.fill();
  g.fillStyle='#1c0e06';g.beginPath();g.arc(cx,cy,r+3,0,6.283);g.fill();
  const gr=g.createLinearGradient(cx-r,cy-r,cx+r,cy+r);gr.addColorStop(0,'#fff0a0');gr.addColorStop(.45,'#e0b44a');gr.addColorStop(1,'#9a7418');
  g.fillStyle=gr;g.beginPath();g.arc(cx,cy,r+1,0,6.283);g.fill();
  g.save();g.beginPath();g.arc(cx,cy,r-3,0,6.283);g.clip();
  g.fillStyle=satPattern();g.fillRect(cx-r,cy-r,r*2,r*2);
  g.fillStyle=tintKey||'rgba(20,8,2,.35)';g.fillRect(cx-r,cy-r,r*2,r*2);
  const sh=g.createRadialGradient(cx-r*.3,cy-r*.4,1,cx,cy,r);sh.addColorStop(0,'rgba(255,230,180,.28)');sh.addColorStop(1,'rgba(0,0,0,.35)');g.fillStyle=sh;g.fillRect(cx-r,cy-r,r*2,r*2);
  g.restore();g.strokeStyle='#2a160a';g.lineWidth=1.5;g.beginPath();g.arc(cx,cy,r-3,0,6.283);g.stroke();
  BTN_CACHE.set(k,c);return c;
}
hdButton=function(x,y,r,down,o={}){
  ctx.globalAlpha=o.alpha==null?1:o.alpha;
  const tint=o.tint||(down?'rgba(255,220,140,.25)':'rgba(20,8,2,.35)');
  ctx.drawImage(btnSkin(r,tint),Math.round(x-r-8),Math.round(y-r-8));
  if(o.ring){ctx.strokeStyle=o.ring;ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,r+4.5,0,6.283);ctx.stroke();}
  ctx.globalAlpha=1;
};
/* ---- Cheaper HD wrap ---- */
HDX.spr=true;
{const _hg=hdGet;hdGet=function(src,mode){
  if(!HDX.on||!src)return null;if(mode==='spr'&&!HDX.spr)return null;
  if(src._hd)return src._hd;if(src._hdMiss)return null;
  if(!src.width||src.width>48){src._hdMiss=1;return null;}
  const c=_hg(src,mode);if(c)src._hd=c;else src._hdMiss=1;return c;
};}
{const prev=ctx.drawImage;
 ctx.drawImage=function(img,a,b,c,d){
   if(arguments.length===5&&img&&img._hd)return prev.call(this,img._hd,a,b,c,d);
   if(arguments.length===5&&img&&!img._hdMiss&&img.width<=48&&img.height<=64&&c>=(img.width||0)*1.9&&d>=(img.height||0)*1.9&&!(typeof HD_NO!=='undefined'&&HD_NO.has(img))){
     const h=hdGet(img,'spr');if(h)return prev.call(this,h,a,b,c,d);
   }
   return prev.apply(this,arguments);
 };}
function hdPrewarm(){
  try{const ids=[T.G,T.K,T.P,T.B,T.BT,T.F,T.S,T.L,T.N,T.RK,T.SN,T.MD,T.SD];
    let i=0;const step=()=>{let n=0;while(i<ids.length&&n<4){const id=ids[i++],arr=TSPR[id];if(arr)for(const s of arr)hdGet(s,'tile');n++;}if(i<ids.length)setTimeout(step,0);};
    setTimeout(step,0);}catch(e){}
}
setTimeout(hdPrewarm,0);
{const _up=update;update=function(dt){qualTick(dt);return _up.apply(this,arguments);};}
/* stubs so older tests that poke CH / chGet don't throw */
const CH={map:new Map(),n:8,px:256,live:false,zn:null};
function chGet(){return null;}function chInvalidate(){}function chkKey(){return 0;}
