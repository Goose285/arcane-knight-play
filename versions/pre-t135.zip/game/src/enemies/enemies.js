/* village bounds (see player/town.js): monsters never spawn / wander / path inside */
const TOWN={x0:3*TS,y0:29*TS,x1:25*TS,y1:45*TS,lv:30};
const townOn=()=>window.__NOTOWN!==true;
const inTownPx=(x,y)=>townOn()&&x>=TOWN.x0&&x<TOWN.x1&&y>=TOWN.y0&&y<TOWN.y1;
const playerInTown=()=>inTownPx(P.x,P.y-8);
const townNear=(x,y,m)=>x>=TOWN.x0-m&&x<TOWN.x1+m&&y>=TOWN.y0-m&&y<TOWN.y1+m;     // (spawn buffer test, always on)
// Relative-difficulty colour: green = easier, yellow = even, red = harder
function lvColor(L){const df=L-P.lv;return df<=-5?'#38d66b':df<=-2?'#8fe05a':df<=1?'#ffe14d':df<=4?'#ff9a3d':'#ff4a4a';}
// territory: pixel rect an enemy is confined to (wander, chase, fight, knock-back). inTerr(e,x,y): is a point inside it.
function initTerritory(e){const t=e.def.territory;e.terr=t?{x0:t.tx0*TS+10,x1:(t.tx1+1)*TS-10,y0:t.ty0*TS+8,y1:(t.ty1+1)*TS-1}:null;}
function clampTerr(e){const t=e.terr;if(!t)return;e.x=clamp(e.x,t.x0,t.x1);e.y=clamp(e.y,t.y0,t.y1);}
const inTerr=(e,x,y,m=0)=>!e.terr||(x>=e.terr.x0-m&&x<=e.terr.x1+m&&y>=e.terr.y0-m&&y<=e.terr.y1+m);
function applyLevel(e,L){
  const d=e.def,k=L-1;
  e.lv=L;e.tier=L>=8?2:L>=5?1:0;e.title=TITLES[e.type][e.tier];e.tname=TIERS[e.type][e.tier];e.sz=e.type==='dragon'?1:TIER_SIZE[e.tier];
  e.mhp=Math.round(d.hp*(1+d.hs*k));e.dm=1+d.ds*k;e.as=1+d.as*k;
  e.xpv=Math.round(d.xp*(1+d.rs*k));e.gm=1+d.rs*k;
  e.vr=Math.round(d.vr*(1+d.ss*k));e.ar=Math.round(d.ar*(1+d.ss*k));
  e.hp=e.maxhp=e.mhp;
  eliteApply(e);
}
// level by zone: meadow/village outskirts 1-3, forest 3-6, castle 6-10, boss 12
function levelFor(type,tx,ty){
  {const fl=foeLevel(type,tx,ty);if(fl)return fl;}
  if(type==='dragon')return 12;
  if(type==='lich')return 16;
  if(type==='rimegar')return 14;if(type==='mossback')return 17;if(type==='colossus')return 20;
  {const zn=zoneOfTy(ty);if(ZONES[zn]){const lo={snow:7,swamp:10,desert:13}[zn],t3=clamp((ZONES[zn].y0+26-ty)/22,0,1);return clamp(Math.round(lo+3*t3+R(-.6,.6)),lo,lo+3);}}
  const owz=zoneOfTy(ty)==='ow';if(type==='wraith'&&owz)return clamp(Math.round(5+R(-.6,1.8)),5,7);   // night wraiths haunting the meadow
  if(!owz&&ty>=CRY0){const t2=clamp((84-ty)/30,0,1),lo2=type==='wraith'?10:8,hi2=type==='wraith'?14:11;return clamp(Math.round(lo2+(hi2-lo2)*t2+R(-.7,.7)),lo2,hi2);}
  let lo,hi,t;
  if(owz&&regions.farm(tx,ty)){lo=5;hi=8;t=clamp((ty-OY-62)/36,0,1);}   // Goldenfield Farms: gentler near the gate, tougher deep south
  else if(regions.castle(tx,ty)){lo=6;hi=10;t=clamp(1-(ty-OY-1)/10,0,1);}
  else if(regions.forest(tx,ty)){lo=3;hi=6;t=clamp(Math.hypot(tx-OX-27,ty-OY-38)/32,0,1);}
  else{lo=1;hi=3;t=clamp((29-(ty-OY))/13,0,1);}
  const bias=type==='knight'?.4:type==='goblin'?.2:-.2;
  return clamp(Math.round(lo+(hi-lo)*clamp(t+bias*.25,0,1)+R(-.7,.7)),lo,hi);
}
const enemies=[];const WS=[];let wcd=0;
function spawnSpots(n,pred,spacing=4){
  const out=[];let tries=0;
  while(out.length<n&&tries++<4000){
    const x=RI(3,MW-3),y=RI(2,MH-3);
    if(!reach[y][x]||!pred(x,y)||solidTile(x,y))continue;
    if(Math.hypot(x*TS-SPAWN.x,y*TS-SPAWN.y)<10*TS)continue;
    if(townNear(x*TS,y*TS,3*TS))continue;
    if(out.some(o=>Math.hypot(o[0]-x,o[1]-y)<spacing))continue;
    out.push([x,y]);
  }
  return out;
}
function mkEnemyObj(type,tx,ty){
  const d=ENEMY[type];
  return {type,def:d,hx:tx*TS+TS/2,hy:ty*TS+TS-4,x:tx*TS+TS/2,y:ty*TS+TS-4,dir:Math.random()*6.28,wt:R(.5,2),alive:true,respawn:0,alert:0,chasing:false,face:1,bob:Math.random()*6,engaged:false,fa:Math.random()*6.283,ta:0,mode:'look',mt:R(.4,2),lk:R(.3,1),stuck:0};
}
/* a monster coming back (respawn, dusk / dawn swap) starts from a clean slate: full HP, home position, calm wandering AI, no leftover fight / status state */
function resetEnemyState(e){
  Object.assign(e,{hp:e.mhp||e.maxhp,maxhp:e.mhp||e.maxhp,x:e.hx,y:e.hy,chasing:false,engaged:false,dying:false,gdie:false,dyT:0,flash:0,st:'idle',cur:null,dash:null,frozen:0,fimm:0,chill:0,burn:0,stun:0,curse:0,pois:0,
    alert:0,calm:0,mode:'look',mt:R(.4,2),lk:R(.3,1),stuck:0,path:null,hidden:false,fa:Math.random()*6.283,ta:0});
}
function addEnemy(type,tx,ty){
  const e=mkEnemyObj(type,tx,ty);enemies.push(e);
  initTerritory(e);applyLevel(e,levelFor(type,tx,ty));e.baseLv=e.lv;
  if(!window.__NOELITE){eliteRoll(e);if(e.elite)applyLevel(e,e.lv);}
}
let GOBLIN_CAMP={tx:50,ty:24};
/* an open, well-connected clearing in the east of the forest for the goblins' camp */
function findGoblinCamp(){
  const open=(x,y)=>x>=0&&y>=0&&x<MW&&y<MH&&reach[y][x]&&!solidTile(x,y);
  let best=null,bs=-1;
  for(let y=18;y<=34;y++)for(let x=44;x<=58;x++){
    if(!open(x,y)||townNear(x*TS,y*TS,6*TS))continue;
    let n=0;for(let dy=-5;dy<=5;dy++)for(let dx=-5;dx<=5;dx++)if(Math.hypot(dx,dy)<=5.5&&open(x+dx,y+dy))n++;
    const sc=n-Math.hypot(x-50,y-25)*.4;if(sc>bs){bs=sc;best={tx:x,ty:y};}
  }
  return best||{tx:50,ty:24};
}
function populate(){
  const meadow=(x,y)=>x>=3&&x<=24&&y>=14&&y<=24;   // (the village starts at y29: keep monsters well clear of its gates)
  spawnSpots(8,meadow,3.5).forEach(([x,y])=>addEnemy('slime',x,y));   // all the open-world slimes live in the meadow just north of Oakvale (the slime quests point there), none in the east forest
  const f=(x,y)=>regions.forest(x,y);
  spawnSpots(4,f,5).forEach(([x,y])=>addEnemy('knight',x,y));
  spawnSpots(2,f,5).forEach(([x,y])=>addEnemy('goblin',x,y));
  const c=(x,y)=>regions.castle(x,y)&&!(x>=29&&x<=34&&y<=6);
  spawnSpots(3,c,4).forEach(([x,y])=>addEnemy('knight',x,y));
  // the quest goblins have their own place: a camp in the east of Whisperwood (none in the castle with the dragon)
  GOBLIN_CAMP=findGoblinCamp();
  {const cp=GOBLIN_CAMP,near=(x,y)=>Math.hypot(x-cp.tx,y-cp.ty)<=5.5;spawnSpots(5,near,2.5).forEach(([x,y])=>addEnemy('goblin',x,y));}
  addEnemy('dragon',32,4);
  // night-only monsters (appear at dusk, gone at dawn): wraiths in the meadow, extra undead + goblins in the forest
  const nightAdd=(type,list)=>list.forEach(([x,y])=>{addEnemy(type,x,y);const e=enemies[enemies.length-1];e.night=true;e.alive=false;e.respawn=55;});
  nightAdd('wraith',spawnSpots(4,meadow,4));nightAdd('knight',spawnSpots(2,f,5));nightAdd('goblin',spawnSpots(2,f,5));nightAdd('slime',spawnSpots(2,meadow,4));
  // the crypt: bats and wraiths in the halls, the Lich King on his throne
  const spots=[['bat',22,69],['bat',41,70],['bat',31,75],['bat',9,70],['bat',54,70],['bat',31,64],['bat',9,76],['bat',54,76],
    ['wraith',24,68],['wraith',39,70],['wraith',9,67],['wraith',54,67],['wraith',31,69],['wraith',9,73],['wraith',54,73]];
  spots.forEach(([t,x,y])=>addEnemy(t,x,y));
  addEnemy('lich',31,56);
  // the three regions: ten monsters each + a boss in the arena
  for(const id in ZONES){const z=ZONES[id];ZONE_SPAWNS.forEach(([k,x,dy])=>addEnemy(z.mobs[k],x,z.y0+dy));addEnemy(z.boss,36,z.y0+4);}
}
populate();
