
/* ---- enemy AI ---- */
const pickW=l=>{let s=0;l.forEach(a=>s+=a[1]);let r=Math.random()*s;for(const a of l){r-=a[1];if(r<=0)return a[0];}return l[0][0];};
// ground blasts never land through a wall: relative to the target AND to the caster
function scatterSpot(c,p,dx,dy,co=7){let q=clampRay(p,7,{x:p.x+dx,y:p.y+dy},7);q=clampRay(c,co,q,7);return q;}
const ATK={
  slime(e){
    const c=ecen(e),p=aimPos();
    if(Math.random()<.55){const q=clampRay(c,7,p,7),z=Z.circle(q.x,q.y,36);return{windup:.95,zones:[z],recover:.5,strike(e){e.hop=.35;hitZones([z],12,'boom');}};}
    const a=angTo(c,p),z=Z.line(c.x,c.y,a,240,16);
    return{windup:.65,zones:[z],recover:.5,strike(e){e.hop=.25;fireProj(c.x,c.y,a,150,10,'goo',7);}};
  },
  knight(e){
    const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);
    const k=pickW(d<115?[['slash',50],['charge',25],['guard',25]]:[['charge',60],['guard',25],['slash',15]]);
    if(k==='slash'){const z=Z.cone(c.x,c.y,a,78,.95);return{windup:.85,zones:[z],recover:.6,strike(e){e.lunge=.25;hitZones([z],24,'slash');}};}
    if(k==='charge'){const len=clamp(d+80,150,300),z=Z.line(c.x,c.y,a,len,38);return{windup:.95,zones:[z],recover:.7,strike(e){e.dash={vx:Math.cos(a)*640,vy:Math.sin(a)*640,t:z.len/640};hitZones([z],20,'slash');}};}
    if(e.guard>0)return ATK.knight(e);
    return{windup:.25,zones:[],recover:.3,strike(e){e.guard=2.6;sfx('shield');}};
  },
  goblin(e){
    const c=ecen(e),p=aimPos(),a=angTo(c,p);
    const k=pickW([['aim',40],['volley',35],['bomb',25]]);
    if(k==='aim'){const z=Z.line(c.x,c.y,a,430,14);return{windup:.9,zones:[z],recover:.6,strike(e){e.draw=.2;fireProj(c.x,c.y,a,480,13,'arrow',5);}};}
    if(k==='volley'){const as=[a-.4,a,a+.4],zs=as.map(q=>Z.line(c.x,c.y,q,430,12));return{windup:1.1,zones:zs,recover:.5,strike(e){e.draw=.2;as.forEach(q=>fireProj(c.x,c.y,q,460,12,'arrow',5));}};}
    const p0=clampRay(c,7,p,7),zs=[Z.circle(p0.x,p0.y,38)];for(let i=0;i<2;i++){const q=Math.random()*6.283,r=R(55,100),w=scatterSpot(c,p,Math.cos(q)*r,Math.sin(q)*r);zs.push(Z.circle(w.x,w.y,38));}
    return{windup:1.15,zones:zs,recover:.6,strike(e){e.draw=.2;hitZones(zs,16,'boom');}};
  },
  bat(e){
    const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);
    if(Math.random()<.6){const len=clamp(d+90,150,300),z=Z.line(c.x,c.y,a,len,30);return{windup:.6,zones:[z],recover:.5,strike(e){e.dash={vx:Math.cos(a)*720,vy:Math.sin(a)*720,t:z.len/720};e.lunge=.2;hitZones([z],15,'slash');}};}
    const z=Z.circle(c.x,c.y,74,eOff(e));return{windup:.8,zones:[z],recover:.5,strike(e){e.hop=.3;hitZones([z],13,'void');}};     // screech: leave its wingspan
  },
  wraith(e){
    const c=ecen(e),p=aimPos(),a=angTo(c,p);
    const k=pickW([['wail',35],['bolts',40],['drain',25]]);
    if(k==='wail'){const z=Z.cone(c.x,c.y,a,160,.65);return{windup:.95,zones:[z],recover:.6,strike(e){e.lunge=.2;hitZones([z],20,'void');}};}
    if(k==='bolts'){const as=[a-.32,a,a+.32],zs=as.map(q=>Z.line(c.x,c.y,q,440,13));return{windup:1.0,zones:zs,recover:.6,strike(e){as.forEach(q=>fireProj(c.x,c.y,q,310,12,'soul',6));}};}
    const p0=clampRay(c,7,p,7),zs=[Z.circle(p0.x,p0.y,40)];for(let i=0;i<2;i++){const q=Math.random()*6.283,r=R(55,105),w=scatterSpot(c,p,Math.cos(q)*r,Math.sin(q)*r);zs.push(Z.circle(w.x,w.y,40));}
    return{windup:1.1,zones:zs,recover:.6,strike(e){hitZones(zs,16,'void');}};
  },
  lich(e){
    const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y),p2=e.p2,p3=e.p3;
    const pool=[['bolts',35],['rain',35],['sweep',d<150?45:6]];
    if(p2)pool.push(['spiral',40]);
    if(p3){pool.push(['ray',40]);pool.push(['nova',35]);}
    const k=pickW(pool),ph=p3?.8:p2?.9:1;
    if(k==='bolts'){const n=p3?7:p2?5:3,as=[];for(let i=0;i<n;i++)as.push(a+(i-(n-1)/2)*.3);const zs=as.map(q=>Z.line(c.x,c.y,q,470,14,19));
      return{windup:.95*ph,zones:zs,recover:.7,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.4;as.forEach(q=>fireProj(c.x,c.y,q,360,14,'soul',7));}};}
    if(k==='rain'){const n=p3?9:p2?7:5,p0=clampRay(c,19,p,7),zs=[Z.circle(p0.x,p0.y,34)];for(let i=1;i<n;i++){const q=Math.random()*6.283,r=R(30,170),w=scatterSpot(c,p,Math.cos(q)*r,Math.sin(q)*r,19);zs.push(Z.circle(w.x,w.y,34));}
      return{windup:1.05*ph,zones:zs,recover:.7,strike(e){e.dragonOpen=.4;hitZones(zs,20,'void');}};}
    if(k==='sweep'){const z=Z.cone(c.x,c.y,a,150,1.0,19);return{windup:.8*ph,zones:[z],recover:.7,strike(e){e.hop=.3;hitZones([z],26,'slash');}};}
    if(k==='spiral'){   // a spiral of delayed grave-blasts winding out from the king
      const n=9,a0=Math.random()*6.283,zs=[];for(let i=0;i<n;i++){const ang=a0+i*.85,r=46+i*15;const w=scatterSpot(c,c,Math.cos(ang)*r,Math.sin(ang)*r,19);zs.push(Z.circle(w.x,w.y,32));}
      return{windup:.5,zones:[],recover:1.3,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;zs.forEach((z,i)=>schedule(i*.2,()=>{if(B.phase!=='fight')return;warnZones([z],.7);schedule(.7,()=>{if(B.phase==='fight')hitZones([z],18,'void');});}));}};}
    if(k==='ray'){const rays=o=>{const zs=[];for(let i=0;i<6;i++)zs.push(Z.line(c.x,c.y,o+i*Math.PI/3,330,32,19));return zs;};
      const o=Math.random()*6.283,A=rays(o),Bz=rays(o+Math.PI/6);
      return{windup:1.1,zones:A,recover:1.1,start(e){e.charge=1;},strike(e){e.dragonOpen=.5;e.charge=0;hitZones(A,26,'void');schedule(.25,()=>{if(B.phase!=='fight')return;warnZones(Bz,.85);schedule(.85,()=>{if(B.phase==='fight')hitZones(Bz,26,'void');});});}};}
    // nova: a deadly ring - stand right next to him or outside the ring
    const z=Z.ring(c.x,c.y,64,235,19);return{windup:1.2,zones:[z],recover:1.0,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.6;hitZones([z],32,'void');}};
  },
  dragon(e){
    const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y),p2=e.p2;
    let pool=[['breath',35],['meteor',35],['tail',d<140?45:10]];
    if(p2)pool.push(['inferno',40]);
    const k=pickW(pool);
    if(k==='breath'){const z=Z.cone(c.x,c.y,a,235,p2?.6:.5);return{windup:p2?.85:1.15,zones:[z],recover:.8,start(e){e.charge=1;},strike(e){e.dragonOpen=.6;e.charge=0;hitZones([z],28,'fire');}};}
    if(k==='meteor'){const n=p2?7:5,p0=clampRay(c,19,p,7),zs=[Z.circle(p0.x,p0.y,34)];for(let i=1;i<n;i++){const q=Math.random()*6.283,r=R(30,150),w=scatterSpot(c,p,Math.cos(q)*r,Math.sin(q)*r,19);zs.push(Z.circle(w.x,w.y,34));}
      return{windup:p2?.9:1.1,zones:zs,recover:.7,strike(e){e.dragonOpen=.4;hitZones(zs,20,'boom');}};}
    if(k==='tail'){const z=Z.circle(c.x,c.y,108,19);return{windup:p2?.85:1.0,zones:[z],recover:.7,strike(e){e.hop=.3;hitZones([z],26,'slash');if(p2){const z2=Z.circle(c.x,c.y,160,19);schedule(.15,()=>{if(B.phase!=='fight')return;warnZones([z2],.55);schedule(.55,()=>{if(B.phase==='fight')hitZones([z2],24,'slash');});});}}};}
    const rays=(o)=>{const zs=[];for(let i=0;i<8;i++)zs.push(Z.line(c.x,c.y,o+i*Math.PI/4,300,34));return zs;};
    const o=Math.random()*6.283,A=rays(o),Bz=rays(o+Math.PI/8);
    return{windup:1.2,zones:A,recover:1.1,start(e){e.charge=1;},strike(e){e.dragonOpen=.5;e.charge=0;hitZones(A,28,'fire');schedule(.2,()=>{if(B.phase!=='fight')return;warnZones(Bz,.9);schedule(.9,()=>{if(B.phase==='fight')hitZones(Bz,28,'fire');});});}};
  }
};
const BAND={slime:[26,64],knight:[30,60],goblin:[150,230],dragon:[125,200],bat:[24,70],wraith:[95,175],lich:[130,215],wolf:[26,80],yeti:[30,70],toad:[60,130],witch:[120,200],scorpion:[30,80],mummy:[30,70],rimegar:[130,215],mossback:[130,215],colossus:[130,215]};
// breadth-first search over walkable tiles to the nearest tile that can see the player (limited, runs a few times a second)
function findLosPath(e){
  const sx=Math.floor(e.x/TS),sy=Math.floor((e.y-4)/TS),pc=aimPos(),key=(x,y)=>y*MW+x,par=new Map([[key(sx,sy),-1]]),q=[[sx,sy]];
  let goal=null;
  for(let h=0;h<q.length&&q.length<900;h++){
    const [x,y]=q[h];
    if(h>0&&losW({x:x*TS+16,y:y*TS+16},0,pc,7)){goal=[x,y];break;}
    for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=key(nx,ny);if(par.has(k)||solidTile(nx,ny))continue;par.set(k,key(x,y));q.push([nx,ny]);}
  }
  if(!goal)return null;
  const path=[];let k=key(goal[0],goal[1]);
  while(k!==-1&&k!==key(sx,sy)){path.push({x:(k%MW)*TS+16,y:Math.floor(k/MW)*TS+22});k=par.get(k);}
  return path.reverse();
}
/* ---- M23 tactics: projectile dodging, flanking, retreat at low HP, ranged repositioning ---- */
const DODGE_BASE={slime:.10,knight:.20,goblin:.28,bat:.34,wraith:.26,wolf:.30,yeti:.12,toad:.16,witch:.28,scorpion:.24,mummy:.10};
// chance to sidestep an incoming shot: by type, grows with tier / elite / being out-levelled; bosses never dodge
function dodgeChance(e){
  if(window.__DODGEP!=null)return window.__DODGEP;
  if(e.def.boss||e.def.big)return 0;
  const b=DODGE_BASE[e.type]||.15;return clamp(b*(1+.3*(e.tier||0))+(e.elite?.12:0)+clamp((e.lv-P.lv)*.01,-.05,.08),0,.6);
}
const RETREATERS=new Set(['knight','goblin','wraith','witch','wolf','bat','scorpion']);
const FLANKERS=new Set(['slime','knight','bat','wolf','yeti','scorpion','mummy','toad']);
function tryDodge(e,dt,c){
  e.dodgeCd=Math.max(0,(e.dodgeCd||0)-dt);
  if(e.dodgeCd>0||e.st==='windup'||e.dash||e.def.boss||e.def.big)return;
  for(const s of B.shots){
    if(s.own!=='p'||s.dead)continue;
    const sp=Math.hypot(s.vx,s.vy)||1,ux=s.vx/sp,uy=s.vy/sp,rx=c.x-s.x,ry=c.y-s.y,t=rx*ux+ry*uy;
    if(t<10||t>sp*.34)continue;                                   // only shots about to arrive (~.3s)
    const lat=-rx*uy+ry*ux;if(Math.abs(lat)>eRad(e)+s.r+3)continue;   // ...and actually on target
    s.rolled=s.rolled||[];if(s.rolled.includes(e))continue;s.rolled.push(e);   // one roll per shot per enemy
    if(Math.random()>dodgeChance(e)*(s.kind==='charged'?.55:1))continue;
    const sg=lat>=0?1:-1,nx=-uy*sg,ny=ux*sg;
    e.dash={vx:nx*330,vy:ny*330,t:.2};e.dodgeCd=2.6-.3*(e.tier||0);e.dodged=(e.dodged||0)+1;
    burst(c.x,c.y+8,'#e8e0c8',5,70,.3);floatText(c.x,c.y-30,'DODGE','#cfe6ff',9);return;
  }
}
// melee enemies fan out around the player instead of queueing up: each takes its own slot on a circle
function flankTarget(e,p,rad){
  const m=B.ens.filter(o=>!o.dying&&o.joinT<=0&&FLANKERS.has(o.type));if(m.length<2||!FLANKERS.has(e.type))return null;
  let cx=0,cy=0;m.forEach(o=>{cx+=o.x;cy+=o.y;});cx/=m.length;cy/=m.length;
  const base=Math.atan2(cy-p.y,cx-p.x),i=m.indexOf(e),th=base+(i-(m.length-1)/2)*Math.min(1.25,2.4/m.length);
  return {x:p.x+Math.cos(th)*rad,y:p.y+Math.sin(th)*rad};
}
/* ---- group tactics: with 3+ regular enemies engaged they stop stacking up. Melee units take slots at different angles around the hero (front first, then
   sides / behind, so some circle round to flank); ranged / casters hold their preferred distance on the pack's side, strafing and kiting, behind the melee
   line; hard separation keeps every body apart; attacks are staggered. Bosses keep their own mechanics (they are not slotted, others just give them room). ---- */
const FORM_MIN=2,FORM_GAP=52;                   // slot spacing (px between body centres) the formation aims for
const isRangedT=t=>(BAND[t]||[0])[0]>=60;
const FORM_OFF={1:[0],2:[-1.15,1.15],3:[-1.05,1.05,2.9],4:[-.8,.8,-2.25,2.25],5:[0,-1.25,1.25,-2.5,2.5],6:[-.52,.52,-1.57,1.57,-2.62,2.62]};   // spread wide: pairs pincer, bigger groups surround the hero
const formGroup=()=>B.ens.filter(o=>!o.dying&&!o.dummy&&o.joinT<=0&&!o.def.boss);
const slotFree=(x,y)=>!solidTile(Math.floor(x/TS),Math.floor((y+4)/TS))&&!wallT(x,y+7);
// the slot point for an angle: pulled in (or rotated aside) when a wall / tree blocks it, so slots respect the terrain
function slotPoint(p,ang,rad,needLos){
  for(const da of [0,.5,-.5,1,-1,1.5,-1.5]){
    const a=ang+da,pt={x:p.x+Math.cos(a)*rad,y:p.y+Math.sin(a)*rad},q=clampRay(p,7,pt,7);
    if(Math.hypot(q.x-p.x,q.y-p.y)>=rad*.85&&slotFree(q.x,q.y)&&(!needLos||losW(p,7,q,7)))return {x:q.x,y:q.y,ang:a};
  }
  const q=clampRay(p,7,{x:p.x+Math.cos(ang)*rad*.6,y:p.y+Math.sin(ang)*rad*.6},7);return {x:q.x,y:q.y,ang};
}
function updateFormation(dt){
  const F=B.form||(B.form={t:0,base:null,n:0,side:Math.random()<.5?1:-1,clock:0});
  F.clock+=dt;F.t-=dt;
  const g=formGroup();F.n=g.length;
  if(g.length<FORM_MIN){if(F.base!==null){F.base=null;for(const o of B.ens)o.slot=null;}return;}
  if(F.t>0)return;F.t=.25;
  const p=aimPos();
  // the side the pack came from: mean direction from the hero to the group (kept steady unless the pack really swaps sides)
  let sx=0,sy=0;for(const o of g){const c=ecen(o),d=Math.hypot(c.x-p.x,c.y-p.y)||1;sx+=(c.x-p.x)/d;sy+=(c.y-p.y)/d;}
  const mag=Math.hypot(sx,sy)/g.length,ca=Math.atan2(sy,sx);
  if(F.base===null||(mag>.4&&Math.abs(angDiff(ca,F.base))>1.4))F.base=ca;
  const base=F.base;
  const mel=g.filter(o=>!isRangedT(o.type)),rng=g.filter(o=>isRangedT(o.type));
  // ---- melee: slots at spread angles; front slots go to the nearest bodies ----
  let rM=52;
  if(mel.length){
    const n=Math.min(6,mel.length),offs=(FORM_OFF[n]||FORM_OFF[6]).map((o,i)=>(n===3&&i===2?o*F.side:o));
    const so=offs.slice().sort((a,b)=>a-b);let gap=2*Math.PI-(so[so.length-1]-so[0]);for(let i=1;i<so.length;i++)gap=Math.min(gap,so[i]-so[i-1]);
    if(so.length>1)rM=clamp(FORM_GAP/(2*Math.sin(Math.min(gap,3)/2)),52,92);
    const order=offs.map((o,i)=>i).sort((a,b)=>Math.abs(offs[a])-Math.abs(offs[b])),taken=new Set();
    mel.forEach(o=>{o.slot=null;});
    const pool=mel.slice();
    for(const si of order){
      const ang=base+offs[si],rad=rM+(mel.length>6?40:0),sp=slotPoint(p,ang,rad,false);
      let best=null,bc=1e9;for(const o of pool){const c=ecen(o),cost=Math.hypot(c.x-sp.x,c.y-sp.y)-(o.sIdx===si?24:0);if(cost<bc){bc=cost;best=o;}}
      if(!best)break;pool.splice(pool.indexOf(best),1);best.slot={x:sp.x,y:sp.y,ranged:false,rad,ang:sp.ang};best.sIdx=si;
    }
    for(const o of pool){const k=pool.indexOf(o),sp=slotPoint(p,base+F.side*(2.2+k*.6),rM+40,false);o.slot={x:sp.x,y:sp.y,ranged:false,rad:rM+40,ang:sp.ang};}   // overflow: an outer ring
  }
  // ---- ranged: on the pack's side, behind the melee line, spread apart and drifting sideways (strafing) ----
  rng.sort((a,b)=>angDiff(angTo(p,ecen(a)),base)-angDiff(angTo(p,ecen(b)),base));
  rng.forEach((o,j)=>{
    const band=BAND[o.type],rad=clamp(Math.max((band[0]+band[1])/2,(mel.length?rM:0)+58),band[0]+10,band[1]-8);
    const drift=Math.sin(F.clock*.55+(o.id||0)*1.7+j*2.1)*.32,ang=base+(j-(rng.length-1)/2)*.8+drift,sp=slotPoint(p,ang,rad,true);
    o.slot={x:sp.x,y:sp.y,ranged:true,rad,ang:sp.ang};
  });
}
// can this enemy start an attack now? grouped fights allow one melee + one ranged telegraph at a time, spaced out, and only from a sensible position
function formAttackOk(e,d,winding){
  const F=B.form;if(!F||F.n<FORM_MIN||e.def.boss)return true;
  if(e.atkCd<-3.5)return true;
  const rg=isRangedT(e.type);
  if(B.ens.some(o=>o!==e&&o.st==='windup'&&!o.dying&&isRangedT(o.type)===rg&&!o.def.boss))return false;
  if(!e.slot)return true;
  const band=BAND[e.type];return d<=band[1]+(rg?60:46);
}
function startAttack(e,a){e.st='windup';e.cur=a;e.t=a.windup;if(a.zones&&a.zones.length)warnZones(a.zones,a.windup);if(a.start)a.start(e);}
function updateEnemyCombat(e,dt){updateEnemyCombat0(e,dt);if(!e.dying)foeTick(e,dt);clampTerr(e);}
function updateEnemyCombat0(e,dt){
  e.flash=Math.max(0,e.flash-dt);
  if(e.dying)return;
  if(e.dummy){   // Combat Lab training dummy: never moves or attacks; statuses wear off; heals back up
    e.hop=Math.max(0,e.hop-dt);e.bob+=dt*2;e.st='idle';e.cur=null;e.dash=null;e.atkCd=1e9;e.joinT=0;
    for(const k of ['frozen','chill','burn','stun','pois','curse'])if(e[k]>0)e[k]=Math.max(0,e[k]-dt);
    e.hp=Math.min(e.maxhp,e.hp+e.maxhp*.2*dt);return;}
  e.hop=Math.max(0,e.hop-dt);e.guard=Math.max(0,e.guard-dt);e.lunge=Math.max(0,e.lunge-dt);e.draw=Math.max(0,e.draw-dt);e.dragonOpen=Math.max(0,e.dragonOpen-dt);e.bob+=dt*5;
  e.chill=Math.max(0,e.chill-dt);const cs=e.chill>0?.6:1;   // chilled: -40% move & attack speed
  const sp=(e.p3?1.6:e.p2?1.35:1)*e.as*cs,c=ecen(e),p=aimPos(),d=Math.hypot(p.x-c.x,p.y-c.y);
  if(Math.abs(p.x-c.x)>6)e.face=p.x<c.x?1:-1;
  if(e.joinT>0)return;                                   // still noticing ("!")
  e.fimm=Math.max(0,e.fimm-dt);
  if(e.frozen>0){
    e.frozen-=dt;e.dash=null;
    if(e.frozen<=0){e.frozen=0;e.fimm=2.5;sfx('thaw');burst(c.x,c.y,'#bff1ff',10,90,.5);floatText(c.x,c.y-30,'THAWED','#bff1ff',11);}
  }
  if(e.stun>0){e.stun-=dt;if(e.stun<=0)e.stun=0;}
  const los=losEP(e);
  if(e.burn>0){e.burn-=dt;e.burnT-=dt;if(e.burnT<=0){e.burnT=.5;e.hp-=4;floatText(c.x+R(-8,8),c.y-24,'4','#ff9a3d',11);burst(c.x,c.y,'#ff7a2a',3,50,.4);if(e.hp<=0){e.hp=0;killEnemy(e);return;}}}
  const hw=e.def.big?12:7;
  if(e.dash){const s=Math.min(dt,e.dash.t);moveBox(e,e.dash.vx*s,0,hw,8);moveBox(e,0,e.dash.vy*s,hw,8);e.dash.t-=dt;if(e.dash.t<=0)e.dash=null;}
  if(e.frozen>0||e.stun>0)return;                 // frozen solid: no movement, no attacks, timers paused
  if(e.retreat>0)e.retreat-=dt;
  else if(!e.retreated&&RETREATERS.has(e.type)&&!e.def.boss&&e.st!=='windup'&&e.hp<e.maxhp*.28&&e.hp>0&&B.ens.filter(o=>!o.dying).length>=1&&Math.random()<(window.__RETREATP!=null?window.__RETREATP:.65)){
    e.retreated=true;e.retreat=2.6;e.st='idle';e.cur=null;B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);floatText(c.x,c.y-30,'RETREAT!','#ffd09a',10);}
  tryDodge(e,dt,c);
  const still=e.st==='windup'&&e.type!=='goblin';
  if(!e.dash&&!still){
    e.strafeT-=dt;e.reposT=Math.max(0,(e.reposT||0)-dt);if(e.strafeT<=0){e.strafeT=R(1.1,2.4);e.strafe=-e.strafe;}
    const band=BAND[e.type];let vx=0,vy=0,spd=cs*e.def.chase*(e.def.big?(e.p2?1.15:.75):e.type==='slime'?1.1:e.type==='bat'?1.15:1);
    const ux=(p.x-c.x)/(d||1),uy=(p.y-c.y)/(d||1);
    if(e.retreat>0){vx=-ux*.9-uy*e.strafe*.4;vy=-uy*.9+ux*e.strafe*.4;spd*=1.3;}   // wounded: back off and let the others cover
    else if(!los&&e.st!=='windup'){                           // wall in the way: walk a real route to the nearest tile with a clear line of sight
      e.pathT-=dt;
      if(e.pathT<=0||!e.path){e.pathT=.6;e.path=findLosPath(e);}
      let wp=e.path&&e.path[0];
      while(wp&&Math.hypot(wp.x-e.x,wp.y-e.y)<9){e.path.shift();wp=e.path[0];}
      if(wp){const wl=Math.hypot(wp.x-e.x,wp.y-e.y)||1;vx=(wp.x-e.x)/wl;vy=(wp.y-e.y)/wl;spd*=1.05;}
      else{if(e.strafeT>.7)e.strafeT=.7;vx=ux*.55-uy*e.strafe*.85;vy=uy*.55+ux*e.strafe*.85;}
    }
    else if(e.slot&&B.form&&B.form.n>=FORM_MIN&&!e.def.boss){   // group tactics: head for the assigned slot (orbiting round the hero, never through them)
      const S0=e.slot,sdx=S0.x-c.x,sdy=S0.y-c.y,sd=Math.hypot(sdx,sdy);
      if(S0.ranged&&d<band[0]){vx=-ux*.9-uy*e.strafe*.5;vy=-uy*.9+ux*e.strafe*.5;spd*=1.05;}   // hero closing in: kite back, a little sideways
      else if(sd>10){
        const ae=Math.atan2(c.y-p.y,c.x-p.x),as=Math.atan2(S0.y-p.y,S0.x-p.x),da=angDiff(as,ae);
        if(Math.abs(da)>.4&&d<S0.rad+90){   // wrong side of the hero: circle round at the slot radius
          const sg=da>0?1:-1,rr=clamp((S0.rad-d)/30,-1,1);vx=-Math.sin(ae)*sg*.95+Math.cos(ae)*rr*.7;vy=Math.cos(ae)*sg*.95+Math.sin(ae)*rr*.7;
        } else {vx=sdx/sd;vy=sdy/sd;}
        if(sd<26)spd*=.55;
      }
      else{vx=0;vy=0;}
    }
    else if(d>band[1]){
      const ft=d>band[1]+26?flankTarget(e,p,band[1]+6):null;
      if(ft){const fx=ft.x-c.x,fy=ft.y-c.y,fl=Math.hypot(fx,fy)||1;vx=fx/fl*.8+ux*.35;vy=fy/fl*.8+uy*.35;}else{vx=ux;vy=uy;}}
    else if(d<band[0]){vx=-ux*.8-uy*e.strafe*.5;vy=-uy*.8+ux*e.strafe*.5;spd*=.9;}
    else{vx=-uy*e.strafe;vy=ux*e.strafe;spd*=(e.reposT>0?.95:.45);}   // (ranged foes sidestep briskly to a new firing spot after a shot)
    // personal space: a soft push away from close neighbours; in a group fight a hard push-out too, so bodies never stack
    {const grp=B.form&&B.form.n>=FORM_MIN&&!e.def.boss;let px=0,py=0;
      for(const o of B.ens){if(o===e||o.dying||o.dummy)continue;const ox=e.x-o.x,oy=e.y-o.y,od=Math.hypot(ox,oy)||.1,minD=eRad(e)+eRad(o)+(grp?12:6),rg=minD+(grp?16:4);
        if(od<rg){const k=(1-od/rg)*(grp?3:1.5)+(od<minD?(grp?1.2:0):0),ux2=od>.2?ox/od:Math.cos(e.bob*3),uy2=od>.2?oy/od:Math.sin(e.bob*3);vx+=ux2*k;vy+=uy2*k;
          if(grp&&od<minD){const push=Math.min((minD-od)*(o.def.boss?1:.5),110*dt);px+=ux2*push;py+=uy2*push;}}}
      if(px||py){moveBox(e,px,0,hw,8);moveBox(e,0,py,hw,8);}}
    const vl=Math.hypot(vx,vy);if(vl>1){vx/=vl;vy/=vl;}
    if(e.st==='windup')spd*=.35;if(e.st==='recover')spd*=.5;
    if(e.type==='slime')spd*=Math.max(0,Math.sin(e.bob*.8))*1.8;
    if(e.type==='goblin'&&d<band[0]+10)spd*=1.15;
    if(spd>0)stepEnemy(e,vx,vy,spd,dt);
  }
  if(e.st==='idle'){
    e.atkCd-=dt*sp;
    if(e.atkCd<=0){
      if(e.retreat>0)return;
      const far=((e.type!=='goblin'&&!e.def.big)&&d>320)||!los;
      const winding=B.ens.filter(o=>o.st==='windup'&&!o.dying).length;
      const grpF=B.form&&B.form.n>=FORM_MIN&&!e.def.boss;
      if(!far&&winding<2&&B.atkGap<=0&&(!grpF||formAttackOk(e,d,winding))){B.owner=e;ZOFF=eOff(e);startAttack(e,ATK[e.type](e));B.atkGap=grpF?clamp(.6+.2*(B.form.n-3),.6,1.2):.5+(liveEns().length>2?.25:0);}   // staggered, capped attacks keep telegraphs fair
    }
  } else if(e.st==='windup'){
    e.t-=dt*cs;
    if(e.t<=0){B.owner=e;e.cur.strike(e);e.st='recover';e.t=e.cur.recover||.5;}
  } else if(e.st==='recover'){
    e.t-=dt*cs;if(e.t<=0){e.st='idle';const n=liveEns().length,m=(1+.2*(n-1))/(e.as*cs);e.atkCd=m*(e.def.big?R(1.0,1.6)/(e.p3?1.7:e.p2?1.4:1):e.type==='slime'?R(1.1,1.8):R(.9,1.5));e.cur=null;if(BAND[e.type][0]>=90&&Math.random()<.5){e.strafe=-e.strafe;e.reposT=1.0;e.strafeT=1.2;}}
  }
}

/* ---- new regions' monsters. Same building blocks as the older foes: a telegraphed zone, a windup, then hitZones / fireProj ---- */
const scatterZones=(c,p,n,rad,minR,maxR,co=7)=>{const p0=clampRay(c,co,p,7),zs=[Z.circle(p0.x,p0.y,rad)];for(let i=1;i<n;i++){const q=Math.random()*6.283,r=R(minR,maxR),w=scatterSpot(c,p,Math.cos(q)*r,Math.sin(q)*r,co);zs.push(Z.circle(w.x,w.y,rad));}return zs;};
const dashAtk=(e,c,a,d,wind,dmg,fx,spd=720,w=30)=>{const len=clamp(d+90,150,300),z=Z.line(c.x,c.y,a,len,w);return{windup:wind,zones:[z],recover:.55,strike(e){e.dash={vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,t:z.len/spd};e.lunge=.2;hitZones([z],dmg,fx);}};};
const coneAtk=(e,c,a,reach,half,wind,dmg,fx)=>{const z=Z.cone(c.x,c.y,a,reach,half);return{windup:wind,zones:[z],recover:.6,strike(e){e.lunge=.2;hitZones([z],dmg,fx);}};};
Object.assign(ATK,{
  wolf(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);return Math.random()<.6?dashAtk(e,c,a,d,.65,17,'slash',700):coneAtk(e,c,a,84,.8,.7,20,'slash');},
  yeti(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);
    const k=pickW(d<120?[['slam',55],['throw',20],['charge',25]]:[['throw',45],['charge',40],['slam',15]]);
    if(k==='slam'){const z=Z.circle(c.x,c.y,82,eOff(e));return{windup:1.0,zones:[z],recover:.7,strike(e){e.hop=.3;hitZones([z],26,'frost');}};}
    if(k==='throw'){const z=Z.line(c.x,c.y,a,380,16);return{windup:.85,zones:[z],recover:.6,strike(e){e.lunge=.2;fireProj(c.x,c.y,a,330,15,'ice',8);}};}
    return dashAtk(e,c,a,d,.95,24,'slash',620,38);},
  toad(e){const c=ecen(e),p=aimPos(),a=angTo(c,p);
    if(Math.random()<.5){const z=Z.line(c.x,c.y,a,210,20);return{windup:.8,zones:[z],recover:.6,strike(e){e.lunge=.25;hitZones([z],20,'mire');}};}
    const q=clampRay(c,7,p,7),z=Z.circle(q.x,q.y,52);return{windup:1.0,zones:[z],recover:.6,strike(e){e.hop=.35;hitZones([z],22,'mire');}};},
  witch(e){const c=ecen(e),p=aimPos(),a=angTo(c,p);
    if(Math.random()<.55){const as=[a-.34,a,a+.34],zs=as.map(q=>Z.line(c.x,c.y,q,430,13));return{windup:1.0,zones:zs,recover:.6,strike(e){as.forEach(q=>fireProj(c.x,c.y,q,300,13,'spore',6));}};}
    const zs=scatterZones(c,p,3,42,55,105);return{windup:1.15,zones:zs,recover:.6,strike(e){hitZones(zs,18,'mire');}};},
  scorpion(e){const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y);return Math.random()<.5?dashAtk(e,c,a,d,.7,20,'slash',700):coneAtk(e,c,a,90,.9,.8,24,'sand');},
  mummy(e){const c=ecen(e),p=aimPos(),a=angTo(c,p);
    if(Math.random()<.5)return coneAtk(e,c,a,100,.9,1.1,28,'slash');
    const zs=scatterZones(c,p,4,40,40,115);return{windup:1.2,zones:zs,recover:.7,strike(e){hitZones(zs,20,'sand');}};},
});
/* regional bosses: the Lich King's phase structure (bolts / rain / sweep, p2 spiral, p3 rays + nova) re-skinned per boss, plus one signature move */
function mkBoss(th){
  return function(e){
    const c=ecen(e),p=aimPos(),a=angTo(c,p),d=Math.hypot(p.x-c.x,p.y-c.y),p2=e.p2,p3=e.p3;
    const pool=[['bolts',th.w[0]],['rain',th.w[1]],['sweep',d<150?45:6],['uniq',th.w[2]]];
    if(p2)pool.push(['spiral',40]);
    if(p3){pool.push(['ray',40]);pool.push(['nova',35]);}
    const k=pickW(pool),ph=p3?.8:p2?.9:1;
    if(k==='bolts'){const n=p3?7:p2?5:3,as=[];for(let i=0;i<n;i++)as.push(a+(i-(n-1)/2)*.3);const zs=as.map(q=>Z.line(c.x,c.y,q,470,14,19));
      return{windup:.95*ph,zones:zs,recover:.7,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.4;as.forEach(q=>fireProj(c.x,c.y,q,360,14,th.proj,7));}};}
    if(k==='rain'){const zs=scatterZones(c,p,p3?9:p2?7:5,34,30,170,19);return{windup:1.05*ph,zones:zs,recover:.7,strike(e){e.dragonOpen=.4;hitZones(zs,20,th.fx);}};}
    if(k==='sweep'){const z=Z.cone(c.x,c.y,a,150,1.0,19);return{windup:.8*ph,zones:[z],recover:.7,strike(e){e.hop=.3;hitZones([z],26,'slash');}};}
    if(k==='spiral'){const n=9,a0=Math.random()*6.283,zs=[];for(let i=0;i<n;i++){const ang=a0+i*.85,r=46+i*15;const w=scatterSpot(c,c,Math.cos(ang)*r,Math.sin(ang)*r,19);zs.push(Z.circle(w.x,w.y,32));}
      return{windup:.5,zones:[],recover:1.3,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;zs.forEach((z,i)=>schedule(i*.2,()=>{if(B.phase!=='fight')return;warnZones([z],.7);schedule(.7,()=>{if(B.phase==='fight')hitZones([z],18,th.fx);});}));}};}
    if(k==='ray'){const rays=o=>{const zs=[];for(let i=0;i<6;i++)zs.push(Z.line(c.x,c.y,o+i*Math.PI/3,330,32,19));return zs;};
      const o=Math.random()*6.283,A=rays(o),Bz=rays(o+Math.PI/6);
      return{windup:1.1,zones:A,recover:1.1,start(e){e.charge=1;},strike(e){e.dragonOpen=.5;e.charge=0;hitZones(A,26,th.fx);schedule(.25,()=>{if(B.phase!=='fight')return;warnZones(Bz,.85);schedule(.85,()=>{if(B.phase==='fight')hitZones(Bz,26,th.fx);});});}};}
    if(k==='nova'){const z=Z.ring(c.x,c.y,64,235,19);return{windup:1.2,zones:[z],recover:1.0,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.6;hitZones([z],32,th.fx);}};}
    return th.uniq(e,c,p,a,ph);
  };
}
ATK.rimegar=mkBoss({proj:'ice',fx:'frost',w:[30,35,40],   // signature: a frost star - 10 icicle lanes radiate from the titan
  uniq:(e,c,p,a,ph)=>{const o=Math.random()*6.283,zs=[];for(let i=0;i<10;i++)zs.push(Z.line(c.x,c.y,o+i*Math.PI/5,300,24,19));
    return{windup:1.15*ph,zones:zs,recover:.9,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.5;hitZones(zs,26,'frost');}};}});
ATK.mossback=mkBoss({proj:'spore',fx:'mire',w:[40,30,40],   // signature: three heads bite in a wide fan
  uniq:(e,c,p,a,ph)=>{const zs=[-.95,0,.95].map(o=>Z.cone(c.x,c.y,a+o,190,.36,19));
    return{windup:.95*ph,zones:zs,recover:.8,strike(e){e.hop=.3;hitZones(zs,28,'mire');}};}});
ATK.colossus=mkBoss({proj:'sandb',fx:'sand',w:[25,40,40],   // signature: a stomp - safe inside the ring, hit on the ring, then a second wave
  uniq:(e,c,p,a,ph)=>{const z=Z.ring(c.x,c.y,50,170,19),z2=Z.circle(c.x,c.y,230,19);
    return{windup:1.1*ph,zones:[z],recover:.9,start(e){e.charge=1;},strike(e){e.charge=0;e.dragonOpen=.4;e.hop=.4;hitZones([z],30,'sand');schedule(.5,()=>{if(B.phase!=='fight')return;warnZones([z2],.7);schedule(.7,()=>{if(B.phase==='fight')hitZones([z2],22,'sand');});});}};}});
