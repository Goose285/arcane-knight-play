/* =====================================================================
   PET + TROPHY + HOUSE ART (all code-drawn, original). 16x16 sprites.
   ===================================================================== */
SP.pets={};
SP.pets.cinder=autoOutline(makeSprite(16,16,g=>{
  rect(g,3,7,9,5,'#e07a2a');rect(g,4,6,7,2,'#f0a050');rect(g,10,4,5,5,'#e07a2a');rect(g,11,5,3,3,'#f0a050');rect(g,14,6,2,2,'#2a1810');
  rect(g,10,2,2,3,'#c0561a');rect(g,13,2,2,3,'#c0561a');rect(g,12,6,1,1,'#fff');rect(g,4,12,2,3,'#c0561a');rect(g,9,12,2,3,'#c0561a');
  rect(g,1,5,3,3,'#ff6a1f');rect(g,0,3,2,3,'#ffd23f');rect(g,2,4,1,2,'#fff3a0');}),'#2a1408');
SP.pets.wisp=autoOutline(makeSprite(16,16,g=>{
  ell(g,8,8,5,6,'#6fc4f0');ell(g,8,9,3,4,'#bfe9ff');tri(g,4,13,8,16,12,13,'#6fc4f0');rect(g,6,6,1,2,'#10304a');rect(g,10,6,1,2,'#10304a');
  rect(g,7,1,2,3,'#effaff');rect(g,3,3,1,1,'#fff');rect(g,13,5,1,1,'#fff');}),'#0c2a40');
SP.pets.moth=autoOutline(makeSprite(16,16,g=>{
  ell(g,4,7,4,5,'#a060e0');ell(g,12,7,4,5,'#a060e0');ell(g,4,7,2,3,'#d8a8ff');ell(g,12,7,2,3,'#d8a8ff');rect(g,7,4,2,8,'#4a2a6a');
  rect(g,7,3,2,2,'#e8d8ff');rect(g,6,1,1,3,'#4a2a6a');rect(g,9,1,1,3,'#4a2a6a');rect(g,3,5,1,1,'#fff');rect(g,12,5,1,1,'#fff');}),'#1e0c32');
SP.pets.pebblin=autoOutline(makeSprite(16,16,g=>{
  rect(g,3,5,10,8,'#9a927f');rect(g,4,4,8,2,'#b8b0a0');rect(g,2,8,2,4,'#807866');rect(g,12,8,2,4,'#807866');rect(g,5,13,2,2,'#6a6454');rect(g,9,13,2,2,'#6a6454');
  rect(g,5,7,2,2,'#ffd23f');rect(g,9,7,2,2,'#ffd23f');rect(g,6,7,1,1,'#2a2010');rect(g,10,7,1,1,'#2a2010');rect(g,6,11,4,1,'#5a5444');}),'#1c1810');
/* trophies, drawn on a small pedestal */
const trophyBase=(g,col)=>{rect(g,3,12,10,3,'#5a4a3a');rect(g,4,11,8,2,'#7a6a52');rect(g,3,12,10,1,'#9a8a6a');};
SP.trophy={};
SP.trophy.fang=autoOutline(makeSprite(16,16,g=>{trophyBase(g);tri(g,5,11,11,11,8,1,'#f4ecd8');tri(g,6,11,9,11,8,3,'#fff');rect(g,5,10,6,1,'#c8b890');}),'#1a1408');
SP.trophy.crown=autoOutline(makeSprite(16,16,g=>{trophyBase(g);rect(g,4,7,8,4,'#2a6a4a');rect(g,4,6,2,2,'#7dffa0');rect(g,7,4,2,4,'#7dffa0');rect(g,10,6,2,2,'#7dffa0');rect(g,5,9,6,1,'#b0ffd0');rect(g,7,8,2,1,'#fff');}),'#08180e');
SP.trophy.horn=autoOutline(makeSprite(16,16,g=>{trophyBase(g);tri(g,4,11,9,11,11,2,'#bfe9ff');tri(g,6,11,9,11,10,4,'#effaff');rect(g,4,10,5,1,'#6fc4f0');}),'#0c2030');
SP.trophy.eye=autoOutline(makeSprite(16,16,g=>{trophyBase(g);ell(g,8,7,4,4,'#4a7a22');ell(g,8,7,3,3,'#c8f060');rect(g,7,5,2,4,'#10200a');rect(g,6,5,1,1,'#fff');}),'#0c1806');
SP.trophy.idol=autoOutline(makeSprite(16,16,g=>{trophyBase(g);rect(g,5,3,6,8,'#c8a040');rect(g,6,4,4,6,'#e8c860');rect(g,6,5,1,2,'#3a2a08');rect(g,9,5,1,2,'#3a2a08');rect(g,7,8,2,1,'#3a2a08');}),'#241a06');
SP.trophy.laurel=autoOutline(makeSprite(16,16,g=>{trophyBase(g);for(let i=0;i<5;i++){rect(g,3+i,9-i,2,2,'#3aaa3a');rect(g,11-i,9-i,2,2,'#3aaa3a');}rect(g,7,3,2,3,'#ffd23f');rect(g,7,10,2,1,'#e8504a');}),'#082008');
SP.trophy.brand=autoOutline(makeSprite(16,16,g=>{trophyBase(g);rect(g,4,3,8,8,'#4a4650');rect(g,5,4,6,6,'#6a6670');tri(g,8,4,5,10,11,10,'#ff7a3a');tri(g,8,6,6,10,10,10,'#ffd23f');}),'#140a06');
SP.trophy.banner=autoOutline(makeSprite(16,16,g=>{trophyBase(g);rect(g,7,1,2,10,'#6a4a2a');rect(g,3,2,10,6,'#d84a3a');tri(g,3,8,13,8,8,12,'#d84a3a');rect(g,6,4,4,2,'#ffd23f');}),'#2a0c08');
SP.houseSign=autoOutline(makeSprite(16,16,g=>{rect(g,7,5,2,10,'#6a4a2a');rect(g,2,2,12,7,'#c89a52');rect(g,3,3,10,5,'#e8c07a');rect(g,5,5,6,1,'#7a5a2a');rect(g,5,7,4,1,'#7a5a2a');}),'#2a1a08');
SP.keeper=person({body:'#6a4a8a',bodyL:'#a07ac8',bodyD:'#42285e',hair:'#d8a050',dir:'d',belt:'#e8d070'});
SP.bed=autoOutline(makeSprite(16,16,g=>{rect(g,1,6,14,8,'#7a5a3a');rect(g,2,5,12,3,'#e8e0d0');rect(g,2,8,12,5,'#c8504a');rect(g,2,8,12,1,'#e8806a');rect(g,1,5,2,10,'#5a3e22');}),'#1a1008');
SP.shelfPost=autoOutline(makeSprite(16,16,g=>{rect(g,2,10,12,4,'#7a5a3a');rect(g,3,6,10,5,'#9a7a4a');rect(g,3,6,10,1,'#c8a060');rect(g,5,3,6,3,'#e8d070');rect(g,7,1,2,3,'#ffe14d');}),'#1a1008');
