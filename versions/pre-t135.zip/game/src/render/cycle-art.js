/* =====================================================================
   DAY / SUNSET / NIGHT art direction (M18).  Everything here is procedural + original.
   Tiles: LN lantern post, FR campfire (animated), PW pond water (sparkles + lily pads, animated), PR pond rim stones. All solid.
   Per frame: soft tree shadows that swing and lengthen with the sun, butterflies (day), falling blossom petals, and at night
   fireflies + faint stars.  The colour grade blends continuously from DAY.t (see dayGrade) over the 8-minute cycle.
   Performance: one cached sprite per shadow/tile, ~20 butterfly/firefly cells, <=14 petal emitters, one multiply fill.
   ===================================================================== */
const CY={sn:0,bn:0,sh:new Int16Array(1800),bl:new Int16Array(200),shadow:null};
Object.assign(T,{LN:55,FR:56,PW:57,PR:58});
[T.LN,T.FR,T.PW,T.PR].forEach(t=>SOLID.add(t));
Object.assign(TSPR.mini,{[T.LN]:'#ffc23a',[T.FR]:'#ff7a1f',[T.PW]:'#3a7fd5',[T.PR]:'#8a8d9c'});
(function buildCycleArt(){
  const grass=v=>TSPR[T.G][v];
  TSPR[T.LN]=[0,1].map(v=>makeSprite(16,16,g=>{g.drawImage(grass(v),0,0);
    ell(g,8,15,4,1,'rgba(0,0,0,.25)');rect(g,6,14,4,2,'#2c2733');rect(g,7,7,2,8,'#3a3440');rect(g,7,7,1,8,'#544c60');
    rect(g,4,1,8,1,'#2c2733');rect(g,5,0,6,1,'#3a3440');rect(g,4,2,1,6,'#2c2733');rect(g,11,2,1,6,'#2c2733');rect(g,4,7,8,1,'#2c2733');
    rect(g,5,2,6,5,'#ffbe4a');rect(g,6,3,4,3,'#ffe27a');rect(g,7,4,2,2,'#fff6c8');rect(g,5,2,1,5,'#e08a2a');rect(g,8,2,1,5,'#c97a1c');}));
  TSPR[T.FR]=[0,1,2,3].map(f=>makeSprite(16,16,g=>{g.drawImage(grass(1),0,0);
    ell(g,8,13,7,3,'rgba(0,0,0,.28)');
    for(const [x,y] of [[2,12],[3,14],[5,15],[8,15],[11,15],[13,13],[13,11],[12,9],[3,10],[1,12]]){rect(g,x,y-1,3,2,'#6a6e7c');rect(g,x,y-1,3,1,'#9a9eac');}
    line(g,3,13,13,11,'#4a2c14');line(g,3,11,13,13,'#6b4423');rect(g,4,12,2,1,'#8a5a2c');
    const h=[7,9,8,10][f],sw=[0,1,0,-1][f];
    tri(g,8+sw,12-h,4,12,12,12,'#e8531c');tri(g,8+sw,12-h+2,5,12,11,12,'#ff9a2a');tri(g,8+(sw>>1),12-h+4,6,12,10,12,'#ffd84a');rect(g,7,9,2,3,'#fff3b0');
    rect(g,3+f*2,4-(f&1),1,1,'#ffb040');rect(g,12-f,3+f,1,1,'#ff8a2a');}));
  TSPR[T.PW]=[0,1].flatMap(lv=>[0,1,2,3].map(f=>makeSprite(16,16,g=>{
    rect(g,0,0,16,16,'#2f72c8');rect(g,0,8,16,8,'#2a66b8');rect(g,0,0,16,3,'#4a90e0');
    for(let i=0;i<3;i++){const y=(i*5+f*2)%16,x=(i*7+f*3)%11;rect(g,x,y,4,1,'#8cc8ff');rect(g,x+6,(y+4)%16,3,1,'#2458a0');}
    const pads=lv?[[9,4],[4,11]]:[[3,5],[10,10]];
    pads.forEach(([px,py],k)=>{ell(g,px+2,py+1,3,2,'#2c8a3c');ell(g,px+2,py+1,2,1,'#4cb04c');rect(g,px+2,py+1,3,1,'#2f72c8');rect(g,px,py,1,1,'#6ad060');
      if(k===0){rect(g,px+1,py-1,2,2,lv?'#fff':'#ff8ab8');rect(g,px+1,py-1,1,1,'#ffe98a');}});
    const sp=[[2,3],[11,6],[6,12],[13,13]];for(let i=0;i<2;i++){const [sx,sy]=sp[(f+i*2)%4];rect(g,sx,sy,1,1,'#ffffff');if(f%2===i){rect(g,sx-1,sy,3,1,'#cfe8ff');rect(g,sx,sy-1,1,3,'#cfe8ff');rect(g,sx,sy,1,1,'#fff');}}
  })));
  TSPR[T.PR]=[0,1].map(v=>makeSprite(16,16,g=>{rect(g,0,0,16,16,'#8e91a0');for(let y=0;y<16;y+=5){rect(g,0,y+4,16,1,'#5a5e70');const off=((y/5)+v)%2?0:5;for(let x=off;x<16;x+=10)rect(g,x,y,1,4,'#5a5e70');}
    rect(g,0,0,16,2,'#b4b7c4');rect(g,0,2,16,1,'#a0a3b2');sprinkle(g,v+41,['#7a7d8c','#a4a7b6'],8);rect(g,3+v*6,11,3,1,'#5a8a46');rect(g,10-v*5,6,2,1,'#6a9a52');}));
  // soft tree shadow (stretched by drawTreeShadows)
  CY.shadow=makeSprite(32,12,g=>{for(const [rx,ry,a] of [[15,5,.16],[13,4,.18],[10,3,.2],[6,2,.2]])ell(g,16,6,rx,ry,`rgba(12,30,28,${a})`);});
})();
/* ---------- state + sunset/day grade ---------- */
function dayGrade(){
  const t=DAY.t,m=Math.min(t,1-t),n=DAY.nightAmt;
  let s=clamp(1-Math.abs(m-.21)/.12,0,1);s=s*s*(3-2*s);           // dawn / dusk glow, peaks 0.21 of a cycle from midnight
  const dusk=t>.5,lamp=clamp(n+(dusk?.85:.3)*s,0,1);
  const e=Math.max(0,Math.sin((t-.25)*6.283185));                  // sun height 0..1
  return {s,n,lamp,e,day:clamp(1-n-s,0,1)};
}
function drawGrade(G){
  const lerpC=(a,b,k)=>[lerp(a[0],b[0],k),lerp(a[1],b[1],k),lerp(a[2],b[2],k)];
  let c=lerpC([255,249,232],[255,196,146],G.s);                    // warm late-morning cream -> sunset orange
  c=lerpC(c,[255,255,255],G.n);
  if(c[0]<254.5||c[1]<254.5||c[2]<254.5){ctx.save();ctx.globalCompositeOperation='multiply';ctx.fillStyle=`rgb(${c[0]|0},${c[1]|0},${c[2]|0})`;ctx.fillRect(0,0,VW,VH);ctx.restore();}
  if(G.s>.02){ctx.fillStyle=`rgba(255,120,40,${.13*G.s*(1-G.n)})`;ctx.fillRect(0,0,VW,VH);}
}
/* ---------- soft shadows ---------- */
const SHADOW_TILE=new Uint8Array(64);[T.T,T.PN,T.PM,T.AC,T.RE,T.LN].forEach(t=>SHADOW_TILE[t]=1);
function drawTreeShadows(){
  const n=CY.sn;if(!n)return;
  const G=dayGrade(),a0=.9*(1-G.n*.85);if(a0<.04)return;
  const sunA=((DAY.t-.25)/.5),dx=clamp(sunA*2-1,-1,1),e=G.e,L=.8+2.1*Math.pow(1-e,2.2);
  const w=Math.round(30*(.75+.45*L)),h=12,ox=dx*L*9,aa=a0*(.45+.55*Math.min(1,e*3.5+.25));
  const cx=Math.round(cam.x),cy=Math.round(cam.y);
  ctx.save();ctx.globalAlpha=Math.min(1,aa);
  const bk=BIGTREE>1?1+(BIGTREE-1)*.55:1,wb=Math.round(w*bk),hb=Math.round(h*bk);   // big trees cast a bigger shadow
  for(let i=0;i<n;i+=2){const x=CY.sh[i],y=CY.sh[i+1];
    if(bk>1&&BIGTREE_IDS.has(map[y][x]))ctx.drawImage(CY.shadow,Math.round(x*TS+16+ox*bk-wb/2-cx),Math.round(y*TS+TS-9-(hb-h)*.4-cy),wb,hb);
    else ctx.drawImage(CY.shadow,Math.round(x*TS+16+ox-w/2-cx),Math.round(y*TS+TS-9-cy),w,h);}
  ctx.restore();
}
/* ---------- ambient life: butterflies (day), petals, fireflies (night) ---------- */
const BF_COL=[['#ff9a3d','#ffd27a'],['#ffe14d','#fff3a8'],['#8ab8ff','#d6e6ff'],['#ff8ab8','#ffd0e4'],['#ffffff','#d8e6ff'],['#c890ff','#e6ccff']];
function ambientCells(cell,dens,fn){
  const px=cell*TS,x0=Math.floor(cam.x/px)-1,y0=Math.floor(cam.y/px)-1,x1=Math.floor((cam.x+VW)/px)+1,y1=Math.floor((cam.y+VH)/px)+1;
  for(let cy=y0;cy<=y1;cy++)for(let cx=x0;cx<=x1;cx++){const h=hash2(cx+300,cy+700);if(h%100>=dens)continue;
    const bx=(cx+((h>>8)&255)/256)*px,by=(cy+((h>>16)&255)/256)*px;fn(bx,by,h);}
}
function ambientOk(x,y){const tx=Math.floor(x/TS),ty=Math.floor(y/TS);if(tx<1||ty<1||tx>=MW-1||ty<OWY0||ty>=OWY0+OW_H||solidTile(tx,ty))return false;return !inChapel(tx,ty)&&!regions.castle(tx,ty);}
function drawAmbientDay(){
  if(B||zoneOfPx(P.y)!=='ow'){CY.bn=0;return;}
  const G=dayGrade(),ca=Math.round(cam.x),cb=Math.round(cam.y);
  const a=(1-G.n)*clamp(1-G.s*.7,0,1);
  if(a>.08){
    ambientCells(6,34,(bx,by,h)=>{
      const t=gtime*(.45+(h&7)*.05)+(h&1023),x=bx+Math.sin(t*1.1)*46+Math.sin(t*2.3)*14,y=by+Math.cos(t*.9)*34+Math.sin(t*1.7)*10;
      if(!ambientOk(x,y))return;
      const c=BF_COL[(h>>4)%BF_COL.length],fl=Math.sin(gtime*(14+(h&3))+h)>0?1:0,sx=Math.round(x-ca),sy=Math.round(y-cb);
      ctx.globalAlpha=a;ctx.fillStyle='rgba(0,0,0,.18)';ctx.fillRect(sx,sy+12,3,1);
      ctx.fillStyle=c[0];if(fl){ctx.fillRect(sx-3,sy-2,3,3);ctx.fillRect(sx+2,sy-2,3,3);ctx.fillStyle=c[1];ctx.fillRect(sx-2,sy-1,1,1);ctx.fillRect(sx+3,sy-1,1,1);}
      else{ctx.fillRect(sx-2,sy-1,2,2);ctx.fillRect(sx+1,sy-1,2,2);ctx.fillStyle=c[1];ctx.fillRect(sx-2,sy-1,1,1);ctx.fillRect(sx+2,sy-1,1,1);}
      ctx.fillStyle='#3a2a2a';ctx.fillRect(sx,sy-1,1,3);ctx.globalAlpha=1;});
  }
  // falling blossom petals under purple trees
  const pa=1-G.n*.5;
  for(let i=0;i<CY.bn&&i<28;i+=2){const x=CY.bl[i],y=CY.bl[i+1];
    for(let k=0;k<3;k++){const ph=(gtime*.3+(((x*7+y*13+k*37)%100)/100))%1,px=x*TS+10+k*5+Math.sin(ph*9+k*2+x)*8+ph*12,py=y*TS+4+ph*38;
      ctx.globalAlpha=Math.sin(ph*Math.PI)*.95*pa;ctx.fillStyle=k===0?'#f6b8ee':k===1?'#d8a2f6':'#fff0fa';ctx.fillRect(Math.round(px-ca),Math.round(py-cb),2,2);}}
  ctx.globalAlpha=1;
}
function drawNightFx(){            // called from drawLighting, on top of the dark layer
  const n=DAY.nightAmt;if(n<.06||B)return;const z=zoneOfPx(P.y);if(z!=='ow'&&z!=='swamp')return;
  const ca=Math.round(cam.x),cb=Math.round(cam.y);
  ambientCells(5,42,(bx,by,h)=>{
    const t=gtime*.6+(h&1023),x=bx+Math.sin(t*1.3)*30+Math.sin(t*.7)*20,y=by+Math.cos(t*1.1)*26;
    if(z==='ow'&&!ambientOk(x,y))return;
    const pu=.35+.65*Math.max(0,Math.sin(gtime*2.2+(h&63))),sx=Math.round(x-ca),sy=Math.round(y-cb);
    ctx.globalAlpha=n*pu*.28;ctx.fillStyle='#d8ff7a';ctx.fillRect(sx-3,sy-3,7,7);
    ctx.globalAlpha=n*(.5+.5*pu);ctx.fillStyle='#f4ffb0';ctx.fillRect(sx,sy,2,2);});
  if(!TOUCH||VW>=700||true){for(let i=0;i<22;i++){const hh=hash2(i*31+5,77),sx=hh%VW,sy=(hh>>10)%Math.floor(VH*.7);
    const tw=Math.sin(gtime*(1.2+(i%5)*.4)+i*1.7);if(tw<.2)continue;ctx.globalAlpha=n*.3*tw;ctx.fillStyle='#e8ecff';ctx.fillRect(sx,sy,1,1);if(i%4===0){ctx.fillRect(sx-1,sy,3,1);ctx.fillRect(sx,sy-1,1,3);}}}
  ctx.globalAlpha=1;
}
