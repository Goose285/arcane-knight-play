/* telegraphed-zone fill/stroke and projectile colours per damage theme */
const FXC={void:['rgba(110,255,170,.65)','#e8fff0'],frost:['rgba(130,205,255,.65)','#effaff'],mire:['rgba(120,170,60,.65)','#e6ffb0'],sand:['rgba(235,185,80,.65)','#fff3cf']};
const PETC={ember:['255,150,60','#ff9a3d','#fff3cf'],pfrost:['150,220,255','#8fd8ff','#ffffff'],spark:['200,150,255','#c58bff','#ffffff'],pebble:['150,140,120','#a49c88','#d8d0bc']};
const PROJC={soul:['125,255,170','#7dffa0','#eafff0'],ice:['150,220,255','#8fd8ff','#ffffff'],spore:['170,230,90','#9ad03a','#f0ffc0'],sandb:['255,200,90','#e8a838','#fff3cf']};

/* ---- combat rendering (world space) ---- */
function drawCombatGround(){
  const b=B,tg=b.target;
  if(b.dim>0&&tg&&!tg.dying){
    ctx.save();ctx.globalAlpha=.35*b.dim;ctx.strokeStyle=b.fleeT>0?'#ffb0a0':'#9ab8ff';ctx.lineWidth=2;ctx.setLineDash([10,10]);ctx.lineDashOffset=-gtime*20;
    ctx.beginPath();ctx.arc(tg.x,tg.y-4,FLEE_DIST-20,0,6.283);ctx.stroke();ctx.restore();
  }
  // target marker under the enemy the player is auto-aiming at
  if(tg&&!tg.dying&&b.ens.length>1&&b.phase==='fight'){
    ctx.save();ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.globalAlpha=.7+.3*Math.sin(gtime*8);ctx.beginPath();ctx.ellipse(tg.x,tg.y-1,eRad(tg)+7,(eRad(tg)+7)*.4,0,0,6.283);ctx.stroke();ctx.restore();
  }
  for(const w of b.zones){
    const p=w.t/w.dur,last=p>.72,fl=Math.floor(gtime*12)%2===0;
    shapePath(w);ctx.fillStyle=last?`rgba(255,40,30,${.55+.2*(fl?1:0)})`:(fl?'rgba(255,225,70,.5)':'rgba(255,150,40,.45)');ctx.fill();
    shapePath(w,p);ctx.fillStyle=last?'rgba(255,80,60,.55)':'rgba(255,240,150,.35)';ctx.fill();
    shapePath(w);ctx.strokeStyle=last?'#fff':'#fff6b0';ctx.lineWidth=2;ctx.stroke();
  }
  drawBossPools();drawExtrasGround();
}
function drawShot(s){
  const a=Math.atan2(s.vy,s.vx);
  if(s.kind==='pet'){const pc3=PETC[s.pk]||PETC.ember;for(let i=1;i<5;i++){ctx.fillStyle=`rgba(${pc3[0]},${.4-i*.07})`;ctx.beginPath();ctx.arc(s.x-Math.cos(a)*i*5,s.y-Math.sin(a)*i*5,6-i,0,6.283);ctx.fill();}ctx.fillStyle=pc3[1];ctx.beginPath();ctx.arc(s.x,s.y,s.pk==='pebble'?6:4.5,0,6.283);ctx.fill();ctx.fillStyle=pc3[2];ctx.beginPath();ctx.arc(s.x,s.y,2,0,6.283);ctx.fill();}
  else if(s.kind==='arcane'){ctx.fillStyle='rgba(255,230,90,.35)';ctx.beginPath();ctx.ellipse(s.x-s.vx*.025,s.y-s.vy*.025,14,3,a,0,6.283);ctx.fill();ctx.fillStyle='#ffe14d';ctx.beginPath();ctx.arc(s.x,s.y,5,0,6.283);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(s.x,s.y,2.5,0,6.283);ctx.fill();}
  else if(s.kind==='charged'){for(let i=1;i<5;i++){ctx.fillStyle=`rgba(125,249,255,${.35-i*.06})`;ctx.beginPath();ctx.arc(s.x-Math.cos(a)*i*9,s.y-Math.sin(a)*i*9,12-i*1.6,0,6.283);ctx.fill();}ctx.fillStyle='#7df9ff';ctx.beginPath();ctx.arc(s.x,s.y,12,0,6.283);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(s.x,s.y,7,0,6.283);ctx.fill();}
  else if(s.kind==='fire'){for(let i=1;i<6;i++){ctx.fillStyle=`rgba(255,${120+i*20},40,${.5-i*.07})`;ctx.beginPath();ctx.arc(s.x-Math.cos(a)*i*6+Math.sin(gtime*30+i)*1.5,s.y-Math.sin(a)*i*6,9-i,0,6.283);ctx.fill();}ctx.fillStyle='#ff6a1f';ctx.beginPath();ctx.arc(s.x,s.y,9,0,6.283);ctx.fill();ctx.fillStyle='#ffd23f';ctx.beginPath();ctx.arc(s.x,s.y,5.5,0,6.283);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(s.x+1,s.y,2.3,0,6.283);ctx.fill();}
  else if(s.kind==='goo'){ctx.fillStyle='#3fae4a';ctx.beginPath();ctx.ellipse(s.x,s.y,8,6+Math.sin(gtime*14)*1.2,0,0,6.283);ctx.fill();ctx.fillStyle='#9af09a';ctx.fillRect(s.x-4,s.y-3,3,2);}
  else if(PROJC[s.kind]){const pc2=PROJC[s.kind];for(let i=1;i<6;i++){ctx.fillStyle=`rgba(${pc2[0]},${.45-i*.07})`;ctx.beginPath();ctx.arc(s.x-Math.cos(a)*i*7,s.y-Math.sin(a)*i*7,8-i,0,6.283);ctx.fill();}ctx.fillStyle=pc2[1];ctx.beginPath();ctx.arc(s.x,s.y,7,0,6.283);ctx.fill();ctx.fillStyle=pc2[2];ctx.beginPath();ctx.arc(s.x,s.y,3,0,6.283);ctx.fill();}
  else if(s.kind==='arrow'){ctx.save();ctx.translate(s.x,s.y);ctx.rotate(a);ctx.fillStyle='rgba(255,255,255,.25)';ctx.fillRect(-34,-1,26,2);ctx.fillStyle='#a0713a';ctx.fillRect(-12,-1,22,3);ctx.fillStyle='#e8e8ee';ctx.beginPath();ctx.moveTo(14,.5);ctx.lineTo(8,-4);ctx.lineTo(8,5);ctx.fill();ctx.fillStyle='#d8d8d8';ctx.fillRect(-14,-3,4,2);ctx.fillRect(-14,2,4,2);ctx.restore();}
}
function drawFx(f){
  const p=f.t/f.dur,z=f.z;
  if(f.k==='boom'){
    if(z.k==='circle'){const r=z.r*(.35+.65*Math.min(1,p*2.2));ctx.globalAlpha=1-p;ctx.fillStyle='#ff7a2a';ctx.beginPath();ctx.arc(z.x,z.y,r,0,6.283);ctx.fill();ctx.fillStyle='#ffd23f';ctx.beginPath();ctx.arc(z.x,z.y,r*.65,0,6.283);ctx.fill();ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(z.x,z.y,r*.3,0,6.283);ctx.fill();ctx.globalAlpha=1;}
    else{ctx.globalAlpha=1-p;shapePath(z);ctx.fillStyle='#ffd23f';ctx.fill();ctx.globalAlpha=1;}
  }
  else if(f.k==='fire'){ctx.globalAlpha=Math.min(1,(1-p)*2);shapePath(z);ctx.fillStyle='rgba(255,100,30,.75)';ctx.fill();
    const n=z.k==='circle'?6:z.k==='cone'?12:10;
    for(let i=0;i<n;i++){const u=(i+.5)/n;let x,y;if(z.k==='cone'){const aa=z.a+(Math.sin(i*7.3)*z.half*.8),rr=Math.min(z.len*u,coneRay(z,aa));x=z.x+Math.cos(aa)*rr;y=z.y+Math.sin(aa)*rr;}else if(z.k==='line'){x=z.x+Math.cos(z.a)*z.len*u;y=z.y+Math.sin(z.a)*z.len*u;}else{x=z.x+Math.cos(i*2.1)*z.r*.6;y=z.y+Math.sin(i*2.1)*z.r*.6;}
      const h=(1-p*p)*(22+Math.sin(gtime*30+i*2)*5);ctx.fillStyle=i%2?'#ff6a1f':'#ffb02f';ctx.beginPath();ctx.ellipse(x,y-h/3,6,h/2,0,0,6.283);ctx.fill();ctx.fillStyle='#ffe99a';ctx.beginPath();ctx.ellipse(x,y-h/4,3,h/3,0,0,6.283);ctx.fill();}
    ctx.globalAlpha=1;}
  else if(FXC[f.k]){ctx.globalAlpha=Math.min(1,(1-p)*1.8);shapePath(z,Math.min(1,.55+p*1.2));ctx.fillStyle=FXC[f.k][0];ctx.fill();ctx.strokeStyle=FXC[f.k][1];ctx.lineWidth=2;ctx.stroke();ctx.globalAlpha=1;}
  else if(f.k==='slash'){ctx.globalAlpha=(1-p)*.8;shapePath(z);ctx.fillStyle='#fff';ctx.fill();ctx.strokeStyle='#8fd0ff';ctx.lineWidth=3;ctx.stroke();ctx.globalAlpha=1;}
  else if(f.k==='lance'){const l=z.len*Math.min(1,p*4);ctx.globalAlpha=1-p*p;const dx=Math.cos(z.a),dy=Math.sin(z.a);ctx.save();ctx.translate(z.x,z.y);ctx.rotate(z.a);ctx.fillStyle='#c9a3ff';ctx.fillRect(0,-8,l,16);ctx.fillStyle='#fff';ctx.fillRect(0,-3,l,6);ctx.beginPath();ctx.moveTo(l+16,0);ctx.lineTo(l,-9);ctx.lineTo(l,9);ctx.fill();ctx.restore();ctx.globalAlpha=1;}
  else if(f.k==='arc'){ctx.globalAlpha=1-p;const r=z.r;ctx.strokeStyle='#fff';ctx.lineWidth=7*(1-p)+2;ctx.beginPath();ctx.arc(z.x,z.y,r*.8,z.a-1.1+p*1.4,z.a-1.1+p*1.4+1.0);ctx.stroke();ctx.strokeStyle='#8fd0ff';ctx.lineWidth=3;ctx.beginPath();ctx.arc(z.x,z.y,r*.95,z.a-1.1+p*1.4,z.a-1.1+p*1.4+.9);ctx.stroke();ctx.globalAlpha=1;}
  else if(f.k==='iceburst'){
    const q=Math.min(1,p*3.2),fade=p<.65?1:1-(p-.65)/.35,r=z.r;
    ctx.save();ctx.globalAlpha=.4*fade;ctx.fillStyle='#78cdff';ctx.beginPath();ctx.ellipse(z.x,z.y,r*q,r*q*.62,0,0,6.283);ctx.fill();
    ctx.globalAlpha=.95*fade;ctx.strokeStyle='#e8fbff';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(z.x,z.y,r*q,r*q*.62,0,0,6.283);ctx.stroke();
    const n=z.r>50?10:6,gr=Math.min(1,p*4.5);
    for(let i=0;i<=n;i++){const big=i===n,ang=i*2.4+.5,rr=big?0:(i%2?.42:.78)*r*q,x=z.x+Math.cos(ang)*rr,y=z.y+Math.sin(ang)*rr*.62,h=(big?(z.r>50?48:36):(16+(i%3)*8))*gr,w=big?9:5;
      ctx.globalAlpha=fade;ctx.fillStyle=i%2?'#a8e8ff':'#7fd0ff';ctx.beginPath();ctx.moveTo(x-w,y);ctx.lineTo(x,y-h);ctx.lineTo(x+w,y);ctx.closePath();ctx.fill();
      ctx.fillStyle='#effcff';ctx.beginPath();ctx.moveTo(x-w,y);ctx.lineTo(x,y-h);ctx.lineTo(x-w*.2,y);ctx.closePath();ctx.fill();}
    if(p<.18){ctx.globalAlpha=(1-p/.18)*.9;ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(z.x,z.y,r*.5,0,6.283);ctx.fill();}
    ctx.restore();
  }
  else if(f.k==='bloodburst'){
    const q=Math.min(1,p*3),fade=p<.7?1:1-(p-.7)/.3,r=z.r,pc=pcen();
    ctx.save();ctx.globalAlpha=.42*fade;ctx.fillStyle='#8a1226';ctx.beginPath();ctx.ellipse(z.x,z.y,r*q,r*q*.62,0,0,6.283);ctx.fill();
    ctx.globalAlpha=.9*fade;ctx.strokeStyle='#ff5a6a';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(z.x,z.y,r*q,r*q*.62,0,0,6.283);ctx.stroke();
    const n=z.r>50?8:4;
    for(let i=0;i<n;i++){
      const ang=i*6.283/n+.4,u=Math.min(1,p/.5),v=Math.max(0,(p-.5)/.5),e2=v*v*(3-2*v);
      let x=z.x+Math.cos(ang)*r*.55*(1-u*.5),y=z.y-u*(26+(i%3)*12)+Math.sin(ang)*r*.2;
      x+= (pc.x-x)*e2;y+=(pc.y-12-y)*e2;
      ctx.globalAlpha=v>.92?(1-v)*12:1;
      ctx.fillStyle='#6a0f1e';ctx.beginPath();ctx.arc(x,y,6.5,0,6.283);ctx.fill();ctx.fillStyle='#d42a44';ctx.beginPath();ctx.arc(x,y,5,0,6.283);ctx.fill();ctx.fillStyle='#ffb0ba';ctx.beginPath();ctx.arc(x-1.8,y-2,1.6,0,6.283);ctx.fill();
    }
    ctx.restore();
  }
  else if(f.k==='bloodheal'){ctx.globalAlpha=1-p;ctx.strokeStyle='#ff5a6a';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(z.x,z.y+10-p*26,18+p*8,7,0,0,6.283);ctx.stroke();ctx.globalAlpha=1;}
  else if(f.k==='quake'){const col=z.c||'#d9b27a',q=Math.min(1,p*2.4),fade=1-p;ctx.save();ctx.globalAlpha=.35*fade;ctx.fillStyle=col;ctx.beginPath();ctx.ellipse(z.x,z.y+4,z.r*q,z.r*q*.55,0,0,6.283);ctx.fill();
    for(let k=0;k<3;k++){const qq=Math.max(0,q-k*.18);ctx.globalAlpha=(.9-k*.25)*fade;ctx.strokeStyle=k?'#fff':col;ctx.lineWidth=4-k;ctx.beginPath();ctx.ellipse(z.x,z.y+4,z.r*qq,z.r*qq*.55,0,0,6.283);ctx.stroke();}
    ctx.globalAlpha=fade;ctx.strokeStyle='#3a2a1a';ctx.lineWidth=2;for(let i=0;i<9;i++){const an=i*.7+.3,r0=z.r*q*.2,r1=z.r*q*(.55+(i%3)*.15);ctx.beginPath();ctx.moveTo(z.x+Math.cos(an)*r0,z.y+4+Math.sin(an)*r0*.55);ctx.lineTo(z.x+Math.cos(an+.12)*(r0+r1)/2,z.y+4+Math.sin(an+.12)*(r0+r1)/2*.55);ctx.lineTo(z.x+Math.cos(an)*r1,z.y+4+Math.sin(an)*r1*.55);ctx.stroke();}
    ctx.restore();}
  else if(f.k==='wardpop'){const col=z.c||'#ffe9a0';ctx.save();ctx.globalAlpha=1-p;ctx.strokeStyle=col;ctx.lineWidth=4;ctx.beginPath();ctx.arc(z.x,z.y,20+p*60,0,6.283);ctx.stroke();ctx.restore();}
  else if(f.k==='steam'){ctx.save();const fade=1-p;for(let i=0;i<10;i++){const an=i*.63+1,r=z.r*(.2+.7*Math.min(1,p*2.2))*(.4+(i%4)*.2),x=z.x+Math.cos(an)*r,y=z.y-8+Math.sin(an)*r*.6-p*34;ctx.globalAlpha=.7*fade;ctx.fillStyle=i%2?'#ffffff':'#cfe9ff';ctx.beginPath();ctx.arc(x,y,12+(i%3)*5+p*8,0,6.283);ctx.fill();}
    ctx.globalAlpha=.5*fade;ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(z.x,z.y,z.r*Math.min(1,p*3),z.r*.6*Math.min(1,p*3),0,0,6.283);ctx.stroke();ctx.restore();}
  else if(f.k==='meteorboom'){const q=Math.min(1,p*3),fade=1-p;ctx.save();ctx.globalAlpha=fade;ctx.fillStyle='#ff5a1f';ctx.beginPath();ctx.ellipse(z.x,z.y,z.r*1.1*q,z.r*.7*q,0,0,6.283);ctx.fill();ctx.fillStyle='#ffb02f';ctx.beginPath();ctx.ellipse(z.x,z.y-6,z.r*.75*q,z.r*.5*q,0,0,6.283);ctx.fill();
    ctx.fillStyle='#fff6c0';ctx.beginPath();ctx.ellipse(z.x,z.y-10,z.r*.4*q,z.r*.28*q,0,0,6.283);ctx.fill();
    ctx.strokeStyle='#fff';ctx.lineWidth=3;ctx.globalAlpha=fade*.8;ctx.beginPath();ctx.ellipse(z.x,z.y,z.r*1.6*q,z.r*1.0*q,0,0,6.283);ctx.stroke();
    ctx.fillStyle='#3a2a2a';for(let i=0;i<7;i++){const an=i*.9,r=z.r*q*(.5+(i%3)*.3);ctx.globalAlpha=fade;ctx.fillRect(Math.round(z.x+Math.cos(an)*r),Math.round(z.y-p*60*(1-p)*(1+i%3)+Math.sin(an)*r*.5),4,4);}
    ctx.restore();}
  else if(f.k==='timering'){ctx.save();const q=Math.min(1,p*2.5);ctx.globalAlpha=(1-p)*.9;ctx.strokeStyle='#ffd23f';ctx.lineWidth=5;ctx.beginPath();ctx.arc(z.x,z.y,q*Math.max(VW,VH)*.6,0,6.283);ctx.stroke();ctx.lineWidth=2;ctx.strokeStyle='#fff';ctx.beginPath();ctx.arc(z.x,z.y,q*Math.max(VW,VH)*.6-8,0,6.283);ctx.stroke();ctx.restore();}
  else if(f.k==='heal'){ctx.globalAlpha=1-p;ctx.strokeStyle='#7dffa0';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(z.x,z.y-p*26,18+p*8,7,0,0,6.283);ctx.stroke();ctx.globalAlpha=1;}
}
function drawCombatTop(){
  const b=B;
  b.shots.forEach(drawShot);
  b.fx.forEach(drawFx);
  drawBossShields();drawExtrasTop();
  b.parts.forEach(q=>{ctx.globalAlpha=clamp(1-q.t/q.life,0,1);ctx.fillStyle=q.col;ctx.fillRect(Math.round(q.x),Math.round(q.y),q.sz,q.sz);});ctx.globalAlpha=1;
  b.texts.forEach(t=>{txt(t.s,t.x,t.y-t.t*28,{size:t.size,align:'center',col:t.col,alpha:clamp(2-t.t*1.8,0,1)});});
  const bounce=Math.abs(Math.sin(gtime*12))*5;
  if(b.phase==='alert'){const a=Math.min(1,b.t*5);txt('!',P.x,P.y-42-bounce,{size:26,align:'center',col:'#ffe14d',alpha:a});}
  for(const e of b.ens){
    if(e.dying)continue;
    if((b.phase==='alert'&&e.joinT<=0&&b.t<.8)||e.joinT>0){
      const a=b.phase==='alert'?Math.min(1,b.t*5):1;
      txt('!',e.x,e.y-(e.def.big?96:44)-bounce,{size:26,align:'center',col:'#ff4040',alpha:a});
    }
  }
}
