const TREE_FADE=new Map(),TREE_FADE_HERO=.55,TREE_FADE_NPC=.4;
function drawEntShadow(x,y,w){ctx.fillStyle='rgba(0,0,0,.28)';ctx.beginPath();ctx.ellipse(Math.round(x-cam.x),Math.round(y-cam.y)-1,w,w*.38,0,0,6.283);ctx.fill();}
function drawWorld(){
  const cx=Math.round(cam.x),cy=Math.round(cam.y);
  const x0=Math.floor(cx/TS),y0=Math.floor(cy/TS),x1=x0+Math.ceil(VW/TS)+1,y1=y0+Math.ceil(VH/TS)+1;
  CY.sn=0;CY.bn=0;const bigTrees=[];
  for(let y=y0;y<=y1;y++)for(let x=x0-1;x<=x1+1;x++){
    if(x<0||y<0||x>=MW||y>=MH)continue;
    const id=map[y][x];
    if(BIGTREE&&BIGTREE_IDS.has(id)){const L=treeLayers(id,x,y);ctx.drawImage(L.bg,x*TS-cx,y*TS-cy,TS,TS);bigTrees.push({x,y,fg:L.fg});}
    else ctx.drawImage(tileSprite(id,x,y,gtime),x*TS-cx,y*TS-cy,TS,TS);
    if(SHADOW_TILE[id]===1&&CY.sn<1796){CY.sh[CY.sn++]=x;CY.sh[CY.sn++]=y;if(id===T.T&&BLOSSOM[y*MW+x]===1&&CY.bn<196){CY.bl[CY.bn++]=x;CY.bl[CY.bn++]=y;}}
    if(id===T.Z)drawFlame(x*TS-cx+16,y*TS-cy+4);
  }
  drawTreeShadows();
  drawChurchFx();drawChurch2();drawChestGlints();drawRoutineSigns();
  ctx.save();ctx.translate(-cx,-cy);if(!B&&state!=='editor')drawVision();if(B)drawCombatGround();drawGuardBolts();ctx.restore();
  drawMapMarks();drawInnPorch(cx,cy);
  const ents=[];
  ents.push({y:(CHAPEL.cross.y)*TS+8,fn:drawChapelCross});
  if(WELLOPT)ents.push({y:(VILLAGE_POND.y0+3)*TS+24,fn:drawWellOverlay});   // mockup only
  if(bigTrees.length){   // big trees: y-sorted canopy that fades when the hero / an NPC / a quest marker is behind it
    const dyn=[{x:P.x,y:P.y,h:50,a:TREE_FADE_HERO}];for(const n of NPCS)if(Math.abs(n.x-P.x)<VW&&Math.abs(n.y-P.y)<VH)dyn.push({x:n.x,y:n.y,h:70,a:TREE_FADE_NPC});
    if(!B)for(const w of questWorldItems())dyn.push({x:w.tx*TS+16,y:w.ty*TS+20,h:56,a:TREE_FADE_NPC});
    if(PET.active)dyn.push({x:PET.x,y:PET.y,h:30,a:TREE_FADE_NPC});
    for(const e of enemies)if(e.alive&&!e.hidden)dyn.push({x:e.x,y:e.y,h:48,a:TREE_FADE_NPC});
    const k=BIGTREE,w=TS*k;
    for(const t of bigTrees)ents.push({y:t.y*TS+TS-3,fn:()=>{
      const bx=t.x*TS+TS/2,by=t.y*TS+TS,ti=t.y*TS*0+t.y*MW+t.x;let tgt=1;
      for(const d of dyn){if(d.y>=by-4)continue;if(Math.abs(d.x-bx)<w*.42&&d.y>by-w+4&&d.y-d.h<by-14){if(d.a<tgt)tgt=d.a;}}
      let f=TREE_FADE.get(ti);if(f===undefined)f=1;f+=(tgt-f)*.22;if(Math.abs(f-tgt)<.01)f=tgt;if(f>=.999)TREE_FADE.delete(ti);else TREE_FADE.set(ti,f);
      if(f<.999)ctx.globalAlpha=f;
      ctx.drawImage(t.fg,Math.round(bx-w/2-cx),Math.round(by-w-cy+2),w,w);ctx.globalAlpha=1;}});
  }
  for(const s of SPW)ents.push({y:s.y,fn:()=>drawSpawner(s)});
  for(const f of FISH_SPOTS)ents.push({y:f.ty*TS+TS-6,fn:()=>drawFishSpot(f)});
  ents.push({y:INN.y1*TS+30,fn:()=>drawInnSign(cx,cy)});
  ents.push({y:P.y,fn:()=>{drawDashFx();drawPlayerWorld();}});
  for(const n of NPCS)ents.push({y:n.y,fn:()=>{drawEntShadow(n.x,n.y,11);if(n.way)drawWayGlow(n);draw(n.way&&!SEC.ways[n.way]?SP.waystoneOff:SP[n.spr],n.x-cam.x-16,n.y-cam.y-31+Math.round(Math.sin(gtime*2+n.x)*.6),2);
    if(!B&&!DLG&&Math.hypot(n.x-P.x,n.y-P.y)<46)txt(TOUCH?'TAP':'E',n.x-cam.x,n.y-cam.y-38,{size:12,align:'center',col:'#ffe14d'});
    else if(!B&&!DLG)drawNpcMarker(n);}});
  if(!B)for(const w of questWorldItems())ents.push({y:w.ty*TS+20,fn:()=>drawQuestItem(w)});
  for(const e of enemies){if(!e.alive||e.hidden)continue;ents.push({y:e.y,fn:()=>drawEnemyWorld(e)});}
  if(PET.active)ents.push({y:PET.y,fn:drawPetWorld});
  drawHouseTrophies().forEach(o=>ents.push(o));
  ents.sort((a,b)=>a.y-b.y).forEach(o=>o.fn());
  drawWorldFx();drawGotoMark();drawFishingWorld();drawAmbientDay();
  if(B){ctx.save();ctx.translate(-cx,-cy);drawCombatTop();ctx.restore();}
  else if(WS.length){ctx.save();ctx.translate(-cx,-cy);WS.forEach(drawShot);ctx.restore();}
}
function drawPlayerWorld(){
  drawEntShadow(P.x,P.y,11);
  const f=P.moving?[1,0,2,0][Math.floor(P.anim)&3]:0;
  const fight=!!B&&B.phase!=='alert';
  if(B&&B.phase==='lose'&&Math.floor(B.t*14)%2)return;
  const blink=(B&&B.inv>0&&B.phase==='fight'&&Math.floor(gtime*18)%2===0);
  let spr=SP.hero[P.dir][f];
  if(B&&(P.dir==='r'||P.dir==='l'))spr=P.dir==='r'?SP.heroB[0]:SP.heroBL;
  let px=P.x-cam.x-16,py=P.y-cam.y-31;
  let lean=0;
  if(FISH.on&&!B){const po=fishPose();px+=po.ox;py+=po.oy;lean=po.lean;if(po.step&&SP.hero[P.dir])spr=SP.hero[P.dir][po.step];}   // casting swing / breathing / weight shift / lean on a bite / pull-back on the reel
  if(!blink){
    if(lean){ctx.save();ctx.translate(Math.round(px+16),Math.round(py+31));ctx.rotate(lean);ctx.translate(-Math.round(px+16),-Math.round(py+31));}
    if(B&&B.ghost>0)ctx.globalAlpha=.4;draw(spr,px,py,2);ctx.globalAlpha=1;
    drawGearOnPlayer(spr,px,py);
    if(B&&B.flash>0){ctx.globalAlpha=.8;draw(whiteOf(spr),px,py,2);ctx.globalAlpha=1;}
    if(lean)ctx.restore();
  }
  if(B){
    // arcane shot hand position by facing
    const hx=P.x-cam.x+(P.dir==='r'?16:P.dir==='l'?-16:P.dir==='u'?7:-7),hy=P.y-cam.y-(P.dir==='u'?22:15);
    if(B.shootAnim>0){ctx.fillStyle='rgba(255,240,150,.9)';ctx.beginPath();ctx.arc(hx,hy,4+B.shootAnim*24,0,6.283);ctx.fill();}
    if(B.charge>.25){const fr=Math.min(1,B.charge),full=fr>=1,r=3+fr*8+(full?Math.sin(gtime*40)*1.5:0);ctx.fillStyle=full?'rgba(255,255,255,.95)':'rgba(125,249,255,.8)';ctx.beginPath();ctx.arc(hx,hy,r,0,6.283);ctx.fill();ctx.strokeStyle='#7df9ff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(hx,hy,r+2.5,0,6.283);ctx.stroke();}
    if(B.barrier>0){const a=B.barrier<2?(Math.floor(gtime*10)%2?.9:.3):.9;ctx.globalAlpha=a*.6;ctx.fillStyle='rgba(120,240,255,.25)';ctx.beginPath();ctx.ellipse(P.x-cam.x,P.y-cam.y-14,19,23,0,0,6.283);ctx.fill();ctx.strokeStyle='#8ff0ff';ctx.lineWidth=2;ctx.stroke();ctx.globalAlpha=1;}
  }
  else if(WCH.on&&WCH.t>.25){    // charging a shot while exploring
    const hx=P.x-cam.x+(P.dir==='r'?16:P.dir==='l'?-16:P.dir==='u'?7:-7),hy=P.y-cam.y-(P.dir==='u'?22:15),fr=Math.min(1,WCH.t),full=fr>=1,r=3+fr*8+(full?Math.sin(gtime*40)*1.5:0);
    ctx.fillStyle=full?'rgba(255,255,255,.95)':'rgba(125,249,255,.8)';ctx.beginPath();ctx.arc(hx,hy,r,0,6.283);ctx.fill();ctx.strokeStyle='#7df9ff';ctx.lineWidth=1.5;ctx.beginPath();ctx.arc(hx,hy,r+2.5,0,6.283);ctx.stroke();
  }
}
/* an attuned waystone glows: pulsing cyan aura on the ground + rising sparks (the dormant ones stay dull grey) */
function drawWayGlow(n){
  if(!SEC.ways[n.way])return;
  const age=n.fxT!=null?gtime-n.fxT:9;
  if(age<2.4){   // just unlocked: expanding light ring + a flash + a column of rising sparkles
    const x0=n.x-cam.x,y0=n.y-cam.y-16,k=age/2.4;
    ctx.save();ctx.globalCompositeOperation='lighter';
    const fr=Math.min(1,age/.35)*(1-Math.min(1,age/.9)),g=ctx.createRadialGradient(x0,y0,0,x0,y0,60);g.addColorStop(0,`rgba(255,255,255,${.8*fr})`);g.addColorStop(1,'rgba(125,249,255,0)');ctx.fillStyle=g;ctx.fillRect(x0-60,y0-60,120,120);
    ctx.globalAlpha=(1-k)*.9;ctx.strokeStyle='#7df9ff';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(x0,y0+14,10+k*54,(10+k*54)*.4,0,0,6.283);ctx.stroke();
    ctx.globalCompositeOperation='source-over';ctx.fillStyle='#e8ffff';
    for(let i=0;i<10;i++){const u=(age*.55+i/10)%1;ctx.globalAlpha=(1-k)*(1-u);ctx.fillRect(Math.round(x0-18+i*4+Math.sin(age*5+i)*4),Math.round(y0+16-u*60),2,2+(i%2));}
    ctx.restore();
  }
  const x=n.x-cam.x,y=n.y-cam.y-16,p=.5+.5*Math.sin(gtime*2.6+n.x),r=34+6*p;
  ctx.save();ctx.globalCompositeOperation='lighter';
  const g=ctx.createRadialGradient(x,y,2,x,y,r);g.addColorStop(0,`rgba(125,249,255,${.42+.18*p})`);g.addColorStop(1,'rgba(125,249,255,0)');ctx.fillStyle=g;ctx.fillRect(x-r,y-r,r*2,r*2);
  ctx.globalCompositeOperation='source-over';ctx.fillStyle='#d8fdff';
  for(let i=0;i<4;i++){const k=(gtime*.7+i/4+n.y*.013)%1;ctx.globalAlpha=1-k;ctx.fillRect(Math.round(x-10+i*7+Math.sin(gtime*3+i)*3),Math.round(y+8-k*34),2,2);}
  ctx.restore();
}
function drawEnemyWorld(e){
  if(e.vanish>0&&B&&e.engaged&&!e.dying){const sx=e.x-cam.x,sy=e.y-cam.y;ctx.fillStyle='rgba(142,58,122,.5)';for(let i=0;i<3;i++)ctx.fillRect(Math.round(sx+Math.sin(gtime*9+i*2)*8),Math.round(sy-10-i*6),2,2);return;}   // Shadowcap: vanished
  drawEnemyWorld0(e);
}
function drawEnemyWorld0(e){
  const sx=e.x-cam.x,sy=e.y-cam.y,spr=SP[e.dummy?'dummy':(e.def.disg&&!(B&&e.engaged)&&!(e.alert>0)&&!e.chasing?e.def.disg:e.def.spr)];
  const fighting=!!B&&e.engaged;
  if((fighting||e.gdie)&&e.dying&&Math.floor(e.dyT*18)%2)return;
  const flip=e.type==='goblin'?e.face>0:e.face<0;
  const wob=fighting&&e.st==='windup'?Math.sin(gtime*50)*1.5:0;
  let lx=0;if(fighting&&e.lunge>0)lx=-e.face*Math.sin(e.lunge/.25*Math.PI)*8;
  if(fighting&&e.draw>0)lx=e.face*4*Math.sin(e.draw/.2*Math.PI);
  const hopH=fighting&&e.hop>0?Math.sin(e.hop/.35*Math.PI)*9:0;
  if(e.def.big){
    drawEntShadow(e.x,e.y,28);
    const by=sy-hopH+Math.round(Math.sin(e.bob*.7)*1.5);
    draw(spr,sx-spr.width+wob+lx,by-spr.height*2+2,2,flip);
    if(fighting&&e.flash>0){ctx.globalAlpha=.8;draw(whiteOf(spr),sx-spr.width+wob+lx,by-spr.height*2+2,2,flip);ctx.globalAlpha=1;}
    if(fighting){
      const lich=e.type==='lich',mx=lich?sx+(e.face>0?27:-27):sx+(e.face>0?-24:24),my=lich?by-spr.height*2+8:by-spr.height*2+24;
      if(e.charge>0&&e.st==='windup'){const pr=1-e.t/(e.cur?e.cur.windup:1);ctx.fillStyle=lich?'rgba(110,255,170,.85)':'rgba(255,140,40,.85)';ctx.beginPath();ctx.arc(mx,my,3+pr*9,0,6.283);ctx.fill();ctx.fillStyle=lich?'#eafff0':'#ffe14d';ctx.beginPath();ctx.arc(mx,my,1.5+pr*5,0,6.283);ctx.fill();}
      if(e.dragonOpen>0){ctx.fillStyle=lich?'rgba(140,255,190,.9)':'rgba(255,170,60,.9)';ctx.beginPath();ctx.arc(mx,my,7+e.dragonOpen*14,0,6.283);ctx.fill();}
      if(e.p2){ctx.fillStyle=lich?`rgba(${e.p3?'190,90,255':'90,255,150'},${.1+.07*Math.sin(gtime*10)})`:`rgba(255,40,40,${.1+.07*Math.sin(gtime*10)})`;ctx.fillRect(sx-36,by-spr.height*2+2,72,64);}
    }
    if(!fighting&&Math.sin(e.fa)<-.6){ctx.globalAlpha=.4;draw(blackOf(spr),sx-spr.width+wob+lx,by-spr.height*2+2,2,flip);ctx.globalAlpha=1;}
    if(!fighting&&!(e.alert>0))txt('BOSS  Lv '+e.lv,sx,sy-spr.height*2-6,{size:11,align:'center',col:lvColor(e.lv)});
  } else {
    drawEntShadow(e.x,e.y,11*e.sz);drawEliteAura(e,sx,sy);
    let sq=1;
    if(e.type==='slime')sq=1+Math.sin(e.bob*(fighting?3.2:1.6))*.08;
    else if(e.type==='bat')sq=1+Math.sin(e.bob*(fighting?7:4))*.22;
    const fly=e.type==='bat'?9+Math.sin(e.bob*.9)*3:e.type==='wraith'?5+Math.sin(e.bob*.6)*3:0;
    const w=32*(2-sq)*e.sz,h=32*sq*e.sz;
    const hop=hopH+(e.type==='slime'?Math.abs(Math.sin(e.bob*.8))*3:Math.abs(Math.sin(e.bob*1.3))*((e.chasing||fighting)?1.5:.6));
    ctx.save();ctx.translate(Math.round(sx+wob+lx),Math.round(sy-hop-fly));if(flip)ctx.scale(-1,1);
    if(e.type==='wraith')ctx.globalAlpha=.78;ctx.drawImage(spr,-w/2,-h-2,w,h);ctx.globalAlpha=1;
    if(e.tier>0){ctx.globalAlpha=e.tier===1?.2:.28;ctx.drawImage(tintOf(spr,TIER_TINT[e.tier]),-w/2,-h-2,w,h);ctx.globalAlpha=1;}   // elite tint
    if(fighting&&e.flash>0){ctx.globalAlpha=.8;ctx.drawImage(whiteOf(spr),-w/2,-h-2,w,h);ctx.globalAlpha=1;}
    if(!fighting&&Math.sin(e.fa)<-.6){ctx.globalAlpha=.4;ctx.drawImage(blackOf(spr),-w/2,-h-2,w,h);ctx.globalAlpha=1;}
    ctx.restore();
    if(fighting&&e.guard>0){ctx.globalAlpha=.55+.2*Math.sin(gtime*16);ctx.strokeStyle='#bfe6ff';ctx.lineWidth=2;ctx.fillStyle='rgba(130,190,255,.3)';ctx.beginPath();ctx.ellipse(sx+(e.face>0?-13:13),sy-17,7,16,0,0,6.283);ctx.fill();ctx.stroke();ctx.globalAlpha=1;}
  }
  if(fighting&&e.chill>0&&!e.dying&&!(e.frozen>0)){
    const dr=e.def.big;ctx.save();ctx.globalAlpha=.22+.1*Math.sin(gtime*8);
    if(dr)draw(tintOf(spr,'#7fd8ff'),sx-spr.width+wob+lx,sy-spr.height*2+2,2,flip);
    else{ctx.translate(Math.round(sx),Math.round(sy));if(flip)ctx.scale(-1,1);const w2=32*e.sz;ctx.drawImage(tintOf(spr,'#7fd8ff'),-w2/2,-w2-2,w2,w2);}
    ctx.restore();ctx.fillStyle='#d9f6ff';for(let i=0;i<2;i++)ctx.fillRect(sx+R(-14,14),sy-R(6,dr?70:34),2,2);
  }
  if(fighting&&e.stun>0&&e.stunK==='time'&&!e.dying&&!e.def.big){ctx.save();ctx.globalAlpha=.4;ctx.translate(Math.round(sx),Math.round(sy));if(flip)ctx.scale(-1,1);const w2=32*e.sz;ctx.drawImage(tintOf(spr,'#ffd98a'),-w2/2,-w2-2,w2,w2);ctx.restore();}
  if(fighting&&e.pois>0&&!e.dying){ctx.fillStyle='#a6e85a';for(let i=0;i<2;i++)ctx.fillRect(Math.round(sx+R(-10,10)),Math.round(sy-R(6,e.def.big?60:32)),3,3);}
  if(fighting&&e.frozen>0&&!e.dying){
    const dr=e.def.big,iw=dr?44:19,ih=dr?spr.height*2+4:42,bx=sx,by=sy+3;
    ctx.save();ctx.globalAlpha=.4;
    if(dr)draw(tintOf(spr,'#7fd8ff'),sx-spr.width+wob+lx,sy-spr.height*2+2,2,flip);
    else{ctx.translate(Math.round(sx),Math.round(sy));if(flip)ctx.scale(-1,1);const w2=32,h2=32;ctx.drawImage(tintOf(spr,'#7fd8ff'),-w2/2,-h2-2,w2,h2);}
    ctx.restore();ctx.save();
    const fa=Math.min(1,e.frozen*2);
    ctx.globalAlpha=.5*fa+.08;ctx.fillStyle='#8fdcff';ctx.beginPath();ctx.moveTo(bx-iw,by);ctx.lineTo(bx-iw-3,by-ih*.55);ctx.lineTo(bx-iw*.6,by-ih);ctx.lineTo(bx+iw*.55,by-ih-4);ctx.lineTo(bx+iw+3,by-ih*.5);ctx.lineTo(bx+iw,by);ctx.closePath();ctx.fill();
    ctx.globalAlpha=.9*fa;ctx.strokeStyle='#effcff';ctx.lineWidth=2;ctx.stroke();
    ctx.globalAlpha=.6*fa;ctx.beginPath();ctx.moveTo(bx-iw*.5,by-ih*.15);ctx.lineTo(bx-iw*.1,by-ih*.8);ctx.moveTo(bx+iw*.2,by-ih*.2);ctx.lineTo(bx+iw*.55,by-ih*.65);ctx.strokeStyle='#fff';ctx.lineWidth=1.5;ctx.stroke();
    if(Math.floor(gtime*5+e.x)%3===0){ctx.fillStyle='#fff';ctx.globalAlpha=.9;ctx.fillRect(bx+Math.sin(e.x)*iw*.6,by-ih*.5-Math.cos(e.y)*ih*.3,2,2);}
    ctx.restore();
  }
  if(fighting){
    if(e.burn>0){ctx.fillStyle='#ff7a2a';for(let i=0;i<3;i++)ctx.fillRect(sx+R(-8,8),sy-R(6,e.def.big?50:30),2,2);}
    if(!e.dying){const bw=e.def.big?64:36,by2=sy-(e.def.big?spr.height*2+12:42-(e.sz-1)*40);bar(sx-bw/2,by2,bw,4,e.hp/e.maxhp,e.chill>0?'#7fd8ff':e.def.boss?'#ff7a2a':'#e8504a');
      txt(e.title+'  Lv '+e.lv,sx,by2-4,{size:9,align:'center',col:lvColor(e.lv),lw:3});}
  }
  if(!fighting&&!e.def.big&&!e.dying&&!(e.alert>0)){const dd=Math.hypot(e.x-P.x,e.y-P.y);txt((dd<190?e.title+'  ':'')+'Lv '+e.lv,sx,sy-40-(e.sz-1)*40,{size:9,align:'center',col:lvColor(e.lv),lw:3,alpha:dd<190?1:.8});}
  if(e.alert>0){const a=Math.min(1,e.alert*3);txt('!',sx,sy-(e.def.big?118:42)-Math.round((.7-e.alert)*8),{size:28,align:'center',col:'#ff4040',alpha:a});}
}

/* '!' = quest available, '?' = ready to hand in (bright), grey '?' = quest in progress */
function drawNpcMarker(n){
  const m=npcMarker(n);if(!m)return;
  const x=n.x-cam.x,y=n.y-cam.y-44+Math.round(Math.sin(gtime*3+n.x)*2);
  const ch=m==='avail'?'!':'?',col=m==='active'?'#9a96b8':m==='ready'?'#7dffa0':'#ffe14d';
  if(m!=='active'){ctx.save();ctx.globalAlpha=.25+.12*Math.sin(gtime*5);ctx.fillStyle=col;ctx.beginPath();ctx.arc(x,y-6,11,0,6.283);ctx.fill();ctx.restore();}
  txt(ch,x,y,{size:m==='active'?18:24,align:'center',col,lw:5});
}
function drawQuestItem(w){
  const x=w.tx*TS+16-cam.x,y=w.ty*TS+22-cam.y,b=Math.sin(gtime*3)*2;
  drawEntShadow(w.tx*TS+16,w.ty*TS+22,7);
  ctx.save();ctx.globalAlpha=.3+.2*Math.sin(gtime*5);ctx.fillStyle='#ffe98a';ctx.beginPath();ctx.arc(x,y-8+b,13,0,6.283);ctx.fill();ctx.restore();
  draw(SP.ic.g_ring,x-12,y-22+b,1.5);
  for(let i=0;i<3;i++){const k=(gtime*1.3+i/3)%1;ctx.globalAlpha=1-k;ctx.fillStyle='#fff';ctx.fillRect(Math.round(x-12+i*10+Math.sin(gtime*4+i)*3),Math.round(y-20-k*14),2,2);}ctx.globalAlpha=1;
}
