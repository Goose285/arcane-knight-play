
/* =====================================================================
   REAL-TIME COMBAT — fought right in the overworld, free 8-way movement
   ===================================================================== */
const MAGIC={frostbolt:{k:'ice',area:false,dur:3},crimsonbolt:{k:'blood',area:false},frostburst:{k:'ice',area:true,dur:3.6},crimsonburst:{k:'blood',area:true}};
const SPLASH_R=70;
const ER={slime:13,knight:14,goblin:12,dragon:30,bat:11,wraith:13,lich:30,wolf:12,yeti:16,toad:14,witch:13,scorpion:14,mummy:14,rimegar:30,mossback:30,colossus:30};
const eRad=e=>ER[e.type]*(e.sz||1);
const ecen=e=>({x:e.x,y:e.y-(e.def.big?26:e.type==='bat'?20:13)});
const pcen=()=>({x:P.x,y:P.y-12});
const angTo=(a,b)=>Math.atan2(b.y-a.y,b.x-a.x);
const angDiff=(a,b)=>Math.atan2(Math.sin(a-b),Math.cos(a-b));
const dirOfAngle=a=>Math.abs(Math.cos(a))>=Math.abs(Math.sin(a))?(Math.cos(a)<0?'l':'r'):(Math.sin(a)<0?'u':'d');
/* ---- walls: every wall-type tile blocks projectiles, blasts, cones and lines (trees/fences/water do not) ---- */
const wallT=(x,y)=>{const tx=Math.floor(x/TS),ty=Math.floor(y/TS);if(tx<0||ty<0||tx>=MW||ty>=MH)return true;const t=map[ty][tx];return t===T.B||t===T.BT||t===T.R||t===T.RL||t===T.H||t===T.D||t===T.Z||t===T.S||t===T.PR||t===T.CW||t===T.CP||t===T.CK||t===T.CT||XWALLS.has(t);};
const solidProj=(x,y)=>wallT(x,y+7);          // test at ground level so a body hugging a wall is never "inside" it
// fraction (0..1) of the way from a to b where the first wall is met (1 = clear). skip: ignore the last few px (target hugging a wall)
function rayWall(ax,ay,bx,by,skip=8){const d=Math.hypot(bx-ax,by-ay);if(d<1)return 1;const n=Math.ceil(d/4);for(let i=1;i<=n;i++){if(i/n*d>d-skip)break;if(wallT(ax+(bx-ax)*i/n,ay+(by-ay)*i/n))return (i-1)/n;}return 1;}
const losW=(a,ao,b,bo)=>rayWall(a.x,a.y+ao,b.x,b.y+bo)>=1;
const eOff=e=>e.def.big?19:7;
const losEP=e=>losW(ecen(e),eOff(e),aimPos(),7);
function clampRay(a,ao,b,bo){const f=rayWall(a.x,a.y+ao,b.x,b.y+bo,0);if(f>=1)return{x:b.x,y:b.y};const d=Math.hypot(b.x-a.x,b.y-a.y),t=Math.max(0,f*d-10)/d;return{x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t};}
function clipLen(x,y,a,len){const dx=Math.cos(a),dy=Math.sin(a);for(let d=4;d<=len;d+=4)if(wallT(x+dx*d,y+dy*d))return Math.max(0,d-4);return len;}
// swept movement: never skips over a wall tile. true = hit a wall
function sweepShot(s,dt){const n=Math.max(1,Math.ceil(Math.hypot(s.vx,s.vy)*dt/5));for(let i=0;i<n;i++){s.x+=s.vx*dt/n;s.y+=s.vy*dt/n;if(solidProj(s.x,s.y))return true;}return false;}
let ZOFF=7;
const FLEE_DIST=340;

const ALERT_R=220,MAX_ENG=4;
const SHORT={slime:'SLIME',knight:'KNIGHT',goblin:'GOBLIN',dragon:'DRAGON',bat:'BAT',wraith:'WRAITH',lich:'LICH KING',wolf:'WOLF',yeti:'BRUTE',toad:'TOAD',witch:'WITCH',scorpion:'SCORPION',mummy:'MUMMY',rimegar:'RIMEGAR',mossback:'MOSSBACK',colossus:'COLOSSUS'};
const liveEns=()=>B.ens.filter(e=>!e.dying);
function initCombatEnemy(e,delay){
  const def=e.def;
  Object.assign(e,{hp:e.mhp,maxhp:e.mhp,chill:0,st:'idle',t:0,cur:null,moveCd:.8,atkCd:1.7+Math.random()*1.0,flash:0,guard:0,burn:0,burnT:0,hop:0,dash:null,charge:0,p2:false,dragonOpen:0,engaged:true,
    strafe:Math.random()<.5?1:-1,strafeT:1.2,lunge:0,draw:0,dying:false,dyT:0,hidden:false,chasing:false,alert:0,slideT:0,joinT:delay,path:null,pathT:0,frozen:0,fimm:0,lastDealt:0,stun:0,curse:0,pois:0,slot:null,sIdx:-1});
  e.face=P.x<e.x?1:-1;e.fa=angTo(ecen(e),pcen());eliteInit(e);
}
// enemies near an ongoing fight notice the noise and pile in, one after another
function recruit(base,opt={}){
  const src=liveEns();if(!src.length)return 0;
  const R0=ALERT_R+(B.loud>0?60:0),pe={x:P.x,y:P.y-12},cand=[];
  for(const o of enemies){
    if(!o.alive||o.engaged||o.dying)continue;
    if(o.terr&&!inTerr(o,P.x,P.y,6))continue;          // territorial enemies don't leave home to join a fight
    let why=null;
    // 1. they heard the fight (noise travels from every fighter)
    if(!opt.prox){let d=1e9;for(const s of src)d=Math.min(d,Math.hypot(o.x-s.x,o.y-s.y));if(d<R0)why='noise';cand.push([d,o,why]);continue;}
    // 2. the hero walked into their awareness circle (any direction, walls block) or into their sight cone
    if(o.tut||trivial(o)||o.calm>0||playerInTown())continue;
    const ey=eEye(o),dp=Math.hypot(pe.x-ey.x,pe.y-ey.y);
    if(dp<=awareR(o)&&losClear(ey,pe))why='near';
    else if(dp<=o.vr){const sm=sensed(o);if(sm)why=sm==='auto'?'near':'cone';}
    if(why)cand.push([dp,o,why]);
  }
  cand.sort((a,b)=>a[0]-b[0]);
  let k=0;
  for(const [,o,why] of cand){
    const cap=why==='noise'||!why?MAX_ENG:MAX_ENG+2;   // anyone who has actually noticed YOU may squeeze in past the usual cap
    if(!why)continue;
    if(liveEns().length>=cap)continue;
    initCombatEnemy(o,base+k*.3);B.ens.push(o);k++;
  }
  return k;
}
function startEncounter(e,byPlayer){
  sfx('encounter');WS.length=0;const carry=(WCH.on&&held('KeyJ'))?WCH.t:0;WCH.on=false;WCH.t=0;   // a shot you were charging in the overworld carries into the fight
  B={ens:[],phase:'alert',t:0,dim:0,shake:0,hitstop:0,zones:[],shots:[],fx:[],texts:[],parts:[],timers:[],hand:[],sel:0,gauge:0,gaugeFlash:0,banner:null,
     inv:0,barrier:0,shootCd:0,charge:0,charging:false,flash:0,shootAnim:0,idleT:0,fleeT:0,gainXp:0,gainGold:0,levels:0,defeated:{},boss:false,
     loud:0,noiseT:1,atkGap:0,owner:null,target:null,total:1,cleared:false,drops:[]};initExtras();
  if(carry>.05){B.charge=carry;B.charging=true;B.carry=true;}   // drops: future gear drops (items) - non-empty forces the full victory screen
  initCombatEnemy(e,0);B.ens.push(e);
  P.dir=dirOfAngle(angTo(pcen(),ecen(e)));P.aim=angTo(pcen(),ecen(e));
  B.target=e;
  const n=recruit(byPlayer?.35:.6)+recruit(byPlayer?.35:.6,{prox:true});B.total=1+n;
  if(byPlayer){B.phase='fight';B.t=0;B.dim=1;dealHand();setBanner('AMBUSH!',.9,'#ffe14d');e.atkCd=1.4;e.joinT=0;}
}
// boss phase change: interrupt the current attack, brief breather, flare of energy
function bossPhase(e){const c=ecen(e);e.st='idle';e.cur=null;e.atkCd=1.5;B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);burst(c.x,c.y,e.type==='lich'?'#9dffb0':'#ff7a2a',30,200,.9);if(typeof bossMechPhase==='function')bossMechPhase(e);}
function schedule(d,fn){B.timers.push({t:d,fn,o:B.owner});}
function addFx(k,z,dur,o={}){B.fx.push({k,z,t:0,dur:dur||(k==='fire'?.55:.42),...o});}
function burst(x,y,col,n=10,sp=100,life=.5){for(let i=0;i<n;i++){const a=Math.random()*6.283,s=R(.3,1)*sp;B.parts.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s-30,t:0,life:life*R(.6,1),col,sz:RI(2,3)});}}
function floatText(x,y,s,col='#fff',size=14){B.texts.push({x,y,s,col,size,t:0});}
function setBanner(s,dur=1.2,col='#fff'){B.banner={s,t:0,dur,col};}

/* ---- telegraph zones: circle / line / cone, drawn on the ground ---- */
const Z={
  circle:(x,y,r,off=7)=>({k:'circle',x,y,r,off}),
  ring:(x,y,r0,r1,off=7)=>({k:'ring',x,y,r0,r1,r:r1,off}),
  line:(x,y,a,len,w,off=ZOFF)=>({k:'line',x,y,a,len:clipLen(x,y+off,a,len),w,off}),
  cone:(x,y,a,len,half,off=ZOFF)=>{const N=16,rays=[];for(let i=0;i<=N;i++)rays.push(clipLen(x,y+off,a-half+2*half*i/N,len));return{k:'cone',x,y,a,len,half,off,rays,N};}
};
const coneRay=(z,ang)=>{const u=clamp((angDiff(ang,z.a)+z.half)/(2*z.half),0,1)*z.N,i0=Math.floor(u);return Math.min(z.rays[i0],z.rays[Math.min(z.N,i0+1)]);};
function warnZones(zs,dur){zs.forEach(z=>B.zones.push({...z,t:0,dur,o:B.owner}));sfx('warn');}
function inZone(z,p,m=6){
  if(z.k==='circle')return Math.hypot(p.x-z.x,p.y-z.y)<=z.r+m&&rayWall(z.x,z.y+z.off,p.x,p.y+7)>=1;   // blasts don't pass walls
  if(z.k==='ring'){const d=Math.hypot(p.x-z.x,p.y-z.y);return d>=z.r0&&d<=z.r1+m&&rayWall(z.x,z.y+z.off,p.x,p.y+7)>=1;}
  if(z.k==='line'){const dx=Math.cos(z.a),dy=Math.sin(z.a),rx=p.x-z.x,ry=p.y-z.y,t=rx*dx+ry*dy;if(t<-m||t>z.len+m)return false;return Math.abs(-rx*dy+ry*dx)<=z.w/2+m;}
  const d=Math.hypot(p.x-z.x,p.y-z.y);if(d>z.len+m)return false;if(d<14)return true;
  const ang=Math.atan2(p.y-z.y,p.x-z.x);
  if(Math.abs(angDiff(ang,z.a))>z.half+Math.atan2(m,d))return false;
  return d<=coneRay(z,ang)+m;
}
function shapePath(z,k=1){
  ctx.beginPath();
  if(z.k==='circle'){ctx.arc(z.x,z.y,Math.max(.1,z.r*k),0,6.283);}
  else if(z.k==='ring'){ctx.arc(z.x,z.y,Math.max(.1,z.r1*k),0,6.283);ctx.moveTo(z.x+z.r0*k,z.y);ctx.arc(z.x,z.y,Math.max(.1,z.r0*k),0,6.283,true);}
  else if(z.k==='line'){const dx=Math.cos(z.a),dy=Math.sin(z.a),nx=-dy*z.w/2,ny=dx*z.w/2,L=z.len*k;ctx.moveTo(z.x+nx,z.y+ny);ctx.lineTo(z.x+dx*L+nx,z.y+dy*L+ny);ctx.lineTo(z.x+dx*L-nx,z.y+dy*L-ny);ctx.lineTo(z.x-nx,z.y-ny);ctx.closePath();}
  else{ctx.moveTo(z.x,z.y);for(let i=0;i<=z.N;i++){const q=z.a-z.half+2*z.half*i/z.N,r=z.rays[i]*k;ctx.lineTo(z.x+Math.cos(q)*r,z.y+Math.sin(q)*r);}ctx.closePath();}
}
function hitZones(zs,dmg,kind='boom'){
  dmg=Math.round(dmg*(B.owner&&B.owner.dm||1));
  let hp=false;const p=pcen();
  zs.forEach(z=>{addFx(kind,z);if(inZone(z,p))hp=true;
    if(kind==='boom'&&z.k==='circle')burst(z.x,z.y,'#ffb23f',8,90,.4);});
  sfx(kind==='slash'?'slash':'boom');B.shake=Math.max(B.shake,.12);B.loud=1;
  const dc=B.decoy;if(dc&&dc.hp>0&&zs.some(z=>inZone(z,{x:dc.x,y:dc.y-12})))dc.hp-=dmg;
  if(hp)damagePlayer(dmg,B.owner);
}
function fireProj(x,y,a,spd,dmg,kind,r=6){dmg=Math.round(dmg*(B.owner&&B.owner.dm||1));B.shots.push({x,y,vx:Math.cos(a)*spd,vy:Math.sin(a)*spd,r,dmg,own:'e',kind,life:2.6,a,src:B.owner});}

/* ---- damage ---- */
function damagePlayer(d,src){
  if(B.inv>0||B.phase==='win'||B.phase==='lose'||B.phase==='reward')return;
  const p=pcen();
  if(B.barrier>0){B.barrier=0;B.inv=.5;sfx('clang');burst(p.x,p.y,'#8ff0ff',14,130,.5);floatText(p.x,p.y-28,'BLOCK','#8ff0ff',12);return;}
  const df=gearStats().def;if(df>0)d=Math.max(1,Math.round(d-df));d=Math.max(1,Math.round(d*boonDef()));   // armor: flat damage reduction
  P.hp-=d;B.inv=1.1;if(P.sleepT>0){P.sleepT=0;floatText(p.x,p.y-44,'AWAKE!','#ffe14d',12);}B.flash=.25;B.shake=.3;B.hitstop=.06;sfx('hurt');eliteLeech(src||B.owner,d);
  floatText(p.x,p.y-26,String(d),'#ff6b6b',16);burst(p.x,p.y,'#ff6b6b',10,110,.5);
  if(P.hp<=0){P.hp=0;loseBattle();}
}
function damageEnemy(e,d,kind){
  if(e.dying)return false;
  if(!e.engaged){initCombatEnemy(e,.2);B.ens.push(e);B.cleared=false;}
  const c=ecen(e),top=c.y-(e.def.big?34:20);
  e.lastDealt=0;d*=boonDmg();
  {const fm=foeDmgMult(e,kind);if(fm===0){floatText(c.x,top,'MISS','#cfd0ff',11);return false;}if(fm!==1){d*=fm;if(fm<.7&&Math.random()<.3)floatText(c.x,top-10,fm<=.2?'SHELLED':'ARMOUR','#cfd8ff',10);if(fm>1.5)floatText(c.x,top-10,'CORE HIT!','#7df9ff',12);}}
  const quiet=kind==='dot'||kind==='wolf'||kind==='pet';
  if(e.guard>0&&kind!=='dot'){
    if(kind==='arcane'){sfx('clang');floatText(c.x,top,'CLANG!','#cfd8ff',12);burst(c.x-e.face*10,c.y,'#cfd8ff',6,90,.3);return false;}
    e.guard=0;floatText(c.x,top-12,'GUARD BREAK!','#ffe14d',12);
  }
  if(kind==='fire'&&skillRank('fire')>=3){e.burn=Math.max(e.burn||0,2.5);e.burnT=e.burnT||.5;}
  if((kind==='ice'||kind==='steam')&&skillRank('frost')>=3)e.chill=Math.max(e.chill||0,2.5);
  const cursed=e.curse>0;if(cursed)d*=2;           // Curse card: double damage
  const crit=!quiet&&Math.random()<.05+gearStats().crit;if(crit)d*=1.6;   // gear crit chance
  if(e.bshield>0&&kind!=='dot')return bossShieldHit(e,Math.round(d),c,top);
  d=Math.round(d);const d0=d;d=eliteShield(e,d,c,top);if(d<=0){burst(c.x,c.y,'#cfefff',4,80,.3);eliteAfterHit(e,d0,kind);return true;}
  e.lastDealt=Math.min(d,Math.max(0,e.hp));e.hp-=d;e.flash=quiet?.06:.12;
  if(!quiet){sfx('hit');B.hitstop=Math.max(B.hitstop,kind==='arcane'?.015:.05);}
  if(kind!=='arcane'&&!quiet){B.shake=Math.max(B.shake,.15);B.loud=1;}
  floatText(c.x+R(-8,8),top,String(d),kind==='charged'?'#7df9ff':cursed?'#e0a0ff':kind==='dot'?'#b6f06a':'#fff',kind==='charged'?18:quiet?11:cursed?16:14);
  burst(c.x,c.y,kind==='fire'?'#ff9a3d':'#fff3a0',kind==='arcane'?4:9,100,.4);
  if(crit){floatText(c.x,top-14,'CRIT!','#ffe14d',12);}
  eliteAfterHit(e,d0,kind);
  if(e.hp<=0){e.hp=0;killEnemy(e);}
  else if(e.def.p2at&&!e.p2&&e.hp<e.maxhp*e.def.p2at){e.p2=true;setBanner(e.type==='lich'?'THE KING RISES!':'ENRAGED!',1.3,e.type==='lich'?'#9dffb0':'#ff6b6b');B.shake=.5;sfx('boom');bossPhase(e);}
  else if(e.def.p3at&&!e.p3&&e.hp<e.maxhp*e.def.p3at){e.p3=true;setBanner('FINAL FORM!',1.4,'#d49bff');B.shake=.8;sfx('boom');bossPhase(e);}
  return true;
}
function killEnemy(e){
  if(e.dying)return;
  if(e.lab){labKill(e);return;}
  e.dying=true;e.dyT=0;e.st='idle';e.cur=null;e.guard=0;e.dash=null;e.bshield=0;
  if(e.def.boss){B.pools=[];B.ens.filter(o=>o.tmp&&!o.dying).forEach(o=>{o.hp=0;killEnemy(o);});}
  B.zones=B.zones.filter(z=>z.o!==e);B.timers=B.timers.filter(t=>t.o!==e);
  const c=ecen(e);sfx('boom');B.shake=Math.max(B.shake,.4);eliteDeath(e,c);
  for(let i=0;i<4;i++)addFx('boom',{k:'circle',x:c.x+R(-14,14),y:c.y+R(-14,14),r:20},.5);
  burst(c.x,c.y,'#ffb23f',18,150,.7);
  const d=e.def,g=Math.round(RI(d.gold[0],d.gold[1])*e.gm),xpv=Math.round(e.xpv*(e.rush?1:storyXp()));
  B.gainXp+=xpv;B.gainGold+=g;P.xp+=xpv;P.gold+=g;kills++;dailyEvent('kill',e);dailyEvent('gold',g);B.defeated[e.type]=(B.defeated[e.type]||0)+1;if(e.tmp)kills--;
  floatText(c.x,c.y-34,'+'+xpv+' XP','#9ad0ff',13);floatText(c.x,c.y-18,'+'+g+' G','#ffd23f',13);sfx('coin');   // non-blocking reward popups
  while(P.xp>=xpNeed()){P.xp-=xpNeed();P.lv++;B.levels++;P.hp=maxHp();sfx('level');floatText(P.x,P.y-50,'LEVEL UP!','#7dffa0',16);toast(`LEVEL UP!  Lv ${P.lv}  -  HP restored  +1 SKILL POINT`,2.6,'#7dffa0');B.saveSoon=true;}
  if(e.rush){}
  else if(e.type==='dragon'){bossDown=true;B.boss=true;grantCard('dragonfire',c);}   // felling the dragon unlocks Dragonfire
  else if(e.type==='lich'){lichDown=true;storyOnLich();B.boss=true;B.bossName='LICH KING';grantCard(['meteor','drain','timestop'][RI(0,2)],c);}
  petOnKill(e);trophyOnKill(e);guarOnBossKill(e);
  if(!e.rush){secretOnKill(e);
  rollMats(e).forEach((t,i)=>floatText(c.x+30,c.y-40-i*12,t,'#7df9ff',11));
  questEvent('kill',e.type);questLoot(e).forEach((t,i)=>floatText(c.x,c.y-82-i*12,t,'#7df97d',11));}
  const gd=e.rush?null:rollGearDrop(e);if(gd){addGear(gd);B.drops.push({name:gd.name,rar:gd.rar,item:gd,slot:gd.slot});floatText(c.x,c.y-66,'GEAR!',GEAR_RAR[gd.rar].col,14);   // gear drop -> full loot screen
    const eqd=GEAR.eq[gd.slot];if(!eqd){equipGear(gd);gd.auto=true;}else if(gearScore(gd)>gearScore(eqd))gd.upgrade=true;}
  const drop=e.rush?null:rollDrop(e.def.boss?16:(e.lv||1)+(e.elite?4:0));if(drop)grantCard(drop.id,c);   // occasional card drop, rarer at higher levels
  if(B.ens.every(o=>o.dying)){
    // full victory screen only for the boss (or when a future gear drop needs showing); normal fights just keep playing
    if(e.rush)B.cleared=true;else if(B.boss||B.drops.length>0)winBattle();else B.cleared=true;
  }
}
function knock(e,a,dist){const sp=dist/.12;let t=0;e.dash={vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,t:.12};}
