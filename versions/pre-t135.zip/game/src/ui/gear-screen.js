/* =====================================================================
   EQUIPMENT SCREEN (pause menu -> EQUIPMENT) + gear drawn on the hero
   ===================================================================== */
const gearIcon=it=>it.slot==='armor'?SP.ic.g_armor:it.slot==='ring'?SP.ic.g_ring:SP.ic.sword;
function openGear(){openUIMode('gear');}
function gearIconBox(x,y,it,sz=32){
  const c=it?GEAR_RAR[it.rar].col:'#3a3660';ctx.fillStyle=it?c:'#1d1a38';ctx.fillRect(x,y,sz,sz);ctx.fillStyle='rgba(255,255,255,.16)';ctx.fillRect(x,y,sz,8);
  if(it){draw(gearIcon(it),x+1,y+1,sz/16);ctx.globalAlpha=.35;draw(tintOf(gearIcon(it),c),x+1,y+1,sz/16);ctx.globalAlpha=1;}
}
function slotRow(slot){
  const it=GEAR.eq[slot];
  return {sel:true,h:46,act(){if(!it){uiMsg('Nothing equipped');return;}if(unequipGear(slot)){sfx('select');saveGame('gear');}else uiMsg('Backpack is full');},
    draw(x0,y,W,h,isSel,si){
      ctx.fillStyle=isSel?'#26224a':'#17142b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=it?GEAR_RAR[it.rar].col:'#4a4470';ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      gearIconBox(x0+7,y+7,it);
      txt(GEAR_SLOT_NAME[slot],x0+48,y+13,{size:8,col:'#9aa0ff',lw:2});
      if(it){txt(`${it.name}  Lv${it.lv}`,x0+48,y+26,{size:10,col:GEAR_RAR[it.rar].col,lw:2});txt(gearStatLine(it),x0+48,y+39,{size:8,col:'#cfd0ff',bold:false});
        uiButton(x0+W-74,y+9,66,28,'REMOVE',true,()=>{UI.sel=si;if(unequipGear(slot)){sfx('select');saveGame('gear');}else uiMsg('Backpack is full');},{tag:'unequip:'+slot,clip:true,size:10,bg:'#7a2e3a',bd:'#ff9aa8',sel:si});}
      else txt('- empty -',x0+48,y+31,{size:10,col:'#6a6690'});
    }};
}
function statsRow(){
  return {h:46,draw(x0,y,W,h){
    const s=gearStats();ctx.fillStyle='#120f26';ctx.fillRect(x0,y,W,h);
    const cells=[['SHOT',arcaneDmg(),'#ffe14d'],['HP',maxHp(),'#7dffa0'],['DEF',s.def,'#9ad0ff'],['DEAL','+'+Math.round(s.gauge*100)+'%','#ffb86b'],['CRIT',Math.round((.05+s.crit)*100)+'%','#ff8a8a']];
    const cw=W/cells.length;cells.forEach((c,i)=>{txt(c[0],x0+cw*(i+.5),y+16,{size:8,align:'center',col:'#9aa0ff',lw:2});txt(String(c[1]),x0+cw*(i+.5),y+36,{size:14,align:'center',col:c[2],lw:3});});
  }};
}
function itemRow(it){
  const eq=GEAR.eq[it.slot],diff=gearScore(it)-gearScore(eq),col=GEAR_RAR[it.rar].col;
  const doEq=()=>{if(equipGear(it)){sfx('select');uiMsg('Equipped '+it.name,false);saveGame('gear');}};
  return {sel:true,h:56,act:doEq,tap:doEq,
    draw(x0,y,W,h,isSel,si){
      ctx.fillStyle=isSel?'#26224a':'#17142b';ctx.fillRect(x0,y,W,h);ctx.fillStyle=col;ctx.fillRect(x0,y,3,h);
      if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}
      gearIconBox(x0+7,y+12,it);
      txt(it.name,x0+48,y+14,{size:10,col,lw:2});
      txt(`${GEAR_RAR[it.rar].n} ${GEAR_SLOT_NAME[it.slot]}  Lv${it.lv}`,x0+48,y+26,{size:8,col:'#b9b4d8',lw:2});
      txt(gearStatLine(it),x0+48,y+37,{size:8,col:'#cfd0ff',bold:false});
      txt(!eq?'NEW SLOT':diff>0.01?'UPGRADE':diff<-0.01?'weaker':'same',x0+48,y+49,{size:8,col:!eq||diff>0.01?'#7dffa0':diff<-0.01?'#ff9a9a':'#9aa0ff',lw:2});
      uiButton(x0+W-78,y+5,70,23,'EQUIP',true,()=>{UI.sel=si;if(equipGear(it)){sfx('select');uiMsg('Equipped '+it.name,false);saveGame('gear');}},{tag:'equip:'+it.id,clip:true,size:11,sel:si});
      uiButton(x0+W-78,y+30,70,21,'SELL '+gearSell(it),true,()=>{UI.sel=si;const g=sellGear(it);sfx('coin');uiMsg(`Sold for ${g} G`,false);saveGame('gear');},{tag:'sell:'+it.id,clip:true,size:9,bg:'#6a5a1a',bd:'#ffd23f',sel:si});
    }};
}
UI_MODES.gear={title:()=>'EQUIPMENT',sub:()=>[`Gold ${P.gold} G    Backpack ${GEAR.inv.length}/${INV_MAX}`,'#ffd23f'],rows(){
  const r=[{t:'head',s:'EQUIPPED'}];GEAR_SLOTS.forEach(s=>r.push(slotRow(s)));
  r.push({t:'head',s:'TOTAL STATS'});r.push(statsRow());
  r.push({t:'head',s:'BACKPACK  (tap an item to equip it)'});
  const inv=GEAR.inv.slice().sort((a,b)=>GEAR_RAR_ORDER.indexOf(b.rar)-GEAR_RAR_ORDER.indexOf(a.rar)||b.lv-a.lv);
  if(!inv.length)r.push({t:'head',s:'  (empty - defeat monsters to find gear)'});
  inv.forEach(it=>r.push(itemRow(it)));return r;}};
/* ---- gear visible on the hero: armor tints the tunic, the weapon is held in hand, rings sparkle, legendary gear glows ---- */
function drawGearOnPlayer(spr,px,py){
  const w=GEAR.eq.weapon,a=GEAR.eq.armor,r=GEAR.eq.ring;if(!w&&!a&&!r)return;
  const leg=GEAR_SLOTS.some(s=>GEAR.eq[s]&&GEAR.eq[s].rar==='legendary');
  if(leg){ctx.save();ctx.globalAlpha=.25+.12*Math.sin(gtime*5);ctx.fillStyle='#ffb02e';ctx.beginPath();ctx.ellipse(px+16,py+31,17,6,0,0,6.283);ctx.fill();ctx.restore();}
  if(a){ctx.save();ctx.globalAlpha=.3;draw(tintOf(spr,GEAR_RAR[a.rar].col),px,py,2);ctx.restore();}
  if(w){const c=GEAR_RAR[w.rar].col,d=P.dir,sx=d==='l'?px-10:d==='r'?px+19:d==='u'?px+20:px+19,sy=d==='u'?py+10:py+13;
    ctx.save();draw(SP.ic.sword,sx,sy,1.5,d==='l');ctx.globalAlpha=.55;draw(tintOf(SP.ic.sword,c),sx,sy,1.5,d==='l');ctx.restore();
    if(w.rar==='epic'||w.rar==='legendary'){ctx.fillStyle=c;const k=(gtime*3)%1;ctx.globalAlpha=1-k;ctx.fillRect(Math.round(sx+4+Math.sin(gtime*9)*5),Math.round(sy+4-k*10),2,2);ctx.globalAlpha=1;}}
  if(r&&(r.rar==='rare'||r.rar==='epic'||r.rar==='legendary')){ctx.fillStyle=GEAR_RAR[r.rar].col;ctx.globalAlpha=.5+.5*Math.sin(gtime*8);ctx.fillRect(px+(P.dir==='l'?4:22),py+22,2,2);ctx.globalAlpha=1;}
}
