/* =====================================================================
   EDITOR PALETTE, part 2: walls (auto-connecting), planters, chests, the eastern region tiles and every new monster, plus an "All"
   tab that lists EVERY tile / prop / building piece in the game and every NPC look, so anything can be placed.
   And the COPY tool: drag a box over an area (or tap one object) to copy it, then tap anywhere to stamp copies (tiles + monster spawns).
   ===================================================================== */
ED_CATS.splice(ED_CATS.indexOf('Enemies'),0,'Walls','Regions');ED_CATS.push('All');
const edAddItem=it=>{it.key=it.kind+':'+(it.kind==='t'||it.kind==='p'?it.id:it.kind==='b'?it.w:it.kind==='e'?it.type:it.npc);if(ED_ITEM_BY[it.key])return;ED_ITEMS.push(it);ED_ITEM_BY[it.key]=it;};
[['WLM','Low wall, mossy'],['WLC','Low wall, clean'],['WCM','Castle wall, mossy'],['WCC','Castle wall, clean'],['WIV','Ivy wall'],['WRU','Ruined wall'],
 ['TWM','Tower, mossy'],['TWC','Tower, clean'],['WCN','Corner pillar'],['WGH','Gate arch'],['WGT','Wooden gate'],
 ['PL1','Planter, flowers'],['PL2','Planter, lavender'],['PL3','Long planter (joins)'],['PL4','Stone urn planter']].forEach(([k,n])=>edAddItem({cat:'Walls',kind:'p',id:T[k],name:n}));
edAddItem({cat:'Props',kind:'p',id:T.CHST,name:'Treasure chest'});
[['MO','Moss','t'],['RG','Quarry rubble','t'],['VB','Basalt','t'],['MS1','Giant red mushroom','p'],['MS2','Giant purple mushroom','p'],['MS3','Small mushrooms','p'],
 ['CR1','Purple crystal','p'],['CR2','Blue crystal','p'],['CL','Cliff rock','p'],['VR','Volcanic rocks','p'],['LV','Lava','p']].forEach(([k,n,kind])=>edAddItem({cat:'Regions',kind,id:T[k],name:n}));
for(const t in ENEMY){if(ENEMY[t].boss||!SP[ENEMY[t].spr])continue;edAddItem({cat:'Enemies',kind:'e',type:t,name:(ENEMY[t].name||t)+' spawn'});}
// ALL: every tile id that has art, every NPC look in the world
{const TN=Object.fromEntries(Object.entries(T).map(([k,v])=>[v,k]));
 for(const id of [...new Set(Object.values(T))].sort((a,b)=>a-b)){if(!TSPR[id]||!TSPR[id][0]||id===T.W)continue;const it={cat:'All',kind:'p',id,name:'Tile '+TN[id]};edAddItem(it);}
 const seen=new Set(Object.values(ED_NPC_DEFS).map(d=>d.spr));
 for(const n of NPCS){if(!n.spr||seen.has(n.spr)||!SP[n.spr]||n.way)continue;seen.add(n.spr);ED_NPC_DEFS['x_'+n.spr]={name:n.name,spr:n.spr,lines:['Hello there.']};edAddItem({cat:'All',kind:'n',npc:'x_'+n.spr,name:n.name+' (look)'});}}
[T.WLM,T.WLC,T.WCM,T.WCC,T.WIV,T.WRU,T.TWM,T.TWC,T.WCN,T.WGH,T.WGT,T.PL1,T.PL2,T.PL3,T.PL4,T.CHST,T.MS1,T.MS2,T.MS3,T.CR1,T.CR2,T.CL,T.VR,T.LV].forEach(t=>{ED_PROPSET.add(t);ED_OKSET.add(t);});
[T.MO,T.RG,T.VB].forEach(t=>{ED_GROUNDSET.add(t);ED_OKSET.add(t);});
for(const it of ED_ITEMS)if(it.cat==='All'&&it.kind==='p'&&!ED_GROUNDSET.has(it.id)){ED_PROPSET.add(it.id);ED_OKSET.add(it.id);}
/* ---- COPY tool ---- */
ED.cp={buf:null,a:null,b:null,sel:false};
function edCopyDown(w){const tx=Math.floor(w.x/TS),ty=Math.floor(w.y/TS);ED.cp.a=[tx,ty];ED.cp.b=[tx,ty];ED.cp.sel=false;}
function edCopyMove(w){const c=ED.cp;if(!c.a)return;const tx=Math.floor(w.x/TS),ty=Math.floor(w.y/TS);if(tx!==c.a[0]||ty!==c.a[1])c.sel=true;c.b=[tx,ty];}
function edCopyGrab(x0,y0,x1,y1){
  const t=[],en=[];for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)if(edIn(x,y))t.push([x-x0,y-y0,map[y][x]]);
  for(const e of enemies){if(e.def.boss||e.tmp||e.spw||e.rush||e.night||e.edDel)continue;const ex=Math.floor(e.hx/TS),ey=Math.floor(e.hy/TS);if(ex>=x0&&ex<=x1&&ey>=y0&&ey<=y1)en.push([ex-x0,ey-y0,e.type]);}
  ED.cp.buf={w:x1-x0+1,h:y1-y0+1,t,en};edMsg('Copied '+(x1-x0+1)+'x'+(y1-y0+1)+(en.length?' + '+en.length+' spawn(s)':'')+' - tap to stamp, drag for a new box');sfx('select');
}
function edCopyUp(){
  const c=ED.cp;if(!c.a)return;const [ax,ay]=c.a,[bx,by]=c.b;c.a=null;
  if(c.sel){c.sel=false;edCopyGrab(Math.min(ax,bx),Math.min(ay,by),Math.max(ax,bx),Math.max(ay,by));return;}
  if(!c.buf){edCopyGrab(ax,ay,ax,ay);return;}                 // a single tap with nothing copied copies that one object / tile
  edCopyStamp(ax,ay);
}
function edCopyStamp(tx,ty){
  const B0=ED.cp.buf;if(!B0)return 0;const t=[];
  for(const [dx,dy,id] of B0.t){const x=tx+dx,y=ty+dy;if(!edIn(x,y)||!ED_OKSET.has(map[y][x])||isVillagePondTile(x,y)||map[y][x]===id)continue;t.push([x,y,id]);}
  if(t.length)edPush({k:'tiles',t});
  let n=0;for(const [dx,dy,type] of B0.en){const x=tx+dx,y=ty+dy;if(edIn(x,y)&&!solidTile(x,y)&&!inTownPx(x*TS+16,y*TS+16)){edPush({k:'eadd',type,tx:x,ty:y});n++;}}
  if(!t.length&&!n){edMsg('Nothing to stamp there');return 0;}
  sfx('select');edMsg('Stamped');return t.length+n;
}
function edCopyDraw(){
  if(state!=='editor'||ED.tool!=='copy')return;const c=ED.cp;ctx.save();ctx.lineWidth=2;
  if(c.a&&c.sel){const x0=Math.min(c.a[0],c.b[0]),y0=Math.min(c.a[1],c.b[1]),x1=Math.max(c.a[0],c.b[0]),y1=Math.max(c.a[1],c.b[1]);
    ctx.fillStyle='rgba(125,249,255,.15)';ctx.strokeStyle='#7df9ff';ctx.setLineDash([6,4]);const r=[x0*TS-cam.x,y0*TS-cam.y,(x1-x0+1)*TS,(y1-y0+1)*TS];ctx.fillRect(...r);ctx.strokeRect(...r);}
  else if(c.buf&&ED.hover){const w=edW(ED.hover),tx=Math.floor(w.x/TS),ty=Math.floor(w.y/TS);ctx.globalAlpha=.55;
    for(const [dx,dy,id] of c.buf.t){const s=tileSprite(id,tx+dx,ty+dy,gtime);if(s)ctx.drawImage(s,(tx+dx)*TS-cam.x,(ty+dy)*TS-cam.y,TS,TS);}
    ctx.globalAlpha=1;ctx.strokeStyle='#ffe14d';ctx.strokeRect(tx*TS-cam.x,ty*TS-cam.y,c.buf.w*TS,c.buf.h*TS);}
  ctx.restore();
}
