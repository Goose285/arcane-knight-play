/* =====================================================================
   OAKVALE CHAPEL + RIVERSIDE: Father Anselm (free full-heal blessing, a kind word, and the game is saved) and Fisher Tobin
   (fishing tips, sells your catch, gives the fishing quests). Both are plain NPCs, so tapping them walks you over and talks.
   ===================================================================== */
NPCS.push({name:'Father Anselm',x:19.7*TS,y:33.75*TS,spr:'priest',priest:true,lines:[]});
NPCS.push({name:'Fisher Tobin',x:24.1*TS,y:41.7*TS,spr:'fisher',fisher:true,lines:[]});
const PRIEST_WORDS=[
  '"Be strong and of a good courage; be not afraid, neither be thou dismayed: for the LORD thy God is with thee whithersoever thou goest."  - Joshua 1:9',
  '"They that wait upon the LORD shall renew their strength; they shall mount up with wings as eagles."  - Isaiah 40:31',
  '"Yea, though I walk through the valley of the shadow of death, I will fear no evil: for thou art with me."  - Psalm 23:4',
  'Even the longest night gives way to morning. Rest a while, friend, and take heart.',
  'You carry more courage than you know. Be kind to those you meet on the road, and the road will be kinder to you.',
];
const CHURCH={met:false,visits:0};
function priestBless(){
  P.hp=maxHp();P.regen=0;sfx('heal');sfx('level');CHURCH.visits++;ACH.s.bless=(ACH.s.bless|0)+1;
  wfxBurst(P.x,P.y-20,'#fff6c0',26,110,1.1);wfxBurst(P.x,P.y-10,'#ffd34d',12,80,.9);
  toast('You are blessed - fully healed.  (Game saved)',3.2,'#fff6c0');
  saveGame('chapel');
}
function openPriest(npc){
  const first=!CHURCH.met;CHURCH.met=true;
  const lines=first
    ?['Peace be with you, traveler. You are most welcome in this house.','Oakvale Chapel has stood here since before the dragon woke. All who come in good faith may rest here - the weary most of all.','Would you like a blessing for the road? It costs nothing.']
    :[['Welcome back, friend. The door is always open.','Peace be with you again, traveler.','Good to see you safe. Come in, rest.'][RI(0,2)],'Would you like a blessing for the road?'];
  const word=PRIEST_WORDS[RI(0,PRIEST_WORDS.length-1)];
  DLG={name:'FATHER ANSELM',lines,i:0,c:0,yes:'BLESS',no:'LEAVE',choice:priestBless,
       noAct:()=>{DLG=null;},
       after:()=>isEvening()?chapelRestDlg(word):({name:'FATHER ANSELM',lines:[word,'Go in peace, and may you be kept safe on every road.'],i:0,c:0})};
}
function openFisher(npc){
  const lines=['The river is kind to those who wait, friend.','Rippling water means fish are rising. With a rod in hand, tap the ripples - when the bobber dips, tap again, then tap when the marker is in the green.','Better spots open as your Fishing level grows: the meadow river, the Whisperwood pond, even pools out in the bog and ruins.','Want to sell your catch, or cook some to eat?'];
  DLG={name:npc.name,lines,i:0,c:0,yes:'MY CATCH',no:'LATER',choice:()=>openFishing('play')};
}
