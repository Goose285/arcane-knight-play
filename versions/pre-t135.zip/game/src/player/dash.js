/* =====================================================================
   DASH: swipe anywhere on the open screen (not the stick, buttons or cards) to dash that way; Shift on a keyboard (dashes where you move
   / face). 2.5s cooldown shown as a small ring at the hero's feet. A dash gives a short moment of invulnerability in fights and
   breaks a PIN.
   ===================================================================== */
const DASH={cd:0,CD:2.5,t:0,vx:0,vy:0,dur:.16,dist:100,trail:[],ready:0};
const DASH_SWIPE_PX=42,DASH_SWIPE_MS=320;
function tryDash(ax,ay){
  if(state!=='play'||DLG||WARP||(typeof FISH!=='undefined'&&FISH.on))return false;
  if(B&&B.phase!=='fight')return false;
  const l=Math.hypot(ax,ay);if(l<.01)return false;
  if(DASH.cd>0||P.sleepT>0){if(B&&DASH.cd>0)floatText(P.x,P.y-46,'DASH '+DASH.cd.toFixed(1)+'s','#cfd0ff',10);return false;}
  DASH.t=DASH.dur;DASH.vx=ax/l*DASH.dist/DASH.dur;DASH.vy=ay/l*DASH.dist/DASH.dur;DASH.cd=DASH.CD;DASH.ready=0;
  P.aim=Math.atan2(ay,ax);P.dir=dirOfAngle(P.aim);
  if(P.rootT>0){P.rootT=0;if(B)floatText(P.x,P.y-46,'BROKE FREE!','#ffe14d',12);}
  if(B)B.inv=Math.max(B.inv,.32);
  sfx('whoosh');try{navigator.vibrate&&navigator.vibrate(12);}catch(e){}
  return true;
}
function dashTick(dt){
  const was=DASH.cd>0;DASH.cd=Math.max(0,DASH.cd-dt);if(was&&DASH.cd===0)DASH.ready=.45;DASH.ready=Math.max(0,DASH.ready-dt);
  for(const g of DASH.trail)g.t+=dt;while(DASH.trail.length&&DASH.trail[0].t>.3)DASH.trail.shift();
  if(DASH.t<=0)return false;
  DASH.t-=dt;const n=4;for(let i=0;i<n;i++){moveBox(P,DASH.vx*dt/n,0,6,7);moveBox(P,0,DASH.vy*dt/n,6,7);}
  DASH.trail.push({x:P.x,y:P.y,t:0});P.moving=true;P.anim+=dt*14;
  return true;
}
function dashKeys(){
  if(!hit('ShiftLeft','ShiftRight'))return;
  const [dx,dy,m]=moveInput();if(m)tryDash(dx,dy);else tryDash(Math.cos(P.aim),Math.sin(P.aim));
}
/* touch: a quick flick on open screen */
function dashSwipe(t,p){
  if(t.dashed)return;const dx=p.x-t.sx,dy=p.y-t.sy;
  if(Math.hypot(dx,dy)>=DASH_SWIPE_PX&&performance.now()-t.t0<=DASH_SWIPE_MS){t.dashed=true;t.moved=true;tryDash(dx,dy);}
}
function drawDashFx(){
  for(const g of DASH.trail){const a=.35*(1-g.t/.3);ctx.globalAlpha=a;const sp=SP.hero[P.dir]?SP.hero[P.dir][0]:null;if(sp)draw(sp,g.x-cam.x-16,g.y-cam.y-31,2);}ctx.globalAlpha=1;
  const x=Math.round(P.x-cam.x),y=Math.round(P.y-cam.y)+3;
  if(DASH.cd>0){const f=1-DASH.cd/DASH.CD;ctx.strokeStyle='rgba(20,24,44,.55)';ctx.lineWidth=3;ctx.beginPath();ctx.ellipse(x,y,12,5,0,0,6.283);ctx.stroke();
    ctx.strokeStyle='#7df9ff';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,12,5,0,-Math.PI/2,-Math.PI/2+f*6.283);ctx.stroke();}
  else if(DASH.ready>0){ctx.globalAlpha=DASH.ready/.45;ctx.strokeStyle='#ffffff';ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,y,12+(1-DASH.ready/.45)*6,5+(1-DASH.ready/.45)*2,0,0,6.283);ctx.stroke();ctx.globalAlpha=1;}
  // statuses over the head
  const lab=P.sleepT>0?'Zzz':P.rootT>0?'PINNED':P.slowT>0?'SLOWED':null;
  if(lab)txt(lab,x,y-50,{size:10,align:'center',col:P.sleepT>0?'#d8c8ff':P.rootT>0?'#e0c0ff':'#bfe6ff',lw:2});
}
