/* QUEST STATE + EVENTS. st: id -> 'active'|'ready'|'done'. n: kill counters. items: carried quest items. met: NPCs already greeted. */
const QS={st:{},n:{},items:{},met:{},seen:{},ord:[]};
const TRK={id:null,auto:true,open:true,sig:null,flash:0,fk:'',rect:null,done:null,prev:null,cache:null};   // quest tracker state (ui/tracker.js); id/open are saved with the quests
function resetQuests(){QS.st={};QS.n={};QS.items={};QS.met={};QS.seen={};QS.ord=[];TRK.id=null;TRK.auto=true;TRK.open=true;TRK.sig=null;TRK.flash=0;TRK.done=null;TRK.prev=null;}
function questStatus(id){
  const q=QUEST_BY_ID[id];if(QS.st[id])return QS.st[id];
  return (!q.req||QS.st[q.req]==='done')?'avail':'locked';
}
function questProgress(q){
  const o=q.obj;
  if(o.k==='kill'||o.k==='fish')return Math.min(o.n,QS.n[q.id]|0);
  if(o.k==='collect')return Math.min(o.n,QS.items[o.item]|0);
  if(o.k==='find')return QS.items[o.item]?1:0;
  return QS.seen[q.obj.area]?1:0;
}
const questNeed=q=>q.obj.k==='kill'||q.obj.k==='collect'||q.obj.k==='fish'?q.obj.n:1;
function questGoalText(q){const o=q.obj;
  return o.k==='fish'?`Catch ${o.n} fish`:o.k==='kill'?`Defeat ${o.n} ${ENEMY[o.type].name}${o.n>1?'s':''}`:o.k==='collect'?`Collect ${o.n} ${QITEM[o.item].name}`:o.k==='find'?`Find ${QITEM[o.item].name}`:`Reach the ${CRYPT_NAME.toLowerCase().replace(/\b\w/g,c=>c.toUpperCase())}`;}
const rewardCards=r=>r.cards||(r.card?[r.card]:[]);
function questRewardText(r){
  const p=[];if(r.gold)p.push(r.gold+' G');if(r.xp)p.push(r.xp+' XP');for(const k of rewardCards(r))p.push('card: '+CARD[k].name);if(r.gear)p.push((r.gear.rar||'random')+(r.gear.slot?' '+r.gear.slot:' gear'));return p.join(', ');}
function questCheckReady(q){
  if(QS.st[q.id]!=='active')return;
  if(questProgress(q)>=questNeed(q)){QS.st[q.id]='ready';toast(`QUEST READY: ${q.name} - return to ${q.giver}`,3.4,'#7dffa0');sfx('level');}
}
function questStart(id){
  const q=QUEST_BY_ID[id];if(questStatus(id)!=='avail')return false;
  QS.st[id]='active';QS.ord=QS.ord.filter(x=>x!==id);QS.ord.push(id);if(!trkValid(TRK.id)||(TRK.auto&&!/^q:/.test(TRK.id))){TRK.id='q:'+id;TRK.auto=true;}QS.n[id]=0;if(q.obj.k==='collect'||q.obj.k==='find')QS.items[q.obj.item]=0;
  if(id==='fish1'&&FSH.rod<0){FSH.rod=0;toast('Tobin lends you a Wooden Rod!',2.6,'#c08a52');}
  toast('NEW QUEST: '+q.name,3,'#ffe14d');sfx('select');questCheckReady(q);saveGame('quest');return true;
}
/* world events: ('kill',type) ('area',name) */
function questEvent(kind,v){
  if(kind==='area')QS.seen[v]=true;
  for(const q of QUESTS){
    if(QS.st[q.id]!=='active')continue;const o=q.obj;
    if(kind==='fish'&&o.k==='fish'){QS.n[q.id]=(QS.n[q.id]|0)+1;if(QS.n[q.id]<o.n)toast(`${q.name}: ${QS.n[q.id]}/${o.n}`,2,'#ffe14d');questCheckReady(q);}
    if(kind==='kill'&&o.k==='kill'&&o.type===v){QS.n[q.id]=(QS.n[q.id]|0)+1;if(QS.n[q.id]<o.n)toast(`${q.name}: ${QS.n[q.id]}/${o.n}`,2,'#ffe14d');questCheckReady(q);}
    if(kind==='area'&&o.k==='reach'&&o.area===v)questCheckReady(q);
  }
}
/* enemy kill -> quest item drops (only while a collect quest for that enemy is active). returns names for float text */
function questLoot(e){
  const got=[];
  for(const q of QUESTS){
    const o=q.obj;if(QS.st[q.id]!=='active'||o.k!=='collect'||o.from!==e.type)continue;
    if((QS.items[o.item]|0)>=o.n)continue;
    QS.miss=QS.miss||{};
    if(QS.miss[o.item]>=2||Math.random()<o.chance){QS.miss[o.item]=0;QS.items[o.item]=(QS.items[o.item]|0)+1;got.push(QITEM[o.item].name+' '+QS.items[o.item]+'/'+o.n);questCheckReady(q);}else QS.miss[o.item]=(QS.miss[o.item]|0)+1;
  }
  return got;
}
function questGiveXp(n){
  P.xp+=n;let up=0;while(P.xp>=xpNeed()){P.xp-=xpNeed();P.lv++;up++;}
  if(up){P.hp=maxHp();sfx('level');toast(`LEVEL UP!  Lv ${P.lv}  -  HP restored`,2.6,'#7dffa0');}
}
/* hand in: consume items, pay the reward, returns lines describing it */
function questComplete(id){
  const q=QUEST_BY_ID[id];if(QS.st[id]!=='ready')return [];
  QS.st[id]='done';if(q.obj.k==='collect')QS.items[q.obj.item]=Math.max(0,(QS.items[q.obj.item]|0)-q.obj.n);if(q.obj.k==='find')QS.items[q.obj.item]=0;
  const r=q.reward,got=[];
  if(r.gold){P.gold+=r.gold;got.push(r.gold+' gold');}
  if(r.xp){questGiveXp(r.xp);got.push(r.xp+' XP');}
  for(const k of rewardCards(r)){grantCard(k);got.push('the card '+CARD[k].name);}
  if(r.gear){const it=genGear(r.gear.slot,Math.max(3,P.lv),r.gear.rar,false);addGear(it);got.push(it.name+' ('+GEAR_RAR[it.rar].n+' '+GEAR_SLOT_NAME[it.slot]+')');
    if(!GEAR.eq[it.slot])equipGear(it);}
  sfx('questdone');toast('QUEST COMPLETE: '+q.name,3.2,'#7dffa0');saveGame('quest');
  {const hx=P.x,hy=P.y-14;wfxText(hx,hy-34,'Quest Complete!','#ffd54a',14,1.8);wfxBurst(hx,hy-10,'#ffe27a',16,95,.9);wfxBurst(hx,hy-10,'#fff6c8',8,60,.8);}   // a small gold sparkle (no screen flash)
  return ['QUEST COMPLETE: '+q.name,'You received '+got.join(', ')+'.'];
}
/* NPC marker: '!' = new quest to offer, '?' (gold) = ready to hand in, '?' (grey) = in progress */
function npcMarker(npc){
  if(introQuiet()&&npc.name!=='Elder Orin')return null;   // first five minutes: only Orin wears a marker
  let m=null;if(storyReady(npc))return 'avail';
  for(const q of QUESTS){if(q.giver!==npc.name)continue;const s=questStatus(q.id);
    if(s==='ready')return 'ready';if(s==='avail')m='avail';else if(s==='active'&&!m)m='active';}
  return m;
}
/* dialog hook: returns true if it opened a quest dialog */
function questTalk(npc){
  const smith=!!npc.smith;
  const mine=QUESTS.filter(q=>q.giver===npc.name);
  const rd=mine.find(q=>questStatus(q.id)==='ready');
  if(rd){const rw=questComplete(rd.id);DLG={name:npc.name,lines:rd.done.concat(rw),i:0,c:0};return true;}
  const av=mine.find(q=>questStatus(q.id)==='avail');
  if(av){const pre=(!QS.met[npc.name]&&npc.lines&&!introQuiet())?npc.lines:[];QS.met[npc.name]=true;
    DLG={name:npc.name,lines:pre.concat(av.offer,['New quest: '+av.name+' - '+questGoalText(av)+'. Reward: '+questRewardText(av.reward)+'. Accept?']),i:0,c:0,yes:'ACCEPT',no:smith?'SHOP':'LATER',noAct:smith?()=>openShop():null,choice:()=>questStart(av.id)};return true;}
  const ac=mine.find(q=>questStatus(q.id)==='active');
  if(ac&&!smith){QS.met[npc.name]=true;DLG={name:npc.name,lines:ac.prog.concat(['('+ac.name+': '+questProgress(ac)+'/'+questNeed(ac)+')']),i:0,c:0};return true;}
  return false;
}
function packQuests(){return {st:QS.st,n:QS.n,items:QS.items,met:QS.met,seen:QS.seen,ord:QS.ord,trk:{id:TRK.id,open:TRK.open,auto:TRK.auto}};}
function unpackQuests(s){resetQuests();if(!s)return;QS.st=Object.assign({},s.st);QS.n=Object.assign({},s.n);QS.items=Object.assign({},s.items);QS.met=Object.assign({},s.met);QS.seen=Object.assign({},s.seen);
  QS.ord=Array.isArray(s.ord)?s.ord.filter(id=>QUEST_BY_ID[id]):[];if(s.trk&&typeof s.trk==='object'){TRK.id=typeof s.trk.id==='string'?s.trk.id:null;TRK.open=true;   /* always starts expanded (a stale collapsed flag hid the progress + arrow) */TRK.auto=s.trk.auto!==false&&!(typeof s.trk.id==='string'&&s.trk.auto===undefined);}}
/* quest items lying on the map */
function questWorldItems(){return QWORLD.filter(w=>QS.st[w.quest]==='active'&&!QS.items[QUEST_BY_ID[w.quest].obj.item]);}
function updateQuestWorld(){
  for(const w of questWorldItems()){
    if(Math.hypot(w.tx*TS+16-P.x,w.ty*TS+16-(P.y-8))<40){const q=QUEST_BY_ID[w.quest];QS.items[q.obj.item]=1;sfx('coin');toast('Found '+QITEM[q.obj.item].name+'!',2.6,QITEM[q.obj.item].col);questCheckReady(q);saveGame('quest');}
  }
}
