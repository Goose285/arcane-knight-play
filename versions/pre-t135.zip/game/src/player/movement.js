
/* =====================================================================
   OVERWORLD + shared free movement (also used during combat)
   ===================================================================== */
function moveBox(o,dx,dy,hw,h){
  const blocked=(x,y)=>{
    for(const [cx,cy] of [[x-hw,y-h],[x+hw,y-h],[x-hw,y],[x+hw,y]])if(solidTile(Math.floor(cx/TS),Math.floor(cy/TS)))return true;
    return false;};
  const npcBlock=(x,y)=>(o===P&&NPCS.some(n=>Math.abs(n.x-x)<hw+7&&Math.abs(n.y-y)<h+4))||spwSolidAt(x,y,hw,h);
  if(dx){const nx=o.x+dx;if(!blocked(nx,o.y)&&!npcBlock(nx,o.y))o.x=nx;}
  if(dy){const ny=o.y+dy;if(!blocked(o.x,ny)&&!npcBlock(o.x,ny))o.y=ny;}
}
function moveInput(){
  let dx=0,dy=0,mag=1;
  if(held(...K_L))dx--;if(held(...K_R))dx++;if(held(...K_U))dy--;if(held(...K_D))dy++;
  if(!(dx||dy)&&joy.on){dx=joy.x;dy=joy.y;mag=Math.min(1,Math.hypot(dx,dy));}
  if(!(dx||dy)&&!joy.on&&GOTO.k){const g=gotoDir();if(g){dx=g[0];dy=g[1];mag=1;}}      // walking to a tapped NPC / fishing spot
  const l=Math.hypot(dx,dy);
  if(l<.12)return [0,0,0];
  return [dx/l,dy/l,mag];
}
function stepEnemy(e,vx,vy,sp,dt){
  const hw=e.def.big?12:7;
  if(e.slideT>0){e.slideT-=dt;const ox=vx,oy=vy;vx=ox*.35-oy*e.slide*.9;vy=oy*.35+ox*e.slide*.9;}
  const bx=e.x,by=e.y;
  moveBox(e,vx*sp*dt,0,hw,8);moveBox(e,0,vy*sp*dt,hw,8);
  if(inTownPx(e.x,e.y-8)){e.x=bx;e.y=by;}   // monsters never path into the village
  if(Math.hypot(e.x-bx,e.y-by)<sp*dt*.25&&!(e.slideT>0)){e.slideT=.6;e.slide=Math.random()<.5?1:-1;}
}
function updateExplore(dt){
  const fighting=!!B;
  const frozen=fighting&&B.phase!=='fight';
  if(WARP){updateWarp(dt);return;}
  if(DLG&&!fighting){updateDlg(dt);return;}
  updateSpawners(dt);updateGoto(dt);
  if(FISH.on&&!fighting){updateFishing(dt);return;}
  statusTick(dt);
  if(!frozen&&dashTick(dt)){}
  else if(!frozen){
    dashKeys();
    const [dx,dy,mag]=moveInput();
    P.moving=!!mag&&playerSpeedMul()>0;
    if(P.moving){
      const sp=(fighting?122:112)*mag*(B&&B.haste>0?1.45:1)*(B&&B.channel?.6:1)*playerSpeedMul();
      moveBox(P,dx*sp*dt,0,6,7);moveBox(P,0,dy*sp*dt,6,7);
      P.dir=Math.abs(dx)>=Math.abs(dy)?(dx<0?'l':'r'):(dy<0?'u':'d');
      P.aim=Math.atan2(dy,dx);
      P.anim+=dt*9*(.6+.4*mag);
    } else P.anim=0;
  } else {P.moving=false;P.anim=0;}
  P.x=clamp(P.x,TS,MW*TS-TS);P.y=clamp(P.y,TS,MH*TS-4);
  P.grace=Math.max(0,P.grace-dt);
  if(!fighting){
    P.regen+=dt;if(P.regen>1.4&&P.hp<maxHp()){P.regen=0;P.hp++;}
    const fd=Math.hypot(P.x-(16+OX)*TS,P.y-(35+OY)*TS);
    if(fd<2.9*TS&&P.hp<maxHp()){P.regen=0;P.hp=Math.min(maxHp(),P.hp+dt*40);if(Math.random()<dt*3)sfx('heal');}
    wcd-=dt;
    if(hit('KeyE','Enter','KeyJ')){
      let best=null,bd=46;
      for(const n of NPCS){const d=Math.hypot(n.x-P.x,n.y-P.y);if(d<bd){bd=d;best=n;}}
      if(best)openDlg(best);
      else if(tryInteract()){}
      else if(hit('KeyE','Enter')&&fishSpotNear()){startFishing(fishSpotNear());}
      else if(hit('KeyJ')&&state==='play'&&!DLG){WCH.on=true;WCH.t=0;}      // press SHOT: start charging (released early = a normal shot)
    }
    updateWorldCharge(dt);
    updateWorldShots(dt);updateQuestWorld();checkStairs();
  }
  if(!B)reapStale();
  for(const e of enemies){
    if(e.alive&&e.terr)clampTerr(e);
    if(!e.alive){if(e.night||e.spw||e.tmp||e.edDel)continue;e.respawn-=dt;if(e.respawn<=0){if(!e.def.boss&&!window.__NOELITE){eliteRoll(e);applyLevel(e,e.lv);}e.alive=true;resetEnemyState(e);}continue;}
    if(e.engaged)continue;
    updateEnemyWorld(e,dt);
  }
  // camera
  const cy0=camMinY(),tx=clamp(P.x-VW/2,0,Math.max(0,MW*TS-VW)),ty=clamp(P.y-VH/2-10,cy0,Math.max(cy0,MH*TS-VH));
  cam.x=lerp(cam.x,tx,Math.min(1,dt*8));cam.y=lerp(cam.y,ty,Math.min(1,dt*8));
  const an=areaName(Math.floor(P.x/TS),Math.floor(P.y/TS));
  if(an!==areaCur){const first=areaCur==='';areaCur=an;areaT=3;if(!first)saveGame('area');questEvent('area',an);}
  areaT=Math.max(0,areaT-dt);
}
