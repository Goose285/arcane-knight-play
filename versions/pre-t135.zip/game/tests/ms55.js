// M55: editor SAVE (publish world-edits.json to GitHub, mock fetch; baked file merge, no double-apply, migration) + the doubled town and the new Goldenfield Farms region south of it.  node tests/ms55.js
const boot=require('./lib/ms');
(async()=>{
 const {pg,E,ok,sleep,finish}=await boot('ms55',{town:true,grow:true});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);g.DLG=null;g.state='play';d.endFight();});
 await sleep(500);

 console.log("section A");
 // ---------- A. the grown world: doubled town + south region
 const W=await E(()=>{const g=__game,d=g.dbg,w=d.world();return {OW_H:d.OWHv,y0:d.OWY0v,S:d.EXP0.S,ex:d.EXP.S,grow:d.growOn(),townTiles:Math.round((w.TOWN.x1-w.TOWN.x0)/32)*Math.round((w.TOWN.y1-w.TOWN.y0)/32),mini:[d.MINI.ow.spr.width,d.MINI.ow.spr.height],way:d.WAYSTONES.some(q=>q.id==='farm'),lab:d.REGION_LABELS.map(l=>l.name||l.text||l.label||JSON.stringify(l)).join('|'),fishF:d.FISH_SPOTS.some(f=>f.id==='farm1')};});
 ok(W.grow&&W.S===56&&W.ex===56,'the shipped world grows 56 rows south at boot '+JSON.stringify([W.S,W.ex]));
 ok(W.OW_H===104&&W.y0===224,'overworld is 104 rows tall starting at row 224 '+JSON.stringify([W.OW_H,W.y0]));
 ok(W.townTiles===704,'the town area is exactly doubled (352 -> 704 tiles) '+W.townTiles);
 ok(W.way&&W.fishF,'Goldenfield waystone + river fishing spot exist');
 ok(/GOLDENFIELD FARMS/.test(W.lab),'World Map region label names GOLDENFIELD FARMS ('+W.lab+')');
 const R=await E(()=>{const g=__game,d=g.dbg,w=d.world();const N=n=>g.npcs.find(q=>q.name===n);
   const pt=n=>{const q=N(n);return q?[Math.floor(q.x/32),Math.floor(q.y/32)]:null;};
   const sx=Math.floor(w.SPAWN.x/32),sy=Math.floor(w.SPAWN.y/32);
   // BFS over walkable tiles from the spawn
   const H=w.MH,Wd=d.MWv,seen=new Uint8Array(H*Wd),q=[[sx,sy]];seen[sy*Wd+sx]=1;
   while(q.length){const [x,y]=q.pop();for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=Wd||ny>=H||seen[ny*Wd+nx])continue;if(w.solidTile(nx,ny))continue;seen[ny*Wd+nx]=1;q.push([nx,ny]);}}
   const reach=(tx,ty)=>!!seen[ty*Wd+tx];
   const names=['Farmer Hale','Orchard Keeper Mira','Gate Warden Hollis','Baker Wren','Mason Dov'];
   const foes=g.enemies.filter(e=>e.type==='boar'||e.type==='scarecrow');
   const q2=d.QUEST_BY_ID.boars;
   return {npcs:names.map(n=>[n,!!N(n),N(n)?reach(...pt(n)):false]),foes:foes.length,boars:foes.filter(e=>e.type==='boar').length,scare:foes.filter(e=>e.type==='scarecrow').length,
     lv:[Math.min(...foes.map(e=>e.lv)),Math.max(...foes.map(e=>e.lv))],
     inFarm:foes.every(e=>d.areaName(Math.floor(e.x/32),Math.floor(e.y/32))==='GOLDENFIELD FARMS'),
     elderReach:reach(...pt('Elder Orin')),
     areas:[d.areaName(8,52+224-224+224),d.areaName(12,80+224),d.areaName(12,5+224)],
     giver:q2&&q2.giver,
     elder:!!N('Elder Orin'),way:d.WAYSTONES.find(w=>w.id==='farm')};});
 for(const [n,has,r] of R.npcs)ok(has&&r,n+' exists and can be walked to from the spawn');
 ok(R.elderReach,'Elder Orin is still reachable');
 ok(R.boars>=6&&R.scare>=4,'boars and scarecrows live in the fields '+R.boars+'/'+R.scare);
 ok(R.lv[0]>=5&&R.lv[1]<=9,'farm enemies are early/mid level '+R.lv);
 ok(R.inFarm,'every boar/scarecrow stands inside the Goldenfield Farms region');
 ok(R.giver==='Farmer Hale','quest "Boars in the Barley" is given by Farmer Hale');
 ok(R.areas[0]==='OAKVALE VILLAGE'||/OAKVALE/.test(R.areas[0]),'town quarter tile is named Oakvale ('+R.areas[0]+')');
 ok(R.areas[1]==='GOLDENFIELD FARMS','a field tile is named Goldenfield Farms ('+R.areas[1]+')');
 // quest flow: talk to Hale, kill 4 boars
 const Q=await E(()=>{const d=__game.dbg;d.questStart('boars');const s0=d.questStatus('boars');for(let i=0;i<4;i++)d.questEvent('kill','boar');return {s0,s1:d.questStatus('boars')};});
 ok(Q.s0!==Q.s1,'killing four boars advances the farm quest '+JSON.stringify(Q));
 // expand still works on top of the grown base; RESET returns to it
 const X=await E(()=>{const d=__game.dbg;d.edOpen();d.edExpand&&0;d.edPush({k:'expand',d:'e',n:6});const a=[d.MWv,d.EXP.E];d.ED.resetAt=-99;d.edReset();d.edReset();return {a,b:[d.MWv,d.EXP.E,d.EXP.S,d.OWHv],n:d.ED.ops.length};});
 ok(X.a[1]===54,'an east expansion still works on the grown world '+JSON.stringify(X.a));
 ok(X.b[1]===48&&X.b[2]===56&&X.b[3]===104&&X.n===0,'RESET returns to the shipped (grown) layout '+JSON.stringify(X.b));

 console.log("section B");
 // ---------- B. publish with a mock fetch
 await E(()=>{const d=__game.dbg;d.edOpen();localStorage.removeItem(d.ED_TOKEN_KEY);d.ED.ops=[];d.ED.bakedOps=[];d.ED.pub.busy=false;});
 const P=await E(async()=>{const d=__game.dbg;const g0=d.map[240]&&d.map[240][10];
   d.edPush({k:'tiles',t:[[10,240,d.map[240][11]]]});
   const calls=[],real=window.fetch;
   window.fetch=(u,o)=>{o=o||{};calls.push({u:String(u),m:o.method||'GET',auth:o.headers&&o.headers.Authorization,b:o.body});
     if(!o.method||o.method==='GET')return Promise.resolve(new Response(JSON.stringify({sha:'abc123'}),{status:200}));
     return Promise.resolve(new Response(JSON.stringify({content:{}}),{status:200}));};
   // no token: opens the settings box, no network
   await d.edPublish();const noTok={calls:calls.length,box:!!document.getElementById('edSaveBox')&&document.getElementById('edSaveBox').style.display!=='none',msg:d.ED.pub.msg};
   document.getElementById('edSaveBox').style.display='none';
   localStorage.setItem(d.ED_TOKEN_KEY,'github_pat_TESTTOKEN');
   const p=d.edPublish();const during=d.ED.pub.msg;await p;
   const out={noTok,during,after:d.ED.pub.msg,calls};window.fetch=real;return out;});
 ok(P.noTok.calls===0&&P.noTok.box,'SAVE without a token opens the settings box and sends nothing');
 ok(/^Saving/.test(P.during),'status says Saving... while working ('+P.during+')');
 ok(/^Saved! Live in ~1 min/.test(P.after),'status says Saved! Live in ~1 min ('+P.after+')');
 const gets=P.calls.filter(c=>c.m==='GET'),puts=P.calls.filter(c=>c.m==='PUT');
 ok(gets.length===1&&puts.length===1&&P.calls[0].m==='GET','one GET (sha) then one PUT');
 ok(/^https:\/\/api\.github\.com\/repos\/Goose285\/arcane-knight-play\/contents\/world-edits\.json/.test(puts[0].u),'PUT goes to the contents API for world-edits.json');
 ok(puts[0].auth==='Bearer github_pat_TESTTOKEN','token sent as Bearer auth');
 let pb={},pj={};try{pb=JSON.parse(puts[0].b);pj=JSON.parse(Buffer.from(pb.content,'base64').toString('utf8'));}catch(e){}
 ok(pb.branch==='main'&&pb.sha==='abc123'&&/World edits/.test(pb.message),'PUT body has branch main, the sha from the GET and a message');
 ok(Array.isArray(pj.ops)&&pj.ops.length===1&&pj.ops[0].k==='tiles'&&pj.v===2&&pj.g===1,'committed file is the edit layer JSON (1 tile op, v2, grown)');
 ok(!JSON.stringify(pj).includes('TESTTOKEN')&&!puts[0].b.includes('TESTTOKEN'),'the token never goes into the committed file');
 // 404 on GET (no file yet) -> PUT without sha; 401 -> friendly text + box
 const P2=await E(async()=>{const d=__game.dbg;d.ED.pub.busy=false;const calls=[],real=window.fetch;
   window.fetch=(u,o)=>{o=o||{};calls.push({m:o.method||'GET',b:o.body});if(!o.method)return Promise.resolve(new Response('{}',{status:404}));return Promise.resolve(new Response('{}',{status:200}));};
   await d.edPublish();const a={msg:d.ED.pub.msg,put:calls.find(c=>c.m==='PUT')};
   d.ED.pub.busy=false;window.fetch=(u,o)=>Promise.resolve(new Response(JSON.stringify({message:'Bad credentials'}),{status:401}));await d.edPublish();const b=d.ED.pub.msg;
   d.ED.pub.busy=false;window.fetch=()=>Promise.reject(new TypeError('offline'));await d.edPublish();const c=d.ED.pub.msg;
   window.fetch=real;return {a,b,c};});
 ok(/^Saved!/.test(P2.a.msg)&&!JSON.parse(P2.a.put.b).sha,'first publish (no file yet) PUTs without a sha');
 ok(/^Save failed: Token rejected/.test(P2.b),'a 401 shows a friendly error ('+P2.b+')');
 ok(/^Save failed: Cannot reach GitHub/.test(P2.c),'offline shows a friendly error ('+P2.c+')');

 console.log("section C");
 // ---------- C. the baked file: merge, no double apply, missing = no-op
 const M=await E(async()=>{const d=__game.dbg;
   // local layer = [A,B]; a baked file arrives that already contains A,B -> local layer retires
   d.ED.ops=[];d.ED.bakedOps=[];d.ED.redo.length=0;d.edReset();d.ED.resetAt=-99;d.edReset();
   const A={k:'tiles',t:[[10,240,d.map[240][11]]]},B={k:'tiles',t:[[12,240,d.map[240][11]]]};
   d.edPush(A);d.edPush(B);
   d.edAdoptBaked([A,B]);await new Promise(r=>setTimeout(r,100));
   const s1={local:d.ED.ops.length,baked:d.ED.bakedOps.length,saved:localStorage.getItem('ak_world_edits_v1')};
   // a later local edit C stacks after the baked ops
   const C={k:'tiles',t:[[14,240,d.map[240][11]]]};d.edPush(C);
   d.edAdoptBaked([A,B]);const s2={local:d.ED.ops.length,baked:d.ED.bakedOps.length};
   // the baked file grows to [A,B,C]: C leaves the local layer
   d.edAdoptBaked([A,B,C]);await new Promise(r=>setTimeout(r,100));const s3={local:d.ED.ops.length,baked:d.ED.bakedOps.length};
   // baked tile edits are really in the map, exactly once
   const real=window.fetch;window.fetch=()=>Promise.resolve(new Response('',{status:404}));const miss=await d.edLoadBaked();
   window.fetch=()=>Promise.resolve(new Response(JSON.stringify({v:2,g:1,ops:[]}),{status:200}));const empty=await d.edLoadBaked();
   window.fetch=real;
   d.ED.bakedOps=[];d.edReset();d.ED.resetAt=-99;d.edReset();
   return {s1,s2,s3,miss,empty};});
 ok(M.s1.local===0&&M.s1.baked===2&&M.s1.saved===null,'baked file already holding the local edits retires the local layer (no double apply) '+JSON.stringify(M.s1));
 ok(M.s2.local===1&&M.s2.baked===2,'a newer local edit stays on top of the baked ops');
 ok(M.s3.local===0&&M.s3.baked===3,'once the baked file catches up the local edit is dropped '+JSON.stringify(M.s3));
 ok(M.miss===false&&M.empty===true||M.miss===false,'a missing world-edits.json is a no-op ('+M.miss+')');
 // migration of a pre-growth layer (rows were relative to the old overworld at row 0)
 const G=await E(()=>{const d=__game.dbg;return {
   t:d.edMigrate({g:0,ops:[{k:'tiles',t:[[5,10,3]]},{k:'house',x:3,y:4,nx:6,ny:7},{k:'npc',i:0,n:'Elder Orin',x:100,y:200}]}),
   same:d.edMigrate({g:1,ops:[{k:'tiles',t:[[5,10,3]]}]})};});
 ok(G.t[0].t[0][1]===234&&G.t[1].y===228&&G.t[1].ny===231&&G.t[2].y===200+224*32,'a legacy layer is shifted onto the new overworld rows '+JSON.stringify(G.t));
 ok(G.same[0].t[0][1]===10,'a layer already made on the grown world is left alone');

 console.log("section D");
 // ---------- D. service worker + sync script on disk
 const fs=require('fs'),path=require('path'),root=path.join(__dirname,'..');
 const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8'),sw2=fs.readFileSync(path.join(root,'app/www/sw.js'),'utf8');
 ok(/arcane-knight-v4[4-9]/.test(sw)&&sw===sw2,'sw.js is v44+ and identical in app/www');
 ok(/world-edits\\\.json/.test(sw)&&/no-store/.test(sw),'service worker fetches world-edits.json network-first (no-store)');
 const os=require('os'),cp=require('child_process'),tmp=fs.mkdtempSync(path.join(os.tmpdir(),'play-'));
 fs.writeFileSync(path.join(tmp,'world-edits.json'),'{"ops":[1]}');fs.mkdirSync(path.join(tmp,'.git'));fs.writeFileSync(path.join(tmp,'old.txt'),'x');
 cp.execFileSync('node',[path.join(root,'scripts/sync-play.js'),tmp]);
 ok(fs.readFileSync(path.join(tmp,'world-edits.json'),'utf8')==='{"ops":[1]}'&&fs.existsSync(path.join(tmp,'.git'))&&fs.existsSync(path.join(tmp,'index.html'))&&fs.existsSync(path.join(tmp,'old.txt')),'sync-play copies the build but keeps world-edits.json, .git and other files');
 ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
