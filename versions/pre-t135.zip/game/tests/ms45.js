// M45: leather satchel pause/inventory menu: tabs, recessed slots, tap = parchment tooltip with the item name, straps.  node tests/ms45.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,shot,finish}=await boot('ms45',{town:true,device:MOB?'iPhone 12 landscape':undefined});
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.6);d.endFight();g.tp(24,41);g.P.grace=99;g.P.lv=7;g.P.gold=116;
   for(const e of g.enemies)if(e.alive){e.alive=false;e.hidden=true;e.x=64;e.y=64;e.respawn=1e9;}
   const a=d.genGear('weapon',6,'rare',false),b=d.genGear('armor',5,'epic',false);d.addGear(a);d.addGear(b);d.addGear(d.genGear('ring',4,'uncommon',false));d.equipGear(a);
   d.FSH.rod=0;d.FSH.fish={trout:2,carp:3};d.CR.mat.fscale=3;d.CR.mat.bone=2;g.state='paused';d.pauseReset();});
 await sleep(500);
 const L=await E(()=>{const d=__game.dbg,z=__game.size,rs=d.getPauseRects(),S=d.PAUSE.sat;return {tabs:rs.filter(r=>r.kind==='tab').length,straps:rs.filter(r=>r.kind==='strap').map(r=>r.e.id),slots:d.PAUSE.slotRects.length,items:d.satItems().length,fit:rs.every(q=>q.x>=0&&q.y>=0&&q.x+q.w<=z.VW&&q.y+q.h<=z.VH)&&S.bx>=0&&S.bx+S.Wb<=z.VW,sat:S};});
 ok(L.tabs===7&&L.straps.join()==='resume,home,quit','7 bookmark tabs + 3 straps (Resume / Home / Save & Quit)');
 ok(L.slots>=12&&L.items>=6,'recessed slots ('+L.slots+') show the gear / fish / materials ('+L.items+' items)');
 ok(L.fit,'satchel fits the screen');
 await shot('satchel-menu.png');
 // tap slot 0 -> parchment tooltip with the item name (the equipped weapon)
 const tapSlot=async i=>{const p=await E(i=>{const r=__game.dbg.PAUSE.slotRects[i];const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},i);if(MOB)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(250);};
 await tapSlot(0);
 const t=await E(()=>{const d=__game.dbg;return {tip:d.PAUSE.tipItem&&d.PAUSE.tipItem.name,name:d.satItems()[0].name,st:__game.state};});
 ok(t.tip&&t.tip===t.name&&t.st==='paused','tapping a slot shows a tooltip with the item name ('+t.tip+')');
 await shot('satchel-menu-tooltip.png');
 await tapSlot(0);ok(await E(()=>!__game.dbg.PAUSE.tipItem),'tapping the slot again hides it');
 await tapSlot(5);ok(await E(()=>!!__game.dbg.PAUSE.tipItem),'another slot shows its own name');
 const emp=await E(()=>__game.dbg.PAUSE.slotRects.length-1);await tapSlot(emp);ok(await E(()=>!__game.dbg.PAUSE.tipItem),'an empty slot shows nothing');
 // tabs / straps still work
 const tapKind=async id=>{const p=await E(id=>{const r=__game.dbg.getPauseRects().find(q=>q.e.id===id);const c=document.getElementById('c').getBoundingClientRect(),z=__game.size;return {x:c.left+(r.x+r.w/2)/z.VW*c.width,y:c.top+(r.y+r.h/2)/z.VH*c.height};},id);if(MOB)await pg.touchscreen.tap(p.x,p.y);else await pg.mouse.click(p.x,p.y);await sleep(300);};
 await tapKind('inventory');ok(await E(()=>__game.state)==='gear','the INVENTORY tab opens the equipment screen');await E(()=>{__game.dbg.closeUI();});await sleep(200);
 await tapKind('resume');ok(await E(()=>__game.state)==='play','the RESUME strap closes the menu');
 await finish();
})();
