// M54: in-game World Editor (pause menu -> EDITOR): move houses / NPCs / props / spawns by touch drag, paint ground, props palette, NPC name + dialogue, undo/redo, persistence + reset, export.  node tests/ms54.js [desktop|mobile]
const boot=require('./lib/ms');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms54',{town:true,device:MOB?'iPhone 12 landscape':undefined,keepSave:false});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 await E(()=>{window.__NOMETA=true;window.__NOTUT=true;window.__NOACH=true;window.__NOELITE=true;const g=__game,d=g.dbg;if(d.TUT.on)d.tutFinish(true);d.toasts.length=0;g.DLG=null;g.state='play';d.setTimeOfDay(.5);d.endFight();d.TRK.open=false;
   for(const e of g.enemies)if(e.alive){e.mt=1e9;e.lk=1e9;}g.tp(14,38);g.P.x=14.5*32;g.P.y=38*32+28;g.P.grace=99;});
 // screen position (css px) of a logical point / of a world tile centre
 const css=(lx,ly)=>E((lx,ly)=>{const r=document.querySelector('canvas').getBoundingClientRect(),g=__game;return {x:r.left+lx/g.size.VW*r.width,y:r.top+ly/g.size.VH*r.height};},lx,ly);
 const tileCss=(tx,ty,fy=.5)=>E((tx,ty,fy)=>{const r=document.querySelector('canvas').getBoundingClientRect(),g=__game;return {x:r.left+((tx+.5)*32-Math.round(g.cam.x))/g.size.VW*r.width,y:r.top+((ty+fy)*32-Math.round(g.cam.y))/g.size.VH*r.height};},tx,ty,fy);
 const drag=async(a,b)=>{if(MOB){const h=await pg.touchscreen.touchStart(a.x,a.y);await sleep(40);for(let i=1;i<=6;i++){await h.move(a.x+(b.x-a.x)*i/6,a.y+(b.y-a.y)*i/6);await sleep(25);}await h.end();}else{await pg.mouse.move(a.x,a.y);await pg.mouse.down();for(let i=1;i<=6;i++){await pg.mouse.move(a.x+(b.x-a.x)*i/6,a.y+(b.y-a.y)*i/6);await sleep(25);}await pg.mouse.up();}await sleep(80);};
 const tap=async(a)=>{if(MOB)await pg.touchscreen.tap(a.x,a.y);else await pg.mouse.click(a.x,a.y);await sleep(120);};
 const wCss=(x,y)=>E((x,y)=>{const r=document.querySelector('canvas').getBoundingClientRect(),g=__game;return {x:r.left+(x-Math.round(g.cam.x))/g.size.VW*r.width,y:r.top+(y-Math.round(g.cam.y))/g.size.VH*r.height};},x,y);
 const btn=(lab)=>E((lab)=>{const r=__game.dbg.ED.rects.find(q=>q.lab.trim()===lab);return r?{x:r.x+r.w/2,y:r.y+r.h/2}:null;},lab);
 const tapBtn=async(lab)=>{const b=await btn(lab);if(!b)return false;const c=await css(b.x,b.y);await tap(c);return true;};
 const key=(k,n)=>E((k,n)=>k+':'+(__game.dbg.T[n]!==undefined?__game.dbg.T[n]:n),k,n);
 // tap a thumbnail in the picture tray (switching to its category tab first)
 const pick=async(k)=>{const cat=await E(k=>__game.dbg.ED_ITEM_BY[k].cat,k);await tapBtn(cat);await sleep(100);const c=await E(k=>{const d=__game.dbg.ED,q=d.cells.find(c=>c.key===k);return q?{x:q.x+q.w/2,y:q.y+q.h/2}:null;},k);if(!c)return false;await tap(await css(c.x,c.y));return true;};
 // hold a finger / the mouse on a tile, report the editor's ghost while it is down, then lift
 const holdThenLift=async(a,probe)=>{let r;if(MOB){const h=await pg.touchscreen.touchStart(a.x,a.y);await sleep(150);r=await pg.evaluate(probe);await h.end();}else{await pg.mouse.move(a.x,a.y);await pg.mouse.down();await sleep(150);r=await pg.evaluate(probe);await pg.mouse.up();}await sleep(120);return r;};
 // ---- 1. open from the pause menu
 await E(()=>{__game.state='paused';});await sleep(300);
 const eb=await E(()=>{const r=document.querySelector('canvas').getBoundingClientRect(),g=__game;const q=g.dbg.getPauseRects().find(x=>x.e&&x.e.id==='editor');return q?{x:r.left+(q.x+q.w/2)/g.size.VW*r.width,y:r.top+(q.y+q.h/2)/g.size.VH*r.height}:null;});
 ok(!!eb,'pause menu has an EDITOR button');
 if(eb)await tap(eb);await sleep(300);
 const st=await E(()=>({s:__game.state,S:__game.size.S,n:__game.dbg.ED.rects.length}));
 ok(st.s==='editor'&&st.n>=8,'the editor opens (state '+st.s+', '+st.n+' buttons)');
 // ---- 2. drag your house one tile right (door + trigger follow)
 const H0=await E(()=>{const d=__game.dbg;return {tx:d.HOUSE_DOOR.tx,ty:d.HOUSE_DOOR.ty,hs:d.edHouses().find(h=>h.dx===d.HOUSE_DOOR.tx)};});
 await E((tx,ty)=>{const g=__game;g.cam.x=(tx-8)*32;g.cam.y=(ty-9)*32;},H0.tx,H0.ty);await sleep(100);
 await drag(await tileCss(H0.tx-1,H0.hs.y+1),await tileCss(H0.tx,H0.hs.y+1));
 const H1=await E(()=>{const d=__game.dbg,m=d.map,T=d.T;return {tx:d.HOUSE_DOOR.tx,ty:d.HOUSE_DOOR.ty,newDoor:m[d.HOUSE_DOOR.ty-1][d.HOUSE_DOOR.tx]===T.D,oldClear:m[d.HOUSE_DOOR.ty-1][d.HOUSE_DOOR.tx-1]!==T.D,fx:d.HOUSE_FRONT.x,ops:d.ED.ops.length,ls:!!localStorage.getItem('ak_world_edits_v1')};});
 ok(H1.tx===H0.tx+1&&H1.newDoor&&H1.oldClear&&H1.fx===(H1.tx+.5)*32&&H1.ops===1&&H1.ls,'dragging the house 1 tile right moves its door tile, trigger and exit, and is saved '+JSON.stringify(H1));
 // ---- 3. drag an NPC two tiles
 const N0=await E(()=>{const n=__game.npcs.find(q=>q.name==='Elder Orin');return {x:n.x,y:n.y};});
 await E((x,y)=>{const g=__game;g.cam.x=x-420;g.cam.y=y-200;},N0.x,N0.y);await sleep(100);
 await drag(await wCss(N0.x,N0.y-14),await wCss(N0.x-64,N0.y-14));
 const N1=await E(()=>{const n=__game.npcs.find(q=>q.name==='Elder Orin');return {x:n.x,y:n.y};});
 ok(Math.abs(N1.x-(N0.x-64))<1&&N1.y===N0.y,'an NPC drags 2 tiles left with tile snap ('+N0.x+' -> '+N1.x+')');
 // ---- 4. paint water (brush 2), place a tree, spawn a slime, erase
 await E(()=>{const g=__game;g.cam.x=3*32;g.cam.y=18*32;});await sleep(100);
 await tapBtn('BUILD');ok(await pick(await key('t','W')),'the BUILD tray has a Water thumbnail');await tapBtn('x2');
 const sw=await E(()=>({g:__game.dbg.ED.ground,w:__game.dbg.T.W,tool:__game.dbg.ED.tool,b:__game.dbg.ED.brush}));ok(sw.g===sw.w&&sw.tool==='paint'&&sw.b===2,'tapping the water thumbnail selects it (paint tool, brush 2)');
 const pa=await tileCss(8,22),pb=await tileCss(10,22);await drag(pa,pb);
 const W1=await E(()=>{const d=__game.dbg;return [8,9,10,11].map(x=>d.map[22][x]===d.T.W&&d.map[23][x]===d.T.W);});
 ok(W1.filter(Boolean).length>=3,'painting with a 2-wide brush turns a strip to water '+JSON.stringify(W1));
 await pick(await key('p','T'));
 const gh2=await holdThenLift(await tileCss(6,20),()=>{const g=__game,d=g.dbg.ED;return d.ghost?{tx:d.ghost.tx,ty:d.ghost.ty,still:g.dbg.map[20][6]!==g.dbg.T.T,it:d.item}:null;});
 ok(gh2&&gh2.tx===6&&gh2.ty===20&&gh2.still,'a ghost of the tree follows the finger and nothing is placed until you lift ('+JSON.stringify(gh2)+')');
 const tr=await E(()=>__game.dbg.map[20][6]===__game.dbg.T.T);ok(tr,'lifting the finger places the tree');
 const en0=await E(()=>__game.enemies.length);
 const SP=await E(()=>{const d=__game.dbg;for(let y=16;y<22;y++)for(let x=12;x<20;x++)if(d.map[y][x]===d.T.G&&!d.solidTile(x,y))return {x,y};});
 await pick('e:slime');await E((x,y)=>{__game.cam.x=(x-10)*32;__game.cam.y=(y-6)*32;},SP.x,SP.y);await tap(await tileCss(SP.x,SP.y));
 const en1=await E(()=>__game.enemies.length);ok(en1===en0+1,'SLIME palette adds an enemy spawn ('+en0+' -> '+en1+')');
 await E(()=>{__game.cam.x=3*32;__game.cam.y=18*32;});await tapBtn('ERASE');await E(()=>{__game.dbg.ED.brush=1;});await tap(await tileCss(6,20));
 const en1b=await E(()=>__game.enemies.filter(e=>!e.edDel).length);const tr2=await E(()=>__game.dbg.map[20][6]!==__game.dbg.T.T);ok(tr2,'ERASE removes the tree');
 await E((x,y)=>{__game.cam.x=(x-10)*32;__game.cam.y=(y-6)*32;},SP.x,SP.y);await tap(await tileCss(SP.x,SP.y));
 const en2=await E(()=>__game.enemies.filter(e=>!e.edDel).length);ok(en2===en1b-1,'ERASE removes the spawn');
 // ---- 4b. the picture palette
 const tabs=await E(()=>__game.dbg.ED.rects.map(r=>r.lab));await tapBtn('BUILD');
 const tabs2=await E(()=>__game.dbg.ED.rects.map(r=>r.lab.trim()));
 ok(['Ground','Water','Roads','Nature','Props','Enemies','NPCs'].every(c=>tabs2.includes(c)),'tray has the seven category tabs ('+tabs2.filter(l=>/^[A-Z][a-z]/.test(l)).join(',')+')');
 const art=await E(()=>{const d=__game.dbg,out={bad:[],n:d.ED_ITEMS.length,cats:{}};for(const it of d.ED_ITEMS){out.cats[it.cat]=(out.cats[it.cat]||0)+1;const A=d.edArt(it),c=A.spr||A.tile;if(!c){out.bad.push(it.key);continue;}const g=c.getContext('2d').getImageData(0,0,c.width,c.height).data;let o=0;for(let i=3;i<g.length;i+=4)if(g[i]>0)o++;if(o<8)out.bad.push(it.key);}return out;});
 ok(art.bad.length===0&&art.n>=40,'every palette item has a real in-game thumbnail ('+art.n+' items, bad: '+art.bad.join(',')+')');
 ok(art.cats.Ground>=7&&art.cats.Water>=2&&art.cats.Roads>=3&&art.cats.Nature>=7&&art.cats.Props>=7&&art.cats.Enemies>=11&&art.cats.NPCs>=7,'categories are filled '+JSON.stringify(art.cats));
 // selected thumbnail is highlighted
 await pick(await key('t','P'));const hl=await E(()=>{const d=__game.dbg.ED;return {item:d.item,sel:d.cells.filter(c=>c.key===d.item).length,tool:d.tool,ground:d.ground,P:__game.dbg.T.P};});
 ok(hl.item==='t:'+hl.P&&hl.sel===1&&hl.ground===hl.P&&hl.tool==='paint','tapping the gravel road thumbnail selects (and highlights) it');
 // road auto-tiles: painting beside a road tile changes its look right away (no stale cache)
 await E(()=>{__game.cam.x=3*32;__game.cam.y=18*32;});await sleep(100);
 const spot=await E(()=>{const d=__game.dbg;for(let y=15;y<21;y++)for(let x=14;x<26;x++)if([0,1,2].every(i=>d.map[y][x+i]===d.T.G&&d.map[y-1][x+i]===d.T.G&&d.map[y+1][x+i]===d.T.G))return {x,y};});
 await E((x,y)=>{__game.cam.x=(x-10)*32;__game.cam.y=(y-6)*32;},spot.x,spot.y);await sleep(100);
 const sig=(x,y)=>E((x,y)=>__game.tileSpriteOf(__game.dbg.T.P,x,y,0).toDataURL(),x,y);
 await tapBtn('x1');await tap(await tileCss(spot.x,spot.y));
 const rd0=await sig(spot.x,spot.y);await tap(await tileCss(spot.x+1,spot.y));const rd1=await sig(spot.x,spot.y);
 const rd2=await E((x,y)=>{__game.dbg.PATH_CACHE.clear();return __game.tileSpriteOf(__game.dbg.T.P,x,y,0).toDataURL();},spot.x,spot.y);
  ok(rd0!==rd1&&rd1===rd2,'road edge blending updates immediately when a neighbour road tile is painted');
 // water banks auto-blend: a grass tile beside the water now carries a bank mask
 const wm=await E(()=>{const d=__game.dbg,m=d.WE_MASK();if(!m)return -1;let best=0;for(const [x,y] of [[7,22],[7,23],[12,22],[12,23],[8,21],[9,21],[10,21],[11,21],[8,24],[9,24],[10,24],[11,24]])if([d.T.G,d.T.K].includes(d.map[y][x]))best=Math.max(best,m[y*d.MWv+x]);return best;}); ok(wm>0,'grass beside painted water gets a bank edge mask ('+wm+')');
 // house from the tray
 const hs0=await E(()=>__game.dbg.edHouses().length);const hspot=await E(()=>{const d=__game.dbg;for(let y=19;y<30;y++)for(let x=14;x<30;x++){let f=true;for(let r=-2;r<=0&&f;r++)for(let c=-2;c<=2;c++)if(!(d.edWhy(d.ED_ITEM_BY['b:5'],x,y)===null))f=false;if(f)return {x,y};}return null;});
 await E((x,y)=>{__game.cam.x=(x-10)*32;__game.cam.y=(y-6)*32;},hspot.x,hspot.y);await sleep(100);
 await pick('b:5');const hg=await holdThenLift(await tileCss(hspot.x,hspot.y),()=>{const g=__game,d=g.dbg.ED;return d.ghost?{ok:d.ghost.ok,still:g.dbg.edHouses().length}:null;});
 const hs1=await E(()=>__game.dbg.edHouses().length);const dr=await E((x,y)=>__game.dbg.map[y][x]===__game.dbg.T.D,hspot.x,hspot.y);
 ok(hg&&hg.ok&&hg.still===hs0&&hs1===hs0+1&&dr,'a house from the tray shows a ghost, then lands with its door under the finger ('+hs0+' -> '+hs1+')');
 // NPCs / signs from the tray: added, deletable, undoable
 const nn0=await E(()=>__game.npcs.length);const nspot=await E(()=>{const d=__game.dbg;for(let y=15;y<22;y++)for(let x=14;x<26;x++)if(d.edWhy(d.ED_ITEM_BY['n:sign'],x,y)===null&&d.map[y][x]===d.T.G)return {x,y};});
 await E((x,y)=>{__game.cam.x=(x-10)*32;__game.cam.y=(y-6)*32;},nspot.x,nspot.y);await sleep(100);
 await pick('n:sign');await tap(await tileCss(nspot.x,nspot.y,.6));const nn1=await E(()=>({n:__game.npcs.length,s:__game.npcs[__game.npcs.length-1]}));
  ok(nn1.n===nn0+1&&nn1.s.edAdded&&nn1.s.spr==='houseSign'&&nn1.s.lines.length>0,'a sign post can be placed from the tray and talks ('+nn1.n+')');
 await tapBtn('ERASE');await tap(await tileCss(nspot.x,nspot.y,.6));const nn2=await E(()=>{const n=__game.npcs[__game.npcs.length-1];return n.x<0;});ok(nn2,'ERASE removes a placed NPC / sign');
 await tapBtn('UNDO');const nn3=await E(()=>{const n=__game.npcs[__game.npcs.length-1];return n.x>0&&n.edAdded;});ok(nn3,'UNDO brings the removed sign back');
 await tapBtn('UNDO');const nn4=await E(()=>__game.npcs.length);ok(nn4===nn0,'UNDO of the placement removes the sign again ('+nn0+' -> '+nn4+')'+JSON.stringify(await E(()=>({b:__game.dbg.ED.base.npcs.length,ops:__game.dbg.ED.ops.map(o=>o.k),bk:__game.dbg.ED.bakedOps.length}))));
 // enemy thumbnails are the enemy sprites
 const es=await E(()=>{const d=__game.dbg;return d.ED_ITEMS.filter(i=>i.kind==='e').every(i=>d.edArt(i).spr&&d.edArt(i).spr.width>=16);});ok(es,'enemy spawn thumbnails use the enemy sprites');
 // the tray scrolls when it holds more than fits
 await tapBtn('BUILD');await tapBtn('Enemies');const sc=await E(()=>{const d=__game.dbg;const base=d.ED_ITEMS.length;const extra=d.ED_ITEMS.filter(i=>i.cat==='Enemies');for(let k=0;k<4;k++)for(const i of extra)d.ED_ITEMS.push({...i});return base;});await sleep(150);
 const t0=await E(()=>({x:__game.dbg.ED.trayX,max:__game.dbg.ED.trayMax,r:__game.dbg.ED.trayRect}));
 if(t0.max>0){const tc=await css(t0.r.x+t0.r.w*.6,t0.r.y+t0.r.h/2),td=await css(t0.r.x+t0.r.w*.1,t0.r.y+t0.r.h/2);await drag(tc,td);}
 const t1=await E(()=>__game.dbg.ED.trayX);await E(sc=>{__game.dbg.ED_ITEMS.length=sc;},sc);await sleep(120);
 ok(t0.max>0&&t1>20,'dragging the tray scrolls the thumbnails ('+Math.round(t0.x)+' -> '+Math.round(t1)+' of '+Math.round(t0.max)+')');
 await E(()=>{__game.dbg.ED.trayX=0;});
 // ---- 5. NPC name + dialogue (prompt overridden)
 await tapBtn('MOVE');
 await E((x,y)=>{const g=__game;g.cam.x=x-420;g.cam.y=y-200;},N1.x,N1.y);await sleep(100);
 await tap(await wCss(N1.x,N1.y-14));
 const sel=await E(()=>__game.dbg.ED.sel&&__game.dbg.ED.sel.kind);ok(sel==='npc','tapping an NPC selects it');
 await E(()=>{window.__pr=['Old Orin','Hello there! | Second line'];window.prompt=()=>window.__pr.shift();});
 await tapBtn('NAME');await tapBtn('DIALOGUE');
 const nl=await E(()=>{const n=__game.npcs.find(q=>q.name==='Elder Orin');return {label:n.label,lines:n.lines};});
 ok(nl.label==='Old Orin'&&nl.lines.length===2&&nl.lines[0]==='Hello there!','NPC name + dialogue edited ('+JSON.stringify(nl)+')');
 // ---- 6. undo / redo
 const ops=await E(()=>__game.dbg.ED.ops.length);
 await tapBtn('UNDO');await tapBtn('UNDO');
 const u=await E(()=>({ops:__game.dbg.ED.ops.length,label:__game.npcs.find(q=>q.name==='Elder Orin').label}));
 ok(u.ops===ops-2&&u.label===undefined,'undo steps back through the edits ('+ops+' -> '+u.ops+')');
 await tapBtn('REDO');const r2=await E(()=>__game.dbg.ED.ops.length);ok(r2===ops-1,'redo re-applies');
 // ---- 7. zoom
 const z0=await E(()=>__game.size.S);await tapBtn('+');const z1=await E(()=>__game.size.S);await tapBtn('-');await tapBtn('-');const z2=await E(()=>__game.size.S);
 ok(z1===z0+1&&z2===Math.max(1,z0-1),'zoom +/- changes the pixel scale ('+z0+' -> '+z1+' -> '+z2+')');
 // ---- 8. export
 await tapBtn('EXPORT');const ex=await E(()=>{const t=document.getElementById('edExportText');return t&&t.value;});
 let jj=null;try{jj=JSON.parse(ex);}catch(e){}ok(jj&&jj.v===2&&jj.ops.length===r2&&jj.world&&jj.world.expand&&jj.world.cols===64,'EXPORT shows the edits as JSON ('+(jj&&jj.ops.length)+' ops)');
 await E(()=>{document.getElementById('edExport').style.display='none';});
 // ---- 9. persistence: reload applies the overlay; RESET removes it
 await E(()=>__game.dbg.edExit());
 await pg.reload();await sleep(800);
 const P2=await E(()=>({tx:__game.dbg.HOUSE_DOOR.tx,ops:__game.dbg.ED.ops.length,orin:__game.npcs.find(q=>q.name==='Elder Orin').x}));
 ok(P2.tx===H0.tx+1&&P2.ops===r2&&Math.abs(P2.orin-(N0.x-64))<1,'after a reload the saved edits are applied on load ('+JSON.stringify(P2)+')');
 await E(()=>{const g=__game;g.state='paused';});await sleep(200);await E(()=>__game.dbg.edOpen());
 await E(()=>{__game.state='editor';});
 await sleep(400);await tapBtn('RESET');await tapBtn('RESET');
 const P3=await E(()=>({tx:__game.dbg.HOUSE_DOOR.tx,ops:__game.dbg.ED.ops.length,ls:localStorage.getItem('ak_world_edits_v1'),orin:__game.npcs.find(q=>q.name==='Elder Orin').x,dm:__game.dbg.map[__game.dbg.HOUSE_DOOR.ty-1][__game.dbg.HOUSE_DOOR.tx]===__game.dbg.T.D}));
 ok(P3.tx===H0.tx&&P3.ops===0&&P3.ls===null&&Math.abs(P3.orin-N0.x)<1&&P3.dm,'RESET removes every edit and restores the original world ('+JSON.stringify(P3)+')');

 // ---- 10. camera tool, arrows, world expansion
 const cam=()=>E(()=>({x:__game.cam.x,y:__game.cam.y}));
 await tapBtn('CAM');await E(()=>{__game.cam.x=200;__game.cam.y=1000;});await sleep(80);
 const a0=await cam(),pq1=await css(200,100),pq2=await css(130,70);await drag(pq1,pq2);const a1=await cam();
 ok(Math.abs(a1.x-a0.x)>25&&Math.abs(a1.y-a0.y)>10,'CAM tool: one-finger drag pans the camera ('+Math.round(a0.x)+','+Math.round(a0.y)+' -> '+Math.round(a1.x)+','+Math.round(a1.y)+')');
 const ar=await btn('>');const arC=await css(ar.x,ar.y);const b0=await cam();
 if(MOB){const h=await pg.touchscreen.touchStart(arC.x,arC.y);await sleep(900);await h.end();}else{await pg.mouse.move(arC.x,arC.y);await pg.mouse.down();await sleep(900);await pg.mouse.up();}
 const b1=await cam();ok(b1.x>b0.x+40,'on-screen arrow: holding > glides the camera right ('+Math.round(b0.x)+' -> '+Math.round(b1.x)+')');
 await E(()=>{__game.cam.x=-9999;__game.cam.y=-9999;});await sleep(150);const e0=await cam();
 ok(e0.x<0&&e0.x>=-5*32-1&&e0.y<0&&e0.y>=-5*32-1,'camera may drift a little past the map edges, no further ('+Math.round(e0.x)+','+Math.round(e0.y)+')');
 const SZ=()=>E(()=>{const g=__game,d=g.dbg,w=d.world();const o=g.npcs.find(q=>q.name==='Elder Orin'),gd=g.npcs.find(q=>q.tguard);return {mw:d.MWv,oh:d.OWHv,y0:d.OWY0v,ox:d.OXv,oy:d.OYv,mh:w.MH,orin:{x:o.x,y:o.y},door:{...d.HOUSE_DOOR},sp:{...w.SPAWN},px:g.P.x,py:g.P.y,en:g.enemies.length,
    doorTile:d.map[d.HOUSE_DOOR.ty-1][d.HOUSE_DOOR.tx]===d.T.D,orinOk:!w.solidTile(Math.floor(o.x/32),Math.floor(o.y/32)),guardOk:!w.solidTile(Math.floor(gd.x/32),Math.floor(gd.y/32)),
    cryptIn:d.map[w.CRYPT_IN.y][w.CRYPT_IN.x]===d.T.CS,gates:Object.keys(w.GATES).every(k=>{const [x,y]=k.split(',').map(Number);return d.map[y][x]===d.T.GT;}),
    fish:w.FISH_SPOTS.filter(f=>w.zoneOfPx(f.ty*32)==='ow').every(f=>d.map[f.ty][f.tx]===d.T.W),chapel:d.map[w.CHAPEL.y1][w.CHAPEL.door]===d.T.CHC,inn:d.map[w.INN.y1][w.INN.door]===d.T.D,
    way:w.WAYSTONES.filter(q=>q.tx!=null).every(q=>{const n=g.npcs.find(m=>m.way===q.id);return n&&Math.abs(n.x-(q.tx+.5)*32)<1&&!w.solidTile(q.tx,q.ty);}),
    zonePl:w.zoneOfPx(g.P.y),mini:[w.MINI.ow.spr.width,w.MINI.ow.spr.height,w.MINI.ow.y0],town:{...w.TOWN},crypt:w.zoneOfPx(w.CRYPT_ARRIVE.y)}; });
 const Z0=await SZ();ok(Z0.mw===64&&Z0.oh===48&&Z0.y0===0&&Z0.mini[0]===128&&Z0.mini[1]===96,'baseline world is 64 x 48 ('+JSON.stringify([Z0.mw,Z0.oh,Z0.y0])+')');
 await tapBtn('EXPAND');const ns=await E(()=>__game.dbg.ED.rects.map(r=>r.lab).join(','));
 ok(/NORTH \+8/.test(ns)&&/SOUTH \+8/.test(ns)&&/EAST \+8/.test(ns)&&/WEST \+8/.test(ns)&&/\+4/.test(ns)&&/\+16/.test(ns),'EXPAND tool shows N / S / E / W buttons and +4 / +8 / +16 amounts');
 await tapBtn('NORTH +8');await sleep(200);const Z1=await SZ();
 ok(Z1.oh===56&&Z1.mw===64&&Z1.y0===224&&Z1.oy===232&&Z1.mh===224+56&&Z1.mini[1]===112&&Z1.mini[2]===224,'NORTH +8: 56 rows, overworld now starts at row 224 ('+JSON.stringify([Z1.oh,Z1.y0,Z1.oy,Z1.mh,Z1.mini])+')');
 ok(Math.abs(Z1.orin.y-(Z0.orin.y+232*32))<1&&Math.abs(Z1.orin.x-Z0.orin.x)<1&&Z1.door.ty===Z0.door.ty+232&&Z1.door.tx===Z0.door.tx&&Math.abs(Z1.py-(Z0.py+232*32))<1&&Z1.en===Z0.en,'NORTH +8: NPCs, door, hero and spawns all moved down together');
 ok(Z1.doorTile&&Z1.orinOk&&Z1.guardOk&&Z1.cryptIn&&Z1.gates&&Z1.fish&&Z1.chapel&&Z1.inn&&Z1.way,'NORTH +8: house door, NPCs, guards, crypt stairs, gates, fishing spots, chapel, inn and waystones still sit on the right tiles ('+JSON.stringify([Z1.doorTile,Z1.orinOk,Z1.guardOk,Z1.cryptIn,Z1.gates,Z1.fish,Z1.chapel,Z1.inn,Z1.way])+')');
 ok(Z1.zonePl==='ow'&&Z1.crypt==='crypt'&&Math.abs(Z1.town.y0-(Z0.town.y0+232*32))<1,'zones: hero is still in the overworld, crypt rows untouched, town rectangle moved');
 await tapBtn('UNDO');await sleep(150);const Z2=await SZ();
 ok(Z2.oh===48&&Z2.y0===0&&Z2.mw===64&&Math.abs(Z2.orin.y-Z0.orin.y)<1&&Z2.door.ty===Z0.door.ty&&Math.abs(Z2.py-Z0.py)<1&&Z2.doorTile&&Z2.mini[1]===96,'UNDO of the expansion restores the old size and every position ('+JSON.stringify([Z2.oh,Z2.y0])+')');
 await tapBtn('REDO');await tapBtn('EXPAND');
 await tapBtn('+16');await tapBtn('EAST +16');await tapBtn('+4');await tapBtn('WEST +4');await tapBtn('+8');await tapBtn('SOUTH +8');await sleep(200);const Z3=await SZ();
 ok(Z3.mw===64+16+4&&Z3.oh===48+8+8&&Z3.y0===224&&Z3.ox===4&&Z3.oy===232&&Z3.mh===224+64,'EAST +16, WEST +4, SOUTH +8 stack up ('+JSON.stringify([Z3.mw,Z3.oh,Z3.ox,Z3.oy,Z3.mh])+')');
 ok(Math.abs(Z3.orin.x-(Z0.orin.x+4*32))<1&&Z3.door.tx===Z0.door.tx+4&&Z3.doorTile&&Z3.orinOk&&Z3.guardOk&&Z3.cryptIn&&Z3.gates&&Z3.fish&&Z3.chapel&&Z3.inn&&Z3.way,'WEST +4 shifts objects right and everything still lines up with its tiles');
 // paint in the new northern strip, reload, still there; play-mode bounds respect the new size
 const NT=await E(()=>{const d=__game.dbg;d.edPush({k:'tiles',t:[[10,d.OWY0v+2,d.T.W]]});return d.map[d.OWY0v+2][10]===d.T.W;});ok(NT,'tiles in the new area can be painted');
 await tapBtn('EXPORT');const ex2=await E(()=>document.getElementById('edExportText').value);let j2=null;try{j2=JSON.parse(ex2);}catch(e){}
 ok(j2&&j2.world.expand.n===8&&j2.world.expand.s===8&&j2.world.expand.e===16&&j2.world.expand.w===4&&j2.world.cols===84&&j2.world.rows===64&&j2.ops.filter(o=>o.k==='expand').length===4,'EXPORT includes the expansion ('+JSON.stringify(j2&&j2.world)+')');
 await E(()=>{document.getElementById('edExport').style.display='none';});
 const OLDFR=await E(()=>{const p={x:14.5*32,y:38*32+28};__game.dbg.edFrameFix(p,[0,0,48]);return p;});
 ok(Math.abs(OLDFR.x-(14.5*32+4*32))<1&&Math.abs(OLDFR.y-(38*32+28+232*32))<1,'a save from the old world size moves the hero by the same offset');
 await E(()=>__game.dbg.edExit());await sleep(300);
 const PL=await E(()=>{const g=__game,w=g.dbg.world();g.P.x=5.5*32;g.P.y=(g.dbg.OWY0v+3)*32+10;g.P.grace=99;g.tp&&0;return 1;});
 await pg.keyboard.down('ArrowUp');await sleep(1800);await pg.keyboard.up('ArrowUp');
 const PU=await E(()=>{const g=__game,w=g.dbg.world();return {y:g.P.y,z:w.zoneOfPx(g.P.y),cy:g.cam.y,min:g.dbg.OWY0v*32,ch:__game.size.VH,mh:w.MH};});
 ok(PU.z==='ow'&&PU.y>=PU.min&&PU.cy>=PU.min-1&&PU.cy+PU.ch<=PU.mh*32+1,'play mode: hero and camera stay inside the expanded overworld ('+JSON.stringify(PU)+')');
 await pg.reload();await sleep(800);
 const Z4=await E(()=>{const d=__game.dbg,g=__game;return {mw:d.MWv,oh:d.OWHv,y0:d.OWY0v,w:d.map[d.OWY0v+2][10]===d.T.W,orinx:g.npcs.find(q=>q.name==='Elder Orin').x,doorOk:d.map[d.HOUSE_DOOR.ty-1][d.HOUSE_DOOR.tx]===d.T.D};});
 ok(Z4.mw===84&&Z4.oh===64&&Z4.y0===224&&Z4.w&&Math.abs(Z4.orinx-(Z0.orin.x+4*32))<1&&Z4.doorOk,'after a reload the expanded world (and the paint in it) is rebuilt ('+JSON.stringify(Z4)+')');
 await E(()=>{const g=__game;g.state='paused';});await sleep(200);await E(()=>__game.dbg.edOpen());await E(()=>{__game.state='editor';});await sleep(400);
 await tapBtn('RESET');await tapBtn('RESET');const Z5=await SZ();
 ok(Z5.mw===64&&Z5.oh===48&&Z5.y0===0&&Z5.ox===0&&Z5.oy===0&&Math.abs(Z5.orin.x-Z0.orin.x)<1&&Math.abs(Z5.orin.y-Z0.orin.y)<1&&Z5.door.tx===Z0.door.tx&&Z5.doorTile&&Z5.mini[1]===96,'RESET returns the world to its original size and positions ('+JSON.stringify([Z5.mw,Z5.oh,Z5.y0])+')');
 await E(()=>__game.dbg.edExit());const fin=await E(()=>({s:__game.state,S:__game.size.S}));
 ok(fin.s==='play'&&fin.S===st.S,'EXIT returns to play at the normal scale');
 ok(errs.length===0,'no page errors '+errs.join('|'));
 await finish();
})();
