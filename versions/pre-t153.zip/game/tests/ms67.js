// M67 (t150u): HUD layout must not collide on iPhone landscape. Perf mode must NOT shrink VW/S.
//   node tests/ms67.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms67',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t150/.test(tags),'backup tag backup-pre-t150');
 await E(()=>__game.dbg.startFromTitle());await sleep(900);
 // Force perf ON (the regression path) and re-layout
 let s=await E(()=>{
   SET.perf=true;SET.fps=false;if(typeof qualApply==='function')qualApply();else resize();
   layoutTouch();
   const hero={x:SL+8,y:ST+8,w:178,h:60};
   const run=runBtn();
   const pause=btn.pause;
   const overlaps=(a,b)=>a.x<a2x(b)&&a.x+a.w>b.x&&a.y<a2y(b)&&a.y+a.h>b.y;
   function a2x(b){return b.x-(b.r||0);} function a2y(b){return b.y-(b.r||0);}
   const runBox={x:run.x-run.r,y:run.y-run.r,w:run.r*2,h:run.r*2};
   const pauseBox={x:pause.x-pause.r,y:pause.y-pause.r,w:pause.r*2,h:pause.r*2};
   const ovRun=!(runBox.x+runBox.w<hero.x||runBox.x>hero.x+hero.w||runBox.y+runBox.h<hero.y||runBox.y>hero.y+hero.h);
   const ovPause=!(pauseBox.x+pauseBox.w<hero.x||pauseBox.x>hero.x+hero.w||pauseBox.y+pauseBox.h<hero.y||pauseBox.y>hero.y+hero.h);
   // also ensure RUN sits clearly below the hero card
   const runBelow=run.y-run.r > hero.y+hero.h+8;
   return {VW,VH,S,DPR,perf:SET.perf!==false,hero,run,pause,ovRun,ovPause,runBelow,css:cv.style.width};
 });
 ok(s.perf,'performance mode on');
 ok(s.DPR<=2,'DPR capped at 2 (got '+s.DPR+')');
 // On phone landscape (~844x390 CSS), VW must stay near CSS width — NOT capped ~420
 if(MOB){
   ok(s.VW>=700,'mobile landscape VW not artificially capped (VW='+s.VW+', need >=700)');
   ok(s.VH>=300,'mobile landscape VH not shrunk (VH='+s.VH+')');
 } else {
   ok(s.VW>=480,'desktop VW reasonable ('+s.VW+')');
 }
 ok(!s.ovRun,'RUN does not overlap hero panel (run@'+Math.round(s.run.x)+','+Math.round(s.run.y)+' hero '+JSON.stringify(s.hero)+')');
 ok(s.runBelow||!MOB,'RUN sits below the hero card on mobile');
 ok(!s.ovPause,'pause button does not overlap hero panel');
 // resize source must not contain the t149 VW-cap loop
 const main=fs.readFileSync(__dirname+'/../src/main.js','utf8');
 ok(!/while\s*\(!EDS&&Math\.floor\(dw\/\(S\+1\)\)>=420\)/.test(main),'main.js has no VW<=420 bump loop');
 ok(!/S=Math\.max\(2,S\)/.test(main),'main.js has no S>=2 perf bump');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');
 ok(/arcane-knight-v5[6-9]/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v56');
 await sleep(200);ok(errs.length===0,'no page errors '+errs.slice(0,2).join(' | '));
 await finish();
})();
