// M69 (t152u): camera follow + crisp DPR + regression sweep.
//   node tests/ms69.js [desktop|mobile]
const boot=require('./lib/ms'),fs=require('fs'),cp=require('child_process');
(async()=>{
 const MOB=process.argv[2]==='mobile';
 const {pg,E,ok,sleep,finish}=await boot('ms69',{town:true,grow:true,device:MOB?'iPhone 14 Pro landscape':undefined});
 const errs=[];pg.on('pageerror',e=>errs.push(String(e)));
 let tags='';try{tags=cp.execSync('git tag -l "backup-*"',{cwd:__dirname+'/..'}).toString();}catch(e){}
 ok(/backup-pre-t152/.test(tags),'backup tag backup-pre-t152');
 await E(()=>__game.dbg.startFromTitle());await sleep(900);
 // camera follows after walk
 let s=await E(()=>{
   SET.perf=false;SET.fps=true;qualApply();
   P.x=21*32;P.y=262*32;state='play';DLG=null;WARP=null;FISH.on=false;B=null;snapCam();
   const x0=P.x;P.x+=350;
   for(let i=0;i<50;i++)update(1/30);
   return {dx:Math.abs(cam.x-(P.x-VW/2)),off:P.x-cam.x,VW,DPR,S,EN:typeof EN_AI_I};
 });
 ok(s.dx<2,'camera follows player after walk (dx='+s.dx.toFixed(2)+')');
 ok(Math.abs(s.off-s.VW/2)<4,'player roughly centered (offX='+s.off.toFixed(1)+' VW/2='+(s.VW/2)+')');
 ok(s.DPR===2||s.DPR===1,'DPR is 1 or 2 (got '+s.DPR+') — never forced soft 1-only path incorrectly');
 // dialog: camera still follows
 s=await E(()=>{
   DLG={name:'T',lines:['Hello traveler'],i:0,c:99};P.x+=180;
   for(let i=0;i<50;i++)update(1/30);
   const dx=Math.abs(cam.x-(P.x-VW/2));DLG=null;return {dx};
 });
 ok(s.dx<2,'camera follows during dialog (dx='+s.dx.toFixed(2)+')');
 // EN_AI_I declared
 ok(fs.readFileSync(__dirname+'/../src/player/movement.js','utf8').includes('let EN_AI_I=0'),'EN_AI_I is declared (was throwing and skipping cam)');
 ok(fs.readFileSync(__dirname+'/../src/player/movement.js','utf8').includes('function camFollow'),'camFollow helper exists');
 // no VW caps
 ok(!/while\s*\(!EDS&&Math\.floor\(dw\/\(S\+1\)\)>=420\)/.test(fs.readFileSync(__dirname+'/../src/main.js','utf8')),'no VW<=420 loop');
 // forge interior only
 s=await E(()=>{let yard=0,inside=0;const door=SMITH_SHOP.door;
   for(let y=0;y<MH;y++)for(let x=0;x<MW;x++)if(map[y][x]===T.ANV||map[y][x]===T.FRN){
     const near=door&&Math.abs(x-door.tx)<=4&&y>=door.wy-5&&y<=door.wy;if(near)inside++;else yard++;}
   return {yard,inside};});
 ok(s.yard===0&&s.inside>=1,'forge props inside only (yard='+s.yard+' inside='+s.inside+')');
 // house does not bump S
 s=await E(()=>{const s0=S;P.x=SPAWN.x;P.y=SPAWN.y;if(typeof houseZoomWant==='function'){HZ=true;resize();}const sH=S;HZ=false;resize();return {s0,sH,S};});
 ok(s.sH===s.S||s.sH<=s.s0,'house does not enlarge HUD via S bump');
 // perfOn no longer forces DPR1
 s=await E(()=>{SET.perf=true;qualApply();const d1=DPR;SET.perf=false;qualApply();return {perfDpr:d1,hqDpr:DPR,def:SET_DEFAULT.perf};});
 ok(s.def===false,'perf defaults OFF');
 ok(s.perfDpr<=2&&s.hqDpr<=2,'both modes DPR<=2');
 const sw=fs.readFileSync(__dirname+'/../sw.js','utf8');
 ok(/arcane-knight-v58/.test(sw)&&sw===fs.readFileSync(__dirname+'/../app/www/sw.js','utf8'),'service worker v58');
 await sleep(300);ok(errs.length===0,'no page errors '+errs.slice(0,3).join(' | '));
 await finish();
})();
