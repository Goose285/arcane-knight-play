/* =====================================================================
   SETTINGS SCREEN (pause menu or the gear on the title): volume, text size, colour-blind assist, left-handed, gamepad, tutorial.
   ===================================================================== */
UI_STATES.push('settings');
function openSettings(from){openUIMode('settings',from);}
function setRowBox(x0,y,W,h,isSel){ctx.fillStyle=isSel?'#3a2618':'#22140b';ctx.fillRect(x0,y,W,h);ctx.fillStyle='#7dd3ff';ctx.fillRect(x0,y,3,h);if(isSel){ctx.strokeStyle='#ffe14d';ctx.lineWidth=2;ctx.strokeRect(x0+1,y+1,W-2,h-2);}}
function volRow(key,label){
  return {sel:true,h:44,act(which){setVol(key,which==='minus'?-.1:.1);},draw(x0,y,W,h,isSel,si){
    setRowBox(x0,y,W,h,isSel);txt(label,x0+10,y+18,{size:10,col:'#e8e0c8',lw:2});
    const bx=x0+10,bw=W-130;for(let i=0;i<10;i++){ctx.fillStyle=i<Math.round(SET[key]*10)?'#7dd3ff':'#2c2650';ctx.fillRect(bx+i*(bw/10),y+26,bw/10-3,10);}
    txt(Math.round(SET[key]*100)+'%',x0+W-98,y+34,{size:9,col:'#b9b4d8',align:'right',bold:false});
    uiButton(x0+W-86,y+8,36,28,'-',true,()=>{UI.sel=si;setVol(key,-.1);},{tag:'set:'+key+':minus',clip:true,size:16,bg:'#3a2a5a',bd:'#b090ff',sel:si});
    uiButton(x0+W-44,y+8,36,28,'+',true,()=>{UI.sel=si;setVol(key,.1);},{tag:'set:'+key+':plus',clip:true,size:16,bg:'#3a2a5a',bd:'#b090ff',sel:si});}};
}
function optRow(label,tag,val,fn,hint){   // single button showing the current value
  return {sel:true,h:44,act(which){fn(which==='minus'?-1:1);},draw(x0,y,W,h,isSel,si){
    setRowBox(x0,y,W,h,isSel);txt(label,x0+10,y+18,{size:10,col:'#e8e0c8',lw:2});if(hint)txt(hint,x0+10,y+34,{size:8,col:'#9aa0ff',bold:false});
    const bw=Math.min(190,W*.5);uiButton(x0+W-bw-8,y+8,bw,28,val(),true,()=>{UI.sel=si;fn(1);},{tag:'set:'+tag,clip:true,size:10,bg:'#1c3a5a',bd:'#7dd3ff',sel:si});}};
}
UI_MODES.settings={title:()=>'SETTINGS',sub:()=>['Saved on this device','#7dd3ff'],rows(){
  const r=[{t:'head',s:'AUDIO'},volRow('master','MASTER VOLUME'),volRow('music','MUSIC'),volRow('sfx','SOUND EFFECTS'),
    {t:'head',s:'DISPLAY'},
    optRow('TEXT SIZE','text',()=>TEXT_SIZES[SET.text].n,d=>setCycle('text',TEXT_SIZES.length,d),'Dialogues and small labels'),
    optRow('COLOUR-BLIND MODE','cb',()=>CB_MODES[SET.cb].n,d=>setCycle('cb',CB_MODES.length,d),'Re-maps colours that look alike'),
    {h:34,draw(x0,y,W,h){ctx.fillStyle='#120f26';ctx.fillRect(x0,y,W,h);['#e8504a','#4ade80','#ff9a3d','#4a8aff','#c58bff','#ffd23f'].forEach((c,i)=>{ctx.fillStyle=c;ctx.fillRect(x0+10+i*34,y+6,28,22);});txt('preview',x0+W-8,y+21,{size:8,col:'#9aa0ff',align:'right',bold:false});}},
    optRow('REWARD POPUP STYLE','pop',()=>POP_STYLES[SET.pop|0].n,d=>{setCycle('pop',POP_STYLES.length,d);if(typeof revealPreview==='function')revealPreview();},'How new items, cards and level-ups are shown'),
    optRow('PERFORMANCE MODE','perf',()=>SET.perf?'ON':'OFF',()=>{SET.perf=!SET.perf;setSave();setApply();},'ON = lighter FX (fog/lights/HD). Pixels stay sharp either way'),
    optRow('SHOW FPS','fps',()=>SET.fps?'ON':'OFF',()=>{SET.fps=!SET.fps;setSave();},'Overlay frame rate in the corner (for diagnosing lag)'),
    {t:'head',s:'CONTROLS'},
    optRow('LEFT-HANDED LAYOUT','lefty',()=>SET.lefty?'ON':'OFF',()=>setToggle('lefty'),'Mirrors the touch layout: SHOT + card fan left, stick right'),
    optRow('GAMEPAD','pad',()=>SET.pad?'ON':'OFF',()=>setToggle('pad'),PAD.on?'Connected: '+String(PAD.id).slice(0,30):'Stick move, A shoot, B talk, Start pause'),
    {t:'head',s:'HELP'},
    optRow('TUTORIAL','tut',()=>'REPLAY',()=>{if(tutOff()){uiMsg('Tutorial is disabled here');return;}SET.tutDone=false;setSave();closeUI();state='play';tutStart();},'Walk-through of the basics')];
  return r;}};
