/* =====================================================================
   t153u: expand Oakvale WEST + real Blacksmith & Tavern buildings;
   fishing extras live in player/fish-plus.js.
   ===================================================================== */
(function t153Town(){
  // claim buildings so t148 carved-cottage builders skip
  try{if(typeof SMITH_SHOP!=='undefined')SMITH_SHOP.west=true;if(typeof TAVERN!=='undefined')TAVERN.west=true;}catch(e){}

  const TSZ=()=>typeof TS==='number'?TS:32;
  function ty(y){return (typeof OY==='number'?OY:0)+y;}
  function tx(x){return (typeof OX==='number'?OX:0)+x;}
  function put(x,y,id){const X=tx(x),Y=ty(y);if(Y>=0&&Y<MH&&X>=0&&X<MW)map[Y][X]=id;}
  function get(x,y){const X=tx(x),Y=ty(y);return (Y>=0&&Y<MH&&X>=0&&X<MW)?map[Y][X]:-1;}
  function fill(x0,y0,x1,y1,id){for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++)put(x,y,id);}
  function rectBldg(x0,y0,w,h,doorOff){
    // roof row, walls, floor, door on south facade
    for(let y=y0;y<y0+h;y++)for(let x=x0;x<x0+w;x++){
      if(y===y0)put(x,y,T.R);
      else if(y===y0+h-1)put(x,y,(x===x0+doorOff)?T.D:T.H);
      else if(x===x0||x===x0+w-1)put(x,y,T.H);
      else put(x,y,T.F);
    }
    // path south of door
    const dx=x0+doorOff;for(let k=0;k<2;k++){const t=get(dx,y0+h+k);if(t===T.G||t===T.L||t===T.K||t===T.PLB)put(dx,y0+h+k,T.P);}
    return {x0,y0,w,h,door:{tx:tx(x0+doorOff),wy:ty(y0+h-1),lx:x0+doorOff,ly:y0+h-1}};
  }

  const STATE={ready:false};
  function expandWest(){
    // grow town AABB west by ~8 tiles and clear soft land for the new quarter
    const pad=8;
    TOWN.x0=Math.min(TOWN.x0,(tx(3)-pad)*TSZ());
    // clear / soft-fill the western strip into village grass + path spine
    const xL=0,xR=8,yT=31,yB=44;
    for(let y=yT;y<=yB;y++)for(let x=xL;x<=xR;x++){
      const t=get(x,y);
      if(t===T.T||t===T.K||t===T.G||t===T.L||t===-1||t===T.PLB)put(x,y,T.G);
    }
    // west road from gate line up to the new shops
    for(let y=33;y<=43;y++)put(4,y,T.P);
    for(let x=1;x<=7;x++)put(x,37,T.P);
    for(let x=1;x<=7;x++)put(x,42,T.P);
    // lamps + planters along the new road
    for(const [x,y] of [[2,36],[6,36],[2,41],[6,41],[3,33],[5,33]]){
      if(get(x,y)===T.G||get(x,y)===T.P)put(x,y,T.Z);
    }
    if(typeof T.PLB!=='undefined'){
      for(const [x,y] of [[1,35],[7,35],[1,40],[7,40],[3,38],[5,38]])if(get(x,y)===T.G)put(x,y,T.PLB);
    }
  }

  function undoCarvedSmith(){
    // t148 carved Brum's old cottage into a shop; restore a plain house if we find that pattern
    try{
      const n=NPCS.find(q=>q.name==='Blacksmith Brum');if(!n)return;
      // if SMITH_SHOP was the carved one (door near original yard), restore floors north of old door to house tiles
      if(SMITH_SHOP&&SMITH_SHOP.door&&SMITH_SHOP.door.x0!=null&&!SMITH_SHOP.west){
        const {x0,x1,wy}=SMITH_SHOP.door;
        for(let y=wy-4;y<wy;y++)for(let x=x0;x<=x1;x++){
          if(y<0||y>=MH||x<0||x>=MW)continue;
          if(map[y][x]===T.F||map[y][x]===T.ANV||map[y][x]===T.FRN||map[y][x]===T.B){
            map[y][x]=(y===wy-4)?T.R:(x===x0||x===x1)?T.H:T.F;
          }
        }
        // clear leftover ANV/FRN in open grass
        if(typeof clearStrayForge==='function')clearStrayForge();
      }
    }catch(e){}
  }

  function buildWestSmith(){
    // Distinct forge: 6x5, chimney, slate roof, interior racks
    const b=rectBldg(1,33,6,5,3);
    // chimney stack on roof
    put(2,32,T.BT);put(2,33,T.BT);
    // interior: furnace back-left, anvil, weapon racks (use BT as rack posts), floor details
    put(2,34,T.FRN);put(3,35,T.ANV);put(5,34,T.BT);put(5,35,T.BT);
    // Brum inside, slightly north of door
    const n=NPCS.find(q=>q.name==='Blacksmith Brum');
    if(n){n.x=(tx(4)+.5)*TSZ();n.y=(ty(36)+.55)*TSZ();n.hx=n.x;n.hy=n.y;n.smith=true;
      n.lines=['Heat and hammer - that is the Brum way.','Need a rod for the river, or a sharper card? The forge is open.','Stay clear of the furnace - she bites hotter than any goblin.'];}
    // sign outside
    if(!NPCS.some(q=>q.name==="Brum's Forge Sign")){
      NPCS.push({name:"Brum's Forge Sign",x:(tx(7)+.2)*TSZ(),y:(ty(38)+.3)*TSZ(),spr:'sign',sign:true,
        lines:["BRUM'S FORGE","Open morning to dusk. Rods, cards, and honest steel."]});
    }
    SMITH_SHOP.ready=true;SMITH_SHOP.west=true;SMITH_SHOP.door={tx:b.door.tx,wy:b.door.wy,x0:tx(b.x0),x1:tx(b.x0+b.w-1)};
    return b;
  }

  function buildWestTavern(){
    // Oakvale Tap: 7x5, warm hearth, bar, tables
    const b=rectBldg(1,39,7,5,3);
    // hearth / lanterns
    put(2,40,T.Z);put(6,40,T.Z);put(4,40,T.BT); // bar back
    // Mara inside behind the bar
    let mara=NPCS.find(q=>q.name==='Mara the Tapster');
    if(!mara){
      mara={name:'Mara the Tapster',spr:'inn',tavern:true,lines:[]};
      NPCS.push(mara);
    }
    mara.inn=false; // do NOT reuse inn sleep dialog
    mara.tavern=true;mara.oakTap=true;
    mara.x=(tx(4)+.5)*TSZ();mara.y=(ty(41)+.4)*TSZ();mara.hx=mara.x;mara.hy=mara.y;
    mara.lines=['Welcome to the Oakvale Tap - stew on the fire, rumors on the house.',
      'Try the River Stew - it puts a shine of luck on your next casts.',
      'Dawn and dusk, the big ones bite. Night brings the glowfish.',
      'Pull up a stool. First bowl is honest gold - not free, mind.'];
    // remove duplicate inn:true so openDlg does not route to Rosa's inn
    delete mara.inn;
    // sign
    let sig=NPCS.find(q=>q.name==='Tavern Sign'||q.name==='Oakvale Tap Sign');
    if(!sig){sig={name:'Oakvale Tap Sign',spr:'sign',sign:true,lines:[]};NPCS.push(sig);}
    sig.name='Oakvale Tap Sign';sig.x=(tx(8)+.1)*TSZ();sig.y=(ty(44)+.2)*TSZ();
    sig.lines=['THE OAKVALE TAP','Hot stew, cold ale, warm rumors. Noon till late.'];
    TAVERN.ready=true;TAVERN.west=true;TAVERN.door={tx:b.door.tx,wy:b.door.wy,x0:tx(b.x0),x1:tx(b.x0+b.w-1)};
    TAVERN.stew={gold:18,name:'River Stew',buff:'luck',dur:120,msg:'The stew warms you - fishing luck up for a while!'};
    return b;
  }

  function openTavern(npc){
    const stew=TAVERN.stew||{gold:18,name:'River Stew',buff:'luck',dur:120};
    DLG={name:'MARA THE TAPSTER',lines:npc.lines||['Welcome to the Oakvale Tap!'],i:0,c:0,
      yes:'BUY STEW  '+stew.gold+'G',no:'JUST CHAT',
      choice(){
        if(P.gold<stew.gold){toast('Need '+stew.gold+' gold for a bowl.',2,'#ffb0a0');sfx('clang');return;}
        P.gold-=stew.gold;sfx('coin');sfx('heal');
        if(typeof applyMealBuff==='function')applyMealBuff(stew.buff,stew.dur,stew.name);
        else toast(stew.msg||'Delicious!',2.4,'#ffe14d');
      },
      noAct(){DLG=null;}};
  }

  // Hook dialog: tavern NPCs open stew menu (not inn)
  {const _od=openDlg;openDlg=function(npc){
    if(npc&&(npc.oakTap||(npc.tavern&&npc.name&&/Mara/.test(npc.name)))){openTavern(npc);return;}
    return _od.apply(this,arguments);
  };}

  function run(){
    if(STATE.ready||typeof map==='undefined'||!map||!map.length||typeof TOWN==='undefined')return;
    if(typeof T==='undefined'||T.ANV==null)return;
    try{
      expandWest();
      undoCarvedSmith();
      // allow rebuild
      if(typeof SMITH_SHOP!=='undefined')SMITH_SHOP.ready=false;
      if(typeof TAVERN!=='undefined')TAVERN.ready=false;
      buildWestSmith();
      buildWestTavern();
      if(typeof clearStrayForge==='function')clearStrayForge();
      STATE.ready=true;
    }catch(e){try{console.error('t153 town',e);}catch(_){}}
  }
  setTimeout(run,90);setTimeout(run,450);setTimeout(run,1200);
  window.__t153Town=run;
})();
